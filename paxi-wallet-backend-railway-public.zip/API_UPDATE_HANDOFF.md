# PAXI Wallet Backend API Update Handoff

## Implemented changes

The server-side Jupiter integration was migrated from the retired v6/legacy flow to Jupiter Swap API v2. Quotes now use `GET https://api.jup.ag/swap/v2/order`, raw instruction builds use `GET https://api.jup.ag/swap/v2/build`, and both require the server-only `x-api-key` header from `JUPITER_API_KEY`. Existing input validation and normalized result contracts remain in place.

A Uniswap V3 GraphQL market provider was added to the shared market-provider aggregator. It queries configured Uniswap V3 subgraph endpoints for the top pools containing an ERC-20 token, derives USD price as the token’s `derivedETH` multiplied by the subgraph ETH/USD bundle price, and returns pool TVL as liquidity. It supports Ethereum, Polygon, and Arbitrum and remains disabled unless an endpoint is configured.

The provider registry and definitions now expose Uniswap as a `PRICE` and `LIQUIDITY` provider. New server-only environment variables are `UNISWAP_ETHEREUM_SUBGRAPH_URL`, `UNISWAP_POLYGON_SUBGRAPH_URL`, `UNISWAP_ARBITRUM_SUBGRAPH_URL`, and optional `UNISWAP_API_KEY`. `UNISWAP_SUBGRAPH_URL` is accepted as an Ethereum compatibility alias.

## Validation

`npm run check` passed. The full Vitest suite passed with 95 test files and 456 tests. The production build passed with Vite and esbuild; existing bundle-size and dynamic-import warnings remain non-blocking.

## Deployment note

The deployment must provide valid Uniswap V3 GraphQL endpoint URLs obtained from the selected Graph/Uniswap deployment and `JUPITER_API_KEY` for Jupiter Swap API v2 operations. API keys must remain server-side and must not use a `VITE_` prefix.

## References

[1]: https://dev.jup.ag/docs/swap "Jupiter Swap API overview"
[2]: https://dev.jup.ag/docs/api-reference/swap/v2/order "Jupiter Swap API v2 Get Order"
[3]: https://dev.jup.ag/docs/api-reference/swap/v2/build "Jupiter Swap API v2 Build Transaction"
[4]: https://developers.uniswap.org/docs/ecosystem/subgraphs/concepts/v3/queries "Uniswap V3 subgraph queries"
