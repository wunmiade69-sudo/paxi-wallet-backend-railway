# PAXI Wallet — Production Dependency Audit Findings and High-Severity Remediation

**Audit command:** `npm audit --omit=dev`  
**Recorded result:** exit 1; **21 production findings**  
**Severity totals:** **3 high, 11 moderate, 7 low, 0 critical**  
**Current disposition:** Reviewed and accepted for controlled beta; not a clean dependency audit. No `npm audit fix --force` was run.

> The audit output mixes direct packages and transitive packages. A package appearing in an affected dependency path does not necessarily mean that PAXI directly invokes the vulnerable function. Reachability and exploitability must be re-evaluated after every dependency change.

## Executive summary

The findings are concentrated in two active dependency families: the Solana SDK tree and WalletConnect’s legacy ethers/protocol tree. The three high-severity findings are all in the Solana path: `@solana/buffer-layout-utils`, `@solana/spl-token`, and `bigint-buffer`. The direct high-severity package is `@solana/spl-token`; the other two are transitive packages in the same Solana token/account parsing path.

npm’s suggested remediation is not a normal patch update. For the high Solana findings, npm proposes `@solana/spl-token@0.1.8` or a related `@solana/web3.js@0.0.3` tree change, which the repository records as compatibility-sensitive or semver-major metadata. Those versions were **not installed**. The safe approach is a dedicated Solana dependency migration branch, a compatible supported release set, full regression testing, staged deployment, and a fresh production audit.

## All 21 findings

| # | Package | Severity | Directness | Installed version / affected range | What the audit indicates | Current disposition and remediation |
|---:|---|---:|---|---|---|---|
| 1 | `@ethersproject/abstract-provider` | Low | Transitive | `5.8.0`; advisory range `*` | Present in the legacy ethers/WalletConnect provider tree. It is not part of the PAXI v6 local signer path, but may load through WalletConnect authentication/provider code. | **Accepted/reviewed.** Keep WalletConnect disabled and request-approved; upgrade the complete WalletConnect tree in a compatibility-tested release. |
| 2 | `@ethersproject/abstract-signer` | Low | Transitive | `5.8.0`; advisory range `*` | Present in the legacy WalletConnect signer dependency path. PAXI’s local signing architecture uses ethers v6 and does not send private keys to this package. | **Accepted/reviewed.** Do not independently override legacy ethers packages; migrate the complete WalletConnect tree and re-run signing/request tests. |
| 3 | `@ethersproject/hash` | Low | Transitive | `5.8.0`; affected `5.0.6–5.8.0` | Reachable through WalletConnect authentication and message-processing dependencies, not through the PAXI vault cryptography helpers. | **Accepted/reviewed.** Keep sessions user-approved and bounded; upgrade WalletConnect as a tested unit. |
| 4 | `@ethersproject/signing-key` | Low | Transitive | `5.8.0`; affected `<=5.8.0` | Nested legacy signing-key code may load through WalletConnect. It is not used for the vault’s primary key derivation/encryption boundary. | **Accepted/reviewed.** No private key is supplied to external providers; resolve through a complete WalletConnect major migration. |
| 5 | `@ethersproject/transactions` | Low | Transitive | `5.8.0`; affected `<=5.8.0` | Reachable through WalletConnect transaction serialization/provider dependencies. | **Accepted/reviewed.** Preserve chain, address, method, and user-intent validation; upgrade with pairing and signing regression tests. |
| 6 | `@solana/buffer-layout-utils` | **High** | Transitive | `0.3.0`; audit range `*` | Loaded by the active Solana SPL-token tree for binary layout and token/account data handling. Crafted remote RPC/account data is the relevant threat surface. | **Accepted/reviewed; unresolved upstream.** Migrate the Solana SDK tree together, validate all decoded account/token data, and re-audit after a canary upgrade. |
| 7 | `@solana/spl-token` | **High** | Direct | `0.4.15`; audit range `*` | Directly used by Solana token transfers and Gift Code/token fulfillment. Its dependency graph includes vulnerable layout, bigint, extension, and web3 packages. | **Accepted/reviewed; unresolved upstream.** Upgrade the supported SPL-token/web3-compatible set together; re-run all Solana transfer, token, Gift Code, and recovery tests before promotion. |
| 8 | `@solana/spl-token-group` | Moderate | Transitive | `0.0.7`; audit range `*` | Installed through SPL-token extension dependencies. No direct PAXI import of token-group functionality was identified. | **Accepted/reviewed.** Remove or resolve through the planned SPL-token tree migration after confirming extension compatibility. |
| 9 | `@solana/spl-token-metadata` | Moderate | Transitive | `0.1.6`; audit range `*` | Installed through SPL-token extension dependencies; not a direct PAXI feature boundary in the reviewed source. | **Accepted/reviewed.** Resolve through the supported Solana dependency migration and re-audit. |
| 10 | `@solana/web3.js` | Moderate | Direct | `1.98.4`; affected through `1.98.4` in the audit range | Directly used for Solana RPC, account lookup, transaction construction, and confirmation. Exposure depends on affected RPC/parser paths and attacker-controlled data. | **Accepted/reviewed; unresolved upstream.** Upgrade with the compatible Solana tree; preserve bounded RPC calls, chain/address validation, response validation, confirmation checks, and fail-closed fulfillment. |
| 11 | `@stablelib/ed25519` | Moderate | Transitive | `1.0.3`; affected `<=2.0.2` | Nested under WalletConnect relay authentication. The relevant scenario is signature-validation behavior in the relay/auth tree, not PAXI vault encryption. Advisory: [GHSA-x3ff-w252-2g7j](https://github.com/advisories/GHSA-x3ff-w252-2g7j). | **Accepted/reviewed.** Keep WalletConnect disabled in beta and upgrade the complete WalletConnect protocol family with pairing/session tests. |
| 12 | `@walletconnect/auth-client` | Low | Transitive | `2.1.2`; affected range `>=0.4.0-4794884` | Loaded by the active WalletConnect authentication dependency tree. | **Accepted/reviewed.** Exchange only public session metadata and approved requests; upgrade the full WalletConnect tree. |
| 13 | `@walletconnect/core` | Moderate | Transitive/direct tree | `2.23.10` root and `2.17.1` nested; affected through `2.19.1` | Active in pairing, relay, session, and request orchestration. | **Accepted/reviewed.** Keep WalletConnect fail-closed and upgrade the complete coupled tree rather than applying a partial override. |
| 14 | `@walletconnect/relay-auth` | Moderate | Transitive | `1.1.0` root and `1.0.4` nested; affected `<=1.0.4` | Active relay-auth dependency; the nested `1.0.4` path is affected. | **Accepted/reviewed.** Keep relay/session failures fail-closed; resolve through a tested WalletConnect upgrade. |
| 15 | `@walletconnect/sign-client` | Moderate | Transitive | `2.17.1`; affected ranges through `2.19.1` | Active WalletConnect session and signing client. npm reports `fixAvailable: true` without providing a version. | **Accepted/reviewed.** Do not apply an unversioned transitive override; resolve with the complete WalletConnect migration and pairing/signing verification. |
| 16 | `@walletconnect/utils` | Moderate | Direct/transitive tree | `2.23.10` root and `2.17.1` nested; affected `2.15.0-canary.1–2.19.1` | Active request, encoding, and protocol utility path. | **Accepted/reviewed.** Preserve request type, chain, address, and user-intent validation; upgrade the complete tree. |
| 17 | `@walletconnect/web3wallet` | Moderate | Direct | `1.16.1`; audit range `*` | Directly used by the client WalletConnect integration for pairing and approved signing requests. | **Accepted/reviewed; unresolved upstream.** WalletConnect remains disabled and fail-closed; upgrade in a dedicated compatibility branch before reconsidering enablement. |
| 18 | `bigint-buffer` | **High** | Transitive | `1.1.5`; affected `<=1.1.5` | High-severity bigint buffer-overflow advisory in the Solana binary conversion path. Advisory: [GHSA-3gc7-fjrx-p6mg](https://github.com/advisories/GHSA-3gc7-fjrx-p6mg), CVSS 7.5 as recorded by npm. | **Accepted/reviewed; unresolved upstream.** Use strict bounds on token/account inputs and bounded RPC data now; upgrade the Solana dependency tree and verify every token-transfer path. |
| 19 | `elliptic` | Low | Transitive | `6.6.1`; affected `<=6.6.1` | Nested legacy crypto dependency under WalletConnect/ethers v5. PAXI’s primary vault cryptography does not use this package. Advisory: [GHSA-848j-6mx2-7j84](https://github.com/advisories/GHSA-848j-6mx2-7j84). | **Accepted/reviewed.** The existing override prevents drift but is not a resolution; migrate the WalletConnect tree and remove the vulnerable legacy path. |
| 20 | `jayson` | Moderate | Transitive | `4.3.0`; affected `>=2.0.6` | Nested under Solana web3.js for JSON-RPC client behavior and reachable when Solana RPC calls execute. | **Accepted/reviewed.** Keep RPC endpoints, timeouts, response validation, and confirmation checks enforced; resolve through a compatible Solana web3 migration. |
| 21 | `uuid` | Moderate | Transitive | `8.3.2` under `jayson`; affected `<11.1.1` | The advisory concerns v3/v5/v6 calls with caller-provided buffers. The source review found no direct application-controlled use of those UUID APIs, but the package remains reachable in the Solana/Jayson tree. Advisory: [GHSA-w5hq-g745-h8pq](https://github.com/advisories/GHSA-w5hq-g745-h8pq). | **Accepted/reviewed.** Remove through the planned Solana tree migration and re-audit; no direct vulnerable UUID-buffer path was identified. |

## High-severity findings: what they mean

### `@solana/buffer-layout-utils` — High, transitive

This package is part of the active Solana SPL-token binary layout/account-data path. The relevant risk is processing attacker-controlled or malformed remote account data returned through Solana RPC. The package is not a direct PAXI import, but it is production-reachable through the Solana token dependency tree.

**Safe remediation:** upgrade `@solana/spl-token`, `@solana/web3.js`, and their compatible layout dependencies as one tested Solana dependency set. Do not downgrade to npm’s proposed `@solana/spl-token@0.1.8` merely to make the audit output change. Before promotion, run the full Solana wallet creation/recovery, native send, SPL transfer, Token-2022 classification, Gift Code fulfillment, quote/swap, bridge-status, confirmation-recovery, malformed-RPC-response, and provider-outage suites. Canary the release, inspect runtime errors and transaction outcomes, then run `npm audit --omit=dev` again.

**Current compensating controls:** bounded RPC requests and timeouts, chain/address/token validation, strict token decimals and amount checks, canonical Solana program identifiers, conservative unknown/error handling, and fail-closed unsupported fulfillment.

### `@solana/spl-token` — High, direct

This is a direct dependency used by Solana token and reward flows, so it deserves the highest remediation priority. The audit flags its active dependency graph, including vulnerable layout, bigint, token-extension, and web3 components. This is not safely addressed by changing one nested package in isolation.

**Safe remediation:** select a currently supported, patched `@solana/spl-token` release that is compatible with the selected `@solana/web3.js` version, then migrate the Solana tree together in a dedicated branch. Review API and serialization changes, rebuild native bindings if required, run all Solana and Gift Code regression tests, perform funded testnet transfers and failure/recovery drills, canary the deployment, and repeat the production audit. Keep rollback artifacts and the previous lockfile available.

**Current compensating controls:** explicit token-contract, chain, recipient, decimals, amount, balance, receipt, and confirmation checks; canonical SPL/Token-2022 identifiers; unsupported-token blocking; no server custody of user signing keys; and no forced audit fix.

### `bigint-buffer` — High, transitive

The recorded advisory is a buffer-overflow risk in `toBigIntLE()` and is reachable through Solana buffer-layout utilities. The audit identifies the installed `1.1.5` version as affected and proposes a breaking Solana SPL-token tree change.

**Safe remediation:** upgrade the compatible Solana dependency set so the vulnerable transitive version is removed, then verify the resulting lockfile and dependency graph. Add or retain malformed-buffer, oversized-amount, token-account decoding, and RPC-response boundary tests. Run the complete Solana testnet matrix and re-audit. Do not apply `npm audit fix --force`, an untested `overrides` entry, or a package downgrade without proving compatibility and eliminating the vulnerable path.

**Current compensating controls:** application-level bounds on amounts and decoded values, validated token/account addresses and decimals, bounded RPC response handling, and fail-closed error behavior. These controls reduce exploitability but do not make the dependency advisory resolved.

## Recommended remediation sequence

1. Create a dedicated Solana dependency-upgrade branch from the frozen candidate and preserve the current lockfile for rollback.
2. Select compatible patched releases for `@solana/spl-token`, `@solana/web3.js`, layout utilities, bigint conversion, and related token extensions; verify advisories and release notes rather than accepting npm’s forced proposal automatically.
3. Install with the normal lockfile workflow, inspect `npm ls` for duplicate or vulnerable versions, and run `npm audit --omit=dev` before application changes.
4. Run TypeScript, all automated tests, build, lint, Solana token/account fuzz or malformed-input tests, funded testnet transfers, confirmation recovery, Gift Code fulfillment, and bridge/swap status checks.
5. Canary the dependency upgrade with WalletConnect still disabled, monitor RPC/provider errors and transaction outcomes, retain rollback artifacts, and repeat the audit.
6. Promote only after the high findings are absent or have a separately approved, evidence-backed exception. If organizational policy requires zero high-severity production findings, classify the candidate as **BETA NOT READY** until that condition is met.

## Current release implication

The current PAXI Wallet candidate remains **BETA READY WITH KNOWN ACCEPTED RISKS** only under the documented controlled-beta acceptance. The three high findings are **not resolved** by the current source correction. They remain reviewed and mitigated at the application boundary, with a separate compatible Solana upgrade required. The candidate must not be described as production-ready or dependency-clean.
