# PAXI Wallet Migrations — Bug Review

## Scope and validation

I reviewed the extracted project with emphasis on the wallet-link, fee-ledger, send-quote, send-operation, and migration paths. The repository type-checks successfully and builds successfully. The supported test command also passes all **95 test files and 456 tests**. The initial `--runInBand` invocation was not supported by this Vitest version; rerunning the repository’s plain `npm test` command completed successfully.

These results establish that the current unit tests are green, but they do not cover the concurrency and deployment-path issues below.

## Findings

| Severity | Location | Finding | Impact |
|---|---|---|---|
| **High** | `server/fees/sendOperations.ts:24-33` | State transitions use a read-then-unconditional-update pattern. | Concurrent confirmation/reconciliation requests can both validate against the same old state and then overwrite one another, allowing an invalid final state or losing transaction metadata. |
| **Medium** | `server/fees/sendFee.ts:318-361` | Quote insertion and send-operation insertion are not in one database transaction. | A crash or second-insert failure leaves an orphaned quote; the client receives an error although a usable quote has already been persisted. |
| **Medium** | `scripts/applyWalletSendMigrations.ts:195-196` | The standalone wallet migration assumes `paxiSchemaDeployments` already exists. | `npm run db:wallet-send` can create the wallet/send tables and then fail at the ledger insert when run outside the full `db:deploy` sequence, leaving a partially applied migration. |
| **Low/Medium** | `server/fees/walletLink.ts:71-85` | Challenge consumption is not atomic. | Two concurrent requests can both validate the same unexpired challenge before either deletes it. The unique wallet constraint limits duplicate rows, but the endpoint can still produce inconsistent success/error behavior under replay races. |

### 1. High — send-operation state transitions are vulnerable to a TOCTOU race

`transitionSendOperation` first loads the current row, validates the requested transition in application code, and then updates by `operationId` and `userOpenId` only. The update does **not** include the previously observed state in its `WHERE` clause and does not lock the row. The same pattern is used by reconciliation through `persistReconciliationState`.

For example, two requests can read `FEE_CONFIRMED`. One may transition to `SEND_BROADCAST` while another transitions to `FAILED`. Both calls independently pass their transition checks, and the later update wins. This can leave a terminal or intermediate state that does not reflect the actual event ordering, while also overwriting hashes or reconciliation codes supplied by the other request.

**Recommended fix:** perform the read and transition under a row lock (`SELECT ... FOR UPDATE`) inside a transaction, or use an optimistic conditional update such as `UPDATE ... SET state = :to ... WHERE operationId = :id AND userOpenId = :user AND state = :from`. Verify that exactly one row was affected; on zero affected rows, reload and retry or return a conflict. Add a concurrency test that runs confirmation and reconciliation transitions simultaneously.

### 2. Medium — quote and operation creation are not atomic

`issueSendFeeQuote` inserts into `sendFeeQuotes`, then calls `createSendOperation` separately with the same database handle. There is no surrounding transaction. If the process exits between those statements, or if the operation insert fails because of a schema/data problem, the quote remains without its corresponding operation.

This is particularly undesirable because the quote is presented as an issued, persisted artifact, while the API call fails. It also creates cleanup work and makes retry behavior less deterministic. The unique `(userOpenId, operationId)` quote constraint does not repair this gap because each retry generates a new UUID.

**Recommended fix:** wrap both inserts in one transaction and return only after both succeed. If the product intentionally wants durable quotes without operations, make that explicit and add a reconciliation/cleanup job; otherwise enforce the one-to-one relationship at the transaction boundary.

### 3. Medium — standalone migration path can partially apply and then fail

The migration script checks for `users` and `activityEvents`, creates the wallet/send tables, and finally inserts into `paxiSchemaDeployments`. It does not create or check `paxiSchemaDeployments` itself. The table is created by `scripts/applyDeploymentLedger.ts`, which is called earlier by the composite `db:deploy` script, but `db:wallet-send` is also exposed as an independent npm script.

Therefore, running the wallet migration directly against a database that has the prerequisite business tables but not the deployment ledger can successfully create several tables and then fail with a missing-table error. Because the statements are not wrapped in a transaction, the database is left partially migrated.

**Recommended fix:** either make `db:wallet-send` a private step that cannot be invoked independently, or make the script self-contained by ensuring the deployment ledger exists before applying the wallet schema. Prefer a migration-level transaction where supported, plus explicit checks for `feeConfig` and `feeRecords` before attempting their alterations. The migration should also record its ledger entry only after all schema operations have succeeded.

### 4. Low/Medium — wallet-link challenge use is not single-use under concurrency

`verifyWalletLink` selects an unexpired challenge, verifies the signature, inserts the wallet link if needed, and deletes the challenge in separate statements. Two requests carrying the same valid message and signature can both pass the initial select before either request deletes the challenge. If the wallet link already exists, both may report success; if it does not, one request may fail on the unique key after both have performed verification work.

This is not an obvious wallet-ownership bypass because the signature still must recover to the requested address, and the unique link index prevents duplicate link rows. It is nevertheless a replay/race flaw in a function whose intended semantics are single-use challenge consumption.

**Recommended fix:** consume the challenge atomically, ideally by deleting it with predicates for ID, user, wallet, message, and `expiresAt > NOW()`, then require exactly one deleted row before accepting the signature. Alternatively, lock the challenge row in a transaction and mark it consumed with a unique state transition.

## Additional observations

The migration helpers `addColumnIfMissing` and `addIndexIfMissing` check only whether a name exists. If a pre-existing column or index has the wrong type, collation, uniqueness, or column order, the migration silently accepts the incompatible definition. For a “fixed” migration, schema-shape verification would be safer than name-only checks, especially for `feeRecords_user_operation_idx` and the hash indexes.

The production build emits non-fatal bundle warnings, including large client chunks and dynamic imports that are also statically imported. These are performance and deployment-quality concerns rather than correctness failures. The dependency-audit command did not produce a completed result within the review run and should be executed separately in CI with a bounded timeout.

## Verification summary

| Check | Result |
|---|---|
| TypeScript (`npm run check`) | Passed |
| Unit tests (`npm test`) | Passed: 95 files, 456 tests |
| Production build (`npm run build`) | Passed, with chunking/dynamic-import warnings |
| Database migration execution | Not run: no database connection was provided in the archive review environment |

## Priority order

The first fix should be the **conditional/locked state transition**, because it affects the integrity of confirmed and reconciled wallet operations under normal duplicate-request behavior. The second should be making quote creation and operation creation atomic. The standalone migration issue should be fixed before allowing operators to run `db:wallet-send` independently. Finally, make wallet challenge consumption atomic and add concurrency tests for all three paths.

## References

[1]: `server/fees/sendOperations.ts` — send-operation creation and state transition implementation.
[2]: `server/fees/sendFee.ts` — quote issuance, recording, and reconciliation implementation.
[3]: `scripts/applyWalletSendMigrations.ts` — wallet/send schema migration implementation.
[4]: `server/fees/walletLink.ts` — wallet-link challenge and verification implementation.
[5]: `package.json` — project scripts and test/build commands.

---

**Author:** Manus AI
