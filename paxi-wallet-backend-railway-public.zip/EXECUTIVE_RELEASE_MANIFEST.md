# PAXI Wallet — Executive Controlled-Beta Release Manifest

**Release status:** BETA READY WITH KNOWN SECURITY ACCEPTANCE  
**Release date:** 18 August 2026  
**Source:** Existing PAXI Wallet repository; no architecture rebuild

## Included

The release candidate includes the executive directive implementation, the prior production-hardening pass, focused regression tests, `.env.example`, the dependency audit evidence, and the full completion report:

- `FINAL_EXECUTIVE_BETA_COMPLETION_REPORT.md`
- `FINAL_BETA_GATE_REPORT.md`
- `reports/dependency-audit.json`
- `.env.example`
- client fiat conversion, public-link, bounded-slippage, bridge-route, and THORChain status changes
- server treasury, security, provider, payout, Gift Code, and audit hardening already present in the candidate

## Validation

- `npm run check`: PASS, exit 0
- `npm test -- --run`: PASS, 45 files and 156 tests
- `npm run build`: PASS, exit 0; known large-wallet-chunk and dynamic-import diagnostics documented in the completion report
- `npm run lint`: PASS, exit 0; scoped Prettier gate covers the release changes
- `npm audit --omit=dev`: exit 1 with 21 production findings: 7 low, 11 moderate, 3 high, 0 critical; explicitly accepted/reviewed, not hidden

## Required deployment configuration

Production must provide a healthy MySQL/TiDB-compatible database, explicit server treasury/reward/payout destinations, server-only payout signer configuration, provider/RPC configuration, and an HTTPS `VITE_PAXI_PUBLIC_URL`. Public referral/About links remain unavailable until the real public origin is configured. Fee-bearing swap paths fail closed when their public destination is absent or invalid.

## Archive exclusions

The sanitized archive excludes `node_modules`, `dist`, build output, logs, VCS metadata, real `.env` files, local secrets, and temporary test artifacts. It includes `.env.example` only; all template values are placeholders.

## Owner acceptance

Before controlled-beta promotion, the owner must acknowledge the dependency security acceptance and schedule a compatibility-tested Solana/WalletConnect modernization branch. The post-beta roadmap remains: complete Bitcoin and Solana parity, WalletConnect UI, transaction simulation, dApp security, advanced phishing protection, deeper charts, external security audit, dependency modernization, and load testing.
