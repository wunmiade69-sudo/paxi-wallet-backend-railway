# PAXI Wallet — Final Beta Gate & Production Hardening Report

**Audit date:** 18 August 2026  
**Scope:** Current PAXI Wallet build; no architectural rebuild or redesign  
**Author:** Manus AI

## Executive conclusion

> **BETA READY WITH KNOWN SECURITY ACCEPTANCE**

The final candidate passes TypeScript checking, the full Vitest suite, production build, the scoped release lint gate, focused market/security/approval tests, money-moving regression tests, and a read-only live market-provider smoke test. The two concrete treasury-destination issues found during this pass were remediated: the server no longer falls back to an embedded treasury address, and the client swap-fee destination is now explicit public configuration and fails closed when absent or invalid.

The dependency audit does **not** pass. `npm audit --omit=dev` returns **21 production findings: 7 low, 11 moderate, 3 high, and 0 critical**. All findings are in actively used Solana or WalletConnect dependency trees. The recorded npm remediation metadata requires a major dependency-tree change for the affected direct packages, except for one transitive `sign-client` finding where npm reports `fixAvailable: true` without a version. No forced audit fix, downgrade, or untested override was applied. Because every remaining finding has been reviewed for runtime reachability, exploitability, compensating controls, and a controlled upgrade plan, the appropriate release category is the requested **known security acceptance** category rather than an unqualified `BETA READY`.

The release should be promoted only with the dependency acceptance and operational conditions in Section H recorded by the owner. If the release policy requires zero high-severity production advisories, the decision must instead be treated as **BETA NOT READY** until the Solana tree is upgraded and compatibility-tested.

## A. Overall status

| Decision | Status | Basis |
|---|---|---|
| Final beta decision | **BETA READY WITH KNOWN SECURITY ACCEPTANCE** | Runtime checks pass; 21 upstream dependency findings remain explicitly reviewed and mitigated but not eliminated. |
| Critical blocker | None found in the application logic reviewed during this pass | Treasury fallback removed; payout recovery, Gift Code funding, wallet secrecy, market aggregation, Shield routing, approval validation, and failure fallbacks were verified. |
| Security acceptance | Required | Three high and eleven moderate findings remain in active Solana/WalletConnect runtime trees. |
| Secrets | No real secrets added to `.env.example` or the release changes | Configuration remains placeholder-only; signer material remains server-side. |

The acceptance is not based solely on passing tests. It is based on the combination of dependency provenance review, reachable-code assessment, strict input and transaction validation, provider timeouts and circuit breakers, fail-closed money movement, and a controlled upgrade plan.

## B. Dependency audit

### B.1 Audit facts and remediation policy

The command `npm audit --omit=dev` was run after `npm install --ignore-scripts --no-audit`. It exited with code **1**, as expected for a non-zero vulnerability report, and reported 21 production findings. `npm run security:deps` independently classified the three high/critical findings as upstream-unfixable under the repository’s policy and reported no fixable high/critical findings.

The relevant installed direct versions are `@solana/spl-token@0.4.15`, `@solana/web3.js@1.98.4`, `@walletconnect/core@2.23.10`, `@walletconnect/utils@2.23.10`, and `@walletconnect/web3wallet@1.16.1`. The important nested versions include `@solana/buffer-layout-utils@0.3.0`, `bigint-buffer@1.1.5`, `jayson@4.3.0`, `uuid@8.3.2`, `@stablelib/ed25519@1.0.3`, `@walletconnect/sign-client@2.17.1`, `@walletconnect/core@2.17.1`, `@walletconnect/utils@2.17.1`, `@walletconnect/relay-auth@1.0.4`, `@walletconnect/auth-client@2.1.2`, `@ethersproject/*@5.8.0`, and `elliptic@6.6.1`.

The **Fixed version / npm remediation metadata** column deliberately distinguishes an actual verified patched release from npm’s proposed tree-level remediation. The proposed versions were not treated as safe patch upgrades because they require a major or compatibility-sensitive tree change, and they were not installed.

### B.2 Per-vulnerability disposition

| Package | Severity | Direct / transitive | Affected installed version or range | Fixed version / npm remediation metadata | Runtime reachability and exploitability assessment | Status, mitigation, and planned fix |
|---|---:|---|---|---|---|---|
| `@ethersproject/abstract-provider` | Low | Transitive | 5.8.0; advisory range `*` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Present in the WalletConnect/legacy ethers dependency tree. Not imported by the PAXI v6 signer directly; it can be loaded by WalletConnect authentication/provider paths. | **ACCEPTED/REVIEWED.** WalletConnect session and request approval controls remain; upgrade the complete WalletConnect tree in a compatibility-tested maintenance release. |
| `@ethersproject/abstract-signer` | Low | Transitive | 5.8.0; advisory range `*` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Same legacy WalletConnect signer path. PAXI’s local signing architecture uses ethers v6 and does not send private keys to this package. | **ACCEPTED/REVIEWED.** Keep signer material local/server-side as applicable; migrate the complete WalletConnect tree rather than independently overriding legacy packages. |
| `@ethersproject/hash` | Low | Transitive | 5.8.0; affected `5.0.6–5.8.0` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Reachable through WalletConnect authentication and message-processing dependencies, not through the PAXI vault cryptography helpers. | **ACCEPTED/REVIEWED.** User-approved sessions and bounded request handling are compensating controls; upgrade WalletConnect as a tested unit. |
| `@ethersproject/signing-key` | Low | Transitive | 5.8.0; affected `<=5.8.0` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Nested legacy signing-key code can be loaded by WalletConnect. It is not the PAXI vault’s key derivation or encryption implementation. | **ACCEPTED/REVIEWED.** No private key is supplied to external providers; controlled WalletConnect major upgrade is planned. |
| `@ethersproject/transactions` | Low | Transitive | 5.8.0; affected `<=5.8.0` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Reachable through WalletConnect transaction serialization/provider dependencies. PAXI validates chain and user-approved signing requests before local signing. | **ACCEPTED/REVIEWED.** Maintain request validation and upgrade the full tree with pairing/signing regression tests. |
| `@solana/buffer-layout-utils` | High | Transitive | 0.3.0; audit range `*` | npm proposes `@solana/spl-token@0.1.8`, marked semver-major by npm; no verified safe patch applied | Loaded by the active Solana SPL-token tree for binary layout and account/token data handling. Crafted remote account/RPC data is the relevant threat surface; no application-specific exploit was demonstrated in this pass. | **ACCEPTED/REVIEWED; unresolved upstream.** Solana RPC calls are bounded and validated, and no arbitrary raw binary endpoint is exposed. Upgrade `@solana/spl-token` and its compatible `@solana/web3.js` line in a canary branch, then rerun all Solana transfer and wallet tests. |
| `@solana/spl-token` | High | Direct | 0.4.15; audit range `*` | npm proposes `@solana/spl-token@0.1.8`, semver-major metadata; not applied | Directly used by the Solana wallet/Gift Code and token-transfer paths. Its vulnerable transitive layout packages are therefore production-reachable when those paths execute. | **ACCEPTED/REVIEWED; unresolved upstream.** Supported token addresses, recipients, amounts, decimals, and transaction results are validated; unsupported fulfillment is blocked. Controlled major migration is the planned fix. |
| `@solana/spl-token-group` | Moderate | Transitive | 0.0.7; audit range `*` | npm proposes the same Solana SPL-token tree change | Installed through SPL-token extensions. No direct PAXI import of token-group functionality was found; exposure is conditional on extension/module loading. | **ACCEPTED/REVIEWED.** No independent safe remediation was available; remove only if a future dependency audit proves it unused after an upgrade. |
| `@solana/spl-token-metadata` | Moderate | Transitive | 0.1.6; audit range `*` | npm proposes the same Solana SPL-token tree change | Installed through SPL-token extensions. It is not a direct PAXI feature boundary in the reviewed source. | **ACCEPTED/REVIEWED.** Keep token metadata validation conservative and migrate the Solana tree as a unit. |
| `@solana/web3.js` | Moderate | Direct | 1.98.4; affected `<=0.0.0-pr-29130 || 0.0.4–1.98.4` | npm proposes `@solana/web3.js@0.0.3`, marked semver-major metadata; not applied | Directly used for Solana RPC, account lookup, transaction construction, and confirmation. The advisory is therefore in an active production tree, although exploitability depends on the affected RPC/parser path and attacker-controlled data. | **ACCEPTED/REVIEWED; unresolved upstream.** Chain/address validation, bounded requests, explicit confirmation checks, and fail-closed fulfillment reduce exposure. Perform a controlled Solana major migration with live-test and rollback plan. |
| `@stablelib/ed25519` | Moderate | Transitive | 1.0.3; affected `<=2.0.2` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Nested under WalletConnect relay authentication. A malicious signature-validation scenario is the relevant reachability, not PAXI vault encryption. | **ACCEPTED/REVIEWED.** WalletConnect pairing/user approval and chain/request validation are compensating controls; upgrade the full WalletConnect dependency family. Advisory: [GHSA-x3ff-w252-2g7j][4]. |
| `@walletconnect/auth-client` | Low | Transitive | 2.1.2; range `>=0.4.0-4794884` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Loaded by the active WalletConnect web3 wallet integration during authentication/session flows. | **ACCEPTED/REVIEWED.** Only public session metadata and approved requests are exchanged; use a complete tested WalletConnect upgrade. |
| `@walletconnect/core` | Moderate | Transitive/direct tree | 2.23.10 root and 2.17.1 nested; affected ranges through 2.19.1 | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Active in pairing, relay, session, and request orchestration. | **ACCEPTED/REVIEWED.** Session state is user-approved and request validation is enforced; upgrade all WalletConnect packages together. |
| `@walletconnect/relay-auth` | Moderate | Transitive | 1.1.0 root and 1.0.4 nested; affected `<=1.0.4` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Active relay-auth dependency; the nested 1.0.4 node is the affected path. | **ACCEPTED/REVIEWED.** Keep relay/session failures fail-closed and upgrade the nested tree with compatibility tests. |
| `@walletconnect/sign-client` | Moderate | Transitive | 2.17.1; affected ranges through 2.19.1 | npm reports `fixAvailable: true` without a version; no independent fix was applied | Active WalletConnect session and signing client. The vulnerability is in a production-reachable integration path. | **ACCEPTED/REVIEWED.** Because npm supplied no version and the package is coupled to the WalletConnect protocol family, do not apply an untested transitive override. Resolve during the controlled WalletConnect upgrade and verify pairing/signing. |
| `@walletconnect/utils` | Moderate | Direct/transitive tree | 2.23.10 root and 2.17.1 nested; affected `2.15.0-canary.1–2.19.1` | npm proposes `@walletconnect/web3wallet@1.13.0`, semver-major metadata | Active request, encoding, and protocol utility path. | **ACCEPTED/REVIEWED.** Validate approved request type, chain, address, and user intent; upgrade the complete tree. |
| `@walletconnect/web3wallet` | Moderate | Direct | 1.16.1; audit range `*` | npm proposes `@walletconnect/web3wallet@1.13.0`, marked semver-major metadata; not applied | Directly used by the client WalletConnect integration for pairing and approved signing requests. | **ACCEPTED/REVIEWED; unresolved upstream.** No seed phrase/private key/PIN is sent to WalletConnect; upgrade in a dedicated compatibility branch. |
| `bigint-buffer` | High | Transitive | 1.1.5; affected `<=1.1.5` | npm proposes the Solana SPL-token tree change; no safe direct patch applied | Loaded under `@solana/buffer-layout-utils` and reachable through Solana binary conversion paths. The advisory is [GHSA-3gc7-fjrx-p6mg][1] (CVSS 7.5). | **ACCEPTED/REVIEWED; unresolved upstream.** Use strict token/account input validation and bounded RPC data; upgrade Solana dependencies and verify all token-transfer paths. |
| `elliptic` | Low | Transitive | 6.6.1; affected `<=6.6.1` | npm proposes the WalletConnect tree change; existing override pins 6.6.1 but does not resolve the advisory | Nested legacy crypto dependency under the WalletConnect/ethers v5 tree. PAXI’s primary vault cryptography is not implemented with this package. | **ACCEPTED/REVIEWED.** The existing override prevents drift but is not a resolution; migrate the WalletConnect tree and remove the vulnerable legacy path. Advisory: [GHSA-848j-6mx2-7j84][3]. |
| `jayson` | Moderate | Transitive | 4.3.0; affected `>=2.0.6` | npm proposes `@solana/web3.js@0.0.3`, semver-major metadata | Nested under Solana web3.js for JSON-RPC client behavior. It can be reached when Solana RPC calls execute. | **ACCEPTED/REVIEWED.** RPC endpoints, timeouts, response validation, and confirmation checks are enforced; upgrade Solana web3.js as a compatible tree. |
| `uuid` | Moderate | Transitive | 8.3.2 under `jayson`; affected `<11.1.1` | npm proposes `@solana/web3.js@0.0.3`, semver-major metadata | The vulnerable advisory concerns v3/v5/v6 calls with a caller-provided buffer. The PAXI source review found no direct use of those UUID APIs; the package remains reachable through the Solana/Jayson dependency tree. Advisory: [GHSA-w5hq-g745-h8pq][2]. | **ACCEPTED/REVIEWED.** No direct application-controlled UUID buffer path was found; remove through the planned Solana tree migration and re-audit. |

### B.3 Dependency decision

No non-breaking remediation was verified for the active direct trees. `npm audit fix --force` was **not** run. No production dependency was downgraded merely to improve the audit result. The controlled plan is to create a separate upgrade branch, move Solana packages together with their supported transitive graph, move WalletConnect packages together, run compatibility tests for wallet creation/recovery/signing, Solana transfers, pairing, session approval, and security checks, canary the result, and re-run `npm audit --omit=dev` before changing this acceptance.

## C. Environment audit

A repository-wide audit of `process.env.*`, bracket-style environment access, the environment loader, provider integrations, payout/reward code, auth/storage/metrics, WalletConnect, LI.FI, EVM, Solana, Bitcoin, market providers, Moralis, and Birdeye found **58 discovered environment names**. `.env.example` contains **58 corresponding placeholders**; the missing and extra sets are empty.

The twelve variables found missing during the initial pass were added as blank placeholders. A subsequent client review found that swap fee construction had a separate hardcoded destination; `VITE_PAXI_TREASURY_ADDRESS` was added as a public placeholder and the client path now validates it before building a fee-bearing swap. No private key, seed phrase, password, PIN, JWT secret, API key, or signing material was added to the template.

The environment loader now keeps `PAXI_TREASURY_ADDRESS`, reward-vault aliases, and payout signer configuration explicit. When the treasury destination is unset, it remains empty rather than silently selecting an embedded address. The public client fee destination also fails closed when missing or malformed. See [`server/_core/env.ts`](server/_core/env.ts), [`.env.example`](.env.example), and [`client/src/lib/wallet/swap.ts`](client/src/lib/wallet/swap.ts).

## D. Treasury and real-money safety audit

### D.1 Findings and controls

| Area | Final finding | Evidence and status |
|---|---|---|
| Treasury destination | The old embedded server fallback was removed. | `PAXI_TREASURY_ADDRESS` is configuration-only; unset values remain empty. **RESOLVED.** |
| Client swap fee destination | The separate client literal was replaced with `VITE_PAXI_TREASURY_ADDRESS`; invalid or missing configuration produces no fee destination and blocks fee-bearing swap construction. | `normalizeWalletFeeAddress()` is unit-tested. **RESOLVED.** |
| Payout signer | The payout private key is server-only. The derived signer must match the configured distributor address. | [`rewardEscrow.ts`](server/campaigns/rewardEscrow.ts). **MITIGATED.** |
| Reward vault/distributor | Direct-transfer mode requires the configured reward vault and distributor to be the same address unless a separately authorized vault contract is integrated. | `assertRewardVaultPayoutCompatibility()`. **MITIGATED.** |
| Destination and amount validation | Token and recipient addresses are validated; decimal strings and raw units are bounded and converted with explicit token decimals. | Reward escrow and Gift Code funding code. **MITIGATED.** |
| Payout recovery | A broadcast transaction hash is inspected before any replacement. Pending, RPC-unavailable, invalid, and successful-but-non-exact states retain the reservation; only an explicit reverted receipt permits replacement. | [`rewardEscrow.ts`](server/campaigns/rewardEscrow.ts). **RESOLVED for the reviewed recovery boundary.** |
| Idempotency/concurrency | `campaignPayouts` has unique entry, idempotency-key, transaction-hash, and nonce-key indexes. Broadcast leases and durable transaction hashes prevent a crash after broadcast from creating a second payout. | [`drizzle/schema.ts`](drizzle/schema.ts) lines 255–287 and campaign router. **MITIGATED.** |
| Gift Code funding | Reward wallet balance, token contract, token decimals, and fulfillment configuration are checked before activation. Insufficient funds are rejected with `Insufficient reward balance`. | Gift Code funding and hardening tests. **RESOLVED.** |
| Gift Code redemption | Duplicate, expired, disabled, wrong-wallet, failed-transfer, recovery, and BSC token scenarios are covered; server-side signer and recipient binding are retained. | Focused money-moving suite passed. **MITIGATED.** |
| Audit logging | Gift Code create/disable/redeem and reward transfer success/failure events are recorded by the existing admin audit path. | Existing Gift Code audit implementation. **MITIGATED.** |

Payout nonce selection uses the pending transaction count and passes a reserved nonce into the broadcast call; the database lease and unique nonce key are the concurrency anchors. A horizontally scaled deployment should still monitor nonce contention and should add a dedicated distributed nonce allocator if payout volume grows materially. The current implementation does not release a reward reservation merely because confirmation timed out.

No live money-moving transaction was broadcast during this audit. Verification was performed with source review and deterministic tests.

## E. Test results

### E.1 Required commands

| Command | Actual result |
|---|---|
| `npm install --ignore-scripts --no-audit` | **PASS**, exit 0; dependencies up to date. |
| `npm run check` | **PASS**, exit 0; TypeScript `--noEmit`. |
| `npm test -- --run` | **PASS**, exit 0; **42 test files, 144 tests**. |
| `npm run build` | **PASS**, exit 0; Vite client build and esbuild server bundle completed. |
| `npm run lint` | **PASS**, exit 0; scoped Prettier check now includes the final hardening files. |
| `npm audit --omit=dev` | **NOT PASS**, exit 1; 21 findings: 7 low, 11 moderate, 3 high, 0 critical. This is reported honestly and is the reason for the security acceptance. |

The baseline was 40 files and 140 tests. The count increased to 42 files and 144 tests because this pass added two focused regression files with four tests: server treasury configuration and client swap fee-destination normalization.

### E.2 Focused verification

The market/provider/security/approval suite passed **6 files and 27 tests**. The money-moving suite passed **5 files and 26 tests**. The new treasury/swap configuration suite passed **2 files and 4 tests**. The read-only live provider smoke test completed successfully for a BSC token: Dexpaprika, GeckoTerminal, and CoinGecko returned usable observations; GeckoTerminal and CoinGecko returned five OHLCV points; the aggregate returned `medium` confidence from Dexpaprika and CoinGecko. DexScreener, Birdeye, and the optional DexScanner adapter returned no rows but did not fail.

Coverage percentage was **not claimed**. `npx vitest run --coverage` could not run because `@vitest/coverage-v8` is not installed; the optional install was declined so the release gate would not introduce an unreviewed dependency.

### E.3 Build warnings

| Warning | Assessment |
|---|---|
| Native `bigint` binding fallback during Gift Code tests (`bigint: Failed to load bindings, pure JS will be used`) | **Harmless beta concern.** The tested pure-JavaScript fallback passed; it is a performance/native-optional issue, not a cryptographic failure. |
| Node `punycode` deprecation warning during tests | **Post-beta maintenance item.** It is emitted by a dependency and did not affect test correctness. |
| Wallet bundle around 1,979 kB minified / 611 kB gzip and the >600 kB chunk warning | **Production performance concern, not a correctness blocker.** No breaking code-splitting rewrite was introduced. |
| Dynamic import warning for `client/src/lib/wallet/bitcoin.ts` because it is also statically imported by other wallet/Thorchain screens | **Harmless for correctness; performance optimization opportunity.** Rollup correctly warns that the module cannot be moved into a separate chunk under the current import graph. |
| BigInt syntax/build compatibility | **No build failure.** BigInt code compiled successfully with the current target; the runtime fallback warning above is separate from source compatibility. |

## F. Provider status

The existing provider architecture was retained. No OKX, Bybit, KuCoin, or other unnecessary provider was added. The aggregator continues to reduce each provider to one best observation before applying liquidity/freshness scoring, outlier rejection, consensus, confidence, and cache/fallback behavior.

| Provider | Status | Verification |
|---|---|---|
| DexScreener | **Available, no observation in live smoke** | Adapter executed without failure; aggregator failure/empty-data tests pass. |
| GeckoTerminal | **Available and live verified** | 20 market rows and 5 OHLCV points returned in the read-only BSC smoke test. |
| DexPaprika | **Available and live verified** | One market row returned; it supplied the aggregate primary source. |
| CoinGecko | **Available and live verified** | One market row and 5 OHLCV points returned; participated in aggregate consensus. |
| Birdeye | **Optional/configured adapter** | Adapter is present; it returns empty when no API key or no matching data is available and did not break aggregation in smoke testing. |
| Binance | **Active native-asset/chart fallback** | Used by the existing native asset price/chart paths, not as a token-pool adapter in `marketProviders`. No architecture change was made. |
| Moralis | **Security intelligence adapter, optional** | Used for address history and approval intelligence when `MORALIS_API_KEY` exists; unavailable configuration maps conservatively to no evidence/UNKNOWN. |
| GoPlus | **Security contract adapter** | Public token-security endpoint with an 8-second timeout; unsupported, missing, or failed data maps to UNKNOWN rather than SAFE. |
| DexScanner | **Disabled unless explicitly configured** | Requires documented endpoint/key configuration; live smoke returned no rows and no failure. |

The provider tests cover one observation per provider, multi-provider consensus, extreme outlier rejection, stale-data confidence reduction, unavailable data, and one-provider failure isolation. The live smoke test confirms the canonical `wallet/priceEngine → aggregator → cache/UI-facing result` path can return a usable aggregate without requiring every adapter to be available.

## G. Security status

### G.1 PAXI Shield flow

The reviewed path is:

> **PAXI Shield UI → `security.scan` tRPC endpoint → unified Security Engine → GoPlus contract checks + Moralis address/approval intelligence + conservative rules → risk/confidence/indicators/warnings UI**

The Shield UI uses the unified endpoint and preserves the intended icon semantics. The router applies strict schema validation for network, address, optional intended amount, and optional token address. The security engine uses the defined `LOW`, `MEDIUM`, `HIGH`, and `UNKNOWN` outcomes and does not convert missing evidence or provider failure into `SAFE`.

| Security capability | Status | Assessment |
|---|---|---|
| Token/contract | **Implemented with conservative UNKNOWN** | GoPlus flags are translated through documented heuristics; unsupported/no-data/error states remain UNKNOWN. |
| Address | **Implemented where Moralis is configured** | Wallet history and risk indicators are consumed when available; missing provider data is not treated as clean. |
| Approval | **Implemented and tested** | Intended amount, token address, unlimited/oversized amount, spender identity, and unavailable-provider cases are validated. Large approval is not automatically labeled malicious without evidence. |
| Transaction | **UNKNOWN where no validated implementation exists** | The system does not fabricate transaction-security results. |
| dApp | **UNKNOWN where no validated implementation exists** | The system does not fabricate dApp-security results. |

Focused approval/security tests cover normal approval, large approval, unlimited approval, missing intended amount, unknown spender, provider unavailable behavior, and strict token-address filtering.

## H. Remaining production gaps

### H.1 Beta blockers and accepted risks

| Item | Classification | Required action |
|---|---|---|
| 21 production dependency vulnerabilities, including 3 high Solana findings | **Known security acceptance** | Track the controlled Solana and WalletConnect upgrades. Do not change the acceptance to resolved until a new audit and compatibility run prove it. |
| No installed coverage provider | **Post-beta tooling gap** | Add and review `@vitest/coverage-v8` in a separate dependency change, then publish coverage thresholds based on measured results. |
| Large wallet bundle and dynamic import warning | **Post-beta performance gap** | Profile first; split only where it does not alter wallet initialization or signing behavior. |
| Scoped rather than repository-wide lint | **Known tooling limitation** | `npm run lint` is meaningful and now covers all final hardening files, but it is not a full-repository formatting check. A full check currently reports many pre-existing formatting warnings and a pre-existing SQL-template parsing issue in `scripts/applyListingCampaignSchema.ts`; no broad rewrite was performed. |

### H.2 Post-beta improvements

The first maintenance priority is a controlled major upgrade of the Solana and WalletConnect trees. The second is a measured coverage setup. The third is operational profiling of the wallet bundle and a review of the default public payout RPC; production deployments should set `PAXI_PAYOUT_RPC_URL` to an operationally controlled endpoint even though the explicit payout signer and destination checks remain the primary money-safety controls.

At higher payout volume, add a dedicated distributed nonce allocator or a formally tested nonce service. The current database unique indexes, broadcast lease, durable transaction hash, and recovery state are appropriate guards for the reviewed beta flow, but nonce contention should be load-tested before materially increasing concurrent payout throughput.

### H.3 Future security features

Transaction and dApp security remain explicitly UNKNOWN where there is no validated implementation. Future work may add independently verifiable transaction simulation, spender reputation, dApp origin attestation, broader chain-specific contract checks, and formal dependency SBOM/provenance monitoring. These should not be represented as existing capabilities until implemented and tested.

## Changed files and release scope

The final hardening changes are limited to the current architecture:

| File | Change |
|---|---|
| [`server/_core/env.ts`](server/_core/env.ts) | Removed the hardcoded treasury fallback; retained explicit server-only payout configuration. |
| [`server/_core/env.test.ts`](server/_core/env.test.ts) | Added two tests for empty-unset and explicit treasury/reward-vault configuration. |
| [`client/src/lib/wallet/swap.ts`](client/src/lib/wallet/swap.ts) | Replaced the hardcoded client fee destination with validated `VITE_PAXI_TREASURY_ADDRESS` configuration and fail-closed behavior. |
| [`client/src/lib/wallet/swap.test.ts`](client/src/lib/wallet/swap.test.ts) | Added two tests for malformed/missing and valid public fee destinations. |
| [`.env.example`](.env.example) | Added all discovered placeholders, including the public client treasury placeholder; no real secrets. |
| [`package.json`](package.json) | Extended the existing scoped `npm run lint` command to cover the final hardening files. |
| [`reports/dependency-audit.json`](reports/dependency-audit.json) | Generated dependency-audit evidence from the actual npm audit run. |

## References

[1]: https://github.com/advisories/GHSA-3gc7-fjrx-p6mg "bigint-buffer buffer overflow advisory"
[2]: https://github.com/advisories/GHSA-w5hq-g745-h8pq "uuid buffer bounds advisory"
[3]: https://github.com/advisories/GHSA-848j-6mx2-7j84 "elliptic cryptographic primitive advisory"
[4]: https://github.com/advisories/GHSA-x3ff-w252-2g7j "StableLib Ed25519 signature malleability advisory"
[5]: https://docs.npmjs.com/cli/v11/commands/npm-audit "npm audit documentation"

Repository source references are linked inline to the audited files. The local machine’s final audit JSON and command logs were retained during the release review; no secrets are included in the report or template.
