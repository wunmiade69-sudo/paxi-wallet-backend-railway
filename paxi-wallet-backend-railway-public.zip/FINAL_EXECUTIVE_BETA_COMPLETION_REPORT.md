# PAXI Wallet — Final Executive Beta Completion Report

**Audit and implementation date:** 18 August 2026  
**Scope:** Existing PAXI Wallet repository; controlled-beta completion pass without architectural rebuild or visual-identity redesign  
**Author:** Manus AI  
**Final status:** **BETA READY WITH KNOWN SECURITY ACCEPTANCE**

## A. Executive release decision

> **BETA READY WITH KNOWN SECURITY ACCEPTANCE**

The current candidate is suitable for a **controlled beta** after the implementation and verification work described in this report. The application’s principal wallet, market-data, security, payout, reward, Gift Code, referral, swap, bridge, and history paths remain on the existing architecture. The pass corrected concrete user-facing and safety defects rather than masking them with copy or unsupported claims.

The qualification is required because the production dependency audit still reports **21 findings: 7 low, 11 moderate, 3 high, and 0 critical**. The findings are concentrated in actively used Solana and WalletConnect trees. The available npm remediation requires compatibility-sensitive major tree changes; `npm audit fix --force` was not run, no production dependency was downgraded, and no untested override was used to make the report appear clean. Each finding was reviewed in the prior dependency report for package, severity, direct/transitive status, affected version, reachability, exploitability, compensating controls, and upgrade path. The owner must record this acceptance before controlled-beta promotion.

If the organization’s release policy requires zero high-severity production advisories, the correct status changes to **BETA NOT READY** until the Solana and WalletConnect trees are upgraded and compatibility-tested. Under the stated controlled-beta policy, the explicit acceptance is proportionate because the application continues to fail closed around signing, transaction validation, treasury destinations, unsupported routes, and unknown security results.

## B. Files changed and implementation scope

The implementation spans the existing client, server, configuration, and test boundaries. No new provider family, exchange, chain abstraction, or replacement wallet architecture was introduced.

| Area | Main files changed or added | Result |
|---|---|---|
| Fiat preference and valuation | `client/src/lib/wallet/fiat.ts`, `fiat.test.ts`, `client/src/pages/Dashboard.tsx`, `client/src/pages/SettingsScreen.tsx`, `client/src/components/TransactionList.tsx` | Supported EUR, GBP, JPY, and INR now convert displayed USD-denominated values using verified CoinGecko rates; missing or incomplete rates render as unavailable rather than silently displaying USD. |
| Public links and referrals | `client/src/lib/appInfo.ts`, `appInfo.test.ts`, `client/src/lib/wallet/referral.ts`, `client/src/pages/AboutUsScreen.tsx`, `client/src/pages/InviteFriendsScreen.tsx`, `.env.example` | Example domains and fake destinations were removed. About and referral actions fail closed until `VITE_PAXI_PUBLIC_URL` is configured. |
| Swap and bridge safety | `client/src/lib/wallet/slippage.ts`, `slippage.test.ts`, `client/src/pages/SwapPanel.tsx`, `client/src/pages/BridgePanel.tsx`, `client/src/lib/wallet/bridge.ts`, `bridge.test.ts` | Slippage is user-configurable within conservative 10–500 bps bounds. Bridge routes are limited to verified Ethereum, BSC, and Solana beta routes; asset/network mismatches and invalid tolerances are rejected before quoting. |
| THORChain BTC swap safety | `client/src/lib/wallet/thorchain.ts`, `thorchain.test.ts`, `client/src/pages/ThorchainSwapPanel.tsx` | Destination validation is strict and completed, refunded, failed, observed, pending, and unavailable statuses are distinct. Terminal failure/refund cannot appear as generic success or pending. |
| Honest product communication | `client/src/pages/ExperienceScreen.tsx`, `TransactionHistoryScreen.tsx`, `WalletGuideScreen.tsx`, `SwapPanel.tsx` | Copy now describes provider-based quotes, partial BTC/SOL support, browser-only dApp discovery, and the Solana fee-collection limitation accurately. |
| Treasury and prior release hardening | `server/_core/env.ts`, `env.test.ts`, payout/reward/security files from the preceding gate | Embedded server treasury fallback was removed; explicit configuration, payout recovery, Gift Code funding, security scanning, provider aggregation, approval validation, and audit logging remain enforced. |
| Release gate | `package.json` | The scoped Prettier lint gate now includes every file changed during the hardening passes. |

The complete candidate archive excludes `node_modules`, build output, VCS metadata, logs, and real environment files. `.env.example` is included with placeholders only.

## C. Features completed and bugs fixed

### C.1 Dashboard, settings, and history

The settings currency selector now broadcasts a same-session change event. Dashboard portfolio totals and individual asset values use the selected currency, and transaction-history values use the same denomination. USD remains exact. Non-USD values require a complete positive CoinGecko rate set; an unavailable rate is shown as **rate unavailable** or **unavailable**, not as an unverified USD value. Loading, empty, refresh, and missing-price states remain distinct.

The history and wallet-guide copy was corrected to describe indexed history and partial network support. The dashboard retains balance snapshots and stale-while-revalidate history behavior rather than introducing a new cache architecture.

### C.2 Referrals, About, and documentation

The former example referral destination was removed. Referral links are generated only from a normalized HTTP(S) `VITE_PAXI_PUBLIC_URL`; no configured public origin means no referral URL is rendered or shared. About website actions use the same configured origin and visibly communicate that the link is unavailable when the beta deployment has not supplied one. Dead hash links and fake production destinations are not used in these paths.

Campaign detail continues to use server-backed eligibility and payout state. Gift Code creation and redemption remain protected by the previously implemented TON gating, reward-balance preflight, token/decimal checks, duplicate-redemption protection, transaction recovery, and audit logging.

### C.3 Swap, bridge, and BTC swap

Swap slippage now uses bounded presets and a visible risk warning. The selected tolerance is passed into quote and execution paths. Invalid, too-low, or too-high values cannot reach a quote or signing request through the shared policy.

Bridge slippage uses the same bounded policy and refreshes quotes when the selected tolerance changes. The bridge picker now exposes only the controlled-beta route set: **Ethereum, BNB Smart Chain, and Solana**. Polygon, Arbitrum, Bitcoin, and custom networks remain available for other wallet functions where configured but are not advertised as verified bridge routes. The bridge layer rejects mismatched asset/network parameters before contacting LI.FI.

The UI does not claim that a bridge is completed while it is pending. THORChain destination addresses are validated before quote/signing, and refunded or failed actions are terminal non-success outcomes. The existing on-chain transaction state and recovery architecture was preserved.

Solana swap fee collection remains intentionally disabled because no public fee destination is configured for that route. The swap confirmation now says so explicitly instead of implying that the standard wallet fee applies to every chain.

### C.4 dApp discovery

Discover and Web3 Browser remain **external-browser discovery** surfaces. They do not expose a fake in-app connect flow. WalletConnect code remains configuration-gated and is not presented as a fully available beta user journey. Full pairing, transaction simulation, dApp security, and phishing protection remain post-beta capabilities unless separately enabled and verified.

## D. Security issues resolved, mitigated, and accepted

### D.1 Resolved in application code

The following application-level issues were resolved during the cumulative release hardening passes:

| Issue | Resolution |
|---|---|
| Embedded server treasury fallback | Removed. Payout, fee verification, and reward destinations require explicit configuration. |
| Client swap fee destination fallback | Replaced with validated `VITE_PAXI_TREASURY_ADDRESS`; fee-bearing swap construction fails closed when absent or invalid. |
| Missing public-domain guard | Added normalized `VITE_PAXI_PUBLIC_URL`; About and referral links do not render fake or malformed destinations. |
| Fixed or unsafe slippage exposure | Added bounded 10–500 bps policy for swap and bridge controls. |
| Broad unverified bridge picker | Limited beta bridge routes to Ethereum, BSC, and Solana and added asset/network consistency checks. |
| THORChain terminal status ambiguity | Added explicit completed/refunded/failed/observed/pending/unavailable semantics and tests. |
| Unknown security presented as safe | PAXI Shield uses conservative UNKNOWN semantics and correct icon/status meaning. |
| Unverified approval/security inputs | Security scan and approval paths retain strict validation for token, spender, amount, chain, and intended transaction context. |
| Payout and Gift Code recovery risks | Prior pass retained transaction-hash recovery, duplicate/concurrent request protection, exact payout verification, reservation safety, funding checks, and audit events. |
| Environment-template incompleteness | Repository-wide audit now has 58 discovered environment names and 58 matching placeholders. |

Private keys, mnemonics, PINs, and signing material remain in the existing local/server boundaries. The client sends public addresses and approved transaction requests to external services, not wallet secrets.

### D.2 Dependency findings accepted or mitigated

The production audit result is **not clean** and is not represented as resolved. The exact per-advisory table from the preceding gate is retained in `FINAL_BETA_GATE_REPORT.md` and `reports/dependency-audit.json`. The current disposition is:

| Vulnerability family | Count / severity | Reachability | Status |
|---|---:|---|---|
| Solana tree: `@solana/spl-token`, `@solana/web3.js`, `@solana/buffer-layout-utils`, `bigint-buffer`, `jayson`, `uuid`, token extension packages | 3 high, 5 moderate, 1 low | Active Solana balance, token, RPC, and transaction paths; some extension modules are only conditionally loaded | **ACCEPTED/REVIEWED; unresolved upstream**. Strict address/token/amount validation, bounded RPC calls, confirmation checks, and fail-closed fulfillment are compensating controls. Upgrade the Solana tree as a unit in a canary branch. |
| WalletConnect tree: `@walletconnect/web3wallet`, `core`, `utils`, `sign-client`, `relay-auth`, `auth-client`, legacy `@ethersproject/*`, `@stablelib/ed25519`, `elliptic` | Remaining findings in this family are moderate and low; the aggregate audit remains 11 moderate and 7 low across all trees | Pairing, relay, session, and approved-request code exists and is configuration-gated; the main beta UI exposes browser-only discovery rather than a full pairing journey | **ACCEPTED/REVIEWED; unresolved upstream**. User approval, EVM chain allowlisting, bounded WalletConnect URI validation, and no secret transfer are compensating controls. Upgrade the complete WalletConnect family together. |

The aggregate command result is authoritative: `npm audit --omit=dev` exited **1** with **21 vulnerabilities: 7 low, 11 moderate, 3 high, 0 critical**. Available npm fixes were compatibility-sensitive or marked as major-tree changes. No forced fix was applied.

## E. Multi-chain, provider, and operations status

| Capability | EVM | Bitcoin | Solana | PAXI network |
|---|---|---|---|---|
| Address derivation | Implemented for supported EVM networks through the existing engine | Implemented through the existing Bitcoin derivation path | Implemented through the existing Solana derivation path | Not advertised as an enabled chain; no incorrect hardcoded Cosmos/EVM identity is presented |
| Balance / receive | Implemented for configured networks | Implemented with explicit unavailable/error states where indexer/RPC data is absent | Implemented with explicit unavailable/error states | Not enabled |
| Send / signing | Implemented with local signing and validation | Implemented for supported wallet path | Implemented for supported wallet path; dependency acceptance remains | Not enabled |
| History | Indexed/local history supported according to provider availability | Partial/indexer-dependent | Partial/indexer-dependent | Not enabled |
| Swap | EVM provider route supported | THORChain BTC swap is a separate controlled path | Jupiter path supported; fee collection limitation is disclosed | Not enabled |
| Bridge | Controlled beta routes are Ethereum and BSC | Not supported by LI.FI bridge path | EVM-to/from-Solana supported only through the verified beta set | Not supported |

Provider aggregation, health records, rate-limit tracking, circuit breakers, Redis-safe cache fallback, database pool initialization, and transaction recovery remain in the existing production design. Redis failures degrade cache operations to misses rather than turning them into silent successful writes. Provider failures record state, latency, rate limits, and last-error information. Database initialization is lazy and local tooling can run without a configured database; production deployment must still provide a healthy database because money-moving and server-authoritative features require it.

The final Vite build succeeds but reports two known optimization diagnostics: a wallet chunk larger than 600 kB after minification (approximately **1,984.90 kB**, gzip approximately **612.79 kB**) and dynamic-import notices because Bitcoin/Solana modules are also statically imported by other runtime paths. No separate BigInt build failure was observed. These are performance follow-ups, not correctness blockers for the controlled beta.

## F. Exact testing and validation results

The final validation was run with npm after the latest bridge, fiat, link, slippage, THORChain, copy, and fee-semantics changes.

| Command | Result |
|---|---|
| `npm run check` | **PASS, exit 0** (`tsc --noEmit`) |
| `npm test -- --run` | **PASS, exit 0; 45 test files, 156 tests passed** |
| `npm run build` | **PASS, exit 0**; Vite client and esbuild server bundle completed with the warnings documented in Section E |
| `npm run lint` | **PASS, exit 0**; scoped Prettier gate covers the files changed in the release passes |
| `npm audit --omit=dev` | **EXPECTED NON-ZERO, exit 1**; 21 production findings: 7 low, 11 moderate, 3 high, 0 critical |
| Focused current-pass tests | **PASS; 6 files, 21 tests**, including bridge route gating, fiat conversion, slippage, THORChain, app links, and swap configuration |

New regression coverage was added for fiat conversion fail-closed behavior, public-domain normalization, bounded slippage, bridge route gating, and THORChain terminal statuses. Existing tests for wallet crypto, send/swap state, PAXI Shield, security scanning, approval intelligence, payouts, Gift Codes, provider aggregation, and recovery remain in the suite. No test was deleted or weakened.

The repository does not have an installed Vitest coverage provider, so no coverage percentage is claimed. Test counts are reported directly from Vitest output.

## G. Deployment requirements and controlled-beta boundaries

A production deployment must provide a real `DATABASE_URL`, a healthy MySQL/TiDB-compatible database, and explicit treasury/reward/payout configuration. The operator must configure `PAXI_TREASURY_ADDRESS`, reward-vault/escrow destinations, payout RPC URLs, and server-only payout signer keys through the deployment secret manager. Signer material must never be copied to the frontend or committed to the repository.

The deployment must configure `VITE_PAXI_PUBLIC_URL` to the actual HTTPS origin before enabling referral sharing or the About website action. If public swap-fee routing is enabled, `VITE_PAXI_TREASURY_ADDRESS` must be a valid public address synchronized with the server policy; otherwise the client fails closed for the fee-bearing path. `VITE_WC_PROJECT_ID` is optional and does not, by itself, make the browser discovery surface a fully supported WalletConnect product.

Production should set `NODE_ENV=production`, configure provider credentials and RPC endpoints deliberately, use TLS where required, and set `REDIS_REQUIRED=true` where distributed cache locks and provider cooldown coordination are operational requirements. LI.FI bridge fee destinations must be configured in the existing partner configuration for the relevant chain families before relying on bridge fee accounting. The operator must monitor provider health, RPC failures, Redis availability, database health, payout transaction states, and security events.

Post-beta work remains explicitly outside this release candidate: full Bitcoin transaction/history coverage, complete Solana feature parity, exposing WalletConnect pairing and signing UI, transaction simulation, dApp security, advanced phishing protection, deeper historical DEX charts, full dependency modernization, independent security audit, and large-scale load testing.

## H. Final acceptance and recommendation

The application now presents one coherent controlled-beta product. Important actions show the intended effect, cost or fee state, signing risk, and pending/failure semantics. Unsupported or incomplete routes are disabled or clearly labeled rather than presented as fully available. The remaining high-severity dependency acceptance is explicit, bounded by the existing security and transaction controls, and paired with a controlled upgrade plan.

**Recommendation:** approve a controlled beta only with the recorded dependency security acceptance, explicit production environment configuration, monitoring of payout/provider/Redis/database health, and a rollback plan. Do not describe the product as fully multi-chain, fully WalletConnect-enabled, or fully Bitcoin/Solana-complete until the post-beta capabilities in Section G are independently delivered and tested.

### References

[1]: ./FINAL_BETA_GATE_REPORT.md "PAXI Wallet preceding final beta gate report and per-advisory dependency dispositions"  
[2]: ./reports/dependency-audit.json "PAXI Wallet production dependency audit evidence"  
[3]: ./package.json "PAXI Wallet scripts, dependencies, and scoped lint gate"  
[4]: ./server/_core/env.ts "PAXI Wallet server environment and explicit treasury configuration"  
[5]: ./client/src/lib/wallet/fiat.ts "PAXI Wallet shared fiat conversion and fail-closed rate utility"  
[6]: ./client/src/lib/wallet/bridge.ts "PAXI Wallet controlled-beta bridge support and validation"  
[7]: ./client/src/lib/wallet/thorchain.ts "PAXI Wallet THORChain status normalization"  
[8]: https://github.com/advisories/GHSA-3gc7-fjrx-p6mg "bigint-buffer security advisory"  
[9]: https://github.com/advisories/GHSA-w5hq-g745-h8pq "uuid security advisory"  
[10]: https://github.com/advisories/GHSA-848j-6mx2-7j84 "elliptic security advisory"
