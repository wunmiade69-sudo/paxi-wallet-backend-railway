# Paxi Wallet Railway MySQL Audit

**Audit scope:** Read-only inspection of the uploaded backend archive and the supplied Railway MySQL database. No rows or schema objects were modified.

## Executive finding

The database is reachable and healthy at the connection level, but it is **behind the uploaded application code**. If this is the database used by the deployed Paxi Wallet service, the current SEND and wallet-ownership flows cannot operate reliably because required tables and columns are missing. The strongest evidence is that the live database has no `walletLinks`, `walletLinkChallenges`, `sendFeeQuotes`, `sendOperations`, or `feePaymentLedger` tables, while the uploaded server code imports and queries those models.

The live database also contains **zero users, zero activity events, and zero fee records**. This may mean the database is newly provisioned or that the deployed application is connected to a different database. That identity check should happen before any migration is applied.

## Findings

| Priority | Finding | Evidence | Impact |
|---|---|---|---|
| Critical | Required SEND and wallet-link tables are absent | `walletLinks`, `walletLinkChallenges`, `sendFeeQuotes`, `sendOperations`, and `feePaymentLedger` are missing from `SHOW TABLES` | Wallet ownership, server-issued SEND quotes, durable SEND lifecycle, and global fee idempotency can fail at runtime |
| Critical | `feeRecords` is the old schema | It lacks `operationId`, `walletAddress`, `asset`, `feeCurrency`, `feeAmount`, `assetDecimals`, `treasury`, `feeTransactionHash`, and `failureReason`; its operation enum does not include `send` | The current `recordFee()`/SEND code can issue SQL errors or cannot persist the fields it requires |
| Critical | `feeConfig` lacks the `send` operation | The live enum is only `swap_evm`, `swap_btc`, `bridge`, `create_token`, and `listing`; there are zero SEND fee rows | Server-side SEND fee quoting has no database-owned SEND fee configuration |
| High | `sendFeeQuotes` has no migration in the archive | `drizzle/schema.ts` defines it and `sendOperations` references it, but no SQL migration creates it | Running only the supplied `sendOperations` migration would fail because its foreign key target does not exist |
| High | Deployment orchestration does not apply the new migrations | `package.json` `db:deploy` runs the older consolidated steps but does not run `db:send-operations`; the wallet-link and fee-ledger scripts are not included either | Redeployments can repeatedly leave production schema behind source code |
| High | Database has no application users or wallet activity | `users=0`, `activityEvents=0`, `feeRecords=0`; only one verified seed token listing exists | Could indicate wrong `DATABASE_URL`, a fresh database, or that production traffic is not reaching this database |
| Medium | The supplied database credential is exposed in chat | The connection URI included a plaintext password | Rotate the Railway password immediately after the audit |

## Why this explains the failed send review

The uploaded server code’s SEND path first checks a linked wallet, loads a durable `sendFeeQuotes` row, and creates or transitions a `sendOperations` row. The database has none of the tables needed for those operations. The same code also writes SEND-specific fields into `feeRecords`, but the live table does not contain those columns and rejects the `send` enum value. This is a direct, database-level explanation for a generic send failure if the deployed service uses this database.

The codebase’s own documentation already identifies the durable SEND migration as unapplied and labels the work “not safe for production.” The live database confirms that status rather than contradicting it.

## Proposed fix

### 1. Verify the database identity before changing anything

Confirm that the Railway service’s runtime `DATABASE_URL` resolves to the same host and database inspected here. Also check the deployed service health and application logs for SQL errors such as missing table, unknown column, or invalid enum value. Do not migrate this database until it is confirmed to be the active application database.

### 2. Rotate the exposed credential and take a backup

Rotate the Railway MySQL password because it was pasted into chat. Then create and verify a backup or snapshot. The audit was read-only, but the remediation below changes production schema and must be reversible.

### 3. Apply the schema in a controlled staging database first

The required order is:

1. Create `walletLinks` and `walletLinkChallenges` from `drizzle/phase5g-part1b-wallet-links.sql`.
2. Extend `feeConfig` and `feeRecords` using `drizzle/phase5g-part1-send-fees.sql`.
3. Create `feePaymentLedger` using `drizzle/phase5g-part1b-fee-ledger.sql`.
4. Add a new reviewed migration that creates `sendFeeQuotes` exactly as defined in `drizzle/schema.ts`.
5. Create `sendOperations` using `drizzle/phase5g-p2-5b-send-operations.sql`, after `sendFeeQuotes` exists.
6. Run the repository’s database regression suite and the focused SEND lifecycle tests against staging.

The existing `applySendOperationsSchema.ts` is not sufficient by itself because it assumes `sendFeeQuotes` already exists, but the archive contains no migration that creates that table.

### 4. Fix deployment automation

Update `db:deploy` so these migrations are applied through an idempotent, versioned migration runner, not through ad-hoc production commands. Record each successful migration in `paxiSchemaDeployments`. Add preflight checks that verify required prerequisite tables and columns before creating foreign keys. The deployment must fail closed if the schema version is incompatible with the server bundle.

### 5. Seed and verify SEND fee configuration

After the fee schema is extended, insert one approved server-owned SEND configuration for each supported network/chain policy, using the intended percentage and treasury settings. The uploaded code’s default policy shows `send` at **40 basis points** for EVM, but the exact production value should be confirmed by the product owner before insertion. Verify that the treasury address is present and that real fee settlement remains disabled until the full test matrix passes.

### 6. Retest the full path

Test wallet-link challenge and signature verification, quote issuance, quote expiry, fee broadcast, fee confirmation, SEND broadcast, confirmation, retry idempotency, database rollback, RPC failure, insufficient native gas, and client reload/reconciliation. The UI should show the actual failure category rather than “Something went wrong.”

## Important caution

Do **not** run `npm run db:send-operations` directly against production yet. It creates only `sendOperations`, requires `sendFeeQuotes`, and the repository documentation explicitly says the migration was not executed and is staging-only. First add and review the missing `sendFeeQuotes` migration, apply the complete ordered set in staging, and verify rollback.

## Audit artifacts

The raw read-only inventory is stored locally as `db-inventory.tsv`, and the executed audit output is `audit-results.tsv`. Neither file contains the database password.

## Conclusion

The primary defect is **schema drift between the running backend and the Railway database**, not a single bad transaction row. The safest fix is to verify the active database, rotate the exposed credential, back up the database, add the missing `sendFeeQuotes` migration, apply all wallet/SEND/fee migrations in staging, repair deployment automation, and only then migrate production after regression testing.

**Author:** Manus AI
