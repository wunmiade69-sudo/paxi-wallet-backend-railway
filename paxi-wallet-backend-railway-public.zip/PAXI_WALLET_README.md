# PAXI Wallet — Current Controlled-Beta README

**Status:** controlled beta release candidate. This document is authoritative for the current repository state; older review notes and historical beta reports are retained separately and are not current capability claims.

PAXI Wallet is a non-custodial React 19 and TypeScript wallet with an Express 5/tRPC backend, Drizzle ORM, MySQL/TiDB persistence, Redis-backed resilience, and chain-specific client signing. The application is designed so private wallet material is created, encrypted, unlocked, and used for signing in the client runtime. Server-side payout and reward signers are separate operational credentials and are never shipped to the browser.

## Architecture

The frontend is a Vite React application using route-level screens, shared wallet libraries, Radix primitives, Tailwind CSS, and local encrypted vault state. The server exposes tRPC routers and Express endpoints for database-backed features, provider proxies, market data, security intelligence, campaign and Gift Code operations, and production health boundaries.

The wallet engine derives the EVM account from a BIP-39 mnemonic and supports chain-specific Bitcoin and Solana derivation where the corresponding implementation is available. The vault uses authenticated encryption with a PBKDF2-derived key from the user PIN; the decrypted signing material exists only in memory while the wallet is unlocked. Local storage is used for encrypted vault records, preferences, transaction cache, and non-secret UI data, not as a plaintext mnemonic or private-key store.

## Current wallet capabilities

| Area          | Current behavior                                                                                                                                                                                         |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Create/import | Real BIP-39 wallet creation and checksum-validated recovery/import flows.                                                                                                                                |
| Lock/unlock   | PIN-protected encrypted vault with lock, recovery, and optional WebAuthn platform authentication.                                                                                                        |
| Backup/export | PIN-gated recovery-phrase reveal and encrypted keystore export. Any raw-key reveal is explicitly gated and must be treated as sensitive.                                                                 |
| Send/receive  | Real chain-specific validation, fee estimation where supported, signing, broadcast, QR generation, and address copy/share. Unsupported combinations fail closed.                                         |
| History       | Local records are merged with indexed/on-chain records where available. Statuses distinguish unknown, submitted, pending, confirmed/finalized, failed, replaced, dropped, reorged, and expired outcomes. |
| Security      | PAXI Shield calls the unified security engine, using GoPlus contract intelligence, Moralis address/approval intelligence, conservative UNKNOWN semantics, and strict request validation.                 |
| WalletConnect | Disabled by default and fail-closed for the controlled beta. The request validator remains available for a separately reviewed post-beta enablement; no dApp request is auto-signed.                     |

## Supported-chain and feature-parity matrix

The application deliberately distinguishes **configured**, **partially supported**, and **controlled-beta** features. A chain is not described as fully supported merely because an address format exists.

| Chain/network       | Address and balance                                         | Receive/send and signing                                                | History and fees                                                                   | Swap                                | Bridge                                                | Current limitation                                                                           |
| ------------------- | ----------------------------------------------------------- | ----------------------------------------------------------------------- | ---------------------------------------------------------------------------------- | ----------------------------------- | ----------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Ethereum            | EVM address, native and configured ERC-20 balances          | Supported for validated EVM assets                                      | RPC fees; indexed history for Ethereum                                             | Controlled-beta provider route      | Controlled-beta EVM route                             | Provider, RPC, and token availability can vary.                                              |
| BNB Smart Chain     | EVM address, native and configured BEP-20 balances          | Supported for validated EVM assets                                      | RPC fees; indexed history for BSC                                                  | Controlled-beta provider route      | Controlled-beta EVM route                             | Explicit treasury and provider configuration is required for production.                     |
| Polygon             | Shared EVM address and configured native/token operations   | Basic EVM send/receive/signing where the asset is configured            | RPC fee support; history coverage is more limited than Ethereum/BSC                | Not exposed as a general beta route | Not exposed in the controlled-beta bridge predicate   | Do not assume Ethereum/BSC provider or indexer parity.                                       |
| Arbitrum One        | Shared EVM address and configured native/token operations   | Basic EVM send/receive/signing where the asset is configured            | RPC fee support; history coverage is more limited than Ethereum/BSC                | Not exposed as a general beta route | Not exposed in the controlled-beta bridge predicate   | Route and indexer coverage remain intentionally narrower.                                    |
| Bitcoin             | Native SegWit derivation, balance, UTXO lookup              | Bitcoin send construction, local signing, and broadcast are implemented | Esplora fee/status support; full address history is not equivalent to EVM indexing | Not available in beta               | Not available in beta                                 | UTXO confirmation and broadcast recovery are chain-specific.                                 |
| Solana              | Solana keypair/address and configured native/SPL operations | Native/SPL send, local signing, and broadcast are implemented           | RPC fee/status support; full address history is limited                            | Jupiter controlled-beta route       | Only explicitly implemented bridge routes are exposed | Token-2022 risk classification uses the canonical SPL Token SDK identifier.                  |
| PAXI network        | Not configured as an active chain                           | Not available                                                           | Not available                                                                      | Not available                       | Not available                                         | The PAXI network endpoint and asset registry are not assumed. Do not use an EVM placeholder. |
| Custom EVM networks | User-configured address/RPC metadata                        | Basic operations may work after validation                              | No guaranteed indexed history                                                      | Not available                       | Not available                                         | Custom networks are not automatically production-supported.                                  |

## Market-data architecture

Prices flow through the server-side provider aggregation path rather than a single hardcoded exchange. The canonical price engine uses provider-level observations, freshness and liquidity scoring, outlier rejection, confidence calculation, Redis/MySQL caching, and conservative on-chain or fallback behavior. Birdeye is an optional configured adapter. DexScanner remains opt-in and must not be enabled without a documented compatible deployment. The client must show an unavailable or stale state when a verified rate cannot be obtained; it must not silently display USD under a different selected fiat currency.

## Security architecture

PAXI Shield uses one unified `security.scan` boundary. Contract checks, address intelligence, approval intelligence, amount/token context, provider failures, and unknown data are combined conservatively. An unavailable provider does not become a clean bill of health. Approval checks validate the token address, spender, chain, and intended amount before analysis.

Wallet cryptography is client-side. Mnemonics and private keys must never be sent to market-data providers, security providers, WalletConnect peers, analytics, logs, or the server API. Server-side payout and reward paths use explicit operational configuration, destination and chain validation, transaction recovery, audit logging, and idempotent state transitions. Missing treasury configuration fails closed; it does not fall back to an operational address.

## Swap, bridge, rewards, and referrals

Swap quotes are provider-based and use bounded, user-visible slippage controls. The confirmation surface communicates route, network, amount, fee, risk, and the fact that simulation is not fabricated where no safe simulation exists. Bridge routes are explicitly gated to supported beta combinations; unsupported Polygon, Arbitrum, Bitcoin, custom, or invalid combinations are not presented as executable routes.

Campaign rewards, Gift Codes, treasury payouts, and referral rewards are server-controlled economic operations. Gift Code fulfillment performs network, token, decimals, and reward-balance checks before activation. Redemption, payout, transfer success/failure, and administrative actions are audit logged. A broadcast transaction hash is retained and recovered before any retry or reservation release.

Referral links and About links require an explicit configured HTTPS public origin. If it is absent, the UI says the link is unavailable rather than generating an example domain. Referral counts and rewards that are not backed by a live ledger remain clearly marked as pending or unavailable.

## Current beta limitations

The following are intentional controlled-beta limitations, not hidden placeholders:

- WalletConnect signing is disabled by default and remains fail-closed until a separate security review approves the full confirmation and simulation boundary.
- Transaction simulation is not fabricated. Where safe simulation is unavailable, the security state is UNKNOWN/NOT SIMULATED and the confirmation shows the available recipient, token, amount, network, native value, gas, contract, function, spender, and warning context.
- Bitcoin and Solana history coverage is not equivalent to Ethereum/BSC indexed history. Pending and confirmation recovery use chain-specific providers.
- Bridge and swap route coverage is narrower than the complete network registry. A configured chain does not imply every feature is enabled.
- PAXI mainnet is not enabled without a verified network endpoint and asset configuration.
- Physical-device, offline, background/resume, and app-termination testing must be completed by the release owner; sandbox test results do not substitute for that QA.
- Production dependency audit findings remain in active Solana and WalletConnect trees and require an explicit upgrade plan; do not apply forced major upgrades without compatibility testing.

## Environment configuration

Copy `.env.example` to an environment-specific file and populate only the values required by the deployment. Never commit a real `.env` file, seed phrase, PIN, JWT secret, API key, private key, or operational wallet address. Server-only values include database, Redis, provider, treasury, reward, and payout signer settings. Public client values are limited to values intentionally safe to expose, such as the configured public origin and a public fee destination.

Important production requirements include:

- `DATABASE_URL` and, where used, `DATABASE_READ_URL` or `DATABASE_REPLICA_URL`.
- `REDIS_URL` when distributed locks, queues, or cache coordination are required.
- Explicit `PAXI_TREASURY_ADDRESS`, reward-vault/escrow addresses, and server-only payout signer configuration.
- RPC/provider configuration for every chain and provider the deployment actually enables.
- `VITE_PAXI_PUBLIC_URL` for valid HTTPS referral and About links.
- `VITE_WC_ENABLED=false` and an empty `VITE_WC_PROJECT_ID` for the controlled-beta default.
- TLS, reverse-proxy, secret rotation, database backup, restore, migration rollback, and deployment rollback procedures maintained outside the repository.

See `.env.example` for the complete placeholder inventory. Values in that file are intentionally blank unless a non-secret public default is required for local development.

## Development and testing

```bash
npm install
npm run dev

npm run check
npm test -- --run
npm run build
npm run lint
npm audit --omit=dev
```

`npm run lint` is an intentional scoped Prettier gate over release-pass files, not a claim of repository-wide formatting coverage. `npm run security:deps` produces the project’s dependency inventory. Database deployment and regression commands are available in `package.json` and must be run only against the intended environment with migrations reviewed.

## Railway staging and Android QA preparation

The repository is prepared for a controlled Railway staging deployment and Android physical-device QA, but neither infrastructure deployment nor real-device testing is claimed complete. The current backend is MySQL/TiDB-based; do not attach PostgreSQL without an explicitly approved database migration project. Use `RAILWAY_STAGING_ANDROID_QA_REPORT.md` for the exact service settings, migration safety sequence, environment-variable matrix, provider classification, Android staging API-origin procedure, and release blockers.

The active checkout currently lacks `capacitor.config.ts`, `android/`, and the native runtime bridge files. Therefore, Android synchronization, APK compilation, native API-origin validation, and device QA are blocked pending restoration of the separately prepared mobile source. Once restored, set `VITE_PAXI_API_ORIGIN` to the HTTPS Railway backend origin, run `npm run build`, synchronize Capacitor, and build the debug APK. The intended native runtime must fail closed when a native build lacks a valid API origin. The frozen RC renders receive QR codes but does not implement camera QR scanning; camera-based QA must not be claimed.

## Deployment requirements

Deploy the built server with `npm run start` under `NODE_ENV=production` behind HTTPS and a trusted reverse proxy. Configure explicit production secrets through the deployment secret manager, run reviewed database migrations, verify Redis and database connectivity, check provider/RPC health, and confirm that payout signer and treasury configuration is present before enabling money-moving operations.

A production runbook must define structured logging and redaction, security audit-log retention, provider/RPC incident handling, Redis and database degradation behavior, backups and restore verification, migration rollback, deployment rollback, signer/key rotation, and incident response. If any of those mechanisms are not configured for a target deployment, that deployment is not equivalent to the repository’s controlled-beta validation.

## Security caveats and dependency acceptance

The current production audit reports **21 findings** (**7 low, 11 moderate, 3 high, 0 critical**) in active Solana and WalletConnect dependency trees. Available npm remediation requires compatibility-sensitive major changes; no forced upgrade or untested downgrade is applied. These findings are explicitly reviewed in the release report and remain a known controlled-beta security acceptance with a planned upgrade track.

The repository’s cryptography was not weakened or replaced during the correction pass. A passing test suite does not by itself authorize unrestricted mainnet or production treasury use.

## Historical documents

`PAXI_WALLET_FEEDBACK.md`, `todo.md`, and earlier audit reports contain historical implementation notes. `TESTING_GUIDE.md` is the current controlled-beta verification guide. This README and the current release report are authoritative for the present candidate.

## License

MIT. See `LICENSE`.

## Post-beta directive additions

The current tree now includes a canonical token-discovery path at `market.discover`. It accepts supported-chain names, symbols, native asset aliases, EVM contract addresses, and Solana mint addresses; aggregates the already integrated market providers; normalizes results to a chain-plus-token-standard-plus-contract identity; and exposes source, freshness, liquidity, confidence, trust, and PAXI Shield metadata. Provider failures are isolated, and unavailable values remain `—` or `unknown` rather than being fabricated. A market listing or liquidity signal is not a legitimacy guarantee.

Token detail now supports canonical identities in the form `chainId:tokenStandard:contractAddress` as well as the legacy CoinGecko coin-id path. Detail pages show explorer links, copyable contract addresses, wallet-import eligibility only for supported chains, and an explicit warning that token names and symbols are not unique. Historical chart data is unavailable for newly discovered canonical identities until a chart provider mapping exists; the UI states this instead of implying that a missing chart is a successful fetch.

Help & Support is available from the **Me** screen. PAXI AI Support runs through the server-side LLM helper, uses documented PAXI capability boundaries, and receives only allowlisted public diagnostics such as chain, public address, transaction hash, status, error text, quote status, token pair, timestamp, and whether simulation is available. It cannot sign, approve, send funds, change wallet settings, or bypass WalletConnect approval. Recovery phrases, private keys, PINs, passwords, authentication codes, and other secret-looking inputs are rejected before persistence or model invocation. Human escalation creates an idempotent support ticket with user-owned ticket visibility; authorized administrators can list, inspect, reply to, assign, reprioritize, and update ticket status through the existing admin RBAC boundary.

The support migration is `drizzle/0011_support_tickets.sql`. Deploy it through the normal reviewed database migration process before enabling ticket persistence in an environment with a database. The feature remains safe by default when the database is unavailable: support mutations return a temporary-unavailable response rather than storing data in browser storage or emitting credentials to logs or third-party APIs.

## Production-excellence hardening addendum — August 18, 2026

The current candidate adds production swap-review safeguards without changing the existing flow: quote age and expiry are shown before signing, approval targets are surfaced and validated, gas and route context remain explicit, provider-backed simulation is attempted where supported, and unavailable simulation is never rendered as success. EVM receipt failures are represented as the terminal `reverted` state; the receipt explains that the transaction was mined but its effects were rolled back.

Solana wallet-fee collection is intentionally disabled until a real treasury address is configured through the public `VITE_PAXI_SOLANA_TREASURY_ADDRESS` deployment setting. Missing or malformed values fail closed to zero wallet fee and cannot redirect funds; the swap review explicitly displays **Configuration required**, while network and route fees still apply. No treasury address is fabricated in the web RC.

Market provider aggregation records per-provider latency, success, failure, rate-limit, and degraded/unavailable state in the existing health registry. The provider-health view is exposed only through the existing admin RBAC boundary. PAXI AI returns an escalation-safe unavailability response when the model provider fails; it does not perform wallet actions and receives no internal user identifier or wallet secret.

These changes improve application-level safety and observability but do not constitute hardware-wallet custody, physical-device QA, live-network staging, external security review, disaster-recovery execution, or production incident rehearsal. Those remain release-owner requirements in `PRODUCTION_OPERATIONS.md`.

## Production-excellence hardening status

The current candidate includes explicit swap review controls for quote age and expiry, route and approval-target disclosure, gas-estimate availability, simulation status, and irreversible-transaction warning. Failed pre-sign simulation blocks signing; unavailable simulation is shown as unavailable; and mined EVM failures are normalized as `reverted` and rendered as unsuccessful.

The existing provider aggregation path records per-provider latency, successes, failures, rate limits, and degraded/unavailable states in the provider-health registry. This operational view is available only through the existing admin RBAC boundary. PAXI AI returns a safe escalation response when its model provider is unavailable, and it does not perform wallet actions or receive internal user identifiers.

These controls do not claim hardware-wallet custody, physical-device testing, live-network staging, external security review, disaster-recovery execution, or incident-response rehearsal. Those remain deployment-owner requirements.

## Native Help & Support

The controlled-beta client includes a native **Help & Support** screen reachable from the Me area. It provides a PAXI AI landing state with quick prompts, retry and temporary-unavailable handling, explicit escalation to a human, and a ticket workflow with list, detail, and reply states. Support requests remain protected by authenticated tRPC procedures and ticket ownership checks.

Support diagnostics are read-only and deliberately bounded. Public transaction or token context may be attached only through the allowlisted diagnostic fields; the server rejects recovery phrases, private keys, PINs, passwords, authentication codes, API keys, and signer material before persistence or model invocation. PAXI AI cannot sign, approve, send, change settings, enable WalletConnect, or perform any wallet action. Users must never place secrets in support text, screenshots, or diagnostic context.

Transaction support entry points may provide public status context, but they do not imply that a transaction succeeded, was simulated, or can be recovered automatically. A reverted receipt is shown as **Reverted**, while unknown, pending, and unavailable states remain conservative. The UI continues to display explicit uncertainty for unavailable simulation and provider data.

The latest automated hardening validation recorded **53 passing test files and 202 passing tests**, with TypeScript, build, and lint passing. The production dependency audit remains non-zero with 21 documented controlled-beta findings. Physical-device and live operational exercises remain release-owner responsibilities as described in `TESTING_GUIDE.md` and `PRODUCTION_OPERATIONS.md`.

## Final pre-beta gate closure — 18 August 2026

The final pre-beta gate separates **verification trust** from **security assessment**. Only explicit verification metadata can produce a verified or unverified trust state; security labels and scores do not upgrade trust. Missing, malformed, or unsupported verification metadata remains `unknown`, and stale or malformed security reports remain unavailable rather than falling back to arbitrary historical data.

Token name and symbol discovery now uses provider-native search across the existing CoinGecko and DexScreener adapters. Results are canonicalized by **chain, token standard, and contract** (`chainId:tokenStandard:normalizedContract`), failure-isolated, deduplicated, provenance-aware, freshness-aware, and ranked deterministically. EVM chains distinguish ERC-20 and BEP-20 semantics, while Solana uses SPL Token and native assets use the native standard. Search must not invent a token when every supporting provider is unavailable.

The post-correction final validation completed at **2026-08-18T17:32:17Z**: typecheck, full tests, production build, and the expanded lint check passed; Vitest reported **53 test files and 202 tests passing**. The production dependency audit remains non-zero with **21 findings: 7 low, 11 moderate, and 3 high**, which are a documented controlled-beta dependency acceptance rather than a clean-audit claim. Physical-device, funded live-network, external security, backup/restore, rollback, secret-rotation, and incident-response testing remain deployment-owner requirements.

## Final LI.FI fee-hardening status — 18 August 2026

The controlled-beta bridge uses the existing restricted PAXI server proxy for LI.FI quote and status operations. The browser cannot select an arbitrary LI.FI path, inject an API key, replace the integrator, redirect the fee, or choose a different fee rate. The server validates supported chain IDs, token and wallet addresses, numeric values, slippage, request size, response size, and timeout behavior before forwarding a request.

The authoritative bridge fee is loaded on the server as integer basis points and converted to the LI.FI decimal percentage unit. The current implementation preserves the configured integrator `paxiwallet`, rejects client fee mismatches, and enforces the configured maximum. **50 BPS equals 0.50%; 80 BPS equals 0.80%.** The client may display the fee but is not its authority.

`LIFI_API_KEY` is server-only. It is never placed in `VITE_*` variables, frontend code, browser storage, URLs, logs, errors, AI context, or support context. The local `PAXI_TREASURY_ADDRESS` is a separate public operational setting and is not proof of LI.FI partner payout configuration.

The following remain **EXTERNAL CONFIGURATION REQUIRED** and are not claimed as code-verified or live-transaction-verified: LI.FI Partner Portal registration for `paxiwallet`, the exact partner payout/treasury destination per supported chain, production LI.FI API credential activation, production RPC credentials, and any production treasury configuration. A real fee-bearing staging transaction and supported LI.FI account evidence must verify payout before that result can be described as live verified.

The latest LI.FI final-freeze validation completed with **55 test files and 213 tests passing**; typecheck, build, and scoped lint passed. `npm audit --omit=dev` remains non-zero with **21 findings: 7 low, 11 moderate, 3 high, and 0 critical**, which is retained as a documented controlled-beta security acceptance. See `reports/LIFI_FEE_EXTERNAL_CONFIGURATION_NOTES.md` and `release-validation-lifi-final-freeze-2026-08-18/` for evidence.
