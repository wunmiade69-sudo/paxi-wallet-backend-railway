# PAXI Wallet — Final Engineering Correction & Beta Release Candidate Report

**Report date:** 18 August 2026  
**Candidate:** PAXI Wallet controlled-beta release candidate  
**Final status:** **BETA READY WITH KNOWN SECURITY ACCEPTANCE**

> This release decision applies to the corrected controlled-beta codebase only. It is not an authorization for unrestricted mainnet treasury use, production payouts without operational gates, or a claim that physical-device and deployment-runbook testing has been completed.

## 1. Executive summary

The correction pass was completed without rebuilding or replacing the existing wallet architecture. The work addressed the executive directive’s high-risk boundaries: canonical Solana Token-2022 identification, fail-closed WalletConnect behavior, normalized transaction states, submission-versus-confirmation semantics, broadcast recovery, economic idempotency and concurrency, treasury configuration, user-facing capability honesty, and current-state documentation.

The final candidate compiles, builds, passes the complete automated suite, and passes the expanded scoped formatting gate. The latest post-correction run completed with **53 test files and 202 tests passing**. Dependency audit remains non-zero at **21 findings: 7 low, 11 moderate, 3 high, and 0 critical**, concentrated in the active Solana and WalletConnect dependency trees. Those findings are explicitly accepted for this controlled beta with compensating controls and an upgrade plan; they are the reason the status is not an unconditional “BETA READY.”

## 2. Exact changes implemented

The following correction-pass changes are present in the candidate. Existing architecture, campaign listing, chart, Redis, and eligibility systems were retained.

| Area                   | Exact implementation change                                                                                                                                                                             | Primary files                                                                                                    |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Solana Token-2022      | Replaced manually typed program identification with canonical `TOKEN_2022_PROGRAM_ID` and `TOKEN_PROGRAM_ID`; extracted a pure mint-account classifier.                                                 | `server/riskEngine.ts`, `server/riskEngine.test.ts`                                                              |
| WalletConnect          | Added hard-coded `WC_ENABLED = false`, fail-closed client initialization, strict chain/account/method/payload validation, and explicit non-simulation semantics.                                        | `client/src/lib/wallet/walletconnect.ts`, `client/src/lib/wallet/walletconnect.test.ts`, `.env.example`          |
| Transaction model      | Expanded `TxStatus` to a normalized 14-state model, added chain-specific `TxFinality`, transition validation, success/failure/in-flight helpers, and safer UI rendering.                                | `client/src/lib/wallet/txHistory.ts`, `TransactionList.tsx`, `TransactionReceipt.tsx`, `useTransactionStatus.ts` |
| Solana recovery        | Added pure `mapSolanaSignatureStatus()` and signature recovery in transaction indexing.                                                                                                                 | `client/src/lib/wallet/txIndexer.ts`, `txIndexer.test.ts`                                                        |
| Confirmation semantics | Solana swaps and bridges return `submitted` on confirmation timeout while retaining the broadcast hash; sends persist chain-specific finality; swap and bridge panels persist finality/status metadata. | `jupiterSwap.ts`, `bridge.ts`, `swap.ts`, `SendScreen.tsx`, `SwapPanel.tsx`, `BridgePanel.tsx`                   |
| Gift Code concurrency  | Extracted and tested the atomic affected-row guard so a zero-row concurrent reservation fails before redemption and ledger insertion.                                                                   | `server/giftCodes/giftCodeRepository.ts`, `giftCodeConcurrency.test.ts`                                          |
| Documentation          | Rewrote current-state README and controlled-beta testing guide; labeled legacy feedback and todo documents as historical; added production operations readiness requirements.                           | `PAXI_WALLET_README.md`, `TESTING_GUIDE.md`, `PAXI_WALLET_FEEDBACK.md`, `todo.md`, `PRODUCTION_OPERATIONS.md`    |
| Validation gate        | Extended the npm lint script to include correction-pass source, test, environment, and release-document files.                                                                                          | `package.json`                                                                                                   |

## 3. Security corrections

Solana mint classification now uses SDK-owned identifiers rather than a manually duplicated literal. The classifier distinguishes classic SPL Token, Token-2022, unsupported owners, malformed account data, and unavailable account data. This reduces drift risk between the application’s security decision and the installed Solana SDK.[4]

The signing boundary remains client-side. Private keys and mnemonics are not intentionally sent to the server, browser storage in plaintext, logs, analytics, WalletConnect peers, or third-party providers. Server-controlled payout and reward signers remain separate operational credentials and require explicit configuration. Missing treasury configuration fails closed rather than silently selecting an unsafe address.[1]

The correction pass also preserves UNKNOWN/NOT SIMULATED semantics. A request is not described as simulated merely because it has been constructed or validated. Where safe simulation is unavailable, the confirmation surface must display the known recipient, token, amount, network, native value, gas, contract/function context, and risk warning without claiming a simulation result.[1] [2]

## 4. WalletConnect status

WalletConnect is **disabled and fail-closed for the controlled beta**. `WC_ENABLED` is hard-coded to `false`, and the client initialization path throws when the feature is disabled. The validator remains present and unit-tested for a separately reviewed post-beta enablement, but no dApp request can reach an active signing path in this candidate.[5]

The validator rejects unsupported chains, unsupported methods, malformed payloads, and non-transaction signing methods such as `personal_sign`, typed-data signing, and `eth_sign`. This is a security boundary, not a claim that WalletConnect signing is currently available.

## 5. Transaction state-machine status

The client now uses a normalized state model containing `unknown`, `created`, `validating`, `awaiting_signature`, `signed`, `submitted`, `pending`, `confirmed`, `finalized`, `failed`, `replaced`, `dropped`, `reorged`, and `expired`. Chain-specific finality metadata is carried separately, so a successful broadcast is not rendered as successful confirmation.[6]

Transition checks reject invalid state changes. UI components use normalized helpers rather than treating an unknown or intermediate record as successful. Polling covers every in-flight state. Solana signature status is mapped conservatively: processed becomes submitted, confirmed becomes confirmed, finalized becomes finalized, an error becomes failed, and an unavailable status remains unknown.[7]

Timeout behavior is intentionally recoverable. Solana swap and bridge operations retain the transaction hash and return `submitted` rather than throwing as if no economic operation occurred. EVM and Bitcoin records remain subject to their chain-specific confirmation and recovery behavior.

## 6. Money-moving concurrency status

Campaign payout recovery retains a reservation when broadcast confirmation times out or the RPC is unavailable. If a transaction hash exists, the system verifies the existing transaction before any retry. Pending or invalid verification retains the reservation; exact successful transfer verification confirms it; an explicit reverted receipt is the only condition that permits a correctly managed replacement path.[9]

The payout path uses a broadcast lease, unique nonce coordination, transaction-hash retention, and recovery-before-retry behavior. Gift Code reservation uses a database transaction, row locking, an atomic redemption-count predicate, a unique idempotency key, and an affected-row guard. A zero-row update is rejected as a concurrent redemption and cannot proceed to insert a second reward ledger outcome.[8]

Reward accounting maintains separate reserved, claimed, remaining, and escrowed buckets and requires reconciliation. Existing tests cover duplicate redemption, pending versus confirmed idempotency, payout recovery states, and exact accounting. The new `giftCodeConcurrency.test.ts` adds direct regression coverage for the atomic no-row concurrency guard.

## 7. Multi-chain capability matrix

The repository deliberately distinguishes configured capability from route and provider parity. The current matrix is summarized below; the authoritative details and limitations are in the current README.[1]

| Chain/network   | Address/balance                  | Signing and transfers                   | Swap                                | Bridge                         | Controlled-beta limitation                                 |
| --------------- | -------------------------------- | --------------------------------------- | ----------------------------------- | ------------------------------ | ---------------------------------------------------------- |
| Ethereum        | EVM native and configured ERC-20 | Supported where assets are validated    | Provider route                      | EVM route                      | Provider, RPC, and token availability vary.                |
| BNB Smart Chain | Native and configured BEP-20     | Supported where assets are validated    | Provider route                      | EVM route                      | Explicit treasury and provider configuration are required. |
| Polygon         | Basic configured EVM operations  | Basic configured operations             | Not exposed as a general beta route | Not exposed by beta predicate  | No assumed Ethereum/BSC parity.                            |
| Arbitrum One    | Basic configured EVM operations  | Basic configured operations             | Not exposed as a general beta route | Not exposed by beta predicate  | Route and indexer coverage are intentionally narrower.     |
| Bitcoin         | Native SegWit, balances, UTXOs   | Local signing and broadcast implemented | Not available                       | Not available                  | Confirmation and recovery are UTXO-specific.               |
| Solana          | Native/SPL configured operations | Local signing and broadcast implemented | Jupiter controlled-beta route       | Only explicit supported routes | Token-2022 classification uses canonical SDK identifiers.  |
| PAXI network    | Not configured                   | Not available                           | Not available                       | Not available                  | No placeholder EVM endpoint or assumed mainnet support.    |
| Custom EVM      | User-configured metadata         | May work after validation               | Not available                       | Not available                  | Not automatically production-supported.                    |

## 8. UI/UX fixes and safeguards

Transaction list and receipt views now distinguish intermediate, successful, and terminal-failure states. Unknown, submitted, pending, and other in-flight records cannot receive a success treatment merely because a hash was produced. Confirmation surfaces retain the route, network, amount, fee, recipient, contract/function context, slippage or bridge context, and risk state where applicable.

Fiat conversion fails closed when a verified rate is unavailable, and the UI communicates unavailable or stale data rather than silently labeling an unverified value in the selected fiat currency. Slippage is bounded to the existing controlled range and remains user-visible. Unsupported bridge combinations are withheld rather than presented as executable routes. TON Jetton Gift Code fulfillment remains explicitly “Coming soon” and cannot be activated through an unsupported path.[1] [2]

## 9. Placeholders and capability claims removed

Example public domains and fake referral/About origins were removed from user-facing behavior. Referral and About links require an explicit configured HTTPS public origin and otherwise show an unavailable state. The README no longer describes PAXI mainnet as active, and the capability matrix does not infer feature parity from address-format support. Historical review and todo files are labeled as historical rather than being presented as current product claims.

The controlled-beta documentation also states that WalletConnect is disabled, simulation is not fabricated, Bitcoin/Solana history coverage is narrower than EVM indexing, bridge/swap route coverage is limited, physical-device QA is not represented as complete, and the dependency findings remain an accepted limitation.[1]

## 10. Dependency audit disposition

`npm audit --omit=dev` completed with exit code 1 because the dependency graph still contains 21 findings. The exact final count is **7 low, 11 moderate, 3 high, and 0 critical**.[11]

| Disposition | Findings or control                                                                                                                                                         | Decision                                                                                         |
| ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| Resolved    | The manually hardcoded Solana Token-2022 identifier and unsafe state/confirmation semantics were corrected in application code.                                             | Complete.                                                                                        |
| Mitigated   | WalletConnect is hard-disabled; strict validator tests remain in place but the active signing path is unreachable in controlled beta.                                       | Accepted only for controlled beta.                                                               |
| Accepted    | Active Solana and WalletConnect dependency-tree advisories remain, including findings involving `bigint-buffer`, `elliptic`, `uuid`, and WalletConnect transitive packages. | Explicit security acceptance with compensating controls.                                         |
| Unresolved  | Major-version remediation suggested by npm is compatibility-sensitive and would alter Solana or WalletConnect packages.                                                     | No forced upgrade was applied; upgrade work requires a separate compatibility branch and review. |

The accepted findings are a known security limitation, not a claim that the dependency graph is clean. The post-beta plan must prioritize compatible upgrades, fresh audit review, and re-execution of the signing and chain regression suites.

## 11. Automated test results

The original validation run at **2026-08-18T14:38:30Z** is retained as historical evidence. The current post-correction validation is authoritative and is recorded in the final token-standard identity correction addendum below, with **53 test files passed and 202 tests passed**.

The run emitted non-failing warnings: `bigint` reported that native bindings were unavailable and pure JavaScript was used; Node reported the deprecated `punycode` module; and provider-resilience tests intentionally logged simulated provider failures. None changed the exit code.

## 12. Build result

`npm run build` completed successfully with exit code 0. Vite transformed 4,234 modules and produced the client and server bundles. The build emitted a removable Rollup annotation warning from the `ox` dependency, dynamic-import/static-import chunking warnings for Solana and Bitcoin modules, and a large-chunk warning for the wallet bundle at approximately 1,990 kB minified before gzip. These are performance and dependency warnings, not build failures; production operations should track chunking separately from the security acceptance.[10]

## 13. TypeScript and lint results

`npm run check` completed successfully with exit code 0 and no TypeScript diagnostics. `npm run lint` completed successfully with exit code 0 after the gate was expanded to include the correction-pass source, tests, environment template, and current release documents. The lint command is intentionally scoped and is not a claim of repository-wide formatting coverage.[10]

## 14. Manual QA matrix

The manual QA matrix remains a release-owner responsibility. No physical-device, offline, app-termination, background/resume, staging-transfer, or production-deployment exercise is claimed as completed by this sandbox run. The current testing guide marks the manual rows as **Not yet executed** and defines the evidence that must be captured before broader beta exposure.[2]

| Manual area                                           | Candidate expectation                                                | Actual status in this pass                                                            |
| ----------------------------------------------------- | -------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| Desktop browser wallet creation, import, lock, unlock | Encrypted vault and client-side signing behavior                     | Not executed in this pass.                                                            |
| Mobile viewport and responsive layout                 | No clipped critical actions or unsafe confirmation behavior          | Not executed in this pass.                                                            |
| Physical iOS/Android device                           | Background, resume, secure storage, QR, biometric behavior           | Not executed; must be completed by release owner.                                     |
| EVM, Bitcoin, and Solana testnet transfers            | Correct address, amount, fee, signing, hash, and finality status     | Not executed against live networks.                                                   |
| Swap and bridge recovery                              | Timeout retains submitted state and hash; no blind retry             | Covered by deterministic tests; live-provider exercise not executed.                  |
| Gift Code and reward concurrency                      | One economic action cannot create two economic outcomes              | Deterministic and database-boundary coverage present; live staging race not executed. |
| Redis/database/provider outage                        | Fail-closed or explicitly degraded behavior with audit evidence      | Deterministic resilience coverage exists; deployment exercise not executed.           |
| Treasury and signer configuration                     | Explicit configuration, correct chain/token/destination, no fallback | Code and tests audited; real signer/staging transfer not executed.                    |
| WalletConnect disabled state                          | No request reaches an active signing boundary                        | Deterministic tests pass; browser/manual UI exercise not executed.                    |

## 15. Remaining beta blockers and release conditions

The candidate is ready for a **controlled** beta with known security acceptance, subject to the following release-owner gates: keep WalletConnect disabled; use test funds and explicitly configured treasury/reward destinations; verify database, Redis, and provider health; enable audit-log retention and alerting; complete staging transfers and timeout/recovery drills; and ensure no real `.env`, seed phrase, private key, signer credential, or operational secret enters the release artifact.

The following are not resolved by this repository pass: the 21 dependency findings, deployment-owned backup and restore verification, migration and deployment rollback procedures, secret rotation, structured logging and redaction verification, incident response, production RPC failover, and physical-device QA. If any controlled-beta gate is absent, the candidate should be treated as **BETA NOT READY for that environment**, even though the code-level decision remains “BETA READY WITH KNOWN SECURITY ACCEPTANCE.”

## 16. Post-beta roadmap

The first post-beta workstream should establish a compatibility-tested dependency upgrade branch for the Solana and WalletConnect trees, followed by a fresh audit and full regression run. WalletConnect should remain disabled until its request confirmation, simulation, chain/account validation, and peer-trust model receive a separate security review.

The second workstream should complete operational hardening: structured logging with correlation IDs and secret redaction, audit-log retention and alerting, provider/RPC SLOs, Redis/database incident behavior, encrypted backups, restore validation, migration rollback or forward-fix procedures, deployment rollback, signer rotation, and incident response. These requirements are recorded in `PRODUCTION_OPERATIONS.md` and are not fabricated as complete.[3]

The third workstream should complete live staging and device QA across enabled chains, including app lifecycle behavior, QR and biometric flows, transfer recovery, provider outage, concurrent economic actions, and exact on-chain verification. Only after those controls are evidenced should the team consider expanding route coverage, enabling additional bridges, or enabling a reviewed WalletConnect flow.

## References

[1]: PAXI_WALLET_README.md "PAXI Wallet current controlled-beta README"
[2]: TESTING_GUIDE.md "PAXI Wallet controlled-beta testing guide"
[3]: PRODUCTION_OPERATIONS.md "PAXI Wallet production operations readiness"
[4]: server/riskEngine.ts "Solana token-account classification"
[5]: client/src/lib/wallet/walletconnect.ts "WalletConnect boundary and validator"
[6]: client/src/lib/wallet/txHistory.ts "Normalized transaction state model"
[7]: client/src/lib/wallet/txIndexer.ts "Chain status indexing and Solana recovery"
[8]: server/giftCodes/giftCodeRepository.ts "Atomic Gift Code reservation and idempotency"
[9]: server/campaigns/rewardEscrow.ts "Campaign payout recovery and nonce safety"
[10]: release-validation-2026-08-18/summary.txt "Final validation summary"
[11]: release-validation-2026-08-18/audit.log "Final npm audit output"

## Post-beta directive implementation addendum — 18 August 2026

The follow-up executive directive was implemented as an additive extension to the existing wallet architecture. No wallet-signing architecture, Redis design, campaign listing, chart system, or eligibility system was replaced.

| Area                              | Implemented result                                                                                                                                                                                                                                   | Safety boundary                                                                                                                                                                                    |
| --------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Canonical token discovery         | Added `market.discover` with EVM/Solana address detection, symbol/name/native alias search, provider aggregation, deterministic ranking, chain-plus-contract identity, source/freshness/confidence metadata, explorer URLs, and PAXI Shield linkage. | Provider failure is isolated; unknown price, volume, market cap, logo, chart, trust, and security values remain explicit unknowns. A listing or liquidity signal is never presented as legitimacy. |
| Canonical token detail            | Existing detail screen accepts `chainId:contractAddress` identities in addition to legacy CoinGecko ids, with chain, contract, explorer, copy, trust, security, freshness, and import-safety states.                                                 | Unsupported chains and unavailable chart mappings fail closed; missing values are not coerced into zeroes or fabricated charts.                                                                    |
| PAXI AI Support                   | Added a protected server-side support path using the existing LLM helper and a documented support system prompt.                                                                                                                                     | The model cannot sign, approve, send, change settings, bypass WalletConnect, or claim unsupported simulation, receipt, price, or security facts.                                                   |
| Diagnostics and anti-phishing     | Added strict allowlisting for public diagnostics and rejection of recovery phrases, private keys, PINs, passwords, authentication codes, and secret-looking fields.                                                                                  | Wallet secrets are rejected before persistence or LLM invocation; no browser/local-storage fallback is used for support data.                                                                      |
| Human escalation                  | Added idempotent support-ticket creation, message deduplication, user-owned ticket list/detail, and ticket status/priority/assignment fields.                                                                                                        | Duplicate client submissions do not create duplicate tickets or initial messages; users cannot read another user's ticket.                                                                         |
| Authorized support administration | Added admin-only ticket list/detail/reply/update procedures behind the existing `adminProcedure` RBAC guard with audit events.                                                                                                                       | No general-user or unauthenticated support-admin bypass was added.                                                                                                                                 |
| Database boundary                 | Added `supportTickets` and `supportMessages` schema plus `drizzle/0011_support_tickets.sql`.                                                                                                                                                         | The migration must be reviewed and deployed before persistent support is enabled in an environment.                                                                                                |
| Documentation and QA              | Updated the authoritative README and testing guide with discovery/support capabilities, limitations, focused QA, and operational caveats.                                                                                                            | No physical-device, live-network, backup/restore, or deployment exercise is claimed as complete.                                                                                                   |

New focused tests cover EVM/Solana address detection, supported-chain mapping, exact-contract ranking, public diagnostic retention, secret rejection, and support content bounds. The final automated run completed with **52 test files and 187 tests passing**. `npm run check`, `npm run build`, and the expanded `npm run lint` passed. `npm audit --omit=dev` remains non-zero with **21 findings: 7 low, 11 moderate, 3 high, and 0 critical**, unchanged in disposition from the controlled-beta acceptance above. Build warnings remain non-blocking dependency/chunk warnings recorded in `release-validation-2026-08-18/build.log`.

## Final directive-pass addendum — 18 August 2026

The final review identified and corrected two remaining P0 concerns. Token discovery now deterministically selects the latest security assessment using descending `checkedAt`/`updatedAt` ordering, rejects malformed current labels, rejects stale assessments older than the configured freshness window, and returns `unknown` rather than falling back to an older historical report. This behavior is covered by historical-ordering, newest-report, no-report, malformed-report, and stale-report regressions.

The support model boundary now retains internal `userId` only for server-side correlation and ticket ownership. It is removed before safe diagnostic context is serialized into the external model request. Public wallet diagnostics remain allowlisted, and secret rejection remains enforced before persistence or model invocation.

The final validation run at **2026-08-18T15:23:03Z** passed **52 test files and 192 tests**. TypeScript check, production build, and expanded lint passed with exit code 0. Dependency audit remains the known controlled-beta acceptance of **21 findings: 7 low, 11 moderate, 3 high, 0 critical**. No physical-device, live-network, deployment, backup/restore, or incident-response completion is claimed.

## Production Excellence / 10-10 Hardening Addendum — August 18, 2026

This addendum records the latest hardening pass against the existing controlled-beta candidate. The existing wallet, provider, Redis, campaign, chart, and eligibility architecture was retained.

### Additional implementation changes

| Workstream           | Implemented correction                                                                                                                                                                                                   | Evidence                                                                                                                     |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| EVM swap review      | Quote expiry is enforced before signing; the review surface shows quote age/expiry, route/network, minimum received, approval target, gas-estimate availability, simulation state, and irreversible-transaction warning. | `client/src/lib/wallet/swap.ts`, `client/src/pages/SwapPanel.tsx`, `client/src/lib/wallet/swap.test.ts`                      |
| Simulation semantics | Provider-backed simulation is attempted where supported; failed simulation blocks signing, successful simulation is explicit, and unavailable simulation remains unavailable rather than being fabricated.               | `swap.ts`, `SwapPanel.tsx`                                                                                                   |
| Receipt lifecycle    | Mined EVM receipt failures and explorer failure states normalize to terminal `reverted`; the state is not successful and cannot transition back to an in-flight state.                                                   | `txHistory.ts`, `txIndexer.ts`, `TransactionReceipt.tsx`, `txHistory.test.ts`                                                |
| Market observability | Existing multi-provider aggregation now records provider success, latency, failure, and rate-limit state in the existing health registry. Provider health is admin-RBAC protected.                                       | `server/providers/aggregator.ts`, `server/providers/health.ts`, `server/providers/health.test.ts`, `server/routers/admin.ts` |
| AI resilience        | PAXI AI validates message shape and returns an escalation-safe temporary-unavailability response when the model provider fails; no wallet action is taken.                                                               | `server/support/supportService.ts`                                                                                           |

### Focused regression evidence

The focused hardening suite passed with **6 test files and 31 tests**. It covers swap expiry/approval/simulation/reverted semantics, normalized transaction states, Solana and EVM indexer mappings, token discovery safety, support secret and identity boundaries, and provider-health state transitions.

### Current readiness qualification

The candidate remains suitable only for the documented controlled-beta envelope. The following are not claimed as completed by this pass: physical-device QA, hardware-wallet custody, live-network staging with funded accounts, formal external security review, backup/restore rehearsal, deployment rollback rehearsal, secret-rotation rehearsal, and incident-response exercise. The dependency audit remains a known accepted risk and must continue to be tracked separately from application-level hardening.

## Final production-excellence validation — August 18, 2026

The final hardening validation completed at **2026-08-18T15:56:42Z**.

| Gate                   | Result                                                                    |
| ---------------------- | ------------------------------------------------------------------------- |
| `npm run check`        | Passed, exit 0                                                            |
| `npm test -- --run`    | Passed: **53 test files, 199 tests**                                      |
| `npm run build`        | Passed, exit 0; build warnings remain recorded in the validation artifact |
| `npm run lint`         | Passed, exit 0                                                            |
| `npm audit --omit=dev` | Exit 1: **21 vulnerabilities — 7 low, 11 moderate, 3 high, 0 critical**   |

The dependency-audit result is a known controlled-beta acceptance, not a hidden pass. The current findings remain concentrated in active Solana and WalletConnect dependency trees, with remediation requiring compatibility-sensitive upgrades. The release owner must retain the documented compensating controls and upgrade plan.

The focused production-hardening regressions include **31 passing tests** for swap expiry/approval/simulation/reverted semantics, normalized transaction states, indexer mappings, token-discovery safety, support secret and identity boundaries, and provider-health transitions. No physical-device, funded live-network staging, hardware-wallet, backup/restore, deployment rollback, secret-rotation, external security review, or incident-response exercise is claimed as completed.

## Final closure-pass addendum — 2026-08-18T16:24:37Z

The final closure pass completed the native Help & Support workflow and preserved the existing production-hardening boundaries. `SupportScreen.tsx` now provides an AI landing state with quick prompts, visible checking/progress state, retry and temporary-unavailable handling, escalation to a human, ticket creation, ticket list, ticket detail, and reply behavior. The screen reuses the existing protected support router and service contracts rather than introducing a second support architecture.

Support UX remains conservative: the client does not claim that an answer is authoritative, a transaction was simulated, or a transaction can be recovered automatically. Public read-only transaction/token context is bounded by the server allowlist. Recovery phrases, private keys, PINs, passwords, authentication codes, API keys, and signer material remain rejected before persistence or model invocation. The AI path cannot sign, approve, send, change settings, enable WalletConnect, or perform any wallet action.

The controlled-beta QA guide now includes explicit rows for Help & Support landing, AI retry/outage handling, escalation, ticket list/detail/reply, safe transaction context, and secret rejection. These rows remain **Not yet executed** on physical devices because this sandbox cannot truthfully perform the required device/browser matrix.

The fresh hardening validation completed with the following exact results:

| Gate                   | Result                                                                                                                      |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `npm run check`        | Passed, exit 0                                                                                                              |
| `npm test -- --run`    | Passed: **53 test files, 199 tests**                                                                                        |
| `npm run build`        | Passed, exit 0; Rollup annotation, mixed dynamic/static import, and large-chunk warnings recorded in the build log          |
| `npm run lint`         | Passed, exit 0                                                                                                              |
| `npm audit --omit=dev` | Exit 1 with **21 findings: 7 low, 11 moderate, 3 high, 0 critical**; retained as documented controlled-beta risk acceptance |

The previous build termination was an environmental sandbox resource event during chunk rendering. After idle browser helpers were terminated, the same unchanged build completed successfully in 9.59 seconds for the client and 32 ms for the server bundle. This does not change the application code or the warning disposition.

The final status remains **BETA READY WITH KNOWN SECURITY ACCEPTANCE**. This status is conditional on the documented operational requirements: migration deployment, physical-device QA, funded staging, external security review, backup/restore rehearsal, deployment rollback rehearsal, secret rotation, and incident-response validation remain release-owner responsibilities.

## Final Pre-Beta Gate Addendum — 2026-08-18

This addendum records the final-gate corrections applied after the production-hardening closure pass.

### Security-versus-trust semantics

Token verification trust is now distinct from security assessment. Explicit `verified` asset verification maps to `verified`; `registered` maps to `unverified`; all other, missing, or malformed verification values remain `unknown`. Security labels and scores continue to come only from the latest valid, fresh security report. A security label cannot upgrade discovery trust, and a verification label cannot imply a safe security result.

### True multi-provider discovery

Name and symbol discovery now fans out over provider-native search capabilities in the existing registry. CoinGecko uses its search endpoint and resolves platform/contract identity through the existing detail path; DexScreener uses its search endpoint and returns chain-aware token addresses. Results are failure-isolated, deduplicated by canonical chain-plus-contract identity, merged with provider provenance, and ranked deterministically. Provider failure produces an explicit unavailable state rather than a fabricated result.

### Validation evidence

The final-gate runner completed at `2026-08-18T17:11:48Z`: `npm run check` exit 0; `npm test -- --run` exit 0 with 53 test files and 200 tests passing; `npm run build` exit 0; `npm run lint` exit 0; `npm audit --omit=dev` exit 1 with 21 findings (7 low, 11 moderate, 3 high, 0 critical). Build warnings are non-blocking Rollup annotation, mixed dynamic/static import, and large-chunk warnings recorded in the build log. The audit findings remain a known controlled-beta dependency acceptance and are not represented as resolved.

No physical-device QA, funded live-network staging, hardware-wallet custody validation, external security review, backup/restore rehearsal, deployment rollback rehearsal, secret rotation, or incident-response exercise is claimed as completed.

**Final status: BETA READY WITH KNOWN SECURITY ACCEPTANCE.**

### Final validation refresh — 2026-08-18T17:13:08Z

The reproducible final-gate runner completed with `check_exit=0`, `test_exit=0`, `build_exit=0`, `lint_exit=0`, and `audit_exit=1`. Vitest reported **53 test files passed and 200 tests passed**. The production dependency audit reported **21 vulnerabilities: 7 low, 11 moderate, and 3 high**, including the previously reviewed `bigint-buffer` advisory; no critical findings were reported. The non-zero audit remains an explicit controlled-beta acceptance, not a resolved-vulnerability claim.

## Final token-standard identity correction and validation refresh — 2026-08-18

The final-freeze audit identified one objective discovery-model gap: canonical identity previously consisted of chain and contract only, without an explicit token-standard component. The existing architecture was retained and corrected minimally. `ProviderSearchResult` now carries an optional token standard; supported chain context derives ERC-20 for Ethereum/Polygon/Arbitrum, BEP-20 for BNB Smart Chain, SPL Token for Solana, and native for native assets. Unsupported combinations remain `unknown` rather than being guessed. Discovery identity is now `chainId:tokenStandard:normalizedContract`, preserving EVM case-insensitive normalization and non-EVM address semantics.

The discovery regression suite now covers chain-specific standard derivation and duplicate provider observations merged by canonical identity with provenance preserved. Existing security-versus-trust, freshness, malformed-report, and ranking regressions remain in place.

The reproducible post-correction validation runner `scripts/run-final-freeze-validation.sh` completed at `2026-08-18T17:32:17Z` with the following results:

| Gate                   | Result                                                                                                                                |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run check`        | Passed, exit 0                                                                                                                        |
| `npm test -- --run`    | Passed: 53 test files, 202 tests                                                                                                      |
| `npm run build`        | Passed, exit 0; existing Rollup annotation, mixed dynamic/static import, and large-chunk warnings remain documented in `build.log`    |
| `npm run lint`         | Passed, exit 0                                                                                                                        |
| `npm audit --omit=dev` | Exit 1: 21 vulnerabilities — 7 low, 11 moderate, 3 high, 0 critical; retained as the documented controlled-beta dependency acceptance |

No forced dependency upgrade was applied. No physical-device QA, funded live-network staging, deployment rollback, backup/restore rehearsal, secret rotation, external security review, or incident-response exercise is claimed as completed.

**Final status remains: BETA READY WITH KNOWN SECURITY ACCEPTANCE.**

## Final web RC correction pass — Solana fee configuration and validation refresh — 2026-08-18

This pass closed the remaining concrete Solana wallet-fee configuration issue without redesigning the swap architecture. No real Solana treasury address exists in the current production configuration, so the web RC follows the directive's configuration-required path rather than fabricating an address or silently redirecting funds.

`client/src/lib/wallet/jupiterSwap.ts` now reads the optional public `VITE_PAXI_SOLANA_TREASURY_ADDRESS` setting, validates it with the canonical Solana `PublicKey` parser, and fails closed for missing or malformed values. The resulting fee configuration is explicit: `configuration_required`, `enabled: false`, `feeBps: 0`, and no treasury destination. A valid configured address is normalized before it can be used for Jupiter platform-fee routing. The quote path only sends `platformFeeBps` when the validated configuration is enabled, and the execution path only derives a fee account from that validated treasury.

`client/src/pages/SwapPanel.tsx` now displays **Configuration required** for Solana quotes without a validated treasury and states in final review that no PAXI wallet fee is collected on that route while network and route fees still apply. EVM fee behavior and the existing UI architecture are unchanged. `.env.example` documents the blank-by-default public setting and the fail-closed behavior.

Added `client/src/lib/wallet/jupiterSwap.test.ts` with regressions for missing treasury configuration, malformed addresses, zero/disabled fee behavior, no silent destination redirect, and valid treasury validation. The existing EVM swap tests remain unchanged and passing.

The authoritative post-correction validation run was completed after formatting the documentation update:

| Gate                   | Result                                                                                                                                                     |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run check`        | Passed, exit 0                                                                                                                                             |
| `npm test -- --run`    | Passed: **54 test files, 206 tests**                                                                                                                       |
| `npm run build`        | Passed, exit 0; existing large wallet-chunk warning remains documented                                                                                     |
| `npm run lint`         | Passed, exit 0                                                                                                                                             |
| `npm audit --omit=dev` | Exit 1: **21 vulnerabilities — 7 low, 11 moderate, 3 high, 0 critical**; no forced fix applied and findings remain a documented controlled-beta acceptance |

The dependency audit remains concentrated in the previously reviewed Solana and WalletConnect dependency trees. No mobile project was created, and no physical-device QA, funded live-network staging, external security review, backup/restore rehearsal, deployment rollback, secret rotation, or incident-response exercise is claimed as completed.

**Current final web RC decision: BETA READY WITH KNOWN ACCEPTED RISKS.** This is conditional on deployment-owner completion of the documented operational prerequisites and on treating the known dependency findings as an explicit controlled-beta acceptance. The web codebase is frozen after this correction pass.

### Files changed in this correction pass

- `client/src/lib/wallet/jupiterSwap.ts`
- `client/src/lib/wallet/jupiterSwap.test.ts`
- `client/src/lib/wallet/swap.ts`
- `client/src/pages/SwapPanel.tsx`
- `.env.example`
- `PAXI_WALLET_README.md`
- `TESTING_GUIDE.md`
- `PAXI_WALLET_RELEASE_CANDIDATE_REPORT.md`

### Deferred to post-beta or deployment ownership

A read-only PAXI AI diagnostic-tool layer remains deferred because the current context-based support implementation already satisfies the beta security boundary and adding tools would require broader architecture changes. Mobile packaging remains a subsequent Capacitor/native phase. A real Solana treasury address must be supplied and operationally verified before Solana wallet-fee monetization is enabled. Provider expansion remains deferred unless an existing adapter gains a documented, genuine discovery capability.

## Railway staging and Android QA preparation addendum — 2026-08-19

This addendum records the staging-preparation pass performed against the active repository checkout. The backend remains MySQL/TiDB-based; Railway PostgreSQL is not compatible with the current Drizzle schema and migration procedures without a separately approved database-architecture migration. The exact Railway build, start, pre-deploy, readiness, Redis, environment, migration-safety, provider, LI.FI, PAXI AI, treasury, and Android QA procedures are documented in `RAILWAY_STAGING_ANDROID_QA_REPORT.md`.

The active checkout contains the backend staging preparation and the removal of an unreachable client-side map implementation that referenced stale Forge-key variables. It does not currently contain `capacitor.config.ts`, `android/`, `client/src/lib/mobileRuntime.ts`, or `client/src/lib/nativeDevice.ts`. Consequently, Android Capacitor synchronization, APK compilation, native API-origin validation, and physical-device QA are blocked in this checkout and are not claimed complete. The report explicitly requires the separately prepared mobile source to be restored or reattached rather than recreating it as part of this backend staging task.

Repository-side validation completed with `npm run check` exit 0, `npm test -- --run` passing **56 test files and 218 tests**, `npm run lint` exit 0, and `npm run build` exit 0. The production dependency audit remains non-zero at **21 vulnerabilities: 7 low, 11 moderate, and 3 high**; no forced breaking remediation was applied. A built web-bundle scan found none of the scanned server-only credential names or stale client Forge-key aliases.

No Railway project, compatible MySQL/TiDB service, Redis instance, staging credentials, backup/restore rehearsal, real Android device, live transaction, signed APK/AAB, OAuth production flow, or LI.FI partner fee attribution was verified. The web RC remains **BETA READY WITH KNOWN SECURITY ACCEPTANCE**, conditional on the documented deployment-owner controls; the Android status in this active checkout is **BLOCKED PENDING MOBILE SOURCE RESTORATION**, not device-QA ready.
