# PAXI Wallet Production Operations Readiness

**Status:** Controlled-beta operational requirements. This document records the mechanisms visible in the repository and the controls that must be supplied by the deployment owner. It does not claim that infrastructure procedures have been executed in this sandbox.

## Readiness matrix

| Control                          | Repository status            | Release interpretation                                                                                                                                                                                                                                      |
| -------------------------------- | ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Structured logging and redaction | Partial                      | Application error and audit paths exist, but a deployment-level structured logger, correlation IDs, retention policy, and secret-redaction verification must be configured and tested.                                                                      |
| Security audit logs              | Present in application paths | Administrative Gift Code, redemption, reward-transfer, payout, and security-sensitive events are recorded through the existing audit boundary. Production retention and alerting remain deployment requirements.                                            |
| Provider health                  | Present                      | Provider health records success, failure, latency, rate-limit, and last-error information. Operators must expose and monitor those signals.                                                                                                                 |
| RPC health                       | Partial                      | Chain adapters fail conservatively and retry/recover through provider boundaries, but each production RPC endpoint still requires monitoring, timeout policy, quota alerts, and an operator-owned failover plan.                                            |
| Redis failure handling           | Present with limits          | `redisSafe` and cache/lock wrappers degrade gracefully where designed. A deployment must still decide whether money-moving operations are allowed when distributed coordination is unavailable; no cache fallback should be treated as proof of uniqueness. |
| Database failure handling        | Present with limits          | Database access returns explicit unavailable errors or best-effort empty reads at defined boundaries. Production requires connection-pool monitoring, alerting, migration checks, and a tested recovery procedure.                                          |
| Backups                          | External requirement         | Configure encrypted database backups, retention, restore verification, and ownership before enabling real-money beta operations.                                                                                                                            |
| Restore procedure                | External requirement         | Maintain a documented restore runbook, including validation of ledger, payout, Gift Code, audit, and idempotency records after restore.                                                                                                                     |
| Migration rollback               | External requirement         | Review every Drizzle migration for reversibility or forward-fix strategy and test rollback/restore in a staging database before production.                                                                                                                 |
| Deployment rollback              | External requirement         | Keep the previous application artifact and configuration version available; define when to halt payouts and how to roll back without replaying economic operations.                                                                                         |
| Secret rotation                  | External requirement         | Rotate database, Redis, provider, JWT, and payout-signer credentials through a secret manager. Never place signer keys or operational addresses in client configuration.                                                                                    |
| Incident response                | External requirement         | Define severity levels, owner escalation, payout freeze criteria, audit-log preservation, provider outage handling, and post-incident review.                                                                                                               |

## Money-moving operational gates

Before enabling campaign payouts, reward transfers, Gift Code fulfillment, or referral rewards in a target environment, operators must verify explicit treasury and signer configuration, chain and token registry state, database and Redis connectivity, provider/RPC health, audit-log writes, and transaction recovery behavior. Missing configuration must fail closed. A successful application health check is not sufficient evidence that a payout can be safely executed.

A deployment should also perform a controlled staging transfer for each enabled chain and token, independently verify the receipt and exact transfer event, exercise a timeout/recovery path, and confirm that a duplicate request does not create a second economic operation. Test funds and staging recipients must be used for this exercise.

## Operational limitations

The repository does not itself prove that backups, restores, secret rotation, incident response, or physical-device QA have been completed. Those remain explicit release-owner requirements. The controlled-beta decision must therefore remain distinct from unrestricted production authorization.

## Railway staging and Android physical-device QA preparation

The current backend is MySQL/TiDB-based (`drizzle.config.ts` uses the MySQL dialect and `server/db.ts` uses `mysql2`). A Railway PostgreSQL service is therefore not compatible with this repository without a separately approved database-architecture migration. The staging operator must provision a compatible MySQL/TiDB database and Redis service, set the Railway build command to `npm run build`, the start command to `npm run start`, the pre-deploy command to `npm run db:push`, and the deployment healthcheck to `/readyz`. `/healthz` is process liveness only; `/readyz` verifies database readiness and can require Redis when `REDIS_REQUIRED=true`.

The exact environment matrix, migration risk table, provider classification, Android `VITE_PAXI_API_ORIGIN` procedure, and physical-device acceptance matrix are maintained in `RAILWAY_STAGING_ANDROID_QA_REPORT.md`. No Railway deployment, database migration, backup/restore rehearsal, real-device test, signed artifact, or live fee-attribution proof is claimed by this repository state.

## References within the repository

- `server/providers/health.ts` — provider health state and failure metrics.
- `server/resilience/circuitBreaker.ts` — circuit-breaker state transitions.
- `server/redis.ts` — Redis-safe wrappers and graceful degradation boundaries.
- `server/db.ts` — database acquisition and failure behavior.
- `server/adminAudit.ts` — application audit-event boundary.
- `server/campaigns/rewardEscrow.ts` — payout reservation, broadcast, recovery, and signer controls.
- `server/giftCodes/giftCodeService.ts` and `server/giftCodes/giftCodeRepository.ts` — Gift Code reservation and fulfillment state transitions.
- `PAXI_WALLET_README.md` — authoritative current capability and deployment summary.
- `TESTING_GUIDE.md` — current controlled-beta manual QA matrix.
