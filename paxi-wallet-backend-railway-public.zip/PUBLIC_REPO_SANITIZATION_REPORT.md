# Public Repository Sanitization Report
Generated for the PAXI Wallet Railway backend repository. This report intentionally records filenames and status only; it does not print secret values.

## Sensitive file names — PASS

## Generated/dependency directories — PASS

## Secret-pattern scan (`BEGIN[[:space:]]+([A-Z0-9_ ]+)?PRIVATE KEY`) — PASS

## Secret-pattern scan (`gh[pousr]_[A-Za-z0-9_]+`) — PASS

## Secret-pattern scan (`github_pat_[A-Za-z0-9_]+`) — PASS

## Secret-pattern scan (`AKIA[0-9A-Z]{16}`) — PASS

## Secret-pattern scan (`sk-[A-Za-z0-9]{20,}`) — PASS

## Secret-pattern scan (`(PRIVATE|SEED|MNEMONIC|SIGNER|WALLET_KEY|SECRET)[^[:cntrl:]]{0,80}0x[a-fA-F0-9]{64}`) — PASS

## Secret-pattern scan (`Bearer[[:space:]]+[A-Za-z0-9._-]{20,}`) — PASS

## Secret-pattern scan (`mysql(s)?://[^[:space:]]+:[^[:space:]@]+@`) — PASS

## Client-visible secret-like variable scan — PASS

## Overall status — PASS
