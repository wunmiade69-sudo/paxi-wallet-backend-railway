# PAXI Wallet — Railway Staging and Android Physical-Device QA Preparation

**Status:** Staging and controlled-device-QA preparation only. This document does not claim that Railway infrastructure, a staging database, Redis, a real Android device, live transactions, or a signed store artifact has been verified.

**Active-workspace finding:** The current repository contains the backend and staging preparation work, but it does **not** currently contain `capacitor.config.ts`, `android/`, `client/src/lib/mobileRuntime.ts`, or `client/src/lib/nativeDevice.ts`. Android staging-build and physical-device QA are therefore blocked until the separately prepared Capacitor/Android source is restored or explicitly reattached. This report does not recreate that mobile project.

**Architecture constraint:** The current PAXI Wallet backend uses **MySQL/TiDB**, not PostgreSQL. `drizzle.config.ts` declares the MySQL dialect, `server/db.ts` uses `mysql2` and `drizzle-orm/mysql2`, and the migrations contain MySQL-specific DDL such as `AUTO_INCREMENT`, MySQL enums, `ALTER TABLE ... MODIFY`, and MySQL partition/index syntax. A Railway PostgreSQL service must not be attached to this codebase without an explicitly approved database-architecture migration. The staging target must therefore be a compatible MySQL/TiDB service or an equivalent managed MySQL-compatible provider.

## 1. Railway staging status

No Railway project was provisioned or modified in this sandbox. No staging `DATABASE_URL`, `REDIS_URL`, provider credentials, OAuth configuration, or public backend domain was supplied. The commands below are the exact repository-side procedure to apply after the release owner creates a **staging** environment and supplies compatible service credentials.

| Area                 | Current repository evidence                                                                             | Staging status                                         |
| -------------------- | ------------------------------------------------------------------------------------------------------- | ------------------------------------------------------ |
| Database engine      | Drizzle MySQL dialect; `mysql2`; MySQL/TiDB connection URLs                                             | **Compatible service required; PostgreSQL is blocked** |
| Redis                | `ioredis`; optional cache/coordination layer; BullMQ queue connection                                   | **Not provisioned in this sandbox**                    |
| Server build         | `npm run build` creates the Vite client and bundles `server/_core/index.ts` to `dist/index.js`          | **Ready for Railway build**                            |
| Server start         | `npm run start` runs `NODE_ENV=production node dist/index.js`                                           | **Ready for Railway start**                            |
| Migration command    | `npm run db:push`, an idempotent script pipeline plus regression checks                                 | **Ready for staging only after backup/snapshot**       |
| Liveness             | `GET /healthz` returns process-level JSON success                                                       | **Use for basic liveness**                             |
| Readiness            | `GET /readyz` checks database connectivity and, when `REDIS_REQUIRED=true`, Redis `PING`                | **Use as deployment healthcheck**                      |
| Workers              | `ENABLE_WORKERS` defaults to enabled; workers consume the `paxi-market-data` BullMQ queue through Redis | **Enable only after Redis is available**               |
| Production readiness | No Railway execution, backup/restore rehearsal, secret rotation, or device QA completed                 | **Not production-ready**                               |

Railway injects the service `PORT`, and its deployment healthcheck expects the application to listen on that port and return HTTP 200 from the configured path.[1] The recommended staging healthcheck is `/readyz`, not `/healthz`, because `/readyz` tests the database and can test Redis when Redis is required. Railway healthchecks are deployment-time checks rather than continuous monitoring, so an external uptime/alerting control is still required.[1]

Railway Redis services expose `REDIS_URL` and related connection variables for services in the same project.[2] Railway variables are supplied to both build and runtime, can reference another service using `${{SERVICE_NAME.VAR}}`, and should be staged and reviewed before deployment.[3]

### Recommended Railway service settings

| Setting              | Recommended value                                                                                   | Rationale                                                                                             |
| -------------------- | --------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| Build command        | `npm run build`                                                                                     | Matches the repository’s production build.                                                            |
| Start command        | `npm run start`                                                                                     | Runs the bundled production server.                                                                   |
| Pre-deploy command   | `npm run db:push`                                                                                   | Uses the repository’s idempotent deployment pipeline; do not substitute raw Drizzle migration replay. |
| Healthcheck path     | `/readyz`                                                                                           | Verifies database readiness and optionally Redis readiness.                                           |
| Healthcheck timeout  | Railway default initially; increase only with evidence                                              | The application should fail fast on unavailable dependencies.                                         |
| `NODE_ENV`           | `production`                                                                                        | Activates production startup validation and static serving.                                           |
| `REDIS_REQUIRED`     | `true` for full staging with workers; `false` only for an intentionally degraded API-only rehearsal | Prevents silently declaring a full worker-backed environment ready without Redis.                     |
| `REDIS_TLS_REQUIRED` | `true` only when the supplied URL is `rediss://` and the provider requires TLS                      | The server rejects an inconsistent TLS setting.                                                       |
| `ENABLE_WORKERS`     | `true` only after Redis is provisioned and the staging queue is intentionally enabled               | Starts the market-data worker inside the service.                                                     |
| `TRUST_PROXY_HOPS`   | Set to the actual Railway proxy topology after validation                                           | Controls request-origin and secure-cookie behavior.                                                   |

### Exact staging verification commands

Run these from a controlled operator shell with the staging public origin in `STAGING_ORIGIN`. Do not paste a credential-bearing URL into logs or issue reports.

```bash
export STAGING_ORIGIN="https://<staging-public-domain>"

curl --fail-with-body --silent --show-error "$STAGING_ORIGIN/healthz"
curl --fail-with-body --silent --show-error "$STAGING_ORIGIN/readyz"

# Only if METRICS_TOKEN is intentionally configured and the endpoint is needed:
curl --fail-with-body --silent --show-error \
  -H "Authorization: Bearer $METRICS_TOKEN" \
  "$STAGING_ORIGIN/metrics"
```

Expected results are `200` from `/healthz` and `/readyz`, with `/readyz` reporting `database: true` and, when `REDIS_REQUIRED=true`, `redis: true`. A failed readiness response is a staging blocker; do not bypass it by switching to `/healthz` merely to make deployment green.

## 2. Database and migration safety

The authoritative repository procedure is `npm run db:push`. It runs the idempotent deployment scripts in the order recorded in `MIGRATION_RUNBOOK.md`, then runs `scripts/dbRegressionTest.ts`. Raw `drizzle-kit migrate` is intentionally disabled for this deployment state because the Drizzle journal is partial and replaying the raw chain could repeat partitioning or intermediate index operations.

Before any staging migration, create a provider-supported snapshot or logical backup and record the database engine/version, schema name, migration operator, timestamp, and target commit. For production, a verified restore path is mandatory before enabling money-moving operations. Never use reset, drop, truncate, or destructive migration commands against production.

| Migration/history item                       | Operation                                                                                                        | Safety classification                                 | Required staging control                                                                     |
| -------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `0000_careful_mongoose.sql`                  | Creates the base `users` table                                                                                   | Forward-only table creation                           | Confirm the target schema is empty or compatible before first install.                       |
| `0001_universal_asset_registry.sql`          | Creates chains/assets/metadata and foreign keys; references `tokenListings`                                      | Forward-only schema creation with dependency ordering | Confirm `tokenListings` exists in the deployed baseline before applying.                     |
| `0002_market_layer.sql`                      | Creates DEX, liquidity, market, and market-data tables plus indexes/FKs                                          | Forward-only schema creation                          | Check existing names and foreign-key compatibility.                                          |
| `0003_fix_market_pool_identity.sql`          | Drops one unique index and creates a replacement unique index                                                    | **Destructive index replacement; no row deletion**    | Check duplicate rows and schedule for a controlled maintenance window.                       |
| `0004_fix_cex_market_uniqueness.sql`         | Adds a unique index                                                                                              | May fail if existing rows violate uniqueness          | Run duplicate checks before applying.                                                        |
| `0005_case_sensitive_identifiers.sql`        | Changes `assets.identifier` to `utf8mb4_bin` using `ALTER TABLE ... MODIFY`                                      | **Potential table rewrite/lock; data-sensitive**      | Run `drizzle/checks/pre_migration_duplicate_check.sql` first and verify collation afterward. |
| `0006_campaign_reward_escrow.sql`            | Adds escrow columns and verification table/FK                                                                    | Forward-only                                          | Verify existing campaign rows remain valid.                                                  |
| `0007_campaign_reward_accounting.sql`        | Adds accounting fields and payout table/indexes/FKs                                                              | Forward-only                                          | Validate idempotency and transaction-hash indexes.                                           |
| `0008_campaign_payout_recovery.sql`          | Adds `recovery_required` status and broadcast lease                                                              | Forward-only enum/column change                       | Verify application and schema agree on status values.                                        |
| `0009_airdrop_distribution_verification.sql` | Adds recipient field and unique transaction-hash index; rewrites hashless `complete` rows to `approved`          | **Data-changing forward migration**                   | Snapshot first; audit affected rows and require explicit approval.                           |
| `0010_gift_code_multichain_fulfillment.sql`  | Adds fulfillment fields/FK and rewrites old credited rows to `not_required`                                      | **Data-changing forward migration**                   | Snapshot first; reconcile legacy redemption rows before/after.                               |
| `0011_support_tickets.sql`                   | Creates support tables with `IF NOT EXISTS`, FKs, and indexes                                                    | Forward-only, mostly idempotent                       | Verify status/priority and dedupe indexes.                                                   |
| Targeted deployment scripts                  | Apply provider provenance, partitioning, constraints, rewards, indexes, fee seeds, ledger, and regression checks | **Authoritative current procedure**                   | Run only `npm run db:push`; retain stdout/stderr as protected deployment evidence.           |

The migration procedure must be followed by the database regression suite. It verifies required tables, columns, partitioning, composite time-series keys, indexes, foreign keys, the consolidated `paxiSchemaDeployments` ledger, and the expected manual/idempotent deployment history. A successful process exit is required before the backend is considered staging-ready.

## 3. Environment-variable matrix

The matrix below is derived from `server/_core/env.ts`, `.env.example`, the documented Android API-origin requirement, and actual provider code. Blank optional values must remain blank rather than being replaced with fabricated credentials. The active repository currently lacks the Capacitor runtime files, so the native API-origin boundary remains a prerequisite for the restored Android source rather than a verified active file in this workspace.

### Public/client configuration

| Variable                            | Scope                | Requirement                                                  | Notes                                                                                     |
| ----------------------------------- | -------------------- | ------------------------------------------------------------ | ----------------------------------------------------------------------------------------- |
| `VITE_APP_ID`                       | Public build/runtime | Required for production server startup and OAuth integration | Not a secret.                                                                             |
| `VITE_PAXI_API_ORIGIN`              | Public Android build | **Required for native Android staging/production builds**    | Must be an HTTPS Railway backend origin; never localhost, `127.0.0.1`, or HTTP.           |
| `VITE_PAXI_TREASURY_ADDRESS`        | Public client        | Optional public EVM fee destination                          | Must match the server-owned address when configured; it is an address, not a private key. |
| `VITE_PAXI_SOLANA_TREASURY_ADDRESS` | Public client        | Optional public Solana fee destination                       | Leave blank until an actual Solana treasury is configured.                                |
| `VITE_PAXI_PUBLIC_URL`              | Public client        | Optional public referral/about origin                        | Must be HTTPS for staging/production.                                                     |
| `VITE_OAUTH_PORTAL_URL`             | Public client        | Required for the chosen OAuth portal flow                    | No credential belongs in the value.                                                       |
| `VITE_WC_ENABLED`                   | Public client        | `false` for the reviewed beta unless explicitly approved     | WalletConnect remains fail-closed.                                                        |
| `VITE_WC_PROJECT_ID`                | Public client        | Optional public project identifier                           | Not a private key; do not enable the integration without review.                          |

### Server-only secrets and runtime configuration

| Variable group              | Variables                                                                                                                                         | Staging rule                                                                                              |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| Database                    | `DATABASE_URL`, optional `DATABASE_READ_URL`/`DATABASE_REPLICA_URL`                                                                               | Compatible MySQL/TiDB URL only; never expose or log.                                                      |
| Redis                       | `REDIS_URL`, `REDIS_REQUIRED`, `REDIS_TLS_REQUIRED`                                                                                               | Prefer a private Railway Redis connection; use `rediss://` only when supplied.                            |
| Authentication              | `JWT_SECRET`, `OAUTH_SERVER_URL`, `OWNER_OPEN_ID`                                                                                                 | `JWT_SECRET` must be at least 32 characters in production.                                                |
| AI/Forge                    | `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY`                                                                                                | Server-only; used by PAXI AI, storage, image, voice, and server map helpers.                              |
| Storage                     | `S3_BUCKET`, `S3_REGION`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, optional `S3_ENDPOINT`                                                      | Server-only; configure only if support/storage routes are enabled.                                        |
| Treasury/reward fulfillment | `PAXI_TREASURY_ADDRESS`, `PAXI_REWARD_VAULT_ADDRESS`, `PAXI_REWARD_ESCROW_ADDRESS`, `PAXI_REWARD_DISTRIBUTOR_ADDRESS`                             | Addresses are configuration, but signer keys remain server-only.                                          |
| Payout signers              | `PAXI_PAYOUT_PRIVATE_KEY`, chain-specific payout private keys                                                                                     | Keep sealed in the deployment secret manager; do not enable real-money fulfillment in unverified staging. |
| Payout/RPC endpoints        | `PAXI_PAYOUT_RPC_URL`, `ETHEREUM_PAYOUT_RPC_URL`, `POLYGON_PAYOUT_RPC_URL`, `ARBITRUM_PAYOUT_RPC_URL`, `SOLANA_PAYOUT_RPC_URL`, `BITCOIN_RPC_URL` | Use staging/testnet endpoints and test funds for controlled transfers where supported.                    |
| Provider credentials        | `LIFI_API_KEY`, `BIRDEYE_API_KEY`, `DEXSCANNER_API_KEY`, `MORALIS_API_KEY`, optional `COINGECKO_API_KEY`                                          | Server-only and optional unless the corresponding provider is intentionally enabled.                      |
| Runtime controls            | `PORT`, `NODE_ENV`, `ENABLE_WORKERS`, `WORKER_CONCURRENCY`, `TRUST_PROXY_HOPS`, `DB_POOL_SIZE`, `DATABASE_SSL`, `METRICS_TOKEN`                   | Configure according to the staging topology; Railway supplies `PORT`.                                     |

No `GROQ_API_KEY` is consumed by the current application. The stale unreachable client map component that referenced `VITE_FRONTEND_FORGE_API_KEY`/`VITE_FRONTEND_FORGE_API_URL` has been removed, and those variables were removed from `.env.example`. The current client source therefore does not contain that obsolete direct provider-key path.

## 4. Provider audit

| Provider/integration | Status                                            | Credential                                                       | Current location and behavior                                                                                                                               | Failure behavior                                                                           |
| -------------------- | ------------------------------------------------- | ---------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| DexPaprika           | **Active**                                        | None in current adapter                                          | Registered market provider using public endpoints                                                                                                           | Provider errors are recorded and aggregation continues.                                    |
| DexScreener          | **Active**                                        | None in current adapter                                          | Registered market provider; also used by risk/analytics paths and some client public-data paths                                                             | Timeouts/circuit breakers and aggregation fallback.                                        |
| GeckoTerminal        | **Active**                                        | None                                                             | Registered public market provider                                                                                                                           | Empty/fallback result on failure.                                                          |
| CoinGecko            | **Active, optional credential**                   | `COINGECKO_API_KEY` server-only when supplied                    | Markets/search and provider adapter; public mode remains possible                                                                                           | Empty result or fallback to other price/market sources.                                    |
| Binance              | **Active public endpoint**                        | None in current code                                             | Server pricing/chart fallback and client public balance/chart pricing                                                                                       | Timeout/fallback to CoinGecko or other sources.                                            |
| Birdeye              | **Optional**                                      | `BIRDEYE_API_KEY` server-only                                    | Adapter exists but is disabled without a key                                                                                                                | Not selected until configured.                                                             |
| Moralis              | **Optional**                                      | `MORALIS_API_KEY` server-only                                    | Security intelligence adapter; returns no report when absent/unmapped                                                                                       | Fails closed/no provider result.                                                           |
| GoPlus               | **Active public security source**                 | No secret in current code                                        | Security checks use public endpoints; no GoPlus credential is placed in Vite variables                                                                      | Invalid/unavailable data is treated as unavailable, not fabricated as safe.                |
| DexScanner           | **Disabled by default**                           | Requires both `DEXSCANNER_API_BASE_URL` and `DEXSCANNER_API_KEY` | Explicit opt-in only; current code refuses to invent an undocumented endpoint                                                                               | Remains disabled when unset.                                                               |
| LI.FI                | **Active through server read-only proxy**         | `LIFI_API_KEY` server-only and optional                          | `/api/lifi-proxy` permits only `/quote` and `/status`, enforces `integrator=paxiwallet`, validates server-authoritative fee, and restricts supported chains | Input rejected or upstream failure returned without arbitrary proxying.                    |
| Groq                 | **Not implemented/disabled**                      | None                                                             | No `GROQ_API_KEY` or direct Groq API call exists                                                                                                            | Not applicable.                                                                            |
| PAXI AI              | **Active through server-side Forge architecture** | `BUILT_IN_FORGE_API_KEY` server-only                             | Support and AI flows use the server LLM wrapper and never require an Android/client provider key                                                            | Missing key produces a server configuration error; client receives no provider credential. |

### LI.FI separation of evidence

The repository proves the **code configuration** for the LI.FI proxy: the canonical integrator is `paxiwallet`, fee values are validated and server-authoritative, and only quote/status read-only resources are proxied. The repository does not prove **LI.FI partner-portal configuration**, account approval, revenue attribution, or a live fee transaction reaching the treasury. Those are external deployment-owner checks. No claim is made that the treasury receives LI.FI fees until a controlled staging transaction and independent on-chain verification are completed.

## 5. Treasury and wallet-key boundary

Treasury destinations are public addresses. The server keeps the authoritative fee/reward destination configuration, while selected public Vite addresses are used for client-side routing or display. No treasury private key is required merely to receive fees. Payout private keys are distinct server-only signer credentials used only for automated reward fulfillment and must remain sealed outside source, Vite configuration, Android assets, iOS bundles, URLs, logs, analytics, and support content.

The active repository has no Android source/archive to inspect or package in this staging-preparation pass. When the separately prepared mobile project is restored, its hygiene rules must exclude `android/local.properties`, build output, `.gradle`, keystores, signing properties, real `.env` files, and other local machine state. A signed APK/AAB must be produced later by the release owner using external credentials; no fake signature is generated here.

## 6. Android staging API connection

The intended Android staging build must receive the following public build variable:

```text
VITE_PAXI_API_ORIGIN=https://<staging-railway-public-domain>
```

The active repository does not currently contain the Capacitor runtime boundary or Android project, so the following is a **restoration procedure**, not an executed command sequence in this workspace:

```bash
export VITE_PAXI_API_ORIGIN="https://<staging-railway-public-domain>"
npm run build
npx cap sync android
JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64 \
ANDROID_HOME=/opt/android-sdk \
ANDROID_SDK_ROOT=/opt/android-sdk \
./android/gradlew -p android assembleDebug --no-daemon
```

After the mobile source is restored, the release owner must verify authentication, wallet-related API calls, token discovery, market data, security services, PAXI AI, support, and the LI.FI proxy against the staging origin. A successful APK build proves only packaging/build correctness; it does not prove that staging credentials, OAuth redirect configuration, provider quotas, or live backend routes work on a device.

## 7. Physical Android QA status and procedure

No real Android device is connected in this sandbox. The following matrix is therefore **pending**, not passed. Device QA must use a staging backend, test wallets, test funds, and non-production recipients.

| Area             | Required cases                                                                                                                   | Evidence required                                                                         |
| ---------------- | -------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Wallet lifecycle | Create, recovery phrase display, recovery, incorrect recovery, PIN, biometric if supported, force close, restart, device restart | Screen recording/log plus wallet recovery result; never record or submit the seed phrase. |
| Send             | Native token, ERC-20, invalid address, insufficient balance/gas, user rejection, success, confirmation                           | Blockchain explorer link and app status after restart; no fabricated success.             |
| Swap             | Token selection, quote, slippage, fee display, approval, rejection, success/failure, expired quote, restart during swap          | Quote/transaction identifiers and post-restart status.                                    |
| Bridge           | Source/destination, quote, route, fee, signing, source/destination status, restart, failed/delayed route                         | LI.FI status and chain explorer evidence.                                                 |
| Discovery        | Name/symbol/contract search, chain filter, duplicates, unknown/suspicious token                                                  | API responses and security-status evidence.                                               |
| PAXI AI          | Request, server response, provider failure, no API-key exposure                                                                  | Redacted network/log evidence; no provider secret in app or device storage.               |
| Support          | Create/view/escalate ticket; no wallet secret exposure                                                                           | Redacted ticket and audit evidence.                                                       |
| QR               | Current RC renders receive QR codes; camera scan, invalid/malicious QR, permission denial remain **not implemented**             | Record as a release blocker if scanning is required for the beta scope.                   |
| Network          | Wi-Fi, mobile data, offline, reconnect, API/RPC timeout                                                                          | App behavior and server logs with secrets redacted.                                       |

### Critical wallet lifecycle test

The release owner must create a staging test wallet, fund it with a small test amount, force-close and restart the application, perform a small Send, kill the app during transaction monitoring, reopen it, and verify the transaction status from the blockchain. The same lifecycle should be repeated for Swap and Bridge only where safe. The acceptance criterion is that the app recovers from the actual chain status and never fabricates a confirmation.

## 8. Release blockers

| Blocker                                                                 | Impact                                                                                          | Resolution owner/action                                                                        |
| ----------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| No compatible Railway MySQL/TiDB service provisioned                    | Backend cannot connect to PostgreSQL as requested without an architecture change                | Provision compatible MySQL/TiDB staging service or approve a separate migration project.       |
| No staging `DATABASE_URL`/`REDIS_URL`/OAuth/provider variables supplied | Railway deployment and readiness cannot be executed                                             | Create staging environment, seal secrets, and configure the matrix above.                      |
| No database backup/restore rehearsal                                    | Migration and money-moving operations are not release-safe                                      | Snapshot staging, test restore, then run `npm run db:push` and regression verification.        |
| No physical Android device                                              | Native clipboard/share/browser, lifecycle, network, OAuth, and transaction QA remain unverified | Attach a controlled Android device and execute the matrix.                                     |
| No camera QR scanner in frozen RC                                       | Scan-based flows cannot be accepted as working                                                  | Keep as an explicit limitation or approve a separate feature task; do not claim scan QA.       |
| No signed release credentials                                           | Store APK/AAB cannot be produced                                                                | Release owner supplies external keystore/signing properties; never commit them.                |
| LI.FI partner/live fee evidence absent                                  | Revenue attribution and treasury receipt remain unverified                                      | Complete partner portal configuration review and controlled on-chain verification.             |
| Dependency audit requires separate acceptance                           | Current package audit must be reviewed before production authorization                          | Review the latest `npm audit --omit=dev` result; do not apply breaking upgrades automatically. |

## 9. Repository-side validation evidence

The active backend/web workspace was validated after the staging-preparation changes. The results below do not substitute for Railway execution or physical-device QA.

| Gate or inspection                | Result                                                                                                                                                                        |
| --------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run check`                   | Passed, exit 0.                                                                                                                                                               |
| `npm test -- --run`               | Passed: **56 test files and 218 tests**. The new `server/railwayStagingSecurity.test.ts` contributed 5 passing tests.                                                         |
| `npm run lint`                    | Passed, exit 0.                                                                                                                                                               |
| `npm run build`                   | Passed, exit 0. Existing large-wallet-chunk and dynamic/static-import warnings remain non-blocking and documented.                                                            |
| `npm audit --omit=dev`            | Exit 1 with **21 vulnerabilities: 7 low, 11 moderate, 3 high**. No forced breaking upgrade was applied.                                                                       |
| Built web-bundle secret-name scan | Clean for the scanned server-only credential names and stale client Forge-key aliases.                                                                                        |
| Stale client map path             | `client/src/components/Map.tsx` is absent and the stale client Forge-key variables are absent from `.env.example`.                                                            |
| Capacitor/Android validation      | **Blocked in this active workspace** because `capacitor.config.ts`, `android/`, and the native runtime bridge files are absent. No Android sync/build result is claimed here. |

## 10. Required evidence before any production claim

Before changing the status beyond staging/device-QA preparation, retain protected evidence for the compatible database provisioning, Redis connectivity, migration backup and regression output, `/healthz` and `/readyz`, all required environment variables without secret values, provider health and quota checks, OAuth redirect verification, a real-device QA matrix, controlled Send/Swap/Bridge receipts, Android bundle secret scans, signed artifact checksums, rollback instructions, and an approved release-owner decision. None of those external staging/device assertions is claimed by this document.

## References

[1]: https://docs.railway.com/deployments/healthchecks "Railway — Healthchecks"
[2]: https://docs.railway.com/databases/redis "Railway — Redis"
[3]: https://docs.railway.com/variables "Railway — Using Variables"

## Repository sources

The repository-side evidence for this report is contained in `drizzle.config.ts`, `server/db.ts`, `server/redis.ts`, `server/_core/index.ts`, `server/_core/env.ts`, `server/_core/lifiProxy.ts`, `server/_core/llm.ts`, `server/providers/index.ts`, `MIGRATION_RUNBOOK.md`, `scripts/dbRegressionTest.ts`, `.env.example`, and `server/railwayStagingSecurity.test.ts`. The absence of `capacitor.config.ts`, `client/src/lib/mobileRuntime.ts`, `client/src/lib/nativeDevice.ts`, and `android/` is an explicit active-workspace blocker recorded above.

**Prepared by:** Manus AI  
**Scope:** Railway staging preparation and Android physical-device-QA preparation only  
**Production claim:** None

## Provider API verification addendum — 2026-08-19

Official provider documentation was checked before packaging. Public base URLs and authentication requirements are recorded below; account-issued API-key values cannot be retrieved or inferred from public web pages and remain deployment-owner inputs.

| Provider          | Current code status                       | Verified public base URL or endpoint                                                                              | Credential status and release action                                                                                                                                              |
| ----------------- | ----------------------------------------- | ----------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| DexPaprika        | Registered and keyless adapter            | `https://api.dexpaprika.com`                                                                                      | Public/free access is documented, subject to plan limits. Continue using the current adapter.                                                                                     |
| DexScreener       | Active public market adapter              | `https://api.dexscreener.com`                                                                                     | No key is required for the public endpoints used by the current adapter. Preserve unchanged.                                                                                      |
| GeckoTerminal     | Registered and keyless adapter            | `https://api.geckoterminal.com/api/v2`                                                                            | Public API path is documented. Continue using the current adapter subject to rate limits.                                                                                         |
| CoinGecko         | Registered adapter                        | `https://api.coingecko.com/api/v3`                                                                                | `COINGECKO_API_KEY` is optional in the current code and used only when supplied. Do not fabricate a value.                                                                        |
| Birdeye           | Registered but fail-closed without key    | `https://public-api.birdeye.so` in the current template                                                           | `BIRDEYE_API_KEY` is account-issued and required by Birdeye authentication. Supply through Railway secrets only if this provider is intentionally enabled.                        |
| DexScanner        | Registered but intentionally opt-in       | No authoritative canonical endpoint found                                                                         | Keep `DEXSCANNER_API_BASE_URL` and `DEXSCANNER_API_KEY` blank. Do not enable an unrelated service under this name.                                                                |
| LI.FI             | Server proxy integration                  | Official REST API documented at LI.FI; normal access is keyless, with `x-lifi-api-key` optional for higher limits | Keep `LIFI_API_KEY` server-only. Do not place it in the web or Android bundle.                                                                                                    |
| Binance           | Read-only market-data paths               | `https://data-api.binance.vision` for public market data; `https://api.binance.com` is the general Spot REST base | No private trading key is needed for public market data. Never add trading credentials for the wallet’s read-only path.                                                           |
| Jupiter           | Client Solana swap integration            | Current official Swap API: `https://api.jup.ag/swap/v2`                                                           | Current official docs state `x-api-key` is required. The existing adapter’s older/public route must be reviewed before adding a new key; do not expose a Jupiter key client-side. |
| GoPlus            | Server-side security lookup               | Official API documentation was located; the commonly documented REST host is `https://api.gopluslabs.io`          | No account key was found in the active template. Keep any future credential server-only and do not treat public documentation as a key source.                                    |
| Moralis           | Server-side security integration          | Official API documentation located; endpoint selection remains integration-specific                               | `MORALIS_API_KEY` is absent from the active runtime template and must be supplied by the account owner if this optional integration is enabled.                                   |
| THORChain/Midgard | Client read-only quote/status integration | Official developer documentation is the source of truth for current endpoints                                     | No private credential should be added for read-only status/quote calls; signer material remains outside client code.                                                              |

### Current credential finding

The active checkout contains no verified runtime API-key values for the optional keyed providers. The local audit showed only template entries for `BIRDEYE_API_KEY`, `DEXSCANNER_API_KEY`, `MORALIS_API_KEY`, `LIFI_API_KEY`, and `COINGECKO_API_KEY`; values were not printed or copied. The user’s instruction to keep the current active DEX configuration is satisfied by preserving the keyless DexScreener adapter and its official public base URL.

Before final packaging, the release owner must provide only the missing provider credentials that are actually required for the intended staging deployment, preferably by entering them directly into Railway’s encrypted variable store. Do not send private keys, seed phrases, payout signer keys, database passwords, or exchange trading secrets in chat. No key can be safely discovered online.

### References

[1]: https://docs.dexscreener.com/api/reference "DEX Screener API Reference"
[2]: https://docs.coingecko.com/ "CoinGecko API Documentation"
[3]: https://docs.coingecko.com/docs/keyless-public-api "CoinGecko Keyless Public API"
[4]: https://api.geckoterminal.com/docs/index.html "GeckoTerminal API Documentation"
[5]: https://docs.dexpaprika.com/api-reference/introduction "DexPaprika API Introduction"
[6]: https://docs.birdeye.so/docs/authentication-api-keys "Birdeye Authentication and API Keys"
[7]: https://docs.li.fi/api-reference/introduction "LI.FI API Introduction"
[8]: https://developers.binance.com/en/docs/products/spot/rest-api "Binance Spot REST API"
[9]: https://developers.jup.ag/docs/swap "Jupiter Swap API"
[10]: https://docs.gopluslabs.io/reference/api-overview "GoPlus Security API Overview"
[11]: https://docs.moralis.com/ "Moralis Documentation"
[12]: https://docs.thorchain.org/ "THORChain Documentation"
[13]: https://dev.thorchain.org/ "THORChain Developer Documentation"
