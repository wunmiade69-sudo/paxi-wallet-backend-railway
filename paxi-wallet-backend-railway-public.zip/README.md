# PAXI Wallet Backend — Railway Staging

This repository contains the **PAXI Wallet backend and web-RC source prepared for Railway staging inspection**. It does not contain private API keys, wallet seed phrases, payout signer keys, database passwords, Railway tokens, Android signing credentials, dependencies, or generated build output.

## Deployment boundary

The current backend uses **Drizzle ORM with MySQL/TiDB and `mysql2`**. Attach a MySQL-compatible database service for staging. Do not attach PostgreSQL without an explicitly approved database-architecture migration.

The recommended Railway service commands are:

```text
Build command:     npm run build
Start command:     npm run start
Pre-deploy command: npm run db:push
Healthcheck path:  /readyz
```

Run `npm run db:push` only against an intentionally disposable staging database after taking a provider-supported snapshot or backup. The repository’s migration runbook and regression checks are authoritative; do not substitute an unreviewed raw migration replay or reset command.

Redis is required for the full worker-backed staging environment. Configure `REDIS_URL`, set `REDIS_REQUIRED=true`, and set `ENABLE_WORKERS=true` only after Redis connectivity has been confirmed. The readiness endpoint must report database readiness and Redis readiness when Redis is required.

## Railway variables

Add secrets directly in **Railway → Service → Variables**. Do not commit them to GitHub, place them in `.env`, expose them through `VITE_*`, or add them to an Android build.

Typical server-only variables include:

```text
DATABASE_URL
REDIS_URL
LIFI_API_KEY
BIRDEYE_API_KEY
COINGECKO_API_KEY
MORALIS_API_KEY
DEXSCANNER_API_KEY
PAYOUT_SIGNER_PRIVATE_KEY
```

Only configure a provider when its integration is intentionally enabled and its account-issued credential is available. The active DexScreener public adapter does not require a private API key. Do not use exchange trading credentials for the wallet’s read-only market-data paths.

Public configuration such as `VITE_APP_ID`, public treasury addresses, and an HTTPS native API origin may be represented in deployment configuration, but private keys and provider secrets must remain server-side.

## Verification

After deployment, verify the public staging origin without printing credential-bearing URLs:

```bash
export STAGING_ORIGIN="https://<staging-public-domain>"
curl --fail-with-body --silent --show-error "$STAGING_ORIGIN/healthz"
curl --fail-with-body --silent --show-error "$STAGING_ORIGIN/readyz"
```

`/readyz` is the required readiness gate for a full staging environment. Do not bypass a failed readiness response by using `/healthz` alone.

## Local development

Use npm:

```bash
npm install
npm run check
npm test -- --run
npm run lint
npm run build
```

Review `RAILWAY_STAGING_ANDROID_QA_REPORT.md`, `MIGRATION_RUNBOOK.md`, `PRODUCTION_OPERATIONS.md`, and `PAXI_WALLET_RELEASE_CANDIDATE_REPORT.md` before any staging deployment.

## Public-repository safety

This public repository is intentionally sanitized. Before every push, scan for real environment files, private keys, seed phrases, bearer tokens, database credentials, Android keystores, generated output, and local machine configuration. Never add a secret merely because a provider requires one; add it only to Railway’s encrypted variable store.
