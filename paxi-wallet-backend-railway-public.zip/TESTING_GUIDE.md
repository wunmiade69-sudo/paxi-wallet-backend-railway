# PAXI Wallet Beta v0.1 - Testing Guide & Feedback

## 🧪 Testing Instructions

### Setup
1. Clone or extract the project
2. Run `npm install` to install dependencies
3. Run `npm run dev` to start the development server
4. Open `http://localhost:3000` in your browser

### Test Scenarios

#### 1. Onboarding Flow - Create New Wallet
**Steps:**
1. App loads with Splash Screen (3.5 seconds)
2. Click anywhere or wait to proceed to Welcome Screen
3. Click "Create Wallet" button
4. Review the generated 12-word recovery phrase
5. Click "Copy Phrase" to copy to clipboard
6. Click "I Saved My Phrase" to continue
7. Verify recovery phrase by selecting words in correct order
8. Click "Verify Phrase" when all 12 words are selected
9. Set a 6-digit PIN (e.g., 123456)
10. Confirm PIN by entering the same 6 digits
11. Optional: Enable biometric authentication (if supported)
12. Dashboard loads with portfolio information

**Expected Results:**
- ✅ Splash screen displays PAXI branding
- ✅ Welcome screen has two prominent buttons
- ✅ Recovery phrase is displayed in a grid
- ✅ Copy button works (toast notification appears)
- ✅ Verification requires selecting all 12 words in order
- ✅ PIN setup shows 6 circles that fill as you type
- ✅ Biometric setup shows device support status
- ✅ Dashboard displays after successful setup

#### 2. Onboarding Flow - Import Wallet
**Steps:**
1. From Welcome Screen, click "Import Wallet"
2. Enter a 12-word recovery phrase (e.g., "witch collapse practice feed shame open despair creek road again ice least")
3. Click "Import Wallet"
4. Set a 6-digit PIN
5. Confirm PIN
6. Dashboard loads

**Expected Results:**
- ✅ Import screen has textarea for phrase input
- ✅ Validation shows error if phrase is invalid
- ✅ Successful import proceeds to PIN setup
- ✅ Dashboard displays imported wallet

#### 3. Dashboard - Portfolio Overview
**Steps:**
1. From Dashboard, observe the top section
2. Check total portfolio value calculation
3. Look for 24h change percentage
4. Review wallet address display

**Expected Results:**
- ✅ Portfolio value shows sum of all assets
- ✅ 24h change shows +2.34% (demo data)
- ✅ Wallet address is displayed and can be copied
- ✅ Copy button shows checkmark when clicked

#### 4. Dashboard - Assets Tab
**Steps:**
1. Ensure "Assets" tab is selected (default)
2. Scroll through the asset list
3. Check each asset displays: icon, name, symbol, balance, value, 24h change

**Expected Results:**
- ✅ All 7 assets are displayed (PAXI, WPAXI, BNB, ETH, BTC, SOL, USDT)
- ✅ Each asset shows correct balance and USD value
- ✅ Positive changes are green, negative are red
- ✅ Assets are clickable (for future functionality)

#### 5. Dashboard - History Tab
**Steps:**
1. Click "History" tab
2. Review transaction list
3. Check transaction details (type, amount, date, status)

**Expected Results:**
- ✅ History tab shows recent transactions
- ✅ Send transactions show with ↑ icon and red color
- ✅ Receive transactions show with ↓ icon and green color
- ✅ All transactions show "completed" status

#### 6. Dashboard - Send Modal
**Steps:**
1. Click "Send" button in quick actions
2. Select an asset from dropdown
3. Enter recipient address (e.g., "0x1234567890abcdef")
4. Enter amount (e.g., "10")
5. Click "Send Now"
6. Verify toast notification

**Expected Results:**
- ✅ Send modal opens from bottom with animation
- ✅ Asset dropdown shows all 7 supported tokens
- ✅ Address and amount inputs accept text
- ✅ Send button is clickable
- ✅ Success toast appears
- ✅ Modal closes after sending

#### 7. Dashboard - Receive Modal
**Steps:**
1. Click "Receive" button in quick actions
2. Review wallet address displayed
3. Click copy button to copy address
4. View QR code placeholder
5. Click "Done" to close

**Expected Results:**
- ✅ Receive modal opens from bottom
- ✅ Wallet address is displayed
- ✅ Copy button works and shows checkmark
- ✅ QR code placeholder is visible
- ✅ Done button closes the modal

#### 8. Dashboard - Settings
**Steps:**
1. Click settings icon (⚙️) in header
2. Review wallet options (Backup, Export)
3. Review preferences (Dark Mode, Language, Currency)
4. Click "Logout"
5. Confirm app returns to Welcome Screen

**Expected Results:**
- ✅ Settings modal opens from bottom
- ✅ All menu items are visible
- ✅ Logout button is red and prominent
- ✅ Logout clears localStorage and resets app
- ✅ App returns to splash screen on reload

#### 9. UI/UX Testing
**Steps:**
1. Test on different screen sizes (mobile, tablet, desktop)
2. Check animations and transitions
3. Verify color scheme (black, gold, white)
4. Test glassmorphism effects
5. Check all buttons are clickable

**Expected Results:**
- ✅ Layout is responsive and mobile-first
- ✅ Animations are smooth and not jarring
- ✅ Gold accent color is prominent
- ✅ Glassmorphism effects are visible
- ✅ All interactive elements have hover states

#### 10. Error Handling
**Steps:**
1. Try importing invalid recovery phrase
2. Try entering mismatched PINs
3. Try verifying phrase in wrong order
4. Check error messages

**Expected Results:**
- ✅ Invalid phrase shows error message
- ✅ Mismatched PINs show error
- ✅ Wrong phrase order shows error
- ✅ All errors are clear and actionable

## 📊 Performance Metrics

### Target Metrics
- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Cumulative Layout Shift**: < 0.1
- **Time to Interactive**: < 3s

### Optimization Tips
- Enable gzip compression
- Minify CSS and JavaScript
- Use code splitting for routes
- Optimize images
- Cache assets with service workers

## 🎯 Quality Checklist

### Functionality
- [ ] All onboarding screens work correctly
- [ ] Dashboard displays all information
- [ ] Send/Receive modals function properly
- [ ] Settings work as expected
- [ ] Logout clears data and resets app

### UI/UX
- [ ] Design is consistent throughout
- [ ] Colors match brand guidelines
- [ ] Animations are smooth and purposeful
- [ ] Responsive design works on all devices
- [ ] Accessibility is good (contrast, sizing)

### Security
- [ ] Recovery phrase is never logged
- [ ] PIN is encrypted before storage
- [ ] Sensitive data is not exposed in console
- [ ] No hardcoded secrets in code
- [ ] HTTPS is used in production

### Performance
- [ ] App loads quickly
- [ ] No unnecessary re-renders
- [ ] Animations don't cause jank
- [ ] Memory usage is reasonable
- [ ] Bundle size is optimized

### Compatibility
- [ ] Works on Chrome/Chromium
- [ ] Works on Firefox
- [ ] Works on Safari
- [ ] Works on Edge
- [ ] Mobile browsers work correctly

## 🐛 Bug Report Template

```markdown
### Bug Title
[Brief description]

### Steps to Reproduce
1. [First step]
2. [Second step]
3. [etc.]

### Expected Behavior
[What should happen]

### Actual Behavior
[What actually happens]

### Screenshots
[If applicable]

### Environment
- Browser: [e.g., Chrome 120]
- OS: [e.g., macOS 14.1]
- Device: [e.g., MacBook Pro]

### Additional Context
[Any other relevant information]
```

## 💡 Feature Feedback Template

```markdown
### Feature Title
[Brief description]

### Use Case
[Why this feature is needed]

### Proposed Solution
[How it should work]

### Alternative Solutions
[Other approaches]

### Priority
[ ] Low [ ] Medium [ ] High [ ] Critical

### Additional Context
[Any other relevant information]
```

## 📈 Success Criteria for Beta v0.1

- ✅ All onboarding screens implemented and tested
- ✅ Dashboard fully functional with all tabs
- ✅ Send/Receive modals working
- ✅ Settings accessible
- ✅ Professional UI with glassmorphism
- ✅ Smooth animations throughout
- ✅ Mobile-responsive design
- ✅ localStorage persistence working
- ✅ No console errors
- ✅ Performance acceptable

## 🚀 Next Testing Phases

### Beta v0.2 Testing
- WPAXI Mining functionality
- Referral system
- Daily check-in rewards
- Task system
- Push notifications

### Beta v0.3 Testing
- Staking functionality
- VIP system
- Merchant center
- Payment receiving

### Beta v0.4 Testing
- KYC integration
- Admin panel
- Firebase integration

## 📞 Feedback Channels

- GitHub Issues: For bug reports and feature requests
- Email: [support@paxi.wallet]
- Discord: [Community server link]
- Twitter: [@PAXIWallet]

---

**Testing Version**: 0.1.0  
**Last Updated**: July 2026  
**Status**: Ready for Beta Testing
