# PAXI Wallet — Controlled-Beta Testing Guide

This guide describes the current candidate. It supersedes the original v0.1 demo checklist. It does **not** claim that physical-device testing has been completed; the device matrix below is an execution plan for the release owner.

## Automated release checks

Run from the repository root with npm:

```bash
npm install
npm run check
npm test -- --run
npm run build
npm run lint
npm audit --omit=dev
```

Expected interpretation:

| Command                | Meaning                                                                                                 |
| ---------------------- | ------------------------------------------------------------------------------------------------------- |
| `npm run check`        | TypeScript integration check. Any non-zero result blocks release.                                       |
| `npm test -- --run`    | Vitest regression suite. Record exact file and test counts.                                             |
| `npm run build`        | Vite client build plus bundled Express server. Build warnings must be reviewed, not hidden.             |
| `npm run lint`         | Scoped Prettier gate over the current release-pass files. It is not repository-wide lint.               |
| `npm audit --omit=dev` | Production dependency inventory. A non-zero result requires explicit disposition in the release report. |

Focused correction-pass tests include:

```bash
npx vitest run \
  server/riskEngine.test.ts \
  client/src/lib/wallet/walletconnect.test.ts \
  client/src/lib/wallet/txHistory.test.ts \
  client/src/lib/wallet/fiat.test.ts \
  client/src/lib/wallet/slippage.test.ts \
  client/src/lib/wallet/bridge.test.ts \
  client/src/lib/wallet/thorchain.test.ts
```

## Manual QA matrix

Execute the following matrix on **Android low-end**, **Android mid-range**, **Android flagship**, **iPhone**, and **desktop Chromium/Firefox/Safari where available**. Record device model, OS/browser version, build identifier, network condition, result, and evidence. Do not mark a row passed from a sandbox-only check.

| Journey                                                                | Android low-end  | Android mid-range | Android flagship | iPhone           | Desktop          |
| ---------------------------------------------------------------------- | ---------------- | ----------------- | ---------------- | ---------------- | ---------------- |
| Create wallet and display recovery phrase                              | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Recovery/import with checksum validation                               | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Lock, unlock, wrong PIN, and timeout                                   | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Biometric enrollment and unlock                                        | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Backup phrase reveal and encrypted export                              | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| EVM send: recipient, amount, gas, security, sign, pending, result      | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Bitcoin send and UTXO/fee failure states                               | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Solana native/SPL send and confirmation recovery                       | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Receive: chain selection, QR, copy, wrong-network warning              | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Swap: quote, slippage, approval, security, signature, pending, failure | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Bridge: supported route, unsupported route, fee, status, failure       | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| History: submitted, pending, confirmed/finalized, failed, unknown      | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| PAXI Shield: clean, warning, dangerous, unknown, approval risk         | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| WalletConnect disabled/unconfigured state                              | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Referral, rewards, and Gift Code states                                | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Discover external-link handling and unsupported dApp expectations      | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Settings: currency, theme, language, lock, remove wallet               | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Offline/reconnect and provider failure recovery                        | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| Background/resume while a transaction is pending                       | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |
| App/browser termination during a transaction                           | Not yet executed | Not yet executed  | Not yet executed | Not yet executed | Not yet executed |

## Sensitive-action acceptance criteria

Every send, swap, bridge, payout, reward, and signing confirmation must make the following visible before confirmation:

- **What:** operation, token, contract/function or transaction type where available.
- **Where:** recipient, spender, bridge destination, or payout destination.
- **How much:** token amount, native value, and any change/fee impact.
- **Network:** source and destination network, chain ID where relevant.
- **Cost:** gas, network fee, provider fee, wallet fee, and slippage where applicable.
- **Risk:** security result, approval risk, stale/unknown data, and simulation limitation.
- **What happens next:** signing, broadcast, pending/recovery, confirmation, or failure behavior.

No request should be described as simulated when it was not simulated. No submitted transaction should be shown as successful until the relevant chain-specific confirmation/finality rule has been satisfied.

## Failure and recovery scenarios

The release owner must explicitly test RPC timeout after broadcast, duplicate submission, nonce collision or replacement, dropped transactions, bridge failure, swap revert, payout retry, worker restart during payout, Redis unavailability, database retry, and two concurrent Gift Code or reward-claim requests. The required invariant is:

> One economic action must not produce two economic outcomes.

Capture transaction hashes, audit-log entries, database state, and user-visible status for each recovery case. Do not release a reservation merely because a confirmation request timed out when a broadcast hash may exist.

## Evidence and sign-off

For each device and journey, attach screenshots or screen recordings only when they do not expose seed phrases, private keys, PINs, API keys, or personal data. Record failures as failures. A beta decision may be **BETA READY WITH KNOWN SECURITY ACCEPTANCE** only when all blockers are explicitly documented with reachability, compensating controls, and an upgrade or remediation plan.

## Post-beta directive focused QA

The following checks cover the newly implemented discovery and support surfaces. They are automated where indicated, but their device/browser status remains **Not yet executed** until a release owner runs them on the target matrix.

| Journey                                                                   | Expected result                                                                                                                                                                                                                                   |
| ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Search by token name, symbol, native alias, EVM contract, and Solana mint | Results use canonical `chainId:tokenStandard:contractAddress` identity; EVM ERC-20/BEP-20 and Solana SPL/native standards remain distinct; exact address matches rank first; unsupported or malformed addresses do not produce fabricated tokens. |
| Provider partial failure during discovery                                 | Available providers still produce results; failed providers are represented through freshness/confidence metadata and do not crash the search.                                                                                                    |
| Discovery result with missing price, volume, market cap, logo, or chart   | The UI shows `—`, `unknown`, or an unavailable state rather than zero, a made-up logo, or a false chart.                                                                                                                                          |
| Solana swap with missing treasury configuration                           | Quote and confirmation review show **Configuration required**; wallet fee is `0` and no fee destination or silent redirect is used. Network and route fees remain disclosed.                                                                      |
| Canonical token detail                                                    | Chain, contract, explorer, copy action, trust/security, freshness, liquidity, and unknown-data states are visible; unsupported wallet import is unavailable.                                                                                      |
| Help & Support AI chat                                                    | Uses the protected server support procedure and documented PAXI capability boundaries; it cannot sign, approve, send, change settings, or bypass WalletConnect.                                                                                   |
| Recovery phrase/private key/PIN/password in support text or diagnostics   | Request is rejected before persistence or LLM invocation, with clear anti-phishing guidance.                                                                                                                                                      |
| Public-address transaction diagnostics                                    | Only allowlisted public fields are forwarded; no seed phrase, private key, PIN, password, API key, or signer data is accepted.                                                                                                                    |
| Human escalation duplicate submission                                     | Reusing the same client idempotency key returns one ticket and one initial message, not duplicate support work.                                                                                                                                   |
| User ticket list/detail                                                   | A user sees only tickets keyed to their authenticated identity; another user cannot read or mutate the ticket.                                                                                                                                    |
| Admin ticket operations                                                   | Only the existing authorized admin procedure can list, inspect, reply, assign, reprioritize, or change ticket status; every update is audit logged.                                                                                               |
| Database unavailable during support mutation                              | UI receives a temporary-unavailable response; no browser/local-storage fallback persists the ticket.                                                                                                                                              |

Automated focused coverage is available with:

```bash
npx vitest run \
  server/tokenDiscovery.test.ts \
  server/support/supportService.test.ts \
  server/riskEngine.test.ts \
  client/src/lib/wallet/walletconnect.test.ts \
  client/src/lib/wallet/txHistory.test.ts \
  client/src/lib/wallet/txIndexer.test.ts
```

## Production-excellence hardening QA

The swap review must show quote age and expiry, route/network, minimum received, approval target, gas-estimate availability, simulation state, and irreversible-transaction warning before signing. An expired quote must be rejected and require a fresh quote. A failed simulation must block signing; an unavailable simulation must remain visibly unavailable and must not be called successful. A mined receipt with `status === 0` must appear as **Reverted**, not Successful or merely Pending.

The admin workspace must expose provider health only through existing admin authorization. A successful provider call records latency and healthy state; a failed call records bounded error text and failure state; partial provider failure must not prevent healthy providers from producing an aggregate result. PAXI AI provider failure must return a safe temporary-unavailable response with human escalation and must perform no wallet action.

## Final native Help & Support UX checks

The native Help & Support screen now has three explicit modes: **Ask PAXI AI**, **My Tickets**, and **Contact Human**. The following checks remain part of the device/browser execution plan and are not marked as physically executed by this sandbox run.

| Journey                                 | Expected result                                                                                                                                                               |
| --------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Open Help & Support from Me             | The screen opens with the PAXI Assistant landing state, safety notice, quick prompts, and no fabricated support history.                                                      |
| Send a quick prompt or custom question  | The user message appears immediately; a visible “PAXI Assistant is checking…” state is shown; the answer is rendered in the existing markdown-capable chat surface.           |
| AI provider failure                     | The user receives a temporary-unavailable explanation, no wallet action is taken, and Retry plus human-support actions are available.                                         |
| AI uncertainty or escalation suggestion | The screen offers Create Support Ticket, Open ticket form, and Close actions rather than implying that an uncertain answer is authoritative.                                  |
| Open My Tickets                         | Only the authenticated user’s tickets appear; empty state and Report a Problem action are clear.                                                                              |
| Open ticket detail                      | Ticket key, subject, status, priority, created/updated times, and message history are visible; resolved/closed tickets do not expose an active reply composer.                |
| Reply to an open ticket                 | The reply is submitted once, the composer clears, and the refreshed thread shows the new message. Secret-looking content remains rejected by the server.                      |
| Contact Human                           | Category, subject, description, and safe diagnostic context are explicit; the form warns the user never to include recovery phrases, private keys, PINs, passwords, or codes. |
| Safe transaction/token context          | Only public, read-only context is disclosed to support; simulation availability remains explicit and signing credentials never enter the support flow.                        |

The latest automated validation record is stored under `release-validation-hardening-2026-08-18/summary.txt`: TypeScript, full Vitest, build, and lint passed; production dependency audit remains non-zero with the documented accepted controlled-beta findings.

## Final pre-beta gate checks

| Journey                                   | Expected result                                                                                                                                                                                                                     |
| ----------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Verification trust versus security result | `verified`/`unverified` trust comes only from explicit verification metadata; security labels and scores do not upgrade trust, and missing or malformed verification remains `unknown`.                                             |
| Newest security report selection          | The newest valid fresh report is selected; stale or malformed current data resolves to unknown rather than falling back to an older historical safe result.                                                                         |
| Provider-native name/symbol discovery     | CoinGecko and DexScreener search independently through the existing provider registry; partial provider failure is isolated and canonical chain-plus-token-standard-plus-contract results remain deduplicated and provenance-aware. |
| All discovery providers unavailable       | The result is an explicit unavailable state; no token identity, logo, price, or security result is invented.                                                                                                                        |

The post-correction automated run completed at `2026-08-18T17:32:17Z` and passed typecheck, full Vitest, build, and lint with **53 test files and 202 tests**. The production dependency audit remains non-zero with **21 findings (7 low, 11 moderate, 3 high, 0 critical)** and requires the documented controlled-beta acceptance. The final-freeze directive’s physical-device and deployment-owner checks remain explicitly unexecuted by this sandbox validation.

## Final LI.FI fee-hardening QA — 18 August 2026

The automated LI.FI proxy regressions cover the required fee-authority and restricted-proxy boundary:

| Check                         | Expected result                                                                                                                                         |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| LI.FI API key server-only     | `LIFI_API_KEY` is read only by the server proxy and never reaches client code, browser storage, URLs, logs, AI context, or support context.             |
| Restricted proxy              | Only the wallet-required quote and status operations are exposed; arbitrary paths and methods are rejected.                                             |
| Malformed quote and query     | Invalid chain IDs, token/wallet addresses, integers, slippage, oversized requests, and malformed values are rejected with controlled errors.            |
| Invalid or excessive fee      | Negative, fractional, non-finite, malformed, and above-limit basis-point values are rejected.                                                           |
| Manipulated client fee        | A client fee that differs from the server-authoritative bridge fee is rejected.                                                                         |
| Manipulated integrator        | A client integrator cannot replace the server-owned `paxiwallet` value.                                                                                 |
| Valid fee conversion          | Integer BPS are converted to LI.FI decimal percentage units; 50 BPS is 0.50% and 80 BPS is 0.80%.                                                       |
| Bridge fee disclosure         | The user sees the PAXI fee estimate, route/provider costs where available, network fee, destination, slippage, and quote-expiry context before signing. |
| Local signing                 | The browser signs locally; the LI.FI server proxy never receives private wallet material.                                                               |
| External payout configuration | Partner registration, payout/treasury destination, production API credentials, and live fee-bearing payout remain release-owner verification tasks.     |

Run the focused proxy suite with:

```bash
npx vitest run server/_core/lifiProxy.test.ts
```

The current final-freeze automated result is **55 test files and 213 tests passed**. Typecheck, production build, and the scoped lint gate passed. `npm audit --omit=dev` returned exit 1 with **21 findings: 7 low, 11 moderate, 3 high, and 0 critical**; this remains an explicitly documented controlled-beta acceptance. No live LI.FI payout or physical-device result is claimed from the sandbox run.
