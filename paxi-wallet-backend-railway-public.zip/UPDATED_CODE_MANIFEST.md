# PAXI Wallet Updated Code Manifest

This archive contains the complete updated PAXI Wallet source after the campaign reward escrow, payout verification, task-proof, authorization, cache, and chain-aware identifier changes.

The main implementation areas are the Drizzle campaign escrow schema and migration, the reward escrow and payout verifier, campaign router and claim/moderation guards, server environment and fee configuration, the actual swap-proof decoder integration, client-side chain-aware identifiers, campaign owner/admin screens, and the focused identifier regression test.

The repository was validated with `npm run check`, `npm test`, and `npm run build`. The current validation result is 31 test files and 88 tests passing. Install dependencies with `npm install` before running these commands in a fresh checkout.

The built frontend can be previewed with `npm run build` followed by the temporary static server script:

```bash
PORT=4173 node scripts/tempStaticServer.mjs
```

The full API server still requires production configuration, including `DATABASE_URL`, `JWT_SECRET`, `VITE_APP_ID`, and `OAUTH_SERVER_URL`, plus any blockchain payout signer and router allowlist settings needed for live on-chain operations.
