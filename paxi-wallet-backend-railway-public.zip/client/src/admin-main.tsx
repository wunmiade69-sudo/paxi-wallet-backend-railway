import AdminScreen from "@/pages/AdminScreen";
import { renderWorkspace } from "@/workspaces/bootstrap";

renderWorkspace(<AdminScreen onBack={() => window.location.assign("/")} />);
