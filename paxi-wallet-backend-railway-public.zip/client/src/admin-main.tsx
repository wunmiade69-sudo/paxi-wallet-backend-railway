import AdminWorkspace from "@/workspaces/AdminWorkspace";
import { renderWorkspace } from "@/workspaces/bootstrap";

renderWorkspace(<AdminWorkspace />);
