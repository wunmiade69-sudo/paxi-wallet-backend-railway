import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const adminPath = fileURLToPath(new URL("./pages/AdminScreen.tsx", import.meta.url));
const panelPath = fileURLToPath(new URL("./components/AdminReviewPanel.tsx", import.meta.url));
const adminEntryPath = fileURLToPath(new URL("./admin-main.tsx", import.meta.url));
const legacyReviewPath = fileURLToPath(new URL("./pages/AdminReviewScreen.tsx", import.meta.url));
const listingsRouterPath = fileURLToPath(new URL("../../server/routers/listings.ts", import.meta.url));
const campaignsRouterPath = fileURLToPath(new URL("../../server/routers/campaigns.ts", import.meta.url));

const read = (path: string) => readFileSync(path, "utf8");

describe("Phase 7I admin console contracts", () => {
  it("uses one shipped AdminScreen entry and embeds review workflows in its shell", () => {
    const admin = read(adminPath);
    const entry = read(adminEntryPath);
    const panel = read(panelPath);

    expect(entry).toContain("AdminScreen");
    expect(admin).toContain("AdminReviewPanel");
    expect(admin).toContain('id: "review"');
    expect(admin).toContain("canReviewQueues");
    expect(admin).toContain('sections.filter(({ id }) => id !== "review" || canReviewQueues)');
    expect(panel).toContain('role="tablist"');
    expect(panel).toContain("aria-selected={active}");
    expect(panel).not.toContain("Admin Review</h1>");
    expect(panel).not.toContain("ArrowLeft");
    expect(read(legacyReviewPath)).toContain('export { default } from "@/components/AdminReviewPanel"');
  });

  it("requires explicit reason confirmation and prevents duplicate processing", () => {
    const admin = read(adminPath);
    const panel = read(panelPath);

    expect(admin).toContain("Reason must be at least 10 characters.");
    expect(admin).toContain("Processing… do not submit again.");
    expect(admin).toContain('role="dialog"');
    expect(admin).not.toContain("window.prompt");
    expect(admin).toContain("server-authorized and will be recorded in the admin audit log");
    expect(panel).toContain("A reason of at least 10 characters is required.");
    expect(panel).toContain("processing={review.isPending}");
    expect(read(listingsRouterPath)).toContain("reason: z.string().trim().min(10).max(1000)");
    expect(read(campaignsRouterPath)).toContain("reason: z.string().trim().min(10).max(1000)");
  });

  it("keeps admin tables usable on small screens without exposing sensitive fields", () => {
    const admin = read(adminPath);

    expect(admin).toContain("md:hidden");
    expect(admin).toContain("rounded-xl border border-foreground/10 bg-secondary/40 p-3");
    expect(admin).toContain("Sensitive credentials and signing material are never displayed.");
  });
});

export {};
