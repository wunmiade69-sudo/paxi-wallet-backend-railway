import { useEffect, useState } from "react";
import { Check, X, Twitter, Send as TelegramIcon, Globe } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { describeUserFacingError } from "@/lib/userFacingError";

export type AdminReviewTab = "listings" | "campaign-review" | "operations" | "campaigns";


interface AdminReviewPanelProps {
  initialTab?: AdminReviewTab;
}

export default function AdminReviewPanel({ initialTab = "listings" }: AdminReviewPanelProps) {
  const [tab, setTab] = useState<AdminReviewTab>(initialTab);
  useEffect(() => setTab(initialTab), [initialTab]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Admin review workflows">
        <TabButton active={tab === "listings"} onClick={() => setTab("listings")} label="Pending Listings" />
        <TabButton active={tab === "campaign-review"} onClick={() => setTab("campaign-review")} label="Campaign Review" />
        <TabButton active={tab === "operations"} onClick={() => setTab("operations")} label="Operations" />
        <TabButton active={tab === "campaigns"} onClick={() => setTab("campaigns")} label="Campaign Payouts" />
      </div>
      <div>
        {tab === "listings" ? <PendingListings /> : tab === "campaign-review" ? <PendingCampaignReviews /> : tab === "operations" ? <CampaignOperations /> : <CampaignPayouts />}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={`min-h-10 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
        active ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'
      }`}
    >
      {label}
    </button>
  );
}

function ReviewReasonDialog({
  open,
  title,
  description,
  destructive = false,
  processing = false,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  title: string;
  description: string;
  destructive?: boolean;
  processing?: boolean;
  onCancel: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState("");
  useEffect(() => {
    if (!open) setReason("");
  }, [open]);
  if (!open) return null;
  const valid = reason.trim().length >= 10;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" role="presentation">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl" role="dialog" aria-modal="true" aria-labelledby="admin-action-title">
        <h2 id="admin-action-title" className="text-base font-semibold text-foreground">{title}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{description}</p>
        <label className="mt-4 block text-xs font-semibold text-foreground" htmlFor="admin-action-reason">Audit reason</label>
        <textarea
          id="admin-action-reason"
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          placeholder="Enter at least 10 characters"
          rows={3}
          disabled={processing}
          className="mt-1 w-full resize-y rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground outline-none focus:border-accent/50 disabled:opacity-60"
        />
        {!valid && reason.length > 0 && <p className="mt-1 text-xs text-destructive">A reason of at least 10 characters is required.</p>}
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={onCancel} disabled={processing} className="rounded-lg bg-secondary px-4 py-2 text-xs font-semibold text-muted-foreground disabled:opacity-50">Cancel</button>
          <button type="button" onClick={() => valid && onConfirm(reason.trim())} disabled={!valid || processing} className={`rounded-lg px-4 py-2 text-xs font-semibold disabled:cursor-not-allowed disabled:opacity-50 ${destructive ? "bg-destructive text-white" : "bg-accent text-accent-foreground"}`}>
            {processing ? "Processing…" : "Confirm"}
          </button>
        </div>
      </div>
    </div>
  );
}

function PendingListings() {
  const utils = trpc.useUtils();
  const { data: pending, isLoading } = trpc.listings.adminListPending.useQuery();
  const [action, setAction] = useState<{ id: number; decision: 'verified' | 'rejected' } | null>(null);

  const review = trpc.listings.adminReview.useMutation({
    onSuccess: () => {
      utils.listings.adminListPending.invalidate();
      setAction(null);
    },
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t update this request. Please try again.')),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!pending || pending.length === 0) {
    return <p className="text-sm text-muted-foreground">No listings waiting for review.</p>;
  }

  return (
    <div className="space-y-4">
      {pending.map((listing) => (
        <div key={listing.id} className="glass-card p-4 space-y-3">
          <div className="flex items-center gap-3">
            {listing.logoKey && (
              <img
                src={`/manus-storage/${listing.logoKey}`}
                alt={listing.symbol}
                className="w-10 h-10 rounded-full object-cover"
              />
            )}
            <div>
              <p className="text-sm font-semibold text-foreground">
                {listing.name} ({listing.symbol})
              </p>
              <p className="text-xs text-muted-foreground font-mono break-all">{listing.contractAddress}</p>
              <p className="text-xs text-muted-foreground">{listing.network}</p>
            </div>
          </div>

          {listing.plan && <p className="text-xs text-foreground/80">{listing.plan}</p>}

          {listing.socials && (
            <div className="flex gap-3 text-muted-foreground">
              {listing.socials.twitter && <Twitter className="w-4 h-4" />}
              {listing.socials.telegram && <TelegramIcon className="w-4 h-4" />}
              {listing.socials.website && <Globe className="w-4 h-4" />}
            </div>
          )}

          <p className="text-xs text-muted-foreground">
            Fee tx: <span className="font-mono break-all">{listing.feeTxHash}</span> (${listing.feeAmountUsd} verified)
          </p>

          <div className="flex gap-2">
            <button type="button" onClick={() => setAction({ id: listing.id, decision: 'verified' })} disabled={review.isPending} className="flex-1 flex items-center justify-center gap-1.5 bg-accent hover:bg-accent/90 text-accent-foreground text-xs font-semibold py-2 rounded-lg disabled:opacity-50">
              <Check className="w-3.5 h-3.5" /> Approve
            </button>
            <button type="button" onClick={() => setAction({ id: listing.id, decision: 'rejected' })} disabled={review.isPending} className="flex-1 flex items-center justify-center gap-1.5 bg-secondary text-muted-foreground text-xs font-semibold py-2 rounded-lg disabled:opacity-50">
              <X className="w-3.5 h-3.5" /> Reject
            </button>
          </div>
          <ReviewReasonDialog
            open={action?.id === listing.id}
            title={action?.decision === 'rejected' ? 'Reject token listing' : 'Approve token listing'}
            description="This action is recorded in the admin audit log. Confirm the operational reason before continuing."
            destructive={action?.decision === 'rejected'}
            processing={review.isPending}
            onCancel={() => setAction(null)}
            onConfirm={(reason) => {
              if (!action) return;
              review.mutate({ id: action.id, decision: action.decision, reason, ...(action.decision === 'rejected' ? { rejectionReason: reason } : {}) });
            }}
          />
        </div>
      ))}
    </div>
  );
}

function PendingCampaignReviews() {
  const utils = trpc.useUtils();
  const { data: pending, isLoading } = trpc.campaigns.adminListPendingReview.useQuery();
  const [action, setAction] = useState<{ id: number; decision: 'active' | 'rejected' } | null>(null);
  const review = trpc.campaigns.adminReview.useMutation({
    onSuccess: () => {
      utils.campaigns.adminListPendingReview.invalidate();
      utils.campaigns.listActive.invalidate();
      setAction(null);
    },
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t update this request. Please try again.')),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading campaign review queue…</p>;
  if (!pending || pending.length === 0) return <p className="text-sm text-muted-foreground">No funded campaigns are waiting for review.</p>;

  return (
    <div className="space-y-4">
      {pending.map((campaign) => (
        <article key={campaign.id} className="glass-card overflow-hidden !p-0">
          {campaign.bannerKey && <img src={`/manus-storage/${campaign.bannerKey}`} alt="Campaign banner awaiting review" className="h-32 w-full object-cover" />}
          <div className="space-y-3 p-4">
            <div className="flex items-start gap-3">
              {campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-10 w-10 rounded-xl object-cover" />}
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{campaign.title}</p><p className="text-xs text-muted-foreground">{campaign.taskTokenSymbol} · ${campaign.poolRequiredAmountUsd} pool verified</p></div>
            </div>
            {campaign.description && <p className="text-xs text-foreground/80">{campaign.description}</p>}
            <div className="grid grid-cols-2 gap-2 text-xs"><p className="rounded-lg bg-secondary p-2 text-muted-foreground">Reward: <span className="font-semibold text-foreground">{campaign.rewardAmount} {campaign.rewardTokenSymbol}</span></p><p className="rounded-lg bg-secondary p-2 text-muted-foreground">Winners: <span className="font-semibold text-foreground">{campaign.maxWinners}</span></p></div>
            {campaign.website && <p className="break-all text-xs text-accent">{campaign.website}</p>}

            <div className="flex gap-2">
              <button type="button" onClick={() => setAction({ id: campaign.id, decision: 'active' })} disabled={review.isPending} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-accent py-2 text-xs font-semibold text-accent-foreground disabled:opacity-50"><Check className="h-3.5 w-3.5" />Approve & publish</button>
              <button type="button" onClick={() => setAction({ id: campaign.id, decision: 'rejected' })} disabled={review.isPending} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-secondary py-2 text-xs font-semibold text-muted-foreground disabled:opacity-50"><X className="h-3.5 w-3.5" />Reject</button>
            </div>
            <ReviewReasonDialog
              open={action?.id === campaign.id}
              title={action?.decision === 'rejected' ? 'Reject campaign' : 'Approve campaign'}
              description="This review decision is recorded in the admin audit log. Confirm the operational reason before continuing."
              destructive={action?.decision === 'rejected'}
              processing={review.isPending}
              onCancel={() => setAction(null)}
              onConfirm={(reason) => {
                if (!action) return;
                review.mutate({ campaignId: action.id, decision: action.decision, reason, ...(action.decision === 'rejected' ? { rejectionReason: reason } : {}) });
              }}
            />
          </div>
        </article>
      ))}
    </div>
  );
}

function CampaignPayouts() {
  const { data: activeCampaigns, isLoading } = trpc.campaigns.listActive.useQuery();
  const [selectedCampaignId, setSelectedCampaignId] = useState<number | null>(null);

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!activeCampaigns || activeCampaigns.length === 0) {
    return <p className="text-sm text-muted-foreground">No active campaigns.</p>;
  }

  if (selectedCampaignId) {
    return <CampaignEntryList campaignId={selectedCampaignId} onBack={() => setSelectedCampaignId(null)} />;
  }

  return (
    <div className="space-y-3">
      {activeCampaigns.map((c) => (
        <button
          key={c.id}
          onClick={() => setSelectedCampaignId(c.id)}
          className="w-full text-left glass-card p-4 flex items-center justify-between"
        >
          <div>
            <p className="text-sm font-semibold text-foreground">{c.title}</p>
            <p className="text-xs text-muted-foreground">
              {c.winnersCount}/{c.maxWinners} slots claimed
            </p>
          </div>
          <span className="text-xs text-accent font-medium">View →</span>
        </button>
      ))}
    </div>
  );
}

function CampaignOperations() {
  const utils = trpc.useUtils();
  const { data: campaigns, isLoading } = trpc.campaigns.adminListOperational.useQuery();
  const [action, setAction] = useState<{ campaignId: number; label: string; destructive?: boolean; fields: { isFeatured?: boolean; claimsPaused?: boolean; suspended?: boolean } } | null>(null);
  const update = trpc.campaigns.adminSetOperations.useMutation({
    onSuccess: () => {
      utils.campaigns.adminListOperational.invalidate();
      utils.campaigns.featured.invalidate();
      utils.campaigns.listActive.invalidate();
      setAction(null);
      toast.success('Campaign operation updated.');
    },
    onError: (error) => toast.error(describeUserFacingError(error, 'We couldn’t update this campaign. Please try again.')),
  });
  if (isLoading) return <p className="text-sm text-muted-foreground">Loading operational campaigns…</p>;
  if (!campaigns || campaigns.length === 0) return <p className="text-sm text-muted-foreground">No active or suspended campaigns.</p>;
  return (
    <div className="space-y-3">
      {campaigns.map((campaign) => (
        <article key={campaign.id} className="glass-card space-y-3 p-4">
          <div className="flex items-start gap-3">{campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-9 w-9 rounded-xl object-cover" />}<div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{campaign.title}</p><p className="text-xs text-muted-foreground">{campaign.status} · {campaign.winnersCount}/{campaign.maxWinners} slots</p></div></div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <button type="button" onClick={() => setAction({ campaignId: campaign.id, label: campaign.isFeatured ? 'Remove campaign feature' : 'Feature campaign on home', fields: { isFeatured: !campaign.isFeatured } })} disabled={update.isPending} className={`rounded-lg py-2 text-xs font-semibold disabled:opacity-50 ${campaign.isFeatured ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'}`}>{campaign.isFeatured ? 'Featured on home' : 'Feature on home'}</button>
            <button type="button" onClick={() => setAction({ campaignId: campaign.id, label: campaign.claimsPaused ? 'Resume campaign claims' : 'Pause campaign claims', fields: { claimsPaused: !campaign.claimsPaused } })} disabled={update.isPending} className={`rounded-lg py-2 text-xs font-semibold disabled:opacity-50 ${campaign.claimsPaused ? 'bg-amber-400/20 text-amber-200' : 'bg-secondary text-muted-foreground'}`}>{campaign.claimsPaused ? 'Resume claims' : 'Pause claims'}</button>
            <button type="button" onClick={() => setAction({ campaignId: campaign.id, label: campaign.status === 'suspended' ? 'Resume campaign' : 'Suspend campaign', destructive: campaign.status !== 'suspended', fields: { suspended: campaign.status !== 'suspended' } })} disabled={update.isPending} className="rounded-lg bg-secondary py-2 text-xs font-semibold text-muted-foreground disabled:opacity-50">{campaign.status === 'suspended' ? 'Resume campaign' : 'Suspend campaign'}</button>
          </div>
        </article>
      ))}
      <ReviewReasonDialog
        open={Boolean(action)}
        title={action?.label ?? 'Update campaign'}
        description="This operational change is recorded in the admin audit log. Confirm the reason before continuing."
        destructive={action?.destructive}
        processing={update.isPending}
        onCancel={() => setAction(null)}
        onConfirm={(reason) => {
          if (!action) return;
          update.mutate({ campaignId: action.campaignId, ...action.fields, reason });
        }}
      />
    </div>
  );
}

function CampaignEntryList({ campaignId, onBack }: { campaignId: number; onBack: () => void }) {
  const utils = trpc.useUtils();
  const { data: entries, isLoading } = trpc.campaigns.adminListEntries.useQuery({ campaignId });
  const [payoutTxHash, setPayoutTxHash] = useState<Record<number, string>>({});
  const [payoutEntryId, setPayoutEntryId] = useState<number | null>(null);

  const markPayout = trpc.campaigns.markPayout.useMutation({
    onSuccess: () => {
      utils.campaigns.adminListEntries.invalidate({ campaignId });
      setPayoutEntryId(null);
    },
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t update this request. Please try again.')),
  });

  return (
    <div className="space-y-3">
      <button onClick={onBack} className="text-xs text-accent font-medium">
        ← Back to campaigns
      </button>
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : !entries || entries.length === 0 ? (
        <p className="text-sm text-muted-foreground">No entries yet.</p>
      ) : (
        entries
          .filter((e) => e.slotNumber != null)
          .sort((a, b) => (a.slotNumber ?? 0) - (b.slotNumber ?? 0))
          .map((entry) => (
            <div key={entry.id} className="glass-card p-4 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-foreground">Winner #{entry.slotNumber}</p>
                <span
                  className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                    entry.payoutStatus === 'paid' ? 'bg-accent/20 text-accent' : 'bg-secondary text-muted-foreground'
                  }`}
                >
                  {entry.payoutStatus}
                </span>
              </div>
              <p className="text-xs text-muted-foreground font-mono break-all">proof: {entry.proofTxHash}</p>
              {entry.payoutStatus === 'claimable' && (
                <div className="flex gap-2">
                  <input
                    value={payoutTxHash[entry.id] ?? ''}
                    onChange={(e) => setPayoutTxHash((s) => ({ ...s, [entry.id]: e.target.value }))}
                    placeholder="Payout tx hash after sending reward"
                    className="flex-1 bg-secondary border border-border rounded-lg py-2 px-3 text-xs text-foreground outline-none focus:border-accent/50"
                  />
                  <button
                    type="button"
                    onClick={() => setPayoutEntryId(entry.id)}
                    disabled={!payoutTxHash[entry.id]?.trim() || markPayout.isPending}
                    className="bg-accent hover:bg-accent/90 disabled:opacity-40 text-accent-foreground text-xs font-semibold px-3 rounded-lg"
                  >
                    Mark Paid
                  </button>
                </div>
              )}
            </div>
          ))
      )}
      <ReviewReasonDialog
        open={payoutEntryId !== null}
        title="Mark campaign payout paid"
        description="Only confirm after the reward transfer has been independently completed and the transaction hash is recorded. This action is audited."
        processing={markPayout.isPending}
        onCancel={() => setPayoutEntryId(null)}
        onConfirm={(reason) => {
          if (payoutEntryId === null) return;
          markPayout.mutate({ entryId: payoutEntryId, payoutTxHash: (payoutTxHash[payoutEntryId] ?? '').trim(), reason });
        }}
      />
    </div>
  );
}
