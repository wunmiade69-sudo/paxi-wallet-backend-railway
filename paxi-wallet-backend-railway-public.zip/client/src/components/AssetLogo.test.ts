import { describe, expect, it } from 'vitest';
import { isSafeAssetImageUrl, logoCacheStorageKey, selectAssetLogoSource } from './AssetLogo';

describe('isSafeAssetImageUrl', () => {
  it('allows absolute HTTP and HTTPS provider logos', () => {
    expect(isSafeAssetImageUrl('https://assets.example.test/token.png')).toBe(true);
    expect(isSafeAssetImageUrl('http://assets.example.test/token.png')).toBe(true);
  });

  it('allows same-origin bundled asset paths', () => {
    expect(isSafeAssetImageUrl('/logos/token.png')).toBe(true);
    expect(isSafeAssetImageUrl('/dapp-logos/pancakeswap.svg')).toBe(true);
  });

  it('rejects non-HTTP(S), protocol-relative, malformed, and missing sources', () => {
    expect(isSafeAssetImageUrl('javascript:alert(1)')).toBe(false);
    expect(isSafeAssetImageUrl('data:image/svg+xml;base64,abc')).toBe(false);
    expect(isSafeAssetImageUrl('//evil.example.test/token.png')).toBe(false);
    expect(isSafeAssetImageUrl('not a URL')).toBe(false);
    expect(isSafeAssetImageUrl(null)).toBe(false);
  });

  it('uses stable namespaced keys and never shares a cached logo across identities', () => {
    expect(logoCacheStorageKey(' ethereum:0xabc ')).toBe('paxi-successful-logo:ethereum:0xabc');
    expect(logoCacheStorageKey()).toBeNull();
    expect(logoCacheStorageKey('   ')).toBeNull();

    const cachedForAssetA = 'https://cdn.example.test/a.png';
    expect(selectAssetLogoSource(undefined, cachedForAssetA)).toBe(cachedForAssetA);
    expect(selectAssetLogoSource('https://cdn.example.test/a-new.png', cachedForAssetA)).toBe('https://cdn.example.test/a-new.png');
    expect(selectAssetLogoSource(undefined, cachedForAssetA, [cachedForAssetA])).toBeUndefined();
    expect(selectAssetLogoSource(undefined, 'https://cdn.example.test/a.png', ['https://cdn.example.test/b.png'])).toBe('https://cdn.example.test/a.png');
  });

  it('does not select unsafe current or cached sources', () => {
    expect(selectAssetLogoSource('javascript:alert(1)', 'data:image/png;base64,abc')).toBeUndefined();
  });
});
