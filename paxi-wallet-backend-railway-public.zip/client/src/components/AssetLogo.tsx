import { useEffect, useState, type ReactNode } from 'react';
import { safeGetLocalStorage, safeSetLocalStorage } from '@/lib/safeStorage';
import { cn } from '@/lib/utils';

interface AssetLogoProps {
  src?: string | null;
  alt?: string;
  fallback: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  /** Optional stable identity used for successful-logo persistence. */
  cacheKey?: string;
  'aria-hidden'?: boolean;
}

const SIZE_CLASSES: Record<NonNullable<AssetLogoProps['size']>, string> = {
  sm: 'h-8 w-8 text-[10px]',
  md: 'h-10 w-10 text-xs',
  lg: 'h-12 w-12 text-sm',
};

/**
 * Remote http(s) image URLs are allowed, and so are same-origin absolute
 * paths (e.g. bundled assets under `/dapp-logos/…`) so curated entries can
 * ship a logo without depending on a third-party host being reachable.
 * A leading `//` is rejected because browsers resolve that as protocol-relative
 * to an arbitrary host, not same-origin. javascript:, data:, and malformed
 * values all fall through to the caller's fallback.
 */
export function isSafeAssetImageUrl(src?: string | null): src is string {
  if (!src) return false;
  if (src.startsWith('/') && !src.startsWith('//')) return true;
  try {
    const parsed = new URL(src);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

const LOGO_CACHE_PREFIX = 'paxi-successful-logo:';

/** Returns the namespaced storage key, or null when there is no stable identity. */
export function logoCacheStorageKey(cacheKey?: string): string | null {
  return typeof cacheKey === 'string' && cacheKey.trim()
    ? `${LOGO_CACHE_PREFIX}${cacheKey.trim()}`
    : null;
}

/** Selects the current source first, then the successful source for the same identity. */
export function selectAssetLogoSource(src: string | null | undefined, cachedSrc: string | null | undefined, failedSources: readonly string[] = []): string | undefined {
  return [src, cachedSrc].find((value): value is string => isSafeAssetImageUrl(value) && !failedSources.includes(value));
}

function readCachedLogo(cacheKey?: string): string | null {
  const storageKey = logoCacheStorageKey(cacheKey);
  if (!storageKey) return null;
  const value = safeGetLocalStorage(storageKey);
  return isSafeAssetImageUrl(value) ? value : null;
}

function writeCachedLogo(cacheKey: string | undefined, value: string): void {
  const storageKey = logoCacheStorageKey(cacheKey);
  if (!storageKey || !isSafeAssetImageUrl(value)) return;
  safeSetLocalStorage(storageKey, value);
}

/** Stable logo surface shared by wallet assets and provider-backed market rows. */
export default function AssetLogo({ src, alt = '', fallback, size = 'md', className, cacheKey, 'aria-hidden': ariaHidden }: AssetLogoProps) {
  const [failedSources, setFailedSources] = useState<string[]>([]);
  const [cachedSrc, setCachedSrc] = useState<string | null>(() => readCachedLogo(cacheKey));
  const candidateSrc = selectAssetLogoSource(src, cachedSrc, failedSources);

  useEffect(() => {
    setFailedSources([]);
    setCachedSrc(readCachedLogo(cacheKey));
  }, [src, cacheKey]);

  return (
    <span
      className={cn(
        'relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full border border-foreground/10 bg-secondary font-semibold text-accent',
        SIZE_CLASSES[size],
        className,
      )}
      aria-hidden={ariaHidden ?? (!alt ? true : undefined)}
    >
      <span aria-hidden="true" className="select-none">
        {fallback}
      </span>
      {candidateSrc && (
        <img
          src={candidateSrc}
          alt={alt}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 h-full w-full object-contain bg-secondary"
          onLoad={() => writeCachedLogo(cacheKey, candidateSrc)}
          onError={() => setFailedSources((current) => current.includes(candidateSrc) ? current : [...current, candidateSrc])}
        />
      )}
    </span>
  );
}
