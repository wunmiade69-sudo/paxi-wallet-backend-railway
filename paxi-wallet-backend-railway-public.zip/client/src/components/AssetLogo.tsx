import { useEffect, useState, type ReactNode } from 'react';
import { safeGetLocalStorage, safeSetLocalStorage } from '@/lib/safeStorage';
import { cn } from '@/lib/utils';

interface AssetLogoProps {
  src?: string | null;
  alt?: string;
  fallback: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  /** Optional stable identity used for successful-logo persistence. */
  cacheKey?: string;
  'aria-hidden'?: boolean;
}

const SIZE_CLASSES: Record<NonNullable<AssetLogoProps['size']>, string> = {
  sm: 'h-8 w-8 text-[10px]',
  md: 'h-10 w-10 text-xs',
  lg: 'h-12 w-12 text-sm',
};

/**
 * Remote http(s) image URLs are allowed, and so are same-origin absolute
 * paths (e.g. bundled assets under `/dapp-logos/…`) so curated entries can
 * ship a logo without depending on a third-party host being reachable.
 * A leading `//` is rejected because browsers resolve that as protocol-relative
 * to an arbitrary host, not same-origin. javascript:, data:, and malformed
 * values all fall through to the caller's fallback.
 */
export function isSafeAssetImageUrl(src?: string | null): src is string {
  if (!src) return false;
  if (src.startsWith('/') && !src.startsWith('//')) return true;
  try {
    const parsed = new URL(src);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

const LOGO_CACHE_PREFIX = 'paxi-successful-logo:';
const LOGO_HTTP_CACHE = 'paxi-dapp-logos-v1';
const remoteLogoRequests = new Map<string, Promise<string | null>>();

function isRemoteLogo(value: string): boolean {
  try {
    const protocol = new URL(value).protocol;
    return protocol === 'http:' || protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Reuse a downloaded remote logo across mounts and browser sessions. Bundled
 * same-origin assets remain immediate; remote assets are fetched once, stored
 * in the browser Cache API, and deduplicated while a request is in flight.
 */
async function loadLogoSource(source: string): Promise<string> {
  if (!isRemoteLogo(source) || typeof window === 'undefined' || !('caches' in window) || typeof URL.createObjectURL !== 'function') {
    return source;
  }
  const existing = remoteLogoRequests.get(source);
  if (existing) return (await existing) ?? source;
  const request = (async (): Promise<string | null> => {
    try {
      const cache = await window.caches.open(LOGO_HTTP_CACHE);
      let response = await cache.match(source);
      if (!response) {
        response = await fetch(source, { mode: 'cors' });
        if (!response.ok) return null;
        await cache.put(source, response.clone());
      }
      return URL.createObjectURL(await response.blob());
    } catch {
      return null;
    }
  })();
  remoteLogoRequests.set(source, request);
  return (await request) ?? source;
}

/** Returns the namespaced storage key, or null when there is no stable identity. */
export function logoCacheStorageKey(cacheKey?: string): string | null {
  return typeof cacheKey === 'string' && cacheKey.trim()
    ? `${LOGO_CACHE_PREFIX}${cacheKey.trim()}`
    : null;
}

/** Selects the current source first, then the successful source for the same identity. */
export function selectAssetLogoSource(src: string | null | undefined, cachedSrc: string | null | undefined, failedSources: readonly string[] = []): string | undefined {
  return [src, cachedSrc].find((value): value is string => isSafeAssetImageUrl(value) && !failedSources.includes(value));
}

function readCachedLogo(cacheKey?: string): string | null {
  const storageKey = logoCacheStorageKey(cacheKey);
  if (!storageKey) return null;
  const value = safeGetLocalStorage(storageKey);
  return isSafeAssetImageUrl(value) ? value : null;
}

function writeCachedLogo(cacheKey: string | undefined, value: string): void {
  const storageKey = logoCacheStorageKey(cacheKey);
  if (!storageKey || !isSafeAssetImageUrl(value)) return;
  safeSetLocalStorage(storageKey, value);
}

/** Stable logo surface shared by wallet assets and provider-backed market rows. */
export default function AssetLogo({ src, alt = '', fallback, size = 'md', className, cacheKey, 'aria-hidden': ariaHidden }: AssetLogoProps) {
  const [failedSources, setFailedSources] = useState<string[]>([]);
  const [cachedSrc, setCachedSrc] = useState<string | null>(() => readCachedLogo(cacheKey));
  const [loadedSrc, setLoadedSrc] = useState<string | undefined>();
  const candidateSrc = selectAssetLogoSource(src, cachedSrc, failedSources);

  useEffect(() => {
    setFailedSources([]);
    setCachedSrc(readCachedLogo(cacheKey));
    setLoadedSrc(undefined);
  }, [src, cacheKey]);

  useEffect(() => {
    let cancelled = false;
    if (!candidateSrc) return;
    void loadLogoSource(candidateSrc).then((resolved) => {
      if (!cancelled) setLoadedSrc(resolved);
    });
    return () => {
      cancelled = true;
    };
  }, [candidateSrc]);

  return (
    <span
      className={cn(
        'relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full border border-foreground/10 bg-secondary font-semibold text-accent',
        SIZE_CLASSES[size],
        className,
      )}
      aria-hidden={ariaHidden ?? (!alt ? true : undefined)}
    >
      <span aria-hidden="true" className="select-none">
        {fallback}
      </span>
      {candidateSrc && loadedSrc && (
        <img
          src={loadedSrc}
          alt={alt}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 h-full w-full object-contain bg-secondary"
          onLoad={() => writeCachedLogo(cacheKey, candidateSrc)}
          onError={() => setFailedSources((current) => current.includes(candidateSrc) ? current : [...current, candidateSrc])}
        />
      )}
    </span>
  );
}
