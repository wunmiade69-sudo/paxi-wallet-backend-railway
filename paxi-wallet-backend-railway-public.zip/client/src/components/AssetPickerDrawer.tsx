import { useMemo, useState } from 'react';
import { Search, ChevronDown, Check } from 'lucide-react';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import { NETWORKS, assetKey, type AssetConfig } from '@/lib/wallet/chains';
import { getAssetLogoUrl } from '@/lib/appInfo';

interface AssetPickerDrawerProps {
  label: string; // e.g. "You pay"
  assets: AssetConfig[];
  selected: AssetConfig | undefined;
  /** A token to grey out (e.g. the one picked on the other side of a swap). Compared by symbol, which is fine when `assets` is scoped to one network. */
  disabledSymbol?: string;
  /** Show the network under each row - turn on when `assets` spans multiple chains (e.g. Send), so same-symbol tokens (USDT on ETH vs BSC) are distinguishable. */
  showNetwork?: boolean;
  onSelect: (asset: AssetConfig) => void;
}

/**
 * Trigger renders as a compact pill (icon + symbol + chevron) that opens a
 * bottom sheet with search - replaces the bare native <select> that used to
 * sit here. Native selects render outside normal layout flow on some mobile
 * WebViews (that's the floating detached dropdown bug), and even when they
 * render fine they look like a browser form control, not part of the app.
 *
 * Selection is keyed by `assetKey` (symbol+network), not bare symbol -
 * several tokens (USDT, USDC) exist as separate entries on more than one
 * chain, so symbol alone can't tell them apart.
 */
export default function AssetPickerDrawer({ label, assets, selected, disabledSymbol, showNetwork, onSelect }: AssetPickerDrawerProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return assets;
    return assets.filter((a) => a.symbol.toLowerCase().includes(q) || a.name.toLowerCase().includes(q));
  }, [assets, query]);

  return (
    <Drawer
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) setQuery('');
      }}
    >
      <DrawerTrigger asChild>
        <button
          type="button"
          className="flex items-center gap-2 bg-secondary hover:bg-muted border border-border rounded-full pl-2 pr-3 py-1.5 shrink-0 transition-colors"
          aria-label={`${label}: ${selected?.symbol ?? 'choose token'}`}
        >
          <AssetIcon asset={selected} size={22} />
          <span className="text-foreground font-semibold text-sm">{selected?.symbol ?? 'Select'}</span>
          <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
      </DrawerTrigger>
      <DrawerContent className="max-h-[75vh]">
        <DrawerHeader className="text-left">
          <DrawerTitle>{label}</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-2">
          <div className="relative">
            <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search name or symbol"
              className="w-full bg-secondary border border-border rounded-lg py-2.5 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
            />
          </div>
        </div>
        <div className="overflow-y-auto px-2 pb-6">
          {filtered.length === 0 && (
            <p className="text-center text-sm text-muted-foreground py-8">No tokens match "{query}"</p>
          )}
          {filtered.map((a) => {
            const isDisabled = a.symbol === disabledSymbol;
            const isSelected = selected ? assetKey(a) === assetKey(selected) : false;
            return (
              <button
                key={assetKey(a)}
                type="button"
                disabled={isDisabled}
                onClick={() => {
                  onSelect(a);
                  setOpen(false);
                  setQuery('');
                }}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left transition-colors ${
                  isDisabled ? 'opacity-35 cursor-not-allowed' : 'hover:bg-foreground/5'
                }`}
              >
                <AssetIcon asset={a} size={32} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm truncate">{a.symbol}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {a.name}
                    {showNetwork ? ` · ${a.network}` : ''}
                  </p>
                </div>
                {isSelected && <Check className="w-4 h-4 text-accent shrink-0" />}
              </button>
            );
          })}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

export function AssetIcon({ asset, size = 28 }: { asset: AssetConfig | undefined; size?: number }) {
  const [failed, setFailed] = useState(false);
  if (!asset) {
    return (
      <span
        className="rounded-full bg-secondary flex items-center justify-center shrink-0"
        style={{ width: size, height: size }}
      />
    );
  }
  const logoUrl = getAssetLogoUrl(asset);
  if (logoUrl && !failed) {
    return (
      <img
        src={logoUrl}
        alt={asset.symbol}
        onError={() => setFailed(true)}
        className="rounded-full bg-foreground/5 object-contain shrink-0"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <span
      className="rounded-full bg-foreground/5 flex items-center justify-center shrink-0"
      style={{ width: size, height: size, fontSize: size * 0.55 }}
    >
      {asset.icon}
    </span>
  );
}
