import { useEffect, useMemo, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, CircleHelp, Loader2, Search, X } from 'lucide-react';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import AssetLogo from '@/components/AssetLogo';
import { ASSETS, NETWORKS, assetKey, type AssetConfig } from '@/lib/wallet/chains';
import type { AssetBalance } from '@/lib/wallet/balances';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { shortenCanonicalIdentifier } from '@/lib/marketIdentity';
import { filterLocalAssetsForSearch, filterProviderAssetsForSearch, searchResultToCanonicalToken, type AssetImportSeed } from '@/lib/assetSearch';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { trpc } from '@/lib/trpc';

interface AssetSearchDrawerProps {
  balances: Record<string, AssetBalance>;
  onSelectAsset: (asset: AssetConfig, balance: AssetBalance | undefined) => void;
  onAddToken: (initial?: AssetImportSeed) => void;
}

/**
 * Full-height Assets search flow. Network selection deliberately precedes the
 * search field so results from similarly named assets cannot be mixed across
 * chains. All identity matching continues to use chain + contract/mint.
 */
export default function AssetSearchDrawer({ balances, onSelectAsset, onAddToken }: AssetSearchDrawerProps) {
  const [open, setOpen] = useState(false);
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  const searchableAssets = useMemo(() => [...ASSETS, ...getCustomTokens().map(customTokenToAsset)], []);
  const normalizedQuery = query.trim();
  useEffect(() => {
    const timer = window.setTimeout(() => setDebouncedQuery(normalizedQuery), 350);
    return () => window.clearTimeout(timer);
  }, [normalizedQuery]);
  const { data: providerResults, isFetching } = trpc.market.search.useQuery(
    { query: debouncedQuery },
    { enabled: open && Boolean(selectedNetwork) && debouncedQuery.length >= 2 },
  );

  const localMatches = useMemo(
    () => filterLocalAssetsForSearch(searchableAssets, selectedNetwork, normalizedQuery),
    [normalizedQuery, searchableAssets, selectedNetwork],
  );

  const providerMatches = useMemo(
    () => filterProviderAssetsForSearch(providerResults ?? [], selectedNetwork, debouncedQuery, searchableAssets),
    [debouncedQuery, providerResults, searchableAssets, selectedNetwork],
  );

  const reset = () => {
    setSelectedNetwork(null);
    setQuery('');
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next) reset();
  };

  const networkEntries = Object.values(NETWORKS);
  const hasSearch = Boolean(selectedNetwork && normalizedQuery);
  const hasPendingSearch = normalizedQuery.length >= 2 && normalizedQuery !== debouncedQuery;
  const selectedNetworkLabel = selectedNetwork ? NETWORKS[selectedNetwork]?.label ?? selectedNetwork : null;

  return (
    <Drawer open={open} onOpenChange={handleOpenChange}>
      <DrawerTrigger asChild>
        <button
          type="button"
          className="paxi-pressable flex min-h-14 w-full items-center gap-3 rounded-2xl border border-accent/35 bg-accent/10 px-4 text-left transition-colors hover:bg-accent/15"
          aria-label="Search Assets"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/15 text-accent">
            <Search className="h-5 w-5" aria-hidden={true} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-sm font-semibold text-foreground">Search Assets</span>
            <span className="mt-0.5 block truncate text-xs text-muted-foreground">Choose a blockchain, then find a token</span>
          </span>
          <ChevronRight className="h-5 w-5 shrink-0 text-accent" aria-hidden={true} />
        </button>
      </DrawerTrigger>

      <DrawerContent className="h-[92dvh] max-h-[92dvh] overflow-hidden rounded-t-3xl border-border/80">
        <DrawerHeader className="shrink-0 border-b border-border/60 px-5 pb-4 pt-5 text-left">
            <div className="flex items-start justify-between gap-3">
            <div>
              <DrawerTitle className="text-xl tracking-tight">Search Assets</DrawerTitle>
              <DrawerDescription className="mt-1">Choose a blockchain before searching for an asset.</DrawerDescription>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <button
                type="button"
                className="paxi-icon-button"
                aria-label="Back from asset search"
                onClick={() => selectedNetwork ? setSelectedNetwork(null) : setOpen(false)}
              >
                <ChevronLeft className="h-4 w-4" aria-hidden={true} />
              </button>
              <DrawerClose asChild>
                <button type="button" className="paxi-icon-button" aria-label="Close asset search">
                  <X className="h-4 w-4" aria-hidden={true} />
                </button>
              </DrawerClose>
            </div>
          </div>
        </DrawerHeader>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-[calc(1.5rem+env(safe-area-inset-bottom))] pt-5">
          <section aria-labelledby="asset-search-network-heading">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 id="asset-search-network-heading" className="text-sm font-semibold text-foreground">Choose Blockchain</h2>
              {selectedNetwork && (
                <button
                  type="button"
                  onClick={() => { setSelectedNetwork(null); setQuery(''); }}
                  className="text-xs font-medium text-accent"
                >
                  Change
                </button>
              )}
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              {networkEntries.map((network) => {
                const selected = selectedNetwork === network.id;
                return (
                  <button
                    key={network.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => { setSelectedNetwork(network.id); setQuery(''); }}
                    className={`paxi-pressable flex min-h-[4.5rem] items-center gap-3 rounded-2xl border px-3.5 py-3 text-left transition-colors ${selected ? 'border-accent bg-accent/12' : 'border-border/70 bg-secondary/35 hover:bg-secondary/70'}`}
                  >
                    <AssetLogo src={network.iconUrl} fallback={network.nativeSymbol} size="md" cacheKey={`network:${network.id}`} aria-hidden={true} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-foreground">{network.label}</span>
                      <span className="mt-0.5 block text-[11px] text-muted-foreground">
                        {network.chainType === 'evm' ? `EVM${network.chainId ? ` · Chain ID ${network.chainId}` : ''}` : network.chainType === 'sol' ? 'Solana network' : 'Bitcoin network'}
                      </span>
                    </span>
                    {selected && <Check className="h-4 w-4 shrink-0 text-accent" aria-label="Selected" />}
                  </button>
                );
              })}
            </div>
          </section>

          {selectedNetwork && (
            <section className="mt-6" aria-labelledby="asset-search-field-heading">
              <h2 id="asset-search-field-heading" className="mb-3 text-sm font-semibold text-foreground">Search {selectedNetworkLabel} assets</h2>
              <label className="relative block">
                <span className="sr-only">Search by name, symbol, contract or mint</span>
                  <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden={true} />
                <input
                  autoFocus
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search by name, symbol, contract or mint"
                  aria-label="Search by name, symbol, contract or mint"
                  className="paxi-field w-full py-3 pl-10 pr-10 text-sm text-foreground placeholder:text-muted-foreground outline-none"
                />
                {query && (
                  <button type="button" onClick={() => setQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-muted-foreground hover:text-foreground" aria-label="Clear asset search">
                    <X className="h-4 w-4" aria-hidden={true} />
                  </button>
                )}
              </label>

              {hasSearch && (
                <div className="mt-4 space-y-2" aria-live="polite">
                  {(isFetching || hasPendingSearch) && (
                    <p className="flex items-center gap-2 px-1 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Searching {selectedNetworkLabel} assets…</p>
                  )}
                  {localMatches.map((asset) => (
                    <button
                      key={`local:${assetKey(asset)}`}
                      type="button"
                      onClick={() => { onSelectAsset(asset, balances[assetKey(asset)]); setOpen(false); }}
                      className="paxi-pressable flex min-h-16 w-full items-center gap-3 rounded-2xl border border-border/70 bg-secondary/25 px-3.5 py-3 text-left transition-colors hover:bg-secondary/70"
                    >
                      <AssetLogo src={asset.iconUrl} fallback={asset.icon} size="md" cacheKey={`asset:${assetKey(asset)}`} aria-hidden={true} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2 text-sm font-semibold text-foreground"><span>{asset.symbol}</span><span className="paxi-status bg-accent/12 px-1.5 py-0.5 text-[9px] text-accent">In wallet</span></span>
                        <span className="mt-0.5 block truncate text-xs text-muted-foreground">{asset.name} · {NETWORKS[asset.network]?.label ?? asset.network}</span>
                        {asset.contractAddress && <span className="mt-0.5 block truncate font-mono text-[10px] text-muted-foreground/70">{shortenCanonicalIdentifier(asset.contractAddress)}</span>}
                      </span>
                      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden={true} />
                    </button>
                  ))}
                  {providerMatches.map((result) => {
                    const canonical = searchResultToCanonicalToken(result);
                    const sourceLabel = result.sources?.length
                      ? result.sources.join(', ')
                      : result.source ?? 'Unavailable';
                    return (
                    <button
                      key={`provider:${result.chain}:${result.contractAddress ?? result.coinId ?? result.id}`}
                      type="button"
                      disabled={!result.chain || !result.contractAddress}
                      onClick={() => { if (result.chain && result.contractAddress) { onAddToken({ networkId: result.chain, contractAddress: result.contractAddress, logoUrl: result.image ?? undefined, source: result.source, sources: result.sources, fieldSources: result.fieldSources }); setOpen(false); } }}
                      className="paxi-pressable flex min-h-16 w-full items-center gap-3 rounded-2xl border border-border/70 bg-secondary/25 px-3.5 py-3 text-left transition-colors hover:bg-secondary/70 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <AssetLogo src={result.image} fallback={result.symbol?.slice(0, 3) || '?'} size="md" cacheKey={`market:${result.chain}:${result.contractAddress ?? result.coinId ?? result.id}`} aria-hidden={true} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-foreground">{result.symbol || 'Unknown token'}</span>
                        <span className="mt-0.5 block truncate text-xs text-muted-foreground">{canonical?.name ?? result.name ?? 'Unknown token'} · {selectedNetworkLabel}</span>
                        {result.contractAddress && <span className="mt-0.5 block truncate font-mono text-[10px] text-muted-foreground/70">{shortenCanonicalIdentifier(result.contractAddress)}</span>}
                        <span className="mt-0.5 block truncate text-[10px] text-muted-foreground/70">{result.currentPrice != null ? formatFiat(result.currentPrice, currency, fiatRate) : 'Price unavailable'} · 24h {result.priceChangePercent24h != null ? `${result.priceChangePercent24h >= 0 ? '+' : ''}${result.priceChangePercent24h.toFixed(2)}%` : 'unavailable'}</span>
                        <span className="mt-0.5 block truncate text-[10px] text-muted-foreground/70">Liquidity {result.liquidity != null ? formatFiat(result.liquidity, currency, fiatRate) : 'unavailable'} · Chart unavailable · ${sourceLabel} · Security {result.securityStatus === 'available' ? 'available' : 'unavailable'}</span>
                      </span>
                      <span className="text-xs font-semibold text-accent">Add</span>
                    </button>
                    );
                  })}
                  {!isFetching && !hasPendingSearch && localMatches.length === 0 && providerMatches.length === 0 && (
                    <div className="rounded-2xl border border-dashed border-border/80 px-4 py-8 text-center">
                      <p className="text-sm font-medium text-foreground">No assets found</p>
                      <p className="mt-1 text-xs text-muted-foreground">Try another name, symbol, contract, or mint on {selectedNetworkLabel}.</p>
                    </div>
                  )}
                </div>
              )}
            </section>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

export function AssetSearchValue({ value, usdPrice, currency, fiatRate }: { value: number | null; usdPrice: number | null; currency: import('@/lib/currency').FiatCurrency; fiatRate: number | null }) {
  if (value == null || usdPrice == null) return '—';
  return formatFiat(value * usdPrice, currency, fiatRate);
}
