import { Wallet, LineChart, ArrowLeftRight, Compass, User } from 'lucide-react';
import { useI18n } from '@/lib/i18n';

export type NavTab = 'assets' | 'markets' | 'trade' | 'discover' | 'me';

interface BottomNavProps {
  active: NavTab;
  onNavigate: (tab: NavTab) => void;
}

const TAB_KEYS: Array<{ id: NavTab; key: string; icon: typeof Wallet }> = [
  { id: 'assets', key: 'nav_assets', icon: Wallet },
  { id: 'markets', key: 'nav_markets', icon: LineChart },
  { id: 'trade', key: 'nav_trade', icon: ArrowLeftRight },
  { id: 'discover', key: 'nav_discover', icon: Compass },
  { id: 'me', key: 'nav_me', icon: User },
];

/**
 * Fixed bottom tab bar, shared by every top-level screen. Markets/Trade/
 * Discover are stubs for now ("coming soon") - Assets (the existing
 * Dashboard) and Me are the two fully wired tabs, per what was asked for
 * first. Keeping all 5 tabs visible now (rather than adding them one at a
 * time) so the nav shape doesn't shift under the user as more gets built.
 */
export default function BottomNav({ active, onNavigate }: BottomNavProps) {
  const { t } = useI18n();
  return (
    <nav aria-label="Primary navigation" className="fixed bottom-0 left-0 right-0 z-50 border-t border-foreground/10 bg-background/90 backdrop-blur-xl paxi-safe-bottom">
      <div className="mx-auto grid max-w-md grid-cols-5 gap-1 px-2 py-2">
        {TAB_KEYS.map(({ id, key, icon: Icon }) => {
          const isActive = active === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              aria-current={isActive ? 'page' : undefined}
              className="paxi-pressable relative flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-xl py-1.5 text-[11px] transition-colors hover:bg-foreground/5"
            >
              <span
                className={`absolute inset-x-1.5 inset-y-0 rounded-xl bg-accent/10 transition-all duration-300 ease-out ${
                  isActive ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
                }`}
              />
              <Icon
                className={`w-5 h-5 relative transition-all duration-300 ease-out ${
                  isActive ? 'text-accent scale-110 -translate-y-0.5' : 'text-muted-foreground scale-100'
                }`}
              />
              <span
                className={`relative transition-all duration-300 ${
                  isActive ? 'text-accent font-semibold' : 'text-muted-foreground font-medium'
                }`}
              >
                {t(key)}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
