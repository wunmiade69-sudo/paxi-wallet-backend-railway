import { useState } from 'react';
import { ChevronDown, Check, AlertTriangle, Globe2 } from 'lucide-react';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import type { NetworkConfig } from '@/lib/wallet/chains';

const CHAIN_GLYPH: Record<string, string> = {
  ethereum: 'Ξ',
  bsc: 'B',
  bitcoin: '₿',
  solana: 'S',
};

/** Real chain logo when available (see NETWORKS[x].iconUrl in chains.ts), falling back to the
 * text glyph above if the image 404s/fails to load - same pattern AssetIcon uses for tokens. */
function NetworkGlyph({ network, size = 28 }: { network: NetworkConfig; size?: number }) {
  const [failed, setFailed] = useState(false);
  if (network.iconUrl && !failed) {
    return (
      <img
        src={network.iconUrl}
        alt={network.label}
        onError={() => setFailed(true)}
        className="rounded-full bg-foreground/5 object-contain shrink-0"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <span
      className="rounded-full bg-foreground/5 flex items-center justify-center shrink-0 font-semibold text-accent"
      style={{ width: size, height: size, fontSize: size * 0.45 }}
    >
      {CHAIN_GLYPH[network.id] ?? network.label.charAt(0)}
    </span>
  );
}

interface NetworkPickerDrawerProps {
  label: string;
  networks: NetworkConfig[];
  selected: NetworkConfig | undefined;
  disabledIds?: string[];
  onSelect: (id: string) => void;
  /** Optional footer action, e.g. "+ Add a custom network" */
  footer?: React.ReactNode;
  /** Called when the footer is activated; the picker closes before the action runs. */
  onFooterInteract?: () => void;
  /** Optional explicit all-networks choice for filters that support it. */
  allLabel?: string;
  onSelectAll?: () => void;
}

export default function NetworkPickerDrawer({ label, networks, selected, disabledIds = [], onSelect, footer, onFooterInteract, allLabel = 'All networks', onSelectAll }: NetworkPickerDrawerProps) {
  const [open, setOpen] = useState(false);

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <button
          type="button"
          className="w-full flex items-center gap-2.5 bg-secondary hover:bg-muted border border-border rounded-lg px-3 py-3 transition-colors"
          aria-label={`${label}: ${selected?.label ?? (onSelectAll ? allLabel : 'choose network')}`}
        >
          {selected ? <NetworkGlyph network={selected} size={24} /> : onSelectAll ? <Globe2 className="h-5 w-5 shrink-0 text-accent" aria-hidden="true" /> : null}
          <span className="text-foreground font-medium text-sm flex-1 text-left truncate">
            {selected?.label ?? (onSelectAll ? allLabel : 'Select network')}
          </span>
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
        </button>
      </DrawerTrigger>
      <DrawerContent className="max-h-[85dvh] overflow-hidden rounded-t-3xl border-border/80">
        <DrawerHeader className="shrink-0 border-b border-border/60 text-left">
          <DrawerTitle>{label}</DrawerTitle>
        </DrawerHeader>
        <div className="min-h-0 max-h-[62dvh] overflow-y-auto overscroll-contain px-2 pb-2 touch-pan-y">
          {onSelectAll && (
            <button
              type="button"
              data-network-id="all"
              aria-pressed={!selected}
              onClick={() => {
                onSelectAll();
                setOpen(false);
              }}
              className={`paxi-pressable mb-1 flex min-h-[4.25rem] w-full items-center gap-3 rounded-xl border px-3.5 py-3 text-left transition-colors ${
                !selected ? 'border-accent bg-accent/10' : 'border-transparent hover:bg-foreground/5'
              }`}
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent/10 text-accent">
                <Globe2 className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-foreground">{allLabel}</span>
                <span className="block truncate text-xs text-muted-foreground">All supported networks</span>
              </span>
              {!selected && <Check className="h-4 w-4 shrink-0 text-accent" aria-hidden="true" />}
            </button>
          )}
          {networks.map((n) => {
            const isDisabled = disabledIds.includes(n.id);
            const isSelected = n.id === selected?.id;
            return (
              <button
                key={n.id}
                type="button"
                data-network-id={n.id}
                aria-pressed={isSelected}
                disabled={isDisabled}
                onClick={() => {
                  onSelect(n.id);
                  setOpen(false);
                }}
                className={`paxi-pressable mb-1 flex min-h-[4.25rem] w-full items-center gap-3 rounded-xl border px-3.5 py-3 text-left transition-colors ${
                  isSelected ? 'border-accent bg-accent/10' : 'border-transparent hover:bg-foreground/5'
                } ${isDisabled ? 'cursor-not-allowed opacity-40' : ''}`}
              >
                <NetworkGlyph network={n} size={32} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm truncate">{n.label}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {n.chainType.toUpperCase()}
                    {n.chainId ? ` · Chain ID ${n.chainId}` : ''}
                  </p>
                </div>
                {isDisabled && !isSelected && <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0" />}
                {isSelected && <Check className="w-4 h-4 text-accent shrink-0" />}
              </button>
            );
          })}
        </div>
        {footer && (
          <div
            className="shrink-0 border-t border-border/60 px-4 pb-[calc(1rem+env(safe-area-inset-bottom))] pt-3"
            onClickCapture={() => {
              setOpen(false);
              onFooterInteract?.();
            }}
          >
            {footer}
          </div>
        )}
      </DrawerContent>
    </Drawer>
  );
}

export { NetworkGlyph };
