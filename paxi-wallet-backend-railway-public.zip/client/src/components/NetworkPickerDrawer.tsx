import { useState } from 'react';
import { ChevronDown, Check, AlertTriangle } from 'lucide-react';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import type { NetworkConfig } from '@/lib/wallet/chains';

const CHAIN_GLYPH: Record<string, string> = {
  ethereum: 'Ξ',
  bsc: 'B',
  bitcoin: '₿',
  solana: 'S',
};

/** Real chain logo when available (see NETWORKS[x].iconUrl in chains.ts), falling back to the
 * text glyph above if the image 404s/fails to load - same pattern AssetIcon uses for tokens. */
function NetworkGlyph({ network, size = 28 }: { network: NetworkConfig; size?: number }) {
  const [failed, setFailed] = useState(false);
  if (network.iconUrl && !failed) {
    return (
      <img
        src={network.iconUrl}
        alt={network.label}
        onError={() => setFailed(true)}
        className="rounded-full bg-foreground/5 object-contain shrink-0"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <span
      className="rounded-full bg-foreground/5 flex items-center justify-center shrink-0 font-semibold text-accent"
      style={{ width: size, height: size, fontSize: size * 0.45 }}
    >
      {CHAIN_GLYPH[network.id] ?? network.label.charAt(0)}
    </span>
  );
}

interface NetworkPickerDrawerProps {
  label: string;
  networks: NetworkConfig[];
  selected: NetworkConfig | undefined;
  disabledIds?: string[];
  onSelect: (id: string) => void;
  /** Optional footer action, e.g. "+ Add a custom network" */
  footer?: React.ReactNode;
}

export default function NetworkPickerDrawer({ label, networks, selected, disabledIds = [], onSelect, footer }: NetworkPickerDrawerProps) {
  const [open, setOpen] = useState(false);

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <button
          type="button"
          className="w-full flex items-center gap-2.5 bg-secondary hover:bg-muted border border-border rounded-lg px-3 py-3 transition-colors"
          aria-label={`${label}: ${selected?.label ?? 'choose network'}`}
        >
          {selected && <NetworkGlyph network={selected} size={24} />}
          <span className="text-foreground font-medium text-sm flex-1 text-left truncate">
            {selected?.label ?? 'Select network'}
          </span>
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
        </button>
      </DrawerTrigger>
      <DrawerContent className="max-h-[75vh]">
        <DrawerHeader className="text-left">
          <DrawerTitle>{label}</DrawerTitle>
        </DrawerHeader>
        <div className="overflow-y-auto px-2 pb-2">
          {networks.map((n) => {
            const isDisabled = disabledIds.includes(n.id);
            const isSelected = n.id === selected?.id;
            return (
              <button
                key={n.id}
                type="button"
                disabled={isDisabled}
                onClick={() => {
                  onSelect(n.id);
                  setOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left transition-colors ${
                  isDisabled ? 'opacity-40 cursor-not-allowed' : 'hover:bg-foreground/5'
                }`}
              >
                <NetworkGlyph network={n} size={32} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-sm truncate">{n.label}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {n.chainType.toUpperCase()}
                    {n.chainId ? ` · Chain ID ${n.chainId}` : ''}
                  </p>
                </div>
                {isDisabled && !isSelected && <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0" />}
                {isSelected && <Check className="w-4 h-4 text-accent shrink-0" />}
              </button>
            );
          })}
        </div>
        {footer && <div className="px-4 pb-4 pt-1 border-t border-white/5">{footer}</div>}
      </DrawerContent>
    </Drawer>
  );
}

export { NetworkGlyph };
