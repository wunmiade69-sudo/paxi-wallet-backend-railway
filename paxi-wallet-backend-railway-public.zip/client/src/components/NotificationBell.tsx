import { Bell } from 'lucide-react';
import { useEffect, useState } from 'react';
import { getNotifications, subscribeToNotifications } from '@/lib/phase3Local';

interface NotificationBellProps {
  onOpen: () => void;
  label?: string;
}

/**
 * Shared top-level notification entry point. The badge is derived from the
 * persisted notification store, so it cannot claim unread state from a
 * provider or from a transient screen-local counter.
 */
export default function NotificationBell({ onOpen, label = 'Open notifications' }: NotificationBellProps) {
  const [unreadCount, setUnreadCount] = useState(() => getNotifications().filter((notification) => !notification.read).length);

  useEffect(() => {
    const refresh = () => setUnreadCount(getNotifications().filter((notification) => !notification.read).length);
    return subscribeToNotifications(refresh);
  }, []);

  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label={unreadCount > 0 ? `${label}, ${unreadCount} unread` : label}
      className="paxi-icon-button relative flex items-center justify-center border border-border/70 bg-secondary/45 text-muted-foreground transition-colors hover:border-accent/30 hover:bg-foreground/5 hover:text-foreground"
    >
      <Bell className="h-5 w-5" aria-hidden={true} />
      {unreadCount > 0 && (
        <span
          aria-hidden={true}
          className="absolute -right-0.5 -top-0.5 flex min-h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[9px] font-bold leading-none text-accent-foreground"
        >
          {unreadCount > 99 ? '99+' : unreadCount}
        </span>
      )}
    </button>
  );
}

export type { NotificationBellProps };
