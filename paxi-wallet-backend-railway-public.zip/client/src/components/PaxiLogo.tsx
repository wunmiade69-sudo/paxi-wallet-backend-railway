import { useState } from 'react';
import { PAXI_LOGO_URL } from '@/lib/appInfo';

interface PaxiLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'hero';
  className?: string;
  priority?: boolean;
}

const SIZE_CLASSES: Record<NonNullable<PaxiLogoProps['size']>, string> = {
  sm: 'h-8 w-8',
  md: 'h-12 w-12',
  lg: 'h-20 w-20',
  hero: 'h-36 w-36 sm:h-44 sm:w-44',
};

export default function PaxiLogo({ size = 'md', className = '', priority = false }: PaxiLogoProps) {
  const [failed, setFailed] = useState(false);
  const sizeClass = SIZE_CLASSES[size];

  if (failed) {
    return (
      <div
        className={`${sizeClass} ${className} flex items-center justify-center rounded-full border border-accent/70 bg-[#080808] text-accent shadow-[0_0_36px_rgba(245,158,11,0.22)]`}
        aria-label="PAXI logo"
        role="img"
      >
        <span className="text-[0.62em] font-black tracking-[0.22em]">PAXI</span>
      </div>
    );
  }

  return (
    <div
      className={`${sizeClass} ${className} overflow-hidden rounded-full border border-accent/70 bg-[#080808] p-1 shadow-[0_0_36px_rgba(245,158,11,0.22)]`}
    >
      <img
        src={PAXI_LOGO_URL}
        alt="PAXI logo"
        className="h-full w-full rounded-full object-contain"
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        onError={() => setFailed(true)}
      />
    </div>
  );
}
