interface PaxiLogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  priority?: boolean;
}

export default function PaxiLogo({ size = 'md', className = '', priority }: PaxiLogoProps) {
  const dim = size === 'sm' ? 36 : size === 'md' ? 48 : 64;
  return (
    <div
      className={`flex items-center justify-center rounded-xl bg-primary/10 ring-1 ring-primary/20 ${className}`}
      style={{ width: dim, height: dim }}
    >
      <img
        src="/paxi-logo.svg"
        alt="PAXI"
        width={dim}
        height={dim}
        className="h-full w-full object-contain p-1"
        onError={(e) => {
          const target = e.target as HTMLImageElement;
          target.style.display = 'none';
          const parent = target.parentElement;
          if (parent) {
            parent.innerHTML = `<span class="text-primary font-black" style="font-size:${Math.floor(dim * 0.4)}px">P</span>`;
          }
        }}
      />
    </div>
  );
}
