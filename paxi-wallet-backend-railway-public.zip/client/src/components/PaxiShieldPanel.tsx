import {
  AlertTriangle,
  Check,
  HelpCircle,
  ShieldAlert,
  ShieldCheck,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

interface PaxiShieldPanelProps {
  network: string;
  contractAddress?: string;
  isNative?: boolean;
  targetType?: "contract" | "address" | "transaction" | "approval" | "dapp";
  target?: string;
  intendedAmount?: number;
  tokenAddress?: string;
}

type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "UNKNOWN";

function riskTone(
  riskLevel?: RiskLevel
): "safe" | "checking" | "unknown" | "risk" {
  if (riskLevel === "HIGH") return "risk";
  if (riskLevel === "LOW") return "safe";
  if (riskLevel === "MEDIUM" || riskLevel === "UNKNOWN") return "unknown";
  return "checking";
}

function riskLabel(riskLevel?: RiskLevel): string {
  if (!riskLevel) return "Checking security";
  if (riskLevel === "LOW") return "Low risk";
  if (riskLevel === "MEDIUM") return "Medium risk";
  if (riskLevel === "HIGH") return "High risk";
  return "Unknown risk";
}

export function SecurityStatusBadge({
  network,
  contractAddress,
  isNative,
  targetType = "contract",
  target,
  intendedAmount,
  tokenAddress,
}: PaxiShieldPanelProps) {
  const scanTarget = target ?? contractAddress ?? "";
  const { data, isLoading } = trpc.security.scan.useQuery(
    { targetType, network, target: scanTarget, intendedAmount, tokenAddress },
    { enabled: !isNative && !!scanTarget }
  );

  if (isNative) return <StatusLine tone="unknown" label="Native asset" />;
  if (isLoading)
    return <StatusLine tone="checking" label="Checking security" />;
  return (
    <StatusLine
      tone={riskTone(data?.riskLevel as RiskLevel | undefined)}
      label={riskLabel(data?.riskLevel as RiskLevel | undefined)}
    />
  );
}

function StatusLine({
  tone,
  label,
}: {
  tone: "safe" | "checking" | "unknown" | "risk";
  label: string;
}) {
  const styles = {
    safe: "border-emerald-400/20 bg-emerald-400/10 text-emerald-300",
    checking: "border-white/10 bg-white/[0.04] text-muted-foreground",
    unknown: "border-amber-400/20 bg-amber-400/10 text-amber-300",
    risk: "border-red-400/20 bg-red-400/10 text-red-300",
  }[tone];
  const dot = {
    safe: "bg-emerald-400",
    checking: "bg-white/40",
    unknown: "bg-amber-400",
    risk: "bg-red-400",
  }[tone];
  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-[11px] font-semibold tracking-wide ${styles}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} aria-hidden="true" />
      {label}
    </span>
  );
}

export function PaxiShieldPanel({
  network,
  contractAddress,
  isNative,
  targetType = "contract",
  target,
  intendedAmount,
  tokenAddress,
}: PaxiShieldPanelProps) {
  const scanTarget = target ?? contractAddress ?? "";
  const { data, isLoading } = trpc.security.scan.useQuery(
    { targetType, network, target: scanTarget, intendedAmount, tokenAddress },
    { enabled: !isNative && !!scanTarget }
  );

  if (isNative) return null;
  const riskLevel = data?.riskLevel as RiskLevel | undefined;
  const indicators = data?.indicators ?? [];
  const warnings = data?.warnings ?? [];

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-4 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-accent/20 bg-accent/10">
            {riskLevel === "HIGH" ? (
              <ShieldAlert className="h-4 w-4 text-red-300" />
            ) : riskLevel === "MEDIUM" || riskLevel === "UNKNOWN" ? (
              <AlertTriangle className="h-4 w-4 text-amber-300" />
            ) : (
              <ShieldCheck className="h-4 w-4 text-emerald-300" />
            )}
          </span>
          <div>
            <p className="text-sm font-semibold text-foreground">PAXI Shield</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground">
              Unified security intelligence, not a guarantee
            </p>
          </div>
        </div>
        <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          Security
        </span>
      </div>

      {isLoading ? (
        <p className="text-xs text-muted-foreground">
          Checking contract, provider signals, and PAXI rules…
        </p>
      ) : !data ? (
        <UnknownState />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2">
            <SummaryRow
              label="Risk"
              value={riskLabel(riskLevel)}
              tone={riskTone(riskLevel)}
            />
            <SummaryRow
              label="Confidence"
              value={
                data.confidence === "none"
                  ? "LOW"
                  : data.confidence.toUpperCase()
              }
              tone={data.confidence === "high" ? "safe" : "unknown"}
            />
            <SummaryRow
              label="Score"
              value={data.score == null ? "Unavailable" : `${data.score}/100`}
              tone={riskTone(riskLevel)}
            />
            <SummaryRow
              label="Sources"
              value={
                data.sources.length ? data.sources.join(", ") : "Unavailable"
              }
              tone={data.sources.length ? "safe" : "unknown"}
            />
          </div>

          {indicators.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-foreground">
                Indicators
              </p>
              <div className="space-y-1.5">
                {indicators.map(indicator => (
                  <IndicatorRow key={indicator} label={indicator} />
                ))}
              </div>
            </div>
          )}

          {warnings.length > 0 && (
            <div className="rounded-xl border border-amber-400/20 bg-amber-400/10 px-3 py-2.5 text-[11px] leading-relaxed text-amber-200">
              {warnings[0]}
            </div>
          )}

          <p className="text-[11px] leading-relaxed text-muted-foreground">
            Security assessments are informational and do not guarantee that an
            asset, address, transaction, or dApp is safe.
          </p>
        </>
      )}
    </div>
  );
}

function UnknownState() {
  return (
    <p className="text-xs leading-relaxed text-muted-foreground">
      Risk: UNKNOWN. Insufficient information is available to determine the risk
      reliably. Unknown data is not treated as safe.
    </p>
  );
}

function SummaryRow({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "safe" | "checking" | "unknown" | "risk";
}) {
  const colors = {
    safe: "text-emerald-300",
    checking: "text-muted-foreground",
    unknown: "text-amber-300",
    risk: "text-red-300",
  };
  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.025] px-2.5 py-2">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <p className={`mt-1 text-xs font-semibold ${colors[tone]}`}>{value}</p>
    </div>
  );
}

function IndicatorRow({ label }: { label: string }) {
  const normalized = label.toLowerCase();
  const isNegative =
    /high risk|malicious|honeypot|unlimited|suspicious|spam|blocked|blacklist|rug/.test(
      normalized
    );
  const isUnknown =
    /unknown|unavailable|not configured|insufficient|not provided|not available|unsupported|not confirmed|not returned/.test(
      normalized
    );
  const tone = isNegative
    ? "negative"
    : isUnknown
      ? "unknown"
      : /warning|caution|large approval|unverified/.test(normalized)
        ? "warning"
        : "positive";
  const icon =
    tone === "negative" ? (
      <X className="h-3.5 w-3.5 text-red-300" />
    ) : tone === "warning" ? (
      <AlertTriangle className="h-3.5 w-3.5 text-amber-300" />
    ) : tone === "unknown" ? (
      <HelpCircle className="h-3.5 w-3.5 text-muted-foreground" />
    ) : (
      <Check className="h-3.5 w-3.5 text-emerald-300" />
    );
  const background =
    tone === "negative"
      ? "bg-red-400/10"
      : tone === "warning"
        ? "bg-amber-400/10"
        : tone === "unknown"
          ? "bg-white/[0.06]"
          : "bg-emerald-400/10";
  return (
    <div className="flex min-h-9 items-center gap-2 rounded-xl border border-white/[0.07] bg-white/[0.025] px-2.5 py-2">
      <span
        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${background}`}
      >
        {icon}
      </span>
      <span className="text-[11px] leading-tight text-foreground/75">
        {label}
      </span>
    </div>
  );
}
