import { useEffect, useState } from 'react';
import { Delete, Fingerprint, LockKeyhole, ShieldCheck } from 'lucide-react';
import { authenticateWithBiometric, isBiometricAvailable, registerBiometric } from '@/lib/wallet/biometric';
import { enableBiometricForCurrentSession, getActiveWalletId, isBiometricEnabledOnVault, unlockWithPIN } from '@/lib/wallet/vault';

interface SensitiveExportGateProps {
  open: boolean;
  actionLabel: string;
  onAuthorized: () => void;
  onCancel: () => void;
}

const PIN_LENGTH = 6;

type GateStep = 'pin' | 'device';

/**
 * Two independent local factors for exporting wallet secrets:
 * the wallet PIN plus a platform authenticator assertion (Face ID, Touch ID,
 * Android fingerprint, or the device passkey). The secret is never passed
 * through this component and the gate closes after every authorization.
 */
export default function SensitiveExportGate({ open, actionLabel, onAuthorized, onCancel }: SensitiveExportGateProps) {
  const [pin, setPin] = useState('');
  const [step, setStep] = useState<GateStep>('pin');
  const [error, setError] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [deviceReady, setDeviceReady] = useState(false);
  const [settingUpDevice, setSettingUpDevice] = useState(false);
  const [shake, setShake] = useState(false);

  useEffect(() => {
    if (!open) return;
    setPin('');
    setStep('pin');
    setError('');
    setVerifying(false);
    void Promise.all([isBiometricAvailable(), Promise.resolve(isBiometricEnabledOnVault())]).then(([available, enabled]) => {
      setDeviceReady(available && enabled);
    });
  }, [open]);

  if (!open) return null;

  const fail = (message: string) => {
    setError(message);
    setPin('');
    setShake(true);
    window.setTimeout(() => setShake(false), 420);
  };

  const verifyPin = async (value: string) => {
    setVerifying(true);
    setError('');
    try {
      await unlockWithPIN(value);
      if (!deviceReady) {
        fail('Device authentication is not enabled. Enable biometrics in wallet security before exporting secrets.');
        return;
      }
      setStep('device');
      const ok = await authenticateWithBiometric();
      if (!ok) {
        setStep('pin');
        fail('Device authentication was cancelled or failed. Nothing was revealed.');
        return;
      }
      onAuthorized();
    } catch {
      fail('Incorrect PIN. Nothing was revealed.');
    } finally {
      setVerifying(false);
    }
  };

  const handleKeyPress = (digit: string) => {
    if (verifying || step !== 'pin' || pin.length >= PIN_LENGTH) return;
    const next = pin + digit;
    setPin(next);
    setError('');
    if (next.length === PIN_LENGTH) void verifyPin(next);
  };

  const setupDeviceFactor = async () => {
    setSettingUpDevice(true);
    setError('');
    try {
      const registered = await registerBiometric(`paxi-${getActiveWalletId() ?? 'wallet'}`);
      if (!registered) throw new Error('Device authentication setup was cancelled.');
      await enableBiometricForCurrentSession();
      setDeviceReady(true);
      setStep('device');
      const ok = await authenticateWithBiometric();
      if (!ok) throw new Error('Device authentication was not completed.');
      onAuthorized();
    } catch (error) {
      setStep('pin');
      setError(error instanceof Error ? error.message : 'Could not set up device authentication.');
    } finally {
      setSettingUpDevice(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex flex-col bg-background px-6 py-10" role="dialog" aria-modal="true" aria-label="Authorize sensitive export">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center text-center">
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-accent/25 bg-accent/10">
          {step === 'device' ? <Fingerprint className="h-7 w-7 text-accent" /> : <LockKeyhole className="h-6 w-6 text-accent" />}
        </div>
        <h1 className="text-xl font-bold text-foreground">Two-step export approval</h1>
        <p className="mt-2 max-w-xs text-sm text-muted-foreground">{actionLabel}</p>
        <div className="mt-5 rounded-xl border border-destructive/25 bg-destructive/10 p-3 text-left text-xs text-destructive">
          This action can expose complete control of your funds. PAXI will require your wallet PIN and device authentication every time.
        </div>

        {step === 'pin' ? (
          <>
            <div className={`mt-8 flex justify-center gap-3 ${shake ? 'animate-shake' : ''}`}>
              {Array.from({ length: PIN_LENGTH }, (_, index) => (
                <div key={index} className={`h-3 w-3 rounded-full border transition-all ${index < pin.length ? 'scale-110 border-accent bg-accent shadow-md shadow-accent/40' : 'border-border bg-secondary'} ${error ? 'ring-2 ring-destructive/40' : ''}`} />
              ))}
            </div>
            <p className="mt-4 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">Step 1 of 2 · Wallet PIN</p>
            {error && <p className="mt-4 text-sm font-medium text-destructive">{error}</p>}
            <div className="mt-6 grid w-full max-w-[280px] grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
                <button key={digit} type="button" onClick={() => handleKeyPress(String(digit))} disabled={verifying} className="aspect-square rounded-full border border-border/60 bg-secondary/70 text-xl font-semibold text-foreground transition hover:bg-secondary active:scale-95 disabled:opacity-40">{digit}</button>
              ))}
              <div />
              <button type="button" onClick={() => handleKeyPress('0')} disabled={verifying} className="aspect-square rounded-full border border-border/60 bg-secondary/70 text-xl font-semibold text-foreground transition hover:bg-secondary active:scale-95 disabled:opacity-40">0</button>
              <button type="button" onClick={() => setPin((value) => value.slice(0, -1))} disabled={verifying} className="flex aspect-square items-center justify-center rounded-full text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive disabled:opacity-40"><Delete className="h-5 w-5" /></button>
            </div>
          </>
        ) : (
          <div className="mt-8 rounded-2xl border border-accent/25 bg-accent/5 p-6">
            <Fingerprint className="mx-auto h-10 w-10 animate-pulse text-accent" />
            <p className="mt-4 font-semibold text-foreground">Confirm on this device</p>
            <p className="mt-2 text-sm text-muted-foreground">Complete Face ID, Touch ID, fingerprint, or passkey verification. The secret stays hidden until it succeeds.</p>
          </div>
        )}

        <button type="button" onClick={onCancel} disabled={verifying} className="mt-8 flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground disabled:opacity-40">
          <ShieldCheck className="h-4 w-4" /> Cancel
        </button>
        {!deviceReady && (
          <div className="mt-5 max-w-xs text-center">
            <p className="text-xs text-amber-300">A device authenticator is required as the second factor.</p>
            <button type="button" onClick={() => void setupDeviceFactor()} disabled={settingUpDevice || verifying} className="mt-3 rounded-xl border border-accent/30 bg-accent/10 px-4 py-2 text-xs font-semibold text-accent transition hover:bg-accent/20 disabled:opacity-50">
              {settingUpDevice ? 'Setting up device security…' : 'Set up device authentication'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
