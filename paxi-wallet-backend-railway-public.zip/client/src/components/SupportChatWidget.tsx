import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Loader2, TicketPlus, Check } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

const WELCOME: ChatTurn = {
  role: 'assistant',
  content: "Hi! I'm PAXI AI. Ask me anything about sending, swapping, bridging, or security - or file a ticket below if you need a human.",
};

/** Global floating chat button + panel. Mounted once at the app root. Never asks for or accepts a seed phrase/private key. */
export function SupportChatWidget() {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<'chat' | 'ticket'>('chat');
  const [turns, setTurns] = useState<ChatTurn[]>([WELCOME]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const chatMutation = trpc.support.chat.useMutation({
    onSuccess: (reply) => setTurns((prev) => [...prev, { role: 'assistant', content: reply }]),
    onError: () => setTurns((prev) => [...prev, { role: 'assistant', content: "Sorry, I couldn't respond just now. You can file a support ticket instead." }]),
  });

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [turns, open]);

  const send = () => {
    const trimmed = input.trim();
    if (!trimmed || chatMutation.isPending) return;
    const nextTurns = [...turns, { role: 'user' as const, content: trimmed }];
    setTurns(nextTurns);
    setInput('');
    chatMutation.mutate({ history: nextTurns });
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        aria-label="Open support chat"
        className="fixed bottom-20 right-4 z-40 flex h-12 w-12 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lg shadow-black/30 active:scale-95 transition-transform"
      >
        <MessageCircle className="h-5 w-5" />
      </button>
    );
  }

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 flex justify-center px-3 pb-3 sm:items-end">
      <div className="flex h-[70vh] max-h-[560px] w-full max-w-sm flex-col overflow-hidden rounded-2xl border border-white/10 bg-background shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
          <div>
            <p className="text-sm font-semibold text-foreground">PAXI AI</p>
            <p className="text-[11px] text-muted-foreground">Support assistant · not your private keys</p>
          </div>
          <button onClick={() => setOpen(false)} aria-label="Close support chat" className="rounded-lg p-1.5 text-muted-foreground active:bg-white/[0.06]">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex border-b border-white/10 text-xs font-semibold">
          <button
            onClick={() => setMode('chat')}
            className={`flex-1 py-2.5 ${mode === 'chat' ? 'text-accent border-b-2 border-accent' : 'text-muted-foreground'}`}
          >
            Chat
          </button>
          <button
            onClick={() => setMode('ticket')}
            className={`flex-1 py-2.5 ${mode === 'ticket' ? 'text-accent border-b-2 border-accent' : 'text-muted-foreground'}`}
          >
            File a ticket
          </button>
        </div>

        {mode === 'chat' ? (
          <>
            <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
              {turns.map((turn, i) => (
                <div key={i} className={`flex ${turn.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed ${
                      turn.role === 'user' ? 'bg-accent text-accent-foreground' : 'bg-white/[0.06] text-foreground/90'
                    }`}
                  >
                    {turn.content}
                  </div>
                </div>
              ))}
              {chatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-1.5 rounded-2xl bg-white/[0.06] px-3 py-2 text-xs text-muted-foreground">
                    <Loader2 className="h-3 w-3 animate-spin" /> Typing…
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 border-t border-white/10 p-3">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && send()}
                placeholder="Ask a question…"
                className="flex-1 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-foreground outline-none focus:border-accent/40"
              />
              <button
                onClick={send}
                disabled={chatMutation.isPending || !input.trim()}
                aria-label="Send"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground disabled:opacity-40"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </>
        ) : (
          <TicketForm onClose={() => setOpen(false)} />
        )}
      </div>
    </div>
  );
}

function TicketForm({ onClose }: { onClose: () => void }) {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const submit = trpc.support.submitTicket.useMutation();

  if (submit.isSuccess) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-400/10">
          <Check className="h-5 w-5 text-emerald-300" />
        </span>
        <p className="text-sm font-semibold text-foreground">Ticket #{submit.data.id} submitted</p>
        <p className="text-xs text-muted-foreground">Our team will follow up. You can close this window now.</p>
        <button onClick={onClose} className="mt-2 rounded-xl bg-accent px-4 py-2 text-xs font-semibold text-accent-foreground">Done</button>
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col gap-3 overflow-y-auto px-4 py-3">
      <p className="text-[11px] text-muted-foreground">
        We will never ask for your seed phrase or private key. Don't include them here.
      </p>
      <input
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        placeholder="Subject"
        className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-foreground outline-none focus:border-accent/40"
      />
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Describe the issue…"
        rows={5}
        className="resize-none rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-foreground outline-none focus:border-accent/40"
      />
      <input
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email (optional, for follow-up)"
        className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-foreground outline-none focus:border-accent/40"
      />
      {submit.isError && <p className="text-[11px] text-red-300">Couldn't submit - check the fields and try again.</p>}
      <button
        onClick={() => submit.mutate({ subject, message, contactEmail: email.trim() || undefined })}
        disabled={submit.isPending || subject.trim().length < 3 || message.trim().length < 10}
        className="flex items-center justify-center gap-1.5 rounded-xl bg-accent px-4 py-2.5 text-xs font-semibold text-accent-foreground disabled:opacity-40"
      >
        {submit.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <TicketPlus className="h-3.5 w-3.5" />}
        {submit.isPending ? 'Submitting…' : 'Submit ticket'}
      </button>
    </div>
  );
}
