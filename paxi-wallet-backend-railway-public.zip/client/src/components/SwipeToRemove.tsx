import { useRef, useState } from 'react';
import { Trash2 } from 'lucide-react';

interface SwipeToRemoveProps {
  children: React.ReactNode;
  onRemove: () => void;
  /** Built-in assets can't be removed - render them with no swipe behavior at all. */
  disabled?: boolean;
  removeLabel?: string;
}

const REVEAL_WIDTH = 84; // px width of the red "Remove" panel revealed on swipe

/**
 * Swipe-left-to-reveal-remove, the same interaction pattern as iOS Mail/
 * Messages. Pointer events (not touch-only) so it also works with a mouse
 * drag in desktop browser testing, not just on a real device.
 */
export default function SwipeToRemove({ children, onRemove, disabled, removeLabel = 'Remove' }: SwipeToRemoveProps) {
  const [dragX, setDragX] = useState(0); // 0 = closed, negative = revealed
  const [isDragging, setIsDragging] = useState(false);
  const startX = useRef<number | null>(null);
  const startDragX = useRef(0);
  const pointerId = useRef<number | null>(null);

  if (disabled) return <>{children}</>;

  const clamp = (x: number) => Math.min(0, Math.max(-REVEAL_WIDTH, x));

  const handlePointerDown = (e: React.PointerEvent) => {
    startX.current = e.clientX;
    startDragX.current = dragX;
    pointerId.current = e.pointerId;
    setIsDragging(true);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (startX.current == null || pointerId.current !== e.pointerId) return;
    const delta = e.clientX - startX.current;
    // Only start dragging once movement is clearly horizontal-left intent,
    // so a normal vertical scroll or a tap isn't mistaken for a swipe.
    if (Math.abs(delta) > 4) setDragX(clamp(startDragX.current + delta));
  };

  const endDrag = () => {
    setIsDragging(false);
    startX.current = null;
    pointerId.current = null;
    setDragX((x) => (x < -REVEAL_WIDTH / 2 ? -REVEAL_WIDTH : 0));
  };

  return (
    <div className="relative overflow-hidden rounded-2xl">
      <div className="absolute inset-y-0 right-0 flex items-stretch" style={{ width: REVEAL_WIDTH }}>
        <button
          type="button"
          onClick={() => {
            setDragX(0);
            onRemove();
          }}
          className="flex-1 bg-destructive text-destructive-foreground flex flex-col items-center justify-center gap-1 text-[11px] font-semibold active:opacity-80"
        >
          <Trash2 className="w-4 h-4" />
          {removeLabel}
        </button>
      </div>
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        style={{
          transform: `translateX(${dragX}px)`,
          transition: isDragging ? 'none' : 'transform 200ms ease-out',
          touchAction: 'pan-y',
        }}
        className="relative bg-background"
      >
        {children}
      </div>
    </div>
  );
}
