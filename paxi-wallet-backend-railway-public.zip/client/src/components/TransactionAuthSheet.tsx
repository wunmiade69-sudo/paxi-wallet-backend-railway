import { useEffect, useState } from 'react';
import { Delete, Fingerprint, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { authenticateWithBiometric, isBiometricAvailable } from '@/lib/wallet/biometric';
import { isBiometricEnabledOnVault, unlockWithBiometric, unlockWithPIN } from '@/lib/wallet/vault';

interface TransactionAuthSheetProps {
  open: boolean;
  /** Short description of what's being approved, e.g. "Send 10.5 PAXI" - shown above the PIN dots for context. */
  actionLabel: string;
  onSuccess: () => void;
  onCancel: () => void;
}

const PIN_LENGTH = 6; // matches the wallet's real unlock PIN - see vault.ts

/**
 * Re-confirms the user's identity right before a signing action actually
 * happens, even though the wallet session is already unlocked - the same
 * pattern banking apps use for money movements. Reuses the real wallet PIN
 * (unlockWithPIN/unlockWithBiometric) rather than a separate, weaker code,
 * since introducing a second independent PIN wouldn't actually protect
 * anything additional - the real security boundary is the one already
 * protecting the mnemonic.
 */
export default function TransactionAuthSheet({ open, actionLabel, onSuccess, onCancel }: TransactionAuthSheetProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [shake, setShake] = useState(false);
  const [biometricReady, setBiometricReady] = useState(false);

  useEffect(() => {
    if (!open) return;
    setPin('');
    setError('');
    (async () => {
      const supported = await isBiometricAvailable();
      const enabled = isBiometricEnabledOnVault();
      setBiometricReady(supported && enabled);
      if (supported && enabled) handleBiometric();
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  if (!open) return null;

  const handleKeyPress = (digit: string) => {
    if (pin.length < PIN_LENGTH) {
      setError('');
      const next = pin + digit;
      setPin(next);
      if (next.length === PIN_LENGTH) handlePinSubmit(next);
    }
  };

  const handlePinSubmit = async (fullPin: string) => {
    setVerifying(true);
    setError('');
    try {
      await unlockWithPIN(fullPin);
      onSuccess();
    } catch {
      setError('Incorrect PIN. Please try again.');
      setPin('');
      setShake(true);
      setTimeout(() => setShake(false), 420);
    } finally {
      setVerifying(false);
    }
  };

  const handleBiometric = async () => {
    setError('');
    try {
      const ok = await authenticateWithBiometric();
      if (!ok) return;
      await unlockWithBiometric();
      onSuccess();
    } catch {
      toast.error('Biometric confirmation failed. Enter your PIN instead.');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-background flex flex-col px-6 py-10">
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
        <div className="w-14 h-14 rounded-2xl bg-accent/10 border border-accent/25 flex items-center justify-center mb-4">
          <ShieldCheck className="w-6 h-6 text-accent" strokeWidth={2.25} />
        </div>
        <h1 className="text-xl font-bold text-foreground text-center mb-1">Confirm to continue</h1>
        <p className="text-muted-foreground text-sm text-center mb-8">{actionLabel}</p>

        <div className={`flex justify-center gap-3 mb-8 ${shake ? 'animate-shake' : ''}`}>
          {[...Array(PIN_LENGTH)].map((_, i) => (
            <div
              key={i}
              className={`w-3 h-3 rounded-full transition-all duration-150 ${
                i < pin.length ? 'bg-accent scale-110 shadow-md shadow-accent/40' : 'bg-secondary border border-border'
              } ${error ? 'ring-2 ring-destructive/40' : ''}`}
            />
          ))}
        </div>

        {error && <p className="text-sm text-destructive font-medium mb-4 text-center">{error}</p>}

        <div className="w-full grid grid-cols-3 gap-4 max-w-[280px] mx-auto">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
            <button
              key={digit}
              onClick={() => handleKeyPress(digit.toString())}
              disabled={verifying}
              className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 border border-border/60 text-foreground font-semibold text-xl transition-all duration-100 disabled:opacity-40"
            >
              {digit}
            </button>
          ))}
          {biometricReady ? (
            <button
              onClick={handleBiometric}
              className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 border border-border/60 text-accent transition-all duration-100 flex items-center justify-center"
              title="Confirm with biometrics"
            >
              <Fingerprint className="w-5 h-5" />
            </button>
          ) : (
            <div />
          )}
          <button
            onClick={() => handleKeyPress('0')}
            disabled={verifying}
            className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 border border-border/60 text-foreground font-semibold text-xl transition-all duration-100 disabled:opacity-40"
          >
            0
          </button>
          <button
            onClick={() => setPin(pin.slice(0, -1))}
            disabled={verifying}
            className="aspect-square rounded-full hover:bg-destructive/10 active:scale-95 text-muted-foreground hover:text-destructive transition-all duration-100 disabled:opacity-40 flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        <button
          onClick={onCancel}
          disabled={verifying}
          className="mt-8 text-sm text-muted-foreground hover:text-foreground transition-colors disabled:opacity-40"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
