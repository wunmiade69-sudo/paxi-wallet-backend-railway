import { useMemo, useState } from "react";
import {
  ArrowUpRight,
  ArrowDownToLine,
  RefreshCw,
  ArrowLeftRight,
  ExternalLink,
  Sparkles,
  History,
} from "lucide-react";
import { NETWORKS } from "@/lib/wallet/chains";
import {
  isTxInFlight,
  isTxSuccessful,
  normalizeTxStatus,
  type TxRecord,
  type TxType,
} from "@/lib/wallet/txHistory";
import TransactionReceipt from "./TransactionReceipt";
import { formatWalletAmount } from "@/lib/wallet/amountFormatting";
import {
  convertUsdToFiat,
  formatFiat,
  type FiatCurrency,
  type FiatRates,
} from "@/lib/wallet/fiat";

const TYPE_META: Record<TxType, { label: string; icon: typeof ArrowUpRight }> =
  {
    send: { label: "Send", icon: ArrowUpRight },
    receive: { label: "Receive", icon: ArrowDownToLine },
    swap: { label: "Swap", icon: RefreshCw },
    bridge: { label: "Bridge", icon: ArrowLeftRight },
    create: { label: "Create", icon: Sparkles },
  };

const FILTERS: Array<{ id: "all" | TxType; label: string }> = [
  { id: "all", label: "All" },
  { id: "receive", label: "Receive" },
  { id: "send", label: "Send" },
  { id: "swap", label: "Swap" },
  { id: "bridge", label: "Bridge" },
  { id: "create", label: "Create" },
];

function shortHash(hash: string) {
  return hash.length > 14 ? `${hash.slice(0, 8)}…${hash.slice(-6)}` : hash;
}

/** Raw on-chain amounts can come back as long decimal strings like
 * "0.244986105709800337" - always cap what's displayed so it can never
 * overflow/overlap the row, regardless of how many decimals the source gave us. */
function formatAmount(amount: string | number | undefined): string {
  return amount === undefined ? "?" : formatWalletAmount(amount);
}

/** Short display label for a network, independent of the fuller label used
 * elsewhere in the app (e.g. network pickers) where the long form reads better. */
const SHORT_NETWORK_LABEL: Record<string, string> = {
  ethereum: "ETH",
  bsc: "BSC",
  bitcoin: "BTC",
  solana: "SOL",
};

function formatWhen(ts: number) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  return sameDay
    ? d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })
    : d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

interface TransactionListProps {
  records: TxRecord[];
  showFilters?: boolean;
  emptyTitle?: string;
  emptySubtitle?: string;
  /** Optional: current USD price per symbol, used to show a fiat value under the amount. Omit to hide it entirely. */
  prices?: Record<string, number>;
  currency?: FiatCurrency;
  fiatRates?: FiatRates;
}

const STATUS_BADGE: Record<
  ReturnType<typeof normalizeTxStatus>,
  { label: string; className: string }
> = {
  unknown: { label: "Unknown", className: "bg-slate-400/15 text-slate-300" },
  created: { label: "Created", className: "bg-slate-400/15 text-slate-300" },
  validating: {
    label: "Validating",
    className: "bg-amber-400/15 text-amber-400",
  },
  awaiting_signature: {
    label: "Awaiting signature",
    className: "bg-amber-400/15 text-amber-400",
  },
  signed: { label: "Signed", className: "bg-amber-400/15 text-amber-400" },
  submitted: {
    label: "Submitted",
    className: "bg-amber-400/15 text-amber-400",
  },
  pending: { label: "Pending", className: "bg-amber-400/15 text-amber-400" },
  confirmed: {
    label: "Confirmed",
    className: "bg-emerald-400/15 text-emerald-400",
  },
  finalized: {
    label: "Finalized",
    className: "bg-emerald-400/15 text-emerald-400",
  },
  failed: { label: "Failed", className: "bg-red-400/15 text-red-400" },
  reverted: { label: "Reverted", className: "bg-red-400/15 text-red-400" },
  replaced: { label: "Replaced", className: "bg-red-400/15 text-red-400" },
  dropped: { label: "Dropped", className: "bg-red-400/15 text-red-400" },
  reorged: { label: "Reorged", className: "bg-red-400/15 text-red-400" },
  expired: { label: "Expired", className: "bg-red-400/15 text-red-400" },
};

export default function TransactionList({
  records,
  showFilters = true,
  emptyTitle = "No transactions yet",
  emptySubtitle = "Send, swap, or bridge from this wallet and it will show up here.",
  prices,
  currency = "USD",
  fiatRates = {},
}: TransactionListProps) {
  const [filter, setFilter] = useState<"all" | TxType>("all");
  const [selected, setSelected] = useState<TxRecord | null>(null);

  const filtered = useMemo(
    () => (filter === "all" ? records : records.filter(r => r.type === filter)),
    [records, filter]
  );

  return (
    <div className="space-y-3">
      {showFilters && records.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          {FILTERS.map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                filter === f.id
                  ? "bg-accent text-accent-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-12 h-12 rounded-full bg-foreground/5 flex items-center justify-center mx-auto mb-3">
            <History className="w-5 h-5 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground font-medium text-sm">
            {records.length === 0 ? emptyTitle : "No matching transactions"}
          </p>
          {records.length === 0 && (
            <p className="text-xs text-muted-foreground mt-1.5 max-w-xs mx-auto">
              {emptySubtitle}
            </p>
          )}
        </div>
      ) : (
        <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
          {filtered.map((r, i) => {
            const meta = TYPE_META[r.type];
            const Icon = meta.icon;
            const networkLabel =
              SHORT_NETWORK_LABEL[r.networkId] ??
              NETWORKS[r.networkId]?.label ??
              r.networkId;
            const status = normalizeTxStatus(r.status);
            const statusBadge = STATUS_BADGE[status];

            const primaryAmount =
              r.type === "swap" || r.type === "bridge"
                ? { symbol: r.toSymbol ?? "", amount: r.toAmount, sign: "+" }
                : {
                    symbol: r.fromSymbol,
                    amount: r.fromAmount,
                    sign:
                      r.type === "receive"
                        ? "+"
                        : r.type === "create"
                          ? ""
                          : "-",
                  };
            const price = prices?.[primaryAmount.symbol];
            const usdValue =
              price != null && primaryAmount.amount != null
                ? Number(primaryAmount.amount) * price
                : null;
            const fiatValue =
              usdValue != null
                ? convertUsdToFiat(usdValue, currency, fiatRates)
                : null;

            return (
              <button
                key={r.id}
                onClick={() => setSelected(r)}
                style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
                className="animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both w-full flex items-center gap-3 px-4 py-3.5 transition-colors hover:bg-foreground/5 active:bg-foreground/10 text-left"
              >
                <div className="w-9 h-9 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                    <p className="font-semibold text-foreground text-sm shrink-0">
                      {meta.label}
                    </p>
                    <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-secondary text-muted-foreground shrink-0">
                      {networkLabel}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full shrink-0 ${statusBadge.className}`}
                    >
                      {statusBadge.label}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate whitespace-nowrap mt-1">
                    {r.type === "send" && r.counterparty
                      ? `To ${r.counterparty.slice(0, 6)}…${r.counterparty.slice(-4)}`
                      : r.type === "receive" && r.counterparty
                        ? `From ${r.counterparty.slice(0, 6)}…${r.counterparty.slice(-4)}`
                        : r.type === "swap" || r.type === "bridge"
                          ? `${formatAmount(r.fromAmount)} ${r.fromSymbol} → ${formatAmount(r.toAmount)} ${r.toSymbol ?? ""}`
                          : r.type === "create" && r.counterparty
                            ? `Deployed ${r.counterparty.slice(0, 6)}…${r.counterparty.slice(-4)}`
                            : shortHash(r.hash)}
                  </p>
                </div>
                <div className="text-right shrink-0 max-w-[34%]">
                  <p
                    className={`font-semibold text-sm whitespace-nowrap overflow-hidden text-ellipsis ${
                      !isTxSuccessful(status)
                        ? isTxInFlight(status)
                          ? "text-foreground"
                          : "text-muted-foreground line-through"
                        : "text-foreground"
                    }`}
                  >
                    {primaryAmount.sign}
                    {formatAmount(primaryAmount.amount)} {primaryAmount.symbol}
                  </p>
                  {fiatValue != null ? (
                    <p className="text-xs text-muted-foreground whitespace-nowrap">
                      ≈ {formatFiat(fiatValue, currency)}
                    </p>
                  ) : usdValue != null && currency !== "USD" ? (
                    <p className="text-xs text-amber-400 whitespace-nowrap">
                      Rate unavailable
                    </p>
                  ) : null}
                  <div className="flex items-center justify-end gap-1 text-xs text-muted-foreground whitespace-nowrap mt-0.5">
                    {formatWhen(r.timestamp)}
                    {r.explorerUrl && (
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {selected && (
        <TransactionReceipt
          record={selected}
          onClose={() => setSelected(null)}
          primaryActionLabel="Close"
        />
      )}
    </div>
  );
}
