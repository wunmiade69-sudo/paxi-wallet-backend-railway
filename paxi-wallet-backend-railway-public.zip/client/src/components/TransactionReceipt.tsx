import { useState } from 'react';
import { CheckCircle2, Clock, XCircle, Share2, Copy, ExternalLink, Download } from 'lucide-react';
import { toast } from 'sonner';
import { NETWORKS } from '@/lib/wallet/chains';
import PaxiLogo from '@/components/PaxiLogo';
import type { TxRecord } from '@/lib/wallet/txHistory';
import { useTransactionStatus } from '@/hooks/useTransactionStatus';

const TYPE_TITLE: Record<TxRecord['type'], string> = {
  send: 'Send',
  receive: 'Receive',
  swap: 'Swap',
  bridge: 'Bridge',
  create: 'Token Creation',
};

function statusLabel(status: NonNullable<TxRecord['status']>): string {
  return status === 'confirmed' ? 'Successful' : status.charAt(0).toUpperCase() + status.slice(1);
}

/** Named by host rather than parsed generically, since the exact `blockstream.info` vs
 * `explorer.solana.com` naming isn't derivable from the URL shape alone. */
function explorerName(url?: string): string {
  if (!url) return 'Explorer';
  if (url.includes('bscscan')) return 'BscScan';
  if (url.includes('etherscan')) return 'Etherscan';
  if (url.includes('solana')) return 'Solana Explorer';
  if (url.includes('blockstream')) return 'Blockstream';
  return 'Explorer';
}

function formatWhen(ts: number) {
  return new Date(ts).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

function shortAddr(addr: string) {
  return addr.length > 12 ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : addr;
}

function buildShareText(r: TxRecord): string {
  const lines = [
    `Paxi Wallet · ${TYPE_TITLE[r.type]}`,
    `${r.fromAmount} ${r.fromSymbol}${r.toAmount ? ` → ${r.toAmount} ${r.toSymbol ?? ''}` : ''}`,
    `Status: ${statusLabel(r.status ?? 'confirmed')}`,
    `Network: ${NETWORKS[r.networkId]?.label ?? r.networkId}`,
    `Date: ${formatWhen(r.timestamp)}`,
    `Hash: ${r.hash}`,
  ];
  if (r.explorerUrl) lines.push(r.explorerUrl);
  return lines.join('\n');
}

const ACCENT = '#f97316'; // matches the app's --accent orange - kept as a plain hex here since
// canvas fillStyle can't reliably parse the oklch() value the design tokens use.

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawFittedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  initialSize: number,
  color: string,
  align: CanvasTextAlign = 'center',
  weight = 700,
) {
  let size = initialSize;
  ctx.textAlign = align;
  ctx.font = `${weight} ${size}px system-ui, -apple-system, sans-serif`;
  while (size > 14 && ctx.measureText(text).width > maxWidth) {
    size -= 1;
    ctx.font = `${weight} ${size}px system-ui, -apple-system, sans-serif`;
  }
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

/**
 * Draws an actual branded receipt image (the way OPay/Trust Wallet share cards work) rather
 * than just a text summary - built with plain Canvas 2D drawing so no extra dependency is
 * needed. Returns a PNG Blob, or null if canvas rendering isn't available in this browser.
 */
function drawOfficialLogo(ctx: CanvasRenderingContext2D, x: number, y: number, size: number): void {
  // Keep the downloaded image self-contained. A remote canvas image can be
  // blocked by CORS and make PNG export fail, so the receipt uses a crisp
  // vector-style PAXI seal while the in-app view uses the official logo asset.
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, size / 2, 0, Math.PI * 2);
  ctx.fillStyle = '#1a1608';
  ctx.fill();
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x, y, size / 2 - 12, 0, Math.PI * 2);
  ctx.strokeStyle = '#fbbf24aa';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = '#fbbf24';
  ctx.font = '900 48px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('P', x, y + 16);
  ctx.font = '700 14px system-ui, -apple-system, sans-serif';
  ctx.letterSpacing = '4px';
  ctx.fillText('PAXI', x, y + size / 2 - 18);
  ctx.restore();
}

async function generateReceiptImage(r: TxRecord): Promise<Blob | null> {
  const W = 720;
  const H = 1180;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const status = r.status ?? 'confirmed';
  const statusColor = status === 'failed' ? '#f87171' : status === 'pending' ? '#fbbf24' : ACCENT;
  const heading = `${TYPE_TITLE[r.type]} ${statusLabel(status)}`;

  // Background with a restrained document-like frame.
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, '#11100d');
  bg.addColorStop(0.38, '#0b0b0b');
  bg.addColorStop(1, '#070707');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(0, 0, W, 6);

  // Branded receipt header: logo left, document identity center-left, security label right.
  drawOfficialLogo(ctx, 104, 78, 76);
  ctx.textAlign = 'left';
  ctx.fillStyle = '#f97316';
  ctx.font = '800 34px system-ui, -apple-system, sans-serif';
  ctx.fillText('PAXI', 158, 70);
  ctx.fillStyle = '#a3a3a3';
  ctx.font = '600 15px system-ui, -apple-system, sans-serif';
  ctx.fillText('OFFICIAL TRANSACTION RECEIPT', 158, 98);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#9ca3af';
  ctx.font = '600 14px system-ui, -apple-system, sans-serif';
  ctx.fillText('SECURE RECORD', W - 72, 72);
  ctx.fillStyle = statusColor;
  ctx.font = '700 13px system-ui, -apple-system, sans-serif';
  ctx.fillText(statusLabel(status).toUpperCase(), W - 72, 98);
  ctx.strokeStyle = '#f59e0b55';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(72, 132);
  ctx.lineTo(W - 72, 132);
  ctx.stroke();

  // Status hero.
  const cy = 258;
  ctx.beginPath();
  ctx.arc(W / 2, cy, 64, 0, Math.PI * 2);
  ctx.fillStyle = `${statusColor}22`;
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = `${statusColor}66`;
  ctx.stroke();

  ctx.strokeStyle = statusColor;
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (status === 'failed') {
    ctx.beginPath();
    ctx.moveTo(W / 2 - 22, cy - 22);
    ctx.lineTo(W / 2 + 22, cy + 22);
    ctx.moveTo(W / 2 + 22, cy - 22);
    ctx.lineTo(W / 2 - 22, cy + 22);
    ctx.stroke();
  } else if (status === 'pending') {
    ctx.beginPath();
    ctx.arc(W / 2, cy, 26, -Math.PI / 2, Math.PI * 0.6);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(W / 2, cy);
    ctx.lineTo(W / 2, cy - 16);
    ctx.moveTo(W / 2, cy);
    ctx.lineTo(W / 2 + 12, cy + 6);
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.moveTo(W / 2 - 26, cy);
    ctx.lineTo(W / 2 - 6, cy + 22);
    ctx.lineTo(W / 2 + 30, cy - 24);
    ctx.stroke();
  }

  drawFittedText(ctx, heading, W / 2, cy + 96, W - 140, 40, '#f5f5f5');
  drawFittedText(ctx, statusLabel(status).toUpperCase(), W / 2, cy + 128, W - 160, 18, statusColor, 'center', 700);
  drawFittedText(ctx, `${r.fromAmount} ${r.fromSymbol}`, W / 2, cy + 190, W - 150, 50, '#ffffff');
  if (r.toAmount) {
    drawFittedText(ctx, `→ ${r.toAmount} ${r.toSymbol ?? ''}`, W / 2, cy + 232, W - 150, 27, '#9ca3af', 'center', 400);
  }

  // Detail card with a clear section label and responsive values.
  const rows: Array<[string, string]> = [
    ['Status', statusLabel(status)],
    ['Type', TYPE_TITLE[r.type]],
    ['Network', NETWORKS[r.networkId]?.label ?? r.networkId],
    ...(r.counterparty ? [[r.type === 'send' ? 'To' : r.type === 'create' ? 'Contract' : 'From', shortAddr(r.counterparty)] as [string, string]] : []),
    ['Date', formatWhen(r.timestamp)],
    ['Transaction hash', shortAddr(r.hash)],
  ];
  const cardTop = cy + 282;
  const rowH = 62;
  const cardH = rows.length * rowH + 72;
  roundRect(ctx, 56, cardTop, W - 112, cardH, 22);
  ctx.fillStyle = '#171717';
  ctx.fill();
  ctx.strokeStyle = '#ffffff18';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.textAlign = 'left';
  ctx.fillStyle = '#f59e0b';
  ctx.font = '700 14px system-ui, -apple-system, sans-serif';
  ctx.fillText('TRANSACTION DETAILS', 92, cardTop + 42);
  rows.forEach(([label, value], i) => {
    const rowY = cardTop + 86 + rowH * i;
    ctx.textAlign = 'left';
    ctx.font = '400 21px system-ui, -apple-system, sans-serif';
    ctx.fillStyle = '#9ca3af';
    ctx.fillText(label, 92, rowY);
    drawFittedText(ctx, value, W - 92, rowY, 300, 21, '#f5f5f5', 'right', 600);
    if (i < rows.length - 1) {
      ctx.strokeStyle = '#ffffff0d';
      ctx.beginPath();
      ctx.moveTo(92, rowY + 22);
      ctx.lineTo(W - 92, rowY + 22);
      ctx.stroke();
    }
  });

  // Footer
  ctx.textAlign = 'center';
  ctx.font = '700 17px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#f59e0b';
  ctx.fillText('NON-CUSTODIAL · VERIFIED RECORD', W / 2, H - 82);
  ctx.font = '400 16px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#6b7280';
  ctx.fillText('Secured by PAXI Wallet', W / 2, H - 50);

  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), 'image/png', 0.95));
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between px-4 py-3">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-xs font-semibold text-foreground truncate max-w-[60%] text-right">{value}</span>
    </div>
  );
}

function downloadReceiptImage(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

interface TransactionReceiptProps {
  record: TxRecord;
  onClose: () => void;
  /** Shown on the main bottom button - "Done" right after broadcasting, "Close" when reopened from history. */
  primaryActionLabel?: string;
}

/** Full-screen receipt for one transaction - shown right after a successful Send/Swap/Bridge,
 * and again whenever the user taps that transaction later in History. Same component both
 * times so the receipt someone screenshots mid-flow matches what they find later. */
export default function TransactionReceipt({ record: initialRecord, onClose, primaryActionLabel = 'Done' }: TransactionReceiptProps) {
  const { record: liveRecord, isPolling, timedOut } = useTransactionStatus(initialRecord);
  const record = liveRecord ?? initialRecord;
  const status = record.status ?? 'confirmed';
  const StatusIcon = status === 'failed' ? XCircle : status === 'pending' ? Clock : CheckCircle2;
  const statusColor = status === 'failed' ? 'text-destructive' : status === 'pending' ? 'text-amber-400' : 'text-accent';
  const statusRing = status === 'failed' ? 'bg-destructive/10 border-destructive/25' : status === 'pending' ? 'bg-amber-400/10 border-amber-400/25' : 'bg-accent/10 border-accent/25';

  const heading =
    status === 'failed'
      ? `${record.type === 'create' ? 'Token Creation' : TYPE_TITLE[record.type]} Failed`
      : status === 'pending'
        ? `${record.type === 'create' ? 'Token Creation' : TYPE_TITLE[record.type]} Pending`
        : record.type === 'create'
          ? 'Token Created'
          : `${TYPE_TITLE[record.type]} Successful`;

  const [isGenerating, setIsGenerating] = useState(false);

  const handleShare = async () => {
    setIsGenerating(true);
    try {
      const blob = await generateReceiptImage(record);
      const filename = `paxi-receipt-${record.hash.slice(0, 10)}.png`;
      const file = blob ? new File([blob], filename, { type: 'image/png' }) : null;
      const canShareFiles = Boolean(file && typeof navigator.share === 'function' && typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] }));

      if (file && canShareFiles) {
        try {
          await navigator.share({ title: `Paxi Wallet ${TYPE_TITLE[record.type]} Receipt`, files: [file] });
        } catch {
          // User cancelled the native share sheet - not an error.
        }
        return;
      }

      // Some Android WebViews expose navigator.share but reject image files.
      // Preserve the visual receipt by saving the PNG instead of silently
      // downgrading to a text-only share.
      if (blob) {
        downloadReceiptImage(blob, filename);
        toast.success('Image sharing is unavailable here; receipt image saved');
        return;
      }

      // Text is the last-resort path only when canvas/image generation is unavailable.
      const text = buildShareText(record);
      if (typeof navigator.share === 'function') {
        try {
          await navigator.share({ title: `Paxi Wallet ${TYPE_TITLE[record.type]} Receipt`, text });
        } catch {
          /* cancelled */
        }
      } else {
        await navigator.clipboard.writeText(text);
        toast.success('Receipt copied to clipboard');
      }
    } catch {
      toast.error('Could not share the receipt');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    setIsGenerating(true);
    try {
      const blob = await generateReceiptImage(record);
      if (!blob) throw new Error('no canvas support');
      downloadReceiptImage(blob, `paxi-receipt-${record.hash.slice(0, 10)}.png`);
      toast.success('Receipt image saved');
    } catch {
      // Very old browser with no canvas support - a text file still beats nothing.
      const text = buildShareText(record);
      const blob = new Blob([text], { type: 'text/plain' });
      downloadReceiptImage(blob, `paxi-receipt-${record.hash.slice(0, 10)}.txt`);
      toast.success('Receipt saved');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyHash = async () => {
    try {
      await navigator.clipboard.writeText(record.hash);
      toast.success('Transaction hash copied');
    } catch {
      toast.error('Could not copy');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-background overflow-y-auto animate-in fade-in duration-200">
      <div className="max-w-md mx-auto w-full px-6 py-8 flex flex-col items-center text-center min-h-screen">
        <div className="w-full flex items-center justify-between pb-5 mb-7 border-b border-foreground/10">
          <div className="flex items-center gap-3 text-left">
            <PaxiLogo size="sm" priority />
            <div>
              <p className="text-accent font-black tracking-[0.16em] text-sm">PAXI</p>
              <p className="text-[9px] text-muted-foreground font-semibold uppercase tracking-[0.16em]">Official receipt</p>
            </div>
          </div>
          <span className="text-[9px] uppercase tracking-[0.15em] text-muted-foreground">Secure record</span>
        </div>
        <div className={`w-16 h-16 rounded-full border flex items-center justify-center mb-5 ${statusRing} ${statusColor}`}>
          <StatusIcon className="w-8 h-8" strokeWidth={2.25} />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-1">{heading}</h1>

        <p className="text-3xl font-bold text-foreground mt-4 break-all">
          {record.fromAmount} {record.fromSymbol}
        </p>
        {record.toAmount && (
          <p className="text-muted-foreground text-sm mt-1">
            → {record.toAmount} {record.toSymbol}
          </p>
        )}

        {status === 'pending' && (
          <p className="text-amber-400 text-xs mt-3" role="status">
            {isPolling ? 'Waiting for blockchain confirmation…' : timedOut ? "Still pending. We'll continue checking when you reopen your transaction history." : 'Pending'}
          </p>
        )}

        <div className={`w-full mt-7 rounded-2xl border p-4 text-left ${status === 'confirmed' ? 'border-accent/25 bg-accent/5' : status === 'pending' ? 'border-amber-400/25 bg-amber-400/5' : 'border-destructive/25 bg-destructive/5'}`}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Transaction result</p>
              <p className={`text-sm font-semibold mt-1 ${statusColor}`}>{statusLabel(status)}</p>
            </div>
            <span className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">{NETWORKS[record.networkId]?.label ?? record.networkId}</span>
          </div>
          {status === 'confirmed' && <p className="text-xs text-muted-foreground mt-3">The blockchain has confirmed this transaction. Your receipt is ready to save or share.</p>}
          {status === 'pending' && <p className="text-xs text-muted-foreground mt-3">The transaction is still being checked against the blockchain.</p>}
          {status === 'failed' && <p className="text-xs text-muted-foreground mt-3">The blockchain rejected this transaction. No successful transfer was recorded.</p>}
        </div>

        <div className="w-full glass-card mt-8 divide-y divide-white/5 text-left !p-0 overflow-hidden">
          <Row label="Status" value={statusLabel(status)} />
          <Row label="Network" value={NETWORKS[record.networkId]?.label ?? record.networkId} />
          {record.toNetworkId && <Row label="To network" value={NETWORKS[record.toNetworkId]?.label ?? record.toNetworkId} />}
          {record.counterparty && (
            <Row
              label={record.type === 'send' ? 'To' : record.type === 'create' ? 'Contract' : 'From'}
              value={shortAddr(record.counterparty)}
            />
          )}
          {record.feeAmount && <Row label="Network fee" value={`${record.feeAmount} ${record.feeSymbol ?? ''}`} />}
          <Row label="Date" value={formatWhen(record.timestamp)} />
          <button
            onClick={handleCopyHash}
            className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-foreground/5 transition-colors"
          >
            <span className="text-xs text-muted-foreground">Transaction hash</span>
            <span className="text-xs font-mono text-foreground flex items-center gap-1.5 shrink-0">
              {shortAddr(record.hash)}
              <Copy className="w-3 h-3" />
            </span>
          </button>
        </div>

        {record.explorerUrl && (
          <a
            href={record.explorerUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 text-accent text-sm font-medium mt-5"
          >
            View on {explorerName(record.explorerUrl)}
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}

        <div className="w-full grid grid-cols-2 gap-3 mt-8">
          <button
            onClick={handleShare}
            disabled={isGenerating}
            className="flex items-center justify-center gap-2 bg-secondary hover:bg-muted disabled:opacity-60 border border-border rounded-lg py-3 font-semibold text-sm text-foreground transition-colors active:scale-95"
          >
            <Share2 className="w-4 h-4" /> Share
          </button>
          <button
            onClick={handleSave}
            disabled={isGenerating}
            className="flex items-center justify-center gap-2 bg-secondary hover:bg-muted disabled:opacity-60 border border-border rounded-lg py-3 font-semibold text-sm text-foreground transition-colors active:scale-95"
          >
            <Download className="w-4 h-4" /> Save
          </button>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 text-accent-foreground font-semibold rounded-lg py-3 mt-4 transition-all duration-300 transform hover:scale-105 active:scale-95"
        >
          {primaryActionLabel}
        </button>
      </div>
    </div>
  );
}
