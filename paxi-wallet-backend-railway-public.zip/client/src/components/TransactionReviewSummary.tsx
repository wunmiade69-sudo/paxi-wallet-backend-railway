import { ArrowDownLeft, ArrowUpRight, Route, ShieldAlert } from 'lucide-react';

export interface TransactionReviewSummaryProps {
  operation: 'send' | 'swap' | 'bridge';
  network: string;
  fromLabel: string;
  fromAmount: string;
  toLabel?: string;
  toAmount?: string;
  recipient?: string;
  destinationNetwork?: string;
  networkFee?: string;
  serviceFee?: string;
  route?: string;
  estimatedTime?: string;
  minimumReceived?: string;
  slippage?: string;
  approvalScope?: string;
}

function shortAddress(value: string): string {
  return value.length > 18 ? `${value.slice(0, 10)}…${value.slice(-8)}` : value;
}

function Row({ label, value, emphasis = false }: { label: string; value?: string; emphasis?: boolean }) {
  if (!value) return null;
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="text-muted-foreground">{label}</span>
      <span className={`max-w-[64%] text-right ${emphasis ? 'font-semibold text-foreground' : 'text-foreground/90'}`}>{value}</span>
    </div>
  );
}

export default function TransactionReviewSummary({
  operation,
  network,
  fromLabel,
  fromAmount,
  toLabel,
  toAmount,
  recipient,
  destinationNetwork,
  networkFee,
  serviceFee,
  route,
  estimatedTime,
  minimumReceived,
  slippage,
  approvalScope,
}: TransactionReviewSummaryProps) {
  const isSend = operation === 'send';
  const isBridge = operation === 'bridge';
  const title = isSend ? 'What leaves your wallet' : isBridge ? 'Transfer summary' : 'Trade summary';
  return (
    <section className="rounded-2xl border border-white/[0.09] bg-white/[0.035] p-4" aria-label="Transaction effect summary">
      <div className="mb-3 flex items-center gap-2">
        {isSend ? <ArrowUpRight className="h-4 w-4 text-accent" /> : isBridge ? <Route className="h-4 w-4 text-accent" /> : <ArrowDownLeft className="h-4 w-4 text-accent" />}
        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-accent">{title}</p>
      </div>
      <div className="space-y-2.5 text-sm">
        <Row label="From" value={`${fromAmount} ${fromLabel}`} emphasis />
        {!isSend && toLabel && toAmount && <Row label={isBridge ? 'Expected on destination' : 'Expected back'} value={`${toAmount} ${toLabel}`} emphasis />}
        <Row label="Network" value={destinationNetwork ? `${network} → ${destinationNetwork}` : network} />
        {recipient && <Row label={isSend ? 'Recipient' : 'Contract / recipient'} value={shortAddress(recipient)} />}
        <Row label="Network fee" value={networkFee ?? 'Estimate unavailable'} />
        <Row label="PAXI / route fee" value={serviceFee ?? 'None disclosed'} />
        <Row label="Route" value={route} />
        <Row label="Estimated time" value={estimatedTime} />
        <Row label="Minimum received" value={minimumReceived} />
        <Row label="Slippage tolerance" value={slippage} />
        {approvalScope && <Row label="Approval scope" value={approvalScope} />}
      </div>
      <div className="mt-3 flex items-start gap-2 border-t border-white/[0.07] pt-3 text-[11px] leading-4 text-muted-foreground">
        <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-300" aria-hidden="true" />
        <span>Review the destination, network, fees, and expected effect. On-chain transactions cannot be reversed after signing.</span>
      </div>
    </section>
  );
}
