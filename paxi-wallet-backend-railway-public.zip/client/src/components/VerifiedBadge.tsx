import { BadgeCheck } from 'lucide-react';

interface VerifiedBadgeProps {
  label?: string;
  size?: 'sm' | 'md';
  compact?: boolean;
}

export default function VerifiedBadge({ label = 'Verified asset', size = 'sm', compact = false }: VerifiedBadgeProps) {
  const iconClass = size === 'md' ? 'h-4 w-4' : 'h-3.5 w-3.5';
  const textClass = size === 'md' ? 'text-xs' : 'text-[10px]';

  if (compact) {
    return (
      <span title={label} aria-label={label}       className="inline-flex min-h-5 shrink-0 items-center text-sky-300">
        <BadgeCheck className={iconClass} aria-hidden="true" />
      </span>
    );
  }

  return (
    <span
      title={label}
      aria-label={label}
      className={`paxi-status border border-sky-400/25 bg-sky-400/10 text-sky-300 ${textClass}`}
    >
      <BadgeCheck className={iconClass} aria-hidden="true" />
      <span>Verified</span>
    </span>
  );
}
