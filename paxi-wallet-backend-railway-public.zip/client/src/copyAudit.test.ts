import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const productionFiles = [
  'client/src/components/ErrorBoundary.tsx',
  'client/src/pages/AdminScreen.tsx',
  'client/src/pages/AddTokenScreen.tsx',
  'client/src/pages/AddressBookScreen.tsx',
  'client/src/pages/CampaignCreateScreen.tsx',
  'client/src/pages/CampaignDetailScreen.tsx',
  'client/src/pages/CreateTokenScreen.tsx',
  'client/src/pages/DiscoverScreen.tsx',
  'client/src/pages/GiftCodeScreen.tsx',
  'client/src/pages/InviteFriendsScreen.tsx',
  'client/src/pages/ListingSubmitScreen.tsx',
  'client/src/pages/ManageWalletsScreen.tsx',
  'client/src/pages/NotificationsScreen.tsx',
  'client/src/pages/PaxiAISupportScreen.tsx',
  'client/src/pages/SendScreen.tsx',
  'client/src/pages/SettingsScreen.tsx',
  'client/src/pages/SwapPanel.tsx',
  'client/src/pages/TokenDetailScreen.tsx',
  'client/src/pages/Web3BrowserScreen.tsx',
] as const;

const prohibitedCustomerPhrases = [
  /backend configuration/i,
  /database error/i,
  /redis error/i,
  /sql error/i,
  /api endpoint/i,
  /environment variable/i,
  /stack trace/i,
  /internal server error/i,
  /provider configuration/i,
  /tokenFactory\.ts/i,
  /WalletKit/i,
];

describe('production customer copy', () => {
  it('does not expose prohibited implementation phrases in major screens', () => {
    const matches: string[] = [];
    for (const relativePath of productionFiles) {
      const source = readFileSync(resolve(process.cwd(), relativePath), 'utf8');
      for (const pattern of prohibitedCustomerPhrases) {
        if (pattern.test(source)) matches.push(`${relativePath}: ${pattern}`);
      }
    }
    expect(matches).toEqual([]);
  });

  it('does not render an error stack in the recovery boundary', () => {
    const source = readFileSync(resolve(process.cwd(), 'client/src/components/ErrorBoundary.tsx'), 'utf8');
    expect(source).not.toContain('this.state.error?.stack');
    expect(source).toContain('Please reload the app and try again.');
  });
});
