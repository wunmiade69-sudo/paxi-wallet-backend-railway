import { useEffect, useRef, useState } from 'react';

/**
 * Animates a number toward a new target without restarting from an older
 * completed target when several refresh results arrive close together.
 * The underlying value remains the caller-provided target; this hook only
 * controls cosmetic interpolation.
 */
export function useCountUp(target: number, durationMs = 700): number {
  const [display, setDisplay] = useState(target);
  const displayRef = useRef(target);
  const rafRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    const from = displayRef.current;
    const to = target;
    if (from === to) return;

    const start = performance.now();
    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / durationMs, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = from + (to - from) * eased;
      displayRef.current = current;
      setDisplay(current);
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        displayRef.current = to;
      }
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      // Preserve the last rendered interpolation so a new target continues
      // smoothly rather than jumping back to the previous completed target.
      rafRef.current = undefined;
    };
  }, [target, durationMs]);

  return display;
}
