import { useEffect, useState } from "react";
import { resolvePendingStatus } from "@/lib/wallet/txIndexer";
import { isTxInFlight, type TxRecord } from "@/lib/wallet/txHistory";

const POLL_DELAYS_MS = [
  0, 2_000, 4_000, 6_000, 10_000, 15_000, 30_000,
] as const;
const MAX_POLLING_WINDOW_MS = 5 * 60 * 1_000;

export interface TransactionStatusState {
  record: TxRecord | null;
  isPolling: boolean;
  timedOut: boolean;
}

/**
 * Resolves a locally-broadcast transaction quickly while keeping the history
 * resolver as the authoritative recovery layer for later screens and app
 * restarts. The hook stops on confirmed/failed or after five minutes.
 */
export function useTransactionStatus(
  record: TxRecord | null
): TransactionStatusState {
  const [currentRecord, setCurrentRecord] = useState<TxRecord | null>(record);
  const [isPolling, setIsPolling] = useState(false);
  const [timedOut, setTimedOut] = useState(false);

  useEffect(() => {
    let disposed = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const startedAt = Date.now();
    let attempt = 0;

    setCurrentRecord(record);
    setTimedOut(false);
    setIsPolling(Boolean(record && isTxInFlight(record.status)));

    if (!record || !isTxInFlight(record.status)) {
      return () => {
        disposed = true;
        if (timer) clearTimeout(timer);
      };
    }

    const poll = async (): Promise<void> => {
      if (disposed) return;

      const resolved = await resolvePendingStatus(record);
      if (disposed) return;

      setCurrentRecord(resolved);
      if (!isTxInFlight(resolved.status)) {
        setIsPolling(false);
        return;
      }

      const elapsed = Date.now() - startedAt;
      if (elapsed >= MAX_POLLING_WINDOW_MS) {
        setIsPolling(false);
        setTimedOut(true);
        return;
      }

      setIsPolling(true);
      const delay =
        POLL_DELAYS_MS[Math.min(attempt + 1, POLL_DELAYS_MS.length - 1)] ??
        30_000;
      attempt += 1;
      timer = setTimeout(() => {
        void poll();
      }, delay);
    };

    void poll();

    return () => {
      disposed = true;
      if (timer) clearTimeout(timer);
    };
  }, [record?.hash, record?.status, record?.timestamp]);

  return { record: currentRecord, isPolling, timedOut };
}
