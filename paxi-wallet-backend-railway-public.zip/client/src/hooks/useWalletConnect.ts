import { useSyncExternalStore } from 'react';
import { walletConnectManager } from '@/lib/wallet/walletconnect';

/** Subscribes a component to the WalletConnect manager's state (sessions,
 * pending proposal, pending request) so approval UIs re-render the instant
 * a dApp asks for something. */
export function useWalletConnect() {
  useSyncExternalStore(
    (cb) => walletConnectManager.subscribe(cb),
    () => walletConnectManager.version
  );

  return {
    sessions: walletConnectManager.sessions,
    pendingProposal: walletConnectManager.pendingProposal,
    pendingRequest: walletConnectManager.pendingRequest,
    pair: (uri: string) => walletConnectManager.pair(uri),
    approveProposal: () => walletConnectManager.approveProposal(),
    rejectProposal: () => walletConnectManager.rejectProposal(),
    approveRequest: () => walletConnectManager.approveRequest(),
    rejectRequest: () => walletConnectManager.rejectRequest(),
    disconnectSession: (topic: string) => walletConnectManager.disconnectSession(topic),
  };
}
