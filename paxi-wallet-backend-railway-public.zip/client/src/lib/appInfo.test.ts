import { describe, expect, it } from "vitest";
import {
  getAssetLogoUrl,
  getTrustedAssetLabel,
  getTrustedMarketLabel,
  isTrustedAsset,
  normalizePublicUrl,
  PAXI_LOGO_URL,
} from "./appInfo";
import { ASSETS } from "./wallet/chains";

describe("trusted asset verification", () => {
  it("recognizes canonical native assets and PAXI by their exact configured identity", () => {
    expect(
      isTrustedAsset({ symbol: "BNB", network: "bsc", isNative: true })
    ).toBe(true);
    expect(
      isTrustedAsset({ symbol: "BTC", network: "bitcoin", isNative: true })
    ).toBe(true);
    expect(
      isTrustedAsset({
        symbol: "PAXI",
        network: "bsc",
        contractAddress: "0xeda04581461bc308e60052fe489e20c3f78d6e4e",
      })
    ).toBe(true);
  });

  it("recognizes only exact canonical stablecoin contracts and rejects lookalikes", () => {
    expect(
      isTrustedAsset({
        symbol: "USDT",
        network: "ethereum",
        contractAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
      })
    ).toBe(true);
    expect(
      isTrustedAsset({
        symbol: "USDT",
        network: "bsc",
        contractAddress: "0x0000000000000000000000000000000000000001",
      })
    ).toBe(false);
    expect(
      getTrustedAssetLabel({
        symbol: "USDC",
        network: "polygon",
        contractAddress: "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",
      })
    ).toBe("Verified canonical asset");
  });

  it("does not verify or ship Polygon USDT, but still verifies Polygon USDC", () => {
    expect(
      isTrustedAsset({
        symbol: "USDT",
        network: "polygon",
        contractAddress: "0xc2132D05D31c914a87C6611C10748AEb04B58e8",
      })
    ).toBe(false);
    expect(
      ASSETS.some(
        asset => asset.symbol === "USDT" && asset.network === "polygon"
      )
    ).toBe(false);
    expect(
      ASSETS.some(
        asset => asset.symbol === "USDC" && asset.network === "polygon"
      )
    ).toBe(true);
  });

  it("resolves the official PAXI logo from exact identity even when the stored icon is missing", () => {
    expect(
      getAssetLogoUrl({
        symbol: "PAXI",
        network: "bsc",
        contractAddress: "0xeda04581461bc308e60052fe489e20c3f78d6e4e",
      })
    ).toBe(PAXI_LOGO_URL);
    expect(
      getAssetLogoUrl({
        symbol: "PAXI",
        network: "bsc",
        contractAddress: "0x0000000000000000000000000000000000000001",
        iconUrl: "fallback.png",
      })
    ).toBe("fallback.png");
  });

  it("recognizes market assets only from an exact provider id and symbol pair", () => {
    expect(getTrustedMarketLabel({ id: "tether", symbol: "usdt" })).toBe(
      "Verified canonical market asset"
    );
    expect(
      getTrustedMarketLabel({ id: "some-usdt-copy", symbol: "USDT" })
    ).toBeNull();
  });

  it("accepts only explicit HTTP(S) public URLs and removes a trailing slash", () => {
    expect(normalizePublicUrl("https://paxi.example/")).toBe(
      "https://paxi.example"
    );
    expect(normalizePublicUrl("javascript:alert(1)")).toBeUndefined();
    expect(normalizePublicUrl("not-a-url")).toBeUndefined();
    expect(normalizePublicUrl("")).toBeUndefined();
  });
});
