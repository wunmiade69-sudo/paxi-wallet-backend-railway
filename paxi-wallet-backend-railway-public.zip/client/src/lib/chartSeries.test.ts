import { describe, expect, it } from 'vitest';
import {
  hasCompleteOhlc,
  hasSufficientChartData,
  normalizeChartSeries,
} from './chartSeries';

const representativeAssets = [
  { symbol: 'BTC', timestamp: 1_700_000_000_000, price: 42_000 },
  { symbol: 'ETH', timestamp: 1_700_000_060_000, price: 2_200 },
  { symbol: 'SOL', timestamp: 1_700_000_120_000, price: 90 },
  { symbol: 'BNB', timestamp: 1_700_000_180_000, price: 310 },
  { symbol: 'TOKEN', timestamp: 1_700_000_240_000, price: 1.25 },
  { symbol: 'SOL-TOKEN', timestamp: 1_700_000_300_000, price: 0.42 },
] as const;

describe('normalizeChartSeries', () => {
  it('normalizes seconds and milliseconds, rejects malformed points, and sorts chronologically', () => {
    const result = normalizeChartSeries([
      { timestamp: 1_700_000_120, price: '12' },
      { timestamp: 1_700_000_000_000, price: 10 },
      { timestamp: null, price: 999 },
      { timestamp: 'not-a-date', price: 999 },
      { timestamp: 1_700_000_180_000, price: Number.NaN },
      { timestamp: 1_700_000_240_000, price: Number.POSITIVE_INFINITY },
      { timestamp: 1_700_000_300_000, price: 0 },
      { timestamp: 1_700_000_360_000, price: -1 },
    ]);

    expect(result).toHaveLength(2);
    expect(result.map((point) => point.time)).toEqual([1_700_000_000, 1_700_000_120]);
    expect(result.every((point) => Number.isFinite(point.price) && point.price > 0)).toBe(true);
  });

  it('deduplicates timestamps deterministically without creating an extra point', () => {
    const result = normalizeChartSeries([
      { timestamp: 1_700_000_000_000, price: 10 },
      { timestamp: 1_700_000_000_500, price: 11 },
      { timestamp: 1_700_000_060_000, price: 12 },
    ]);

    expect(result).toHaveLength(2);
    expect(result[0]).toMatchObject({ time: 1_700_000_000, price: 11 });
  });

  it('keeps a complete, internally consistent OHLC candle and strips malformed candle fields', () => {
    const result = normalizeChartSeries([
      { timestamp: 1_700_000_000_000, open: 10, high: 13, low: 9, close: 12 },
      { timestamp: 1_700_000_060_000, open: 10, high: 8, low: 9, close: 11 },
    ]);

    expect(hasCompleteOhlc(result[0])).toBe(true);
    expect(hasCompleteOhlc(result[1])).toBe(false);
    expect(result[1]).not.toHaveProperty('open');
    expect(result[1]).not.toHaveProperty('high');
    expect(result[1]).not.toHaveProperty('low');
    expect(result[1]).not.toHaveProperty('close');
  });

  it('returns only real points and exposes insufficient data rather than inviting a fabricated line', () => {
    const result = normalizeChartSeries([{ timestamp: 1_700_000_000_000, price: 10 }]);

    expect(result).toHaveLength(1);
    expect(hasSufficientChartData(result)).toBe(false);
  });

  it('scales display values without changing chronological identity', () => {
    const result = normalizeChartSeries(representativeAssets, 1.1);

    expect(result).toHaveLength(representativeAssets.length);
    expect(result.map((point) => point.time)).toEqual(
      representativeAssets.map((asset) => Math.floor(asset.timestamp / 1000)),
    );
    expect(result[0].price).toBeCloseTo(46_200);
    expect(result[5].price).toBeCloseTo(0.462);
  });
});
