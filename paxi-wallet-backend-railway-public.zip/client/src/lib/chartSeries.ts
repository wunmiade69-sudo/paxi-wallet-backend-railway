export interface ChartSeriesInputPoint {
  timestamp: unknown;
  price?: unknown;
  open?: unknown;
  high?: unknown;
  low?: unknown;
  close?: unknown;
  volume?: unknown;
}

export interface NormalizedChartPoint {
  /** Original chart timestamp in milliseconds. */
  timestamp: number;
  /** Lightweight Charts timestamp in epoch seconds. */
  time: number;
  /** Price in the requested display currency. */
  price: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
  volume?: number;
}

function finitePositiveNumber(value: unknown): number | null {
  const numeric = typeof value === 'number' || typeof value === 'string' ? Number(value) : NaN;
  return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
}

/**
 * Normalize timestamps from provider responses into epoch seconds.
 * Providers commonly return either milliseconds or seconds; invalid and
 * non-positive values are rejected before they can reach a chart scale.
 */
export function toChartEpochSeconds(value: unknown): number | null {
  const numeric = finitePositiveNumber(value);
  if (numeric == null) return null;
  const milliseconds = numeric < 10_000_000_000 ? numeric * 1000 : numeric;
  const seconds = Math.floor(milliseconds / 1000);
  return Number.isFinite(seconds) && seconds > 0 ? seconds : null;
}

function validOhlc(point: { open?: number; high?: number; low?: number; close?: number }): boolean {
  const values = [point.open, point.high, point.low, point.close];
  if (!values.every((value) => value != null && Number.isFinite(value) && value > 0)) return false;
  const open = point.open as number;
  const high = point.high as number;
  const low = point.low as number;
  const close = point.close as number;
  return high >= Math.max(open, close) && low <= Math.min(open, close) && high >= low;
}

/**
 * Convert provider-shaped points into a safe, deterministic chart series.
 * This is intentionally provider-agnostic: the chart only receives valid
 * numeric prices and chronological timestamps, never fabricated points.
 */
export function normalizeChartSeries(
  points: readonly ChartSeriesInputPoint[],
  displayRate = 1,
): NormalizedChartPoint[] {
  if (!Number.isFinite(displayRate) || displayRate <= 0) return [];

  const byTime = new Map<number, NormalizedChartPoint>();
  for (const point of points) {
    const time = toChartEpochSeconds(point.timestamp);
    if (time == null) continue;

    const close = finitePositiveNumber(point.close);
    const price = close ?? finitePositiveNumber(point.price);
    if (price == null) continue;

    const open = finitePositiveNumber(point.open);
    const high = finitePositiveNumber(point.high);
    const low = finitePositiveNumber(point.low);
    const candidate = {
      timestamp: time * 1000,
      time,
      price: price * displayRate,
      open: open == null ? undefined : open * displayRate,
      high: high == null ? undefined : high * displayRate,
      low: low == null ? undefined : low * displayRate,
      close: close == null ? undefined : close * displayRate,
      volume: finitePositiveNumber(point.volume) ?? undefined,
    } satisfies NormalizedChartPoint;

    // A malformed candle must not contaminate the line series. Preserve the
    // price, but expose OHLC only when the complete candle geometry is valid.
    if (!validOhlc(candidate)) {
      delete candidate.open;
      delete candidate.high;
      delete candidate.low;
      delete candidate.close;
    }

    // Last valid provider row wins for a duplicate timestamp. The resulting
    // map is sorted below, so out-of-order provider responses are harmless.
    byTime.set(time, candidate);
  }

  return [...byTime.values()].sort((left, right) => left.time - right.time);
}

export function hasCompleteOhlc(point: NormalizedChartPoint): boolean {
  return validOhlc(point);
}

export function hasSufficientChartData(points: readonly NormalizedChartPoint[]): boolean {
  return points.length >= 2;
}
