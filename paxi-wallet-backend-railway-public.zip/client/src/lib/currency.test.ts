import { describe, expect, it } from 'vitest';
import { formatFiat, formatFiatCompact, getStoredCurrency, isFiatCurrency } from './currency';

describe('fiat currency utilities', () => {
  it('accepts only supported currency codes and defaults safely', () => {
    expect(isFiatCurrency('USD')).toBe(true);
    expect(isFiatCurrency('CAD')).toBe(false);
    expect(getStoredCurrency()).toBe('USD');
  });

  it('formats USD values in the selected fiat using a supplied rate', () => {
    expect(formatFiat(10, 'USD', 1)).toBe('$10');
    expect(formatFiat(10, 'EUR', 0.9)).toBe('€9');
  });

  it('does not invent a zero value when the selected fiat rate is unavailable', () => {
    expect(formatFiat(10, 'GBP', null)).toBe('—');
    expect(formatFiat(null, 'USD', 1)).toBe('—');
  });

  it('formats large values compactly with the selected fiat symbol', () => {
    expect(formatFiatCompact(1_250_000, 'USD', 1)).toBe('$1.25M');
    expect(formatFiatCompact(1_250_000, 'EUR', 0.9)).toBe('€1.13M');
  });

  it('keeps compact values unavailable when the exchange rate is missing', () => {
    expect(formatFiatCompact(1_250_000, 'INR', null)).toBe('—');
    expect(formatFiatCompact(Number.NaN, 'USD', 1)).toBe('—');
  });
});
