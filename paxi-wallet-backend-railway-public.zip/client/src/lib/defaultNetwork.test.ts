import { describe, expect, it } from 'vitest';
import { getStoredDefaultNetwork, setStoredDefaultNetwork } from './defaultNetwork';

describe('default network preference', () => {
  it('falls back to a supported network when storage is unavailable', () => {
    expect(getStoredDefaultNetwork()).toBe('ethereum');
  });

  it('rejects unsupported network IDs', () => {
    expect(() => setStoredDefaultNetwork('not-a-real-chain')).toThrow('not supported');
  });
});
