import { NETWORKS } from '@/lib/wallet/chains';
import { safeGetLocalStorage, safeSetLocalStorage } from '@/lib/safeStorage';

const DEFAULT_NETWORK_KEY = 'paxi-default-network';
const DEFAULT_NETWORK_CHANGED_EVENT = 'paxi-default-network-changed';

export function getStoredDefaultNetwork(): string {
  const stored = safeGetLocalStorage(DEFAULT_NETWORK_KEY);
  return stored && NETWORKS[stored] ? stored : 'ethereum';
}

export function setStoredDefaultNetwork(networkId: string): string {
  const normalized = networkId.trim();
  if (!NETWORKS[normalized]) {
    throw new Error('That network is not supported by this wallet.');
  }
  safeSetLocalStorage(DEFAULT_NETWORK_KEY, normalized);
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(DEFAULT_NETWORK_CHANGED_EVENT, { detail: normalized }));
  }
  return normalized;
}

export function subscribeToDefaultNetwork(listener: (networkId: string) => void): () => void {
  if (typeof window === 'undefined') return () => undefined;
  const handle = (event: Event) => {
    const networkId = (event as CustomEvent<string>).detail;
    listener(typeof networkId === 'string' && NETWORKS[networkId] ? networkId : getStoredDefaultNetwork());
  };
  window.addEventListener(DEFAULT_NETWORK_CHANGED_EVENT, handle);
  return () => window.removeEventListener(DEFAULT_NETWORK_CHANGED_EVENT, handle);
}
