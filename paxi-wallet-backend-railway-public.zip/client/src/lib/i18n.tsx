/**
 * Real (not stubbed) language switching. Honest about scope: translating
 * every string across every screen in one pass isn't realistic - this
 * covers the always-visible chrome (bottom nav, common actions, settings)
 * plus a `t()` function any screen can pull more keys into over time.
 * Falls back to the English string itself if a key is missing in the
 * chosen language, so nothing ever renders blank.
 */
import { createContext, useContext, useState, type ReactNode } from 'react';
import { safeGetLocalStorage, safeSetLocalStorage } from './safeStorage';

export const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'fr', label: 'Français' },
  { code: 'de', label: 'Deutsch' },
  { code: 'zh', label: '中文' },
] as const;

export type LangCode = (typeof LANGUAGES)[number]['code'];

const STORAGE_KEY = 'paxi-language-code';

type Dict = Record<string, string>;

const en: Dict = {
  nav_assets: 'Assets',
  nav_markets: 'Markets',
  nav_discover: 'Discover',
  nav_trade: 'Trade',
  nav_me: 'Me',
  action_send: 'Send',
  action_receive: 'Receive',
  action_swap: 'Swap',
  action_buy: 'Buy',
  common_all: 'All',
  common_confirm: 'Confirm',
  common_cancel: 'Cancel',
  common_done: 'Done',
  common_back: 'Back',
  common_loading: 'Loading…',
  settings_title: 'Settings',
  settings_wallet: 'Wallet',
  settings_preferences: 'Preferences',
  settings_dark_mode: 'Dark Mode',
  settings_biometric: 'Biometric Unlock',
  settings_language: 'Language',
  settings_currency: 'Currency',
  settings_backup: 'Backup Wallet (view recovery phrase)',
  settings_export: 'Export Wallet',
  settings_report_issue: 'Report an Issue',
  settings_lock: 'Lock Wallet',
  settings_remove: 'Remove Wallet From This Device',
  me_asset_overview: 'Asset Overview',
  me_manage_wallets: 'Manage Wallets',
  me_transaction_records: 'Transaction Records',
  me_list_token: 'List My Token',
  me_start_campaign: 'Start a Campaign',
  me_create_token: 'Create a Token',
  me_admin_review: 'Admin Review',
};

const es: Dict = {
  nav_assets: 'Activos',
  nav_markets: 'Mercados',
  nav_discover: 'Descubrir',
  nav_trade: 'Operar',
  nav_me: 'Perfil',
  action_send: 'Enviar',
  action_receive: 'Recibir',
  action_swap: 'Intercambiar',
  action_buy: 'Comprar',
  common_all: 'Todo',
  common_confirm: 'Confirmar',
  common_cancel: 'Cancelar',
  common_done: 'Hecho',
  common_back: 'Atrás',
  common_loading: 'Cargando…',
  settings_title: 'Configuración',
  settings_wallet: 'Billetera',
  settings_preferences: 'Preferencias',
  settings_dark_mode: 'Modo Oscuro',
  settings_biometric: 'Desbloqueo Biométrico',
  settings_language: 'Idioma',
  settings_currency: 'Moneda',
  settings_backup: 'Respaldar Billetera (ver frase de recuperación)',
  settings_export: 'Exportar Billetera',
  settings_report_issue: 'Reportar un Problema',
  settings_lock: 'Bloquear Billetera',
  settings_remove: 'Eliminar Billetera de Este Dispositivo',
  me_asset_overview: 'Resumen de Activos',
  me_manage_wallets: 'Administrar Billeteras',
  me_transaction_records: 'Historial de Transacciones',
  me_list_token: 'Listar Mi Token',
  me_start_campaign: 'Iniciar una Campaña',
  me_create_token: 'Crear un Token',
  me_admin_review: 'Revisión de Administrador',
};

const fr: Dict = {
  nav_assets: 'Actifs',
  nav_markets: 'Marchés',
  nav_discover: 'Découvrir',
  nav_trade: 'Échanger',
  nav_me: 'Profil',
  action_send: 'Envoyer',
  action_receive: 'Recevoir',
  action_swap: 'Échanger',
  action_buy: 'Acheter',
  common_all: 'Tout',
  common_confirm: 'Confirmer',
  common_cancel: 'Annuler',
  common_done: 'Terminé',
  common_back: 'Retour',
  common_loading: 'Chargement…',
  settings_title: 'Paramètres',
  settings_wallet: 'Portefeuille',
  settings_preferences: 'Préférences',
  settings_dark_mode: 'Mode Sombre',
  settings_biometric: 'Déverrouillage Biométrique',
  settings_language: 'Langue',
  settings_currency: 'Devise',
  settings_backup: 'Sauvegarder le Portefeuille (voir la phrase de récupération)',
  settings_export: 'Exporter le Portefeuille',
  settings_report_issue: 'Signaler un Problème',
  settings_lock: 'Verrouiller le Portefeuille',
  settings_remove: 'Supprimer le Portefeuille de Cet Appareil',
  me_asset_overview: 'Aperçu des Actifs',
  me_manage_wallets: 'Gérer les Portefeuilles',
  me_transaction_records: 'Historique des Transactions',
  me_list_token: 'Lister Mon Token',
  me_start_campaign: 'Démarrer une Campagne',
  me_create_token: 'Créer un Token',
  me_admin_review: 'Révision Admin',
};

const de: Dict = {
  nav_assets: 'Vermögen',
  nav_markets: 'Märkte',
  nav_discover: 'Entdecken',
  nav_trade: 'Handeln',
  nav_me: 'Profil',
  action_send: 'Senden',
  action_receive: 'Empfangen',
  action_swap: 'Tauschen',
  action_buy: 'Kaufen',
  common_all: 'Alle',
  common_confirm: 'Bestätigen',
  common_cancel: 'Abbrechen',
  common_done: 'Fertig',
  common_back: 'Zurück',
  common_loading: 'Lädt…',
  settings_title: 'Einstellungen',
  settings_wallet: 'Wallet',
  settings_preferences: 'Einstellungen',
  settings_dark_mode: 'Dunkelmodus',
  settings_biometric: 'Biometrische Entsperrung',
  settings_language: 'Sprache',
  settings_currency: 'Währung',
  settings_backup: 'Wallet Sichern (Wiederherstellungsphrase ansehen)',
  settings_export: 'Wallet Exportieren',
  settings_report_issue: 'Problem Melden',
  settings_lock: 'Wallet Sperren',
  settings_remove: 'Wallet von Diesem Gerät Entfernen',
  me_asset_overview: 'Vermögensübersicht',
  me_manage_wallets: 'Wallets Verwalten',
  me_transaction_records: 'Transaktionsverlauf',
  me_list_token: 'Meinen Token Listen',
  me_start_campaign: 'Kampagne Starten',
  me_create_token: 'Token Erstellen',
  me_admin_review: 'Admin-Prüfung',
};

const zh: Dict = {
  nav_assets: '资产',
  nav_markets: '行情',
  nav_discover: '发现',
  nav_trade: '交易',
  nav_me: '我的',
  action_send: '发送',
  action_receive: '接收',
  action_swap: '兑换',
  action_buy: '购买',
  common_all: '全部',
  common_confirm: '确认',
  common_cancel: '取消',
  common_done: '完成',
  common_back: '返回',
  common_loading: '加载中…',
  settings_title: '设置',
  settings_wallet: '钱包',
  settings_preferences: '偏好设置',
  settings_dark_mode: '深色模式',
  settings_biometric: '生物识别解锁',
  settings_language: '语言',
  settings_currency: '货币',
  settings_backup: '备份钱包（查看助记词）',
  settings_export: '导出钱包',
  settings_report_issue: '报告问题',
  settings_lock: '锁定钱包',
  settings_remove: '从此设备移除钱包',
  me_asset_overview: '资产概览',
  me_manage_wallets: '管理钱包',
  me_transaction_records: '交易记录',
  me_list_token: '上架我的代币',
  me_start_campaign: '发起活动',
  me_create_token: '创建代币',
  me_admin_review: '管理员审核',
};

const DICTS: Record<LangCode, Dict> = { en, es, fr, de, zh };

interface I18nContextValue {
  lang: LangCode;
  setLang: (code: LangCode) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<LangCode>(() => {
    const stored = safeGetLocalStorage(STORAGE_KEY);
    return (stored && stored in DICTS ? stored : 'en') as LangCode;
  });

  const setLang = (code: LangCode) => {
    setLangState(code);
    safeSetLocalStorage(STORAGE_KEY, code);
  };

  const t = (key: string): string => DICTS[lang][key] ?? en[key] ?? key;

  return <I18nContext.Provider value={{ lang, setLang, t }}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
}
