import { describe, expect, it } from "vitest";
import { listingCanBeResubmitted, listingIsCampaignEligible, listingStatusLabel } from "./listingStatus";

describe("listing status presentation", () => {
  it("only exposes campaign eligibility after verification", () => {
    expect(listingIsCampaignEligible("pending")).toBe(false);
    expect(listingIsCampaignEligible("rejected")).toBe(false);
    expect(listingIsCampaignEligible("verified")).toBe(true);
  });

  it("only allows the owner-facing fix and resubmit action for rejected listings", () => {
    expect(listingCanBeResubmitted("pending")).toBe(false);
    expect(listingCanBeResubmitted("verified")).toBe(false);
    expect(listingCanBeResubmitted("rejected")).toBe(true);
    expect(listingStatusLabel("pending")).toBe("Pending review");
  });
});
