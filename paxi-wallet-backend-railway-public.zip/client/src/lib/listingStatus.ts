export type ListingStatus = "pending" | "verified" | "rejected";

export function listingStatusLabel(status: ListingStatus): string {
  return status === "pending" ? "Pending review" : status === "verified" ? "Verified" : "Rejected";
}

export function listingIsCampaignEligible(status: ListingStatus): boolean {
  return status === "verified";
}

export function listingCanBeResubmitted(status: ListingStatus): boolean {
  return status === "rejected";
}
