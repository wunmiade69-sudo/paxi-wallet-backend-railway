import { beforeEach, describe, expect, it } from 'vitest';
import { clearMarketWatchlist, getMarketWatchlist, isMarketWatchlisted, marketWatchlistKey, toggleMarketWatchlist, type MarketWatchlistItem } from './marketWatchlist';

const memory = new Map<string, string>();
const localStorageStub: Storage = {
  get length() { return memory.size; },
  clear: () => memory.clear(),
  getItem: (key) => memory.get(key) ?? null,
  key: (index) => [...memory.keys()][index] ?? null,
  removeItem: (key) => memory.delete(key),
  setItem: (key, value) => memory.set(key, value),
};

const item: MarketWatchlistItem = {
  key: 'ethereum:0xabc', symbol: 'ABC', name: 'Alpha', chain: 'ethereum', contractAddress: '0xabc', coinId: null, image: '',
};

describe('market watchlist', () => {
  beforeEach(() => {
    memory.clear();
    Object.defineProperty(globalThis, 'window', { configurable: true, value: { localStorage: localStorageStub } });
  });

  it('uses canonical chain identity rather than a symbol', () => {
    expect(marketWatchlistKey({ chain: 'Ethereum', contractAddress: '0xAbC' })).toBe('ethereum:0xabc');
    expect(marketWatchlistKey({ chain: 'solana', identifier: 'native' })).toBe('solana:native');
    expect(marketWatchlistKey({ symbol: 'ABC' })).toBeNull();
  });

  it('toggles and persists one item without duplicates', () => {
    expect(toggleMarketWatchlist(item)).toBe(true);
    expect(toggleMarketWatchlist(item)).toBe(false);
    expect(getMarketWatchlist()).toEqual([]);
    expect(isMarketWatchlisted(item.key)).toBe(false);
    toggleMarketWatchlist(item);
    expect(getMarketWatchlist()).toEqual([item]);
    expect(isMarketWatchlisted(item.key)).toBe(true);
  });

  it('ignores malformed stored entries and clears cleanly', () => {
    localStorageStub.setItem('paxi.market.watchlist.v1', JSON.stringify([item, { key: 'bad' }, 'bad']));
    expect(getMarketWatchlist()).toEqual([item]);
    clearMarketWatchlist();
    expect(getMarketWatchlist()).toEqual([]);
  });
});
