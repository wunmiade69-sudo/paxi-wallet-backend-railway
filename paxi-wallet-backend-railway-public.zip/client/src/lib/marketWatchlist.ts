import { canonicalMarketIdentityKey, canonicalNativeIdentityKey } from './marketIdentity';

const STORAGE_KEY = 'paxi.market.watchlist.v1';

export interface MarketWatchlistItem {
  key: string;
  symbol: string;
  name: string;
  chain: string | null;
  contractAddress: string | null;
  coinId: string | null;
  image: string;
}

function storage(): Storage | null {
  if (typeof window === 'undefined') return null;
  try { return window.localStorage; } catch { return null; }
}

function validItem(value: unknown): value is MarketWatchlistItem {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<MarketWatchlistItem>;
  return typeof item.key === 'string'
    && typeof item.symbol === 'string'
    && typeof item.name === 'string'
    && (typeof item.chain === 'string' || item.chain === null)
    && (typeof item.contractAddress === 'string' || item.contractAddress === null)
    && (typeof item.coinId === 'string' || item.coinId === null)
    && typeof item.image === 'string';
}

export function getMarketWatchlist(): MarketWatchlistItem[] {
  const raw = storage()?.getItem(STORAGE_KEY);
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter(validItem).slice(0, 100) : [];
  } catch {
    return [];
  }
}

function save(items: MarketWatchlistItem[]): void {
  try { storage()?.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, 100))); } catch { /* storage is optional */ }
}

export function marketWatchlistKey(input: { chain?: string | null; contractAddress?: string | null; coinId?: string | null; identifier?: string | null }): string | null {
  if (input.chain && input.contractAddress) return canonicalMarketIdentityKey(input.chain, input.contractAddress);
  if (input.chain && input.identifier === 'native') return canonicalNativeIdentityKey(input.chain);
  return input.coinId ? `coingecko:${input.coinId.trim().toLowerCase()}` : null;
}

export function isMarketWatchlisted(key: string | null): boolean {
  return Boolean(key && getMarketWatchlist().some((item) => item.key === key));
}

export function toggleMarketWatchlist(item: MarketWatchlistItem): boolean {
  const current = getMarketWatchlist();
  const index = current.findIndex((entry) => entry.key === item.key);
  if (index >= 0) {
    current.splice(index, 1);
    save(current);
    return false;
  }
  save([item, ...current.filter((entry) => entry.key !== item.key)]);
  return true;
}

export function clearMarketWatchlist(): void { try { storage()?.removeItem(STORAGE_KEY); } catch { /* storage is optional */ } }
