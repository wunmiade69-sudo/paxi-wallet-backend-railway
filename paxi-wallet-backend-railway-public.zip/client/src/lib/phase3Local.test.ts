import { describe, expect, it } from 'vitest';
import { getNotificationPreferences, notifyForPriceMovement, notifyForTransaction } from './phase3Local';

describe('transaction notification routing', () => {
  const base = {
    hash: '0xABC123',
    networkId: 'ethereum',
    type: 'send' as const,
    symbol: 'ETH',
    amount: '0.25',
  };

  it('creates a submitted notification for a real local broadcast event with an exact transaction target', () => {
    const notification = notifyForTransaction({ ...base, status: 'submitted', source: 'local-wallet' });
    expect(notification?.type).toBe('transaction-submitted');
    expect(notification?.target).toEqual({
      entityType: 'transaction',
      hash: base.hash,
      chain: base.networkId,
      navigation: 'tx-history',
    });
  });

  it('routes confirmed and failed status transitions to their distinct event types', () => {
    expect(notifyForTransaction({ ...base, status: 'confirmed' })?.type).toBe('transaction-confirmed');
    expect(notifyForTransaction({ ...base, status: 'failed' })?.type).toBe('transaction-failed');
  });

  it('deduplicates the same status event while keeping submitted and confirmed distinct', () => {
    const first = notifyForTransaction({ ...base, status: 'submitted' });
    const duplicate = notifyForTransaction({ ...base, status: 'submitted' });
    const confirmed = notifyForTransaction({ ...base, status: 'confirmed' });
    expect(duplicate?.id).toBe(first?.id);
    expect(confirmed?.id).not.toBe(first?.id);
    expect(confirmed?.target?.hash).toBe(base.hash);
  });

  it('routes confirmed receives to incoming-transaction and keeps safe defaults in non-browser contexts', () => {
    expect(notifyForTransaction({ ...base, type: 'receive', status: 'confirmed' })?.type).toBe('incoming-transaction');
    expect(getNotificationPreferences().ecosystemAnnouncements).toBe(false);
  });

  it('does not create price alerts unless the user has enabled them', () => {
    expect(notifyForPriceMovement({ assetKey: 'ethereum:0xabc', symbol: 'TEST', currentPrice: 2 })).toBeNull();
  });
});
