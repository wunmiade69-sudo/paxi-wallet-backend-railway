import type { DefaultOptions } from "@tanstack/react-query";

/**
 * Wallet navigation and locally cached balances remain usable when optional
 * market-data or analytics queries encounter a transient provider failure.
 */
export const walletQueryClientDefaults: DefaultOptions = {
  queries: {
    retry: 1,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  },
  mutations: {
    retry: 0,
  },
};
