/**
 * The app's main tRPC client (client/src/lib/trpc.ts) is React-hooks-only
 * (createTRPCReact) - fine for components, unusable from a plain async
 * function like balances.ts. This is the same server, same router, same
 * transformer, just callable imperatively: `trpcVanilla.market.assetPrice.query(...)`.
 */
import { createTRPCClient, httpBatchLink } from "@trpc/client";
import type { AppRouter } from "../../../server/routers";
import superjson from "superjson";

export const trpcVanilla = createTRPCClient<AppRouter>({
  links: [
    httpBatchLink({
      url: "/api/trpc",
      transformer: superjson,
      fetch(input, init) {
        return globalThis.fetch(input, { ...(init ?? {}), credentials: "include" });
      },
    }),
  ],
});
