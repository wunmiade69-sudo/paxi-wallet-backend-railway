import { describe, expect, it } from 'vitest';
import { describeUserFacingError } from './userFacingError';

describe('describeUserFacingError', () => {
  it('keeps concise actionable authentication and network guidance', () => {
    expect(describeUserFacingError(new Error('Unauthorized'))).toBe('Please sign in again to continue.');
    expect(describeUserFacingError(new Error('Request timeout'))).toBe('Connection issue. Check your internet connection and try again.');
    expect(describeUserFacingError(new Error('Insufficient funds for gas'))).toBe('There isn’t enough balance to complete this action.');
  });

  it('hides implementation details from ordinary users', () => {
    expect(describeUserFacingError(new Error('MySQL connection refused at api.example.com'))).toBe('Something went wrong. Please try again.');
    expect(describeUserFacingError(new Error('TypeError: Cannot read properties of undefined at server/router.ts:42'))).toBe('Something went wrong. Please try again.');
    expect(describeUserFacingError(new Error('Provider returned status code 502'))).toBe('Something went wrong. Please try again.');
  });

  it('retains short plain-language validation copy', () => {
    expect(describeUserFacingError(new Error('Enter a valid recipient address.'))).toBe('Enter a valid recipient address.');
    expect(describeUserFacingError(new Error('This code has expired.'), 'Fallback')).toBe('This code has expired.');
  });

  it('uses contextual fallbacks for empty or overly detailed errors', () => {
    expect(describeUserFacingError(undefined, 'Could not save your wallet.')).toBe('Could not save your wallet.');
    expect(describeUserFacingError(new Error('x'.repeat(181)), 'Could not save your wallet.')).toBe('Could not save your wallet.');
  });
});

