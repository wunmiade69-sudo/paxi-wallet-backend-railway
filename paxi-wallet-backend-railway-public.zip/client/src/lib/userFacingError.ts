const TECHNICAL_TERMS = [
  'backend',
  'frontend',
  'api',
  'endpoint',
  'provider',
  'database',
  'redis',
  'mysql',
  'sql',
  'environment variable',
  'configuration',
  'config',
  'rpc',
  'normalization',
  'serialization',
  'deserialization',
  'stack trace',
  'internal server',
  'syntaxerror',
  'typeerror',
  'referenceerror',
  'econnrefused',
  'jsonrpc',
  'code=',
  'status code',
  ' at ',
] as const;

function rawMessage(error: unknown): string {
  if (typeof error === 'string') return error.trim();
  if (error instanceof Error) return error.message.trim();
  if (error && typeof error === 'object' && 'message' in error) {
    const message = (error as { message?: unknown }).message;
    return typeof message === 'string' ? message.trim() : '';
  }
  return '';
}

/**
 * Converts unknown request/runtime failures into concise product copy. Known,
 * actionable categories are retained; raw implementation details are never
 * returned to the screen. Detailed diagnostics remain available to logs.
 */
export function describeUserFacingError(error: unknown, fallback = 'Something went wrong. Please try again.'): string {
  const raw = rawMessage(error);
  const lower = raw.toLowerCase();

  if (lower.includes('unauthorized') || lower.includes('unauthenticated') || lower.includes('sign in')) {
    return 'Please sign in again to continue.';
  }
  if (lower.includes('forbidden') || lower.includes('permission')) {
    return 'You don’t have permission to do that.';
  }
  if (lower.includes('rate limit') || lower.includes('too many requests') || lower.includes('429')) {
    return 'Too many requests right now. Please wait a moment and try again.';
  }
  if (lower.includes('timeout') || lower.includes('failed to fetch') || lower.includes('network error') || lower.includes('econnreset')) {
    return 'Connection issue. Check your internet connection and try again.';
  }
  if (lower.includes('insufficient funds') || lower.includes('insufficient_funds')) {
    return 'There isn’t enough balance to complete this action.';
  }
  if (lower.includes('user rejected') || lower.includes('action_rejected') || lower.includes('user denied')) {
    return 'Action cancelled.';
  }
  if (!raw || raw.length > 180 || TECHNICAL_TERMS.some((term) => lower.includes(term))) {
    return fallback;
  }

  // Short, plain-language validation messages from the application are safe
  // to retain; stack traces and implementation errors are filtered above.
  return raw;
}

export function logAndDescribeUserFacingError(context: string, error: unknown, fallback?: string): string {
  console.error(`[ui] ${context}`, error);
  return describeUserFacingError(error, fallback);
}
