import { NETWORKS, type ChainType } from './chains';

export type ContactVerification = 'unconfirmed' | 'confirmed' | 'unknown';

/**
 * A saved recipient is scoped to one network. The network is not a trust
 * decision; it only prevents an address saved for one chain from being
 * silently reused on another chain.
 */
export interface Contact {
  id: string;
  name: string;
  network: string;
  address: string;
  note?: string;
  addedAt: number;
  verificationStatus: ContactVerification;
}

const KEY = 'paxi-address-book';

function normalize(address: string) {
  return address.trim();
}

function validEvm(address: string) {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}

function validSolana(address: string) {
  // Base58 public keys are normally 32 bytes and 32–44 characters long.
  return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
}

function validBitcoin(address: string) {
  return /^(bc1|tb1|[13])[a-zA-HJ-NP-Z0-9]{20,90}$/.test(address);
}

export function normalizeContactAddress(network: string, address: string): string {
  const trimmed = normalize(address);
  const config = NETWORKS[network];
  if (!config) throw new Error('Choose a supported network for this contact.');

  const valid = config.chainType === 'evm' ? validEvm(trimmed) : config.chainType === 'sol' ? validSolana(trimmed) : validBitcoin(trimmed);
  if (!valid) throw new Error(`That doesn’t look like a valid ${config.label} address.`);
  return trimmed;
}

export function addressesMatch(network: string, left: string, right: string): boolean {
  const chainType: ChainType | undefined = NETWORKS[network]?.chainType;
  if (chainType === 'evm') return left.trim().toLowerCase() === right.trim().toLowerCase();
  return left.trim() === right.trim();
}

function normalizeStoredContact(value: unknown): Contact | null {
  if (!value || typeof value !== 'object') return null;
  const raw = value as Partial<Contact> & { network?: string };
  const address = typeof raw.address === 'string' ? raw.address.trim() : '';
  const name = typeof raw.name === 'string' ? raw.name.trim() : '';
  if (!name || !address) return null;

  // Legacy records had no network field and were EVM-only. Preserve them as
  // Ethereum contacts, but mark them unconfirmed so they are not mistaken for
  // independently verified recipients.
  const network = typeof raw.network === 'string' && NETWORKS[raw.network] ? raw.network : 'ethereum';
  try {
    normalizeContactAddress(network, address);
  } catch {
    return null;
  }
  return {
    id: typeof raw.id === 'string' ? raw.id : `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    network,
    address,
    note: typeof raw.note === 'string' && raw.note.trim() ? raw.note.trim() : undefined,
    addedAt: typeof raw.addedAt === 'number' ? raw.addedAt : Date.now(),
    verificationStatus: raw.verificationStatus === 'confirmed' || raw.verificationStatus === 'unknown' ? raw.verificationStatus : 'unconfirmed',
  };
}

export function getContacts(): Contact[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    if (!Array.isArray(raw)) return [];
    return raw.map(normalizeStoredContact).filter((contact): contact is Contact => Boolean(contact)).sort((a, b) => a.name.localeCompare(b.name));
  } catch {
    return [];
  }
}

export function addContact(input: { name: string; network: string; address: string; note?: string; verificationStatus?: ContactVerification }): Contact {
  const name = input.name.trim();
  const address = normalizeContactAddress(input.network, input.address);
  if (!name) throw new Error('Give this contact a name.');

  const existing = getContacts();
  if (existing.some((c) => c.network === input.network && addressesMatch(input.network, c.address, address))) {
    throw new Error('This address is already saved on that network.');
  }

  const contact: Contact = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    network: input.network,
    address,
    note: input.note?.trim() || undefined,
    addedAt: Date.now(),
    verificationStatus: input.verificationStatus ?? 'unconfirmed',
  };
  localStorage.setItem(KEY, JSON.stringify([...existing, contact]));
  return contact;
}

export function updateContact(id: string, updates: { name?: string; network?: string; address?: string; note?: string; verificationStatus?: ContactVerification }): void {
  const existing = getContacts();
  const idx = existing.findIndex((c) => c.id === id);
  if (idx === -1) throw new Error('Contact not found.');

  const current = existing[idx];
  const network = updates.network ?? current.network;
  const name = updates.name !== undefined ? updates.name.trim() : current.name;
  const address = updates.address !== undefined ? normalizeContactAddress(network, updates.address) : normalizeContactAddress(network, current.address);
  if (!name) throw new Error('Give this contact a name.');
  if (existing.some((c) => c.id !== id && c.network === network && addressesMatch(network, c.address, address))) {
    throw new Error('This address is already saved on that network.');
  }

  existing[idx] = {
    ...current,
    name,
    network,
    address,
    note: updates.note !== undefined ? updates.note.trim() || undefined : current.note,
    verificationStatus: updates.verificationStatus ?? current.verificationStatus,
  };
  localStorage.setItem(KEY, JSON.stringify(existing));
}

export function deleteContact(id: string): void {
  localStorage.setItem(KEY, JSON.stringify(getContacts().filter((c) => c.id !== id)));
}

/** Used by Send before a saved contact is applied to the recipient field. */
export function contactMatchesNetwork(contact: Contact, network: string): boolean {
  return contact.network === network;
}
