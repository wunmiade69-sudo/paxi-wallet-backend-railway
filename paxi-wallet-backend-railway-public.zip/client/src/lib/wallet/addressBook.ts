/**
 * Local address book - saved recipient contacts, stored per-device like
 * transaction history. Every EVM chain shares one address format, so a
 * contact's address is valid across all EVM networks the wallet supports;
 * `network` is stored as a label/hint only (e.g. "usually pay them on BSC"),
 * not a constraint on where you can send to them.
 */

export interface Contact {
  id: string;
  name: string;
  address: string;
  note?: string;
  addedAt: number;
}

const KEY = 'paxi-address-book';

function normalize(address: string) {
  return address.trim();
}

export function getContacts(): Contact[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    if (!Array.isArray(raw)) return [];
    return raw.sort((a: Contact, b: Contact) => a.name.localeCompare(b.name));
  } catch {
    return [];
  }
}

export function addContact(input: { name: string; address: string; note?: string }): Contact {
  const name = input.name.trim();
  const address = normalize(input.address);
  if (!name) throw new Error('Give this contact a name.');
  if (!/^0x[a-fA-F0-9]{40}$/.test(address)) throw new Error('That doesn\u2019t look like a valid EVM address.');

  const existing = getContacts();
  if (existing.some((c) => c.address.toLowerCase() === address.toLowerCase())) {
    throw new Error('This address is already saved in your address book.');
  }

  const contact: Contact = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, name, address, note: input.note?.trim() || undefined, addedAt: Date.now() };
  localStorage.setItem(KEY, JSON.stringify([...existing, contact]));
  return contact;
}

export function updateContact(id: string, updates: { name?: string; address?: string; note?: string }): void {
  const existing = getContacts();
  const idx = existing.findIndex((c) => c.id === id);
  if (idx === -1) throw new Error('Contact not found.');

  const name = updates.name !== undefined ? updates.name.trim() : existing[idx].name;
  const address = updates.address !== undefined ? normalize(updates.address) : existing[idx].address;
  if (!name) throw new Error('Give this contact a name.');
  if (!/^0x[a-fA-F0-9]{40}$/.test(address)) throw new Error('That doesn\u2019t look like a valid EVM address.');
  if (existing.some((c) => c.id !== id && c.address.toLowerCase() === address.toLowerCase())) {
    throw new Error('This address is already saved in your address book.');
  }

  existing[idx] = { ...existing[idx], name, address, note: updates.note !== undefined ? updates.note.trim() || undefined : existing[idx].note };
  localStorage.setItem(KEY, JSON.stringify(existing));
}

export function deleteContact(id: string): void {
  const existing = getContacts().filter((c) => c.id !== id);
  localStorage.setItem(KEY, JSON.stringify(existing));
}
