import { describe, expect, it } from "vitest";
import { formatWalletAmount, formatWalletInputAmount } from "./amountFormatting";

describe("wallet amount formatting", () => {
  it("renders the reported tiny BNB balance in fixed decimal notation", () => {
    expect(formatWalletAmount(7.49697e-8)).toBe("0.0000000749697");
    expect(formatWalletInputAmount(7.49697e-8, 18)).toBe("0.0000000749697");
  });

  it("never exposes scientific notation for very small finite amounts", () => {
    const displayed = formatWalletAmount(1e-18);

    expect(displayed).not.toMatch(/e[-+]?\d/i);
    expect(displayed).toMatch(/^<0\.0+1$/);
  });

  it("keeps ordinary balances compact and grouped", () => {
    expect(formatWalletAmount(12345.678912)).toBe("12,345.678912");
  });
});
