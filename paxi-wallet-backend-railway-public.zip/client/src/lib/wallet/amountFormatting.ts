export interface WalletAmountFormatOptions {
  /** Maximum fractional digits shown in a read-only balance or quote. */
  maximumFractionDigits?: number;
  /** Keep grouping separators for larger human-readable balances. */
  useGrouping?: boolean;
}

/**
 * Formats wallet amounts without ever falling back to JavaScript scientific
 * notation. Small balances remain legible, while the displayed precision is
 * capped to keep mobile screens readable.
 */
export function formatWalletAmount(
  value: number | string | null | undefined,
  options: WalletAmountFormatOptions = {},
): string {
  if (value == null || value === "") return "—";
  const numeric = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(numeric)) return String(value);
  if (numeric === 0) return "0";

  const maximumFractionDigits = Math.max(0, Math.min(options.maximumFractionDigits ?? 14, 20));
  const fractionalDigits = numeric < 1
    ? Math.min(maximumFractionDigits, Math.max(6, Math.ceil(-Math.log10(Math.abs(numeric))) + 6))
    : Math.min(maximumFractionDigits, 6);

  const rendered = numeric.toLocaleString("en-US", {
    useGrouping: options.useGrouping ?? true,
    maximumFractionDigits: fractionalDigits,
  });

  // A value can be smaller than the selected precision. Make that fact clear
  // without reverting to exponential notation.
  return Number(rendered.replace(/,/g, "")) === 0 ? `<0.${"0".repeat(Math.max(0, fractionalDigits - 1))}1` : rendered;
}

/** Use the asset's native decimal precision when putting a computed value into a numeric input. */
export function formatWalletInputAmount(value: number, decimals = 18): string {
  return formatWalletAmount(value, {
    maximumFractionDigits: Math.max(0, Math.min(decimals, 20)),
    useGrouping: false,
  });
}
