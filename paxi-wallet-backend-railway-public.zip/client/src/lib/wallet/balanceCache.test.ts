import { describe, expect, it } from 'vitest';
import type { AssetBalance } from './balances';
import { clearAllBalanceSnapshots, clearBalanceSnapshot, getBalanceSnapshot, setBalanceSnapshot } from './balanceCache';

const sampleBalance: AssetBalance = {
  asset: {
    symbol: 'BNB',
    name: 'BNB',
    network: 'bsc',
    decimals: 18,
    isNative: true,
    icon: '◆',
    binanceSymbol: 'BNBUSDT',
  },
  balance: 1.25,
  usdPrice: 600,
  change24h: 1.2,
};

describe('session balance snapshots', () => {
  it('returns a copy of the last loaded snapshot for navigation reuse', () => {
    clearAllBalanceSnapshots();
    const snapshot = { bnb: sampleBalance };
    setBalanceSnapshot('0xwallet', snapshot);

    const restored = getBalanceSnapshot('0xwallet');
    expect(restored).toEqual(snapshot);
    expect(restored).not.toBe(snapshot);
  });

  it('replaces the snapshot after a manual refresh and clears it when the wallet is removed', () => {
    clearAllBalanceSnapshots();
    setBalanceSnapshot('0xwallet', { bnb: sampleBalance });
    const refreshed = { bnb: { ...sampleBalance, balance: 2 } };
    setBalanceSnapshot('0xwallet', refreshed);
    expect(getBalanceSnapshot('0xwallet')?.bnb.balance).toBe(2);

    clearBalanceSnapshot('0xwallet');
    expect(getBalanceSnapshot('0xwallet')).toBeNull();
  });
});
