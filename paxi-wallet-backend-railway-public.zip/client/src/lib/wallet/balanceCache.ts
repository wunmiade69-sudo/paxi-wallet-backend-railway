import type { AssetBalance } from './balances';

/**
 * Session-only balance snapshots. This deliberately stays in memory: wallet
 * balances are not written to localStorage, IndexedDB, or any remote store.
 */
const snapshots = new Map<string, Record<string, AssetBalance>>();

export function getBalanceSnapshot(address: string): Record<string, AssetBalance> | null {
  const snapshot = snapshots.get(address);
  return snapshot ? { ...snapshot } : null;
}

export function setBalanceSnapshot(address: string, balances: Record<string, AssetBalance>): void {
  snapshots.set(address, { ...balances });
}

export function clearBalanceSnapshot(address: string): void {
  snapshots.delete(address);
}

export function clearAllBalanceSnapshots(): void {
  snapshots.clear();
}
