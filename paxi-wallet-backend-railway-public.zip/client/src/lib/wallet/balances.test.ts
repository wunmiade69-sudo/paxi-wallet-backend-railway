import { describe, expect, it } from "vitest";
import { mapPortfolioQuotes } from "./balances";

describe("canonical portfolio quote mapping", () => {
  it("maps native quotes independently from contract-bearing assets", () => {
    const map = mapPortfolioQuotes([
      { network: "ethereum", isNative: true, contractAddress: null, priceUsd: 2000, change24h: 1, source: "binance" },
      { network: "ethereum", isNative: false, contractAddress: "0xAbC", priceUsd: 1, change24h: null, source: "dexscreener" },
      { network: "solana", isNative: false, contractAddress: "MintCase", priceUsd: 2, change24h: 3, source: "jupiter" },
    ]);

    expect(map.get("ethereum:native")?.priceUsd).toBe(2000);
    expect(map.get("ethereum:0xabc")?.source).toBe("dexscreener");
    expect(map.get("solana:mintcase")).toBeUndefined();
    expect(map.get("solana:MintCase")?.source).toBe("jupiter");
  });

  it("represents a failed server batch as an empty map so callers render unavailable, not zero", () => {
    const map = mapPortfolioQuotes([]);
    expect(map.size).toBe(0);
    expect(map.get("ethereum:native")).toBeUndefined();
  });
});

