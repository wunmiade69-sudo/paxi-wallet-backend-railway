/**
 * Live balance + price lookups.
 *
 * EVM balances are real: fetched over public RPC endpoints with ethers.js
 * (no API key needed). Prices/charts come from Binance's public market
 * data on data-api.binance.vision - the domain Binance publishes
 * specifically for third-party/browser callers (api.binance.com does
 * not send CORS headers for arbitrary origins and gets silently blocked
 * by the browser). CoinGecko is used as a second-layer fallback if
 * Binance is ever down, rate-limited, or missing a symbol.
 * Anything that fails (offline, RPC hiccup, no market pair, unimplemented
 * BTC/SOL derivation) resolves to `null` rather than a fake number, so the
 * UI can show "—" instead of quietly lying.
 */
import { JsonRpcProvider, formatUnits, Contract } from 'ethers';
import { ASSETS, NETWORKS, type AssetConfig } from './chains';
import { customTokenToAsset, getCustomTokens } from './customTokens';
import { fetchDexMarketData, fetchOnChainPrice, type DexMarketData } from './dexAnalytics';
import { trpcVanilla } from '../trpcVanilla';

const ERC20_ABI = ['function balanceOf(address) view returns (uint256)'];
const BINANCE_API = 'https://data-api.binance.vision/api/v3';
const COINGECKO_API = 'https://api.coingecko.com/api/v3';

/**
 * Binance's public market-data API geo-blocks a number of countries
 * (the US among them) at the network level - the request fails outright,
 * not with a parseable error, so a device in one of those regions would
 * see every price/chart silently fail even though this code is correct.
 * CoinGecko's public API has no such block, so it's used as a fallback
 * whenever a Binance call comes back empty.
 */
export const COINGECKO_IDS: Record<string, string> = {
  BNBUSDT: 'binancecoin',
  ETHUSDT: 'ethereum',
  BTCUSDT: 'bitcoin',
  SOLUSDT: 'solana',
  POLUSDT: 'polygon-ecosystem-token',
  USDTUSDT: 'tether',
  USDCUSDT: 'usd-coin',
};

const providerCache = new Map<string, JsonRpcProvider>();
function getProvider(rpcUrl: string): JsonRpcProvider {
  let p = providerCache.get(rpcUrl);
  if (!p) {
    p = new JsonRpcProvider(rpcUrl);
    providerCache.set(rpcUrl, p);
  }
  return p;
}

/** Race a promise against a timeout so one slow RPC/API call can't stall the whole dashboard. */
function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return Promise.race([promise, new Promise<T>((resolve) => setTimeout(() => resolve(fallback), ms))]);
}

export interface AssetBalance {
  asset: AssetConfig;
  balance: number | null; // null = unavailable
  usdPrice: number | null;
  change24h: number | null;
}

/** Live balance for a single asset - used by Swap/Bridge/Send to pre-check funds before quoting or signing.
 * `solAddress`/`btcAddress` are optional and only needed for those chains (different address than the EVM one). */
export async function fetchAssetBalance(
  asset: AssetConfig,
  evmAddress: string,
  solAddress?: string,
  btcAddress?: string
): Promise<number | null> {
  const network = NETWORKS[asset.network];
  if (network.chainType === 'evm') return fetchEvmBalance(asset, evmAddress);
  if (network.chainType === 'sol' && solAddress) return fetchSolanaBalance(asset, solAddress);
  if (network.chainType === 'btc' && btcAddress) {
    const { fetchBitcoinBalance } = await import('./bitcoin');
    return fetchBitcoinBalance(btcAddress);
  }
  return null;
}

async function fetchSolanaBalance(asset: AssetConfig, solAddress: string): Promise<number | null> {
  const network = NETWORKS[asset.network];
  if (!network.rpcUrl) return null;
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    const connection = new Connection(network.rpcUrl, 'confirmed');
    const owner = new PublicKey(solAddress);

    if (asset.isNative) {
      const lamports = await connection.getBalance(owner);
      return lamports / 1e9;
    }

    if (asset.contractAddress) {
      const mint = new PublicKey(asset.contractAddress);
      const { TOKEN_PROGRAM_ID } = await import('@solana/spl-token');
      const accounts = await connection.getParsedTokenAccountsByOwner(owner, { mint, programId: TOKEN_PROGRAM_ID });
      const total = accounts.value.reduce(
        (sum, acc) => sum + (acc.account.data.parsed.info.tokenAmount.uiAmount ?? 0),
        0,
      );
      return total;
    }
    return null;
  } catch (err) {
    console.warn(`Solana balance fetch failed for ${asset.symbol}:`, err);
    return null;
  }
}

async function fetchEvmBalance(asset: AssetConfig, evmAddress: string): Promise<number | null> {
  const network = NETWORKS[asset.network];
  if (!network.rpcUrl) return null;
  try {
    const provider = getProvider(network.rpcUrl);
    if (asset.isNative) {
      const raw = await provider.getBalance(evmAddress);
      return Number(formatUnits(raw, asset.decimals));
    }
    if (asset.contractAddress) {
      const contract = new Contract(asset.contractAddress, ERC20_ABI, provider);
      const raw = await contract.balanceOf(evmAddress);
      return Number(formatUnits(raw, asset.decimals));
    }
    return null;
  } catch (err) {
    console.warn(`Balance fetch failed for ${asset.symbol}:`, err);
    return null;
  }
}

async function fetchBinanceTicker24hr(
  symbols: string[]
): Promise<Record<string, { price: number; change24h: number }>> {
  const url = `${BINANCE_API}/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(symbols))}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Binance ticker returned ${res.status}`);
  const rows: Array<{ symbol: string; lastPrice: string; priceChangePercent: string }> = await res.json();
  const out: Record<string, { price: number; change24h: number }> = {};
  for (const row of rows) {
    out[row.symbol] = { price: Number(row.lastPrice), change24h: Number(row.priceChangePercent) };
  }
  return out;
}

async function fetchCoingeckoPrices(
  symbols: string[]
): Promise<Record<string, { price: number; change24h: number }>> {
  const ids = symbols.map((s) => COINGECKO_IDS[s]).filter((id): id is string => !!id);
  if (ids.length === 0) return {};
  const url = `${COINGECKO_API}/simple/price?ids=${ids.join(',')}&vs_currencies=usd&include_24hr_change=true`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`CoinGecko price returned ${res.status}`);
  const data: Record<string, { usd: number; usd_24h_change: number }> = await res.json();
  const out: Record<string, { price: number; change24h: number }> = {};
  for (const symbol of symbols) {
    const id = COINGECKO_IDS[symbol];
    const row = id ? data[id] : undefined;
    if (row) out[symbol] = { price: row.usd, change24h: row.usd_24h_change };
  }
  return out;
}

/**
 * One batched call for every symbol's price + 24h change, instead of one
 * request per asset. Tries Binance first (fastest, most precise), and
 * fills in anything missing - whether from a hard failure or Binance
 * simply not returning every symbol - from CoinGecko.
 */
async function fetchBinancePrices(
  symbols: string[]
): Promise<Record<string, { price: number; change24h: number }>> {
  if (symbols.length === 0) return {};
  let out: Record<string, { price: number; change24h: number }> = {};
  try {
    out = await fetchBinanceTicker24hr(symbols);
  } catch (err) {
    console.warn('Binance price fetch failed, falling back to CoinGecko:', err);
  }
  const missing = symbols.filter((s) => !out[s]);
  if (missing.length > 0) {
    try {
      const fallback = await fetchCoingeckoPrices(missing);
      out = { ...out, ...fallback };
    } catch (err) {
      console.warn('CoinGecko price fallback also failed:', err);
    }
  }
  return out;
}

/**
 * Fetch balances + prices for every configured asset, calling `onAsset` as
 * soon as each individual asset resolves (max 6s per asset) instead of
 * waiting for every RPC call to finish before showing anything. The price
 * lookup is one shared batched request, awaited once up front.
 */
export async function fetchAllBalancesStreaming(
  evmAddress: string,
  onAsset: (result: AssetBalance) => void,
  solAddress?: string,
  btcAddress?: string
): Promise<void> {
  const customAssets = getCustomTokens().map(customTokenToAsset);
  const allAssets = [...ASSETS, ...customAssets];

  const binanceSymbols = allAssets.map((a) => a.binanceSymbol).filter((s): s is string => !!s);
  const pricesPromise = withTimeout(fetchBinancePrices(binanceSymbols), 6000, {});

  await Promise.all(
    allAssets.map(async (asset) => {
      const network = NETWORKS[asset.network];
      const balancePromise: Promise<number | null> =
        network.chainType === 'evm'
          ? fetchEvmBalance(asset, evmAddress)
          : network.chainType === 'sol' && solAddress
            ? fetchSolanaBalance(asset, solAddress)
            : network.chainType === 'btc' && btcAddress
              ? import('./bitcoin').then((m) => m.fetchBitcoinBalance(btcAddress))
              : Promise.resolve(null);

      const canonicalPricePromise = asset.isNative
        ? trpcVanilla.market.nativePrice.query({ network: asset.network }).catch(() => null)
        : asset.contractAddress
          ? trpcVanilla.market.assetPrice
              .query({ network: asset.network, contractAddress: asset.contractAddress, symbol: asset.symbol, decimals: asset.decimals })
              .catch(() => null)
          : Promise.resolve(null);
      const [balance, prices, canonicalPrice] = await Promise.all([
        withTimeout(balancePromise, 6000, null),
        pricesPromise,
        withTimeout(canonicalPricePromise, 6000, null),
      ]);
      let priceInfo = canonicalPrice
        ? { price: canonicalPrice.priceUsd, change24h: canonicalPrice.change24h ?? 0 }
        : asset.binanceSymbol
          ? prices[asset.binanceSymbol]
          : undefined;

      // Not on Binance/CoinGecko - true for most imported/custom tokens, since
      // those two only ever cover what they've chosen to list. Ask PAXI's own
      // server cache first: it runs the same DexScreener + on-chain fallback
      // chain, but shared across every wallet instead of each one repeating
      // it, and usually answers from cache in a few ms instead of a live
      // external call. Falls through to the fully client-side path below
      // only if the server is unreachable (offline install, DB down, etc).
      // Server cache/lookup unavailable - fall back to the token's own live
      // DEX price fetched directly from the browser.
      if (!priceInfo && asset.contractAddress) {
        const dexData = await withTimeout(fetchDexMarketData(asset.network, asset.contractAddress), 5000, null);
        if (dexData) priceInfo = { price: dexData.priceUsd, change24h: dexData.change24h ?? 0 };
      }

      // DexScreener hasn't indexed this pair yet (common for a brand-new
      // token) - read the pool's reserves directly over RPC instead, same
      // as balances already do. No 24h change available this way (that
      // needs historical data an indexer provides), so it's reported as 0
      // rather than guessed.
      if (!priceInfo && asset.contractAddress) {
        const network = NETWORKS[asset.network];
        const nativeAsset = allAssets.find((a) => a.network === asset.network && a.isNative);
        const nativeUsdPrice = nativeAsset?.binanceSymbol ? prices[nativeAsset.binanceSymbol]?.price : undefined;
        if (network && nativeUsdPrice) {
          const onChainPrice = await withTimeout(
            fetchOnChainPrice(asset.network, asset.contractAddress, asset.decimals, nativeUsdPrice),
            5000,
            null
          );
          if (onChainPrice) priceInfo = { price: onChainPrice, change24h: 0 };
        }
      }

      const isStablecoin = asset.symbol === 'USDT' || asset.symbol === 'USDC';
      onAsset({
        asset,
        balance,
        usdPrice: isStablecoin ? 1 : priceInfo?.price ?? null,
        change24h: priceInfo?.change24h ?? (isStablecoin ? 0 : null),
      });
    })
  );
}

// Roughly maps each chart range to how many days of CoinGecko history to request.
const RANGE_TO_DAYS: Record<string, number> = { '1h': 1, '4h': 7, '1d': 30, '1w': 365 };

async function fetchCoingeckoHistory(
  binanceSymbol: string,
  interval: string
): Promise<Array<{ time: number; price: number }>> {
  const id = COINGECKO_IDS[binanceSymbol];
  if (!id) return [];
  const days = RANGE_TO_DAYS[interval] ?? 30;
  const url = `${COINGECKO_API}/coins/${id}/market_chart?vs_currency=usd&days=${days}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`CoinGecko history returned ${res.status}`);
  const data: { prices: Array<[number, number]> } = await res.json();
  return data.prices.map(([time, price]) => ({ time, price }));
}

/** Historical candles for the asset-detail price chart. interval e.g. '1h', '1d'; limit = number of candles. */
export async function fetchPriceHistory(
  binanceSymbol: string,
  interval: string,
  limit: number
): Promise<Array<{ time: number; price: number }>> {
  try {
    const url = `${BINANCE_API}/klines?symbol=${binanceSymbol}&interval=${interval}&limit=${limit}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Binance klines returned ${res.status}`);
    const rows: any[] = await res.json();
    if (!Array.isArray(rows) || rows.length === 0) throw new Error('Binance klines returned no candles');
    // Each row: [openTime, open, high, low, close, volume, closeTime, ...]
    return rows.map((r) => ({ time: r[0], price: Number(r[4]) }));
  } catch (err) {
    console.warn('Binance price history failed, falling back to CoinGecko:', err);
    try {
      return await fetchCoingeckoHistory(binanceSymbol, interval);
    } catch (fallbackErr) {
      console.warn('CoinGecko history fallback also failed:', fallbackErr);
      return [];
    }
  }
}

export interface TokenStats {
  marketCap: number | null;
  volume24h: number | null;
  circulatingSupply: number | null;
  totalSupply: number | null;
  circulatingSupplyPct: number | null;
  genesisDate: string | null; // "Created" - ISO date string, e.g. "2015-07-30"
  homepage: string | null;
  twitter: string | null;
  reddit: string | null;
  whitepaper: string | null;
}

/**
 * Market-cap/supply/links data for the Stats panel, from CoinGecko's
 * per-coin endpoint. Only covers the handful of major assets we map to a
 * CoinGecko ID (see COINGECKO_IDS) - custom-imported tokens don't have
 * one, so this resolves to all-null rather than guessing. Note this
 * deliberately does NOT include holder count, security-risk score, or
 * buy/sell transaction split - those come from on-chain/DEX analytics
 * providers (e.g. GoPlus, Moralis, DexScreener) that need a paid API key
 * we don't have wired up yet, so faking them isn't an option; the Stats
 * UI should omit those fields rather than show a made-up number.
 */
export async function fetchTokenStats(binanceSymbol: string): Promise<TokenStats | null> {
  const id = COINGECKO_IDS[binanceSymbol];
  if (!id) return null;
  try {
    const url = `${COINGECKO_API}/coins/${id}?localization=false&tickers=false&community_data=false&developer_data=false&sparkline=false`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`CoinGecko coin detail returned ${res.status}`);
    const data = await res.json();
    const md = data.market_data ?? {};
    const circulating = md.circulating_supply ?? null;
    const total = md.total_supply ?? null;
    return {
      marketCap: md.market_cap?.usd ?? null,
      volume24h: md.total_volume?.usd ?? null,
      circulatingSupply: circulating,
      totalSupply: total,
      circulatingSupplyPct: circulating && total ? (circulating / total) * 100 : null,
      genesisDate: data.genesis_date ?? null,
      homepage: data.links?.homepage?.[0] || null,
      twitter: data.links?.twitter_screen_name ? `https://x.com/${data.links.twitter_screen_name}` : null,
      reddit: data.links?.subreddit_url || null,
      whitepaper: data.links?.whitepaper || null,
    };
  } catch (err) {
    console.warn('Token stats fetch failed:', err);
    return null;
  }
}

export interface DexTokenPanel {
  market: DexMarketData | null;
}

/**
 * For tokens not listed on Binance (most imported ones) - live DEX
 * price/liquidity/market cap and the buy vs sell split across time windows,
 * keyed off the token contract rather than a Binance ticker. Security is
 * resolved separately through the server-backed PAXI Shield panel so its
 * unavailable-provider state remains visible to the user.
 */
export async function fetchDexTokenPanel(asset: AssetConfig): Promise<DexTokenPanel> {
  if (!asset.contractAddress) return { market: null };
  const market = await withTimeout(fetchDexMarketData(asset.network, asset.contractAddress), 6000, null);
  return { market };
}

export async function estimateEvmGasFee(networkId: string, from: string, to: string, valueEth: string) {
  const network = NETWORKS[networkId];
  if (!network.rpcUrl) return null;
  try {
    const provider = getProvider(network.rpcUrl);
    const [feeData, gasLimit] = await Promise.all([
      provider.getFeeData(),
      provider.estimateGas({ from, to, value: valueEth ? BigInt(Math.round(Number(valueEth) * 1e18)) : 0n }).catch(() => 21000n),
    ]);
    const gasPrice = feeData.maxFeePerGas ?? feeData.gasPrice ?? 0n;
    const feeWei = gasPrice * gasLimit;
    return {
      gasLimit: gasLimit.toString(),
      gasPriceGwei: formatUnits(gasPrice, 'gwei'),
      estimatedFeeNative: formatUnits(feeWei, 18),
    };
  } catch (err) {
    console.warn('Gas estimate failed:', err);
    return null;
  }
}
