/**
 * Live balance + price lookups.
 *
 * EVM balances are real: fetched over public RPC endpoints with ethers.js
 * (no API key needed). Prices/charts come from Binance's public market
 * data on data-api.binance.vision - the domain Binance publishes
 * specifically for third-party/browser callers (api.binance.com does
 * not send CORS headers for arbitrary origins and gets silently blocked
 * by the browser). CoinGecko is used as a second-layer fallback if
 * Binance is ever down, rate-limited, or missing a symbol.
 * Anything that fails (offline, RPC hiccup, no market pair, unimplemented
 * BTC/SOL derivation) resolves to `null` rather than a fake number, so the
 * UI can show "—" instead of quietly lying.
 */
import { JsonRpcProvider, formatUnits, Contract } from 'ethers';
import { ASSETS, NETWORKS, type AssetConfig } from './chains';
import { customTokenToAsset, getCustomTokens } from './customTokens';
import { trpcVanilla } from '../trpcVanilla';
import type { TokenFieldSources } from '../phase3Models';

const ERC20_ABI = ['function balanceOf(address) view returns (uint256)'];
export const COINGECKO_IDS: Record<string, string> = {
  BNBUSDT: 'binancecoin',
  ETHUSDT: 'ethereum',
  BTCUSDT: 'bitcoin',
  SOLUSDT: 'solana',
  POLUSDT: 'polygon-ecosystem-token',
  USDTUSDT: 'tether',
  USDCUSDT: 'usd-coin',
};

const providerCache = new Map<string, JsonRpcProvider>();
function getProvider(rpcUrl: string): JsonRpcProvider {
  let p = providerCache.get(rpcUrl);
  if (!p) {
    p = new JsonRpcProvider(rpcUrl);
    providerCache.set(rpcUrl, p);
  }
  return p;
}

/** Race a promise against a timeout so one slow RPC/API call can't stall the whole dashboard. */
function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return Promise.race([promise, new Promise<T>((resolve) => setTimeout(() => resolve(fallback), ms))]);
}

export interface AssetBalance {
  asset: AssetConfig;
  balance: number | null; // null = unavailable
  usdPrice: number | null;
  change24h: number | null;
  /** Actual sources for market fields; unavailable fields are omitted. */
  fieldSources?: TokenFieldSources;
}

interface ClientPriceQuote {
  price: number;
  change24h: number | null;
  source: string;
}

export interface PortfolioQuoteLike {
  network: string;
  isNative: boolean;
  contractAddress: string | null;
  priceUsd: number;
  change24h: number | null;
  source: string;
}

/** Builds the client lookup map from server quotes without symbol-based identity. */
function quoteIdentity(network: string, isNative: boolean, contractAddress?: string | null): string {
  if (isNative) return `${network}:native`;
  const normalizedAddress = network === 'solana'
    ? contractAddress ?? ''
    : contractAddress?.toLowerCase() ?? '';
  return `${network}:${normalizedAddress}`;
}

export function mapPortfolioQuotes(quotes: readonly PortfolioQuoteLike[]): Map<string, PortfolioQuoteLike> {
  return new Map(quotes.map((quote) => [quoteIdentity(quote.network, quote.isNative, quote.contractAddress), quote]));
}

/** Live balance for a single asset - used by Swap/Bridge/Send to pre-check funds before quoting or signing.
 * `solAddress`/`btcAddress` are optional and only needed for those chains (different address than the EVM one). */
export async function fetchAssetBalance(
  asset: AssetConfig,
  evmAddress: string,
  solAddress?: string,
  btcAddress?: string
): Promise<number | null> {
  const network = NETWORKS[asset.network];
  if (network.chainType === 'evm') return fetchEvmBalance(asset, evmAddress);
  if (network.chainType === 'sol' && solAddress) return fetchSolanaBalance(asset, solAddress);
  if (network.chainType === 'btc' && btcAddress) {
    const { fetchBitcoinBalance } = await import('./bitcoin');
    return fetchBitcoinBalance(btcAddress);
  }
  return null;
}

async function fetchSolanaBalance(asset: AssetConfig, solAddress: string): Promise<number | null> {
  const network = NETWORKS[asset.network];
  if (!network.rpcUrl) return null;
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    const connection = new Connection(network.rpcUrl, 'confirmed');
    const owner = new PublicKey(solAddress);

    if (asset.isNative) {
      const lamports = await connection.getBalance(owner);
      return lamports / 1e9;
    }

    if (asset.contractAddress) {
      const mint = new PublicKey(asset.contractAddress);
      const { TOKEN_PROGRAM_ID } = await import('./solanaSplSafe');
      const accounts = await connection.getParsedTokenAccountsByOwner(owner, { mint, programId: TOKEN_PROGRAM_ID });
      const total = accounts.value.reduce(
        (sum, acc) => sum + (acc.account.data.parsed.info.tokenAmount.uiAmount ?? 0),
        0,
      );
      return total;
    }
    return null;
  } catch (err) {
    console.warn(`Solana balance fetch failed for ${asset.symbol}:`, err);
    return null;
  }
}

async function fetchEvmBalance(asset: AssetConfig, evmAddress: string): Promise<number | null> {
  const network = NETWORKS[asset.network];
  if (!network.rpcUrl) return null;
  try {
    const provider = getProvider(network.rpcUrl);
    if (asset.isNative) {
      const raw = await provider.getBalance(evmAddress);
      return Number(formatUnits(raw, asset.decimals));
    }
    if (asset.contractAddress) {
      const contract = new Contract(asset.contractAddress, ERC20_ABI, provider);
      const raw = await contract.balanceOf(evmAddress);
      return Number(formatUnits(raw, asset.decimals));
    }
    return null;
  } catch (err) {
    console.warn(`Balance fetch failed for ${asset.symbol}:`, err);
    return null;
  }
}


/**
 * Fetch balances + prices for every configured asset, calling `onAsset` as
 * soon as each individual asset resolves (max 6s per asset) instead of
 * waiting for every RPC call to finish before showing anything. The price
 * lookup is one shared batched request, awaited once up front.
 */
export async function fetchAllBalancesStreaming(
  evmAddress: string,
  onAsset: (result: AssetBalance) => void,
  solAddress?: string,
  btcAddress?: string,
  assetsToFetch?: AssetConfig[],
): Promise<void> {
  const customAssets = getCustomTokens().map(customTokenToAsset);
  const allAssets = assetsToFetch ?? [...ASSETS, ...customAssets];

  const quoteResponsePromise = withTimeout(
    trpcVanilla.market.portfolioQuotes.query({
      assets: allAssets.map((asset) => ({
        network: asset.network,
        isNative: asset.isNative,
        ...(asset.contractAddress ? { contractAddress: asset.contractAddress } : {}),
        ...(asset.symbol ? { symbol: asset.symbol } : {}),
        decimals: asset.decimals,
      })),
    }).catch((error) => {
      console.warn('Canonical portfolio quote request failed:', error);
      return [];
    }),
    8000,
    [],
  );
  const quoteMapPromise = quoteResponsePromise.then((quotes) => mapPortfolioQuotes(quotes));

  await Promise.all(
    allAssets.map(async (asset) => {
      const network = NETWORKS[asset.network];
      const balancePromise: Promise<number | null> =
        network.chainType === 'evm'
          ? fetchEvmBalance(asset, evmAddress)
          : network.chainType === 'sol' && solAddress
            ? fetchSolanaBalance(asset, solAddress)
            : network.chainType === 'btc' && btcAddress
              ? import('./bitcoin').then((m) => m.fetchBitcoinBalance(btcAddress))
              : Promise.resolve(null);

      const [balance, quoteMap] = await Promise.all([
        withTimeout(balancePromise, 6000, null),
        quoteMapPromise,
      ]);
      const quoteKey = quoteIdentity(asset.network, asset.isNative, asset.contractAddress);
      const canonicalPrice = quoteMap.get(quoteKey);
      const priceInfo: ClientPriceQuote | undefined = canonicalPrice && canonicalPrice.priceUsd != null
        ? {
            price: canonicalPrice.priceUsd,
            change24h: canonicalPrice.change24h,
            source: canonicalPrice.source,
          }
        : undefined;

          onAsset({
        asset,
        balance,
        usdPrice: priceInfo?.price ?? null,
        change24h: priceInfo?.change24h ?? null,
        fieldSources: priceInfo?.price != null
          ? {
              price: [priceInfo.source],
              ...(priceInfo.change24h != null ? { change24h: [priceInfo.source] } : {}),
            }
          : undefined,
      });
    })
  );
}

export async function estimateEvmGasFee(networkId: string, from: string, to: string, valueEth: string) {
  const network = NETWORKS[networkId];
  if (!network.rpcUrl) return null;
  try {
    const provider = getProvider(network.rpcUrl);
    const [feeData, gasLimit] = await Promise.all([
      provider.getFeeData(),
      provider.estimateGas({ from, to, value: valueEth ? BigInt(Math.round(Number(valueEth) * 1e18)) : 0n }).catch(() => 21000n),
    ]);
    const gasPrice = feeData.maxFeePerGas ?? feeData.gasPrice ?? 0n;
    const feeWei = gasPrice * gasLimit;
    return {
      gasLimit: gasLimit.toString(),
      gasPriceGwei: formatUnits(gasPrice, 'gwei'),
      estimatedFeeNative: formatUnits(feeWei, 18),
    };
  } catch (err) {
    console.warn('Gas estimate failed:', err);
    return null;
  }
}
