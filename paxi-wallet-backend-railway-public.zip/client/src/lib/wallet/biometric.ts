/**
 * Thin wrapper around the WebAuthn API for platform biometrics
 * (Face ID / Touch ID / Android fingerprint). A successful assertion here
 * is what gates recovering the wrapped PIN in vault.ts.
 */
import { BIOMETRIC_CREDENTIAL_KEY } from './vault';

export async function isBiometricAvailable(): Promise<boolean> {
  try {
    if (!window.PublicKeyCredential) return false;
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

export async function registerBiometric(username: string): Promise<boolean> {
  try {
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: 'PAXI Wallet', id: window.location.hostname },
        user: {
          id: new TextEncoder().encode(username),
          name: username,
          displayName: username,
        },
        pubKeyCredParams: [
          { alg: -7, type: 'public-key' }, // ES256
          { alg: -257, type: 'public-key' }, // RS256
        ],
        authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required' },
        timeout: 60000,
      },
    })) as PublicKeyCredential | null;

    if (!credential) return false;
    const idBytes = new Uint8Array(credential.rawId);
    let binary = '';
    for (let i = 0; i < idBytes.length; i++) binary += String.fromCharCode(idBytes[i]);
    localStorage.setItem(BIOMETRIC_CREDENTIAL_KEY, btoa(binary));
    return true;
  } catch (error) {
    console.error('Biometric registration failed:', error);
    return false;
  }
}

export async function authenticateWithBiometric(): Promise<boolean> {
  try {
    const stored = localStorage.getItem(BIOMETRIC_CREDENTIAL_KEY);
    if (!stored) return false;
    const binary = atob(stored);
    const credentialId = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) credentialId[i] = binary.charCodeAt(i);

    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const assertion = (await navigator.credentials.get({
      publicKey: {
        challenge,
        allowCredentials: [{ id: credentialId, type: 'public-key', transports: ['internal'] }],
        userVerification: 'required',
        timeout: 60000,
      },
    })) as PublicKeyCredential | null;

    return !!assertion;
  } catch (error) {
    console.error('Biometric authentication failed:', error);
    return false;
  }
}
