import { afterEach, describe, expect, it, vi } from 'vitest';
import { bitcoinSatsForLibrary, computeBitcoinMaxSend, estimateVBytes, proxied, type Utxo } from './bitcoin';
import { getAddressForChainType } from './engine';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('Bitcoin send estimation', () => {
  it('uses the same two-output conservative fee shape as the sender', () => {
    const utxos: Utxo[] = [
      { txid: 'a'.repeat(64), vout: 0, value: 100_000n },
      { txid: 'b'.repeat(64), vout: 1, value: 50_000n },
    ];
    const result = computeBitcoinMaxSend(utxos, 10);

    expect(result.feeSats).toBe(BigInt(estimateVBytes(2, 2)) * 10n);
    expect(result.amountSats).toBe(150_000n - result.feeSats);
    expect(result.amountBtc).toBe('0.0014791');
    expect(result.inputCount).toBe(2);
  });

  it('keeps large exact satoshi values until the guarded bitcoinjs-lib boundary', () => {
    const exact = 2_000_000_000_000_000n;
    expect(BigInt(bitcoinSatsForLibrary(exact))).toBe(exact);
    expect(() => bitcoinSatsForLibrary(9_007_199_254_740_992n)).toThrow(/protocol-safe/);
  });

  it('normalizes invalid or fractional fee rates conservatively', () => {
    const result = computeBitcoinMaxSend([{ txid: 'a'.repeat(64), vout: 0, value: 100_000n }], 0.2);
    expect(result.feeRate).toBe(1n);
    expect(result.feeSats).toBe(BigInt(estimateVBytes(1, 2)));
  });

  it('routes Esplora requests through the server proxy', () => {
    const url = proxied('/tx/abc/status');
    expect(url).toContain('/api/blockscout-proxy?url=');
    expect(decodeURIComponent(url)).toContain('https://blockstream.info/api/tx/abc/status');
  });

  it('parses a confirmed Esplora transaction status', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ confirmed: true, block_height: 123, block_hash: 'block', block_time: 1_700_000_000 }),
    });
    vi.stubGlobal('fetch', fetchMock);
    const { fetchBitcoinTransactionStatus } = await import('./bitcoin');
    await expect(fetchBitcoinTransactionStatus('abc')).resolves.toEqual({
      confirmed: true,
      blockHeight: 123,
      blockHash: 'block',
      blockTime: 1_700_000_000,
    });
    expect(fetchMock).toHaveBeenCalledOnce();
  });

  it('does not fabricate BTC or Solana addresses for an EVM-only private-key import', () => {
    const privateKey = '11'.repeat(32);
    expect(getAddressForChainType(privateKey, 'evm')).toMatch(/^0x[0-9a-f]{40}$/i);
    expect(getAddressForChainType(privateKey, 'btc')).toBeNull();
    expect(getAddressForChainType(privateKey, 'sol')).toBeNull();
  });

  it('keeps an unconfirmed Esplora transaction pending', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => ({ confirmed: false }) }));
    const { fetchBitcoinTransactionStatus } = await import('./bitcoin');
    await expect(fetchBitcoinTransactionStatus('abc')).resolves.toEqual({ confirmed: false });
  });
});
