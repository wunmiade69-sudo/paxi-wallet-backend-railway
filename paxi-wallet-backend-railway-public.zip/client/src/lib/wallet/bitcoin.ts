/**
 * Bitcoin support - a genuinely different model from EVM/Solana (UTXOs,
 * not accounts), so it gets its own file rather than slotting into
 * balances.ts/send.ts's existing shapes.
 *
 * Uses Blockstream's public esplora API (https://blockstream.info/api) for
 * balance, UTXOs, fee estimates, and broadcasting - routed through our own
 * server proxy (server/_core/blockscoutProxy.ts) rather than called
 * directly from the browser, for the same CORS reasons as the EVM history
 * indexer.
 */
import * as bitcoin from 'bitcoinjs-lib';
import { deriveBitcoinKeyPair } from './engine';
import { formatBaseUnits, parseExactBaseUnits } from './decimalParsing';

const ESPLORA_BASE = 'https://blockstream.info/api';

export function proxied(path: string): string {
  return `/api/blockscout-proxy?url=${encodeURIComponent(`${ESPLORA_BASE}${path}`)}`;
}

export interface Utxo {
  txid: string;
  vout: number;
  value: bigint; // satoshis; exact until the bitcoinjs-lib boundary
}

export interface BitcoinTransactionStatus {
  confirmed: boolean;
  blockHeight?: number;
  blockHash?: string;
  blockTime?: number;
}

export interface BitcoinMaxSendEstimate {
  amountSats: bigint;
  amountBtc: string;
  feeSats: bigint;
  feeRate: bigint;
  inputCount: number;
}

// Bitcoin's consensus supply cap is 21,000,000 BTC = 2.1e15 satoshis.
// bitcoinjs-lib currently accepts transaction output values as Number, so every
// conversion at that library boundary is guarded by this protocol invariant.
const MAX_BITCOIN_SATS = 21_000_000n * 100_000_000n;

export function bitcoinSatsForLibrary(units: bigint): number {
  if (units < 0n || units > MAX_BITCOIN_SATS || units > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error('Bitcoin amount exceeds the protocol-safe transaction range.');
  }
  return Number(units);
}

/** Balance in BTC (not satoshis) - confirmed + unconfirmed funds minus spent. */
export async function fetchBitcoinBalance(address: string): Promise<string | null> {
  try {
    const res = await fetch(proxied(`/address/${address}`));
    if (!res.ok) return null;
    const data = await res.json();
    const satoshis =
      data.chain_stats.funded_txo_sum -
      data.chain_stats.spent_txo_sum +
      data.mempool_stats.funded_txo_sum -
      data.mempool_stats.spent_txo_sum;
    const totalSats = BigInt(satoshis);
    if (totalSats < 0n || totalSats > MAX_BITCOIN_SATS) return null;
    return formatBaseUnits(totalSats, 8);
  } catch (err) {
    console.warn('Bitcoin balance fetch failed:', err);
    return null;
  }
}

export async function fetchUtxos(address: string): Promise<Utxo[]> {
  const res = await fetch(proxied(`/address/${address}/utxo`));
  if (!res.ok) throw new Error('Could not fetch Bitcoin UTXOs.');
  const data = await res.json();
  return data.map((u: any) => {
    const value = BigInt(String(u.value));
    if (value < 0n || value > MAX_BITCOIN_SATS) throw new Error('Invalid Bitcoin UTXO value.');
    return { txid: u.txid, vout: u.vout, value };
  });
}

/** Sat/vByte fee rate targeting ~6-block (roughly 1 hour) confirmation. */
function ceilFeeRate(value: unknown): bigint {
  const text = String(value ?? '10').trim();
  if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(text)) return 10n;
  const [whole, fraction = ''] = text.split('.');
  const wholeUnits = BigInt(whole);
  return wholeUnits + (fraction.length > 0 && /[1-9]/.test(fraction) ? 1n : 0n);
}

export async function fetchFeeRate(): Promise<bigint> {
  try {
    const res = await fetch(proxied('/fee-estimates'));
    if (!res.ok) return 10n; // sane fallback if the endpoint is briefly unavailable
    const data = await res.json();
    return ceilFeeRate(data['6'] ?? 10);
  } catch {
    return 10n;
  }
}

export async function fetchPrevTxHex(txid: string): Promise<string> {
  const res = await fetch(proxied(`/tx/${txid}/hex`));
  if (!res.ok) throw new Error(`Could not fetch previous transaction ${txid}.`);
  return res.text();
}

/** Best-effort confirmation status from Blockstream Esplora. */
export async function fetchBitcoinTransactionStatus(txid: string): Promise<BitcoinTransactionStatus | null> {
  try {
    const res = await fetch(proxied(`/tx/${encodeURIComponent(txid)}/status`));
    if (!res.ok) return null;
    const data = await res.json();
    return {
      confirmed: data?.confirmed === true,
      blockHeight: Number.isFinite(data?.block_height) ? Number(data.block_height) : undefined,
      blockHash: typeof data?.block_hash === 'string' ? data.block_hash : undefined,
      blockTime: Number.isFinite(data?.block_time) ? Number(data.block_time) : undefined,
    };
  } catch {
    return null;
  }
}

/** Rough, conservative vByte estimate for a P2WPKH-only transaction - used to
 * compute the fee before the transaction is actually built. Slightly
 * overestimating is intentional: a stuck-forever underpaid tx is worse than
 * a slightly larger fee. */
export function estimateVBytes(inputCount: number, outputCount: number): number {
  return 11 + inputCount * 68 + outputCount * 31;
}

/**
 * Computes the maximum safe send amount using the same conservative fee model
 * as sendBitcoinAsset. We reserve a two-output fee so the actual sender can
 * safely use all selected inputs even if the transaction shape keeps a change
 * output during selection; any remainder is then zero or dust and becomes fee.
 */
export function computeBitcoinMaxSend(utxos: Utxo[], feeRate: number | bigint): BitcoinMaxSendEstimate {
  const normalizedFeeRate = typeof feeRate === 'bigint'
    ? (feeRate > 0n ? feeRate : 1n)
    : (() => {
      const parsed = ceilFeeRate(String(feeRate));
      return parsed > 0n ? parsed : 1n;
    })();
  const totalSats = utxos.reduce((sum, utxo) => {
    if (utxo.value < 0n || utxo.value > MAX_BITCOIN_SATS) throw new Error('Invalid Bitcoin UTXO value.');
    return sum + utxo.value;
  }, 0n);
  const feeSats = BigInt(estimateVBytes(utxos.length, 2)) * normalizedFeeRate;
  const amountSats = totalSats > feeSats ? totalSats - feeSats : 0n;
  return {
    amountSats,
    amountBtc: formatBaseUnits(amountSats, 8),
    feeSats,
    feeRate: normalizedFeeRate,
    inputCount: utxos.length,
  };
}

export async function estimateBitcoinMaxSend(address: string): Promise<BitcoinMaxSendEstimate> {
  if (!address) throw new Error('Could not derive Bitcoin sending address.');
  const [utxos, feeRate] = await Promise.all([fetchUtxos(address), fetchFeeRate()]);
  if (utxos.length === 0) throw new Error('No spendable Bitcoin found in this wallet.');
  const estimate = computeBitcoinMaxSend(utxos, feeRate);
  if (estimate.amountSats <= 546n) throw new Error('Bitcoin balance is too small to cover the network fee.');
  return estimate;
}

export async function sendBitcoinAsset(params: {
  mnemonic: string;
  toAddress: string;
  amountBtc: string;
}): Promise<{ hash: string; explorerUrl?: string }> {
  const keyPair = deriveBitcoinKeyPair(params.mnemonic);
  const { address: fromAddress } = bitcoin.payments.p2wpkh({
    pubkey: Buffer.from(keyPair.publicKey),
    network: bitcoin.networks.bitcoin,
  });
  if (!fromAddress) throw new Error('Could not derive sending address.');

  // Exact string->bigint conversion (never Number()/Math.round()), then a safe
  // widen to Number: BTC's fixed 21M supply cap means the largest possible
  // satoshi value (2.1e15) is always far inside Number.MAX_SAFE_INTEGER, so
  // the widen itself introduces no precision loss - the exactness already
  // happened in parseExactBaseUnits.
  const amountSats = parseExactBaseUnits(params.amountBtc, 8);

  const [utxos, feeRate] = await Promise.all([fetchUtxos(fromAddress), fetchFeeRate()]);
  if (utxos.length === 0) throw new Error('No spendable Bitcoin found in this wallet.');

  // Simple oldest-first coin selection until the target + estimated fee is covered.
  utxos.sort((a, b) => (a.value === b.value ? 0 : a.value > b.value ? -1 : 1));
  const selected: Utxo[] = [];
  let total = 0n;
  for (const utxo of utxos) {
    selected.push(utxo);
    total += utxo.value;
    const estimatedFee = BigInt(estimateVBytes(selected.length, 2)) * feeRate;
    if (total >= amountSats + estimatedFee) break;
  }

  const estimatedFee = BigInt(estimateVBytes(selected.length, 2)) * feeRate;
  if (total < amountSats + estimatedFee) {
    throw new Error('Insufficient BTC balance to cover the amount plus network fee.');
  }

  const psbt = new bitcoin.Psbt({ network: bitcoin.networks.bitcoin });

  for (const utxo of selected) {
    const prevTxHex = await fetchPrevTxHex(utxo.txid);
    const prevTx = bitcoin.Transaction.fromHex(prevTxHex);
    psbt.addInput({
      hash: utxo.txid,
      index: utxo.vout,
      witnessUtxo: { script: prevTx.outs[utxo.vout].script, value: bitcoinSatsForLibrary(utxo.value) },
    });
  }

  psbt.addOutput({ address: params.toAddress, value: bitcoinSatsForLibrary(amountSats) });

  const change = total - amountSats - estimatedFee;
  if (change > 546n) {
    // Above Bitcoin's "dust" threshold - otherwise just let it go to the miner as extra fee.
    psbt.addOutput({ address: fromAddress, value: bitcoinSatsForLibrary(change) });
  }

  selected.forEach((_, i) => psbt.signInput(i, keyPair));
  psbt.finalizeAllInputs();

  const txHex = psbt.extractTransaction().toHex();

  const broadcastRes = await fetch(proxied('/tx'), {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: txHex,
  });
  if (!broadcastRes.ok) {
    const errText = await broadcastRes.text().catch(() => '');
    throw new Error(`Broadcast failed: ${errText || broadcastRes.statusText}`);
  }
  const txid = (await broadcastRes.text()).trim();

  return { hash: txid, explorerUrl: `https://blockstream.info/tx/${txid}` };
}
