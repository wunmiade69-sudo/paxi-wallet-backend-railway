import { describe, expect, it } from "vitest";
import {
  BETA_BRIDGE_NETWORKS,
  isBridgeDestination,
  isBridgeSource,
} from "./bridge";

describe("controlled-beta bridge support", () => {
  it("exposes only the verified Ethereum, BSC, and Solana route set", () => {
    expect(BETA_BRIDGE_NETWORKS).toEqual(["ethereum", "bsc", "solana"]);
    for (const network of BETA_BRIDGE_NETWORKS) {
      expect(isBridgeDestination(network)).toBe(true);
      expect(isBridgeSource(network)).toBe(true);
    }
  });

  it("fails closed for Bitcoin, Polygon, Arbitrum, and custom networks", () => {
    for (const network of ["bitcoin", "polygon", "arbitrum", "custom-chain"]) {
      expect(isBridgeDestination(network)).toBe(false);
      expect(isBridgeSource(network)).toBe(false);
    }
  });
});
