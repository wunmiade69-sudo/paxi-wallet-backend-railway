/**
 * Cross-chain bridging via the LI.FI aggregator API. No API key needed
 * for basic use (rate-limited per IP, fine for a wallet this size).
 *
 * LI.FI aggregates many underlying bridges (Stargate, Across, Hop, and
 * others) plus DEXs for any swap leg, and picks the best route the same
 * way Velora does for same-chain swaps in swap.ts.
 *
 * Supports EVM<->EVM (Ethereum <-> BSC) and EVM<->Solana. Solana is a
 * real leg now - deriveSolanaKeypair() in engine.ts derives a real
 * ed25519 address from the same mnemonic (already used for same-chain
 * Solana swaps in jupiterSwap.ts), so funds sent to/from it are
 * recoverable. Bitcoin is still excluded - LI.FI doesn't route to/from it.
 *
 * EVM and Solana transactions are fundamentally different shapes:
 *  - EVM leg: {to, data, value, chainId} - signed/sent with ethers, same
 *    as before, including the ERC-20 approval step.
 *  - Solana leg: {data} only - a base64-encoded, unsigned, already-built
 *    Solana transaction. No approval step (Solana has no allowance
 *    concept); just deserialize, sign with the derived keypair, and send.
 *  See https://docs.li.fi/introduction/user-flows-and-examples/solana-tx-execution
 *
 * FEE NOTE: the `fee`/`integrator` params below only tell LI.FI what cut
 * to take - WHERE that cut is paid out is configured separately, per
 * chain, in the LI.FI Partner Portal (portal.li.fi) for the "paxiwallet"
 * integrator string. It is a DIFFERENT payout address per chain family
 * (one for EVM, a separate one for Solana). The bridge rate is supplied by
 * the backend fee configuration; confirm/set both payout wallets in the LI.FI
 * portal before relying on bridge fees landing anywhere.
 */
import {
  Contract,
  JsonRpcProvider,
  MaxUint256,
  formatUnits,
  parseUnits,
} from "ethers";
import { Connection, PublicKey, VersionedTransaction } from "@solana/web3.js";
import type { TxStatus } from "./txHistory";
import { NETWORKS, type AssetConfig, type ChainType } from "./chains";
import { walletFromMnemonic, deriveSolanaKeypair } from "./engine";

export const NATIVE_TOKEN_ADDRESS_LIFI =
  "0x0000000000000000000000000000000000000000";
/** LI.FI's placeholder for native SOL - Solana has no real "native token address". */
export const NATIVE_SOL_ADDRESS_LIFI = "11111111111111111111111111111111";
/** LI.FI's (LI.FI-specific, not Solana's actual) chain ID for Solana. */
const LIFI_SOLANA_CHAIN_ID = 1151111081099710;

// Quotes go through the same-origin server proxy so an optional LI.FI API key
// remains server-side and the upstream request is rate-limited centrally.
const LIFI_PROXY_PATH = "/api/lifi-proxy";
const INTEGRATOR = "paxiwallet";

const ERC20_ABI = [
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
];

function tokenAddressFor(asset: AssetConfig): string {
  const chainType = NETWORKS[asset.network]?.chainType;
  if (chainType === "sol")
    return asset.isNative ? NATIVE_SOL_ADDRESS_LIFI : asset.contractAddress!;
  return asset.isNative ? NATIVE_TOKEN_ADDRESS_LIFI : asset.contractAddress!;
}

function lifiChainId(networkId: string): number | undefined {
  const network = NETWORKS[networkId];
  if (!network) return undefined;
  return network.chainType === "sol" ? LIFI_SOLANA_CHAIN_ID : network.chainId;
}

/**
 * Controlled-beta bridge routes. Polygon, Arbitrum, and custom networks remain
 * available for wallet balances/send where configured, but are not exposed as
 * bridge routes until their route, asset, and recovery behavior is verified.
 */
export const BETA_BRIDGE_NETWORKS = ["ethereum", "bsc", "solana"] as const;

/** Only explicitly verified networks are exposed as bridge destinations. */
export function isBridgeDestination(networkId: string): boolean {
  return BETA_BRIDGE_NETWORKS.includes(
    networkId as (typeof BETA_BRIDGE_NETWORKS)[number]
  );
}

/** The controlled-beta source set is the same as the destination set. */
export function isBridgeSource(networkId: string): boolean {
  return isBridgeDestination(networkId);
}

export interface BridgeQuote {
  raw: any; // full LI.FI quote, passed back verbatim when sending the tx
  srcAmountUnits: string;
  destAmountFormatted: string;
  destAmountMinFormatted: string;
  approvalAddress: string | null; // null for a Solana source leg - no approval concept there
  /** Solana-source quotes only populate `data`; EVM-source quotes populate all fields. */
  transactionRequest: {
    to?: string;
    data: string;
    value?: string;
    chainId?: number;
  };
  executionDurationSeconds: number;
  feeAmountFormatted: string; // in srcAsset units
  feeBps: number; // backend-configured bridge rate
  routeNames: string[]; // bridge + any DEX legs used, e.g. ["Stargate", "PancakeSwap"]
}

export async function fetchBridgeQuote(params: {
  fromNetworkId: string;
  toNetworkId: string;
  srcAsset: AssetConfig;
  destAsset: AssetConfig;
  amount: string; // human units of srcAsset
  /** Sender address, in the format of fromNetworkId's chain type (EVM 0x... or Solana base58). */
  fromAddress: string;
  /** Receive address, in the format of toNetworkId's chain type. Same as fromAddress for EVM<->EVM. */
  toAddress: string;
  slippage: number; // decimal, e.g. 0.01 = 1%
  feeBps: number; // returned by the backend fee configuration endpoint
}): Promise<BridgeQuote> {
  const { srcAsset, destAsset } = params;
  const fromNetwork = NETWORKS[params.fromNetworkId];
  const toNetwork = NETWORKS[params.toNetworkId];
  if (!fromNetwork || !isBridgeSource(params.fromNetworkId)) {
    throw new Error(
      `Bridging from ${fromNetwork?.label ?? "that network"} isn't supported yet.`
    );
  }
  if (
    srcAsset.network !== params.fromNetworkId ||
    destAsset.network !== params.toNetworkId
  ) {
    throw new Error(
      "Bridge asset/network mismatch. Select the asset on the chosen network."
    );
  }
  if (!isBridgeDestination(params.toNetworkId)) {
    throw new Error(
      `Bridging to ${toNetwork?.label ?? "that network"} isn't supported yet - this wallet doesn't have a real address for it.`
    );
  }
  if (!params.fromAddress || !params.toAddress) {
    throw new Error(
      "Unlock your wallet to get a Solana address before bridging to/from Solana."
    );
  }
  const fromChainId = lifiChainId(params.fromNetworkId);
  const toChainId = lifiChainId(params.toNetworkId);
  if (!fromChainId || !toChainId)
    throw new Error("Missing chain ID for this network.");
  if (
    !Number.isInteger(params.feeBps) ||
    params.feeBps < 0 ||
    params.feeBps > 10_000
  )
    throw new Error("Invalid backend fee configuration.");
  if (
    !Number.isFinite(params.slippage) ||
    params.slippage < 0.001 ||
    params.slippage > 0.05
  )
    throw new Error("Invalid bridge slippage tolerance.");

  const srcAmountUnits = parseUnits(
    params.amount,
    srcAsset.decimals
  ).toString();
  const qs = new URLSearchParams({
    fromChain: String(fromChainId),
    toChain: String(toChainId),
    fromToken: tokenAddressFor(srcAsset),
    toToken: tokenAddressFor(destAsset),
    fromAddress: params.fromAddress,
    toAddress: params.toAddress,
    fromAmount: srcAmountUnits,
    slippage: String(params.slippage),
    integrator: INTEGRATOR,
    fee: String(params.feeBps / 10000),
  });

  const res = await fetch(`${LIFI_PROXY_PATH}?path=/quote&${qs.toString()}`);
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(
      body?.message ||
        `Could not fetch a bridge quote (${res.status}). Try a different amount or pair.`
    );
  }
  const data = await res.json();
  const estimate = data.estimate;
  if (!estimate || !data.transactionRequest)
    throw new Error("No bridge route found for this pair.");

  const destAmountFormatted = formatUnits(
    estimate.toAmount,
    destAsset.decimals
  );
  const destAmountMinFormatted = formatUnits(
    estimate.toAmountMin,
    destAsset.decimals
  );
  const feeAmountFormatted = (
    (Number(params.amount) * params.feeBps) /
    10000
  ).toFixed(8);

  const routeNames = new Set<string>();
  if (data.toolDetails?.name) routeNames.add(data.toolDetails.name);
  for (const step of data.includedSteps ?? []) {
    if (step.toolDetails?.name) routeNames.add(step.toolDetails.name);
  }

  return {
    raw: data,
    srcAmountUnits,
    destAmountFormatted,
    destAmountMinFormatted,
    approvalAddress: estimate.approvalAddress ?? null,
    transactionRequest: data.transactionRequest,
    executionDurationSeconds: estimate.executionDuration ?? 0,
    feeAmountFormatted,
    feeBps: params.feeBps,
    routeNames: [...routeNames],
  };
}

async function getAllowance(
  rpcUrl: string,
  tokenAddress: string,
  owner: string,
  spender: string
): Promise<bigint> {
  const provider = new JsonRpcProvider(rpcUrl);
  const contract = new Contract(tokenAddress, ERC20_ABI, provider);
  return contract.allowance(owner, spender);
}

export interface BridgeResult {
  approvalHash?: string;
  bridgeHash: string;
  explorerUrl?: string;
  status?: Extract<TxStatus, "submitted" | "confirmed">;
  finality?: "solana_confirmed";
}

async function executeEvmBridge(params: {
  mnemonic: string;
  fromNetworkId: string;
  srcAsset: AssetConfig;
  quote: BridgeQuote;
  userAddress: string;
  onStatus?: (status: "approving" | "bridging") => void;
}): Promise<BridgeResult> {
  const { srcAsset, quote, userAddress } = params;
  const network = NETWORKS[params.fromNetworkId];
  if (!network.rpcUrl)
    throw new Error(`${network.label} RPC is not configured yet`);

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);

  let approvalHash: string | undefined;
  if (!srcAsset.isNative && quote.approvalAddress) {
    const tokenAddress = srcAsset.contractAddress!;
    const currentAllowance = await getAllowance(
      network.rpcUrl,
      tokenAddress,
      userAddress,
      quote.approvalAddress
    );
    if (currentAllowance < BigInt(quote.srcAmountUnits)) {
      params.onStatus?.("approving");
      const erc20 = new Contract(tokenAddress, ERC20_ABI, signer);
      const approveTx = await erc20.approve(quote.approvalAddress, MaxUint256);
      await approveTx.wait();
      approvalHash = approveTx.hash;
    }
  }

  params.onStatus?.("bridging");
  const tx = quote.transactionRequest;
  if (!tx.to) throw new Error("LI.FI did not return a transaction to send.");
  const bridgeTx = await signer.sendTransaction({
    to: tx.to,
    data: tx.data,
    value: tx.value ? BigInt(tx.value) : 0n,
  });

  return {
    approvalHash,
    bridgeHash: bridgeTx.hash,
    explorerUrl: network.explorerTx?.(bridgeTx.hash),
  };
}

/** No approval step - Solana has no allowance concept. Deserialize LI.FI's unsigned tx, sign, send. */
async function executeSolanaBridge(params: {
  mnemonic: string;
  fromNetworkId: string;
  quote: BridgeQuote;
  onStatus?: (status: "approving" | "bridging") => void;
}): Promise<BridgeResult> {
  const network = NETWORKS[params.fromNetworkId];
  if (!network.rpcUrl)
    throw new Error(`${network.label} RPC is not configured yet`);
  if (!params.quote.transactionRequest.data)
    throw new Error("LI.FI did not return a Solana transaction to sign.");

  const connection = new Connection(network.rpcUrl, "confirmed");
  const keypair = deriveSolanaKeypair(params.mnemonic);

  params.onStatus?.("bridging");
  const txBytes = Buffer.from(params.quote.transactionRequest.data, "base64");
  const transaction = VersionedTransaction.deserialize(txBytes);
  transaction.sign([keypair]);

  const signature = await connection.sendRawTransaction(
    transaction.serialize(),
    { maxRetries: 3 }
  );
  try {
    await connection.confirmTransaction(signature, "confirmed");
    return {
      bridgeHash: signature,
      explorerUrl: network.explorerTx?.(signature),
      status: "confirmed",
      finality: "solana_confirmed",
    };
  } catch (error) {
    console.warn(
      "Solana bridge confirmation timed out; leaving status submitted for recovery:",
      error
    );
    return {
      bridgeHash: signature,
      explorerUrl: network.explorerTx?.(signature),
      status: "submitted",
    };
  }
}

/** Approves if needed (EVM only), then sends LI.FI's prebuilt transaction (which includes the wallet fee) as-is. */
export async function executeBridge(params: {
  mnemonic: string;
  fromNetworkId: string;
  srcAsset: AssetConfig;
  quote: BridgeQuote;
  userAddress: string;
  onStatus?: (status: "approving" | "bridging") => void;
}): Promise<BridgeResult> {
  const chainType: ChainType | undefined =
    NETWORKS[params.fromNetworkId]?.chainType;
  if (chainType === "sol") return executeSolanaBridge(params);
  return executeEvmBridge(params);
}
