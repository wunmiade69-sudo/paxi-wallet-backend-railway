/**
 * Cross-chain bridging via the LI.FI aggregator API. No API key needed
 * for basic use (rate-limited per IP, fine for a wallet this size).
 *
 * LI.FI aggregates many underlying bridges (Stargate, Across, Hop, and
 * others) plus DEXs for any swap leg, and picks the best route the same
 * way Velora does for same-chain swaps in swap.ts.
 *
 * Supports EVM<->EVM (Ethereum <-> BSC) and EVM<->Solana. Solana is a
 * real leg now - deriveSolanaKeypair() in engine.ts derives a real
 * ed25519 address from the same mnemonic (already used for same-chain
 * Solana swaps in jupiterSwap.ts), so funds sent to/from it are
 * recoverable. Bitcoin is still excluded - LI.FI doesn't route to/from it.
 *
 * EVM and Solana transactions are fundamentally different shapes:
 *  - EVM leg: {to, data, value, chainId} - signed/sent with ethers, same
 *    as before, including the ERC-20 approval step.
 *  - Solana leg: {data} only - a base64-encoded, unsigned, already-built
 *    Solana transaction. No approval step (Solana has no allowance
 *    concept); just deserialize, sign with the derived keypair, and send.
 *  See https://docs.li.fi/introduction/user-flows-and-examples/solana-tx-execution
 *
 * FEE NOTE: the `fee`/`integrator` params below only tell LI.FI what cut
 * to take - WHERE that cut is paid out is configured separately by LI.FI for
 * the configured integrator. The current PAXI bridge flow reports this as a
 * provider estimate only and does not claim independently verified PAXI fee
 * settlement. Do not treat the LI.FI route fee as the PAXI treasury fee.
 */
import { Contract, JsonRpcProvider, formatUnits, parseUnits } from 'ethers';
import { Connection, VersionedTransaction } from '@solana/web3.js';
import { NETWORKS, type AssetConfig, type ChainType } from './chains';
import { walletFromMnemonic, deriveSolanaKeypair } from './engine';
import { WALLET_FEE_BPS } from './swap';
import { trpcVanilla } from '../trpcVanilla';
import { formatBaseUnits } from './decimalParsing';

/** Must match the server LI.FI request fee=0.003. This is only a route estimate. */
export const LIFI_INTEGRATOR_FEE_BPS = 30;

export const NATIVE_TOKEN_ADDRESS_LIFI = '0x0000000000000000000000000000000000000000';
/** LI.FI's placeholder for native SOL - Solana has no real "native token address". */
export const NATIVE_SOL_ADDRESS_LIFI = '11111111111111111111111111111111';
/** LI.FI's (LI.FI-specific, not Solana's actual) chain ID for Solana. */
const LIFI_SOLANA_CHAIN_ID = 1151111081099710;


const ERC20_ABI = [
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
];

function tokenAddressFor(asset: AssetConfig): string {
  const chainType = NETWORKS[asset.network]?.chainType;
  if (chainType === 'sol') return asset.isNative ? NATIVE_SOL_ADDRESS_LIFI : asset.contractAddress!;
  return asset.isNative ? NATIVE_TOKEN_ADDRESS_LIFI : asset.contractAddress!;
}

function lifiChainId(networkId: string): number | undefined {
  const network = NETWORKS[networkId];
  if (!network) return undefined;
  return network.chainType === 'sol' ? LIFI_SOLANA_CHAIN_ID : network.chainId;
}

/** EVM and Solana are both real, signable destinations. Bitcoin is excluded - see file header. */
export function isBridgeDestination(networkId: string): boolean {
  const chainType = NETWORKS[networkId]?.chainType;
  return chainType === 'evm' || chainType === 'sol';
}

/** Same set as destinations - LI.FI routes both directions between any two supported chains. */
export function isBridgeSource(networkId: string): boolean {
  return isBridgeDestination(networkId);
}

export interface BridgeQuote {
  raw: any; // full LI.FI quote, passed back verbatim when sending the tx
  srcAmountUnits: string;
  destAmountFormatted: string;
  destAmountMinFormatted: string;
  approvalAddress: string | null; // null for a Solana source leg - no approval concept there
  /** Solana-source quotes only populate `data`; EVM-source quotes populate all fields. */
  transactionRequest: { to?: string; data: string; value?: string; chainId?: number };
  executionDurationSeconds: number;
  feeAmountFormatted: string; // in srcAsset units
  routeNames: string[]; // bridge + any DEX legs used, e.g. ["Stargate", "PancakeSwap"]
}

export async function fetchBridgeQuote(params: {
  fromNetworkId: string;
  toNetworkId: string;
  srcAsset: AssetConfig;
  destAsset: AssetConfig;
  amount: string; // human units of srcAsset
  /** Sender address, in the format of fromNetworkId's chain type (EVM 0x... or Solana base58). */
  fromAddress: string;
  /** Receive address, in the format of toNetworkId's chain type. Same as fromAddress for EVM<->EVM. */
  toAddress: string;
  slippage: number; // decimal, e.g. 0.01 = 1%
}): Promise<BridgeQuote> {
  const { srcAsset, destAsset } = params;
  const fromNetwork = NETWORKS[params.fromNetworkId];
  const toNetwork = NETWORKS[params.toNetworkId];
  if (!fromNetwork || !isBridgeSource(params.fromNetworkId)) {
    throw new Error(`Bridging from ${fromNetwork?.label ?? 'that network'} isn't supported yet.`);
  }
  if (!isBridgeDestination(params.toNetworkId)) {
    throw new Error(`Bridging to ${toNetwork?.label ?? 'that network'} isn't supported yet - this wallet doesn't have a real address for it.`);
  }
  if (!params.fromAddress || !params.toAddress) {
    throw new Error('Unlock your wallet to get a Solana address before bridging to/from Solana.');
  }
  const fromChainId = lifiChainId(params.fromNetworkId);
  const toChainId = lifiChainId(params.toNetworkId);
  if (!fromChainId || !toChainId) throw new Error('Missing chain ID for this network.');

  const srcAmountUnits = parseUnits(params.amount, srcAsset.decimals).toString();
  const data = await trpcVanilla.bridge.quote.query({
    fromChain: fromChainId,
    toChain: toChainId,
    fromToken: tokenAddressFor(srcAsset),
    toToken: tokenAddressFor(destAsset),
    fromAddress: params.fromAddress,
    toAddress: params.toAddress,
    fromAmount: srcAmountUnits,
    slippage: params.slippage,
  });
  const estimate = data.estimate;
  if (!estimate || !data.transactionRequest) throw new Error('No bridge route found for this pair.');

  const destAmountFormatted = formatUnits(estimate.toAmount, destAsset.decimals);
  const destAmountMinFormatted = formatUnits(estimate.toAmountMin, destAsset.decimals);
  // Compute the integrator-fee estimate from the exact base-unit amount
  // already derived above (srcAmountUnits), not by re-parsing the human
  // string through Number. Ceiling rounding so the estimate never
  // understates the fee the route will actually take.
  const srcAmountUnitsBigInt = BigInt(srcAmountUnits);
  const feeUnits = (srcAmountUnitsBigInt * BigInt(LIFI_INTEGRATOR_FEE_BPS) + 9999n) / 10000n;
  const feeAmountFormatted = formatBaseUnits(feeUnits, srcAsset.decimals);

  const routeNames = new Set<string>();
  if (data.toolDetails?.name) routeNames.add(data.toolDetails.name);
  for (const step of data.includedSteps ?? []) {
    if (step.toolDetails?.name) routeNames.add(step.toolDetails.name);
  }

  return {
    raw: data,
    srcAmountUnits,
    destAmountFormatted,
    destAmountMinFormatted,
    approvalAddress: estimate.approvalAddress ?? null,
    transactionRequest: data.transactionRequest,
    executionDurationSeconds: estimate.executionDuration ?? 0,
    feeAmountFormatted,
    routeNames: [...routeNames],
  };
}

async function getAllowance(rpcUrl: string, tokenAddress: string, owner: string, spender: string): Promise<bigint> {
  const provider = new JsonRpcProvider(rpcUrl);
  const contract = new Contract(tokenAddress, ERC20_ABI, provider);
  return contract.allowance(owner, spender);
}

export interface BridgeResult {
  approvalHash?: string;
  bridgeHash: string;
  explorerUrl?: string;
}

async function executeEvmBridge(params: {
  mnemonic: string;
  fromNetworkId: string;
  srcAsset: AssetConfig;
  quote: BridgeQuote;
  userAddress: string;
  onStatus?: (status: 'approving' | 'bridging') => void;
}): Promise<BridgeResult> {
  const { srcAsset, quote, userAddress } = params;
  const network = NETWORKS[params.fromNetworkId];
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);

  let approvalHash: string | undefined;
  if (!srcAsset.isNative && quote.approvalAddress) {
    const tokenAddress = srcAsset.contractAddress!;
    const currentAllowance = await getAllowance(network.rpcUrl, tokenAddress, userAddress, quote.approvalAddress);
    if (currentAllowance < BigInt(quote.srcAmountUnits)) {
      params.onStatus?.('approving');
      const erc20 = new Contract(tokenAddress, ERC20_ABI, signer);
      // Grant only the exact amount needed for this bridge quote; never create an unlimited allowance.
      const approveTx = await erc20.approve(quote.approvalAddress, BigInt(quote.srcAmountUnits));
      await approveTx.wait();
      approvalHash = approveTx.hash;
    }
  }

  params.onStatus?.('bridging');
  const tx = quote.transactionRequest;
  if (!tx.to) throw new Error('LI.FI did not return a transaction to send.');
  const bridgeTx = await signer.sendTransaction({
    to: tx.to,
    data: tx.data,
    value: tx.value ? BigInt(tx.value) : 0n,
  });

  return {
    approvalHash,
    bridgeHash: bridgeTx.hash,
    explorerUrl: network.explorerTx?.(bridgeTx.hash),
  };
}

/** No approval step - Solana has no allowance concept. Deserialize LI.FI's unsigned tx, sign, send. */
async function executeSolanaBridge(params: {
  mnemonic: string;
  fromNetworkId: string;
  quote: BridgeQuote;
  onStatus?: (status: 'approving' | 'bridging') => void;
}): Promise<BridgeResult> {
  const network = NETWORKS[params.fromNetworkId];
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);
  if (!params.quote.transactionRequest.data) throw new Error('LI.FI did not return a Solana transaction to sign.');

  const connection = new Connection(network.rpcUrl, 'confirmed');
  const keypair = deriveSolanaKeypair(params.mnemonic);

  params.onStatus?.('bridging');
  const txBytes = Buffer.from(params.quote.transactionRequest.data, 'base64');
  const transaction = VersionedTransaction.deserialize(txBytes);
  transaction.sign([keypair]);

  const signature = await connection.sendRawTransaction(transaction.serialize(), { maxRetries: 3 });
  await connection.confirmTransaction(signature, 'confirmed');

  return {
    bridgeHash: signature,
    explorerUrl: network.explorerTx?.(signature),
  };
}

/** Approves if needed (EVM only), then sends LI.FI's prebuilt transaction (which includes the wallet fee) as-is. */
export async function executeBridge(params: {
  mnemonic: string;
  fromNetworkId: string;
  srcAsset: AssetConfig;
  quote: BridgeQuote;
  userAddress: string;
  onStatus?: (status: 'approving' | 'bridging') => void;
}): Promise<BridgeResult> {
  const chainType: ChainType | undefined = NETWORKS[params.fromNetworkId]?.chainType;
  if (chainType === 'sol') return executeSolanaBridge(params);
  return executeEvmBridge(params);
}

export { WALLET_FEE_BPS };
