/**
 * Raw ethers/RPC errors are unreadable JSON dumps (encoded revert data, hex
 * calldata, etc) - fine for a developer console, useless for a user staring
 * at a failed transaction. This maps the handful of cases that actually
 * happen in practice (insufficient balance, user cancelled, not enough gas)
 * to a short sentence, and falls back to a generic message rather than ever
 * showing raw hex to someone using the app.
 */
export function describeChainError(err: unknown, context?: { feeSymbol?: string }): string {
  const raw = err instanceof Error ? err.message : String(err);
  const lower = raw.toLowerCase();
  const symbol = context?.feeSymbol ?? 'the required token';

  if (lower.includes('exceeds balance') || lower.includes('insufficient balance') || lower.includes('transfer amount exceeds')) {
    return `Insufficient ${symbol} balance to cover this. Add more ${symbol} to your wallet and try again.`;
  }
  if (lower.includes('insufficient funds')) {
    return `Insufficient balance to cover gas for this transaction. Add a bit more of the network's native coin and try again.`;
  }
  if (lower.includes('allowance')) {
    return `The spending approval didn't go through. Try again - you may need to approve the transaction again.`;
  }
  if (lower.includes('user rejected') || lower.includes('user denied') || lower.includes('action_rejected')) {
    return `Transaction cancelled.`;
  }
  if (lower.includes('nonce')) {
    return `A previous transaction is still pending. Wait for it to confirm before trying again.`;
  }
  if (lower.includes('gas required exceeds') || lower.includes('out of gas')) {
    return `This transaction needs more gas than estimated. Try again - it usually resolves itself.`;
  }
  if (lower.includes('network') || lower.includes('timeout') || lower.includes('could not detect')) {
    return `Network connection issue. Check your connection and try again.`;
  }

  // Fall back to something short and non-technical rather than the raw dump.
  return `Transaction failed. Double check your balances and try again.`;
}
