import { describe, expect, it } from 'vitest';
import { identifiersEqual, normalizeIdentifier } from './chains';

describe('chain-aware identifier normalization', () => {
  it('treats EVM addresses as case-insensitive', () => {
    const upper = '0xAbCdEf0123456789012345678901234567890123';
    const lower = upper.toLowerCase();
    expect(normalizeIdentifier('bsc', upper)).toBe(lower);
    expect(identifiersEqual('ethereum', upper, lower)).toBe(true);
  });

  it('preserves non-EVM identifiers exactly', () => {
    const solanaA = 'AbCdEf01234567890123456789012345678901234567';
    const solanaB = solanaA.toLowerCase();
    expect(normalizeIdentifier('solana', solanaA)).toBe(solanaA);
    expect(identifiersEqual('solana', solanaA, solanaB)).toBe(false);
    expect(identifiersEqual('bitcoin', 'bc1QExample', 'bc1qexample')).toBe(false);
  });

  it('does not silently fold unknown network identifiers', () => {
    expect(normalizeIdentifier('custom-network', 'MixedCaseIdentifier')).toBe('MixedCaseIdentifier');
  });
});
