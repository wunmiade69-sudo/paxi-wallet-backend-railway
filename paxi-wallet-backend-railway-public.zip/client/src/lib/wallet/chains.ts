/**
 * Asset & network configuration.
 *
 * "evm" assets share a single derived address (all EVM chains use the same
 * secp256k1 address format), so PAXI, WPAXI, BNB, and ETH all resolve to the
 * wallet's one EVM address across different networks. ERC-20/BEP-20 tokens
 * (like USDT) aren't hardcoded here - add them via "Add Token" with their
 * contract address, the same way MetaMask's "Import Token" works.
 *
 * BTC and SOL use different curves/derivation paths. Deriving real
 * BTC (bech32) and SOL (ed25519) addresses from the same seed needs
 * extra libraries (bitcoinjs-lib / @scure/bip32, @solana/web3.js) that
 * aren't installed yet - see README "Known Gaps". Their `addressType`
 * is marked accordingly so the UI can be honest about it instead of
 * faking a plausible-looking address.
 */

import type { TokenFieldSources } from '../phase3Models';

export type ChainType = 'evm' | 'btc' | 'sol';

/** Trust Wallet's public asset repo - same source already used for token icons below,
 * reused here for the network-level (chain) logos shown in network pickers. */
const TW_ASSETS = 'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains';

/**
 * Canonical identity for an asset in a flat balance/list map. Symbols and names
 * are display fields only: two contracts with the same symbol must never share
 * a balance. EVM addresses are case-insensitive; Solana mints preserve case.
 */
export function assetKey(asset: Pick<AssetConfig, 'network' | 'contractAddress' | 'isNative'>): string {
  const network = asset.network.trim().toLowerCase();
  if (asset.isNative) return `${network}:native`;
  if (!asset.contractAddress) return `${network}:unidentified`;
  const identifier = ['ethereum', 'bsc', 'base', 'polygon', 'arbitrum'].includes(network)
    ? asset.contractAddress.trim().toLowerCase()
    : asset.contractAddress.trim();
  return `${network}:${identifier}`;
}

export interface NetworkConfig {
  id: string;
  label: string;
  chainType: ChainType;
  chainId?: number; // EVM only
  rpcUrl?: string; // public, no API key required
  nativeSymbol: string;
  iconUrl?: string;
  explorerTx?: (hash: string) => string;
  explorerAddress?: (address: string) => string;
}

const BASE_NETWORKS: Record<string, NetworkConfig> = {
  ethereum: {
    id: 'ethereum',
    label: 'Ethereum',
    chainType: 'evm',
    chainId: 1,
    rpcUrl: 'https://ethereum-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    iconUrl: `${TW_ASSETS}/ethereum/info/logo.png`,
    explorerTx: (h) => `https://etherscan.io/tx/${h}`,
    explorerAddress: (a) => `https://etherscan.io/address/${a}`,
  },
  bsc: {
    id: 'bsc',
    label: 'BNB Smart Chain',
    chainType: 'evm',
    chainId: 56,
    rpcUrl: 'https://bsc-rpc.publicnode.com',
    nativeSymbol: 'BNB',
    iconUrl: `${TW_ASSETS}/smartchain/info/logo.png`,
    explorerTx: (h) => `https://bscscan.com/tx/${h}`,
    explorerAddress: (a) => `https://bscscan.com/address/${a}`,
  },
  bitcoin: {
    id: 'bitcoin',
    label: 'Bitcoin',
    chainType: 'btc',
    nativeSymbol: 'BTC',
    iconUrl: `${TW_ASSETS}/bitcoin/info/logo.png`,
    explorerTx: (h) => `https://blockstream.info/tx/${h}`,
    explorerAddress: (a) => `https://blockstream.info/address/${a}`,
  },
  solana: {
    id: 'solana',
    label: 'Solana',
    chainType: 'sol',
    rpcUrl: 'https://solana-rpc.publicnode.com',
    nativeSymbol: 'SOL',
    iconUrl: `${TW_ASSETS}/solana/info/logo.png`,
    explorerTx: (h) => `https://explorer.solana.com/tx/${h}`,
    explorerAddress: (a) => `https://explorer.solana.com/address/${a}`,
  },
  polygon: {
    id: 'polygon',
    label: 'Polygon',
    chainType: 'evm',
    chainId: 137,
    rpcUrl: 'https://polygon-bor-rpc.publicnode.com',
    nativeSymbol: 'POL',
    iconUrl: `${TW_ASSETS}/polygon/info/logo.png`,
    explorerTx: (h) => `https://polygonscan.com/tx/${h}`,
    explorerAddress: (a) => `https://polygonscan.com/address/${a}`,
  },
  arbitrum: {
    id: 'arbitrum',
    label: 'Arbitrum One',
    chainType: 'evm',
    chainId: 42161,
    rpcUrl: 'https://arbitrum-one-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    iconUrl: `${TW_ASSETS}/arbitrum/info/logo.png`,
    explorerTx: (h) => `https://arbiscan.io/tx/${h}`,
    explorerAddress: (a) => `https://arbiscan.io/address/${a}`,
  },
};

/**
 * User-added networks ("Add Network", like MetaMask's custom RPC form).
 * Stored as plain JSON in localStorage, so `explorerTx`/`explorerAddress`
 * (functions) aren't persisted for these - only rpcUrl/chainId/nativeSymbol
 * matter for balance fetching and sending, which is all custom networks
 * are used for today.
 */
const CUSTOM_NETWORKS_KEY = 'paxi-custom-networks';

export function getCustomNetworks(): NetworkConfig[] {
  try {
    return JSON.parse(localStorage.getItem(CUSTOM_NETWORKS_KEY) ?? '[]');
  } catch {
    return [];
  }
}

export function addCustomNetwork(network: NetworkConfig) {
  if (BASE_NETWORKS[network.id]) throw new Error('That network ID is already built in.');
  const existing = getCustomNetworks();
  if (existing.some((n) => n.id === network.id)) throw new Error('You already added a network with that ID.');
  existing.push(network);
  localStorage.setItem(CUSTOM_NETWORKS_KEY, JSON.stringify(existing));
}

export function removeCustomNetwork(id: string) {
  localStorage.setItem(CUSTOM_NETWORKS_KEY, JSON.stringify(getCustomNetworks().filter((n) => n.id !== id)));
}

function mergedNetworks(): Record<string, NetworkConfig> {
  const out = { ...BASE_NETWORKS };
  for (const n of getCustomNetworks()) out[n.id] = n;
  return out;
}

/**
 * Proxy so every existing `NETWORKS[id]` / `Object.values(NETWORKS)` call
 * site across the app keeps working unchanged, but now transparently
 * includes whatever custom networks the user has added - re-read from
 * localStorage on every access so a newly-added network shows up
 * immediately without a page reload.
 */
export const NETWORKS: Record<string, NetworkConfig> = new Proxy({} as Record<string, NetworkConfig>, {
  get: (_t, prop: string) => mergedNetworks()[prop],
  has: (_t, prop: string) => prop in mergedNetworks(),
  ownKeys: () => Reflect.ownKeys(mergedNetworks()),
  getOwnPropertyDescriptor: (_t, prop) => {
    const m = mergedNetworks();
    return prop in m ? { enumerable: true, configurable: true, value: (m as any)[prop] } : undefined;
  },
});

export interface AssetConfig {
  symbol: string;
  name: string;
  icon: string; // emoji fallback, used only if iconUrl fails to load
  iconUrl?: string;
  network: string; // key into NETWORKS
  isNative: boolean;
  // ERC-20 style token contract address (evm only, when isNative is false)
  contractAddress?: string;
  decimals: number;
  /** Optional field-level provenance carried by imported or canonical token metadata. */
  fieldSources?: TokenFieldSources;
  binanceSymbol?: string; // e.g. "BTCUSDT" - used for live price + chart, omitted when there's no market
}

// PAXI and WPAXI aren't hardcoded here anymore - PAXI Network turned out to be
// its own Cosmos-based chain (not EVM), so a hardcoded EVM entry for it was
// wrong. WPAXI, if it exists as a bridged ERC-20/BEP-20, should come in
// through "Import Token" with its real contract address once that's known.
export const ASSETS: AssetConfig[] = [
  {
    symbol: 'BNB',
    name: 'BNB',
    icon: '🟡',
    iconUrl: `${TW_ASSETS}/smartchain/info/logo.png`,
    network: 'bsc',
    isNative: true,
    decimals: 18,
    binanceSymbol: 'BNBUSDT',
  },
  {
    symbol: 'ETH',
    name: 'Ethereum',
    icon: '⟠',
    iconUrl: `${TW_ASSETS}/ethereum/info/logo.png`,
    network: 'ethereum',
    isNative: true,
    decimals: 18,
    binanceSymbol: 'ETHUSDT',
  },
  {
    symbol: 'BTC',
    name: 'Bitcoin',
    icon: '₿',
    iconUrl: `${TW_ASSETS}/bitcoin/info/logo.png`,
    network: 'bitcoin',
    isNative: true,
    decimals: 8,
    binanceSymbol: 'BTCUSDT',
  },
  {
    symbol: 'SOL',
    name: 'Solana',
    icon: '◎',
    iconUrl: `${TW_ASSETS}/solana/info/logo.png`,
    network: 'solana',
    isNative: true,
    decimals: 9,
    binanceSymbol: 'SOLUSDT',
  },
  // Popular stablecoins, preconfigured (the way MetaMask/Trust Wallet ship them by default)
  // so an ordinary token-to-token swap - e.g. USDT -> USDC - works out of the box, instead
  // of every swap being forced through the native coin because nothing else is listed.
  {
    symbol: 'USDT',
    name: 'Tether USD',
    icon: '🟢',
    iconUrl: `${TW_ASSETS}/ethereum/assets/0xdAC17F958D2ee523a2206206994597C13D831ec7/logo.png`,
    network: 'ethereum',
    isNative: false,
    contractAddress: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
    decimals: 6,
    binanceSymbol: 'USDTUSDT', // pegged; see note in balances.ts price lookup
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    icon: '🔵',
    iconUrl: `${TW_ASSETS}/ethereum/assets/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48/logo.png`,
    network: 'ethereum',
    isNative: false,
    contractAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
    decimals: 6,
    binanceSymbol: 'USDCUSDT',
  },
  {
    symbol: 'USDT',
    name: 'Tether USD',
    icon: '🟢',
    iconUrl: `${TW_ASSETS}/smartchain/assets/0x55d398326f99059fF775485246999027B3197955/logo.png`,
    network: 'bsc',
    isNative: false,
    contractAddress: '0x55d398326f99059fF775485246999027B3197955',
    decimals: 18,
    binanceSymbol: 'USDTUSDT',
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    icon: '🔵',
    iconUrl: `${TW_ASSETS}/smartchain/assets/0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d/logo.png`,
    network: 'bsc',
    isNative: false,
    contractAddress: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
    decimals: 18,
    binanceSymbol: 'USDCUSDT',
  },
  {
    symbol: 'POL',
    name: 'Polygon',
    icon: '🟣',
    iconUrl: `${TW_ASSETS}/polygon/info/logo.png`,
    network: 'polygon',
    isNative: true,
    decimals: 18,
    binanceSymbol: 'POLUSDT',
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    icon: '🔵',
    iconUrl: `${TW_ASSETS}/polygon/assets/0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359/logo.png`,
    network: 'polygon',
    isNative: false,
    contractAddress: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
    decimals: 6,
    binanceSymbol: 'USDCUSDT',
  },
  {
    symbol: 'ETH',
    name: 'Ethereum',
    icon: '⟠',
    iconUrl: `${TW_ASSETS}/arbitrum/info/logo.png`,
    network: 'arbitrum',
    isNative: true,
    decimals: 18,
    binanceSymbol: 'ETHUSDT',
  },
  {
    symbol: 'USDT',
    name: 'Tether USD',
    icon: '🟢',
    iconUrl: `${TW_ASSETS}/arbitrum/assets/0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9/logo.png`,
    network: 'arbitrum',
    isNative: false,
    contractAddress: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
    decimals: 6,
    binanceSymbol: 'USDTUSDT',
  },
  {
    symbol: 'USDC',
    name: 'USD Coin',
    icon: '🔵',
    iconUrl: `${TW_ASSETS}/arbitrum/assets/0xaf88d065e77c8cC2239327C5EDb3A432268e5831/logo.png`,
    network: 'arbitrum',
    isNative: false,
    contractAddress: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
    decimals: 6,
    binanceSymbol: 'USDCUSDT',
  },
];

export function getAssetsForChainType(type: ChainType) {
  return ASSETS.filter((a) => NETWORKS[a.network].chainType === type);
}
