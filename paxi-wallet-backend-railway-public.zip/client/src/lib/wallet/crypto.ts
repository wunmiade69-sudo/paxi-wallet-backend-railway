/**
 * Real encryption for wallet secrets, built entirely on the browser's
 * native Web Crypto API (SubtleCrypto) - no extra dependency needed.
 *
 * A user's PIN is never stored. Instead it's run through PBKDF2 (150k
 * rounds, per-vault random salt) to derive an AES-256-GCM key, which
 * encrypts the mnemonic. To unlock, the PIN is re-derived and used to
 * decrypt; wrong PIN just fails to decrypt (auth tag check).
 */

const PBKDF2_ITERATIONS = 150_000;

function toBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function fromBase64(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function deriveKey(pin: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, [
    'deriveKey',
  ]);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: salt as BufferSource, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export interface EncryptedBlob {
  ciphertext: string; // base64
  iv: string; // base64
  salt: string; // base64
  iterations: number;
}

/** Encrypt plaintext (e.g. a mnemonic) with a PIN. */
export async function encryptWithPIN(plaintext: string, pin: string): Promise<EncryptedBlob> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(pin, salt);
  const enc = new TextEncoder();
  const cipherBuf = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, enc.encode(plaintext));
  return {
    ciphertext: toBase64(new Uint8Array(cipherBuf)),
    iv: toBase64(iv),
    salt: toBase64(salt),
    iterations: PBKDF2_ITERATIONS,
  };
}

/** Decrypt a blob created by encryptWithPIN. Throws if the PIN is wrong. */
export async function decryptWithPIN(blob: EncryptedBlob, pin: string): Promise<string> {
  const salt = fromBase64(blob.salt);
  const iv = fromBase64(blob.iv);
  const key = await deriveKey(pin, salt);
  const cipherBytes = fromBase64(blob.ciphertext);
  const plainBuf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, cipherBytes as BufferSource);
  return new TextDecoder().decode(plainBuf);
}

/**
 * Encrypt/decrypt using a raw non-extractable CryptoKey (used to wrap the
 * PIN itself for biometric unlock - see vault.ts / deviceKey.ts).
 */
export async function encryptWithKey(plaintext: string, key: CryptoKey): Promise<{ ciphertext: string; iv: string }> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const cipherBuf = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, enc.encode(plaintext));
  return { ciphertext: toBase64(new Uint8Array(cipherBuf)), iv: toBase64(iv) };
}

export async function decryptWithKey(ciphertext: string, iv: string, key: CryptoKey): Promise<string> {
  const cipherBytes = fromBase64(ciphertext);
  const ivBytes = fromBase64(iv);
  const plainBuf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ivBytes as BufferSource }, key, cipherBytes as BufferSource);
  return new TextDecoder().decode(plainBuf);
}
