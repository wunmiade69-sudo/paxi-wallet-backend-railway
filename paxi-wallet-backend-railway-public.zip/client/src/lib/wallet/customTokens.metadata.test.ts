import { describe, expect, it, vi } from "vitest";

const jupiterQuery = vi.fn();
const getMintSafe = vi.fn();

vi.mock("../trpcVanilla", () => ({
  trpcVanilla: { market: { jupiterToken: { query: jupiterQuery } } },
}));
vi.mock("@solana/web3.js", () => ({
  PublicKey: class PublicKey {
    constructor(public readonly value: string) {}
  },
  Connection: class Connection {
    constructor(public readonly url: string, public readonly commitment: string) {}
  },
}));
vi.mock("./solanaSplSafe", () => ({ getMintSafe }));

describe("Solana custom-token metadata", () => {
  it("uses the server Jupiter response and preserves field provenance", async () => {
    jupiterQuery.mockResolvedValue({
      name: "Example SPL",
      symbol: "EX",
      decimals: 6,
      icon: "https://example.test/ex.png",
    });
    const { lookupTokenMetadata } = await import("./customTokens");

    const result = await lookupTokenMetadata("solana", "So11111111111111111111111111111111111111112");

    expect(result).toEqual({
      name: "Example SPL",
      symbol: "EX",
      decimals: 6,
      logoUrl: "https://example.test/ex.png",
      fieldSources: {
        name: ["jupiter"],
        symbol: ["jupiter"],
        decimals: ["jupiter"],
        logo: ["jupiter"],
      },
    });
    expect(jupiterQuery).toHaveBeenCalledWith({ mint: "So11111111111111111111111111111111111111112" });
    expect(getMintSafe).not.toHaveBeenCalled();
  });
});

