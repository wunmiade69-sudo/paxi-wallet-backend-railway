import { beforeEach, describe, expect, it } from 'vitest';
import { addCustomToken, canonicalCustomTokenAddress, customTokenToAsset, getCustomTokens } from './customTokens';

function installStorage() {
  const values = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
    clear: () => values.clear(),
    key: (index: number) => [...values.keys()][index] ?? null,
    get length() { return values.size; },
  };
}

describe('custom token canonical metadata persistence', () => {
  beforeEach(() => installStorage());

  it('persists field-level sources and carries them into the portfolio asset adapter', () => {
    addCustomToken({
      symbol: 'TKN',
      name: 'Example Token',
      contractAddress: '0x0000000000000000000000000000000000000001',
      network: 'ethereum',
      decimals: 18,
      addedAt: 1,
      iconUrl: 'https://example.com/token.png',
      fieldSources: {
        name: ['evm-contract'],
        symbol: ['evm-contract'],
        decimals: ['evm-contract'],
        logo: ['user-entered'],
      },
    });

    const saved = getCustomTokens()[0];
    expect(saved?.fieldSources?.name).toEqual(['evm-contract']);
    expect(customTokenToAsset(saved!).fieldSources?.logo).toEqual(['user-entered']);
    expect(customTokenToAsset(saved!).iconUrl).toBe('https://example.com/token.png');
  });

  it('does not turn an unsafe custom logo URL into a remote asset source', () => {
    const asset = customTokenToAsset({
      symbol: 'TKN',
      name: 'Example Token',
      contractAddress: '0x0000000000000000000000000000000000000001',
      network: 'ethereum',
      decimals: 18,
      addedAt: 1,
      iconUrl: 'javascript:alert(1)',
      fieldSources: { logo: ['user-entered'] },
    });
    expect(asset.iconUrl).toBeUndefined();
    expect(asset.fieldSources?.logo).toBeUndefined();
  });

  it('canonicalizes EVM casing but preserves Solana mint case', () => {
    expect(canonicalCustomTokenAddress('ethereum', '  0x00000000000000000000000000000000000000Aa  ')).toBe('0x00000000000000000000000000000000000000aa');
    expect(canonicalCustomTokenAddress('solana', '  MintCaseSensitive111111111111111111111111111111  ')).toBe('MintCaseSensitive111111111111111111111111111111');
  });

  it('rejects a duplicate canonical identity while allowing same-symbol different contracts', () => {
    const base = {
      symbol: 'USDT', name: 'Tether', network: 'ethereum', decimals: 6, addedAt: 1,
    } as const;
    addCustomToken({ ...base, contractAddress: '0x0000000000000000000000000000000000000001' });
    addCustomToken({ ...base, contractAddress: '0x0000000000000000000000000000000000000002' });
    expect(() => addCustomToken({ ...base, contractAddress: '0x0000000000000000000000000000000000000001'.replace('a', 'A') })).toThrow('already');
    expect(getCustomTokens()).toHaveLength(2);
  });

  it('persists a safe provider logo and provenance without replacing it with a guessed URL', () => {
    addCustomToken({
      symbol: 'PRV', name: 'Provider Token', contractAddress: '0x0000000000000000000000000000000000000003', network: 'ethereum', decimals: 18, addedAt: 1,
      iconUrl: 'https://provider.example/logo.png', fieldSources: { logo: ['birdeye'] },
    });
    expect(getCustomTokens()[0]?.iconUrl).toBe('https://provider.example/logo.png');
    expect(customTokenToAsset(getCustomTokens()[0]!).fieldSources?.logo).toEqual(['birdeye']);
  });
});

