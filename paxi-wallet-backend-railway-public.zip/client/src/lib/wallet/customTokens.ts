/**
 * "Import Token" support - lets a user add any ERC-20/BEP-20 token by
 * contract address (the same pattern MetaMask uses), instead of us
 * guessing at contract addresses for things like PAXI/WPAXI.
 *
 * Symbol, name, and decimals are read directly from the contract on
 * whichever EVM network the user picks, so what's shown is whatever
 * that contract actually reports - not a hardcoded guess.
 */
import { Contract, JsonRpcProvider, getAddress, isAddress } from 'ethers';
import { identifiersEqual, NETWORKS, type AssetConfig } from './chains';

// Trust Wallet's asset repo folder names don't always match our network ids.
const TRUSTWALLET_CHAIN_FOLDER: Record<string, string> = {
  ethereum: 'ethereum',
  bsc: 'smartchain',
};

const ERC20_METADATA_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
];

const STORAGE_KEY = 'paxi-custom-tokens';

export interface CustomToken {
  symbol: string;
  name: string;
  contractAddress: string;
  network: string;
  decimals: number;
  addedAt: number;
  /**
   * Optional user-supplied logo URL. This app doesn't depend on Trust
   * Wallet's assets repo the way their own app does - you can point this
   * at any image you host yourself (your own site, IPFS, a GitHub repo you
   * control). Falls back to the Trust Wallet repo guess, then the 🪙 emoji,
   * if not set.
   */
  iconUrl?: string;
}

export function getCustomTokens(): CustomToken[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]');
  } catch {
    return [];
  }
}

export function removeCustomToken(contractAddress: string, network: string) {
  const tokens = getCustomTokens().filter(
    (t) => !(identifiersEqual(network, t.contractAddress, contractAddress) && t.network === network)
  );
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tokens));
}

/** Read name/symbol/decimals - straight from the contract for EVM tokens,
 * or from Jupiter's public token list (falling back to just the mint's
 * decimals) for Solana SPL tokens. */
export async function lookupTokenMetadata(
  networkId: string,
  contractAddress: string
): Promise<{ name: string; symbol: string; decimals: number; logoUrl?: string }> {
  const network = NETWORKS[networkId];
  if (!network) throw new Error('Unknown network.');

  if (network.chainType === 'sol') return lookupSolanaTokenMetadata(contractAddress);

  const trimmed = contractAddress.trim();
  if (!trimmed.startsWith('0x') || trimmed.length !== 42) {
    throw new Error(
      `That address looks incomplete (${trimmed.length} characters, expected 42: "0x" + 40 hex digits). ` +
        `Make sure you copied the full address, not a shortened display version.`
    );
  }
  if (!isAddress(trimmed)) throw new Error('Enter a valid contract address');
  if (network.chainType !== 'evm') throw new Error('Custom tokens are only supported on EVM and Solana right now');
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);

  const provider = new JsonRpcProvider(network.rpcUrl);
  const contract = new Contract(trimmed, ERC20_METADATA_ABI, provider);

  try {
    const [name, symbol, decimals] = await Promise.all([
      contract.name(),
      contract.symbol(),
      contract.decimals(),
    ]);
    return { name, symbol, decimals: Number(decimals) };
  } catch {
    throw new Error('Could not read token info from that contract. Double-check the address and network.');
  }
}

async function lookupSolanaTokenMetadata(
  mintAddress: string
): Promise<{ name: string; symbol: string; decimals: number; logoUrl?: string }> {
  const trimmed = mintAddress.trim();
  if (trimmed.length < 32 || trimmed.length > 44) {
    throw new Error('That looks like an incomplete Solana mint address.');
  }

  const { PublicKey } = await import('@solana/web3.js');
  let mintPubkey;
  try {
    mintPubkey = new PublicKey(trimmed);
  } catch {
    throw new Error('Enter a valid Solana token mint address.');
  }

  // Jupiter's public token list has name/symbol/logo for known tokens -
  // same source their own swap UI uses, no API key needed.
  try {
    const res = await fetch(`https://tokens.jup.ag/token/${trimmed}`);
    if (res.ok) {
      const data = await res.json();
      if (data?.symbol) {
        return { name: data.name ?? data.symbol, symbol: data.symbol, decimals: data.decimals, logoUrl: data.logoURI };
      }
    }
  } catch {
    // fall through to on-chain-only lookup below
  }

  // Not in Jupiter's list (new/exotic token) - at least get real decimals
  // straight from the mint account; name/symbol will need to be entered manually.
  const network = NETWORKS.solana;
  if (!network?.rpcUrl) throw new Error('Solana RPC is not configured yet.');
  const { Connection } = await import('@solana/web3.js');
  const { getMint } = await import('@solana/spl-token');
  const connection = new Connection(network.rpcUrl, 'confirmed');
  try {
    const mintInfo = await getMint(connection, mintPubkey);
    return { name: '', symbol: '', decimals: mintInfo.decimals };
  } catch {
    throw new Error('Could not read this Solana token. Double-check the mint address.');
  }
}

export function addCustomToken(token: CustomToken) {
  const tokens = getCustomTokens();
  const exists = tokens.some(
    (t) => identifiersEqual(token.network, t.contractAddress, token.contractAddress) && t.network === token.network
  );
  if (exists) throw new Error('This token is already in your wallet');
  tokens.push(token);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tokens));
}

export function customTokenToAsset(token: CustomToken): AssetConfig {
  const folder = TRUSTWALLET_CHAIN_FOLDER[token.network];
  let iconUrl: string | undefined = token.iconUrl?.trim() || undefined;
  if (!iconUrl && folder && isAddress(token.contractAddress)) {
    iconUrl = `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/${folder}/assets/${getAddress(token.contractAddress)}/logo.png`;
  }
  return {
    symbol: token.symbol,
    name: token.name,
    icon: '🪙',
    iconUrl,
    network: token.network,
    isNative: false,
    contractAddress: token.contractAddress,
    decimals: token.decimals,
    // no coingeckoId - custom tokens don't have a known price feed
  };
}
