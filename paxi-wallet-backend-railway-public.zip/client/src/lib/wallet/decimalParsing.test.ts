import { describe, expect, it } from 'vitest';
import { InvalidDecimalAmountError, parseExactBaseUnits, parseExactBaseUnitsAllowZero } from './decimalParsing';

describe('parseExactBaseUnits', () => {
  it('converts 1 at 18 decimals to exactly 1e18 wei', () => {
    expect(parseExactBaseUnits('1', 18)).toBe(1000000000000000000n);
  });

  it('converts 10 at 18 decimals to exactly 10e18 wei', () => {
    expect(parseExactBaseUnits('10', 18)).toBe(10000000000000000000n);
  });

  it('converts 0.000000001 at 9 decimals to exactly 1 lamport', () => {
    expect(parseExactBaseUnits('0.000000001', 9)).toBe(1n);
  });

  it('converts 0.000001 at 6 decimals to exactly 1 base unit', () => {
    expect(parseExactBaseUnits('0.000001', 6)).toBe(1n);
  });

  it('converts 2 ETH at 18 decimals exactly', () => {
    expect(parseExactBaseUnits('2', 18)).toBe(2000000000000000000n);
  });

  it('converts 10 BNB at 18 decimals exactly', () => {
    expect(parseExactBaseUnits('10', 18)).toBe(10000000000000000000n);
  });

  it('converts 1,000,000 USDT at 6 decimals exactly, beyond Number.MAX_SAFE_INTEGER scaled', () => {
    expect(parseExactBaseUnits('1000000', 6)).toBe(1000000000000n);
  });

  it('converts 0.00000001 BTC at 8 decimals to exactly 1 satoshi', () => {
    expect(parseExactBaseUnits('0.00000001', 8)).toBe(1n);
  });

  it('converts a whole-number BTC amount to exact satoshis without float drift', () => {
    // 0.1 BTC is a classic float-imprecision case: Number('0.1') * 1e8 can land on
    // 9999999.999999998 in IEEE-754 before rounding papers over it. Exact string
    // arithmetic must not depend on that rounding step at all.
    expect(parseExactBaseUnits('0.1', 8)).toBe(10000000n);
  });

  it('rejects negative amounts', () => {
    expect(() => parseExactBaseUnits('-1', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects zero', () => {
    expect(() => parseExactBaseUnits('0', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects malformed values', () => {
    expect(() => parseExactBaseUnits('abc', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('1.2.3', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('.', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects scientific notation', () => {
    expect(() => parseExactBaseUnits('1e18', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('1E-9', 9)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects NaN and Infinity literals', () => {
    expect(() => parseExactBaseUnits('NaN', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('Infinity', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('-Infinity', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects empty and whitespace-only values', () => {
    expect(() => parseExactBaseUnits('', 18)).toThrow(InvalidDecimalAmountError);
    expect(() => parseExactBaseUnits('   ', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects surrounding whitespace rather than silently trimming it', () => {
    expect(() => parseExactBaseUnits(' 1 ', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects excess decimal places rather than silently truncating them', () => {
    expect(() => parseExactBaseUnits('0.0000000001', 9)).toThrow(InvalidDecimalAmountError);
  });

  it('rejects non-string input', () => {
    expect(() => parseExactBaseUnits(1 as unknown as string, 18)).toThrow(InvalidDecimalAmountError);
  });

  it('never produces a value that could have round-tripped through Number unsafely', () => {
    // 18-decimal dust: smallest possible non-zero wei amount.
    expect(parseExactBaseUnits('0.000000000000000001', 18)).toBe(1n);
  });
});

describe('parseExactBaseUnitsAllowZero', () => {
  it('allows an explicit zero', () => {
    expect(parseExactBaseUnitsAllowZero('0', 18)).toBe(0n);
  });

  it('still rejects negative values', () => {
    expect(() => parseExactBaseUnitsAllowZero('-1', 18)).toThrow(InvalidDecimalAmountError);
  });

  it('still converts non-zero amounts exactly', () => {
    expect(parseExactBaseUnitsAllowZero('1', 18)).toBe(1000000000000000000n);
  });
});
