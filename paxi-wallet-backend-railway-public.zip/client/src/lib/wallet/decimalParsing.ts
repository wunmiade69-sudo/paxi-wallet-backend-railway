/**
 * Client re-export of the shared exact-decimal utilities.
 *
 * The implementation lives in `@shared/exactDecimal` so both client and
 * server code share a single, sanctioned decimal-string <-> base-unit
 * bigint parser/formatter instead of maintaining incompatible copies. This
 * file only exists to keep the existing `@/lib/wallet/decimalParsing`
 * import path working for client modules that already reference it.
 */
export {
  InvalidDecimalAmountError,
  parseExactBaseUnits,
  parseExactBaseUnitsAllowZero,
  formatBaseUnits,
  parseExactIntegerUnits,
} from '@shared/exactDecimal';
