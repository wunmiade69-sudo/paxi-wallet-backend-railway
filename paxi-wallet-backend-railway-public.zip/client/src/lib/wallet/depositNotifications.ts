/**
 * Real push notifications (buzzing the phone even with the app closed) need
 * a service worker + device token registration - a separate, bigger build.
 * This is the in-app version: while Paxi is open, it periodically checks
 * indexed history for 'receive' records it hasn't shown a toast for yet,
 * and surfaces one. Seen hashes persist in localStorage so re-opening the
 * app doesn't re-notify for old deposits.
 */
import { useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { getFullHistory } from './txIndexer';
import type { TxRecord } from './txHistory';

const SEEN_KEY = 'paxi-deposit-notify-seen';
const POLL_INTERVAL_MS = 30_000;

function getSeenHashes(): Set<string> {
  try {
    const raw = localStorage.getItem(SEEN_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

function saveSeenHashes(hashes: Set<string>) {
  // Cap stored size so this never grows unbounded.
  const trimmed = Array.from(hashes).slice(-300);
  localStorage.setItem(SEEN_KEY, JSON.stringify(trimmed));
}

export function useDepositNotifications(address: string | null) {
  const initialized = useRef(false);

  useEffect(() => {
    if (!address) return;
    let cancelled = false;

    const check = async () => {
      const history = await getFullHistory(address);
      if (cancelled) return;

      const seen = getSeenHashes();
      const receives = history.filter((r): r is TxRecord => r.type === 'receive');

      if (!initialized.current) {
        // First check after opening the app - mark everything already there
        // as seen instead of toasting a backlog of old deposits.
        receives.forEach((r) => seen.add(r.hash));
        saveSeenHashes(seen);
        initialized.current = true;
        return;
      }

      const newOnes = receives.filter((r) => !seen.has(r.hash));
      for (const r of newOnes) {
        toast.success(`Received ${r.fromAmount} ${r.fromSymbol}`, {
          description: r.counterparty ? `From ${r.counterparty.slice(0, 6)}…${r.counterparty.slice(-4)}` : undefined,
        });
        seen.add(r.hash);
      }
      if (newOnes.length > 0) saveSeenHashes(seen);
    };

    check();
    const interval = setInterval(check, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [address]);
}
