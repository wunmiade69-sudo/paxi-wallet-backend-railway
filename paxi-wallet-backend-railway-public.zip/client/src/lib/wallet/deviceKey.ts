/**
 * A non-extractable AES-GCM CryptoKey, generated once per device and kept
 * in IndexedDB (CryptoKey objects are structured-cloneable, so this works
 * without ever exposing the raw key bytes to JS).
 *
 * Biometric unlock flow:
 *   1. WebAuthn platform authenticator confirms Face ID / fingerprint.
 *   2. On success, we pull this device key from IndexedDB and use it to
 *      decrypt a copy of the PIN that was encrypted with it at enrollment.
 *   3. That PIN then unlocks the vault (see crypto.ts / vault.ts) exactly
 *      as if the user had typed it.
 *
 * This means the biometric prompt is a real gate enforced by the platform
 * authenticator + a key that never leaves the device, not just cosmetic.
 */

const DB_NAME = 'paxi-wallet-keys';
const STORE_NAME = 'keys';
const KEY_ID = 'device-key';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(STORE_NAME);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getStoredKey(): Promise<CryptoKey | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const req = tx.objectStore(STORE_NAME).get(KEY_ID);
    req.onsuccess = () => resolve((req.result as CryptoKey) ?? null);
    req.onerror = () => reject(req.error);
  });
}

async function putKey(key: CryptoKey): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(key, KEY_ID);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/** Get the device key, generating (non-extractable) and persisting it on first use. */
export async function getOrCreateDeviceKey(): Promise<CryptoKey> {
  const existing = await getStoredKey();
  if (existing) return existing;
  const key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, [
    'encrypt',
    'decrypt',
  ]);
  await putKey(key);
  return key;
}

export async function clearDeviceKey(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(KEY_ID);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
