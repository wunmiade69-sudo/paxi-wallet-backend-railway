/**
 * Live price/liquidity/market data for tokens that aren't listed on
 * Binance - which is most imported/custom tokens, since Binance only
 * lists what it lists. Pulled from DexScreener's public API, which
 * indexes on-chain DEX pairs directly by contract address across 60+
 * chains, no API key or account needed (rate-limited to ~300 req/min,
 * which is far more than this wallet needs).
 *
 * This is what makes "any token with a live DEX pair" show a real price
 * in the wallet, not just Binance-listed majors.
 */

import { JsonRpcProvider, Contract, formatUnits } from 'ethers';
import { identifiersEqual, NETWORKS } from './chains';

const DEXSCREENER_API = 'https://api.dexscreener.com/latest/dex';

// Our internal network id -> DexScreener's chain slug.
const DEXSCREENER_CHAIN_ID: Record<string, string> = {
  ethereum: 'ethereum',
  bsc: 'bsc',
  solana: 'solana', // ready for when Solana wallet support lands
};

interface DexScreenerTxnWindow {
  buys: number;
  sells: number;
}

interface DexScreenerPairRaw {
  chainId: string;
  dexId: string;
  url: string;
  priceUsd: string;
  liquidity?: { usd?: number };
  fdv?: number;
  marketCap?: number;
  volume?: { h24?: number };
  priceChange?: { h24?: number };
  txns?: {
    m5?: DexScreenerTxnWindow;
    h1?: DexScreenerTxnWindow;
    h6?: DexScreenerTxnWindow;
    h24?: DexScreenerTxnWindow;
  };
  baseToken: { address: string; name: string; symbol: string };
}

export interface DexMarketData {
  priceUsd: number;
  change24h: number | null;
  liquidityUsd: number | null;
  marketCap: number | null; // prefers reported marketCap, falls back to FDV
  volume24h: number | null;
  dexId: string;
  pairUrl: string;
  txns: {
    m5: DexScreenerTxnWindow;
    h1: DexScreenerTxnWindow;
    h6: DexScreenerTxnWindow;
    h24: DexScreenerTxnWindow;
  };
}

const ZERO_TXNS: DexScreenerTxnWindow = { buys: 0, sells: 0 };

/** Best (highest-liquidity) DEX pair for a token contract on a given network, or null if it has none indexed. */
export async function fetchDexMarketData(networkId: string, contractAddress: string): Promise<DexMarketData | null> {
  const chainSlug = DEXSCREENER_CHAIN_ID[networkId];
  if (!chainSlug) return null;
  try {
    const res = await fetch(`${DEXSCREENER_API}/tokens/${contractAddress}`);
    if (!res.ok) throw new Error(`DexScreener returned ${res.status}`);
    const data: { pairs: DexScreenerPairRaw[] | null } = await res.json();
    const pairs = (data.pairs ?? []).filter(
      (p) => p.chainId === chainSlug && identifiersEqual(networkId, p.baseToken?.address ?? '', contractAddress)
    );
    if (pairs.length === 0) return null;
    const best = pairs.reduce((a, b) => ((b.liquidity?.usd ?? 0) > (a.liquidity?.usd ?? 0) ? b : a));
    const price = Number(best.priceUsd);
    if (!Number.isFinite(price)) return null;
    return {
      priceUsd: price,
      change24h: best.priceChange?.h24 ?? null,
      liquidityUsd: best.liquidity?.usd ?? null,
      marketCap: best.marketCap ?? best.fdv ?? null,
      volume24h: best.volume?.h24 ?? null,
      dexId: best.dexId,
      pairUrl: best.url,
      txns: {
        m5: best.txns?.m5 ?? ZERO_TXNS,
        h1: best.txns?.h1 ?? ZERO_TXNS,
        h6: best.txns?.h6 ?? ZERO_TXNS,
        h24: best.txns?.h24 ?? ZERO_TXNS,
      },
    };
  } catch (err) {
    console.warn(`DexScreener lookup failed for ${contractAddress}:`, err);
    return null;
  }
}

/**
 * Direct on-chain price - read straight off a DEX pair's reserves over the
 * same public RPC balances already use, instead of depending on DexScreener
 * having crawled the pair yet. This is closer to what Trust Wallet actually
 * does for tokens it prices "instantly": no indexer in the loop at all.
 *
 * Brand-new pairs can show up here before DexScreener has indexed them, but
 * a pair also has to exist at all - a token with zero liquidity anywhere
 * returns null from this too, same as DexScreener would.
 */
const FACTORY_ABI = ['function getPair(address tokenA, address tokenB) view returns (address pair)'];
const PAIR_ABI = [
  'function getReserves() view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)',
  'function token0() view returns (address)',
];

interface DexFactoryConfig {
  factoryAddress: string;
  wrappedNativeAddress: string;
  wrappedNativeDecimals: number;
  /** Key into the Binance/CoinGecko price map already fetched for the native coin (e.g. 'BNBUSDT'). */
  nativeBinanceSymbol: string;
}

// One well-known AMM factory per network - used only as a fallback when
// DexScreener has no pair indexed yet. Add more networks here as needed
// (e.g. Uniswap V2 on Ethereum: 0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f,
// WETH: 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2).
const DEX_FACTORIES: Record<string, DexFactoryConfig> = {
  bsc: {
    factoryAddress: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73', // PancakeSwap V2 Factory
    wrappedNativeAddress: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', // WBNB
    wrappedNativeDecimals: 18,
    nativeBinanceSymbol: 'BNBUSDT',
  },
};

/**
 * @param networkId our internal network id, e.g. 'bsc'
 * @param contractAddress the token's contract address
 * @param tokenDecimals the token's own decimals (from lookupTokenMetadata/CustomToken)
 * @param nativeUsdPrice current USD price of the network's native coin (already fetched
 *   from Binance/CoinGecko elsewhere) - needed to convert the pool's native-token ratio to USD
 */
export async function fetchOnChainPrice(
  networkId: string,
  contractAddress: string,
  tokenDecimals: number,
  nativeUsdPrice: number
): Promise<number | null> {
  const factoryConfig = DEX_FACTORIES[networkId];
  const network = NETWORKS[networkId];
  if (!factoryConfig || !network?.rpcUrl || !Number.isFinite(nativeUsdPrice) || nativeUsdPrice <= 0) return null;

  try {
    const provider = new JsonRpcProvider(network.rpcUrl);
    const factory = new Contract(factoryConfig.factoryAddress, FACTORY_ABI, provider);
    const pairAddress: string = await factory.getPair(contractAddress, factoryConfig.wrappedNativeAddress);
    if (!pairAddress || pairAddress === '0x0000000000000000000000000000000000000000') return null;

    const pair = new Contract(pairAddress, PAIR_ABI, provider);
    const [reserve0, reserve1]: [bigint, bigint] = await pair.getReserves();
    const token0: string = await pair.token0();

    const tokenIsToken0 = identifiersEqual(networkId, token0, contractAddress);
    const [tokenReserveRaw, nativeReserveRaw] = tokenIsToken0 ? [reserve0, reserve1] : [reserve1, reserve0];

    const tokenReserve = Number(formatUnits(tokenReserveRaw, tokenDecimals));
    const nativeReserve = Number(formatUnits(nativeReserveRaw, factoryConfig.wrappedNativeDecimals));
    if (tokenReserve <= 0 || nativeReserve <= 0) return null;

    const priceInNative = nativeReserve / tokenReserve;
    return priceInNative * nativeUsdPrice;
  } catch (err) {
    console.warn(`On-chain reserve price lookup failed for ${contractAddress}:`, err);
    return null;
  }
}
