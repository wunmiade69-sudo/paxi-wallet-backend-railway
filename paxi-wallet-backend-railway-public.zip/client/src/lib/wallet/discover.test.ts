import { describe, expect, it } from "vitest";
import { CURATED_DAPPS, faviconFor, formatCompactUsd, normalizeUrl, resolveDappLogo, toDiscoverEntry } from "./discover";

describe("Discover link safety", () => {
  it("normalizes bare domains to HTTPS", () => {
    expect(normalizeUrl("app.example.org/path")).toBe("https://app.example.org/path");
  });

  it("rejects HTTP, unsafe schemes, malformed hosts, and embedded credentials", () => {
    expect(() => normalizeUrl("http://example.org")).toThrow(/HTTPS/i);
    expect(() => normalizeUrl("javascript:alert(1)")).toThrow();
    expect(() => normalizeUrl("https://user:password@example.org")).toThrow(/credentials/i);
    expect(() => normalizeUrl("https://localhost")).toThrow();
  });

  it("does not proxy favicons and preserves an entry-specific fallback boundary", () => {
    expect(faviconFor("http://example.org")).toBe("");
    expect(faviconFor("javascript:alert(1)")).toBe("");
    expect(faviconFor("https://dapp.example.org")).toBe("");
  });

  it("restores bundled logos for curated URLs saved in favorites or recents", () => {
    expect(resolveDappLogo({ url: "https://pancakeswap.finance" })).toBe("/dapp-logos/pancakeswap.svg");
    expect(resolveDappLogo({ url: "https://app.uniswap.org/swap" })).toBe("/dapp-logos/uniswap.svg");
    expect(resolveDappLogo({ url: "https://unknown.example" })).toBeUndefined();
  });

  it("strips a www. prefix when recovering a bundled logo by hostname", () => {
    expect(resolveDappLogo({ url: "https://www.pancakeswap.finance" })).toBe("/dapp-logos/pancakeswap.svg");
    expect(resolveDappLogo({ url: "https://www.uniswap.org" })).toBeUndefined(); // www. is stripped, but the app subdomain is not inferred
  });

  it("accepts only explicitly supplied HTTP(S) logos", () => {
    expect(resolveDappLogo({ url: "https://example.org", logoUrl: "https://cdn.example.org/logo.png" })).toBe("https://cdn.example.org/logo.png");
    expect(resolveDappLogo({ url: "https://example.org", logoUrl: "javascript:alert(1)" })).toBeUndefined();
    expect(resolveDappLogo({ url: "https://example.org" })).toBeUndefined();
  });

  it("preserves curated source and unknown trust state instead of implying verification", () => {
    const entry = toDiscoverEntry({
      id: "example",
      name: "Example DApp",
      url: "https://example.org",
      category: "DEX",
      description: "Example",
      supportedChains: ["ethereum"],
      logoUrl: "https://cdn.example.org/logo.png",
    });

    expect(entry.source).toBe("curated");
    expect(entry.verification).toBe("unknown");
    expect(entry.risk).toBe("unknown");
    expect(entry.logoUrl).toBe("https://cdn.example.org/logo.png");
  });

  it("uses explicit source-or-initials policy across all major curated categories", () => {
    const categories = new Set(CURATED_DAPPS.map((dapp) => dapp.category));
    expect(categories).toEqual(new Set(["DEX", "Aggregator", "Lending", "NFT", "Bridge"]));

    for (const dapp of CURATED_DAPPS) {
      const entry = toDiscoverEntry(dapp);
      // Every curated entry ships a bundled, same-origin badge under
      // /dapp-logos so the directory never falls back to bare initials.
      expect(resolveDappLogo(entry)).toBe(`/dapp-logos/${dapp.id}.svg`);
      expect(entry.verification).toBe("unknown");
      expect(entry.risk).toBe("unknown");
    }
  });

  it("keeps Bridge as its own filterable category instead of folding it into DeFi", () => {
    const jumper = toDiscoverEntry(CURATED_DAPPS.find((d) => d.id === "jumper")!);
    const uniswap = toDiscoverEntry(CURATED_DAPPS.find((d) => d.id === "uniswap")!);
    expect(jumper.category).toBe("bridge");
    expect(uniswap.category).toBe("defi");
  });

  it("formats real TVL magnitudes compactly", () => {
    expect(formatCompactUsd(1_800_000_000)).toBe("$1.8B");
    expect(formatCompactUsd(340_000_000)).toBe("$340M");
    expect(formatCompactUsd(12_500)).toBe("$12.5K");
    expect(formatCompactUsd(950)).toBe("$950");
  });
});
