/**
 * Discover tab data: a small curated dapp directory (name/url/category),
 * plus locally-saved "favorites" and "recently opened" links so pasting an
 * airdrop/registration URL once means it's one tap away next time.
 *
 * This wallet is a web app, not a native shell, so dapps are opened in a
 * new browser tab rather than an embedded webview - most dapps (Uniswap,
 * PancakeSwap, etc.) send X-Frame-Options/CSP headers that block iframing
 * anyway. Signing inside those tabs isn't wired up (that needs WalletConnect
 * with your own project ID); for now the fast path for things like airdrop
 * registration is copying your address and pasting it into their form.
 */

export interface DappEntry {
  name: string;
  url: string;
  category: 'DEX' | 'NFT' | 'Bridge' | 'Aggregator' | 'Lending';
  description: string;
  featured?: boolean;
}

export const CURATED_DAPPS: DappEntry[] = [
  { name: 'Uniswap', url: 'https://app.uniswap.org', category: 'DEX', description: 'Leading Ethereum DEX', featured: true },
  { name: 'PancakeSwap', url: 'https://pancakeswap.finance', category: 'DEX', description: 'Top DEX on BNB Chain', featured: true },
  { name: 'Curve', url: 'https://curve.fi', category: 'DEX', description: 'Stablecoin & pegged-asset swaps' },
  { name: '1inch', url: 'https://app.1inch.io', category: 'Aggregator', description: 'DEX aggregator, best-price routing' },
  { name: 'Aave', url: 'https://app.aave.com', category: 'Lending', description: 'Borrow & lend across chains' },
  { name: 'OpenSea', url: 'https://opensea.io', category: 'NFT', description: 'Largest NFT marketplace' },
  { name: 'Blur', url: 'https://blur.io', category: 'NFT', description: 'NFT marketplace for pro traders' },
  { name: 'Jumper (LI.FI)', url: 'https://jumper.exchange', category: 'Bridge', description: 'Cross-chain bridge aggregator', featured: true },
];

/** Logo source for every dapp, curated or user-pasted alike - derived from the URL itself via
 * Google's public favicon service rather than a per-entry field. (Previously used Clearbit's
 * logo API, which shut down permanently in December 2025 - deriving this dynamically from the
 * URL means there's no static logo field left to go stale the same way again.) */
export function faviconFor(url: string, size: 64 | 128 = 64): string {
  try {
    const { hostname } = new URL(url);
    return `https://www.google.com/s2/favicons?domain=${hostname}&sz=${size}`;
  } catch {
    return '';
  }
}

export interface SavedLink {
  id: string;
  url: string;
  label: string;
  savedAt: number;
}

const RECENTS_KEY = 'paxi-discover-recents';
const FAVORITES_KEY = 'paxi-discover-favorites';
const MAX_RECENTS = 12;

function labelFromUrl(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

/** Accepts a bare domain ("pancakeswap.finance") or a full URL and normalizes to https://... */
export function normalizeUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) throw new Error('Paste or type a link first.');
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    throw new Error("That doesn't look like a valid link.");
  }
  if (!parsed.hostname.includes('.')) throw new Error("That doesn't look like a valid link.");
  return parsed.toString();
}

function readList(key: string): SavedLink[] {
  try {
    const raw = JSON.parse(localStorage.getItem(key) ?? '[]');
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

export function getRecents(): SavedLink[] {
  return readList(RECENTS_KEY);
}

export function getFavorites(): SavedLink[] {
  return readList(FAVORITES_KEY);
}

export function isFavorite(url: string): boolean {
  return getFavorites().some((l) => l.url === url);
}

export function addRecent(url: string): void {
  const existing = getRecents().filter((l) => l.url !== url);
  const entry: SavedLink = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, url, label: labelFromUrl(url), savedAt: Date.now() };
  localStorage.setItem(RECENTS_KEY, JSON.stringify([entry, ...existing].slice(0, MAX_RECENTS)));
}

export function toggleFavorite(url: string): boolean {
  const favorites = getFavorites();
  const exists = favorites.find((l) => l.url === url);
  if (exists) {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites.filter((l) => l.url !== url)));
    return false;
  }
  const entry: SavedLink = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, url, label: labelFromUrl(url), savedAt: Date.now() };
  localStorage.setItem(FAVORITES_KEY, JSON.stringify([entry, ...favorites]));
  return true;
}

export function removeRecent(id: string): void {
  localStorage.setItem(RECENTS_KEY, JSON.stringify(getRecents().filter((l) => l.id !== id)));
}
