import type { DiscoverCategory, DiscoverEntry, RiskStatus, VerificationStatus } from '@/lib/phase3Models';
import { isSafeAssetImageUrl } from '@/components/AssetLogo';

/**
 * Discover data remains curated and client-side in this phase. The richer
 * fields make the catalog future-ready without implying that a listed dApp is
 * safe or that unavailable provider-backed categories contain live data.
 */
export interface DappEntry {
  id?: string;
  name: string;
  url: string;
  category: 'DEX' | 'NFT' | 'Bridge' | 'Aggregator' | 'Lending';
  description: string;
  /** Optional logo supplied by the curated catalog; never inferred from a domain. */
  logoUrl?: string;
  featured?: boolean;
  supportedChains?: string[];
  verification?: VerificationStatus;
  risk?: RiskStatus;
  status?: 'available' | 'unavailable' | 'coming-soon';
}

/**
 * Logos are bundled with the app under /public/dapp-logos instead of being
 * fetched from each dApp's own domain or a third-party favicon aggregator:
 * that keeps every curated entry rendering a real badge (not just initials)
 * without depending on a remote host's uptime, and without the per-request
 * privacy leak of asking a favicon service to resolve a user-visited domain.
 */
export const CURATED_DAPPS: DappEntry[] = [
  { id: 'uniswap', name: 'Uniswap', url: 'https://app.uniswap.org', category: 'DEX', description: 'Leading Ethereum DEX', logoUrl: '/dapp-logos/uniswap.svg', supportedChains: ['ethereum'], verification: 'unknown', risk: 'unknown', featured: true },
  { id: 'pancakeswap', name: 'PancakeSwap', url: 'https://pancakeswap.finance', category: 'DEX', description: 'Top DEX on BNB Chain', logoUrl: '/dapp-logos/pancakeswap.svg', supportedChains: ['bsc'], verification: 'unknown', risk: 'unknown', featured: true },
  { id: 'curve', name: 'Curve', url: 'https://curve.fi', category: 'DEX', description: 'Stablecoin & pegged-asset swaps', logoUrl: '/dapp-logos/curve.svg', supportedChains: ['ethereum', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: '1inch', name: '1inch', url: 'https://app.1inch.io', category: 'Aggregator', description: 'DEX aggregator, best-price routing', logoUrl: '/dapp-logos/1inch.svg', supportedChains: ['ethereum', 'bsc', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: 'aave', name: 'Aave', url: 'https://app.aave.com', category: 'Lending', description: 'Borrow & lend across chains', logoUrl: '/dapp-logos/aave.svg', supportedChains: ['ethereum', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: 'opensea', name: 'OpenSea', url: 'https://opensea.io', category: 'NFT', description: 'NFT marketplace', logoUrl: '/dapp-logos/opensea.svg', supportedChains: ['ethereum', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: 'blur', name: 'Blur', url: 'https://blur.io', category: 'NFT', description: 'NFT marketplace for pro traders', logoUrl: '/dapp-logos/blur.svg', supportedChains: ['ethereum'], verification: 'unknown', risk: 'unknown' },
  { id: 'jumper', name: 'Jumper (LI.FI)', url: 'https://jumper.exchange', category: 'Bridge', description: 'Cross-chain bridge aggregator', logoUrl: '/dapp-logos/jumper.svg', supportedChains: ['ethereum', 'bsc', 'polygon', 'arbitrum', 'solana'], verification: 'unknown', risk: 'unknown', featured: true },
];

const CATEGORY_MAP: Record<DappEntry['category'], DiscoverCategory> = {
  DEX: 'defi',
  Aggregator: 'exchanges',
  Lending: 'lending',
  NFT: 'nft',
  Bridge: 'defi',
};

export function toDiscoverEntry(dapp: DappEntry): DiscoverEntry {
  let domain = '';
  try {
    domain = new URL(dapp.url).hostname.replace(/^www\./, '');
  } catch {
    // Curated URLs are validated at authoring time; empty domain is honest if one is malformed.
  }
  return {
    id: dapp.id ?? dapp.url,
    name: dapp.name,
    url: dapp.url,
    description: dapp.description,
    ...(dapp.logoUrl ? { logoUrl: dapp.logoUrl } : {}),
    category: CATEGORY_MAP[dapp.category],
    supportedChains: dapp.supportedChains ?? [],
    domain,
    verification: dapp.verification ?? 'unknown',
    risk: dapp.risk ?? 'unknown',
    status: dapp.status ?? 'available',
    featured: dapp.featured,
    source: 'curated',
  };
}

/**
 * Discover does not proxy or guess remote logos. Returning an empty source keeps
 * the browser from sending a user’s browsing history to a favicon aggregator;
 * AssetLogo then renders the entry-specific text fallback.
 */
export function faviconFor(_url: string, _size: 64 | 128 = 64): string {
  return '';
}

/**
 * Resolve only a logo explicitly present in a curated/server entry. Domain-based
 * favicon guessing is intentionally unsupported; missing logos stay missing and
 * the shared AssetLogo component renders an entry-specific initials fallback.
 */
export function resolveDappLogo(entry: Pick<DiscoverEntry, 'logoUrl' | 'url'> | Pick<SavedLink, 'url'>): string | undefined {
  const logoUrl = 'logoUrl' in entry ? entry.logoUrl : undefined;
  if (isSafeAssetImageUrl(logoUrl)) return logoUrl;

  // Favorites and recents only retain a URL, so recover the bundled badge for
  // known curated hosts instead of dropping back to initials after navigation.
  try {
    if (!entry.url) return undefined;
    const hostname = new URL(entry.url).hostname.replace(/^www\\./, '').toLowerCase();
    const curated = CURATED_DAPPS.find((dapp) => {
      try {
        return new URL(dapp.url).hostname.replace(/^www\\./, '').toLowerCase() === hostname;
      } catch {
        return false;
      }
    });
    return isSafeAssetImageUrl(curated?.logoUrl) ? curated.logoUrl : undefined;
  } catch {
    return undefined;
  }
}

export interface SavedLink {
  id: string;
  url: string;
  label: string;
  savedAt: number;
}

const RECENTS_KEY = 'paxi-discover-recents';
const FAVORITES_KEY = 'paxi-discover-favorites';
const MAX_RECENTS = 12;

function labelFromUrl(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

/** Accepts a bare domain or a full URL and normalizes to https://... */
export function normalizeUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) throw new Error('Paste or type a link first.');
  if (/^http:\/\//i.test(trimmed)) throw new Error('Only HTTPS links can be opened.');
  const withScheme = /^https:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    throw new Error("That doesn't look like a valid link.");
  }
  if (parsed.protocol !== 'https:' || !parsed.hostname.includes('.') || parsed.username || parsed.password) {
    throw new Error('Only valid HTTPS links without embedded credentials can be opened.');
  }
  return parsed.toString();
}

function readList(key: string): SavedLink[] {
  try {
    const raw = JSON.parse(localStorage.getItem(key) ?? '[]');
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

export function getRecents(): SavedLink[] { return readList(RECENTS_KEY); }
export function getFavorites(): SavedLink[] { return readList(FAVORITES_KEY); }
export function isFavorite(url: string): boolean { return getFavorites().some((l) => l.url === url); }

export function addRecent(url: string): void {
  const existing = getRecents().filter((l) => l.url !== url);
  const entry: SavedLink = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, url, label: labelFromUrl(url), savedAt: Date.now() };
  localStorage.setItem(RECENTS_KEY, JSON.stringify([entry, ...existing].slice(0, MAX_RECENTS)));
}

export function toggleFavorite(url: string): boolean {
  const favorites = getFavorites();
  const exists = favorites.find((l) => l.url === url);
  if (exists) {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites.filter((l) => l.url !== url)));
    return false;
  }
  const entry: SavedLink = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, url, label: labelFromUrl(url), savedAt: Date.now() };
  localStorage.setItem(FAVORITES_KEY, JSON.stringify([entry, ...favorites]));
  return true;
}

export function removeRecent(id: string): void {
  localStorage.setItem(RECENTS_KEY, JSON.stringify(getRecents().filter((l) => l.id !== id)));
}
