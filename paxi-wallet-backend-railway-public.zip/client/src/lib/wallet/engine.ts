/**
 * Core, non-mock wallet engine. Uses ethers.js for real BIP-39 mnemonic
 * generation/validation and BIP-32/44 HD derivation of a secp256k1
 * (EVM-compatible) keypair. This is the same derivation MetaMask/Trust
 * Wallet use for Ethereum-family chains, so the address you get here is a
 * real, spendable address - not a placeholder.
 *
 * SOL uses ed25519 and the standard Phantom/Solflare derivation path
 * (m/44'/501'/0'/0'), via @noble/hashes (pure JS SLIP-0010 implementation
 * below) + @solana/web3.js.
 *
 * BTC uses BIP84 native segwit (m/84'/0'/0'/0/0, bc1... addresses), via
 * @scure/bip32 for HD derivation and bitcoinjs-lib + ecpair for the actual
 * keypair/address, with @bitcoinerlab/secp256k1 as the ECC backend -
 * deliberately chosen over the more common tiny-secp256k1 because that one
 * depends on WASM, which caused real problems earlier in this same wallet
 * for a different chain (see git history / conversation - ed25519-hd-key's
 * Node-crypto dependency crashed silently in-browser). Everything here is
 * pure JS on purpose.
 */
import { HDNodeWallet, Mnemonic, Wallet, isAddress as ethersIsAddress } from 'ethers';
import { Keypair, PublicKey } from '@solana/web3.js';
import { hmac } from '@noble/hashes/hmac';
import { sha512 } from '@noble/hashes/sha512';
import { HDKey } from '@scure/bip32';
import * as bitcoin from 'bitcoinjs-lib';
import { ECPairFactory, type ECPairInterface } from 'ecpair';
import * as ecc from '@bitcoinerlab/secp256k1';
import type { ChainType } from './chains';

bitcoin.initEccLib(ecc);
const ECPair = ECPairFactory(ecc);

const BITCOIN_DERIVATION_PATH = "m/84'/0'/0'/0/0"; // BIP84 native segwit (bc1...), same default as most modern wallets

export interface GeneratedWallet {
  mnemonic: string;
  evmAddress: string;
  privateKey: string;
}

const DERIVATION_PATH = "m/44'/60'/0'/0/0"; // standard EVM path
const SOLANA_DERIVATION_PATH = "m/44'/501'/0'/0'"; // standard Phantom/Solflare path

/** Generate a brand-new 12-word BIP-39 mnemonic and its EVM keypair. */
export function generateWallet(): GeneratedWallet {
  const wallet = HDNodeWallet.createRandom(undefined, DERIVATION_PATH);
  return {
    mnemonic: wallet.mnemonic!.phrase,
    evmAddress: wallet.address,
    privateKey: wallet.privateKey,
  };
}

/** Validate a BIP-39 mnemonic (checksum included), not just "12 words". */
export function isValidMnemonic(phrase: string): boolean {
  try {
    return Mnemonic.isValidMnemonic(phrase.trim().toLowerCase());
  } catch {
    return false;
  }
}

/** Recover the EVM keypair from an existing mnemonic. */
export function importWallet(phrase: string): GeneratedWallet {
  const normalized = phrase.trim().toLowerCase();
  if (!isValidMnemonic(normalized)) {
    throw new Error('Invalid recovery phrase');
  }
  const wallet = HDNodeWallet.fromPhrase(normalized, undefined, DERIVATION_PATH);
  return {
    mnemonic: normalized,
    evmAddress: wallet.address,
    privateKey: wallet.privateKey,
  };
}

/** Accepts a raw private key with or without the "0x" prefix. */
export function isValidPrivateKey(input: string): boolean {
  const trimmed = input.trim();
  const hex = trimmed.startsWith('0x') ? trimmed.slice(2) : trimmed;
  return /^[0-9a-fA-F]{64}$/.test(hex);
}

function normalizePrivateKey(input: string): string {
  const trimmed = input.trim();
  return trimmed.startsWith('0x') ? trimmed : `0x${trimmed}`;
}

/**
 * Import a single EVM account directly from its raw private key, rather than a seed phrase.
 * Unlike a mnemonic, a private key can't derive a Bitcoin or Solana address too - it's a
 * single secp256k1 keypair, EVM-only, by construction. Callers that need to distinguish this
 * kind of wallet from a full seed-based one should store that it came from importPrivateKey.
 */
export function importPrivateKey(privateKey: string): { evmAddress: string; privateKey: string } {
  if (!isValidPrivateKey(privateKey)) {
    throw new Error('Enter a valid private key (64 hex characters, with or without "0x").');
  }
  const normalized = normalizePrivateKey(privateKey);
  const wallet = new Wallet(normalized);
  return { evmAddress: wallet.address, privateKey: normalized };
}

/**
 * Rebuild the signing wallet (with private key) from stored signing material, which is either
 * a BIP-39 mnemonic (seed-based wallets - the normal case) or a raw private key (accounts
 * imported via importPrivateKey - EVM-only, no seed). Every EVM send/swap/bridge call site
 * reads its signing material through vault.ts's getUnlockedMnemonic() and hands it straight
 * to this function, so branching here (instead of at every call site) is what makes a
 * private-key-imported account "just work" for every EVM feature with no other code changes.
 */
export function walletFromMnemonic(material: string): Wallet {
  if (isValidPrivateKey(material)) {
    return new Wallet(normalizePrivateKey(material));
  }
  const hd = HDNodeWallet.fromPhrase(material, undefined, DERIVATION_PATH);
  return new Wallet(hd.privateKey);
}

function bip39SeedHex(mnemonic: string): string {
  // ethers already implements the real BIP-39 mnemonic->seed algorithm
  // (PBKDF2-HMAC-SHA512, 2048 rounds) - reuse it instead of pulling in a
  // second bip39 library just for this.
  return Mnemonic.fromPhrase(mnemonic.trim().toLowerCase()).computeSeed().slice(2); // strip "0x"
}

function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return bytes;
}

/**
 * SLIP-0010 ed25519 hierarchical derivation - the same algorithm Phantom/
 * Solflare use, implemented directly with @noble/hashes (pure JS, no Node
 * built-ins) instead of the `ed25519-hd-key` package. That package calls
 * Node's `crypto.createHmac` directly, which doesn't exist in a browser -
 * the resulting `undefined` return crashes the moment its code does
 * `result.slice(...)` on it. @noble/hashes has no such assumption (it's
 * what ethers itself uses internally), so this works the same everywhere.
 */
function ed25519DerivePath(path: string, seedHex: string): { key: Uint8Array } {
  const ED25519_CURVE = new TextEncoder().encode('ed25519 seed');
  const seed = hexToBytes(seedHex);

  const hmacSha512 = (key: Uint8Array, data: Uint8Array) => hmac(sha512, key, data);

  let I = hmacSha512(ED25519_CURVE, seed);
  let key = I.slice(0, 32);
  let chainCode = I.slice(32);

  const segments = path
    .split('/')
    .slice(1) // drop leading "m"
    .map((seg) => parseInt(seg.replace("'", ''), 10) + 0x80000000); // all hardened, per SLIP-0010 ed25519

  for (const index of segments) {
    const indexBytes = new Uint8Array(4);
    new DataView(indexBytes.buffer).setUint32(0, index, false); // big-endian
    const data = new Uint8Array(1 + 32 + 4);
    data.set(key, 1); // data[0] stays 0 (hardened-only marker byte)
    data.set(indexBytes, 33);
    I = hmacSha512(chainCode, data);
    key = I.slice(0, 32);
    chainCode = I.slice(32);
  }

  return { key };
}

/** Derive the real ed25519 Solana keypair for this mnemonic (Phantom/Solflare-compatible path). */
export function deriveSolanaKeypair(mnemonic: string): Keypair {
  const seedHex = bip39SeedHex(mnemonic);
  const { key } = ed25519DerivePath(SOLANA_DERIVATION_PATH, seedHex);
  return Keypair.fromSeed(key);
}

/** Derive the BIP84 native-segwit Bitcoin node (m/84'/0'/0'/0/0) - uses @scure/bip32,
 * pure JS like @noble/hashes, deliberately avoiding tiny-secp256k1's WASM dependency. */
function deriveBitcoinNode(mnemonic: string) {
  const seedHex = bip39SeedHex(mnemonic);
  const root = HDKey.fromMasterSeed(hexToBytes(seedHex));
  const child = root.derive(BITCOIN_DERIVATION_PATH);
  if (!child.privateKey || !child.publicKey) throw new Error('Failed to derive Bitcoin key');
  return child;
}

export function deriveBitcoinKeyPair(mnemonic: string): ECPairInterface {
  const child = deriveBitcoinNode(mnemonic);
  return ECPair.fromPrivateKey(Buffer.from(child.privateKey!));
}

export function deriveBitcoinAddress(mnemonic: string): string {
  const child = deriveBitcoinNode(mnemonic);
  const { address } = bitcoin.payments.p2wpkh({
    pubkey: Buffer.from(child.publicKey!),
    network: bitcoin.networks.bitcoin,
  });
  if (!address) throw new Error('Failed to derive Bitcoin address');
  return address;
}

/** For a private-key-imported account (EVM-only, no seed), only 'evm' resolves - 'sol'/'btc'
 * correctly return null rather than throwing, since there's no seed to derive them from. */
export function getAddressForChainType(mnemonic: string, chainType: ChainType): string | null {
  if (isValidPrivateKey(mnemonic)) {
    return chainType === 'evm' ? new Wallet(normalizePrivateKey(mnemonic)).address : null;
  }
  if (chainType === 'evm') {
    return HDNodeWallet.fromPhrase(mnemonic, undefined, DERIVATION_PATH).address;
  }
  if (chainType === 'sol') {
    return deriveSolanaKeypair(mnemonic).publicKey.toBase58();
  }
  if (chainType === 'btc') {
    return deriveBitcoinAddress(mnemonic);
  }
  return null;
}

export function isValidAddressForChainType(address: string, chainType: ChainType): boolean {
  if (chainType === 'evm') return ethersIsAddress(address);
  if (chainType === 'btc') {
    try {
      // Real validation - actually decodes the address into an output script,
      // not just a shape/regex check.
      bitcoin.address.toOutputScript(address, bitcoin.networks.bitcoin);
      return true;
    } catch {
      return false;
    }
  }
  if (chainType === 'sol') {
    try {
      // Real validation - decodes as a base58 32-byte curve point, not just a shape check.
      new PublicKey(address);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

/** Export an encrypted keystore (ethers v3 JSON keystore format) protected by a password. */
export async function exportEncryptedKeystore(mnemonic: string, password: string): Promise<string> {
  const wallet = walletFromMnemonic(mnemonic);
  return wallet.encrypt(password);
}
