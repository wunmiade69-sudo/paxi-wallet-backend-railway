import { describe, expect, it } from 'vitest';
import { describeTxError, isThorchainTradingHaltedError } from './errors';

describe('transaction error presentation', () => {
  it('recognizes upstream THORChain trading halts', () => {
    expect(isThorchainTradingHaltedError(new Error('THORChain: trading is halted'))).toBe(true);
    expect(isThorchainTradingHaltedError(new Error('temporary network halt'))).toBe(true);
    expect(isThorchainTradingHaltedError(new Error('insufficient funds'))).toBe(false);
  });

  it('replaces raw THORChain halt errors with an actionable maintenance message', () => {
    expect(describeTxError(new Error('THORChain: trading is halted'))).toBe(
      'THORChain swaps are temporarily paused. No funds were sent. Please try again when trading resumes.'
    );
  });
});
