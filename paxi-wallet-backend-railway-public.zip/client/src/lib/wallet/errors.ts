/**
 * ethers.js / JSON-RPC errors come back as large, quoted, developer-facing
 * blobs (nested `info.error.message`, request payloads, code=INSUFFICIENT_FUNDS,
 * version tags, etc). Fine for a console.error, unusable in a UI. This maps
 * the common cases to a short sentence a user can actually act on, and falls
 * back to hiding anything else that's clearly not written for a human.
 */
export function isThorchainTradingHaltedError(err: unknown): boolean {
  const raw = err instanceof Error ? err.message : String(err ?? '');
  const lower = raw.toLowerCase();
  return lower.includes('trading is halted') || lower.includes('swap is halted') || lower.includes('network halt') || lower.includes("can't process swap");
}

export type TxErrorContext = 'send' | 'swap';

/**
 * Shared by Send, Swap, Bridge, and THORChain flows. The revert/execution-failure
 * branch defaults to swap wording ("different pair", "slippage") since that's the
 * majority of callers; Send passes context: 'send' so a plain transfer failure
 * doesn't suggest swap-only remedies that don't apply to it.
 */
export function describeTxError(err: unknown, context: TxErrorContext = 'swap'): string {
  const raw = err instanceof Error ? err.message : String(err ?? '');
  const lower = raw.toLowerCase();

  if (isThorchainTradingHaltedError(err)) {
    return 'THORChain swaps are temporarily paused. No funds were sent. Please try again when trading resumes.';
  }
  if (lower.includes('insufficient funds') || lower.includes('insufficient_funds')) {
    return "You don't have enough balance to cover this amount plus the network fee.";
  }
  if (lower.includes('user rejected') || lower.includes('action_rejected') || lower.includes('user denied')) {
    return 'Transaction was cancelled.';
  }
  if (lower.includes('nonce')) {
    return 'Another transaction is still pending. Please wait a moment and try again.';
  }
  if (lower.includes('replacement fee too low') || lower.includes('underpriced') || lower.includes('fee too low')) {
    return 'Network is busy right now. Please try again in a moment.';
  }
  if (lower.includes('gas required exceeds allowance') || lower.includes('out of gas')) {
    return "This transaction needs more gas than your balance allows. Try a smaller amount, or add more to cover network fees.";
  }
  if (lower.includes('call_exception') || lower.includes('execution reverted') || lower.includes('unpredictable_gas_limit')) {
    return context === 'send'
      ? 'This transaction would fail on-chain. Double-check the recipient address and amount, and make sure you have enough balance to cover the network fee.'
      : 'This transaction would fail on-chain. Try a smaller amount, a different pair, or a higher slippage tolerance.';
  }
  if (lower.includes('timeout') || lower.includes('failed to fetch') || lower.includes('network error')) {
    return 'Network connection issue. Check your internet connection and try again.';
  }
  if (lower.includes('rate limit') || lower.includes('429')) {
    return 'Too many requests right now. Please wait a moment and try again.';
  }

  // Anything else: don't show a raw provider/RPC dump (long, quoted, JSON-shaped)
  // straight to the user - keep it short and generic instead.
  const looksLikeRawProviderError = raw.length > 140 || /code=|"error"|version=\d/.test(raw);
  return looksLikeRawProviderError ? 'Something went wrong with this transaction. Please try again.' : raw;
}
