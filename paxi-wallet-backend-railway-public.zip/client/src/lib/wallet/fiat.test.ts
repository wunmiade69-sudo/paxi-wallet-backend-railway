import { describe, expect, it } from "vitest";
import { convertUsdToFiat, formatFiat, isFiatCurrency } from "./fiat";

describe("fiat conversion", () => {
  it("accepts only the supported fiat currencies", () => {
    expect(isFiatCurrency("USD")).toBe(true);
    expect(isFiatCurrency("EUR")).toBe(true);
    expect(isFiatCurrency("CAD")).toBe(false);
    expect(isFiatCurrency(null)).toBe(false);
  });

  it("converts USD values with the verified rate for the selected currency", () => {
    expect(convertUsdToFiat(100, "EUR", { EUR: 0.92 })).toBeCloseTo(92);
    expect(convertUsdToFiat(100, "USD", {})).toBe(100);
  });

  it("does not silently display USD when a selected-currency rate is missing", () => {
    expect(convertUsdToFiat(100, "GBP", {})).toBeNull();
    expect(convertUsdToFiat(-1, "EUR", { EUR: 0.92 })).toBeNull();
  });

  it("formats supported currencies with their native symbols", () => {
    expect(formatFiat(1234.5, "USD")).toContain("$");
    expect(formatFiat(1234.5, "EUR")).toContain("€");
    expect(formatFiat(1234.5, "JPY")).toMatch(/[¥￥]/);
  });
});
