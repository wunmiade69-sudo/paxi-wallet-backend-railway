import { safeGetLocalStorage } from "@/lib/safeStorage";

export const FIAT_CURRENCIES = ["USD", "EUR", "GBP", "JPY", "INR"] as const;
export type FiatCurrency = (typeof FIAT_CURRENCIES)[number];

const FIAT_STORAGE_KEY = "paxi-currency";
const COINGECKO_SIMPLE_PRICE_URL =
  "https://api.coingecko.com/api/v3/simple/price?ids=usd-coin&vs_currencies=eur,gbp,jpy,inr";

const LOCALES: Record<FiatCurrency, string> = {
  USD: "en-US",
  EUR: "de-DE",
  GBP: "en-GB",
  JPY: "ja-JP",
  INR: "en-IN",
};

const SYMBOLS: Record<FiatCurrency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  JPY: "¥",
  INR: "₹",
};

export type FiatRates = Partial<Record<Exclude<FiatCurrency, "USD">, number>>;

export function isFiatCurrency(
  value: string | null | undefined
): value is FiatCurrency {
  return Boolean(value && FIAT_CURRENCIES.includes(value as FiatCurrency));
}

export function getStoredFiatCurrency(): FiatCurrency {
  const value = safeGetLocalStorage(FIAT_STORAGE_KEY);
  return isFiatCurrency(value) ? value : "USD";
}

export function getFiatSymbol(currency: FiatCurrency): string {
  return SYMBOLS[currency];
}

export function convertUsdToFiat(
  usdValue: number,
  currency: FiatCurrency,
  rates: FiatRates
): number | null {
  if (!Number.isFinite(usdValue) || usdValue < 0) return null;
  if (currency === "USD") return usdValue;
  const rate = rates[currency];
  return Number.isFinite(rate) && (rate as number) > 0
    ? usdValue * (rate as number)
    : null;
}

export function formatFiat(value: number, currency: FiatCurrency): string {
  const maximumFractionDigits = currency === "JPY" ? 0 : 2;
  return new Intl.NumberFormat(LOCALES[currency], {
    style: "currency",
    currency,
    minimumFractionDigits: currency === "JPY" ? 0 : 2,
    maximumFractionDigits,
  }).format(value);
}

export async function fetchFiatRates(signal?: AbortSignal): Promise<FiatRates> {
  const response = await fetch(COINGECKO_SIMPLE_PRICE_URL, {
    signal,
    headers: { Accept: "application/json" },
  });
  if (!response.ok)
    throw new Error(`Fiat rate request failed (${response.status})`);
  const payload = (await response.json()) as {
    "usd-coin"?: Record<string, unknown>;
  };
  const rates = payload["usd-coin"];
  if (!rates || typeof rates !== "object")
    throw new Error("Fiat rate response was empty");

  const next: FiatRates = {};
  for (const currency of ["EUR", "GBP", "JPY", "INR"] as const) {
    const value = rates[currency.toLowerCase()];
    if (typeof value === "number" && Number.isFinite(value) && value > 0)
      next[currency] = value;
  }
  if (Object.keys(next).length !== 4)
    throw new Error("Fiat rate response was incomplete");
  return next;
}
