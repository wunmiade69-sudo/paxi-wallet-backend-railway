import { describe, expect, it } from "vitest";
import {
  getSolanaFeeConfig,
  normalizeSolanaTreasuryAddress,
  SOL_WALLET_FEE_BPS,
} from "./jupiterSwap";

describe("Solana wallet-fee configuration", () => {
  it("fails closed for missing or malformed treasury values", () => {
    expect(normalizeSolanaTreasuryAddress(undefined)).toBe("");
    expect(normalizeSolanaTreasuryAddress(" ")).toBe("");
    expect(normalizeSolanaTreasuryAddress("not-a-solana-address")).toBe("");

    expect(getSolanaFeeConfig("")).toEqual({
      status: "configuration_required",
      enabled: false,
      feeBps: 0,
      treasuryAddress: null,
    });
    expect(getSolanaFeeConfig("not-a-solana-address")).toEqual({
      status: "configuration_required",
      enabled: false,
      feeBps: 0,
      treasuryAddress: null,
    });
  });

  it("does not silently redirect a fee when the treasury is missing", () => {
    const config = getSolanaFeeConfig(undefined);
    expect(config.enabled).toBe(false);
    expect(config.feeBps).toBe(0);
    expect(config.treasuryAddress).toBeNull();
    expect(config.status).toBe("configuration_required");
  });

  it("enables the fee only for a valid Solana treasury address", () => {
    const treasury = "11111111111111111111111111111111";
    expect(normalizeSolanaTreasuryAddress(treasury)).toBe(treasury);
    expect(getSolanaFeeConfig(treasury)).toEqual({
      status: "configured",
      enabled: true,
      feeBps: SOL_WALLET_FEE_BPS,
      treasuryAddress: treasury,
    });
  });
});

describe("Solana fee boundary", () => {
  it("keeps missing configuration safe for swap execution", () => {
    const config = getSolanaFeeConfig("");
    expect(config.treasuryAddress).toBeNull();
    expect(config.enabled).toBe(false);
    expect(config.feeBps).toBe(0);
  });
});
