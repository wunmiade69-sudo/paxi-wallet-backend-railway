import { afterEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({ solanaQuote: vi.fn() }));
vi.mock('../trpcVanilla', () => ({
  trpcVanilla: { swap: { solanaQuote: { query: mocks.solanaQuote } } },
}));

import { getSolanaSwapQuote, SOL_TREASURY_ADDRESS } from './jupiterSwap';
import type { AssetConfig } from './chains';

const sol: AssetConfig = {
  symbol: 'SOL',
  name: 'Solana',
  icon: '◎',
  network: 'solana',
  isNative: true,
  decimals: 9,
};

const usdc: AssetConfig = {
  symbol: 'USDC',
  name: 'USD Coin',
  icon: '$',
  network: 'solana',
  isNative: false,
  contractAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  decimals: 6,
};

describe('Jupiter Solana execution boundary', () => {
  afterEach(() => {
    mocks.solanaQuote.mockReset();
    vi.restoreAllMocks();
  });

  it('does not request or report a Solana platform fee without a treasury address', async () => {
    expect(SOL_TREASURY_ADDRESS).toBe('');
    mocks.solanaQuote.mockResolvedValue({
      quoteResponse: { inAmount: '1000000000', outAmount: '150000000', otherAmountThreshold: '148500000', routePlan: [{ swapInfo: { label: 'Mock route' } }] },
      inputAmountUnits: '1000000000',
      outputAmountUnits: '150000000',
      minimumOutputAmountUnits: '148500000',
      routeNames: ['Mock route'],
    });

    const quote = await getSolanaSwapQuote({ fromAsset: sol, toAsset: usdc, amount: '1', slippageBps: 100 });

    expect(mocks.solanaQuote).toHaveBeenCalledWith({
      inputMint: 'So11111111111111111111111111111111111111112',
      outputMint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
      amount: '1000000000',
      slippageBps: 100,
    });
    expect(quote.feeBps).toBe(0);
    expect(quote.feeAmountFormatted).toBe('0');
  });

  it('rejects an invalid or empty Jupiter route instead of creating an executable quote', async () => {
    mocks.solanaQuote.mockResolvedValue({
      quoteResponse: { routePlan: [] },
      inputAmountUnits: '0',
      outputAmountUnits: '0',
      minimumOutputAmountUnits: '0',
      routeNames: [],
    });

    await expect(getSolanaSwapQuote({ fromAsset: sol, toAsset: usdc, amount: '1' })).rejects.toThrow('invalid or unavailable Solana route');
  });

  it('does not report success when Jupiter times out or the provider rejects the request', async () => {
    mocks.solanaQuote.mockRejectedValue(new Error('request timed out'));

    await expect(getSolanaSwapQuote({ fromAsset: sol, toAsset: usdc, amount: '1' })).rejects.toThrow('request timed out');
  });
});
