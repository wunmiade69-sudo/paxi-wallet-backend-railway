/**
 * Solana swap engine via Jupiter Aggregator (quote-api.jup.ag) - the
 * standard multi-DEX router for Solana, the equivalent of what Velora does
 * for EVM in swap.ts. No API key needed for this usage level.
 *
 * Uses the /swap-instructions endpoint (raw instructions) rather than
 * /swap (a pre-compiled, already-signed-shape transaction), specifically
 * so this wallet's own fee-collection instruction can be added into the
 * same transaction - a compiled VersionedTransaction from /swap can't be
 * modified afterward.
 *
 * FEE NOTE (documented limitation, not silently skipped): the platform fee
 * is taken via Jupiter's own platformFeeBps mechanism into an associated
 * token account for the OUTPUT mint, owned by the Solana treasury address.
 * That account is created on-the-fly (paid by the swapper, a few thousand
 * lamports) if it doesn't exist yet - this works for any output token.
 */
import {
  Connection,
  PublicKey,
  TransactionMessage,
  VersionedTransaction,
  AddressLookupTableAccount,
} from "@solana/web3.js";
import { NETWORKS, type AssetConfig } from "./chains";
import { deriveSolanaKeypair } from "./engine";
import type { SwapQuote } from "./swap";
import type { TxStatus } from "./txHistory";

const JUPITER_API_BASE = "https://quote-api.jup.ag/v6";
export const SOL_WALLET_FEE_BPS = 30; // 0.3%, matches the EVM fee

export type SolanaFeeStatus = "configured" | "configuration_required";

/**
 * Solana uses a different address curve from the EVM treasury. The address is
 * an explicit public client configuration value; malformed or missing values
 * fail closed and never become a fee destination.
 */
export function normalizeSolanaTreasuryAddress(
  value: string | undefined
): string {
  const trimmed = value?.trim() ?? "";
  if (!trimmed) return "";
  try {
    return new PublicKey(trimmed).toBase58();
  } catch {
    return "";
  }
}

const configuredSolanaTreasuryAddress = normalizeSolanaTreasuryAddress(
  import.meta.env.VITE_PAXI_SOLANA_TREASURY_ADDRESS as string | undefined
);

/** Empty means Solana wallet-fee collection is intentionally disabled. */
export const SOL_TREASURY_ADDRESS = configuredSolanaTreasuryAddress;

export function getSolanaFeeConfig(treasuryAddress = SOL_TREASURY_ADDRESS): {
  status: SolanaFeeStatus;
  enabled: boolean;
  feeBps: number;
  treasuryAddress: string | null;
} {
  const normalizedTreasury = normalizeSolanaTreasuryAddress(treasuryAddress);
  if (!normalizedTreasury) {
    return {
      status: "configuration_required",
      enabled: false,
      feeBps: 0,
      treasuryAddress: null,
    };
  }
  return {
    status: "configured",
    enabled: true,
    feeBps: SOL_WALLET_FEE_BPS,
    treasuryAddress: normalizedTreasury,
  };
}

const NATIVE_SOL_MINT = "So11111111111111111111111111111111111111112";

function mintFor(asset: AssetConfig): string {
  return asset.isNative ? NATIVE_SOL_MINT : asset.contractAddress!;
}

export function isSolanaSwappable(asset: AssetConfig): boolean {
  return NETWORKS[asset.network]?.chainType === "sol";
}

/** Internal: the raw Jupiter quote, kept alongside the shared SwapQuote shape for use at execute time. */
type SolanaSwapQuote = SwapQuote & { _jupiterRaw: any };

export async function getSolanaSwapQuote(params: {
  fromAsset: AssetConfig;
  toAsset: AssetConfig;
  amount: string; // human units
  slippageBps?: number;
}): Promise<SolanaSwapQuote> {
  const inputMint = mintFor(params.fromAsset);
  const outputMint = mintFor(params.toAsset);
  const feeConfig = getSolanaFeeConfig();
  const amountUnits = Math.round(
    Number(params.amount) * 10 ** params.fromAsset.decimals
  );

  const url = new URL(`${JUPITER_API_BASE}/quote`);
  url.searchParams.set("inputMint", inputMint);
  url.searchParams.set("outputMint", outputMint);
  url.searchParams.set("amount", String(amountUnits));
  url.searchParams.set("slippageBps", String(params.slippageBps ?? 100));
  if (feeConfig.enabled)
    url.searchParams.set("platformFeeBps", String(feeConfig.feeBps));

  const res = await fetch(url.toString());
  if (!res.ok) throw new Error("Could not get a Solana swap quote.");
  const quote = await res.json();

  const destAmount = Number(quote.outAmount) / 10 ** params.toAsset.decimals;
  const destAmountMin =
    Number(quote.otherAmountThreshold) / 10 ** params.toAsset.decimals;
  const routeNames: string[] = Array.from(
    new Set<string>(
      (quote.routePlan ?? [])
        .map((r: any) => r.swapInfo?.label)
        .filter((l: unknown): l is string => typeof l === "string")
    )
  );
  // Jupiter's platform fee comes out of the OUTPUT (destAsset), unlike the
  // EVM path's fee-from-source display - shown correctly in SwapPanel by
  // labeling this with toAsset.symbol for Solana quotes specifically.
  const feeAmount = feeConfig.enabled
    ? destAmount * (feeConfig.feeBps / 10000)
    : 0;

  return {
    priceRoute: quote,
    srcAmountUnits: quote.inAmount,
    destAmountUnits: quote.outAmount,
    destAmountFormatted: destAmount.toString(),
    destAmountMinFormatted: destAmountMin.toString(),
    rate: destAmount / Number(params.amount),
    feeBps: feeConfig.feeBps,
    feeAmountFormatted: feeAmount.toString(),
    walletFeeStatus: feeConfig.status,
    tokenTransferProxy: "",
    gasCostEstimate: null,
    routeNames,
    quoteFetchedAt: Date.now(),
    _jupiterRaw: quote,
  };
}

function instructionFromJson(ix: any) {
  return {
    programId: new PublicKey(ix.programId),
    keys: ix.accounts.map((a: any) => ({
      pubkey: new PublicKey(a.pubkey),
      isSigner: a.isSigner,
      isWritable: a.isWritable,
    })),
    data: Buffer.from(ix.data, "base64"),
  };
}

export async function executeSolanaSwap(params: {
  mnemonic: string;
  quote: SolanaSwapQuote;
  toAsset: AssetConfig;
}): Promise<{
  swapHash: string;
  explorerUrl?: string;
  status: Extract<TxStatus, "submitted" | "confirmed">;
  finality?: "solana_confirmed";
}> {
  const network = NETWORKS[params.toAsset.network];
  if (!network?.rpcUrl) throw new Error("Solana RPC is not configured.");

  const connection = new Connection(network.rpcUrl, "confirmed");
  const keypair = deriveSolanaKeypair(params.mnemonic);

  const feeConfig = getSolanaFeeConfig();
  const feeAccountBody: Record<string, unknown> = {};
  if (feeConfig.enabled && feeConfig.treasuryAddress) {
    const { getAssociatedTokenAddressSync } = await import("@solana/spl-token");
    const outputMint = new PublicKey(mintFor(params.toAsset));
    const feeAccount = getAssociatedTokenAddressSync(
      outputMint,
      new PublicKey(feeConfig.treasuryAddress)
    );
    feeAccountBody.feeAccount = feeAccount.toBase58();
  }

  const res = await fetch(`${JUPITER_API_BASE}/swap-instructions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      quoteResponse: params.quote._jupiterRaw,
      userPublicKey: keypair.publicKey.toBase58(),
      wrapAndUnwrapSol: true,
      ...feeAccountBody,
    }),
  });
  if (!res.ok) throw new Error("Could not build the Solana swap transaction.");
  const data = await res.json();

  const instructions = [
    ...(data.computeBudgetInstructions ?? []).map(instructionFromJson),
    ...(data.setupInstructions ?? []).map(instructionFromJson),
    instructionFromJson(data.swapInstruction),
    ...(data.cleanupInstruction
      ? [instructionFromJson(data.cleanupInstruction)]
      : []),
  ];

  const lookupTableAccounts: AddressLookupTableAccount[] = [];
  for (const address of data.addressLookupTableAddresses ?? []) {
    const account = await connection.getAddressLookupTable(
      new PublicKey(address)
    );
    if (account.value) lookupTableAccounts.push(account.value);
  }

  const { blockhash } = await connection.getLatestBlockhash("confirmed");
  const message = new TransactionMessage({
    payerKey: keypair.publicKey,
    recentBlockhash: blockhash,
    instructions,
  }).compileToV0Message(lookupTableAccounts);

  const tx = new VersionedTransaction(message);
  tx.sign([keypair]);

  const signature = await connection.sendTransaction(tx, {
    skipPreflight: false,
    maxRetries: 3,
  });
  try {
    await connection.confirmTransaction(signature, "confirmed");
    return {
      swapHash: signature,
      explorerUrl: network.explorerTx?.(signature),
      status: "confirmed",
      finality: "solana_confirmed",
    };
  } catch (error) {
    console.warn(
      "Solana swap confirmation timed out; leaving status submitted for recovery:",
      error
    );
    return {
      swapHash: signature,
      explorerUrl: network.explorerTx?.(signature),
      status: "submitted",
    };
  }
}
