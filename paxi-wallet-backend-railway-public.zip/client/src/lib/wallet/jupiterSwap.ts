/**
 * Solana swap engine via Jupiter Aggregator (quote-api.jup.ag) - the
 * standard multi-DEX router for Solana, the equivalent of what Velora does
 * for EVM in swap.ts. No API key needed for this usage level.
 *
 * Uses the /swap-instructions endpoint (raw instructions) rather than
 * /swap (a pre-compiled, already-signed-shape transaction), specifically
 * so this wallet's own fee-collection instruction can be added into the
 * same transaction - a compiled VersionedTransaction from /swap can't be
 * modified afterward.
 *
 * FEE NOTE (documented limitation, not silently skipped): the platform fee
 * is taken via Jupiter's own platformFeeBps mechanism into an associated
 * token account for the OUTPUT mint, owned by the Solana treasury address.
 * That account is created on-the-fly (paid by the swapper, a few thousand
 * lamports) if it doesn't exist yet - this works for any output token.
 */
import { parseUnits } from 'ethers';
import {
  Connection,
  PublicKey,
  TransactionMessage,
  VersionedTransaction,
  AddressLookupTableAccount,
} from '@solana/web3.js';
import { NETWORKS, type AssetConfig } from './chains';
import { deriveSolanaKeypair } from './engine';
import type { SwapQuote } from './swap';
import { trpcVanilla } from '../trpcVanilla';
import { formatBaseUnits, parseExactIntegerUnits } from '@shared/exactDecimal';

export const SOL_WALLET_FEE_BPS = 30; // 0.3%, matches the EVM fee

/** Set this to the Solana address fees should land in - a separate address
 * from the EVM treasury (different curve/chain), still to be provided. */
export const SOL_TREASURY_ADDRESS = ''; // <- fill in before fees can be collected on Solana swaps

const NATIVE_SOL_MINT = 'So11111111111111111111111111111111111111112';

function mintFor(asset: AssetConfig): string {
  return asset.isNative ? NATIVE_SOL_MINT : asset.contractAddress!;
}

export function isSolanaSwappable(asset: AssetConfig): boolean {
  return NETWORKS[asset.network]?.chainType === 'sol';
}

/** Internal: the raw Jupiter quote, kept alongside the shared SwapQuote shape for use at execute time. */
type SolanaSwapQuote = SwapQuote & { _jupiterRaw: any };

export async function getSolanaSwapQuote(params: {
  fromAsset: AssetConfig;
  toAsset: AssetConfig;
  amount: string; // human units
  slippageBps?: number;
}): Promise<SolanaSwapQuote> {
  const inputMint = mintFor(params.fromAsset);
  const outputMint = mintFor(params.toAsset);
  const amountUnits = parseUnits(params.amount, params.fromAsset.decimals).toString();
  const quoteResult = await trpcVanilla.swap.solanaQuote.query({
    inputMint,
    outputMint,
    amount: amountUnits,
    slippageBps: params.slippageBps ?? 100,
  });
  const quote = quoteResult.quoteResponse;
  const inputUnits = parseExactIntegerUnits(quoteResult.inputAmountUnits, 'Jupiter input amount');
  const outputUnits = parseExactIntegerUnits(quoteResult.outputAmountUnits, 'Jupiter output amount');
  const minimumOutputUnits = parseExactIntegerUnits(quoteResult.minimumOutputAmountUnits, 'Jupiter minimum output amount');
  if (inputUnits <= 0n || outputUnits <= 0n || minimumOutputUnits <= 0n) {
    throw new Error('Jupiter returned an invalid or unavailable Solana route.');
  }

  const destAmount = formatBaseUnits(outputUnits, params.toAsset.decimals);
  const destAmountMin = formatBaseUnits(minimumOutputUnits, params.toAsset.decimals);
  const routeNames = quoteResult.routeNames;
  // Jupiter's platform fee comes out of the OUTPUT (destAsset), unlike the
  // EVM path's fee-from-source display - shown correctly in SwapPanel by
  // labeling this with toAsset.symbol for Solana quotes specifically.
  const feeAmount = SOL_TREASURY_ADDRESS
    ? formatBaseUnits((outputUnits * BigInt(SOL_WALLET_FEE_BPS)) / 10_000n, params.toAsset.decimals)
    : '0';

  return {
    priceRoute: quote,
    srcAmountUnits: inputUnits.toString(),
    destAmountUnits: outputUnits.toString(),
    destAmountFormatted: destAmount,
    destAmountMinFormatted: destAmountMin,
    // Compatibility/display field only; exact source/destination units above
    // are the values used by the quote and transaction path.
    rate: Number(destAmount) / Number(params.amount),
    feeBps: SOL_TREASURY_ADDRESS ? SOL_WALLET_FEE_BPS : 0,
    feeAmountFormatted: feeAmount.toString(),
    feeAddress: SOL_TREASURY_ADDRESS || null,
    tokenTransferProxy: '',
    gasCostEstimate: null,
    routeNames,
    _jupiterRaw: quote,
  };
}

function instructionFromJson(ix: any) {
  return {
    programId: new PublicKey(ix.programId),
    keys: ix.accounts.map((a: any) => ({
      pubkey: new PublicKey(a.pubkey),
      isSigner: a.isSigner,
      isWritable: a.isWritable,
    })),
    data: Buffer.from(ix.data, 'base64'),
  };
}

export async function executeSolanaSwap(params: {
  mnemonic: string;
  quote: SolanaSwapQuote;
  toAsset: AssetConfig;
}): Promise<{ swapHash: string; explorerUrl?: string; status: 'confirmed' }> {
  const network = NETWORKS[params.toAsset.network];
  if (!network?.rpcUrl) throw new Error('Solana RPC is not configured.');

  const connection = new Connection(network.rpcUrl, 'confirmed');
  const keypair = deriveSolanaKeypair(params.mnemonic);

  const data = await trpcVanilla.swap.solanaInstructions.query({
    quoteResponse: params.quote._jupiterRaw,
    userPublicKey: keypair.publicKey.toBase58(),
  });

  const instructions = [
    ...(data.computeBudgetInstructions ?? []).map(instructionFromJson),
    ...(data.setupInstructions ?? []).map(instructionFromJson),
    instructionFromJson(data.swapInstruction),
    ...(data.cleanupInstruction ? [instructionFromJson(data.cleanupInstruction)] : []),
  ];

  const lookupTableAccounts: AddressLookupTableAccount[] = [];
  for (const address of data.addressLookupTableAddresses ?? []) {
    const account = await connection.getAddressLookupTable(new PublicKey(address));
    if (account.value) lookupTableAccounts.push(account.value);
  }

  const { blockhash } = await connection.getLatestBlockhash('confirmed');
  const message = new TransactionMessage({
    payerKey: keypair.publicKey,
    recentBlockhash: blockhash,
    instructions,
  }).compileToV0Message(lookupTableAccounts);

  const tx = new VersionedTransaction(message);
  tx.sign([keypair]);

  const signature = await connection.sendTransaction(tx, { skipPreflight: false, maxRetries: 3 });
  await connection.confirmTransaction(signature, 'confirmed');

  return { swapHash: signature, explorerUrl: network.explorerTx?.(signature), status: 'confirmed' as const };
}
