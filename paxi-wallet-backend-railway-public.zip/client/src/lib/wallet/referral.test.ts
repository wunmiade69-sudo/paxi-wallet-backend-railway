import { describe, expect, it } from "vitest";
import { getReferralCode, getReferralLink } from "./referral";

describe("referral links", () => {
  it("keeps the deterministic wallet code", () => {
    expect(getReferralCode("0xabcdef1234567890")).toBe("PAXI-34567890");
  });

  it("returns a relative link without inventing a production hostname", () => {
    expect(getReferralLink("0xabcdef1234567890")).toBe("/r/PAXI-34567890");
  });

  it("resolves only against an explicit HTTP(S) origin", () => {
    expect(getReferralLink("0xabcdef1234567890", "https://wallet.example/app")).toBe("https://wallet.example/r/PAXI-34567890");
    expect(getReferralLink("0xabcdef1234567890", "javascript:alert(1)")).toBe("/r/PAXI-34567890");
  });
});

