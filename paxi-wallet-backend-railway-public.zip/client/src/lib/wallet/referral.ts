/**
 * Referral code/link generation. The code is deterministic (derived from
 * the wallet address), so it's stable across devices without needing a
 * backend account. What this does NOT do yet: track who actually signed
 * up through your link, or credit any reward - that needs a backend plus
 * the WPAXI token to exist. The UI is upfront about that rather than
 * showing fabricated invite counts.
 */

import { PAXI_PUBLIC_URL } from "@/lib/appInfo";

const REFERRAL_BASE_URL = PAXI_PUBLIC_URL ? `${PAXI_PUBLIC_URL}/r` : null;

/** Short, shareable, deterministic per-address code (not a secret - it's just an identifier). */
export function getReferralCode(address: string): string {
  const clean = address.replace(/^0x/i, "").toUpperCase();
  return `PAXI-${clean.slice(-8)}`;
}

export function getReferralLink(address: string): string | null {
  return REFERRAL_BASE_URL
    ? `${REFERRAL_BASE_URL}/${getReferralCode(address)}`
    : null;
}
