/**
 * Referral code/link generation. The code is deterministic (derived from
 * the wallet address), so it's stable across devices without needing a
 * backend account. What this does NOT do yet: track who actually signed
 * up through your link, or credit any reward - that needs a backend plus
 * the WPAXI token to exist. The UI is upfront about that rather than
 * showing fabricated invite counts.
 */

/** Short, shareable, deterministic per-address code (not a secret - it's just an identifier). */
export function getReferralCode(address: string): string {
  const clean = address.replace(/^0x/i, '').toUpperCase();
  return `PAXI-${clean.slice(-8)}`;
}

export function getReferralLink(address: string, baseUrl?: string): string {
  const path = `/r/${encodeURIComponent(getReferralCode(address))}`;
  const origin = baseUrl?.trim() || (typeof window !== "undefined" ? window.location.origin : "");
  if (!origin) return path;
  try {
    const parsed = new URL(origin);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return path;
    return new URL(path, parsed.origin).toString();
  } catch {
    return path;
  }
}
