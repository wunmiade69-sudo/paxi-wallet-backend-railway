import { Contract, JsonRpcProvider, formatUnits } from 'ethers';
import { NETWORKS } from './chains';
import { walletFromMnemonic } from './engine';

const ERC20_APPROVAL_ABI = [
  'function approve(address spender, uint256 amount) returns (bool)',
];

export interface ApprovalRevokeEstimate {
  networkFeeNative: string;
}

export async function estimateApprovalRevoke(params: {
  network: string;
  owner: string;
  tokenAddress: string;
  spender: string;
}): Promise<ApprovalRevokeEstimate | null> {
  const network = NETWORKS[params.network];
  if (!network?.rpcUrl || network.chainType !== 'evm') return null;
  try {
    const provider = new JsonRpcProvider(network.rpcUrl);
    const contract = new Contract(params.tokenAddress, ERC20_APPROVAL_ABI, provider);
    const [feeData, gasLimit] = await Promise.all([
      provider.getFeeData(),
      contract.approve.estimateGas(params.spender, 0n, { from: params.owner }),
    ]);
    const gasPrice = feeData.maxFeePerGas ?? feeData.gasPrice ?? 0n;
    return { networkFeeNative: formatUnits(gasLimit * gasPrice, 18) };
  } catch {
    return null;
  }
}

export async function revokeErc20Approval(params: {
  mnemonic: string;
  network: string;
  tokenAddress: string;
  spender: string;
}): Promise<{ hash: string; explorerUrl?: string }> {
  const network = NETWORKS[params.network];
  if (!network || network.chainType !== 'evm') throw new Error('Approval revocation is only available on EVM networks.');
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);
  const contract = new Contract(params.tokenAddress, ERC20_APPROVAL_ABI, signer);
  const tx = await contract.approve(params.spender, 0n);
  return { hash: tx.hash, explorerUrl: network.explorerTx?.(tx.hash) };
}
