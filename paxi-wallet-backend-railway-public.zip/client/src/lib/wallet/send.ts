/**
 * Real transaction signing + broadcast for EVM-family assets, using the
 * wallet's own private key (derived on-the-fly from the unlocked mnemonic,
 * never persisted) and a public RPC endpoint. This sends an actual
 * on-chain transaction - there is no test/sandbox mode here, so amount and
 * recipient should always be double-checked, exactly like any real wallet.
 *
 * sendSolanaAsset below is the same idea for SOL/SPL token transfers.
 * Bitcoin sending is implemented in bitcoin.ts with its own UTXO-based transaction
 * builder and broadcast path; it intentionally remains separate from account-based sends.
 */
import { Contract, JsonRpcProvider, formatUnits, parseUnits } from 'ethers';
import { NETWORKS, type AssetConfig } from './chains';
import { walletFromMnemonic, deriveSolanaKeypair } from './engine';
import { getDefaultConfirmationDepth } from '@shared/confirmationPolicy';
import { parseExactBaseUnits } from './decimalParsing';

export class TransactionConfirmationUnknownError extends Error {
  readonly status = 'unknown' as const;
  constructor(message: string) {
    super(message);
    this.name = 'TransactionConfirmationUnknownError';
  }
}

const ERC20_TRANSFER_ABI = ['function transfer(address to, uint256 amount) returns (bool)'];

export async function waitForEvmConfirmation(params: {
  network: string;
  hash: string;
  timeoutMs?: number;
}): Promise<{ networkFeeNative: string }> {
  const network = NETWORKS[params.network];
  if (!network?.rpcUrl) throw new Error(`${params.network} RPC is not configured yet`);
  const provider = new JsonRpcProvider(network.rpcUrl);
  const confirmations = getDefaultConfirmationDepth(params.network);
  const receipt = await provider.waitForTransaction(params.hash, confirmations, params.timeoutMs ?? 180_000);
  if (!receipt) throw new TransactionConfirmationUnknownError(`Transaction status is unknown: the broadcast may have succeeded, but the required ${confirmations} confirmations were not reached before timeout. Retry status verification without sending again.`);
  if (receipt.status !== 1) throw new Error('Transaction failed on-chain');
  const gasPrice = receipt.gasPrice ?? 0n;
  return { networkFeeNative: formatUnits(receipt.gasUsed * gasPrice, 18) };
}

export async function estimateEvmAssetTransferGasFee(params: {
  network: string;
  fromAddress: string;
  asset: AssetConfig;
  toAddress: string;
  amount: string;
}): Promise<{ estimatedFeeNative: string } | null> {
  const network = NETWORKS[params.network];
  if (!network?.rpcUrl) return null;
  try {
    const provider = new JsonRpcProvider(network.rpcUrl);
    if (params.asset.isNative) {
      const [feeData, gasLimit] = await Promise.all([
        provider.getFeeData(),
        provider.estimateGas({ from: params.fromAddress, to: params.toAddress, value: parseUnits(params.amount, 18) }),
      ]);
      const gasPrice = feeData.maxFeePerGas ?? feeData.gasPrice ?? 0n;
      return { estimatedFeeNative: formatUnits(gasLimit * gasPrice, 18) };
    }
    if (!params.asset.contractAddress) throw new Error('Asset is missing a contract address');
    const contract = new Contract(params.asset.contractAddress, ERC20_TRANSFER_ABI, provider);
    const [feeData, gasLimit] = await Promise.all([
      provider.getFeeData(),
      contract.transfer.estimateGas(params.toAddress, parseUnits(params.amount, params.asset.decimals), { from: params.fromAddress }),
    ]);
    const gasPrice = feeData.maxFeePerGas ?? feeData.gasPrice ?? 0n;
    return { estimatedFeeNative: formatUnits(gasLimit * gasPrice, 18) };
  } catch (err) {
    console.warn('Asset transfer gas estimate failed:', err);
    return null;
  }
}

export async function sendEvmAsset(params: {
  mnemonic: string;
  asset: AssetConfig;
  toAddress: string;
  amount: string; // human units, e.g. "0.5"
}): Promise<{ hash: string; explorerUrl?: string }> {
  const { asset } = params;
  const network = NETWORKS[asset.network];
  if (network.chainType !== 'evm') throw new Error(`${asset.symbol} sending is not yet supported`);
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);
  let amountUnits: bigint;
  try {
    amountUnits = parseUnits(params.amount, asset.decimals);
  } catch {
    throw new Error('Amount must be a valid decimal supported by the asset.');
  }
  if (amountUnits <= 0n) throw new Error('Amount must be greater than zero');

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);

  let tx;
  if (asset.isNative) {
    tx = await signer.sendTransaction({ to: params.toAddress, value: amountUnits });
  } else if (asset.contractAddress) {
    const contract = new Contract(asset.contractAddress, ERC20_TRANSFER_ABI, signer);
    tx = await contract.transfer(params.toAddress, amountUnits);
  } else {
    throw new Error('Asset is missing a contract address');
  }

  return { hash: tx.hash, explorerUrl: network.explorerTx?.(tx.hash) };
}

export async function sendSolanaAsset(params: {
  mnemonic: string;
  asset: AssetConfig;
  toAddress: string;
  amount: string; // human units, e.g. "0.5"
}): Promise<{ hash: string; explorerUrl?: string }> {
  const { asset } = params;
  const network = NETWORKS[asset.network];
  if (network.chainType !== 'sol') throw new Error(`${asset.symbol} sending is not supported on Solana send path`);
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);

  const {
    Connection,
    PublicKey,
    SystemProgram,
    Transaction,
    sendAndConfirmTransaction,
  } = await import('@solana/web3.js');

  const connection = new Connection(network.rpcUrl, 'confirmed');
  const keypair = deriveSolanaKeypair(params.mnemonic);
  const toPubkey = new PublicKey(params.toAddress);

  let signature: string;

  if (asset.isNative) {
    // SOL always has 9 decimals (1 SOL = 1e9 lamports). Parsed exactly from the
    // decimal string as a bigint - never scaled through a float. @solana/web3.js
    // v1.95's SystemProgram.transfer accepts `lamports` as number | bigint, so
    // the exact bigint is passed straight through with no intermediate Number().
    const lamports = parseExactBaseUnits(params.amount, 9);
    const balance = await connection.getBalance(keypair.publicKey);
    if (lamports > BigInt(balance)) throw new Error('Insufficient SOL balance');
    const tx = new Transaction().add(
      SystemProgram.transfer({ fromPubkey: keypair.publicKey, toPubkey, lamports }),
    );
    signature = await sendAndConfirmTransaction(connection, tx, [keypair]);
  } else if (asset.contractAddress) {
    const {
      getOrCreateAssociatedTokenAccountSafe,
      createTransferCheckedInstructionSafe,
      getMintSafe,
    } = await import('./solanaSplSafe');

    const mint = new PublicKey(asset.contractAddress);
    const mintInfo = await getMintSafe(connection, mint);

    const fromAta = await getOrCreateAssociatedTokenAccountSafe(connection, keypair, mint, keypair.publicKey);
    const toAta = await getOrCreateAssociatedTokenAccountSafe(connection, keypair, mint, toPubkey);

    const amountUnits = parseExactBaseUnits(params.amount, mintInfo.decimals);
    if (amountUnits > fromAta.amount) throw new Error(`Insufficient ${asset.symbol} balance`);
    const tx = new Transaction().add(
      createTransferCheckedInstructionSafe(
        fromAta.address,
        mint,
        toAta.address,
        keypair.publicKey,
        amountUnits,
        mintInfo.decimals,
      ),
    );
    signature = await sendAndConfirmTransaction(connection, tx, [keypair]);
  } else {
    throw new Error('Asset is missing a contract (mint) address');
  }

  return { hash: signature, explorerUrl: network.explorerTx?.(signature) };
}
