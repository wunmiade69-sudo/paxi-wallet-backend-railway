import { afterEach, describe, expect, it } from "vitest";
import { clearSendRecovery, loadLatestSendRecovery, loadSendRecovery, saveSendRecovery } from "./sendRecovery";

const storage = new Map<string, string>();
const originalLocalStorage = globalThis.localStorage;

function installStorage(): void {
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      setItem: (key: string, value: string) => storage.set(key, value),
      getItem: (key: string) => storage.get(key) ?? null,
      removeItem: (key: string) => storage.delete(key),
    },
  });
}

afterEach(() => {
  storage.clear();
  Object.defineProperty(globalThis, "localStorage", { configurable: true, value: originalLocalStorage });
});

describe("SEND recovery pointer", () => {
  it("finds a durable operation pointer before the form fields are reconstructed", () => {
    installStorage();
    saveSendRecovery({
      operationId: "op-reload",
      quoteId: "quote-reload",
      network: "ethereum",
      walletAddress: "0xAbC",
      recipient: "0xDef",
      assetAddress: null,
      assetSymbol: "ETH",
      amount: "2",
      feeTransactionHash: null,
      transactionHash: null,
    });

    expect(loadLatestSendRecovery({ network: "ethereum", walletAddress: "0xabc" })?.operationId).toBe("op-reload");
    expect(loadSendRecovery({ network: "ethereum", walletAddress: "0xabc", recipient: "0xdef", assetSymbol: "ETH", amount: "2" })?.operationId).toBe("op-reload");
  });

  it("does not expose a pointer belonging to another wallet or network", () => {
    installStorage();
    saveSendRecovery({
      operationId: "op-owned",
      quoteId: "quote-owned",
      network: "ethereum",
      walletAddress: "0xAbC",
      recipient: "0xDef",
      assetAddress: null,
      assetSymbol: "ETH",
      amount: "2",
      feeTransactionHash: null,
      transactionHash: null,
    });

    expect(loadLatestSendRecovery({ network: "bsc", walletAddress: "0xabc" })).toBeNull();
    expect(loadLatestSendRecovery({ network: "ethereum", walletAddress: "0x999" })).toBeNull();
  });

  it("ignores malformed local data and clears it explicitly", () => {
    installStorage();
    storage.set("paxi.send.recovery.v1", JSON.stringify({ operationId: "op-only" }));
    expect(loadLatestSendRecovery({ network: "ethereum", walletAddress: "0xabc" })).toBeNull();
    clearSendRecovery();
    expect(storage.size).toBe(0);
  });
});
