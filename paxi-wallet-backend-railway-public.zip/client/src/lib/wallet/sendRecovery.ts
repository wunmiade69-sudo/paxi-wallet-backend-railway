export interface SendRecoveryRecord {
  operationId: string;
  quoteId: string;
  network: string;
  walletAddress: string;
  recipient: string;
  assetAddress: string | null;
  assetSymbol: string;
  amount: string;
  feeTransactionHash: string | null;
  transactionHash: string | null;
  updatedAt: number;
}

const STORAGE_KEY = "paxi.send.recovery.v1";
const MAX_RECOVERY_AGE_MS = 24 * 60 * 60 * 1000;

function isRecoveryRecord(value: unknown): value is SendRecoveryRecord {
  if (!value || typeof value !== "object") return false;
  const record = value as Partial<SendRecoveryRecord>;
  return typeof record.operationId === "string" && record.operationId.length > 0 && record.operationId.length <= 128
    && typeof record.quoteId === "string" && record.quoteId.length > 0 && record.quoteId.length <= 128
    && typeof record.network === "string" && record.network.length > 0
    && typeof record.walletAddress === "string" && record.walletAddress.length > 0
    && typeof record.recipient === "string" && record.recipient.length > 0
    && (record.assetAddress === null || typeof record.assetAddress === "string")
    && typeof record.assetSymbol === "string" && record.assetSymbol.length > 0
    && typeof record.amount === "string" && record.amount.length > 0
    && (record.feeTransactionHash === null || typeof record.feeTransactionHash === "string")
    && (record.transactionHash === null || typeof record.transactionHash === "string")
    && typeof record.updatedAt === "number" && Number.isFinite(record.updatedAt);
}

function readRecovery(): SendRecoveryRecord | null {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null");
    if (!isRecoveryRecord(parsed) || Date.now() - parsed.updatedAt > MAX_RECOVERY_AGE_MS) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveSendRecovery(record: Omit<SendRecoveryRecord, "updatedAt">): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...record, updatedAt: Date.now() }));
  } catch {
    /* storage is best-effort; the durable server operation remains authoritative */
  }
}

export function loadSendRecovery(match: Pick<SendRecoveryRecord, "network" | "walletAddress" | "recipient" | "assetSymbol" | "amount">): SendRecoveryRecord | null {
  const value = readRecovery();
  if (!value) return null;
  if (value.network !== match.network
    || value.walletAddress.toLowerCase() !== match.walletAddress.toLowerCase()
    || value.recipient.toLowerCase() !== match.recipient.toLowerCase()
    || value.assetSymbol !== match.assetSymbol
    || value.amount !== match.amount) return null;
  return value;
}

/**
 * Returns the recovery pointer for the active wallet/network even when a reload
 * occurred before the form fields were reconstructed. The server operation must
 * still be fetched and authorized before any transaction action is taken.
 */
export function loadLatestSendRecovery(match: Pick<SendRecoveryRecord, "network" | "walletAddress">): SendRecoveryRecord | null {
  const value = readRecovery();
  if (!value) return null;
  if (value.network !== match.network || value.walletAddress.toLowerCase() !== match.walletAddress.toLowerCase()) return null;
  return value;
}

export function clearSendRecovery(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* storage is best-effort */
  }
}
