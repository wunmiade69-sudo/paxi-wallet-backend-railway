import { describe, expect, it } from "vitest";
import { formatSlippageBps, normalizeSlippageBps } from "./slippage";

describe("slippage policy", () => {
  it("accepts integer values within the safe bounds", () => {
    expect(normalizeSlippageBps("50")).toBe(50);
    expect(normalizeSlippageBps(500)).toBe(500);
  });

  it("rejects malformed and dangerous values", () => {
    expect(normalizeSlippageBps("0")).toBeNull();
    expect(normalizeSlippageBps("5")).toBeNull();
    expect(normalizeSlippageBps("501")).toBeNull();
    expect(normalizeSlippageBps("1.5")).toBeNull();
    expect(normalizeSlippageBps("abc")).toBeNull();
  });

  it("formats basis points as a user-facing percentage", () => {
    expect(formatSlippageBps(50)).toBe("0.50%");
    expect(formatSlippageBps(500)).toBe("5.00%");
  });
});
