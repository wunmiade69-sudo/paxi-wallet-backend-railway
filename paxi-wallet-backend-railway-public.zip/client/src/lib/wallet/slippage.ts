export const SLIPPAGE_PRESETS_BPS = [50, 100, 200] as const;
export const MIN_SLIPPAGE_BPS = 10;
export const MAX_SLIPPAGE_BPS = 500;

export function normalizeSlippageBps(value: string | number): number | null {
  const bps = typeof value === "number" ? value : Number(value);
  if (
    !Number.isInteger(bps) ||
    bps < MIN_SLIPPAGE_BPS ||
    bps > MAX_SLIPPAGE_BPS
  )
    return null;
  return bps;
}

export function formatSlippageBps(bps: number): string {
  return `${(bps / 100).toFixed(2)}%`;
}
