import { describe, expect, it } from 'vitest';
import { PublicKey } from '@solana/web3.js';
import {
  MINT_ACCOUNT_SIZE,
  TOKEN_ACCOUNT_SIZE,
  TOKEN_PROGRAM_ID,
  createTransferCheckedInstructionSafe,
  parseMintAccount,
  parseTokenAccount,
} from './solanaSplSafe';

function writeU64LE(value: bigint, data: Uint8Array, offset: number): void {
  let remaining = value;
  for (let index = offset; index < offset + 8; index += 1) {
    data[index] = Number(remaining & 0xffn);
    remaining >>= 8n;
  }
}

function makeMintData(): Buffer {
  const data = Buffer.alloc(MINT_ACCOUNT_SIZE);
  writeU64LE(123_456_789n, data, 36);
  data[44] = 6;
  data[45] = 1;
  return data;
}

function makeTokenAccountData(mint: PublicKey, owner: PublicKey): Buffer {
  const data = Buffer.alloc(TOKEN_ACCOUNT_SIZE);
  mint.toBuffer().copy(data, 0);
  owner.toBuffer().copy(data, 32);
  writeU64LE(987_654_321n, data, 64);
  data[108] = 1;
  data[109] = 0;
  return data;
}

describe('safe classic SPL-token compatibility boundary', () => {
  const mint = new PublicKey('So11111111111111111111111111111111111111112');
  const owner = new PublicKey('11111111111111111111111111111111');
  const accountAddress = new PublicKey('SysvarRent111111111111111111111111111111111');

  it('parses valid fixed-width mint data with native BigInt arithmetic', () => {
    const parsed = parseMintAccount(mint, {
      executable: false,
      owner: TOKEN_PROGRAM_ID,
      lamports: 1,
      data: makeMintData(),
    });

    expect(parsed.address.equals(mint)).toBe(true);
    expect(parsed.supply).toBe(123_456_789n);
    expect(parsed.decimals).toBe(6);
    expect(parsed.isInitialized).toBe(true);
  });

  it('parses valid fixed-width token-account data and preserves exact amount', () => {
    const parsed = parseTokenAccount(accountAddress, {
      executable: false,
      owner: TOKEN_PROGRAM_ID,
      lamports: 1,
      data: makeTokenAccountData(mint, owner),
    });

    expect(parsed.mint.equals(mint)).toBe(true);
    expect(parsed.owner.equals(owner)).toBe(true);
    expect(parsed.amount).toBe(987_654_321n);
    expect(parsed.isInitialized).toBe(true);
    expect(parsed.isFrozen).toBe(false);
  });

  it.each([
    ['missing account', null],
    ['truncated mint', { executable: false, owner: TOKEN_PROGRAM_ID, lamports: 1, data: Buffer.alloc(MINT_ACCOUNT_SIZE - 1) }],
    ['oversized mint', { executable: false, owner: TOKEN_PROGRAM_ID, lamports: 1, data: Buffer.alloc(MINT_ACCOUNT_SIZE + 1) }],
    ['wrong mint owner', { executable: false, owner, lamports: 1, data: makeMintData() }],
  ])('rejects %s without producing financial state', (_label, info) => {
    expect(() => parseMintAccount(mint, info as never)).toThrow();
  });

  it.each([
    ['missing account', null],
    ['truncated token account', { executable: false, owner: TOKEN_PROGRAM_ID, lamports: 1, data: Buffer.alloc(TOKEN_ACCOUNT_SIZE - 1) }],
    ['oversized token account', { executable: false, owner: TOKEN_PROGRAM_ID, lamports: 1, data: Buffer.alloc(TOKEN_ACCOUNT_SIZE + 1) }],
    ['wrong token owner', { executable: false, owner, lamports: 1, data: makeTokenAccountData(mint, owner) }],
  ])('rejects %s before token interpretation', (_label, info) => {
    expect(() => parseTokenAccount(accountAddress, info as never)).toThrow();
  });

  it('rejects an invalid token-account state instead of constructing a transaction', () => {
    const data = makeTokenAccountData(mint, owner);
    data[108] = 3;
    expect(() => parseTokenAccount(accountAddress, {
      executable: false,
      owner: TOKEN_PROGRAM_ID,
      lamports: 1,
      data,
    })).toThrow('invalid state');
  });

  it.each([
    ['invalid mint-authority option', 0, 2],
    ['uninitialized mint state', 45, 0],
    ['invalid freeze-authority option', 46, 2],
  ])('rejects %s before reading supply', (_label, offset, value) => {
    const data = makeMintData();
    data[offset] = value;
    expect(() => parseMintAccount(mint, {
      executable: false,
      owner: TOKEN_PROGRAM_ID,
      lamports: 1,
      data,
    })).toThrow();
  });

  it('rejects amounts outside uint64 and invalid decimals before instruction construction', () => {
    expect(() => createTransferCheckedInstructionSafe(
      owner,
      mint,
      accountAddress,
      owner,
      0x1_0000_0000_0000_0000n,
      6,
    )).toThrow('uint64');
    expect(() => createTransferCheckedInstructionSafe(owner, mint, accountAddress, owner, 1n, 256)).toThrow('uint8');
  });
});
