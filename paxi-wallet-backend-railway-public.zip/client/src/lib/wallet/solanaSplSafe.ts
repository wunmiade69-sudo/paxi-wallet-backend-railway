import {
  Connection,
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
  TransactionInstruction,
  sendAndConfirmTransaction,
  type AccountInfo,
} from '@solana/web3.js';

/**
 * PAXI's current Solana wallet paths use the classic SPL Token program.
 * This module intentionally handles only the fixed-width classic mint and
 * token-account layouts used by those paths. It does not attempt to decode
 * arbitrary provider bytes or Token-2022 extension data.
 *
 * The parser reads only the documented fixed-width fields with explicit bounds
 * checks and native BigInt arithmetic. It does not import @solana/spl-token,
 * @solana/buffer-layout-utils, or bigint-buffer.
 */
export const TOKEN_PROGRAM_ID = new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
export const ASSOCIATED_TOKEN_PROGRAM_ID = new PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');

export const MINT_ACCOUNT_SIZE = 82;
export const TOKEN_ACCOUNT_SIZE = 165;

export interface SafeMint {
  address: PublicKey;
  supply: bigint;
  decimals: number;
  isInitialized: boolean;
}

export interface SafeTokenAccount {
  address: PublicKey;
  mint: PublicKey;
  owner: PublicKey;
  amount: bigint;
  isInitialized: boolean;
  isFrozen: boolean;
  isNative: boolean;
}

function assertFixedWidthData(info: AccountInfo<Buffer> | null, expectedSize: number, label: string): Buffer {
  if (!info) throw new Error(`${label} account was not found`);
  if (!info.owner.equals(TOKEN_PROGRAM_ID)) throw new Error(`${label} account has an unexpected owner`);
  if (info.data.length < expectedSize) throw new Error(`${label} account data is truncated`);
  if (info.data.length > expectedSize) throw new Error(`${label} account data is unexpectedly oversized`);
  return info.data;
}

function readU64LE(data: Uint8Array, offset: number): bigint {
  if (offset < 0 || offset + 8 > data.length) throw new Error('SPL integer field is out of bounds');
  let value = 0n;
  for (let index = offset + 7; index >= offset; index -= 1) {
    value = (value << 8n) | BigInt(data[index]!);
  }
  return value;
}

function writeU64LE(value: bigint, data: Uint8Array, offset: number): void {
  if (value < 0n || value > 0xffffffffffffffffn) throw new Error('SPL amount is outside the uint64 range');
  if (offset < 0 || offset + 8 > data.length) throw new Error('SPL integer field is out of bounds');
  let remaining = value;
  for (let index = offset; index < offset + 8; index += 1) {
    data[index] = Number(remaining & 0xffn);
    remaining >>= 8n;
  }
}

export function parseMintAccount(
  address: PublicKey,
  info: AccountInfo<Buffer> | null,
): SafeMint {
  const data = assertFixedWidthData(info, MINT_ACCOUNT_SIZE, 'Mint');
  const mintAuthorityOption = data[0]!;
  const isInitialized = data[45]!;
  const freezeAuthorityOption = data[46]!;
  if (mintAuthorityOption > 1 || freezeAuthorityOption > 1) {
    throw new Error('Mint account has invalid authority option');
  }
  if (isInitialized !== 1) throw new Error('Mint account is not initialized');
  return {
    address,
    // MintLayout: option(0..3), authority(4..35), supply(36..43), decimals(44).
    supply: readU64LE(data, 36),
    decimals: data[44]!,
    isInitialized: true,
  };
}

export function parseTokenAccount(
  address: PublicKey,
  info: AccountInfo<Buffer> | null,
): SafeTokenAccount {
  const data = assertFixedWidthData(info, TOKEN_ACCOUNT_SIZE, 'Token');
  const state = data[108]!;
  const isNativeOption = data[109]!;
  if (state > 2) throw new Error('Token account has an invalid state');
  if (isNativeOption > 1) throw new Error('Token account has an invalid native option');
  return {
    address,
    // AccountLayout: mint(0..31), owner(32..63), amount(64..71).
    mint: new PublicKey(data.subarray(0, 32)),
    owner: new PublicKey(data.subarray(32, 64)),
    amount: readU64LE(data, 64),
    isInitialized: state !== 0,
    isFrozen: state === 2,
    isNative: isNativeOption !== 0,
  };
}

export async function getMintSafe(connection: Connection, address: PublicKey): Promise<SafeMint> {
  return parseMintAccount(address, await connection.getAccountInfo(address, 'confirmed'));
}

export async function getTokenAccountSafe(connection: Connection, address: PublicKey): Promise<SafeTokenAccount> {
  return parseTokenAccount(address, await connection.getAccountInfo(address, 'confirmed'));
}

export function getAssociatedTokenAddressSafe(mint: PublicKey, owner: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [owner.toBuffer(), TOKEN_PROGRAM_ID.toBuffer(), mint.toBuffer()],
    ASSOCIATED_TOKEN_PROGRAM_ID,
  )[0];
}

function createAssociatedTokenAccountInstruction(
  payer: PublicKey,
  associatedToken: PublicKey,
  owner: PublicKey,
  mint: PublicKey,
): TransactionInstruction {
  return new TransactionInstruction({
    programId: ASSOCIATED_TOKEN_PROGRAM_ID,
    keys: [
      { pubkey: payer, isSigner: true, isWritable: true },
      { pubkey: associatedToken, isSigner: false, isWritable: true },
      { pubkey: owner, isSigner: false, isWritable: false },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    ],
    // Associated Token Program instruction 1: CreateIdempotent.
    data: Buffer.from([1]),
  });
}

export async function getOrCreateAssociatedTokenAccountSafe(
  connection: Connection,
  payer: Keypair,
  mint: PublicKey,
  owner: PublicKey,
): Promise<SafeTokenAccount> {
  const address = getAssociatedTokenAddressSafe(mint, owner);
  const existing = await connection.getAccountInfo(address, 'confirmed');
  if (existing) {
    const account = parseTokenAccount(address, existing);
    if (!account.mint.equals(mint) || !account.owner.equals(owner)) {
      throw new Error('Associated token account has unexpected mint or owner');
    }
    return account;
  }

  const transaction = new Transaction().add(
    createAssociatedTokenAccountInstruction(payer.publicKey, address, owner, mint),
  );
  try {
    await sendAndConfirmTransaction(connection, transaction, [payer]);
  } catch (error) {
    // Preserve a real error unless the idempotent instruction raced and the
    // account now exists and validates.
    const raced = await connection.getAccountInfo(address, 'confirmed');
    if (!raced) throw error;
  }

  const created = parseTokenAccount(address, await connection.getAccountInfo(address, 'confirmed'));
  if (!created.mint.equals(mint) || !created.owner.equals(owner)) {
    throw new Error('Created associated token account has unexpected mint or owner');
  }
  return created;
}

export function createTransferCheckedInstructionSafe(
  source: PublicKey,
  mint: PublicKey,
  destination: PublicKey,
  owner: PublicKey,
  amount: bigint,
  decimals: number,
): TransactionInstruction {
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 255) {
    throw new Error('SPL decimals are outside the uint8 range');
  }
  const data = Buffer.alloc(10);
  data[0] = 12; // TokenInstruction.TransferChecked
  writeU64LE(amount, data, 1);
  data[9] = decimals;
  return new TransactionInstruction({
    programId: TOKEN_PROGRAM_ID,
    keys: [
      { pubkey: source, isSigner: false, isWritable: true },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: destination, isSigner: false, isWritable: true },
      { pubkey: owner, isSigner: true, isWritable: false },
    ],
    data,
  });
}
