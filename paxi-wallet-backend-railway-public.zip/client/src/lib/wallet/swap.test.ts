import { describe, expect, it } from "vitest";
import {
  classifySimulationError,
  isSwapQuoteFresh,
  normalizeWalletFeeAddress,
  statusFromReceiptStatus,
  validateSwapSpender,
  SWAP_QUOTE_TTL_MS,
} from "./swap";

describe("swap fee destination configuration", () => {
  it("fails closed for missing and malformed addresses", () => {
    expect(normalizeWalletFeeAddress(undefined)).toBe("");
    expect(normalizeWalletFeeAddress(" ")).toBe("");
    expect(normalizeWalletFeeAddress("not-an-address")).toBe("");
  });

  it("normalizes a valid public treasury address", () => {
    expect(
      normalizeWalletFeeAddress("0x0000000000000000000000000000000000000001")
    ).toBe("0x0000000000000000000000000000000000000001");
  });
});

describe("swap execution safety", () => {
  it("rejects expired or future-dated quotes", () => {
    const now = 1_000_000;
    expect(
      isSwapQuoteFresh({ quoteFetchedAt: now - SWAP_QUOTE_TTL_MS }, now)
    ).toBe(true);
    expect(
      isSwapQuoteFresh({ quoteFetchedAt: now - SWAP_QUOTE_TTL_MS - 1 }, now)
    ).toBe(false);
    expect(isSwapQuoteFresh({ quoteFetchedAt: now + 1 }, now)).toBe(false);
  });

  it("validates approval targets and never accepts arbitrary text", () => {
    expect(
      validateSwapSpender("0x0000000000000000000000000000000000000001")
    ).toBe("0x0000000000000000000000000000000000000001");
    expect(() => validateSwapSpender("router.example")).toThrow(
      "approval target"
    );
  });

  it("distinguishes simulation failure from unavailable simulation", () => {
    expect(
      classifySimulationError(new Error("execution reverted: balance"))
    ).toBe("failed");
    expect(classifySimulationError(new Error("method not found"))).toBe(
      "unavailable"
    );
  });

  it("does not call a reverted receipt confirmed", () => {
    expect(statusFromReceiptStatus(1)).toBe("confirmed");
    expect(statusFromReceiptStatus(0)).toBe("reverted");
    expect(statusFromReceiptStatus(null)).toBe("reverted");
  });
});
