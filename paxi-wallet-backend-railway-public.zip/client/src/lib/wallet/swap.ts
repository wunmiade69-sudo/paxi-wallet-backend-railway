/**
 * Swap engine - real on-chain token swaps via the Velora (formerly ParaSwap)
 * aggregator API. No API key required, same "public no-key endpoint"
 * pattern as prices/balances.ts.
 *
 * "Multiple swap" here means multi-source aggregation: a single quote
 * request is routed by Velora's Hopper algorithm across 300+ liquidity
 * sources (Uniswap, PancakeSwap, Balancer, Curve, and more), splitting
 * one trade across several pools/DEXs when that gives a better price -
 * not something this wallet has to pick a single DEX for.
 *
 * The wallet's own fee is applied via the aggregator's built-in partner
 * fee mechanism (`partnerAddress` + `partnerFeeBps`): it's collected
 * on-chain, inside the same swap transaction, sent straight to the
 * wallet's fee address - no separate transfer, no extra gas.
 *
 * EVM only (Ethereum, BNB Smart Chain), matching the rest of this wallet.
 */
import {
  Contract,
  JsonRpcProvider,
  formatUnits,
  getAddress,
  isAddress,
  parseUnits,
} from "ethers";
import { NETWORKS, type AssetConfig } from "./chains";
import { walletFromMnemonic } from "./engine";
import type { TxStatus } from "./txHistory";

export const NATIVE_TOKEN_ADDRESS =
  "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";

/** The wallet's own swap fee - taken on-chain by the aggregator, in the same tx as the swap. */
export const WALLET_FEE_BPS = 30; // 0.3%
export const SWAP_QUOTE_TTL_MS = 30_000;
export function normalizeWalletFeeAddress(value: string | undefined): string {
  const trimmed = value?.trim() ?? "";
  return isAddress(trimmed) ? getAddress(trimmed) : "";
}

const configuredWalletFeeAddress = import.meta.env
  .VITE_PAXI_TREASURY_ADDRESS as string | undefined;
export const WALLET_FEE_ADDRESS = normalizeWalletFeeAddress(
  configuredWalletFeeAddress
);
const PARTNER_NAME = "paxiwallet";

const API_BASE = "https://api.paraswap.io";
const ERC20_ABI = [
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
];

function tokenAddressFor(asset: AssetConfig): string {
  return asset.isNative ? NATIVE_TOKEN_ADDRESS : asset.contractAddress!;
}

/**
 * Velora's priceRoute nests the individual DEXs used (e.g. "UniswapV3",
 * "PancakeSwapV2") at varying depths depending on how the trade was split.
 * Rather than hardcode a schema that can shift between versions, walk the
 * whole object and collect every `exchange` field - this is what actually
 * shows the user PancakeSwap/Sushiswap/etc. were used, instead of just
 * asserting "we use many DEXs" with nothing to back it up.
 */
function extractRouteNames(
  node: unknown,
  acc: Set<string> = new Set()
): string[] {
  if (!node || typeof node !== "object") return [...acc];
  for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
    if (key === "exchange" && typeof value === "string") acc.add(value);
    else if (Array.isArray(value))
      value.forEach(v => extractRouteNames(v, acc));
    else if (value && typeof value === "object") extractRouteNames(value, acc);
  }
  return [...acc];
}

/** Only EVM assets on the same network can be swapped against each other. */
export function isSwappable(asset: AssetConfig): boolean {
  return NETWORKS[asset.network]?.chainType === "evm";
}

export interface SwapQuote {
  priceRoute: any; // opaque payload from Velora, passed back verbatim to /transactions
  srcAmountUnits: string; // base units (wei)
  destAmountUnits: string; // base units, before slippage tolerance
  destAmountFormatted: string; // human units
  destAmountMinFormatted: string; // after slippage tolerance - what you're guaranteed to receive
  rate: number; // 1 srcAsset = `rate` destAsset
  feeBps: number;
  /** Explicit fee state for routes where wallet-fee collection is disabled by configuration. */
  walletFeeStatus?: "configured" | "configuration_required" | "not_collected";
  feeAmountFormatted: string; // in srcAsset units, informational (fee is actually deducted from destAmount on-chain)
  tokenTransferProxy: string; // address to grant ERC-20 allowance to
  gasCostEstimate: string | null; // native units, if the API returns it
  routeNames: string[]; // e.g. ["UniswapV3", "PancakeSwapV2"] - which DEXs this quote was actually split across
  /** Time the quote was received; execution rejects missing or expired quotes. */
  quoteFetchedAt: number;
}

export type SwapSimulationStatus = "success" | "failed" | "unavailable";

export interface SwapSimulationResult {
  status: SwapSimulationStatus;
  reason?: string;
}

export function isSwapQuoteFresh(
  quote: Pick<SwapQuote, "quoteFetchedAt">,
  now = Date.now()
): boolean {
  return (
    Number.isFinite(quote.quoteFetchedAt) &&
    now - quote.quoteFetchedAt >= 0 &&
    now - quote.quoteFetchedAt <= SWAP_QUOTE_TTL_MS
  );
}

export function validateSwapSpender(spender: string): string {
  if (!isAddress(spender)) throw new Error("Swap approval target is invalid.");
  return getAddress(spender);
}

export function classifySimulationError(error: unknown): SwapSimulationStatus {
  const message =
    error instanceof Error
      ? error.message.toLowerCase()
      : String(error).toLowerCase();
  if (
    message.includes("execution reverted") ||
    message.includes("revert") ||
    message.includes("insufficient")
  )
    return "failed";
  if (
    message.includes("method not found") ||
    message.includes("unsupported") ||
    message.includes("timeout") ||
    message.includes("network")
  )
    return "unavailable";
  return "failed";
}

/** Get the best available swap rate, aggregated across many DEXs, with the wallet fee already reflected. */
export async function fetchSwapQuote(params: {
  networkId: string;
  srcAsset: AssetConfig;
  destAsset: AssetConfig;
  amount: string; // human units of srcAsset
  userAddress: string;
  slippageBps: number; // e.g. 100 = 1%
}): Promise<SwapQuote> {
  const { srcAsset, destAsset, userAddress, slippageBps } = params;
  if (!isAddress(userAddress))
    throw new Error("Swap wallet address is invalid.");
  if (
    !Number.isInteger(slippageBps) ||
    slippageBps < 0 ||
    slippageBps >= 10_000
  )
    throw new Error("Swap slippage is invalid.");
  if (srcAsset.network !== destAsset.network)
    throw new Error("Swap assets must be on the same network.");
  if (srcAsset.symbol === destAsset.symbol)
    throw new Error("Choose two different assets.");
  if (!WALLET_FEE_ADDRESS)
    throw new Error("Swap fee destination is not configured");
  const network = NETWORKS[params.networkId];
  if (!network || network.chainType !== "evm")
    throw new Error("Swaps are only supported on EVM networks right now.");
  if (!network.chainId)
    throw new Error(`${network.label} is missing a chain ID.`);

  const srcAmountUnits = parseUnits(
    params.amount,
    srcAsset.decimals
  ).toString();
  const qs = new URLSearchParams({
    srcToken: tokenAddressFor(srcAsset),
    destToken: tokenAddressFor(destAsset),
    srcDecimals: String(srcAsset.decimals),
    destDecimals: String(destAsset.decimals),
    amount: srcAmountUnits,
    side: "SELL",
    network: String(network.chainId),
    userAddress,
    partner: PARTNER_NAME,
  });

  const res = await fetch(`${API_BASE}/prices?${qs.toString()}`);
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(
      body?.error ||
        `Could not fetch a quote (${res.status}). Try a different amount or pair.`
    );
  }
  const data = await res.json();
  const priceRoute = data.priceRoute;
  if (!priceRoute) throw new Error("No route found for this pair.");
  if (!srcAsset.isNative && !isAddress(priceRoute.tokenTransferProxy ?? ""))
    throw new Error("Swap approval target is unavailable.");

  const destAmountUnits: string = priceRoute.destAmount;
  const destAmountFormatted = formatUnits(destAmountUnits, destAsset.decimals);
  const destAmountMin =
    (BigInt(destAmountUnits) * BigInt(10000 - slippageBps)) / 10000n;
  const destAmountMinFormatted = formatUnits(destAmountMin, destAsset.decimals);
  const rate = Number(destAmountFormatted) / Number(params.amount);
  const feeAmountFormatted = (
    (Number(params.amount) * WALLET_FEE_BPS) /
    10000
  ).toFixed(8);

  return {
    priceRoute,
    srcAmountUnits,
    destAmountUnits,
    destAmountFormatted,
    destAmountMinFormatted,
    rate,
    feeBps: WALLET_FEE_BPS,
    feeAmountFormatted,
    tokenTransferProxy: priceRoute.tokenTransferProxy,
    gasCostEstimate: priceRoute.gasCostUSD ?? null,
    routeNames: extractRouteNames(priceRoute),
    quoteFetchedAt: Date.now(),
  };
}

/** Current ERC-20 allowance the wallet has granted to the aggregator's transfer proxy. */
async function getAllowance(
  rpcUrl: string,
  tokenAddress: string,
  owner: string,
  spender: string
): Promise<bigint> {
  const provider = new JsonRpcProvider(rpcUrl);
  const contract = new Contract(tokenAddress, ERC20_ABI, provider);
  return contract.allowance(owner, spender);
}

export function statusFromReceiptStatus(
  receiptStatus: number | null | undefined
): TxStatus {
  return receiptStatus === 1 ? "confirmed" : "reverted";
}

export interface SwapResult {
  approvalHash?: string;
  swapHash: string;
  explorerUrl?: string;
  status?: TxStatus;
  finality?: "evm_receipt" | "solana_confirmed" | "solana_finalized";
  simulation?: SwapSimulationResult;
  approvalTarget?: string;
}

/**
 * Runs the full swap: approves the aggregator's transfer proxy for
 * ERC-20 source tokens if needed, builds the transaction (which bakes in
 * the wallet's partner fee), then signs and broadcasts. Real on-chain
 * transactions - no sandbox mode, same as send.ts.
 */
export async function executeSwap(params: {
  mnemonic: string;
  networkId: string;
  srcAsset: AssetConfig;
  destAsset: AssetConfig;
  quote: SwapQuote;
  slippageBps: number;
  userAddress: string;
  onStatus?: (status: "approving" | "simulating" | "swapping") => void;
  onSimulation?: (status: SwapSimulationStatus) => void;
}): Promise<SwapResult> {
  const { srcAsset, destAsset, quote, userAddress } = params;
  if (!isAddress(userAddress))
    throw new Error("Swap wallet address is invalid.");
  if (!isSwapQuoteFresh(quote))
    throw new Error(
      "This swap quote expired. Request a new quote before signing."
    );
  if (srcAsset.network !== destAsset.network)
    throw new Error("Swap assets must be on the same network.");
  if (!WALLET_FEE_ADDRESS)
    throw new Error("Swap fee destination is not configured");
  const network = NETWORKS[params.networkId];
  if (!network.rpcUrl)
    throw new Error(`${network.label} RPC is not configured yet`);

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);

  let approvalHash: string | undefined;
  let approvalTarget: string | undefined;
  let simulation: SwapSimulationResult = {
    status: "unavailable",
    reason: "Simulation has not run yet.",
  };
  if (!srcAsset.isNative) {
    const tokenAddress = srcAsset.contractAddress!;
    approvalTarget = validateSwapSpender(quote.tokenTransferProxy);
    const currentAllowance = await getAllowance(
      network.rpcUrl,
      tokenAddress,
      userAddress,
      approvalTarget
    );
    if (currentAllowance < BigInt(quote.srcAmountUnits)) {
      params.onStatus?.("approving");
      const erc20 = new Contract(tokenAddress, ERC20_ABI, signer);
      const approveTx = await erc20.approve(
        approvalTarget,
        BigInt(quote.srcAmountUnits)
      );
      await approveTx.wait();
      approvalHash = approveTx.hash;
    }
  }

  params.onStatus?.("swapping");
  const destAmountMin =
    (BigInt(quote.destAmountUnits) * BigInt(10000 - params.slippageBps)) /
    10000n;

  const txRes = await fetch(
    `${API_BASE}/transactions/${network.chainId}?ignoreChecks=true`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        srcToken: tokenAddressFor(srcAsset),
        destToken: tokenAddressFor(destAsset),
        srcAmount: quote.srcAmountUnits,
        destAmount: destAmountMin.toString(),
        priceRoute: quote.priceRoute,
        userAddress,
        partner: PARTNER_NAME,
        partnerAddress: WALLET_FEE_ADDRESS,
        partnerFeeBps: WALLET_FEE_BPS,
        // Without this, Velora deposits the fee into their own FeeClaimer
        // contract instead of sending it to partnerAddress - it would sit
        // there forever unless a separate claim transaction is made against
        // that contract. This makes the fee land directly, in the same tx.
        takeSurplus: true,
        isDirectFeeTransfer: true,
        srcDecimals: srcAsset.decimals,
        destDecimals: destAsset.decimals,
      }),
    }
  );

  if (!txRes.ok) {
    const body = await txRes.json().catch(() => null);
    throw new Error(
      body?.error || `Could not build the swap transaction (${txRes.status}).`
    );
  }
  const tx = await txRes.json();
  if (!isAddress(tx.to) || typeof tx.data !== "string")
    throw new Error("Swap transaction preview is invalid.");
  if (tx.chainId != null && Number(tx.chainId) !== network.chainId)
    throw new Error(
      "Swap transaction chain does not match the selected network."
    );

  const unsignedSwapTx = {
    to: getAddress(tx.to),
    data: tx.data,
    value: tx.value ? BigInt(tx.value) : 0n,
  };
  try {
    params.onStatus?.("simulating");
    await provider.call(unsignedSwapTx);
    simulation = { status: "success" };
    params.onSimulation?.("success");
  } catch (error) {
    simulation = {
      status: classifySimulationError(error),
      reason: error instanceof Error ? error.message : String(error),
    };
    params.onSimulation?.(simulation.status);
    if (simulation.status === "failed")
      throw new Error(
        "Swap simulation failed. Review the amount, route, and balance before signing."
      );
    console.warn(
      "[swap] simulation unavailable; continuing with explicit unavailable status"
    );
  }

  const swapTx = await signer.sendTransaction(unsignedSwapTx);

  // The transaction is broadcast before this point, but a successful `wait()`
  // gives the receipt screen the authoritative mined result immediately. If a
  // public RPC times out, keep the safe pending fallback and let the receipt
  // poller resolve it later rather than claiming success prematurely.
  let status: TxStatus = "pending";
  try {
    const receipt = await swapTx.wait();
    if (receipt) status = statusFromReceiptStatus(receipt.status);
  } catch (error) {
    console.warn(
      "Swap receipt wait failed; leaving status pending for polling:",
      error
    );
  }

  return {
    approvalHash,
    swapHash: swapTx.hash,
    explorerUrl: network.explorerTx?.(swapTx.hash),
    status,
    simulation,
    approvalTarget,
  };
}
