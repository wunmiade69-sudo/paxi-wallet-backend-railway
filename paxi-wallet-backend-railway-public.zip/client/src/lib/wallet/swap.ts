/**
 * Swap engine - real on-chain token swaps via the Velora (formerly ParaSwap)
 * aggregator API. No API key required, same "public no-key endpoint"
 * pattern as prices/balances.ts.
 *
 * "Multiple swap" here means multi-source aggregation: a single quote
 * request is routed by Velora's Hopper algorithm across 300+ liquidity
 * sources (Uniswap, PancakeSwap, Balancer, Curve, and more), splitting
 * one trade across several pools/DEXs when that gives a better price -
 * not something this wallet has to pick a single DEX for.
 *
 * The wallet's own fee is applied via the aggregator's built-in partner
 * fee mechanism (`partnerAddress` + `partnerFeeBps`): it's collected
 * on-chain, inside the same swap transaction, sent straight to the
 * wallet's fee address - no separate transfer, no extra gas.
 *
 * EVM only (Ethereum, BNB Smart Chain), matching the rest of this wallet.
 */
import { Contract, JsonRpcProvider, parseUnits } from 'ethers';
import { NETWORKS, type AssetConfig } from './chains';
import { walletFromMnemonic } from './engine';
import type { TxStatus } from './txHistory';
import { trpcVanilla } from '../trpcVanilla';

export const NATIVE_TOKEN_ADDRESS = '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';

/** The wallet's own swap fee - taken on-chain by the aggregator, in the same tx as the swap. */
export const WALLET_FEE_BPS = 30; // 0.3% fallback only for display compatibility; server config is authoritative.

const ERC20_ABI = [
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
];

function tokenAddressFor(asset: AssetConfig): string {
  return asset.isNative ? NATIVE_TOKEN_ADDRESS : asset.contractAddress!;
}

/**
 * Canonical wrapped-native addresses for the chains the direct Uniswap/
 * PancakeSwap on-chain quoters support. Those quoter contracts operate on
 * ERC20 pools only, so a native asset has to be represented by its wrapped
 * ERC20 form here - unlike Velora, which accepts NATIVE_TOKEN_ADDRESS
 * directly and does this substitution internally.
 */
const WRAPPED_NATIVE_ADDRESS: Record<string, string> = {
  ethereum: '0xC02aaA39b223FE8D0A0e5C4f27eAD9083C756Cc2',
  bsc: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  polygon: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270',
  arbitrum: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
};

/** Address to use when querying the direct DEX quoters (swap.directDexQuote) - wrapped, not the Velora native placeholder. */
export function directDexTokenAddressFor(networkId: string, asset: AssetConfig): string | null {
  if (!asset.isNative) return asset.contractAddress ?? null;
  return WRAPPED_NATIVE_ADDRESS[networkId] ?? null;
}

export function isDirectDexSupportedNetwork(networkId: string): boolean {
  return networkId in WRAPPED_NATIVE_ADDRESS;
}

/** Only EVM assets on the same network can be swapped against each other. */
export function isSwappable(asset: AssetConfig): boolean {
  return NETWORKS[asset.network]?.chainType === 'evm';
}

export interface SwapQuote {
  priceRoute: any; // opaque payload from Velora, passed back verbatim to /transactions
  srcAmountUnits: string; // base units (wei)
  destAmountUnits: string; // base units, before slippage tolerance
  destAmountFormatted: string; // human units
  destAmountMinFormatted: string; // after slippage tolerance - what you're guaranteed to receive
  rate: number; // 1 srcAsset = `rate` destAsset
  feeBps: number;
  feeAmountFormatted: string; // in srcAsset units, informational (fee is actually deducted from destAmount on-chain)
  feeAddress: string | null; // server-configured treasury used by the final transaction
  tokenTransferProxy: string; // address to grant ERC-20 allowance to
  gasCostEstimate: string | null; // native units, if the API returns it
  routeNames: string[]; // e.g. ["UniswapV3", "PancakeSwapV2"] - which DEXs this quote was actually split across
}

/** Get the best available swap rate, aggregated across many DEXs, with the wallet fee already reflected. */
export async function fetchSwapQuote(params: {
  networkId: string;
  srcAsset: AssetConfig;
  destAsset: AssetConfig;
  amount: string;
  userAddress: string;
  slippageBps: number;
  feeBps: number;
  feeAddress: string | null;
}): Promise<SwapQuote> {
  const network = NETWORKS[params.networkId];
  if (!network || network.chainType !== 'evm') throw new Error('Swaps are only supported on EVM networks right now.');
  const chainId = network.chainId;
  if (!chainId) throw new Error(`${network.label} is missing a chain ID.`);
  // Exact string->bigint conversion via ethers' own bigint-safe decimal
  // parser (the same one used for every EVM send in send.ts), rather than
  // scaling the human-entered amount through a float. parseUnits already
  // rejects malformed/over-precise input; a non-positive result is treated
  // the same as any other invalid amount.
  let srcAmountUnitsBigint: bigint;
  try {
    srcAmountUnitsBigint = parseUnits(params.amount, params.srcAsset.decimals);
  } catch {
    throw new Error('Enter a valid amount.');
  }
  if (srcAmountUnitsBigint <= 0n) throw new Error('Amount must be greater than zero');
  const srcAmountUnits = srcAmountUnitsBigint.toString();
  return trpcVanilla.swap.quote.query({
    networkId: params.networkId,
    chainId,
    srcToken: tokenAddressFor(params.srcAsset),
    destToken: tokenAddressFor(params.destAsset),
    srcDecimals: params.srcAsset.decimals,
    destDecimals: params.destAsset.decimals,
    amount: srcAmountUnits,
    userAddress: params.userAddress,
    slippageBps: params.slippageBps,
  });
}

/** Current ERC-20 allowance the wallet has granted to the aggregator's transfer proxy. */
async function getAllowance(rpcUrl: string, tokenAddress: string, owner: string, spender: string): Promise<bigint> {
  const provider = new JsonRpcProvider(rpcUrl);
  const contract = new Contract(tokenAddress, ERC20_ABI, provider);
  return contract.allowance(owner, spender);
}

export function statusFromReceiptStatus(receiptStatus: number | null | undefined): TxStatus {
  return receiptStatus === 1 ? 'confirmed' : 'failed';
}

export interface SwapResult {
  approvalHash?: string;
  swapHash: string;
  explorerUrl?: string;
  status?: TxStatus;
}

/**
 * Runs the full swap: approves the aggregator's transfer proxy for
 * ERC-20 source tokens if needed, builds the transaction (which bakes in
 * the wallet's partner fee), then signs and broadcasts. Real on-chain
 * transactions - no sandbox mode, same as send.ts.
 */
export async function executeSwap(params: {
  mnemonic: string;
  networkId: string;
  srcAsset: AssetConfig;
  destAsset: AssetConfig;
  quote: SwapQuote;
  slippageBps: number;
  userAddress: string;
  onStatus?: (status: 'approving' | 'swapping') => void;
}): Promise<SwapResult> {
  const { srcAsset, destAsset, quote, userAddress } = params;
  const network = NETWORKS[params.networkId];
  const chainId = network.chainId;
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);
  if (!chainId) throw new Error(`${network.label} is missing a chain ID.`);

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);

  let approvalHash: string | undefined;
  if (!srcAsset.isNative) {
    const tokenAddress = srcAsset.contractAddress!;
    const currentAllowance = await getAllowance(network.rpcUrl, tokenAddress, userAddress, quote.tokenTransferProxy);
    if (currentAllowance < BigInt(quote.srcAmountUnits)) {
      params.onStatus?.('approving');
      const erc20 = new Contract(tokenAddress, ERC20_ABI, signer);
      // Grant only the exact amount needed for this quoted swap; never create an unlimited allowance.
      const approveTx = await erc20.approve(quote.tokenTransferProxy, BigInt(quote.srcAmountUnits));
      await approveTx.wait();
      approvalHash = approveTx.hash;
    }
  }

  params.onStatus?.('swapping');
  const destAmountMin = (BigInt(quote.destAmountUnits) * BigInt(10000 - params.slippageBps)) / 10000n;

  const tx = await trpcVanilla.swap.transaction.query({
    networkId: params.networkId,
    chainId,
    srcToken: tokenAddressFor(srcAsset),
    destToken: tokenAddressFor(destAsset),
    srcDecimals: srcAsset.decimals,
    destDecimals: destAsset.decimals,
    srcAmount: quote.srcAmountUnits,
    destAmount: destAmountMin.toString(),
    priceRoute: quote.priceRoute,
    userAddress,
  });

  const swapTx = await signer.sendTransaction({
    to: tx.to,
    data: tx.data,
    value: tx.value ? BigInt(tx.value) : 0n,
  });

  // The transaction is broadcast before this point, but a successful `wait()`
  // gives the receipt screen the authoritative mined result immediately. If a
  // public RPC times out, keep the safe pending fallback and let the receipt
  // poller resolve it later rather than claiming success prematurely.
  let status: TxStatus = 'pending';
  try {
    const receipt = await swapTx.wait();
    if (receipt) status = statusFromReceiptStatus(receipt.status);
  } catch (error) {
    console.warn('Swap receipt wait failed; leaving status pending for polling:', error);
  }

  return {
    approvalHash,
    swapHash: swapTx.hash,
    explorerUrl: network.explorerTx?.(swapTx.hash),
    status,
  };
}
