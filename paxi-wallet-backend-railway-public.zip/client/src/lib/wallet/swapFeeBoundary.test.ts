import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const swapPath = fileURLToPath(new URL("./swap.ts", import.meta.url));
const veloraPath = fileURLToPath(new URL("../../../../server/veloraQuote.ts", import.meta.url));
const swapPanelPath = fileURLToPath(new URL("../../pages/SwapPanel.tsx", import.meta.url));
const bridgePath = fileURLToPath(new URL("./bridge.ts", import.meta.url));
const bridgePanelPath = fileURLToPath(new URL("../../pages/BridgePanel.tsx", import.meta.url));

describe("Phase 7C fee destination boundaries", () => {
  it("binds EVM swap execution to the quote-bound fee address and rate", () => {
    const source = readFileSync(swapPath, "utf8");
    const serverSource = readFileSync(veloraPath, "utf8");

    expect(source).toContain("feeAddress: string | null");
    expect(serverSource).toContain("body.partnerAddress = feeAddress");
    expect(serverSource).toContain("body.partnerFeeBps = feeBps");
    expect(source).not.toContain("partnerAddress: WALLET_FEE_ADDRESS");
    expect(source).not.toContain("partnerFeeBps: WALLET_FEE_BPS");
  });

  it("gets the EVM fee rate and treasury through read-only server queries", () => {
    const source = readFileSync(swapPanelPath, "utf8");

    expect(source).toContain("trpc.fees.getTreasuryForNetwork.useQuery");
    expect(source).toContain("trpc.fees.getConfig.useQuery");
    expect(source).toContain("feeBps: serverFeeBps");
    expect(source).toContain("feeAddress: serverFeeAddress");
  });

  it("does not label the LI.FI route estimate as a verified PAXI bridge fee", () => {
    const bridge = readFileSync(bridgePath, "utf8");
    const panel = readFileSync(bridgePanelPath, "utf8");

    expect(bridge).toContain("LIFI_INTEGRATOR_FEE_BPS");
    expect(panel).toContain("LI.FI integrator fee estimate");
    expect(panel).toContain("a server-owned PAXI fee is not included");
  });
});

