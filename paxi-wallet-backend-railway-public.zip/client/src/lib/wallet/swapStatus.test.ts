import { describe, expect, it } from 'vitest';
import { statusFromReceiptStatus } from './swap';

describe('swap receipt status mapping', () => {
  it('marks a successful EVM receipt as confirmed', () => {
    expect(statusFromReceiptStatus(1)).toBe('confirmed');
  });

  it('marks a reverted EVM receipt as failed', () => {
    expect(statusFromReceiptStatus(0)).toBe('failed');
  });

  it('does not claim success when a receipt status is unavailable', () => {
    expect(statusFromReceiptStatus(null)).toBe('failed');
    expect(statusFromReceiptStatus(undefined)).toBe('failed');
  });
});
