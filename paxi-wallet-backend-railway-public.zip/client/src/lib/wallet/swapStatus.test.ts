import { describe, expect, it } from "vitest";
import { statusFromReceiptStatus } from "./swap";

describe("swap receipt status mapping", () => {
  it("marks a successful EVM receipt as confirmed", () => {
    expect(statusFromReceiptStatus(1)).toBe("confirmed");
  });

  it("marks a reverted EVM receipt as reverted", () => {
    expect(statusFromReceiptStatus(0)).toBe("reverted");
  });

  it("does not claim success when a receipt status is unavailable", () => {
    expect(statusFromReceiptStatus(null)).toBe("reverted");
    expect(statusFromReceiptStatus(undefined)).toBe("reverted");
  });
});
