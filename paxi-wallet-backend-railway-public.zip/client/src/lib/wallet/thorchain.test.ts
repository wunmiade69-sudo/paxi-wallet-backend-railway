import { afterEach, describe, expect, it, vi } from "vitest";
import { getThorchainSwapQuote, pollThorchainSwapStatus } from "./thorchain";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("THORChain gateway integration", () => {
  it("uses the documented Liquify quote gateway and normalizes a quote", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        inbound_address: "bc1qinbound",
        memo: "=:ETH.ETH:0x0000000000000000000000000000000000000001",
        expected_amount_out: "123456789",
        expiry: 1_900_000_000,
        fees: { total: "12345" },
      }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const quote = await getThorchainSwapQuote({
      destAsset: { thorId: "ETH.ETH", label: "Ethereum (ETH)" },
      destinationAddress: "0x0000000000000000000000000000000000000001",
      amountBtc: "0.01",
    });

    const requestUrl = decodeURIComponent(String(fetchMock.mock.calls[0]?.[0]));
    expect(requestUrl).toContain(
      "gateway.liquify.com/chain/thorchain_api/thorchain/quote/swap"
    );
    expect(requestUrl).toContain("from_asset=BTC.BTC");
    expect(quote.inboundAddress).toBe("bc1qinbound");
    expect(quote.expectedAmountOutFormatted).toBe("1.23456789");
  });

  it("uses the documented Liquify Midgard gateway for action tracking", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ actions: [{ status: "success" }] }),
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(pollThorchainSwapStatus("a".repeat(64))).resolves.toBe(
      "completed"
    );
    expect(decodeURIComponent(String(fetchMock.mock.calls[0]?.[0]))).toContain(
      "gateway.liquify.com/chain/thorchain_midgard/v2/actions"
    );
  });

  it.each([
    ["refunded", "refunded"],
    ["failed", "failed"],
  ] as const)(
    "preserves terminal %s status from Midgard",
    async (upstreamStatus, expectedStatus) => {
      vi.stubGlobal(
        "fetch",
        vi.fn().mockResolvedValue({
          ok: true,
          json: async () => ({ actions: [{ status: upstreamStatus }] }),
        })
      );

      await expect(pollThorchainSwapStatus("b".repeat(64))).resolves.toBe(
        expectedStatus
      );
    }
  );
});
