import { afterEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({ thorchainQuote: vi.fn(), thorchainStatus: vi.fn() }));
vi.mock('../trpcVanilla', () => ({
  trpcVanilla: { swap: { thorchainQuote: { query: mocks.thorchainQuote }, thorchainStatus: { query: mocks.thorchainStatus } } },
}));

import { getThorchainSwapQuote, pollThorchainSwapStatus } from './thorchain';

afterEach(() => {
  mocks.thorchainQuote.mockReset();
  mocks.thorchainStatus.mockReset();
  vi.restoreAllMocks();
});

describe('THORChain server boundary integration', () => {
  it('normalizes a server-provided quote without calling a browser gateway', async () => {
    mocks.thorchainQuote.mockResolvedValue({
      inboundAddress: 'bc1qinbound',
      memo: '=:ETH.ETH:0x0000000000000000000000000000000000000001',
      amountInBtc: '0.01',
      expectedAmountOutFormatted: '1.23456789',
      destAssetLabel: 'ETH.ETH',
      totalFeesUsd: '0.00',
      expirySeconds: 1_900_000_000,
      raw: {},
    });

    const quote = await getThorchainSwapQuote({
      destAsset: { thorId: 'ETH.ETH', label: 'Ethereum (ETH)' },
      destinationAddress: '0x0000000000000000000000000000000000000001',
      amountBtc: '0.01',
    });

    expect(mocks.thorchainQuote).toHaveBeenCalledWith({
      destinationAsset: 'ETH.ETH',
      destinationAddress: '0x0000000000000000000000000000000000000001',
      amountSats: '1000000',
    });
    expect(quote.inboundAddress).toBe('bc1qinbound');
    expect(quote.expectedAmountOutFormatted).toBe('1.23456789');
  });

  it('uses the server status procedure and preserves completed status', async () => {
    mocks.thorchainStatus.mockResolvedValue('completed');

    await expect(pollThorchainSwapStatus('a'.repeat(64))).resolves.toBe('completed');
    expect(mocks.thorchainStatus).toHaveBeenCalledWith({ txid: 'a'.repeat(64) });
  });
});
