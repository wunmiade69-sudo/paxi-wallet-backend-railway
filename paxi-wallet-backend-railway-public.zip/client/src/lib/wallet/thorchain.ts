/**
 * Bitcoin -> other-chain swaps via THORChain, the real cross-chain protocol
 * major wallets (Trust Wallet, Exodus, etc.) use for this - since Bitcoin
 * has no smart contracts, there's no on-chain "swap" the way EVM/Solana
 * have. Instead: THORChain's own network holds liquidity, and a swap
 * happens by sending BTC to a THORChain-controlled vault address with a
 * memo encoding the swap instructions.
 *
 * Flow:
 *   1. getThorchainSwapQuote() - asks THORChain for the current vault
 *      address, the exact memo to use, and the expected output.
 *   2. executeThorchainSwap() - builds a real Bitcoin transaction paying
 *      that vault address, with the memo embedded as an OP_RETURN output,
 *      signs and broadcasts it (reusing the same UTXO/fee/broadcast
 *      plumbing as a plain BTC send in bitcoin.ts).
 *   3. pollThorchainSwapStatus() - THORChain's own network picks up the
 *      deposit and completes the swap on its side; this checks progress.
 *
 * Routed through the same server proxy as Blockstream/Blockscout, for the
 * same CORS reasons.
 */
import * as bitcoin from "bitcoinjs-lib";
import { deriveBitcoinKeyPair } from "./engine";
import {
  fetchUtxos,
  fetchFeeRate,
  fetchPrevTxHex,
  estimateVBytes,
  type Utxo,
} from "./bitcoin";

// Current documented public gateways. Nine Realms direct hosts can return DNS/upstream
// failures from browser/server environments; Liquify exposes the same public APIs with
// stable gateway routing.
const THORNODE_BASE = "https://gateway.liquify.com/chain/thorchain_api";
const MIDGARD_BASE = "https://gateway.liquify.com/chain/thorchain_midgard";

function proxiedThornode(pathAndQuery: string): string {
  return `/api/blockscout-proxy?url=${encodeURIComponent(`${THORNODE_BASE}${pathAndQuery}`)}`;
}
function proxiedMidgard(pathAndQuery: string): string {
  return `/api/blockscout-proxy?url=${encodeURIComponent(`${MIDGARD_BASE}${pathAndQuery}`)}`;
}

/** THORChain's own asset notation, e.g. "ETH.ETH", "BSC.BNB", "BSC.USDT-0X55D398...". */
export interface ThorchainAsset {
  thorId: string;
  label: string;
}

// The destination assets this wallet actually offers - intentionally a
// short, known-good list rather than every asset THORChain's pools
// support, since pool support changes over time and an unlisted/low-depth
// pool gives a bad swap rate or fails outright.
export const THORCHAIN_DEST_ASSETS: ThorchainAsset[] = [
  { thorId: "ETH.ETH", label: "Ethereum (ETH)" },
  { thorId: "BSC.BNB", label: "BNB Smart Chain (BNB)" },
  {
    thorId: "BSC.USDT-0X55D398326F99059FF775485246999027B3197955",
    label: "USDT on BSC",
  },
  {
    thorId: "ETH.USDT-0XDAC17F958D2EE523A2206206994597C13D831EC",
    label: "USDT on Ethereum",
  },
];

export interface ThorchainQuote {
  inboundAddress: string;
  memo: string;
  amountInBtc: string;
  expectedAmountOutFormatted: string;
  destAssetLabel: string;
  totalFeesUsd?: string;
  expirySeconds: number;
  warning?: string;
  raw: any;
}

export async function getThorchainSwapQuote(params: {
  destAsset: ThorchainAsset;
  destinationAddress: string;
  amountBtc: string;
}): Promise<ThorchainQuote> {
  const amountSats = Math.round(Number(params.amountBtc) * 1e8);
  if (!Number.isFinite(amountSats) || amountSats <= 0)
    throw new Error("Enter a valid BTC amount.");

  const search = new URLSearchParams({
    from_asset: "BTC.BTC",
    to_asset: params.destAsset.thorId,
    amount: String(amountSats),
    destination: params.destinationAddress,
  });

  const res = await fetch(
    proxiedThornode(`/thorchain/quote/swap?${search.toString()}`)
  );
  if (!res.ok)
    throw new Error(
      "Could not get a THORChain swap quote - the route may not be available right now."
    );
  const data = await res.json();

  if (data.error) {
    // THORChain itself pauses trading network-wide sometimes (not specific to this wallet or
    // pair) - surface that plainly instead of the raw simulator error text, which reads like a
    // bug in the app rather than an upstream network state. See reports/THORCHAIN_GATEWAY_FINDINGS.md.
    if (/halt/i.test(data.error)) {
      throw new Error(
        "THORChain trading is temporarily paused network-wide. This is not specific to your swap - try again later."
      );
    }
    throw new Error(`THORChain: ${data.error}`);
  }
  if (!data.inbound_address || !data.memo) {
    throw new Error("THORChain did not return a usable quote for this route.");
  }

  // THORChain returns destination-asset amounts in 1e8 units regardless of
  // that chain's native decimals (its own internal accounting standard).
  const expectedOut = Number(data.expected_amount_out ?? 0) / 1e8;

  return {
    inboundAddress: data.inbound_address,
    memo: data.memo,
    amountInBtc: params.amountBtc,
    expectedAmountOutFormatted: expectedOut.toString(),
    destAssetLabel: params.destAsset.label,
    totalFeesUsd: data.fees?.total
      ? (Number(data.fees.total) / 1e8).toFixed(2)
      : undefined,
    expirySeconds: data.expiry ?? 0,
    warning: data.warning,
    raw: data,
  };
}

export async function executeThorchainSwap(params: {
  mnemonic: string;
  quote: ThorchainQuote;
}): Promise<{ hash: string; explorerUrl?: string }> {
  const keyPair = deriveBitcoinKeyPair(params.mnemonic);
  const { address: fromAddress } = bitcoin.payments.p2wpkh({
    pubkey: Buffer.from(keyPair.publicKey),
    network: bitcoin.networks.bitcoin,
  });
  if (!fromAddress) throw new Error("Could not derive sending address.");

  const amountSats = Math.round(Number(params.quote.amountInBtc) * 1e8);
  const [utxos, feeRate] = await Promise.all([
    fetchUtxos(fromAddress),
    fetchFeeRate(),
  ]);
  if (utxos.length === 0)
    throw new Error("No spendable Bitcoin found in this wallet.");

  // Vault payment + OP_RETURN memo + possible change = 3 outputs.
  utxos.sort((a, b) => b.value - a.value);
  const selected: Utxo[] = [];
  let total = 0;
  for (const utxo of utxos) {
    selected.push(utxo);
    total += utxo.value;
    const estimatedFee = estimateVBytes(selected.length, 3) * feeRate;
    if (total >= amountSats + estimatedFee) break;
  }
  const estimatedFee = estimateVBytes(selected.length, 3) * feeRate;
  if (total < amountSats + estimatedFee) {
    throw new Error(
      "Insufficient BTC balance to cover the swap amount plus network fee."
    );
  }

  const psbt = new bitcoin.Psbt({ network: bitcoin.networks.bitcoin });
  for (const utxo of selected) {
    const prevTxHex = await fetchPrevTxHex(utxo.txid);
    const prevTx = bitcoin.Transaction.fromHex(prevTxHex);
    psbt.addInput({
      hash: utxo.txid,
      index: utxo.vout,
      witnessUtxo: { script: prevTx.outs[utxo.vout].script, value: utxo.value },
    });
  }

  psbt.addOutput({ address: params.quote.inboundAddress, value: amountSats });

  const memoEmbed = bitcoin.payments.embed({
    data: [Buffer.from(params.quote.memo, "utf8")],
  });
  if (!memoEmbed.output) throw new Error("Could not encode THORChain memo.");
  psbt.addOutput({ script: memoEmbed.output, value: 0 });

  const change = total - amountSats - estimatedFee;
  if (change > 546) {
    psbt.addOutput({ address: fromAddress, value: change });
  }

  selected.forEach((_, i) => psbt.signInput(i, keyPair));
  psbt.finalizeAllInputs();
  const txHex = psbt.extractTransaction().toHex();

  const broadcastRes = await fetch(
    `/api/blockscout-proxy?url=${encodeURIComponent("https://blockstream.info/api/tx")}`,
    {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: txHex,
    }
  );
  if (!broadcastRes.ok) {
    const errText = await broadcastRes.text().catch(() => "");
    throw new Error(`Broadcast failed: ${errText || broadcastRes.statusText}`);
  }
  const txid = (await broadcastRes.text()).trim();

  return { hash: txid, explorerUrl: `https://blockstream.info/tx/${txid}` };
}

export type ThorchainSwapStatus =
  "pending" | "observed" | "completed" | "refunded" | "failed" | "unknown";

/** Poll this periodically (e.g. every 15s) after broadcasting - THORChain
 * takes a number of confirmations + its own processing time, this is not instant. */
export async function pollThorchainSwapStatus(
  btcTxid: string
): Promise<ThorchainSwapStatus> {
  try {
    const res = await fetch(proxiedMidgard(`/v2/actions?txid=${btcTxid}`));
    if (!res.ok) return "unknown";
    const data = await res.json();
    const action = data.actions?.[0];
    if (!action) return "pending";
    if (action.status === "success" || action.status === "completed")
      return "completed";
    if (action.status === "refunded" || action.status === "refund")
      return "refunded";
    if (action.status === "failed" || action.status === "error")
      return "failed";
    if (action.status === "observed") return "observed";
    return "observed";
  } catch {
    return "unknown";
  }
}
