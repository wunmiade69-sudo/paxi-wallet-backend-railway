/**
 * Deploys a brand-new BEP20/ERC20 token via Paxi's PaxiTokenFactory contract
 * (see /contracts/PaxiTokenFactory.sol).
 *
 * Flow: pay the $0.50 fee first, as a single plain USDT transfer to
 * treasury (payCreationFee, one signature, no "approve" concept - exactly
 * like the listing/campaign fee flows already in this app) - THEN deploy.
 * The contract's own on-chain feeAmount should be set to 0 by the owner
 * (one-time call via BscScan Write Contract) once fees are collected this
 * way, so createToken() itself needs no approval and no second payment.
 * createTokenOnChain reads the contract's live feeAmount and only bothers
 * with approve+pull if it's still nonzero, so this stays correct either way.
 *
 * FACTORY_ADDRESSES must be filled in after you deploy PaxiTokenFactory.sol
 * to each network - see the deployment steps at the bottom of that file.
 * Networks missing an address here simply aren't offered in the UI yet.
 */
import { Contract, Interface, JsonRpcProvider, parseUnits } from 'ethers';
import { NETWORKS } from './chains';
import { walletFromMnemonic } from './engine';
import { CANONICAL_CHAINS } from '@shared/canonicalRegistry';
import { formatBaseUnits } from './decimalParsing';

export const FACTORY_ADDRESSES: Record<string, string> = {
  bsc: '0xc913e259eeef3d4623900b05e8a8ab6a496b9ef2', // PaxiTokenFactory, deployed BSC mainnet
};

/** Same USDT/USDC addresses the server checks in server/feeVerification.ts - keep in sync. */
export const FEE_TOKEN_ADDRESSES: Record<string, { USDT: string; USDC: string }> = {
  bsc: {
    USDT: CANONICAL_CHAINS.bsc.stablecoins.USDT!.address,
    USDC: CANONICAL_CHAINS.bsc.stablecoins.USDC!.address,
  },
  ethereum: {
    USDT: CANONICAL_CHAINS.ethereum.stablecoins.USDT!.address,
    USDC: CANONICAL_CHAINS.ethereum.stablecoins.USDC!.address,
  },
};

export const CREATION_FEE_USD = 0.5;
const FEE_TOKEN_DECIMALS: Record<string, number> = { bsc: 18, ethereum: 6 };

const ERC20_ABI = [
  'function transfer(address to, uint256 amount) returns (bool)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
];

const FACTORY_ABI = [
  'function createToken(string tokenName, string tokenSymbol, uint256 initialSupply) returns (address)',
  'function feeAmount() view returns (uint256)',
  'event TokenCreated(address indexed tokenAddress, address indexed creator, string name, string symbol, uint256 supply, uint256 feePaid)',
];

export function isCreationSupported(network: string): boolean {
  return Boolean(FACTORY_ADDRESSES[network] && FEE_TOKEN_ADDRESSES[network]);
}

/** Best-effort network-fee estimate for the review screen - a real `estimateGas` against the
 * factory using a throwaway read (no signer needed since createToken doesn't depend on
 * caller balance for the estimate itself). Falls back to a conservative flat guess if the
 * RPC call fails, since a missing "provider fee" line is worse than an approximate one. */
export async function estimateTokenCreationGasFee(params: {
  network: string;
  fromAddress: string;
  tokenName: string;
  tokenSymbol: string;
  initialSupply: string;
}): Promise<{ estimatedFeeNative: string; nativeSymbol: string } | null> {
  const { network } = params;
  const factoryAddress = FACTORY_ADDRESSES[network];
  const chainConfig = NETWORKS[network];
  if (!factoryAddress || !chainConfig?.rpcUrl) return null;

  try {
    const provider = new JsonRpcProvider(chainConfig.rpcUrl);
    const factory = new Contract(factoryAddress, FACTORY_ABI, provider);
    const supplyUnits = parseUnits(params.initialSupply || '1', 18);

    const [feeData, gasLimit] = await Promise.all([
      provider.getFeeData(),
      factory.createToken
        .estimateGas(params.tokenName || 'Token', params.tokenSymbol || 'TKN', supplyUnits, { from: params.fromAddress })
        .catch(() => 2_500_000n), // conservative fallback if the estimate call itself fails (e.g. locked wallet)
    ]);
    const gasPrice = feeData.maxFeePerGas ?? feeData.gasPrice ?? 0n;
    const feeWei = gasPrice * gasLimit;

    // Exact wei -> decimal-string formatting. This estimate is echoed back
    // into the review screen and can be re-parsed further up the flow, so
    // it must never be widened through Number/toFixed.
    return {
      estimatedFeeNative: formatBaseUnits(feeWei, 18),
      nativeSymbol: chainConfig.nativeSymbol,
    };
  } catch (err) {
    console.warn('Token creation gas estimate failed:', err);
    return null;
  }
}

/**
 * Step 1: pay the $0.50 creation fee directly to the treasury address, as a
 * plain transfer - one signature, nothing to approve. Returns the tx hash,
 * which the server verifies (server/feeVerification.ts) exactly the same
 * way it verifies listing/campaign fees - it just checks a real transfer of
 * at least $0.50 landed at treasury, regardless of which flow produced it.
 */
export async function payCreationFee(params: {
  mnemonic: string;
  network: string;
  treasuryAddress: string;
  feeToken?: 'USDT' | 'USDC';
}): Promise<{ feeTxHash: string }> {
  const { network, feeToken = 'USDT' } = params;
  const feeTokenAddress = FEE_TOKEN_ADDRESSES[network]?.[feeToken];
  if (!feeTokenAddress) throw new Error(`Fee payment isn't set up for "${network}" yet.`);

  const chainConfig = NETWORKS[network];
  if (!chainConfig?.rpcUrl) throw new Error(`${network} RPC isn't configured.`);

  const provider = new JsonRpcProvider(chainConfig.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);
  const feeUnits = parseUnits(CREATION_FEE_USD.toString(), FEE_TOKEN_DECIMALS[network] ?? 6);

  const feeTokenContract = new Contract(feeTokenAddress, ERC20_ABI, signer);
  const tx = await feeTokenContract.transfer(params.treasuryAddress, feeUnits);
  await tx.wait();

  return { feeTxHash: tx.hash };
}

/**
 * Step 2: deploy the token. If the contract's on-chain feeAmount is still
 * nonzero (owner hasn't disabled it yet), this transparently falls back to
 * the old approve-then-create path so nothing breaks either way.
 */
export async function createTokenOnChain(params: {
  mnemonic: string;
  network: string;
  tokenName: string;
  tokenSymbol: string;
  initialSupply: string; // human units, e.g. "1000000"
  feeToken?: 'USDT' | 'USDC';
  onStatus?: (status: 'approving' | 'creating') => void;
}): Promise<{ tokenAddress: string; createTxHash: string }> {
  const { network, feeToken = 'USDT' } = params;
  const factoryAddress = FACTORY_ADDRESSES[network];
  const feeTokenAddress = FEE_TOKEN_ADDRESSES[network]?.[feeToken];
  if (!factoryAddress || !feeTokenAddress) {
    throw new Error(`Token creation isn't set up for "${network}" yet - the factory address is missing.`);
  }

  const chainConfig = NETWORKS[network];
  if (!chainConfig?.rpcUrl) throw new Error(`${network} RPC isn't configured.`);

  const provider = new JsonRpcProvider(chainConfig.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);
  const factory = new Contract(factoryAddress, FACTORY_ABI, signer);

  const onChainFee: bigint = await factory.feeAmount();
  if (onChainFee > 0n) {
    throw new Error('The token factory still charges an on-chain fee. Backend-fee mode requires factory feeAmount=0 before deployment.');
  }

  params.onStatus?.('creating');
  const supplyUnits = parseUnits(params.initialSupply, 18);
  const createTx = await factory.createToken(params.tokenName, params.tokenSymbol, supplyUnits);
  const receipt = await createTx.wait();

  const iface = new Interface(FACTORY_ABI);
  let tokenAddress: string | undefined;
  for (const log of receipt.logs) {
    try {
      const parsed = iface.parseLog(log);
      if (parsed?.name === 'TokenCreated') {
        tokenAddress = parsed.args.tokenAddress as string;
        break;
      }
    } catch {
      // not a log from this contract, skip
    }
  }
  if (!tokenAddress) throw new Error('Token was created but the address could not be read from the transaction.');

  return { tokenAddress, createTxHash: createTx.hash };
}
