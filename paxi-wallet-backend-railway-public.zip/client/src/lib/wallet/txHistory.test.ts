import { describe, expect, it } from "vitest";
import {
  canTransitionTxStatus,
  isTxInFlight,
  isTxSuccessful,
  isTxTerminalFailure,
  normalizeTxStatus,
} from "./txHistory";

describe("normalized transaction state model", () => {
  it("does not treat an omitted status as successful", () => {
    expect(normalizeTxStatus(undefined)).toBe("unknown");
    expect(isTxSuccessful(undefined)).toBe(false);
  });

  it("recognizes the signing and broadcast states as in flight", () => {
    expect(isTxInFlight("awaiting_signature")).toBe(true);
    expect(isTxInFlight("submitted")).toBe(true);
    expect(isTxInFlight("pending")).toBe(true);
    expect(isTxInFlight("confirmed")).toBe(false);
  });

  it("requires an explicit confirmed or finalized state for success", () => {
    expect(isTxSuccessful("confirmed")).toBe(true);
    expect(isTxSuccessful("finalized")).toBe(true);
    expect(isTxSuccessful("submitted")).toBe(false);
    expect(isTxSuccessful("failed")).toBe(false);
    expect(isTxSuccessful("reverted")).toBe(false);
  });

  it("identifies replacement, dropped, reorged, and expired outcomes as terminal failures", () => {
    for (const status of [
      "failed",
      "reverted",
      "replaced",
      "dropped",
      "reorged",
      "expired",
    ] as const) {
      expect(isTxTerminalFailure(status)).toBe(true);
    }
  });

  it("allows normal broadcast recovery and blocks success after terminal failure", () => {
    expect(canTransitionTxStatus("awaiting_signature", "signed")).toBe(true);
    expect(canTransitionTxStatus("signed", "submitted")).toBe(true);
    expect(canTransitionTxStatus("submitted", "pending")).toBe(true);
    expect(canTransitionTxStatus("pending", "confirmed")).toBe(true);
    expect(canTransitionTxStatus("submitted", "reverted")).toBe(true);
    expect(canTransitionTxStatus("failed", "confirmed")).toBe(false);
    expect(canTransitionTxStatus("replaced", "pending")).toBe(false);
  });

  it("allows a confirmed transaction to become finalized or reorged", () => {
    expect(canTransitionTxStatus("confirmed", "finalized")).toBe(true);
    expect(canTransitionTxStatus("confirmed", "reorged")).toBe(true);
  });
});
