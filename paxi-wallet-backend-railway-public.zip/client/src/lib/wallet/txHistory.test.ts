import { afterEach, describe, expect, it } from 'vitest';
import { clearTxRecords, ensureTxRecord, getTxRecords, updateTxRecord } from './txHistory';

const storage = new Map<string, string>();
const originalLocalStorage = globalThis.localStorage;

function installStorage(): void {
  Object.defineProperty(globalThis, 'localStorage', {
    configurable: true,
    value: {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => storage.set(key, value),
      removeItem: (key: string) => storage.delete(key),
    },
  });
}

const pendingSend = {
  type: 'send' as const,
  networkId: 'ethereum',
  hash: `0x${'a'.repeat(64)}`,
  fromSymbol: 'ETH',
  fromAmount: '1',
  counterparty: `0x${'b'.repeat(40)}`,
  status: 'pending' as const,
};

afterEach(() => {
  storage.clear();
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: originalLocalStorage });
});

describe('pending SEND history', () => {
  it('creates one pending row and finalizes it by the known hash', () => {
    installStorage();
    const first = ensureTxRecord(pendingSend);
    const second = ensureTxRecord({ ...pendingSend, hash: pendingSend.hash.toUpperCase() });

    expect(second.id).toBe(first.id);
    expect(getTxRecords()).toHaveLength(1);

    updateTxRecord(pendingSend.hash, { status: 'confirmed' }, true, pendingSend.networkId);
    expect(getTxRecords()[0]?.status).toBe('confirmed');
  });

  it('does not confuse the same hash on a different network with this record', () => {
    installStorage();
    ensureTxRecord(pendingSend);
    ensureTxRecord({ ...pendingSend, networkId: 'bsc' });
    expect(getTxRecords()).toHaveLength(2);
  });

  it('updates only the requested network when hashes collide', () => {
    installStorage();
    ensureTxRecord(pendingSend);
    ensureTxRecord({ ...pendingSend, networkId: 'bsc' });
    updateTxRecord(pendingSend.hash, { status: 'confirmed' }, false, 'bsc');
    const records = getTxRecords();
    expect(records.find((record) => record.networkId === 'ethereum')?.status).toBe('pending');
    expect(records.find((record) => record.networkId === 'bsc')?.status).toBe('confirmed');
  });

  it('clears local history explicitly', () => {
    installStorage();
    ensureTxRecord(pendingSend);
    clearTxRecords();
    expect(getTxRecords()).toHaveLength(0);
  });
});
