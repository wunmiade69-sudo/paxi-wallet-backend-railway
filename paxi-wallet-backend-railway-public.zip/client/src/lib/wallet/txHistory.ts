/**
 * Local transaction history.
 *
 * This is the wallet's own log: every Send/Swap/Bridge this app broadcasts
 * gets recorded here the moment it's submitted, keyed off the real tx hash,
 * starting in `pending` status. On its own this only covers "what did I
 * just do in this app" - it can't know about transactions made outside it
 * (like a plain receive from someone else, or activity from before this
 * device had the wallet installed).
 *
 * For the full picture - real confirmations, receives, fees - this is
 * merged with on-chain data at read time. See `txIndexer.ts`
 * (`getFullHistory`), which resolves each pending local record's real
 * status via RPC and unions in on-chain history from a block explorer API.
 * `getTxRecords` below is still useful on its own for "what this app has
 * done" without a network round-trip (e.g. instant paint before the merged
 * fetch resolves).
 */

export type TxType = "send" | "receive" | "swap" | "bridge" | "create";

/** Common lifecycle states. Chain-specific finality is carried separately in `finality`. */
export type TxStatus =
  | "unknown"
  | "created"
  | "validating"
  | "awaiting_signature"
  | "signed"
  | "submitted"
  | "pending"
  | "confirmed"
  | "finalized"
  | "failed"
  | "reverted"
  | "replaced"
  | "dropped"
  | "reorged"
  | "expired";

export type TxFinality =
  | "evm_receipt"
  | "solana_confirmed"
  | "solana_finalized"
  | "bitcoin_confirmations"
  | "bridge_observed"
  | "bridge_completed"
  | "payout_verified"
  | "unknown";

export interface TxRecord {
  id: string;
  type: TxType;
  networkId: string;
  hash: string;
  explorerUrl?: string;
  fromSymbol: string;
  fromAmount: string;
  toSymbol?: string; // swap/bridge only
  toAmount?: string; // swap/bridge only, estimated
  toNetworkId?: string; // bridge only, destination chain
  counterparty?: string; // send: recipient address, receive: sender address
  timestamp: number;
  /** Older records may omit this field; omitted status is normalized to unknown, never success. */
  status?: TxStatus;
  /** Chain-specific confirmation/finality rule used to interpret the status. */
  finality?: TxFinality;
  feeAmount?: string; // network fee actually paid, once known
  feeSymbol?: string;
  source?: "local" | "onchain"; // local = broadcast by this app; onchain = discovered via indexer (e.g. a receive)
}

const KEY = "paxi-tx-history";
const MAX_RECORDS = 200;

export function normalizeTxStatus(status: TxRecord["status"]): TxStatus {
  return status ?? "unknown";
}

export function isTxInFlight(status: TxRecord["status"]): boolean {
  return [
    "created",
    "validating",
    "awaiting_signature",
    "signed",
    "submitted",
    "pending",
  ].includes(normalizeTxStatus(status));
}

export function isTxSuccessful(status: TxRecord["status"]): boolean {
  return ["confirmed", "finalized"].includes(normalizeTxStatus(status));
}

export function isTxTerminalFailure(status: TxRecord["status"]): boolean {
  return [
    "failed",
    "reverted",
    "replaced",
    "dropped",
    "reorged",
    "expired",
  ].includes(normalizeTxStatus(status));
}

const ALLOWED_TRANSITIONS: Record<TxStatus, readonly TxStatus[]> = {
  unknown: [
    "created",
    "validating",
    "awaiting_signature",
    "signed",
    "submitted",
    "pending",
    "confirmed",
    "finalized",
    "failed",
    "reverted",
    "expired",
  ],
  created: [
    "validating",
    "awaiting_signature",
    "failed",
    "reverted",
    "expired",
  ],
  validating: ["awaiting_signature", "signed", "failed", "reverted", "expired"],
  awaiting_signature: ["signed", "failed", "reverted", "expired"],
  signed: ["submitted", "failed", "reverted", "expired"],
  submitted: [
    "pending",
    "confirmed",
    "finalized",
    "failed",
    "reverted",
    "replaced",
    "dropped",
    "reorged",
    "expired",
  ],
  pending: [
    "pending",
    "confirmed",
    "finalized",
    "failed",
    "reverted",
    "replaced",
    "dropped",
    "reorged",
    "expired",
  ],
  confirmed: ["finalized", "reorged", "reverted"],
  finalized: ["reorged"],
  failed: [],
  reverted: [],
  replaced: [],
  dropped: [],
  reorged: ["pending", "confirmed", "finalized"],
  expired: [],
};

export function canTransitionTxStatus(
  from: TxRecord["status"],
  to: TxStatus
): boolean {
  const current = normalizeTxStatus(from);
  return current === to || ALLOWED_TRANSITIONS[current].includes(to);
}

export function getTxRecords(): TxRecord[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    if (!Array.isArray(raw)) return [];
    return raw
      .filter((record): record is TxRecord =>
        Boolean(
          record &&
          typeof record === "object" &&
          typeof record.hash === "string"
        )
      )
      .sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export function addTxRecord(
  record: Omit<TxRecord, "id" | "timestamp" | "source"> & { status?: TxStatus }
): TxRecord {
  const full: TxRecord = {
    status: "pending",
    ...record,
    source: "local",
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: Date.now(),
  };
  const existing = getTxRecords();
  existing.unshift(full);
  localStorage.setItem(KEY, JSON.stringify(existing.slice(0, MAX_RECORDS)));
  return full;
}

/** Patches a previously-logged record in place (used to persist resolved pending -> confirmed/failed status + fee). */
export function updateTxRecord(
  hash: string,
  patch: Partial<
    Pick<TxRecord, "status" | "feeAmount" | "feeSymbol" | "finality">
  >
) {
  const existing = getTxRecords();
  const idx = existing.findIndex(
    r => r.hash.toLowerCase() === hash.toLowerCase()
  );
  if (idx === -1) return false;
  if (
    patch.status &&
    !canTransitionTxStatus(existing[idx].status, patch.status)
  )
    return false;
  existing[idx] = { ...existing[idx], ...patch };
  localStorage.setItem(KEY, JSON.stringify(existing.slice(0, MAX_RECORDS)));
  return true;
}

export function clearTxRecords() {
  localStorage.removeItem(KEY);
}
