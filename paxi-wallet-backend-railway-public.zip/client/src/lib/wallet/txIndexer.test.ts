import { describe, expect, it } from "vitest";
import { mapSolanaSignatureStatus } from "./txIndexer";

describe("mapSolanaSignatureStatus", () => {
  it("maps finalized signatures with Solana finality", () => {
    expect(
      mapSolanaSignatureStatus({ confirmationStatus: "finalized", err: null })
    ).toEqual({
      status: "finalized",
      finality: "solana_finalized",
    });
  });

  it("maps confirmed signatures without claiming finalized", () => {
    expect(
      mapSolanaSignatureStatus({ confirmationStatus: "confirmed", err: null })
    ).toEqual({
      status: "confirmed",
      finality: "solana_confirmed",
    });
  });

  it("maps failed signatures to failure regardless of confirmation stage", () => {
    expect(
      mapSolanaSignatureStatus({
        confirmationStatus: "confirmed",
        err: { InstructionError: [0, "Custom"] },
      })
    ).toEqual({
      status: "failed",
    });
  });

  it("keeps processed signatures submitted and not successful", () => {
    expect(
      mapSolanaSignatureStatus({ confirmationStatus: "processed", err: null })
    ).toEqual({
      status: "submitted",
    });
  });

  it("returns unknown when the RPC has no signature information", () => {
    expect(mapSolanaSignatureStatus(null)).toBeNull();
  });
});
