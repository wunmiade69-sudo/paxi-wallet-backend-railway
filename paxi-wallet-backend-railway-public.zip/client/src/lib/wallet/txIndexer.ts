/**
 * Real transaction history.
 *
 * `txHistory.ts` only knows about what this app itself broadcast. This
 * module fills the two gaps that leaves open:
 *
 * 1. Confirmation status. A freshly-sent tx is logged locally as `pending`
 *    and never updated - here we check the real receipt over the same
 *    public RPC already used for balances/sending, so Sent quickly becomes
 *    Confirmed (or Failed) instead of sitting as "pending" forever.
 * 2. Everything the app didn't broadcast. A plain incoming transfer from
 *    someone else never touches `addTxRecord`, so without an outside data
 *    source it would simply never show up. Blockscout runs free, no-key
 *    public API instances for Ethereum and BSC (same "no signup" bar as
 *    every other data source in this app - Binance, DexScreener, GoPlus,
 *    Velora, LI.FI) that index full address history, so it's used here for
 *    native transfers and ERC-20 token transfers.
 *
 * BTC/SOL still have no address-history indexer here (see chains.ts), so
 * `getFullHistory` does not add external history for them. Pending Bitcoin
 * records are nevertheless resolved through Esplora transaction status, while
 * Solana sends return after `sendAndConfirmTransaction`.
 */
import { JsonRpcProvider, formatUnits } from "ethers";
import { Connection } from "@solana/web3.js";
import { NETWORKS } from "./chains";
import {
  getTxRecords,
  isTxInFlight,
  updateTxRecord,
  type TxRecord,
  type TxStatus,
} from "./txHistory";
import { fetchBitcoinTransactionStatus } from "./bitcoin";

const BLOCKSCOUT_BASE: Record<string, string> = {
  ethereum: "https://eth.blockscout.com",
  bsc: "https://bsc.blockscout.com",
};

const FETCH_TIMEOUT_MS = 8000;
const MAX_PER_NETWORK = 40;

export function mapSolanaSignatureStatus(
  value: {
    err?: unknown | null;
    confirmationStatus?: "processed" | "confirmed" | "finalized" | null;
  } | null
): {
  status: TxStatus;
  finality?: "solana_confirmed" | "solana_finalized";
} | null {
  if (!value) return null;
  if (value.err) return { status: "failed" };
  if (value.confirmationStatus === "finalized")
    return { status: "finalized", finality: "solana_finalized" };
  if (value.confirmationStatus === "confirmed")
    return { status: "confirmed", finality: "solana_confirmed" };
  return { status: "submitted" };
}

async function fetchJson(url: string): Promise<any | null> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    // Routed through our own server (server/_core/blockscoutProxy.ts) instead of
    // calling Blockscout directly - browsers can silently block the direct call
    // due to CORS, which used to show up as "deposit just doesn't appear".
    const proxiedUrl = `/api/blockscout-proxy?url=${encodeURIComponent(url)}`;
    const res = await fetch(proxiedUrl, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null; // indexer being unreachable shouldn't break the screen - caller just gets fewer records
  }
}

function short(addr: string): string {
  return addr;
}

/** Native coin transfers (ETH/BNB in and out) for one address on one EVM network. */
async function fetchNativeHistory(
  networkId: string,
  address: string
): Promise<TxRecord[]> {
  const base = BLOCKSCOUT_BASE[networkId];
  const network = NETWORKS[networkId];
  if (!base || !network) return [];

  const data = await fetchJson(
    `${base}/api/v2/addresses/${address}/transactions?filter=to%7Cfrom`
  );
  const items: any[] = Array.isArray(data?.items) ? data.items : [];

  return items
    .slice(0, MAX_PER_NETWORK)
    .filter(t => t?.value && t.value !== "0") // skip 0-value contract calls (approvals, swap legs) - token transfers below cover the real movement
    .map((t): TxRecord => {
      const isOutgoing =
        String(t.from?.hash).toLowerCase() === address.toLowerCase();
      const valueEth = Number(formatUnits(BigInt(t.value ?? "0"), 18));
      const status: TxStatus =
        t.status === "error"
          ? "reverted"
          : t.status === "ok"
            ? "confirmed"
            : "pending";
      const feeWei = t.fee?.value;
      return {
        id: `onchain-${networkId}-${t.hash}`,
        type: isOutgoing ? "send" : "receive",
        networkId,
        hash: t.hash,
        explorerUrl: network.explorerTx?.(t.hash),
        fromSymbol: network.nativeSymbol,
        fromAmount: valueEth.toString(),
        counterparty: short(isOutgoing ? t.to?.hash : t.from?.hash),
        timestamp: t.timestamp ? new Date(t.timestamp).getTime() : Date.now(),
        status,
        feeAmount: feeWei
          ? Number(formatUnits(BigInt(feeWei), 18)).toString()
          : undefined,
        feeSymbol: feeWei ? network.nativeSymbol : undefined,
        source: "onchain",
      };
    });
}

/** ERC-20/BEP-20 token transfers (in and out) for one address on one EVM network. */
async function fetchTokenTransferHistory(
  networkId: string,
  address: string
): Promise<TxRecord[]> {
  const base = BLOCKSCOUT_BASE[networkId];
  const network = NETWORKS[networkId];
  if (!base || !network) return [];

  const data = await fetchJson(
    `${base}/api/v2/addresses/${address}/token-transfers?filter=to%7Cfrom`
  );
  const items: any[] = Array.isArray(data?.items) ? data.items : [];

  return items.slice(0, MAX_PER_NETWORK).map((t): TxRecord => {
    const isOutgoing =
      String(t.from?.hash).toLowerCase() === address.toLowerCase();
    const decimals = Number(t.token?.decimals ?? 18);
    const rawValue = t.total?.value ?? "0";
    let amount = "0";
    try {
      amount = Number(formatUnits(BigInt(rawValue), decimals)).toString();
    } catch {
      /* malformed value from indexer - leave as 0 rather than throw */
    }
    return {
      id: `onchain-${networkId}-token-${t.transaction_hash}-${t.token?.address}`,
      type: isOutgoing ? "send" : "receive",
      networkId,
      hash: t.transaction_hash,
      explorerUrl: network.explorerTx?.(t.transaction_hash),
      fromSymbol: t.token?.symbol ?? "TOKEN",
      fromAmount: amount,
      counterparty: short(isOutgoing ? t.to?.hash : t.from?.hash),
      timestamp: t.timestamp ? new Date(t.timestamp).getTime() : Date.now(),
      status: "confirmed", // token-transfer events only exist once mined, so these are always confirmed
      source: "onchain",
    };
  });
}

/**
 * Full on-chain history across every EVM network this wallet has an indexer for. Never throws - best effort.
 */
export async function fetchOnChainHistory(
  address: string
): Promise<TxRecord[]> {
  if (!address) return [];
  const networkIds = Object.keys(BLOCKSCOUT_BASE);
  const results = await Promise.all(
    networkIds.flatMap(id => [
      fetchNativeHistory(id, address),
      fetchTokenTransferHistory(id, address),
    ])
  );
  return results.flat();
}

/**
 * Blockscout receipt fallback for EVM transactions. This is intentionally
 * limited to the two indexed EVM networks and only returns a status when the
 * explorer explicitly reports a mined transaction.
 */
async function resolveEvmStatusFromBlockscout(
  record: TxRecord
): Promise<TxStatus | null> {
  const base = BLOCKSCOUT_BASE[record.networkId];
  if (!base) return null;
  const data = await fetchJson(`${base}/api/v2/transactions/${record.hash}`);
  if (!data) return null;
  if (data.status === "ok" || data.result === "success") return "confirmed";
  if (data.status === "error" || data.result === "failure") return "reverted";
  if (data.block && data.confirmations != null) return "confirmed";
  return null;
}

/** Best-effort receipt check for a still-pending local record, over RPC with an explorer fallback. */
export async function resolvePendingStatus(
  record: TxRecord
): Promise<TxRecord> {
  const network = NETWORKS[record.networkId];
  if (!network) return record;

  if (network.chainType === "btc") {
    const status = await fetchBitcoinTransactionStatus(record.hash);
    if (!status?.confirmed) return record;
    updateTxRecord(record.hash, {
      status: "confirmed",
      finality: "bitcoin_confirmations",
    });
    return {
      ...record,
      status: "confirmed",
      finality: "bitcoin_confirmations",
    };
  }

  if (network.chainType === "sol") {
    if (!network.rpcUrl) return record;
    try {
      const connection = new Connection(network.rpcUrl, "confirmed");
      const signature = await connection.getSignatureStatus(record.hash, {
        searchTransactionHistory: true,
      });
      const mapped = mapSolanaSignatureStatus(signature.value);
      if (!mapped) return record;
      if (mapped.status === "submitted")
        return { ...record, status: mapped.status };
      updateTxRecord(record.hash, mapped);
      return { ...record, ...mapped };
    } catch {
      return record;
    }
  }

  if (network.chainType !== "evm" || !network.rpcUrl) return record;
  try {
    const provider = new JsonRpcProvider(network.rpcUrl);
    const receipt = await provider.getTransactionReceipt(record.hash);
    if (!receipt) {
      const explorerStatus = await resolveEvmStatusFromBlockscout(record);
      if (explorerStatus) {
        updateTxRecord(record.hash, {
          status: explorerStatus,
          finality: "evm_receipt",
        });
        return { ...record, status: explorerStatus, finality: "evm_receipt" };
      }

      // No receipt yet - normally just "still pending", but every EVM chain this app supports
      // mines blocks in seconds, not weeks. A record still unconfirmed after a full day either
      // never actually broadcast successfully or was dropped by the network - leaving it
      // "Pending" forever at that point is actively misleading, so it's marked Failed instead.
      const ageMs = Date.now() - record.timestamp;
      const STALE_PENDING_MS = 24 * 60 * 60 * 1000;
      if (ageMs > STALE_PENDING_MS) {
        updateTxRecord(record.hash, { status: "dropped" });
        return { ...record, status: "dropped" };
      }
      return record;
    }
    const status: TxStatus = receipt.status === 1 ? "confirmed" : "reverted";
    let feeAmount = record.feeAmount;
    try {
      if (receipt.gasUsed != null && receipt.gasPrice != null) {
        feeAmount = Number(
          formatUnits(receipt.gasUsed * receipt.gasPrice, 18)
        ).toString();
      }
    } catch {
      /* fee is a nice-to-have, not critical */
    }
    // Persist the resolved status - otherwise every future screen load starts back at
    // 'pending' and has to re-resolve via RPC again, even for a tx confirmed weeks ago.
    updateTxRecord(record.hash, {
      status,
      finality: "evm_receipt",
      feeAmount,
      feeSymbol: feeAmount ? network.nativeSymbol : record.feeSymbol,
    });
    return {
      ...record,
      status,
      finality: "evm_receipt",
      feeAmount,
      feeSymbol: feeAmount ? network.nativeSymbol : record.feeSymbol,
    };
  } catch {
    const explorerStatus = await resolveEvmStatusFromBlockscout(record);
    if (explorerStatus) {
      updateTxRecord(record.hash, {
        status: explorerStatus,
        finality: "evm_receipt",
      });
      return { ...record, status: explorerStatus, finality: "evm_receipt" };
    }
    return record; // RPC/indexer hiccup - leave status as-is, next refresh will retry
  }
}

/**
 * The merged view every screen should actually render: local app activity
 * (with real confirmation status resolved) unioned with on-chain history
 * (which catches receives and anything from before/outside this app).
 * Best-effort throughout - a failed indexer or RPC call degrades to
 * "fewer records", never an error screen.
 */
export async function getFullHistory(address: string): Promise<TxRecord[]> {
  const local = getTxRecords();
  const onChainPromise = fetchOnChainHistory(address);

  // Resolve any still-pending local records' real status in parallel with the indexer fetch.
  const resolvedLocal = await Promise.all(
    local.map(r =>
      isTxInFlight(r.status) ? resolvePendingStatus(r) : Promise.resolve(r)
    )
  );
  const onChain = await onChainPromise;

  const byHash = new Map<string, TxRecord>();
  // Seed with on-chain records first - they carry the authoritative confirmed/failed status and fee
  // for plain sends/receives the app didn't originate (or wasn't open to log).
  for (const r of onChain) {
    const key = r.hash.toLowerCase();
    if (!byHash.has(key)) byHash.set(key, r);
  }
  // Layer local records on top. For a swap/bridge/create, the local record is already the
  // complete, authoritative account of what happened - this app built that transaction, so it
  // knows the real destination asset/amount/network. On-chain data can't be trusted to replace
  // it here: Blockscout indexes a single swap as TWO separate ERC-20 transfer legs (token out,
  // token in) sharing the same tx hash, so whichever leg happened to win the dedup race above
  // would silently overwrite the correct fromSymbol/fromAmount/explorerUrl with just one leg's -
  // which is exactly what was showing an empty/wrong explorer link and hash for swaps and
  // bridges. Only a plain send/receive (where the local record might be missing an explorer
  // link, e.g. if it predates that field) benefits from being backed by the on-chain version.
  for (const r of resolvedLocal) {
    const key = r.hash.toLowerCase();
    const onChainMatch = byHash.get(key);
    if (!onChainMatch) {
      byHash.set(key, r);
    } else if (
      r.type === "swap" ||
      r.type === "bridge" ||
      r.type === "create"
    ) {
      byHash.set(key, {
        ...r,
        explorerUrl: r.explorerUrl ?? onChainMatch.explorerUrl,
      });
    } else {
      byHash.set(key, {
        ...onChainMatch,
        type: r.type,
        toSymbol: r.toSymbol ?? onChainMatch.toSymbol,
        toAmount: r.toAmount ?? onChainMatch.toAmount,
        toNetworkId: r.toNetworkId ?? onChainMatch.toNetworkId,
        counterparty: r.counterparty ?? onChainMatch.counterparty,
      });
    }
  }

  return Array.from(byHash.values()).sort((a, b) => b.timestamp - a.timestamp);
}

/**
 * Stale-while-revalidate cache around `getFullHistory`.
 *
 * Blockscout (or the RPC) being slow used to mean every screen just sat on
 * a loading spinner - a cold Dashboard/Transaction Records/Asset Detail
 * open had to wait on a live fetch every single time, even for data that
 * hadn't changed in the last few minutes. This caches the last successful
 * merged result per address in localStorage and serves it instantly, while
 * kicking off a fresh fetch in the background to replace it. So:
 *
 * - Cold start with a cache hit: instant paint from cache + a silent
 *   background refresh.
 * - Cold start with no cache (first time, or a cleared cache): behaves
 *   exactly like before - waits on the live fetch.
 * - Blockscout/RPC is slow or down: the cached list is what's shown,
 *   rather than an empty/loading screen, until (if ever) a refresh
 *   succeeds.
 *
 * Not shared with `getFullHistory` callers who want a guaranteed-fresh
 * result (e.g. right after a manual pull-to-refresh) - they can keep
 * calling `getFullHistory` directly.
 */
const CACHE_KEY_PREFIX = "paxi-tx-cache-";
const CACHE_MAX_AGE_MS = 5 * 60 * 1000; // beyond this, still shown instantly, but treated as "stale" for callers that care

interface CacheEntry {
  records: TxRecord[];
  fetchedAt: number;
}

function cacheKey(address: string): string {
  return `${CACHE_KEY_PREFIX}${address.toLowerCase()}`;
}

function readCache(address: string): CacheEntry | null {
  try {
    const raw = localStorage.getItem(cacheKey(address));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (
      !Array.isArray(parsed?.records) ||
      typeof parsed?.fetchedAt !== "number"
    )
      return null;
    return parsed as CacheEntry;
  } catch {
    return null;
  }
}

function writeCache(address: string, records: TxRecord[]) {
  try {
    localStorage.setItem(
      cacheKey(address),
      JSON.stringify({ records, fetchedAt: Date.now() } satisfies CacheEntry)
    );
  } catch {
    /* localStorage full/unavailable - caching is a nice-to-have, not critical */
  }
}

export interface HistoryLoadResult {
  records: TxRecord[];
  /** true if these records came from cache rather than a fresh fetch (isStale means "shown before this call's own fetch resolved") */
  isStale: boolean;
}

/**
 * Returns cached records immediately (if any) and calls `onFresh` once the
 * real fetch resolves, so a caller can paint fast and then swap in the
 * up-to-date list without ever showing a blank/loading state on a repeat
 * visit. Also updates the cache for next time.
 */
export function getHistoryStaleWhileRevalidate(
  address: string,
  onFresh: (result: HistoryLoadResult) => void
): TxRecord[] {
  const cached = address ? readCache(address) : null;

  getFullHistory(address)
    .then(fresh => {
      writeCache(address, fresh);
      onFresh({ records: fresh, isStale: false });
    })
    .catch(() => {
      // getFullHistory is already best-effort internally and shouldn't throw, but if it somehow
      // does, leave whatever was last painted (cache or nothing) rather than erroring the screen.
    });

  return cached?.records ?? [];
}
