/**
 * The "vault" is the wallet's persisted, encrypted state in localStorage,
 * plus a small in-memory session that holds decrypted mnemonics only
 * while the app is unlocked (never persisted in plaintext, ever).
 *
 * v3 adds multi-wallet support: the vault holds a list of wallet entries
 * (each with its own encrypted mnemonic, or none for watch-only entries)
 * behind a single device PIN, plus an "active wallet" pointer. Every
 * signing wallet on the device is encrypted with the *same* PIN, so
 * switching the active wallet mid-session doesn't require re-entering it.
 */
import { decryptWithKey, decryptWithPIN, encryptWithKey, encryptWithPIN, type EncryptedBlob } from './crypto';
import { clearDeviceKey, getOrCreateDeviceKey } from './deviceKey';
import { generateWallet, importPrivateKey, importWallet as importWalletEngine, isValidAddressForChainType } from './engine';

const VAULT_KEY = 'paxi-wallet-vault';
const BIOMETRIC_KEY = 'paxi-wallet-biometric-pin';
export const BIOMETRIC_CREDENTIAL_KEY = 'paxi-biometric-credential-id';

export interface WalletEntry {
  id: string;
  label: string;
  address: string; // primary EVM address, used as the wallet identifier
  watchOnly: boolean;
  encryptedMnemonic?: EncryptedBlob; // absent for watch-only entries. Holds a raw private key
  // instead of a BIP-39 mnemonic when isPrivateKeyImport is true - same encrypted-string
  // plumbing either way (see engine.ts's walletFromMnemonic, which reads either format).
  isPrivateKeyImport?: boolean; // true = imported via raw private key: EVM-only, no seed, so no BTC/SOL address exists for this entry
  createdAt: number;
}

/** Public, secret-free view of a wallet entry for UI lists. */
export interface WalletSummary {
  id: string;
  label: string;
  address: string;
  watchOnly: boolean;
  isActive: boolean;
  isPrivateKeyImport: boolean;
}

interface VaultRecordV3 {
  version: 3;
  wallets: WalletEntry[];
  activeWalletId: string;
  biometricEnabled: boolean;
}

interface VaultRecordV2 {
  version: 2;
  address: string;
  encryptedMnemonic: EncryptedBlob;
  biometricEnabled: boolean;
}

// In-memory only - cleared on refresh/lock, never written to storage.
const unlockedMnemonics = new Map<string, string>();
let unlockedPin: string | null = null;

function genId(): string {
  return `w_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function readRaw(): VaultRecordV3 | VaultRecordV2 | null {
  const raw = localStorage.getItem(VAULT_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/** Reads the vault, migrating a v2 (single-wallet) record to v3 in place if found. */
function readVault(): VaultRecordV3 | null {
  const record = readRaw();
  if (!record) return null;
  if (record.version === 3) return record;

  // Migrate v2 -> v3: wrap the single wallet as the first entry.
  const v2 = record as VaultRecordV2;
  const migrated: VaultRecordV3 = {
    version: 3,
    wallets: [
      {
        id: genId(),
        label: 'Wallet 1',
        address: v2.address,
        watchOnly: false,
        encryptedMnemonic: v2.encryptedMnemonic,
        createdAt: Date.now(),
      },
    ],
    activeWalletId: '',
    biometricEnabled: v2.biometricEnabled,
  };
  migrated.activeWalletId = migrated.wallets[0].id;
  localStorage.setItem(VAULT_KEY, JSON.stringify(migrated));
  return migrated;
}

function writeVault(record: VaultRecordV3): void {
  localStorage.setItem(VAULT_KEY, JSON.stringify(record));
}

export function hasWallet(): boolean {
  return localStorage.getItem(VAULT_KEY) !== null;
}

function getActiveEntry(vault: VaultRecordV3): WalletEntry | undefined {
  return vault.wallets.find((w) => w.id === vault.activeWalletId);
}

/** Address of the currently-active wallet (signing or watch-only). */
export function getStoredAddress(): string | null {
  const vault = readVault();
  if (!vault) return null;
  return getActiveEntry(vault)?.address ?? null;
}

export function getActiveWalletId(): string | null {
  return readVault()?.activeWalletId ?? null;
}

export function isActiveWalletWatchOnly(): boolean {
  const vault = readVault();
  if (!vault) return false;
  return getActiveEntry(vault)?.watchOnly ?? false;
}

/** True when the active wallet was imported from a raw private key (EVM-only, no seed) -
 * screens that need a Bitcoin or Solana address should treat this the same as "unavailable". */
export function isActiveWalletPrivateKeyImport(): boolean {
  const vault = readVault();
  if (!vault) return false;
  return getActiveEntry(vault)?.isPrivateKeyImport ?? false;
}

/** Secret-free list of every wallet on the device, for the Manage Wallets screen. */
export function getWallets(): WalletSummary[] {
  const vault = readVault();
  if (!vault) return [];
  return vault.wallets.map((w) => ({
    id: w.id,
    label: w.label,
    address: w.address,
    watchOnly: w.watchOnly,
    isActive: w.id === vault.activeWalletId,
    isPrivateKeyImport: w.isPrivateKeyImport ?? false,
  }));
}

export function isBiometricEnabledOnVault(): boolean {
  return readVault()?.biometricEnabled ?? false;
}

/** Create the vault for a brand-new or freshly-imported wallet, and unlock it. `isPrivateKeyImport`
 * marks it as EVM-only (imported from a raw private key rather than a seed phrase) - same
 * encrypted-string storage either way (see WalletEntry's doc comment). */
export async function createVault(mnemonic: string, address: string, pin: string, isPrivateKeyImport = false): Promise<void> {
  const encryptedMnemonic = await encryptWithPIN(mnemonic, pin);
  const entry: WalletEntry = {
    id: genId(),
    label: 'Wallet 1',
    address,
    watchOnly: false,
    isPrivateKeyImport,
    encryptedMnemonic,
    createdAt: Date.now(),
  };
  const record: VaultRecordV3 = {
    version: 3,
    wallets: [entry],
    activeWalletId: entry.id,
    biometricEnabled: false,
  };
  writeVault(record);
  unlockedPin = pin;
  unlockedMnemonics.set(entry.id, mnemonic);
}

/** Unlock with the PIN. Returns the active wallet's mnemonic (or '' if it's watch-only). */
export async function unlockWithPIN(pin: string): Promise<string> {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');

  // Validate the PIN against any signing wallet - they all share one PIN.
  const signingEntry = vault.wallets.find((w) => w.encryptedMnemonic) ?? getActiveEntry(vault);
  if (!signingEntry?.encryptedMnemonic) throw new Error('No signing wallet on this device');
  const verifiedMnemonic = await decryptWithPIN(signingEntry.encryptedMnemonic, pin);

  unlockedPin = pin;
  unlockedMnemonics.clear();
  unlockedMnemonics.set(signingEntry.id, verifiedMnemonic);

  const active = getActiveEntry(vault);
  if (!active) return verifiedMnemonic;
  if (active.id === signingEntry.id) return verifiedMnemonic;
  if (active.watchOnly) return '';
  // Active is a different signing wallet - decrypt it too now that we have the PIN.
  const activeMnemonic = await decryptWithPIN(active.encryptedMnemonic!, pin);
  unlockedMnemonics.set(active.id, activeMnemonic);
  return activeMnemonic;
}

/** Enable biometric unlock: wraps the PIN with a device-bound key, gated by a WebAuthn prompt. */
export async function enableBiometricUnlock(pin: string): Promise<void> {
  const deviceKey = await getOrCreateDeviceKey();
  const wrapped = await encryptWithKey(pin, deviceKey);
  localStorage.setItem(BIOMETRIC_KEY, JSON.stringify(wrapped));

  const vault = readVault();
  if (vault) {
    vault.biometricEnabled = true;
    writeVault(vault);
  }
}

/** Enable biometric unlock using the PIN already verified this session (no re-prompt needed -
 * the person unlocked with it to get here). Throws if the vault is somehow locked. */
export async function enableBiometricForCurrentSession(): Promise<void> {
  if (!unlockedPin) throw new Error('Unlock your wallet first.');
  await enableBiometricUnlock(unlockedPin);
}

export function disableBiometricUnlock(): void {
  localStorage.removeItem(BIOMETRIC_KEY);
  const vault = readVault();
  if (vault) {
    vault.biometricEnabled = false;
    writeVault(vault);
  }
}

/** After a successful WebAuthn assertion, recover the PIN and unlock the vault with it. */
export async function unlockWithBiometric(): Promise<string> {
  const wrappedRaw = localStorage.getItem(BIOMETRIC_KEY);
  if (!wrappedRaw) throw new Error('Biometric unlock is not set up');
  const wrapped = JSON.parse(wrappedRaw) as { ciphertext: string; iv: string };
  const deviceKey = await getOrCreateDeviceKey();
  const pin = await decryptWithKey(wrapped.ciphertext, wrapped.iv, deviceKey);
  return unlockWithPIN(pin);
}

/** Mnemonic of the currently-ACTIVE wallet (null if locked or active is watch-only). */
export function getUnlockedMnemonic(): string | null {
  const vault = readVault();
  if (!vault) return null;
  return unlockedMnemonics.get(vault.activeWalletId) ?? null;
}

export function isUnlocked(): boolean {
  return unlockedPin !== null;
}

export function lock(): void {
  unlockedPin = null;
  unlockedMnemonics.clear();
}

/** Full wipe of every wallet on this device - used for logout / "erase from this device". */
export async function wipeVault(): Promise<void> {
  localStorage.removeItem(VAULT_KEY);
  localStorage.removeItem(BIOMETRIC_KEY);
  localStorage.removeItem(BIOMETRIC_CREDENTIAL_KEY);
  await clearDeviceKey();
  lock();
}

// ---------------------------------------------------------------------------
// Manage Wallets: add / import / watch / rename / delete / switch
// ---------------------------------------------------------------------------

function requirePinMatches(vault: VaultRecordV3, pin: string): Promise<void> {
  const signingEntry = vault.wallets.find((w) => w.encryptedMnemonic);
  if (!signingEntry?.encryptedMnemonic) return Promise.resolve();
  return decryptWithPIN(signingEntry.encryptedMnemonic, pin).then(() => undefined);
}

/** Generate a brand-new signing wallet, add it to the vault, and switch to it. */
export async function addGeneratedWallet(pin: string, label?: string): Promise<WalletSummary> {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  await requirePinMatches(vault, pin); // throws if PIN is wrong

  const generated = generateWallet();
  const entry: WalletEntry = {
    id: genId(),
    label: label?.trim() || `Wallet ${vault.wallets.length + 1}`,
    address: generated.evmAddress,
    watchOnly: false,
    encryptedMnemonic: await encryptWithPIN(generated.mnemonic, pin),
    createdAt: Date.now(),
  };
  vault.wallets.push(entry);
  vault.activeWalletId = entry.id;
  writeVault(vault);
  unlockedPin = pin;
  unlockedMnemonics.set(entry.id, generated.mnemonic);
  return { id: entry.id, label: entry.label, address: entry.address, watchOnly: false, isActive: true, isPrivateKeyImport: false };
}

/** Import an existing signing wallet by recovery phrase, add it, and switch to it. */
export async function addImportedWallet(phrase: string, pin: string, label?: string): Promise<WalletSummary> {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  await requirePinMatches(vault, pin); // throws if PIN is wrong

  const imported = importWalletEngine(phrase); // throws if the phrase is invalid
  if (vault.wallets.some((w) => w.address.toLowerCase() === imported.evmAddress.toLowerCase())) {
    throw new Error('That wallet is already on this device');
  }
  const entry: WalletEntry = {
    id: genId(),
    label: label?.trim() || `Wallet ${vault.wallets.length + 1}`,
    address: imported.evmAddress,
    watchOnly: false,
    encryptedMnemonic: await encryptWithPIN(imported.mnemonic, pin),
    createdAt: Date.now(),
  };
  vault.wallets.push(entry);
  vault.activeWalletId = entry.id;
  writeVault(vault);
  unlockedPin = pin;
  unlockedMnemonics.set(entry.id, imported.mnemonic);
  return { id: entry.id, label: entry.label, address: entry.address, watchOnly: false, isActive: true, isPrivateKeyImport: false };
}

/**
 * Import a single EVM account directly from its raw private key (not a seed phrase), add it,
 * and switch to it. Unlike every other signing wallet in this vault, it has no seed, so it's
 * EVM-only - Send, Swap, Bridge (EVM legs), and Create Token all work normally for it (they
 * all read signing material through getUnlockedMnemonic() and hand it to engine.ts's
 * walletFromMnemonic(), which now accepts a raw private key transparently); Receive/Send on
 * Bitcoin or Solana, and BTC Swap, correctly have no address to offer for this entry.
 */
export async function addImportedPrivateKeyWallet(privateKey: string, pin: string, label?: string): Promise<WalletSummary> {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  await requirePinMatches(vault, pin); // throws if PIN is wrong

  const imported = importPrivateKey(privateKey); // throws if the key is invalid
  if (vault.wallets.some((w) => w.address.toLowerCase() === imported.evmAddress.toLowerCase())) {
    throw new Error('That wallet is already on this device');
  }
  const entry: WalletEntry = {
    id: genId(),
    label: label?.trim() || `Imported ${vault.wallets.length + 1}`,
    address: imported.evmAddress,
    watchOnly: false,
    isPrivateKeyImport: true,
    encryptedMnemonic: await encryptWithPIN(imported.privateKey, pin),
    createdAt: Date.now(),
  };
  vault.wallets.push(entry);
  vault.activeWalletId = entry.id;
  writeVault(vault);
  unlockedPin = pin;
  unlockedMnemonics.set(entry.id, imported.privateKey);
  return { id: entry.id, label: entry.label, address: entry.address, watchOnly: false, isActive: true, isPrivateKeyImport: true };
}

/** Add a read-only entry for an address you don't hold the keys to on this device. */
export function addWatchOnlyWallet(address: string, label?: string): WalletSummary {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  const trimmed = address.trim();
  if (!isValidAddressForChainType(trimmed, 'evm')) throw new Error('Enter a valid EVM address (0x…)');
  if (vault.wallets.some((w) => w.address.toLowerCase() === trimmed.toLowerCase())) {
    throw new Error('That address is already on this device');
  }
  const entry: WalletEntry = {
    id: genId(),
    label: label?.trim() || `Watched ${vault.wallets.filter((w) => w.watchOnly).length + 1}`,
    address: trimmed,
    watchOnly: true,
    createdAt: Date.now(),
  };
  vault.wallets.push(entry);
  writeVault(vault);
  return { id: entry.id, label: entry.label, address: entry.address, watchOnly: true, isActive: vault.activeWalletId === entry.id, isPrivateKeyImport: false };
}

export function renameWallet(id: string, label: string): void {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  const entry = vault.wallets.find((w) => w.id === id);
  if (!entry) throw new Error('Wallet not found');
  const trimmed = label.trim();
  if (!trimmed) throw new Error('Label cannot be empty');
  entry.label = trimmed;
  writeVault(vault);
}

/** Switch the active wallet. Decrypts its mnemonic on the fly if the PIN is already cached. */
export async function switchActiveWallet(id: string): Promise<void> {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  const entry = vault.wallets.find((w) => w.id === id);
  if (!entry) throw new Error('Wallet not found');

  vault.activeWalletId = id;
  writeVault(vault);

  if (!entry.watchOnly && entry.encryptedMnemonic && !unlockedMnemonics.has(id) && unlockedPin) {
    const mnemonic = await decryptWithPIN(entry.encryptedMnemonic, unlockedPin);
    unlockedMnemonics.set(id, mnemonic);
  }
}

/**
 * Remove a wallet from this device. A signing wallet can't be removed if it's
 * the last one left (use "Remove wallet from device" in Settings for that -
 * it's a deliberate, separate full-logout action).
 */
export function deleteWallet(id: string): void {
  const vault = readVault();
  if (!vault) throw new Error('No wallet found on this device');
  const entry = vault.wallets.find((w) => w.id === id);
  if (!entry) throw new Error('Wallet not found');

  const signingCount = vault.wallets.filter((w) => !w.watchOnly).length;
  if (!entry.watchOnly && signingCount <= 1) {
    throw new Error('This is your only wallet. Use "Remove wallet from device" in Settings to erase it instead.');
  }

  vault.wallets = vault.wallets.filter((w) => w.id !== id);
  unlockedMnemonics.delete(id);
  if (vault.activeWalletId === id) {
    const next = vault.wallets.find((w) => !w.watchOnly) ?? vault.wallets[0];
    vault.activeWalletId = next.id;
  }
  writeVault(vault);
}
