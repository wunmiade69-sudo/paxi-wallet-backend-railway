import { describe, expect, it } from "vitest";
import { WC_ENABLED, validateWalletConnectRequest } from "./walletconnect";

const account = "0x1111111111111111111111111111111111111111";
const recipient = "0x2222222222222222222222222222222222222222";
const chainId = "eip155:1";

function validate(
  method: string,
  params: unknown,
  overrides: Partial<{ chainId: string; evmAddress: string }> = {}
) {
  return validateWalletConnectRequest({
    method,
    params,
    chainId: overrides.chainId ?? chainId,
    evmAddress: overrides.evmAddress ?? account,
  });
}

describe("WalletConnect request boundary", () => {
  it("accepts a valid transaction request but marks it not simulated", () => {
    expect(
      validate("eth_sendTransaction", [
        { from: account, to: recipient, value: "0x1", data: "0x" },
      ])
    ).toEqual({
      valid: true,
      simulation: "not_simulated",
      summary: expect.stringContaining("not simulated"),
    });
  });

  it("rejects an unsupported chain", () => {
    expect(
      validate("eth_sendTransaction", [{ to: recipient }], {
        chainId: "eip155:999999",
      })
    ).toMatchObject({
      valid: false,
      reason: expect.stringContaining("Unsupported WalletConnect chain"),
    });
  });

  it("rejects an unsupported method", () => {
    expect(
      validate("wallet_switchEthereumChain", [{ chainId: "0x1" }])
    ).toMatchObject({
      valid: false,
      reason: expect.stringContaining("Unsupported WalletConnect method"),
    });
  });

  it("rejects malformed transaction requests", () => {
    expect(
      validate("eth_sendTransaction", [{ from: account, to: "not-an-address" }])
    ).toMatchObject({
      valid: false,
      summary: "Transaction recipient is invalid",
    });
  });

  it("accepts personal_sign only for the active wallet account", () => {
    expect(validate("personal_sign", ["Hello PAXI", account])).toMatchObject({
      valid: true,
      simulation: "not_simulated",
    });
    expect(validate("personal_sign", ["Hello PAXI", recipient])).toMatchObject({
      valid: false,
      reason: expect.stringContaining("does not match"),
    });
  });

  it("accepts valid typed-data signing and rejects malformed typed data", () => {
    expect(
      validate("eth_signTypedData_v4", [
        account,
        JSON.stringify({ domain: {}, types: {}, message: {} }),
      ])
    ).toMatchObject({
      valid: true,
      simulation: "not_simulated",
    });
    expect(
      validate("eth_signTypedData_v4", [account, "{bad-json"])
    ).toMatchObject({ valid: false, summary: "Malformed dApp request" });
  });

  it("accepts eth_sign only for a hex payload and matching account", () => {
    expect(validate("eth_sign", [account, "0x1234"])).toMatchObject({
      valid: true,
      simulation: "not_simulated",
    });
    expect(validate("eth_sign", [account, "plain text"])).toMatchObject({
      valid: false,
    });
  });

  it("keeps WalletConnect disabled for the current controlled beta", () => {
    expect(WC_ENABLED).toBe(false);
  });
});
