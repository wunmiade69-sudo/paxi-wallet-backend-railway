/**
 * WalletConnect v2, wallet side - this is the real, standard way a wallet
 * without browser-injection capability (i.e. any wallet that isn't a
 * native app with its own WebView) connects to third-party dApps. No
 * iframe, no injected window.ethereum - a dApp shows a WalletConnect URI
 * (as a QR code or copyable string), the user brings it here, and an
 * encrypted session is established through WalletConnect's relay.
 *
 * CRITICAL: this module never signs anything on its own. Every incoming
 * request (session_proposal, session_request) is surfaced as a pending
 * item for the UI to show the user, who must explicitly approve or
 * reject it. Auto-approving would defeat the entire point of a wallet.
 *
 * Needs a free WalletConnect Cloud Project ID (cloud.walletconnect.com /
 * cloud.reown.com) - set WC_PROJECT_ID below before this can actually pair.
 */
import {
  getAddress,
  getBytes,
  isAddress,
  isHexString,
  JsonRpcProvider,
  toUtf8String,
} from "ethers";
import { walletFromMnemonic } from "./engine";
import { NETWORKS } from "./chains";

export const WC_PROJECT_ID =
  (import.meta.env.VITE_WC_PROJECT_ID as string | undefined)?.trim() ?? "";
// WalletConnect signing is not approved for the current controlled beta. Keep this
// hard-disabled until a dedicated approval UI and PAXI security-scan gate exist.
export const WC_ENABLED = false;

/** eip155 chain id -> our internal network id, for the chains we support signing on. */
const EIP155_TO_NETWORK: Record<string, string> = {
  "eip155:1": "ethereum",
  "eip155:56": "bsc",
  "eip155:137": "polygon",
  "eip155:42161": "arbitrum",
};
const SUPPORTED_EIP155_CHAINS = Object.keys(EIP155_TO_NETWORK);

export interface DappMetadata {
  name: string;
  description?: string;
  url: string;
  icons: string[];
}

export interface PendingProposal {
  id: number;
  dapp: DappMetadata;
  requestedChains: string[];
}

export interface PendingRequest {
  id: number;
  topic: string;
  dapp: DappMetadata;
  method: string;
  chainId: string;
  params: any;
  /** Human-readable summary for the approval screen - e.g. "Send 0.1 ETH to 0x1234…5678". */
  summary: string;
}

export interface ActiveSession {
  topic: string;
  dapp: DappMetadata;
  chains: string[];
}

type Listener = () => void;

export type WalletConnectRequestValidation =
  | { valid: true; simulation: "not_simulated"; summary: string }
  | { valid: false; reason: string; summary: string };

const WALLETCONNECT_METHODS = new Set([
  "eth_sendTransaction",
  "personal_sign",
  "eth_sign",
  "eth_signTypedData",
  "eth_signTypedData_v4",
]);

function isHexQuantity(value: unknown): value is string {
  return typeof value === "string" && /^0x[0-9a-fA-F]+$/.test(value);
}

function shortAddress(address: string): string {
  return `${address.slice(0, 6)}…${address.slice(-4)}`;
}

/**
 * Validate a request before it reaches any signing primitive. Simulation is
 * intentionally not claimed here; enabled beta builds must show that state.
 */
export function validateWalletConnectRequest(input: {
  method: string;
  chainId: string;
  params: unknown;
  evmAddress: string;
}): WalletConnectRequestValidation {
  if (!SUPPORTED_EIP155_CHAINS.includes(input.chainId)) {
    return {
      valid: false,
      reason: `Unsupported WalletConnect chain: ${input.chainId}`,
      summary: "Request targets an unsupported network",
    };
  }
  if (!WALLETCONNECT_METHODS.has(input.method)) {
    return {
      valid: false,
      reason: `Unsupported WalletConnect method: ${input.method}`,
      summary: `Unsupported request method: ${input.method}`,
    };
  }
  if (!Array.isArray(input.params)) {
    return {
      valid: false,
      reason: "WalletConnect request parameters must be an array",
      summary: "Malformed dApp request",
    };
  }

  try {
    if (input.method === "eth_sendTransaction") {
      const tx = input.params[0];
      if (
        !tx ||
        typeof tx !== "object" ||
        !isAddress((tx as { to?: unknown }).to)
      ) {
        return {
          valid: false,
          reason: "Transaction recipient is invalid",
          summary: "Transaction recipient is invalid",
        };
      }
      const transaction = tx as {
        to: string;
        from?: unknown;
        data?: unknown;
        value?: unknown;
        gas?: unknown;
      };
      if (
        transaction.from !== undefined &&
        (!isAddress(transaction.from) ||
          getAddress(transaction.from) !== getAddress(input.evmAddress))
      ) {
        return {
          valid: false,
          reason: "Transaction sender does not match this wallet",
          summary: "Transaction sender does not match this wallet",
        };
      }
      if (
        transaction.data !== undefined &&
        (typeof transaction.data !== "string" || !isHexString(transaction.data))
      ) {
        return {
          valid: false,
          reason: "Transaction data is invalid",
          summary: "Transaction data is invalid",
        };
      }
      if (
        transaction.value !== undefined &&
        !isHexQuantity(transaction.value)
      ) {
        return {
          valid: false,
          reason: "Transaction value is invalid",
          summary: "Transaction value is invalid",
        };
      }
      if (transaction.gas !== undefined && !isHexQuantity(transaction.gas)) {
        return {
          valid: false,
          reason: "Transaction gas is invalid",
          summary: "Transaction gas is invalid",
        };
      }
      return {
        valid: true,
        simulation: "not_simulated",
        summary: `Send transaction to ${shortAddress(getAddress(transaction.to))}${transaction.value ? ` with value ${transaction.value}` : ""} (not simulated)`,
      };
    }

    if (input.method === "personal_sign") {
      const [message, address] = input.params;
      if (typeof message !== "string" || !isAddress(address)) {
        return {
          valid: false,
          reason: "personal_sign requires message and account parameters",
          summary: "Malformed personal signature request",
        };
      }
      if (getAddress(address) !== getAddress(input.evmAddress)) {
        return {
          valid: false,
          reason: "Signing account does not match this wallet",
          summary: "Signing account does not match this wallet",
        };
      }
      return {
        valid: true,
        simulation: "not_simulated",
        summary: "Sign personal message (not simulated)",
      };
    }

    if (input.method === "eth_sign") {
      const [address, message] = input.params;
      if (
        !isAddress(address) ||
        typeof message !== "string" ||
        !isHexString(message)
      ) {
        return {
          valid: false,
          reason: "eth_sign requires account and hex message parameters",
          summary: "Malformed message-signing request",
        };
      }
      if (getAddress(address) !== getAddress(input.evmAddress)) {
        return {
          valid: false,
          reason: "Signing account does not match this wallet",
          summary: "Signing account does not match this wallet",
        };
      }
      return {
        valid: true,
        simulation: "not_simulated",
        summary: "Sign message (not simulated)",
      };
    }

    const [address, typedDataInput] = input.params;
    if (
      !isAddress(address) ||
      getAddress(address) !== getAddress(input.evmAddress)
    ) {
      return {
        valid: false,
        reason: "Typed-data signing account does not match this wallet",
        summary: "Typed-data account does not match this wallet",
      };
    }
    const typedData =
      typeof typedDataInput === "string"
        ? JSON.parse(typedDataInput)
        : typedDataInput;
    if (!typedData || typeof typedData !== "object")
      throw new Error("Typed data must be an object");
    return {
      valid: true,
      simulation: "not_simulated",
      summary: "Sign typed data (not simulated)",
    };
  } catch (error) {
    return {
      valid: false,
      reason:
        error instanceof Error
          ? error.message
          : "Malformed WalletConnect request",
      summary: "Malformed dApp request",
    };
  }
}

class WalletConnectManager {
  private web3wallet: any = null;
  private initPromise: Promise<any> | null = null;
  private mnemonic: string | null = null;
  private evmAddress = "";

  pendingProposal: PendingProposal | null = null;
  pendingRequest: PendingRequest | null = null;
  sessions: ActiveSession[] = [];
  version = 0;
  private listeners = new Set<Listener>();

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private notify() {
    this.version++;
    this.listeners.forEach(fn => fn());
  }

  setSigner(mnemonic: string, evmAddress: string) {
    if (!mnemonic || !isAddress(evmAddress))
      throw new Error("Invalid WalletConnect signer state");
    this.mnemonic = mnemonic;
    this.evmAddress = getAddress(evmAddress);
  }

  clearSigner() {
    this.mnemonic = null;
    this.evmAddress = "";
    this.pendingRequest = null;
    this.notify();
  }

  private async getClient() {
    if (this.web3wallet) return this.web3wallet;
    if (this.initPromise) return this.initPromise;

    if (!WC_ENABLED) {
      throw new Error("WalletConnect is disabled for the controlled beta.");
    }
    if (!WC_PROJECT_ID) {
      throw new Error(
        "WalletConnect is not configured yet - a Project ID is needed (see walletconnect.ts)."
      );
    }

    this.initPromise = (async () => {
      const { Core } = await import("@walletconnect/core");
      const { Web3Wallet } = await import("@walletconnect/web3wallet");

      const core = new Core({ projectId: WC_PROJECT_ID });
      const client = await Web3Wallet.init({
        core: core as any,
        metadata: {
          name: "Paxi Wallet",
          description: "Paxi Wallet - multi-chain crypto wallet",
          url: "https://paxiwallet.app",
          icons: [],
        },
      });

      client.on("session_proposal", (event: any) =>
        this.handleSessionProposal(event)
      );
      client.on("session_request", (event: any) =>
        this.handleSessionRequest(event)
      );
      client.on("session_delete", () => this.refreshSessions());

      this.web3wallet = client;
      this.refreshSessions();
      return client;
    })().catch(error => {
      this.initPromise = null;
      throw error;
    });

    return this.initPromise;
  }

  private refreshSessions() {
    if (!this.web3wallet) return;
    const active = this.web3wallet.getActiveSessions();
    this.sessions = Object.values(active).map((s: any) => ({
      topic: s.topic,
      dapp: s.peer.metadata,
      chains: Object.keys(s.namespaces).flatMap(ns =>
        s.namespaces[ns].accounts.map((a: string) =>
          a.split(":").slice(0, 2).join(":")
        )
      ),
    }));
    this.notify();
  }

  async pair(uri: string) {
    const normalized = uri.trim();
    if (!normalized.startsWith("wc:") || normalized.length > 4096)
      throw new Error("Invalid WalletConnect URI");
    const client = await this.getClient();
    await client.core.pairing.pair({ uri: normalized });
  }

  private handleSessionProposal(event: any) {
    const { id, params } = event;
    const requestedChains: string[] = Object.values(
      params.requiredNamespaces ?? {}
    )
      .concat(Object.values(params.optionalNamespaces ?? {}))
      .flatMap((ns: any) => ns.chains ?? []);

    this.pendingProposal = {
      id,
      dapp: params.proposer.metadata,
      requestedChains: [...new Set(requestedChains)],
    };
    (this as any)._lastProposalParams = params;
    this.notify();
  }

  async approveProposal() {
    if (!this.pendingProposal || !this.web3wallet) return;
    const { buildApprovedNamespaces } = await import("@walletconnect/utils");

    const supportedChains = this.pendingProposal.requestedChains.filter(c =>
      SUPPORTED_EIP155_CHAINS.includes(c)
    );
    if (supportedChains.length === 0)
      throw new Error("This dApp does not request a supported EVM network.");
    const chainsToOffer = supportedChains;

    const namespaces = buildApprovedNamespaces({
      proposal: {
        id: this.pendingProposal.id,
        params: (this as any)._lastProposalParams,
      } as any,
      supportedNamespaces: {
        eip155: {
          chains: chainsToOffer,
          methods: [
            "eth_sendTransaction",
            "personal_sign",
            "eth_sign",
            "eth_signTypedData",
            "eth_signTypedData_v4",
          ],
          events: ["chainChanged", "accountsChanged"],
          accounts: chainsToOffer.map(c => `${c}:${this.evmAddress}`),
        },
      },
    });

    await this.web3wallet.approveSession({
      id: this.pendingProposal.id,
      namespaces,
    });
    this.pendingProposal = null;
    this.refreshSessions();
  }

  async rejectProposal() {
    if (!this.pendingProposal || !this.web3wallet) return;
    const { getSdkError } = await import("@walletconnect/utils");
    await this.web3wallet.rejectSession({
      id: this.pendingProposal.id,
      reason: getSdkError("USER_REJECTED"),
    });
    this.pendingProposal = null;
    this.notify();
  }

  private handleSessionRequest(event: any) {
    const { id, topic, params } = event;
    const session = this.web3wallet.engine.signClient.session.get(topic);
    const { request, chainId } = params;
    const validation = validateWalletConnectRequest({
      method: request?.method,
      chainId,
      params: request?.params,
      evmAddress: this.evmAddress,
    });
    const network = EIP155_TO_NETWORK[chainId];
    const summary = validation.valid
      ? `${request.method} on ${network ?? chainId}: ${validation.summary}`
      : validation.summary;

    this.pendingRequest = {
      id,
      topic,
      dapp: session?.peer.metadata ?? {
        name: "Unknown dApp",
        url: "",
        icons: [],
      },
      method: request.method,
      chainId,
      params: request?.params,
      summary: validation.valid
        ? summary
        : `Security review required: ${summary}`,
    };
    this.notify();
  }

  async approveRequest() {
    if (!this.pendingRequest || !this.web3wallet || !this.mnemonic) return;
    const { id, topic, method, chainId, params } = this.pendingRequest;

    try {
      const validation = validateWalletConnectRequest({
        method,
        chainId,
        params,
        evmAddress: this.evmAddress,
      });
      if (!validation.valid) throw new Error(validation.reason);
      let result: string;
      const wallet = walletFromMnemonic(this.mnemonic);

      if (method === "personal_sign") {
        const message = params[0];
        result = await wallet.signMessage(
          isHexData(message) ? getBytes(message) : message
        );
      } else if (method === "eth_sign") {
        result = await wallet.signMessage(getBytes(params[1]));
      } else if (
        method === "eth_signTypedData_v4" ||
        method === "eth_signTypedData"
      ) {
        const typedData =
          typeof params[1] === "string" ? JSON.parse(params[1]) : params[1];
        const { domain, types, message } = typedData;
        const cleanTypes = { ...types };
        delete cleanTypes.EIP712Domain;
        result = await wallet.signTypedData(domain, cleanTypes, message);
      } else if (method === "eth_sendTransaction") {
        const network = EIP155_TO_NETWORK[chainId];
        const rpcUrl = network ? NETWORKS[network]?.rpcUrl : undefined;
        if (!rpcUrl) throw new Error(`No RPC configured for ${chainId}`);
        const provider = new JsonRpcProvider(rpcUrl);
        const signer = wallet.connect(provider);
        const tx = params[0];
        if (!tx || typeof tx !== "object" || !isAddress(tx.to))
          throw new Error("Transaction recipient is invalid");
        const sent = await signer.sendTransaction({
          to: getAddress(tx.to),
          value: tx.value ? BigInt(tx.value) : undefined,
          data: tx.data,
          gasLimit: tx.gas ? BigInt(tx.gas) : undefined,
        });
        result = sent.hash;
      } else {
        throw new Error(`Unsupported method: ${method}`);
      }

      await this.web3wallet.respondSessionRequest({
        topic,
        response: { id, jsonrpc: "2.0", result },
      });
    } catch (err) {
      const { getSdkError } = await import("@walletconnect/utils");
      await this.web3wallet.respondSessionRequest({
        topic,
        response: {
          id,
          jsonrpc: "2.0",
          error: {
            code: 5000,
            message: err instanceof Error ? err.message : "Signing failed",
          },
        },
      });
    }

    this.pendingRequest = null;
    this.notify();
  }

  async rejectRequest() {
    if (!this.pendingRequest || !this.web3wallet) return;
    const { getSdkError } = await import("@walletconnect/utils");
    await this.web3wallet.respondSessionRequest({
      topic: this.pendingRequest.topic,
      response: {
        id: this.pendingRequest.id,
        jsonrpc: "2.0",
        error: getSdkError("USER_REJECTED"),
      },
    });
    this.pendingRequest = null;
    this.notify();
  }

  async disconnectSession(topic: string) {
    if (!this.web3wallet) return;
    const { getSdkError } = await import("@walletconnect/utils");
    await this.web3wallet.disconnectSession({
      topic,
      reason: getSdkError("USER_DISCONNECTED"),
    });
    this.refreshSessions();
  }
}

function isHexData(str: string): boolean {
  return typeof str === "string" && str.startsWith("0x");
}
function hexToBytes(hex: string): Uint8Array {
  if (!isHexString(hex)) throw new Error("Invalid hex payload");
  return getBytes(hex);
}

export const walletConnectManager = new WalletConnectManager();
