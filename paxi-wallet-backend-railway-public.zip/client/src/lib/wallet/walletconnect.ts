/**
 * WalletConnect v2, wallet side - this is the real, standard way a wallet
 * without browser-injection capability (i.e. any wallet that isn't a
 * native app with its own WebView) connects to third-party dApps. No
 * iframe, no injected window.ethereum - a dApp shows a WalletConnect URI
 * (as a QR code or copyable string), the user brings it here, and an
 * encrypted session is established through WalletConnect's relay.
 *
 * CRITICAL: this module never signs anything on its own. Every incoming
 * request (session_proposal, session_request) is surfaced as a pending
 * item for the UI to show the user, who must explicitly approve or
 * reject it. Auto-approving would defeat the entire point of a wallet.
 *
 * Needs a free WalletConnect Cloud Project ID (cloud.walletconnect.com /
 * cloud.reown.com) - set WC_PROJECT_ID below before this can actually pair.
 */
import { getAddress, getBytes, isAddress, isHexString, JsonRpcProvider, toUtf8String } from 'ethers';
import { walletFromMnemonic } from './engine';
import { NETWORKS } from './chains';

export const WC_PROJECT_ID = (import.meta.env.VITE_WC_PROJECT_ID as string | undefined)?.trim() ?? '';

/** eip155 chain id -> our internal network id, for the chains we support signing on. */
const EIP155_TO_NETWORK: Record<string, string> = {
  'eip155:1': 'ethereum',
  'eip155:56': 'bsc',
  'eip155:137': 'polygon',
  'eip155:42161': 'arbitrum',
};
const SUPPORTED_EIP155_CHAINS = Object.keys(EIP155_TO_NETWORK);

export interface DappMetadata {
  name: string;
  description?: string;
  url: string;
  icons: string[];
}

export interface PendingProposal {
  id: number;
  dapp: DappMetadata;
  requestedChains: string[];
}

export interface PendingRequest {
  id: number;
  topic: string;
  dapp: DappMetadata;
  method: string;
  chainId: string;
  params: any;
  /** Human-readable summary for the approval screen - e.g. "Send 0.1 ETH to 0x1234…5678". */
  summary: string;
}

export interface ActiveSession {
  topic: string;
  dapp: DappMetadata;
  chains: string[];
}

type Listener = () => void;

class WalletConnectManager {
  private web3wallet: any = null;
  private initPromise: Promise<any> | null = null;
  private mnemonic: string | null = null;
  private evmAddress = '';

  pendingProposal: PendingProposal | null = null;
  pendingRequest: PendingRequest | null = null;
  sessions: ActiveSession[] = [];
  version = 0;
  private listeners = new Set<Listener>();

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  private notify() {
    this.version++;
    this.listeners.forEach((fn) => fn());
  }

  setSigner(mnemonic: string, evmAddress: string) {
    if (!mnemonic || !isAddress(evmAddress)) throw new Error('Invalid WalletConnect signer state');
    this.mnemonic = mnemonic;
    this.evmAddress = getAddress(evmAddress);
  }

  clearSigner() {
    this.mnemonic = null;
    this.evmAddress = '';
    this.pendingRequest = null;
    this.notify();
  }

  private async getClient() {
    if (this.web3wallet) return this.web3wallet;
    if (this.initPromise) return this.initPromise;

    if (!WC_PROJECT_ID) {
      throw new Error('WalletConnect is not configured yet - a Project ID is needed (see walletconnect.ts).');
    }

    this.initPromise = (async () => {
      const { Core } = await import('@walletconnect/core');
      const { Web3Wallet } = await import('@walletconnect/web3wallet');

      const core = new Core({ projectId: WC_PROJECT_ID });
      const client = await Web3Wallet.init({
        core: core as any,
        metadata: {
          name: 'Paxi Wallet',
          description: 'Paxi Wallet - multi-chain crypto wallet',
          url: 'https://paxiwallet.app',
          icons: [],
        },
      });

      client.on('session_proposal', (event: any) => this.handleSessionProposal(event));
      client.on('session_request', (event: any) => this.handleSessionRequest(event));
      client.on('session_delete', () => this.refreshSessions());

      this.web3wallet = client;
      this.refreshSessions();
      return client;
    })().catch((error) => {
      this.initPromise = null;
      throw error;
    });

    return this.initPromise;
  }

  private refreshSessions() {
    if (!this.web3wallet) return;
    const active = this.web3wallet.getActiveSessions();
    this.sessions = Object.values(active).map((s: any) => ({
      topic: s.topic,
      dapp: s.peer.metadata,
      chains: Object.keys(s.namespaces).flatMap((ns) => s.namespaces[ns].accounts.map((a: string) => a.split(':').slice(0, 2).join(':'))),
    }));
    this.notify();
  }

  async pair(uri: string) {
    const normalized = uri.trim();
    if (!normalized.startsWith('wc:') || normalized.length > 4096) throw new Error('Invalid WalletConnect URI');
    const client = await this.getClient();
    await client.core.pairing.pair({ uri: normalized });
  }

  private handleSessionProposal(event: any) {
    const { id, params } = event;
    const requestedChains: string[] = Object.values(params.requiredNamespaces ?? {})
      .concat(Object.values(params.optionalNamespaces ?? {}))
      .flatMap((ns: any) => ns.chains ?? []);

    this.pendingProposal = {
      id,
      dapp: params.proposer.metadata,
      requestedChains: [...new Set(requestedChains)],
    };
    (this as any)._lastProposalParams = params;
    this.notify();
  }

  async approveProposal() {
    if (!this.pendingProposal || !this.web3wallet) return;
    const { buildApprovedNamespaces } = await import('@walletconnect/utils');

    const supportedChains = this.pendingProposal.requestedChains.filter((c) => SUPPORTED_EIP155_CHAINS.includes(c));
    if (supportedChains.length === 0) throw new Error('This dApp does not request a supported EVM network.');
    const chainsToOffer = supportedChains;

    const namespaces = buildApprovedNamespaces({
      proposal: { id: this.pendingProposal.id, params: (this as any)._lastProposalParams } as any,
      supportedNamespaces: {
        eip155: {
          chains: chainsToOffer,
          methods: ['eth_sendTransaction', 'personal_sign', 'eth_sign', 'eth_signTypedData', 'eth_signTypedData_v4'],
          events: ['chainChanged', 'accountsChanged'],
          accounts: chainsToOffer.map((c) => `${c}:${this.evmAddress}`),
        },
      },
    });

    await this.web3wallet.approveSession({ id: this.pendingProposal.id, namespaces });
    this.pendingProposal = null;
    this.refreshSessions();
  }

  async rejectProposal() {
    if (!this.pendingProposal || !this.web3wallet) return;
    const { getSdkError } = await import('@walletconnect/utils');
    await this.web3wallet.rejectSession({ id: this.pendingProposal.id, reason: getSdkError('USER_REJECTED') });
    this.pendingProposal = null;
    this.notify();
  }

  private handleSessionRequest(event: any) {
    const { id, topic, params } = event;
    const session = this.web3wallet.engine.signClient.session.get(topic);
    const { request, chainId } = params;

    let summary = `${request.method} request`;
    if (request.method === 'eth_sendTransaction') {
      const tx = request.params[0];
      const network = EIP155_TO_NETWORK[chainId];
      const valueEth = tx.value ? Number(BigInt(tx.value)) / 1e18 : 0;
      summary = `Send transaction on ${network ?? chainId} to ${tx.to?.slice(0, 6)}…${tx.to?.slice(-4)}${tx.value ? ` (~${valueEth} ETH/BNB)` : ''}`;
    } else if (request.method === 'personal_sign') {
      try {
        summary = `Sign message: "${toUtf8String(request.params[0]).slice(0, 80)}"`;
      } catch {
        summary = 'Sign message (binary data)';
      }
    } else if (request.method.startsWith('eth_signTypedData')) {
      summary = 'Sign typed data (structured message, e.g. a permit or order)';
    }

    this.pendingRequest = {
      id,
      topic,
      dapp: session?.peer.metadata ?? { name: 'Unknown dApp', url: '', icons: [] },
      method: request.method,
      chainId,
      params: request.params,
      summary,
    };
    this.notify();
  }

  async approveRequest() {
    if (!this.pendingRequest || !this.web3wallet || !this.mnemonic) return;
    const { id, topic, method, chainId, params } = this.pendingRequest;

    try {
      let result: string;
      const wallet = walletFromMnemonic(this.mnemonic);
      if (!SUPPORTED_EIP155_CHAINS.includes(chainId)) throw new Error(`Unsupported WalletConnect chain: ${chainId}`);

      if (method === 'personal_sign') {
        const message = params[0];
        if (typeof message !== 'string' || (isHexData(message) && !isHexString(message))) throw new Error('Invalid personal_sign payload');
        result = await wallet.signMessage(isHexData(message) ? getBytes(message) : message);
      } else if (method === 'eth_sign') {
        if (typeof params[1] !== 'string' || !isHexString(params[1])) throw new Error('Invalid eth_sign payload');
        result = await wallet.signMessage(getBytes(params[1]));
      } else if (method === 'eth_signTypedData_v4' || method === 'eth_signTypedData') {
        const typedData = typeof params[1] === 'string' ? JSON.parse(params[1]) : params[1];
        const { domain, types, message } = typedData;
        const cleanTypes = { ...types };
        delete cleanTypes.EIP712Domain;
        result = await wallet.signTypedData(domain, cleanTypes, message);
      } else if (method === 'eth_sendTransaction') {
        const network = EIP155_TO_NETWORK[chainId];
        const rpcUrl = network ? NETWORKS[network]?.rpcUrl : undefined;
        if (!rpcUrl) throw new Error(`No RPC configured for ${chainId}`);
        const provider = new JsonRpcProvider(rpcUrl);
        const signer = wallet.connect(provider);
        const tx = params[0];
        if (!tx || typeof tx !== 'object' || !isAddress(tx.to)) throw new Error('Transaction recipient is invalid');
        if (tx.from && (!isAddress(tx.from) || getAddress(tx.from) !== getAddress(this.evmAddress))) {
          throw new Error('Transaction sender does not match this wallet');
        }
        if (tx.data !== undefined && (typeof tx.data !== 'string' || !isHexString(tx.data))) throw new Error('Transaction data is invalid');
        if (tx.value !== undefined && (typeof tx.value !== 'string' || !/^0x[0-9a-fA-F]+$/.test(tx.value))) throw new Error('Transaction value is invalid');
        if (tx.gas !== undefined && (typeof tx.gas !== 'string' || !/^0x[0-9a-fA-F]+$/.test(tx.gas))) throw new Error('Transaction gas is invalid');
        const sent = await signer.sendTransaction({
          to: getAddress(tx.to),
          value: tx.value ? BigInt(tx.value) : undefined,
          data: tx.data,
          gasLimit: tx.gas ? BigInt(tx.gas) : undefined,
        });
        result = sent.hash;
      } else {
        throw new Error(`Unsupported method: ${method}`);
      }

      await this.web3wallet.respondSessionRequest({ topic, response: { id, jsonrpc: '2.0', result } });
    } catch (err) {
      const { getSdkError } = await import('@walletconnect/utils');
      await this.web3wallet.respondSessionRequest({
        topic,
        response: { id, jsonrpc: '2.0', error: { code: 5000, message: err instanceof Error ? err.message : 'Signing failed' } },
      });
    }

    this.pendingRequest = null;
    this.notify();
  }

  async rejectRequest() {
    if (!this.pendingRequest || !this.web3wallet) return;
    const { getSdkError } = await import('@walletconnect/utils');
    await this.web3wallet.respondSessionRequest({
      topic: this.pendingRequest.topic,
      response: { id: this.pendingRequest.id, jsonrpc: '2.0', error: getSdkError('USER_REJECTED') },
    });
    this.pendingRequest = null;
    this.notify();
  }

  async disconnectSession(topic: string) {
    if (!this.web3wallet) return;
    const { getSdkError } = await import('@walletconnect/utils');
    await this.web3wallet.disconnectSession({ topic, reason: getSdkError('USER_DISCONNECTED') });
    this.refreshSessions();
  }
}

function isHexData(str: string): boolean {
  return typeof str === 'string' && str.startsWith('0x');
}
function hexToBytes(hex: string): Uint8Array {
  if (!isHexString(hex)) throw new Error('Invalid hex payload');
  return getBytes(hex);
}

export const walletConnectManager = new WalletConnectManager();
