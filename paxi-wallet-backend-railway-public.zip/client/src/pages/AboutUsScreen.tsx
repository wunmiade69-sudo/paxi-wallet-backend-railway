import { ArrowLeft, ExternalLink, Mail, MapPin, MessagesSquare, Send } from 'lucide-react';
import { toast } from 'sonner';
import { ABOUT_LINKS, APP_BUILD_NAME, APP_VERSION, SUPPORT_EMAIL, TOKEN_STORY } from '@/lib/appInfo';

interface AboutUsScreenProps {
  onBack: () => void;
}

const founderStory = [
  'Hello everyone,',
  "I think it's time for me to properly introduce myself.",
  'My name is Adewunmi Joel, and I am the person who started the PAXI ecosystem.',
  'I am from Nigeria, and PAXI started from a simple idea: I wanted to build something of my own in Web3 rather than simply watching other people build.',
  'PAXI was not created because I had a huge company, a large team, or millions of dollars behind me.',
  'It started with an idea, a phone/laptop, learning, experimenting, making mistakes, fixing things, and continuing to build.',
  'Over time, that idea became bigger.',
  'Today, I see PAXI as more than just a token. I want to build an ecosystem that can include a blockchain, wallet, payments, applications, community programs, and other useful products.',
  'But I also want to be honest about where we are.',
  'PAXI is still being built.',
  "We don't have unlimited funding or a huge corporation behind us. There is still a lot of work to do — infrastructure, security, liquidity, development, marketing, community growth and many other things.",
  "That's why I am opening the project up to the community.",
  "I don't want PAXI to be something that only I build behind closed doors.",
  'I want people who believe in the idea to have the opportunity to contribute, suggest ideas, build with us, test the technology, promote the ecosystem, and help shape what PAXI becomes.',
  'Some people may be able to contribute financially.',
  'Others may contribute development skills, design, marketing, community management, infrastructure, testing, partnerships or simply their time.',
  'Every contribution matters.',
  'If we eventually create a community treasury, I want it to be transparent. Contributions and spending should be publicly verifiable, and the community should know what the funds are being used for.',
  "I'm not here to promise anyone guaranteed profits.",
  "I'm here because I believe we can build something meaningful.",
  'PAXI started with one person and an idea.',
  'I want to see how far we can take it together.',
  'Thank you to everyone who has supported PAXI so far.',
  'This is only the beginning.',
];

const communityLinks = [
  { label: 'Main Group', href: 'https://t.me/paxiofficial', icon: Send },
  { label: 'Discussion Group', href: 'https://t.me/paxidiscussion', icon: MessagesSquare },
  { label: 'X', href: 'https://x.com/PaxiToken', icon: null },
] as const;

export default function AboutUsScreen({ onBack }: AboutUsScreenProps) {
  const openLink = (url: string, label: string) => {
    if (url === '#') {
      toast.info(`${label} link isn't set up yet.`);
      return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-2xl mx-auto px-5 sm:px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors p-1 -ml-1 rounded-md"
            aria-label="Go back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">About Us</h1>
          <div className="w-12" aria-hidden="true" />
        </div>
      </div>

      <main className="max-w-2xl mx-auto px-5 sm:px-6 py-7 sm:py-10 space-y-6">
        <section className="relative overflow-hidden rounded-[1.5rem] border border-accent/20 bg-gradient-to-br from-accent/15 via-card/80 to-card/60 p-6 sm:p-9 shadow-lg shadow-accent/5">
          <div className="pointer-events-none absolute -right-16 -top-20 h-48 w-48 rounded-full bg-accent/10 blur-3xl" aria-hidden="true" />
          <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-3xl border border-accent/40 bg-accent text-2xl font-bold tracking-tight text-accent-foreground shadow-lg shadow-accent/20" aria-label="Adewunmi Joel initials">
              AJ
            </div>
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-accent">Founder introduction</p>
              <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Meet the Founder of PAXI</h2>
              <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 text-accent" aria-hidden="true" />
                <span><strong className="font-semibold text-foreground">Adewunmi Joel</strong> · Nigeria</span>
              </p>
            </div>
          </div>
        </section>

        <article className="glass-card !p-6 sm:!p-9" aria-labelledby="founder-story-heading">
          <div className="mb-7 flex items-center gap-3 border-b border-foreground/10 pb-5">
            <div className="h-8 w-1 rounded-full bg-accent" aria-hidden="true" />
            <h3 id="founder-story-heading" className="text-lg font-semibold text-foreground">A note from Adewunmi Joel</h3>
          </div>
          <div className="space-y-5 text-[0.95rem] leading-8 text-muted-foreground sm:text-base">
            {founderStory.map((paragraph, index) => (
              <p key={index} className={index === 0 ? 'font-medium text-foreground' : undefined}>
                {paragraph}
              </p>
            ))}
            <p className="pt-2 font-medium text-foreground">— Adewunmi Joel<br /><span className="text-sm font-normal text-muted-foreground">Founder, PAXI Ecosystem</span></p>
          </div>
        </article>

        <section className="glass-card space-y-4" aria-labelledby="community-heading">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent">Stay connected</p>
            <h3 id="community-heading" className="mt-1 text-xl font-semibold text-foreground">Join the PAXI community</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">Follow the conversation and help shape what PAXI becomes.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {communityLinks.map(({ label, href, icon: Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex min-h-12 items-center justify-between gap-3 rounded-xl border border-foreground/10 bg-foreground/[0.03] px-4 py-3 transition-all hover:border-accent/40 hover:bg-accent/10 active:scale-[0.98]"
                aria-label={`Open PAXI ${label} in a new tab`}
              >
                <span className="text-sm font-medium text-foreground">{label}</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-accent/10 text-accent transition-colors group-hover:bg-accent group-hover:text-accent-foreground">
                  {Icon ? <Icon className="h-4 w-4" aria-hidden="true" /> : <span className="text-sm font-bold" aria-hidden="true">𝕏</span>}
                </span>
              </a>
            ))}
          </div>
        </section>

        <section className="glass-card space-y-3">
          <h3 className="text-sm font-semibold text-foreground">Why PAXI</h3>
          {TOKEN_STORY.split('\n\n').map((paragraph, i) => (
            <p key={i} className="text-sm text-muted-foreground leading-relaxed">
              {paragraph}
            </p>
          ))}
        </section>

        <section className="glass-card space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Security, privacy & legal</h3>
          <div className="space-y-3 text-xs text-muted-foreground leading-relaxed">
            <p><span className="font-semibold text-foreground">Security:</span> PAXI Wallet is non-custodial. Recovery phrases and private keys remain on this device and are not sent to support, market providers, dApps, or AI services.</p>
            <p><span className="font-semibold text-foreground">Privacy:</span> Wallet activity is kept local unless a user explicitly initiates a provider, blockchain, support, or dApp request. Provider availability and privacy policies may vary.</p>
            <p><span className="font-semibold text-foreground">Terms:</span> This wallet software is provided for self-custody use. Users must independently review addresses, networks, fees, approvals, and transaction details before signing.</p>
            <p><span className="font-semibold text-foreground">Licenses:</span> PAXI Wallet includes open-source dependencies. The complete dependency license inventory is maintained with the source distribution.</p>
          </div>
        </section>

        <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
          {ABOUT_LINKS.map((link) => (
            <button
              key={link.label}
              onClick={() => openLink(link.url, link.label)}
              className="w-full flex items-center justify-between py-3.5 px-4 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all"
            >
              <span className="text-sm text-foreground">{link.label}</span>
              <span className="w-7 h-7 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                <ExternalLink className="w-3.5 h-3.5 text-accent" aria-hidden="true" />
              </span>
            </button>
          ))}
          <button
            onClick={() => (window.location.href = `mailto:${SUPPORT_EMAIL}`)}
            className="w-full flex items-center justify-between py-3.5 px-4 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all"
          >
            <span className="text-sm text-foreground">Contact Support</span>
            <span className="w-7 h-7 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
              <Mail className="w-3.5 h-3.5 text-accent" aria-hidden="true" />
            </span>
          </button>
        </div>

        <p className="text-xs text-muted-foreground text-center px-4">
          PAXI Wallet is a non-custodial wallet - your keys never leave this device. Nobody, including us, can
          recover your funds if your recovery phrase is lost.
        </p>
      </main>
    </div>
  );
}
