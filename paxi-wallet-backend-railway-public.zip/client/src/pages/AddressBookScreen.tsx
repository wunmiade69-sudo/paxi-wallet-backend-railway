import { useEffect, useState } from 'react';
import { ArrowLeft, Plus, Search, Copy, Pencil, Trash2, UserRound, Check, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import NetworkPickerDrawer from '@/components/NetworkPickerDrawer';
import { NETWORKS } from '@/lib/wallet/chains';
import { getContacts, addContact, updateContact, deleteContact, type Contact } from '@/lib/wallet/addressBook';
import { describeUserFacingError } from '@/lib/userFacingError';

interface AddressBookScreenProps {
  onBack: () => void;
  /** When provided (opened from Send), tapping a contact returns address and its saved network. */
  onPick?: (address: string, network: string) => void;
  /** Renders without the full-page header/min-height wrapper, for use inside a Drawer. */
  embedded?: boolean;
}

function shortAddress(address: string) {
  return address.length > 16 ? `${address.slice(0, 8)}…${address.slice(-6)}` : address;
}

const NETWORK_OPTIONS = Object.values(NETWORKS);

export default function AddressBookScreen({ onBack, onPick, embedded = false }: AddressBookScreenProps) {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Contact | 'new' | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    setContacts(getContacts());
  }, []);

  const filtered = contacts.filter((c) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return c.name.toLowerCase().includes(q) || c.address.toLowerCase().includes(q) || c.network.toLowerCase().includes(q);
  });

  const handleCopy = (c: Contact) => {
    void navigator.clipboard?.writeText(c.address);
    setCopiedId(c.id);
    toast.success('Address copied');
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleDelete = (id: string) => {
    if (confirmDeleteId !== id) {
      setConfirmDeleteId(id);
      return;
    }
    deleteContact(id);
    setContacts(getContacts());
    setConfirmDeleteId(null);
    toast.success('Contact removed');
  };

  const body = (
    <div className={embedded ? 'px-4 pb-6 space-y-4' : 'max-w-md mx-auto px-6 py-6 space-y-4'}>
      {contacts.length > 0 && (
        <div className="relative">
          <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search name, network or address"
            className="w-full bg-secondary border border-border rounded-lg py-2.5 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
          />
        </div>
      )}

      {contacts.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <UserRound className="w-10 h-10 mx-auto mb-3 opacity-50" />
          <p>No saved contacts yet</p>
          <p className="text-xs text-muted-foreground mt-2 max-w-xs mx-auto">
            Save an address with its network once and pick it by name next time you send.
          </p>
          <button
            onClick={() => setEditing('new')}
            className="mt-4 inline-flex items-center gap-1.5 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm px-4 py-2 rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add a contact
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-8">No contacts match “{query}”</p>
      ) : (
        <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
          {filtered.map((c) => {
            const network = NETWORKS[c.network];
            return (
              <div key={c.id} className="flex items-center gap-3 px-4 py-3.5">
                <button
                  onClick={() => (onPick ? onPick(c.address, c.network) : handleCopy(c))}
                  className="flex items-center gap-3 flex-1 min-w-0 text-left"
                >
                  <span className="w-9 h-9 rounded-full bg-accent/10 flex items-center justify-center font-bold text-accent shrink-0 uppercase">
                    {c.name.charAt(0)}
                  </span>
                  <div className="min-w-0">
                    <p className="font-semibold text-foreground text-sm truncate">{c.name}</p>
                    <p className="text-xs text-muted-foreground font-mono truncate">{shortAddress(c.address)}</p>
                    <p className="text-[11px] text-muted-foreground truncate">
                      {network?.label ?? c.network} · {c.verificationStatus === 'confirmed' ? 'Confirmed' : 'Unconfirmed'}
                    </p>
                  </div>
                </button>
                <div className="flex items-center gap-1 shrink-0">
                  {c.verificationStatus === 'confirmed' && <ShieldCheck className="w-4 h-4 text-accent" aria-label="Confirmed contact" />}
                  <button
                    onClick={() => handleCopy(c)}
                    className="text-muted-foreground hover:text-foreground transition-colors p-1.5"
                    aria-label="Copy address"
                  >
                    {copiedId === c.id ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setEditing(c)}
                    className="text-muted-foreground hover:text-foreground transition-colors p-1.5"
                    aria-label="Edit contact"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(c.id)}
                    onBlur={() => setConfirmDeleteId(null)}
                    className={`transition-colors p-1.5 ${confirmDeleteId === c.id ? 'text-destructive' : 'text-muted-foreground hover:text-foreground'}`}
                    aria-label="Delete contact"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ContactEditorDrawer
        target={editing}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setContacts(getContacts());
          setEditing(null);
        }}
      />
    </div>
  );

  if (embedded) {
    return (
      <>
        <div className="px-4 pb-2 flex justify-end">
          <button onClick={() => setEditing('new')} className="flex items-center gap-1 text-xs font-semibold text-accent hover:text-accent/80 transition-colors">
            <Plus className="w-4 h-4" />
            Add contact
          </button>
        </div>
        {body}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">Address Book</h1>
          <button onClick={() => setEditing('new')} className="flex items-center gap-1 text-xs font-semibold text-accent hover:text-accent/80 transition-colors">
            <Plus className="w-4 h-4" />
            Add
          </button>
        </div>
      </div>
      {body}
    </div>
  );
}

function ContactEditorDrawer({ target, onClose, onSaved }: { target: Contact | 'new' | null; onClose: () => void; onSaved: () => void }) {
  const isNew = target === 'new';
  const contact = isNew ? null : target;
  const [name, setName] = useState('');
  const [network, setNetwork] = useState('ethereum');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const selectedNetwork = NETWORKS[network] ?? NETWORK_OPTIONS[0];

  useEffect(() => {
    setName(contact?.name ?? '');
    setNetwork(contact?.network ?? 'ethereum');
    setAddress(contact?.address ?? '');
    setNote(contact?.note ?? '');
    setError('');
  }, [target]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSave = () => {
    setError('');
    try {
      if (isNew) {
        addContact({ name, network, address, note });
        toast.success(`${name.trim()} saved to your address book`);
      } else if (contact) {
        updateContact(contact.id, { name, network, address, note });
        toast.success('Contact updated');
      }
      onSaved();
    } catch (err) {
      setError(describeUserFacingError(err, 'Could not save this contact.'));
    }
  };

  return (
    <Drawer open={target !== null} onOpenChange={(open) => !open && onClose()}>
      <DrawerContent>
        <DrawerHeader className="text-left">
          <DrawerTitle>{isNew ? 'Add contact' : 'Edit contact'}</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-6 space-y-3 max-w-md mx-auto w-full">
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60" />
          <NetworkPickerDrawer label="Contact network" networks={NETWORK_OPTIONS} selected={selectedNetwork} onSelect={setNetwork} />
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder={selectedNetwork.chainType === 'evm' ? '0x… wallet address' : `${selectedNetwork.label} address`}
            className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground font-mono text-sm focus:outline-none focus:border-accent/60"
          />
          <p className="text-[11px] text-muted-foreground">The saved network is checked before this contact is used in Send.</p>
          <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder='Note (optional) - e.g. “Treasury”' className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60" />
          {error && <p className="text-sm text-destructive">{error}</p>}
          <button onClick={handleSave} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-2.5 rounded-lg transition-colors text-sm">
            {isNew ? 'Save Contact' : 'Save Changes'}
          </button>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
