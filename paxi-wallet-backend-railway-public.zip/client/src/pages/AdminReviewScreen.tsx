export { default } from "@/components/AdminReviewPanel";
export type { AdminReviewTab } from "@/components/AdminReviewPanel";

/**
 * Legacy import compatibility only. The shipped admin route is AdminScreen,
 * which embeds AdminReviewPanel as its single review-queue section.
 */
