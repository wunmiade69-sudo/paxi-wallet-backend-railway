import { useState } from 'react';
import { ArrowLeft, Copy, AlertTriangle, KeyRound } from 'lucide-react';
import { toast } from 'sonner';
import { unlockWithPIN, isActiveWalletPrivateKeyImport } from '@/lib/wallet/vault';

interface BackupWalletProps {
  onBack: () => void;
  onExportInstead?: () => void;
}

export default function BackupWallet({ onBack, onExportInstead }: BackupWalletProps) {
  const [pin, setPin] = useState('');
  const [mnemonic, setMnemonic] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [isChecking, setIsChecking] = useState(false);

  const isPrivateKeyImport = isActiveWalletPrivateKeyImport();

  const handleVerify = async () => {
    setIsChecking(true);
    setError('');
    try {
      const phrase = await unlockWithPIN(pin);
      setMnemonic(phrase);
    } catch {
      setError('Incorrect PIN.');
    } finally {
      setIsChecking(false);
    }
  };

  const handleCopy = () => {
    if (!mnemonic) return;
    navigator.clipboard.writeText(mnemonic);
    toast.success('Recovery phrase copied - clear your clipboard after saving it somewhere safe.');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-2xl font-bold text-accent">Backup Wallet</h1>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full flex-1">
        {isPrivateKeyImport ? (
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto mt-4">
              <KeyRound className="w-5 h-5 text-accent" />
            </div>
            <p className="text-foreground font-semibold text-center">No recovery phrase for this account</p>
            <p className="text-muted-foreground text-sm text-center">
              This wallet was imported from a private key, not a recovery phrase, so there's no 12-word backup for
              it. Its private key is the backup - export it from Export Wallet instead.
            </p>
            <button
              onClick={onExportInstead ?? onBack}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              {onExportInstead ? 'Go to Export Wallet' : 'Back'}
            </button>
          </div>
        ) : !mnemonic ? (
          <div className="space-y-4">
            <p className="text-muted-foreground text-sm">Enter your PIN to view your recovery phrase.</p>
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
              className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground text-center tracking-[0.5em] text-xl"
              placeholder="••••••"
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
            <button
              onClick={handleVerify}
              disabled={pin.length !== 6 || isChecking}
              className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              {isChecking ? 'Checking...' : 'Verify PIN'}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-4">
              <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-sm text-destructive">
                Anyone with this phrase can access your funds. Make sure no one can see your screen.
              </p>
            </div>
            <div className="glass-card grid grid-cols-3 gap-3">
              {mnemonic.split(' ').map((word, i) => (
                <div key={i} className="bg-secondary/50 border border-accent/30 rounded-lg p-3 text-center">
                  <p className="text-xs text-muted-foreground mb-1">{i + 1}</p>
                  <p className="text-sm font-mono text-accent">{word}</p>
                </div>
              ))}
            </div>
            <button
              onClick={handleCopy}
              className="w-full flex items-center justify-center gap-2 bg-secondary hover:bg-muted text-foreground rounded-lg py-3 transition-colors"
            >
              <Copy className="w-4 h-4" />
              Copy Phrase
            </button>
            <button
              onClick={onBack}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
