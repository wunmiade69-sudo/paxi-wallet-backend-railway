import { useEffect, useState } from 'react';
import { ArrowLeft, Fingerprint, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { isBiometricAvailable, registerBiometric } from '@/lib/wallet/biometric';
import { enableBiometricUnlock } from '@/lib/wallet/vault';

interface BiometricSetupProps {
  pin: string;
  onBiometricSetup: (enabled: boolean) => void;
  onBack: () => void;
}

export default function BiometricSetup({ pin, onBiometricSetup, onBack }: BiometricSetupProps) {
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    isBiometricAvailable().then(setIsBiometricSupported);
  }, []);

  const handleEnableBiometric = async () => {
    setIsRegistering(true);
    setError('');

    try {
      const registered = await registerBiometric('paxi-user');
      if (registered) {
        // The vault doesn't exist yet at this step - App.tsx creates it right
        // after this screen completes, so we wrap the PIN into local storage
        // now and it'll be picked up as soon as the vault is written.
        await enableBiometricUnlock(pin);
        setSuccess(true);
        setTimeout(() => onBiometricSetup(true), 1200);
      } else {
        setError('Failed to register biometric. Please try again.');
        setIsRegistering(false);
      }
    } catch {
      setError('Biometric registration failed. Please try again.');
      setIsRegistering(false);
    }
  };

  const handleSkip = () => {
    onBiometricSetup(false);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-2xl font-bold text-accent">Biometric</h1>
        <div className="w-10" />
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
        <div className="mb-8 text-center">
          <p className="text-muted-foreground text-sm">Step 4 of 4</p>
          <div className="flex gap-2 mt-2 justify-center">
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-accent rounded-full" />
          </div>
        </div>

        <div className="mb-6 flex items-center justify-center">
          {success ? (
            <CheckCircle2 className="w-16 h-16 text-accent" />
          ) : (
            <Fingerprint className="w-16 h-16 text-accent" />
          )}
        </div>

        <h2 className="text-3xl font-bold text-foreground mb-2 text-center">
          {success ? 'Biometric Enabled' : 'Enable Biometric'}
        </h2>

        {!isBiometricSupported ? (
          <>
            <p className="text-muted-foreground text-center mb-8">
              Your device doesn't support biometric authentication. You can continue with PIN-only access.
            </p>
            <div className="w-full flex items-start gap-2.5 bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4 mb-8">
              <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
              <p className="text-sm text-yellow-300">
                Biometric authentication is not available on this device.
              </p>
            </div>
          </>
        ) : success ? (
          <>
            <p className="text-muted-foreground text-center mb-8">
              Biometric authentication is set up. You can now unlock your wallet using Face ID or fingerprint.
            </p>
            <div className="w-full flex items-start gap-2.5 bg-green-900/20 border border-green-500/30 rounded-lg p-4 mb-8">
              <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
              <p className="text-sm text-green-300">
                Your wallet is now secured with biometric authentication.
              </p>
            </div>
          </>
        ) : (
          <>
            <p className="text-muted-foreground text-center mb-8">
              Secure your wallet with Face ID or fingerprint for quick and easy access.
            </p>
            <div className="w-full flex items-start gap-2.5 bg-accent/10 border border-accent/30 rounded-lg p-4 mb-8">
              <Info className="w-4 h-4 text-accent shrink-0 mt-0.5" />
              <p className="text-sm text-foreground/80">
                Biometric data never leaves your device. It's used only to unlock a key that's stored
                locally on this device.
              </p>
            </div>
          </>
        )}

        {error && (
          <div className="w-full flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-4 mb-6">
            <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        <div className="w-full space-y-3">
          {!success && (
            <>
              {isBiometricSupported && (
                <button
                  onClick={handleEnableBiometric}
                  disabled={isRegistering}
                  className="w-full py-3 bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 disabled:from-muted disabled:to-muted text-accent-foreground disabled:text-muted-foreground font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:cursor-not-allowed"
                >
                  {isRegistering ? 'Setting up...' : 'Enable Biometric'}
                </button>
              )}

              <button
                onClick={handleSkip}
                className="w-full py-3 bg-secondary hover:bg-muted text-foreground font-semibold rounded-lg transition-colors"
              >
                Skip for Now
              </button>
            </>
          )}

          {success && (
            <button
              onClick={() => onBiometricSetup(true)}
              className="w-full py-3 bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 text-accent-foreground font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 active:scale-95"
            >
              Continue to Wallet
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
