import { useEffect, useMemo, useState } from 'react';
import { ArrowDown, AlertTriangle, Loader2, History } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { ASSETS, NETWORKS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { getStoredAddress, getUnlockedMnemonic } from '@/lib/wallet/vault';
import { getAddressForChainType } from '@/lib/wallet/engine';
import { fetchAssetBalance } from '@/lib/wallet/balances';
import { describeTxError } from '@/lib/wallet/errors';
import {
  executeBridge,
  fetchBridgeQuote,
  isBridgeDestination,
  type BridgeQuote,
} from '@/lib/wallet/bridge';
import { isSwappable } from '@/lib/wallet/swap';
import { isSolanaSwappable } from '@/lib/wallet/jupiterSwap';
import { addTxRecord, getTxRecords, type TxRecord } from '@/lib/wallet/txHistory';
import { notifyForTransaction } from '@/lib/phase3Local';
import AssetPickerDrawer from '@/components/AssetPickerDrawer';
import NetworkPickerDrawer from '@/components/NetworkPickerDrawer';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { SecurityStatusBadge, PaxiShieldPanel } from '@/components/PaxiShieldPanel';
import TransactionReceipt from '@/components/TransactionReceipt';
import { formatWalletAmount, formatWalletInputAmount } from '@/lib/wallet/amountFormatting';

type Step = 'form' | 'confirm' | 'approving' | 'bridging' | 'done';

const SLIPPAGE = 0.01; // 1%

/** Cross-chain: pick a source asset on one network (EVM or Solana), a destination asset on another, bridge. */
export default function BridgePanel() {
  const allAssets = useMemo(() => [...ASSETS, ...getCustomTokens().map(customTokenToAsset)], []);
  const bridgeableAssets = useMemo(() => allAssets.filter((a) => isSwappable(a) || isSolanaSwappable(a)), [allAssets]);
  const fromNetworkIds = useMemo(
    () => Array.from(new Set(bridgeableAssets.map((a) => a.network))),
    [bridgeableAssets]
  );

  const [fromNetworkId, setFromNetworkId] = useState(fromNetworkIds[0] ?? 'ethereum');
  const assetsOnFromNetwork = bridgeableAssets.filter((a) => a.network === fromNetworkId);

  // Every configured network is shown as a destination option, but only EVM/Solana ones are
  // selectable - Bitcoin is visible-but-disabled so it's clear it exists and why it's not offered.
  const allNetworkIds = Object.keys(NETWORKS);
  const [toNetworkId, setToNetworkId] = useState(
    allNetworkIds.find((id) => id !== fromNetworkId && isBridgeDestination(id)) ?? allNetworkIds[0]
  );
  const assetsOnToNetwork = bridgeableAssets.filter((a) => a.network === toNetworkId);

  const [fromSymbol, setFromSymbol] = useState(assetsOnFromNetwork[0]?.symbol ?? '');
  const [toSymbol, setToSymbol] = useState(assetsOnToNetwork[0]?.symbol ?? '');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<Step>('form');
  const [error, setError] = useState('');
  const [quote, setQuote] = useState<BridgeQuote | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [result, setResult] = useState<TxRecord | null>(null);
  const [fromBalance, setFromBalance] = useState<number | null>(null);
  const [balanceLoading, setBalanceLoading] = useState(false);
  const [showAuthGate, setShowAuthGate] = useState(false);
  const recordVerifiedActivity = trpc.activity.recordVerifiedTransaction.useMutation();

  const fromAsset = assetsOnFromNetwork.find((a) => a.symbol === fromSymbol) ?? assetsOnFromNetwork[0];
  const toAsset = assetsOnToNetwork.find((a) => a.symbol === toSymbol) ?? assetsOnToNetwork[0];
  const fromNetwork = NETWORKS[fromNetworkId];
  const toNetwork = NETWORKS[toNetworkId];
  const destSupported = isBridgeDestination(toNetworkId);

  // EVM address is persisted and available without unlocking; the Solana address isn't
  // stored (see vault.ts) and has to be re-derived from the mnemonic each time, so it's
  // only available once the wallet is unlocked - same constraint SwapPanel has for SOL.
  const evmAddress = getStoredAddress() ?? '';
  const mnemonicForAddress = getUnlockedMnemonic();
  const solAddress = mnemonicForAddress ? getAddressForChainType(mnemonicForAddress, 'sol') : null;
  const fromAddress = fromNetwork?.chainType === 'sol' ? (solAddress ?? '') : evmAddress;
  const toAddress = toNetwork?.chainType === 'sol' ? (solAddress ?? '') : evmAddress;
  const address = fromAddress; // kept for the balance-fetch effect below

  const numericAmount = Number(amount);
  const insufficientBalance =
    fromBalance !== null && !isNaN(numericAmount) && numericAmount > 0 && numericAmount > fromBalance;

  // Live balance of the asset being sent, so "Insufficient balance" can be shown
  // up front instead of surfacing a raw RPC revert after Review Bridge.
  useEffect(() => {
    let cancelled = false;
    if (!fromAsset || !address) {
      setFromBalance(null);
      return;
    }
    setBalanceLoading(true);
    fetchAssetBalance(fromAsset, address)
      .then((b) => {
        if (!cancelled) setFromBalance(b);
      })
      .finally(() => {
        if (!cancelled) setBalanceLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [fromAsset, address]);

  useEffect(() => {
    const onNet = bridgeableAssets.filter((a) => a.network === fromNetworkId);
    setFromSymbol(onNet[0]?.symbol ?? '');
    if (toNetworkId === fromNetworkId) {
      const next = allNetworkIds.find((id) => id !== fromNetworkId && isBridgeDestination(id));
      if (next) setToNetworkId(next);
    }
    setAmount('');
    setQuote(null);
    setError('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fromNetworkId]);

  useEffect(() => {
    const onNet = bridgeableAssets.filter((a) => a.network === toNetworkId);
    setToSymbol(onNet[0]?.symbol ?? '');
    setQuote(null);
    setError('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toNetworkId]);

  useEffect(() => {
    setError('');
    setQuote(null);
    const parsedAmount = Number(amount);
    if (!destSupported) return;
    if (!fromAsset || !toAsset || !amount || isNaN(parsedAmount) || parsedAmount <= 0) return;
    if (!fromAddress || !toAddress) {
      setError(
        fromNetwork?.chainType === 'sol' || toNetwork?.chainType === 'sol'
          ? 'Unlock your wallet to bridge to/from Solana.'
          : 'Session locked. Please unlock your wallet again.'
      );
      return;
    }
    // Don't burn a quote request on an amount we already know exceeds the balance -
    // show "Insufficient balance" immediately instead (see render below).
    if (fromBalance !== null && parsedAmount > fromBalance) {
      return;
    }
    setQuoting(true);
    const timer = setTimeout(async () => {
      try {
        const q = await fetchBridgeQuote({
          fromNetworkId,
          toNetworkId,
          srcAsset: fromAsset,
          destAsset: toAsset,
          amount,
          fromAddress,
          toAddress,
          slippage: SLIPPAGE,
        });
        setQuote(q);
      } catch (err) {
        setError(describeTxError(err));
      } finally {
        setQuoting(false);
      }
    }, 500);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fromSymbol, toSymbol, amount, fromNetworkId, toNetworkId, fromBalance, fromAddress, toAddress]);

  const setMaxAmount = () => {
    if (fromBalance === null) return;
    const max = fromAsset?.isNative ? Math.max(0, fromBalance - 0.0005) : fromBalance;
    setAmount(max > 0 ? formatWalletInputAmount(max, fromAsset?.decimals) : '0');
  };

  const handleReview = () => {
    if (insufficientBalance) {
      setError('Insufficient balance for this amount.');
      return;
    }
    if (!quote) {
      setError('Wait for a quote before continuing.');
      return;
    }
    setStep('confirm');
  };

  const handleConfirmBridge = async () => {
    const mnemonic = getUnlockedMnemonic();
    if (!mnemonic || !quote) {
      setError('Session locked. Please unlock your wallet again.');
      setStep('form');
      return;
    }
    setError('');
    setStep('bridging');
    try {
      const res = await executeBridge({
        mnemonic,
        fromNetworkId,
        srcAsset: fromAsset,
        quote,
        userAddress: fromAddress,
        onStatus: (status) => setStep(status),
      });
      setStep('done');
      toast.success('Bridge transaction broadcast');
      const record = addTxRecord({
        type: 'bridge',
        networkId: fromNetworkId,
        hash: res.bridgeHash,
        explorerUrl: res.explorerUrl,
        fromSymbol: fromAsset.symbol,
        fromAmount: amount,
        toSymbol: toAsset.symbol,
        toAmount: quote.destAmountFormatted,
        toNetworkId,
        status: 'pending',
      });
      setResult(record);
      notifyForTransaction({
        hash: res.bridgeHash,
        networkId: fromNetworkId,
        type: 'bridge',
        status: 'submitted',
        symbol: fromAsset.symbol,
        amount,
        source: 'local-wallet',
      });
      if (fromNetwork?.chainType === 'evm') {
        void recordVerifiedActivity.mutateAsync({
          walletAddress: fromAddress,
          chainId: fromNetworkId,
          transactionHash: res.bridgeHash,
        }).catch((activityError) => console.warn('[activity] bridge record deferred:', activityError));
      }
    } catch (err) {
      setError(describeTxError(err));
      setStep('confirm');
    }
  };

  const resetForm = () => {
    setAmount('');
    setQuote(null);
    setResult(null);
    setError('');
    setStep('form');
  };

  const recentBridges = useMemo(
    () => getTxRecords().filter((r) => r.type === 'bridge').slice(0, 3),
    [step]
  );

  if (fromNetworkIds.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
        <ArrowDown className="w-10 h-10 text-muted-foreground rotate-90" />
        <p className="text-foreground font-semibold">No bridgeable assets yet</p>
        <p className="text-sm text-muted-foreground max-w-xs">Bridging needs an EVM or Solana asset to send. Add a token first.</p>
      </div>
    );
  }

  return (
    <>
      <div className="mx-auto w-full max-w-md px-4 py-5 sm:px-6 sm:py-6">
      {step === 'form' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">From network</label>
              <NetworkPickerDrawer
                label="From network"
                networks={fromNetworkIds.map((id) => NETWORKS[id])}
                selected={fromNetwork}
                onSelect={setFromNetworkId}
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">To network</label>
              <NetworkPickerDrawer
                label="To network"
                networks={allNetworkIds.map((id) => NETWORKS[id])}
                selected={toNetwork}
                disabledIds={allNetworkIds.filter((id) => id === fromNetworkId || !isBridgeDestination(id))}
                onSelect={setToNetworkId}
              />
            </div>
          </div>

          {!destSupported && (
            <p className="paxi-alert-warning flex items-start gap-1.5 rounded-xl p-3 text-xs text-yellow-300">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-yellow-500" aria-hidden="true" />
              <span>
                Bridging to {toNetwork?.label} isn't offered yet - this wallet doesn't derive a real{' '}
                {toNetwork?.chainType.toUpperCase()} address, so funds sent there would be unrecoverable.
              </span>
            </p>
          )}

          <div className="glass-card space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs text-muted-foreground">You send</label>
              <span className="text-xs text-muted-foreground">
                {balanceLoading ? (
                  'Balance: …'
                ) : fromBalance !== null ? (
                  <>Balance: {formatWalletAmount(fromBalance)} {fromAsset?.symbol}</>
                ) : null}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                aria-label={`Amount of ${fromAsset?.symbol ?? 'asset'} to bridge`}
                inputMode="decimal"
                className={`paxi-field flex-1 min-w-0 border-0 bg-transparent px-0 text-2xl outline-none placeholder:text-muted-foreground ${
                  insufficientBalance ? 'text-destructive' : 'text-foreground'
                }`}
              />
              <AssetPickerDrawer
                label="You send"
                assets={assetsOnFromNetwork}
                selected={fromAsset}
                onSelect={(a) => setFromSymbol(a.symbol)}
              />
            </div>
            <div className="flex items-center justify-between pt-0.5">
              {insufficientBalance ? (
                <p className="text-xs text-destructive">Insufficient balance</p>
              ) : (
                <span />
              )}
              {fromBalance !== null && fromBalance > 0 && (
                <div className="flex items-center gap-1.5">
                  {[25, 50, 75].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => {
                        const raw = (fromBalance * pct) / 100;
                        const val = fromAsset?.isNative ? Math.max(0, raw - 0.0005 * (pct / 100)) : raw;
                        setAmount(val > 0 ? formatWalletInputAmount(val, fromAsset?.decimals) : '0');
                      }}
                      className="paxi-pressable min-h-9 rounded-lg px-2 text-xs text-muted-foreground transition-colors hover:bg-accent/10 hover:text-accent"
                    >
                      {pct}%
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={setMaxAmount}
                    className="paxi-pressable min-h-9 rounded-lg px-2 text-xs font-semibold text-accent transition-colors hover:bg-accent/10"
                  >
                    Max
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-center -my-3 relative z-10">
            <div className="rounded-full border-4 border-background bg-secondary p-2">
              <ArrowDown className="h-4 w-4 text-accent" aria-hidden="true" />
            </div>
          </div>

          <div className="glass-card space-y-2">
            <label className="text-xs text-muted-foreground">You receive on {toNetwork?.label ?? '—'}</label>
            <div className="flex items-center gap-3">
              <div className="flex-1 min-w-0 text-2xl text-foreground truncate">
                {quoting ? (
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                ) : quote ? (
                  formatWalletAmount(quote.destAmountFormatted)
                ) : (
                  <span className="text-muted-foreground">0.00</span>
                )}
              </div>
              <AssetPickerDrawer
                label="You receive"
                assets={assetsOnToNetwork}
                selected={toAsset}
                onSelect={(a) => setToSymbol(a.symbol)}
              />
            </div>
          </div>

          {quote && (
            <div className="glass-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Quote</span>
                <SecurityStatusBadge network={toAsset.network} contractAddress={toAsset.contractAddress} isNative={toAsset.isNative} />
              </div>
              <div className="space-y-2.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Estimated time</span>
                  <span className="text-foreground font-medium">~{Math.max(1, Math.round(quote.executionDurationSeconds / 60))} min</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-muted-foreground">LI.FI integrator fee estimate</span>
                  <span className="text-foreground font-medium">
                    {quote.feeAmountFormatted} {fromAsset.symbol}
                  </span>
                </div>
                {quote.routeNames.length > 0 && (
                  <div className="flex justify-between gap-3 pt-2.5 border-t border-border">
                    <span className="text-muted-foreground shrink-0">Routed via</span>
                    <span className="text-foreground font-medium text-right">{quote.routeNames.join(', ')}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {error && (
            <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3">
              <p className="text-sm text-destructive">{error}</p>
            </div>
          )}

          <button
            onClick={handleReview}
            disabled={!quote || quoting || !destSupported || insufficientBalance}
            className="w-full bg-accent hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed text-accent-foreground font-semibold py-3 rounded-lg transition-colors"
          >
            {insufficientBalance ? 'Insufficient balance' : 'Review Bridge'}
          </button>

          <p className="text-xs text-muted-foreground text-center">
            Aggregated across multiple bridges for the best route. The LI.FI integrator estimate is shown above; a server-owned PAXI fee is not included unless the route confirms it.
            Slippage tolerance: {(SLIPPAGE * 100).toFixed(1)}%.
          </p>

          {recentBridges.length > 0 && (
            <div className="pt-2">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <History className="w-3.5 h-3.5" />
                Recent bridges
              </div>
              <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
                {recentBridges.map((r) => (
                  <a
                    key={r.id}
                    href={r.explorerUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between px-4 py-3 hover:bg-foreground/5 transition-colors"
                  >
                    <span className="text-sm text-foreground">
                      {r.fromAmount} {r.fromSymbol} ({NETWORKS[r.networkId]?.label}) → {r.toAmount} {r.toSymbol} (
                      {NETWORKS[r.toNetworkId ?? '']?.label})
                    </span>
                    <span className="text-xs text-muted-foreground shrink-0 pl-2">
                      {new Date(r.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {(step === 'approving' || step === 'bridging') && (
        <div className="text-center py-16">
          <div className="animate-spin w-10 h-10 border-4 border-accent border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-muted-foreground">
            {step === 'approving' ? `Approving ${fromAsset.symbol} for bridging...` : 'Broadcasting bridge transaction...'}
          </p>
        </div>
      )}

      {step === 'done' && result && (
        <TransactionReceipt record={result} onClose={resetForm} />
      )}
    </div>

    <Drawer open={step === 'confirm' && !!quote} onOpenChange={(open) => !open && setStep('form')}>
      <DrawerContent className="max-h-[92vh]">
        <DrawerHeader className="text-left pb-2">
          <div className="flex items-center justify-between">
            <DrawerTitle>Bridge Preview</DrawerTitle>
            {quote && <SecurityStatusBadge network={toAsset.network} contractAddress={toAsset.contractAddress} isNative={toAsset.isNative} />}
          </div>
        </DrawerHeader>

        {quote && (
          <div className="overflow-y-auto px-4 pb-6 space-y-4">
            <PaxiShieldPanel network={toAsset.network} contractAddress={toAsset.contractAddress} isNative={toAsset.isNative} />

            <div className="flex items-start gap-2.5 bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-3">
              <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
              <p className="text-xs text-yellow-300">
                This is a real cross-chain transfer - it can't be reversed. It can take a few minutes to arrive.
              </p>
            </div>

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={() => setStep('form')}
                className="flex-1 bg-secondary hover:bg-muted text-foreground font-semibold py-3 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowAuthGate(true)}
                className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-colors"
              >
                Bridge
              </button>
            </div>
          </div>
        )}
      </DrawerContent>
    </Drawer>

    <TransactionAuthSheet
      open={showAuthGate}
      actionLabel={`Bridge ${amount} ${fromSymbol} to ${NETWORKS[toNetworkId]?.label ?? toNetworkId}`}
      onSuccess={() => {
        setShowAuthGate(false);
        handleConfirmBridge();
      }}
      onCancel={() => setShowAuthGate(false)}
    />
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-foreground font-medium">{value}</span>
    </div>
  );
}
