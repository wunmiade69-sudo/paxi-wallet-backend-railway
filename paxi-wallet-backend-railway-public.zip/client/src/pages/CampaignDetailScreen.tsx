import { ArrowLeft, CalendarDays, CheckCircle2, Circle, ExternalLink, Gift, ShieldCheck, Users } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';
import { toast } from 'sonner';
import { describeUserFacingError } from '@/lib/userFacingError';

export default function CampaignDetailScreen({ campaignId, onBack }: { campaignId: number; onBack: () => void }) {
  const { user } = useAuth();
  const { data: campaign, isLoading } = trpc.campaigns.getPublic.useQuery({ campaignId });
  const { data: requirements } = trpc.campaigns.publicRequirements.useQuery({ campaignId }, { enabled: Boolean(campaign) });
  const { data: eligibility, isLoading: isEligibilityLoading } = trpc.campaigns.myEligibility.useQuery({ campaignId }, { enabled: Boolean(campaign && user) });
  const { data: entry } = trpc.campaigns.myEntry.useQuery({ campaignId }, { enabled: Boolean(campaign && user) });
  const utils = trpc.useUtils();
  const requestClaim = trpc.campaigns.requestClaim.useMutation({ onSuccess: (result) => { utils.campaigns.myEntry.invalidate({ campaignId }); toast.success(result.status === 'paid' ? 'Reward is already paid.' : result.status === 'claimable' ? 'Reward request is ready for payout confirmation.' : 'Reward request created.'); }, onError: (error) => toast.error(describeUserFacingError(error, 'We couldn’t request this reward. Please try again.')) });
  if (isLoading) return <div className="min-h-screen bg-background p-6 text-sm text-muted-foreground">Loading campaign…</div>;
  if (!campaign) return <div className="min-h-screen bg-background p-6"><button onClick={onBack} className="text-sm text-accent">← Back</button><p className="mt-6 text-sm text-muted-foreground">This campaign is no longer publicly available.</p></div>;

  const endDate = campaign.endAt ? new Date(campaign.endAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : 'Not scheduled';
  return (
    <div className="min-h-screen bg-background pb-12">
      <div className="sticky top-0 z-40 flex items-center gap-3 border-b border-foreground/5 bg-secondary/50 px-6 py-4 backdrop-blur-xl"><button onClick={onBack} aria-label="Back" className="text-muted-foreground hover:text-foreground"><ArrowLeft className="h-5 w-5" /></button><h1 className="text-lg font-bold text-foreground">Campaign</h1></div>
      <main className="mx-auto max-w-md space-y-5 px-6 py-6">
        {campaign.bannerKey && <img src={`/manus-storage/${campaign.bannerKey}`} alt={`${campaign.title} banner`} className="h-44 w-full rounded-2xl object-cover" />}
        <div className="flex items-start gap-3">{campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-14 w-14 rounded-2xl object-cover" />}<div className="min-w-0 flex-1"><p className="text-xs font-semibold uppercase tracking-wide text-accent">{campaign.taskTokenSymbol} campaign</p><h2 className="mt-1 text-2xl font-bold text-foreground">{campaign.title}</h2><span className="mt-2 inline-flex items-center gap-1 rounded-full bg-emerald-400/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-emerald-300"><ShieldCheck className="h-3 w-3" />Live · Approved</span></div></div>
        {campaign.description && <p className="text-sm leading-6 text-muted-foreground">{campaign.description}</p>}
        <div className="grid grid-cols-2 gap-3"><Metric icon={Gift} label="Reward" value={`${campaign.rewardAmount} ${campaign.rewardTokenSymbol}`} /><Metric icon={CalendarDays} label="Ends" value={endDate} /><Metric icon={Users} label="Reward pool" value={`${campaign.winnersCount}/${campaign.maxWinners} slots claimed`} /><Metric icon={ShieldCheck} label="Requirement" value={`Trade ${campaign.minTokenAmount} ${campaign.taskTokenSymbol}`} /></div>
        <section className="space-y-3 rounded-2xl border border-border bg-secondary/40 p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-foreground">Your eligibility</p><p className="text-xs text-muted-foreground">Based on confirmed PAXI activity</p></div>{eligibility && <span className={`rounded-full px-2 py-1 text-[10px] font-semibold uppercase tracking-wide ${eligibility.eligible ? 'bg-emerald-400/10 text-emerald-300' : 'bg-secondary text-muted-foreground'}`}>{eligibility.metRequirements}/{eligibility.totalRequirements}</span>}</div>{!user && <p className="text-xs leading-5 text-muted-foreground">Sign in to view your requirement progress.</p>}{isEligibilityLoading && <p className="text-xs text-muted-foreground">Checking confirmed PAXI activity…</p>}<div className="space-y-2">{(eligibility?.requirements ?? requirements ?? []).map((requirement) => { const met = 'met' in requirement ? requirement.met : false; return <div key={requirement.key} className="flex items-center gap-2 text-xs"><span className={met ? 'text-emerald-300' : 'text-muted-foreground'}>{met ? <CheckCircle2 className="h-4 w-4" /> : <Circle className="h-4 w-4" />}</span><span className={met ? 'text-foreground' : 'text-muted-foreground'}>{requirement.label}</span></div>; })}</div>{eligibility?.eligible && <p className="rounded-lg bg-emerald-400/10 p-3 text-xs text-emerald-100">You meet the minimum requirement threshold. Claim availability is confirmed separately against the active campaign and reward pool.</p>}{eligibility?.eligible && entry?.slotNumber && entry.payoutStatus === 'pending' && <button onClick={() => requestClaim.mutate({ campaignId })} disabled={requestClaim.isPending} className="w-full rounded-lg bg-accent py-3 text-sm font-semibold text-accent-foreground disabled:opacity-60">{requestClaim.isPending ? 'Verifying claim…' : 'Request Reward'}</button>}{entry?.payoutStatus === 'claimable' && <p className="rounded-lg bg-accent/10 p-3 text-xs text-accent">Reward request recorded. PAXI will confirm the on-chain payout.</p>}{entry?.payoutStatus === 'paid' && <p className="rounded-lg bg-emerald-400/10 p-3 text-xs text-emerald-100">Reward payout was confirmed on-chain.</p>}</section>
        {campaign.website && <button onClick={() => window.open(campaign.website!, '_blank', 'noopener,noreferrer')} className="flex w-full items-center justify-center gap-2 rounded-lg border border-border py-3 text-sm font-semibold text-foreground"><ExternalLink className="h-4 w-4 text-accent" />Project website</button>}
      </main>
    </div>
  );
}

function Metric({ icon: Icon, label, value }: { icon: typeof Gift; label: string; value: string }) { return <div className="rounded-xl bg-secondary p-3"><Icon className="h-4 w-4 text-accent" /><p className="mt-2 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</p><p className="mt-1 text-xs font-semibold leading-5 text-foreground">{value}</p></div>; }
