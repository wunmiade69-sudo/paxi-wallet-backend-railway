import { useEffect, useState } from 'react';
import { ArrowLeft, Clock3, Link2, ShieldAlert, Unplug } from 'lucide-react';
import { toast } from 'sonner';
import type { ConnectedDappRecord } from '@/lib/phase3Models';
import { disconnectConnectedDapp, getConnectedDapps, subscribeToConnectedDapps } from '@/lib/phase3Local';

export default function ConnectedDappsScreen({ onBack }: { onBack: () => void }) {
  const [records, setRecords] = useState<ConnectedDappRecord[]>(() => getConnectedDapps());

  useEffect(() => subscribeToConnectedDapps(() => setRecords(getConnectedDapps())), []);

  const disconnect = async (record: ConnectedDappRecord) => {
    if (!record.canDisconnect) {
      toast.error('This session cannot be changed from this device.');
      return;
    }
    try {
      await disconnectConnectedDapp(record.id);
      setRecords(getConnectedDapps());
      toast.success(`${record.name} disconnected`);
    } catch {
      toast.error('The dApp session could not be disconnected.');
    }
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground" aria-label="Back"><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="text-lg font-bold text-accent">Connected dApps</h1>
        </div>
      </div>
      <main className="max-w-md mx-auto px-6 py-6 space-y-4">
        <div className="glass-card p-4 flex items-start gap-3">
          <Link2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">Only sessions created by a validated WalletConnect flow should appear here. A listing or website visit does not grant a dApp permission.</p>
        </div>
        {records.length === 0 ? (
          <div className="glass-card p-8 text-center space-y-3">
            <ShieldAlert className="w-9 h-9 mx-auto text-muted-foreground" />
            <p className="font-semibold text-foreground">No connected dApps</p>
            <p className="text-sm text-muted-foreground">No active WalletConnect session is currently available. Pair through Discover only when a dApp presents a WalletConnect request.</p>
          </div>
        ) : records.map((record) => (
          <div key={record.id} className="glass-card p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-semibold text-foreground truncate">{record.name}</p>
                <p className="text-xs text-muted-foreground truncate">{record.domain}</p>
              </div>
              <span className={`text-[10px] rounded-full px-2 py-1 ${record.status === 'connected' ? 'bg-emerald-400/15 text-emerald-400' : 'bg-secondary text-muted-foreground'}`}>{record.status}</span>
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              <p>Network: <span className="text-foreground">{record.network}</span></p>
              <p>Permissions: <span className="text-foreground">{record.permissions.length ? record.permissions.join(', ') : 'Unknown'}</span></p>
              <p className="flex items-center gap-1"><Clock3 className="w-3 h-3" /> Last used: {record.lastUsed ? new Date(record.lastUsed).toLocaleString() : 'Unknown'}</p>
            </div>
            {record.canDisconnect && <button onClick={() => disconnect(record)} className="w-full flex items-center justify-center gap-2 rounded-lg border border-destructive/30 text-destructive py-2 text-sm font-semibold"><Unplug className="w-4 h-4" /> Disconnect</button>}
          </div>
        ))}
      </main>
    </div>
  );
}
