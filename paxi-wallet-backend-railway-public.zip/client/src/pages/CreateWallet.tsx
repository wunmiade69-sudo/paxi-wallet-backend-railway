import { useState } from 'react';
import { ArrowLeft, Copy, Check, AlertTriangle, Eye } from 'lucide-react';
import { toast } from 'sonner';

interface CreateWalletProps {
  mnemonic: string;
  onRecoveryPhraseGenerated: (phrase: string) => void;
  onBack: () => void;
}

export default function CreateWallet({ mnemonic, onRecoveryPhraseGenerated, onBack }: CreateWalletProps) {
  const [isCopied, setIsCopied] = useState(false);
  const [isRevealed, setIsRevealed] = useState(false);

  const handleCopyPhrase = () => {
    navigator.clipboard.writeText(mnemonic);
    setIsCopied(true);
    toast.success('Recovery phrase copied - store it somewhere safe, then clear your clipboard.');
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleContinue = () => {
    onRecoveryPhraseGenerated(mnemonic);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-2xl font-bold text-accent">Create Wallet</h1>
        <div className="w-10" />
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
        {/* Step indicator */}
        <div className="mb-8 text-center">
          <p className="text-muted-foreground text-sm">Step 1 of 4</p>
          <div className="flex gap-2 mt-2 justify-center">
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
          </div>
        </div>

        {/* Title */}
        <h2 className="text-3xl font-bold text-foreground mb-2 text-center">Recovery Phrase</h2>
        <p className="text-muted-foreground text-center mb-8">
          Save your 12-word recovery phrase. Keep it safe and never share it.
        </p>

        {/* Recovery Phrase Box */}
        <div className="w-full glass-card mb-6 relative group">
          {!isRevealed && (
            <div
              className="absolute inset-0 bg-secondary/40 backdrop-blur-sm rounded-2xl flex items-center justify-center z-10 group-hover:bg-secondary/30 transition-all cursor-pointer"
              onClick={() => setIsRevealed(true)}
            >
              <div className="text-center">
                <Eye className="w-5 h-5 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">Tap to reveal</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            {mnemonic.split(' ').map((word, index) => (
              <div key={index} className="bg-secondary/50 border border-accent/30 rounded-lg p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">{index + 1}</p>
                <p className="text-sm font-mono text-accent">{word}</p>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={handleCopyPhrase}
          className="w-full mb-6 px-4 py-3 bg-secondary hover:bg-muted text-foreground rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          {isCopied ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
          {isCopied ? 'Copied!' : 'Copy Phrase'}
        </button>

        <div className="w-full flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-4 mb-8">
          <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
          <p className="text-sm text-destructive">
            Never share your recovery phrase. Anyone with it can access your funds. PAXI Wallet
            support will never ask you for it.
          </p>
        </div>

        <button
          onClick={handleContinue}
          disabled={!isRevealed}
          className="w-full py-3 bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 disabled:from-muted disabled:to-muted text-accent-foreground disabled:text-muted-foreground font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:cursor-not-allowed"
        >
          I've Saved My Phrase
        </button>
      </div>
    </div>
  );
}
