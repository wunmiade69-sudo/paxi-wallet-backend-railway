import { useEffect, useState } from 'react';
import { Copy, Send, ArrowDownToLine, RefreshCw, Eye, EyeOff, ArrowLeftRight, CreditCard, Check, Plus, TrendingUp, TrendingDown } from 'lucide-react';
import { useCountUp } from '@/hooks/useCountUp';
import { useRef } from 'react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import { getStoredAddress, getUnlockedMnemonic } from '@/lib/wallet/vault';
import { getAddressForChainType } from '@/lib/wallet/engine';
import { fetchAllBalancesStreaming, type AssetBalance } from '@/lib/wallet/balances';
import { ASSETS, assetKey, NETWORKS, type AssetConfig } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens, removeCustomToken } from '@/lib/wallet/customTokens';
import { getTxRecords, type TxRecord } from '@/lib/wallet/txHistory';
import { assetSectionIncludes, portfolioAssetKind, type AssetSection } from '@/lib/phase3Models';
import { getHistoryStaleWhileRevalidate } from '@/lib/wallet/txIndexer';
import { safeGetLocalStorage, safeSetLocalStorage } from '@/lib/safeStorage';
import { useDepositNotifications } from '@/lib/wallet/depositNotifications';
import { getBalanceSnapshot, setBalanceSnapshot } from '@/lib/wallet/balanceCache';
import TransactionList from '@/components/TransactionList';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import SwipeToRemove from '@/components/SwipeToRemove';
import PaxiLogo from '@/components/PaxiLogo';
import AssetLogo from '@/components/AssetLogo';
import AssetSearchDrawer from '@/components/AssetSearchDrawer';
import NotificationBell from '@/components/NotificationBell';
import VerifiedBadge from '@/components/VerifiedBadge';
import { getAssetLogoUrl, getTrustedAssetLabel, isTrustedAsset } from '@/lib/appInfo';
import { canonicalMarketIdentityKey } from '@/lib/marketIdentity';
import type { AssetImportSeed } from '@/lib/assetSearch';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';

const HIDE_BALANCE_KEY = 'paxi-hide-balance';
const MASK = '••••••';

interface DashboardProps {
  onSend: () => void;
  onReceive: () => void;
  onAddToken: (initial?: AssetImportSeed) => void;
  onSelectAsset: (asset: AssetConfig, balance: AssetBalance | undefined) => void;
  onBalancesSnapshot?: (snapshot: Record<string, AssetBalance>) => void;
  onSelectCampaign: (campaignId: number) => void;
  onNavigate: (tab: NavTab) => void;
  onNotifications: () => void;
}

export default function Dashboard({ onSend, onReceive, onAddToken, onSelectAsset, onBalancesSnapshot, onSelectCampaign, onNavigate, onNotifications }: DashboardProps) {
  const [walletAddress, setWalletAddress] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'portfolio' | 'history'>('portfolio');
  const [assetSection, setAssetSection] = useState<AssetSection>('all');
  const [balances, setBalances] = useState<Record<string, AssetBalance>>({});
  const [loadingSymbols, setLoadingSymbols] = useState<Set<string>>(new Set());
  const [hideBalance, setHideBalance] = useState(() => safeGetLocalStorage(HIDE_BALANCE_KEY) === 'true');
  const [txRecords, setTxRecords] = useState<TxRecord[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  // Bumped after removing a custom token - localStorage is the source of
  // truth for custom tokens (read fresh in the render below), this just
  // forces React to re-render and pick up the change.
  const [customTokenVersion, setCustomTokenVersion] = useState(0);
  const refreshInFlight = useRef(false);
  const pendingBalancesRef = useRef<Record<string, AssetBalance> | null>(null);
  const balanceCommitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const address = getStoredAddress();
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);
  useDepositNotifications(address);

  const toggleHideBalance = () => {
    setHideBalance((prev) => {
      const next = !prev;
      safeSetLocalStorage(HIDE_BALANCE_KEY, String(next));
      return next;
    });
  };

  useEffect(() => {
    if (address) setWalletAddress(address);
  }, [address]);

  const loadBalances = async ({ force = false }: { force?: boolean } = {}) => {
    if (!address || refreshInFlight.current) return;

    const cached = getBalanceSnapshot(address);
    const allAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
    const missingKeys = allAssets.map(assetKey).filter((key) => !cached?.[key]);
    if (!force && cached && missingKeys.length === 0) {
      setBalances(cached);
      onBalancesSnapshot?.(cached);
      setLoadingSymbols(new Set());
      return;
    }

    refreshInFlight.current = true;
    const mnemonic = getUnlockedMnemonic();
    const solAddress = mnemonic ? (getAddressForChainType(mnemonic, 'sol') ?? undefined) : undefined;
    const btcAddress = mnemonic ? (getAddressForChainType(mnemonic, 'btc') ?? undefined) : undefined;
    const nextBalances: Record<string, AssetBalance> = cached ?? {};
    const assetsToFetch = force || !cached
      ? allAssets
      : allAssets.filter((asset) => missingKeys.includes(assetKey(asset)));
    // A refresh must not replace already-rendered values with placeholders. Only
    // assets that have never had a result are considered loading.
    setLoadingSymbols(new Set(missingKeys));

    const commitBalances = () => {
      if (balanceCommitTimerRef.current) {
        clearTimeout(balanceCommitTimerRef.current);
        balanceCommitTimerRef.current = null;
      }
      const snapshot = pendingBalancesRef.current;
      if (!snapshot) return;
      const stableSnapshot = { ...snapshot };
      pendingBalancesRef.current = null;
      setBalances(stableSnapshot);
      setBalanceSnapshot(address, stableSnapshot);
      onBalancesSnapshot?.(stableSnapshot);
    };

    try {
      await fetchAllBalancesStreaming(
        address,
        (result) => {
          nextBalances[assetKey(result.asset)] = result;
          pendingBalancesRef.current = nextBalances;
          if (!balanceCommitTimerRef.current) {
            balanceCommitTimerRef.current = setTimeout(() => {
              balanceCommitTimerRef.current = null;
              const snapshot = pendingBalancesRef.current;
              if (!snapshot) return;
              const stableSnapshot = { ...snapshot };
              pendingBalancesRef.current = null;
              setBalances(stableSnapshot);
              setBalanceSnapshot(address, stableSnapshot);
              onBalancesSnapshot?.(stableSnapshot);
            }, 100);
          }
          setLoadingSymbols((prev) => {
            const next = new Set(prev);
            next.delete(assetKey(result.asset));
            return next;
          });
        },
        solAddress,
        btcAddress,
        assetsToFetch,
      );
    } catch {
      toast.error('Could not refresh balances. Check your connection.');
      setLoadingSymbols(new Set());
    } finally {
      commitBalances();
      refreshInFlight.current = false;
    }
  };

  const handleRemoveToken = (asset: AssetConfig) => {
    if (!asset.contractAddress) return;
    removeCustomToken(asset.contractAddress, asset.network);
    setBalances((prev) => {
      const next = { ...prev };
      delete next[assetKey(asset)];
      if (address) {
        setBalanceSnapshot(address, next);
        onBalancesSnapshot?.(next);
      }
      return next;
    });
    setCustomTokenVersion((v) => v + 1);
    toast.success(`${asset.symbol} removed`);
  };

  useEffect(() => {
    if (address) {
      const cached = getBalanceSnapshot(address);
      if (cached) {
        setBalances(cached);
        onBalancesSnapshot?.(cached);
        setLoadingSymbols(new Set());
      } else {
        void loadBalances();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, customTokenVersion]);

  const balanceList = Object.values(balances);
  const isLoading = loadingSymbols.size > 0;

  // Fetched once for the whole list rather than per-asset - a query per row
  // would mean dozens of requests just to show a checkmark.
  const { data: verifiedListings } = trpc.listings.listVerified.useQuery();
  const { data: featuredCampaigns } = trpc.campaigns.featured.useQuery();
  const verifiedKeys = new Set(
    (verifiedListings ?? []).map((l) => `${l.network}:${l.contractAddress.toLowerCase()}`)
  );
  const isAssetVerified = (asset: AssetConfig) => {
    if (isTrustedAsset(asset)) return true;
    if (!asset.contractAddress) return false;
    return verifiedKeys.has(`${asset.network}:${asset.contractAddress.toLowerCase()}`);
  };

  const portfolioValue = balanceList.reduce((total, b) => {
    if (b.balance == null || b.usdPrice == null) return total;
    return total + b.balance * b.usdPrice;
  }, 0);

  // Weighted 24h change: reconstruct what the portfolio was worth 24h ago
  // per-asset (today's value / (1 + change%)), then compare totals - so an
  // asset that's a bigger share of the portfolio moves the number more,
  // same as how a real portfolio's % change works.
  const pricedBalances = balanceList.filter((b) => b.balance != null && b.usdPrice != null);
  const hasPortfolioData = pricedBalances.length > 0;
  const hasCompletePortfolioChange = hasPortfolioData && pricedBalances.every((b) => b.change24h != null);

  const portfolioValue24hAgo = hasCompletePortfolioChange
    ? pricedBalances.reduce((total, b) => {
        const valueToday = b.balance! * b.usdPrice!;
        const changeFraction = b.change24h! / 100;
        if (changeFraction === -1) return total;
        return total + valueToday / (1 + changeFraction);
      }, 0)
    : 0;
  const portfolioChangePercent =
    hasCompletePortfolioChange && portfolioValue24hAgo > 0 ? ((portfolioValue - portfolioValue24hAgo) / portfolioValue24hAgo) * 100 : null;
  const portfolioChangeValue = portfolioChangePercent != null ? portfolioValue - portfolioValue24hAgo : null;

  const setActiveTabChecked = (tab: 'portfolio' | 'history') => {
    if (tab === 'history') {
      setTxRecords(getTxRecords()); // instant paint from local log
      if (address) {
        const cached = getHistoryStaleWhileRevalidate(address, (fresh) => {
          setTxRecords(fresh.records);
          setIsHistoryLoading(false);
        });
        if (cached.length > 0) setTxRecords(cached); // cache beats the bare local log if we have it
        else setIsHistoryLoading(true);
      }
    }
    setActiveTab(tab);
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    setIsCopied(true);
    toast.success('Wallet address copied!');
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-24">
      {/* Header */}
      <div className="paxi-page-header sticky top-0 z-40">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <PaxiLogo size="sm" priority className="h-9 w-9 border-accent/70 shadow-[0_0_20px_rgba(245,158,11,0.2)]" />
            <div>
              <h1 className="text-lg font-black tracking-[0.16em] text-accent">PAXI</h1>
              <p className="mt-0.5 text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Secure wallet</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <NotificationBell onOpen={onNotifications} />
            <span className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.14em] text-foreground/55">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Ready
            </span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-md px-4 py-6 sm:px-6 sm:py-8">
        {featuredCampaigns && featuredCampaigns.length > 0 && (
          <section className="mb-6" aria-label="Featured campaigns">
            <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto pb-1 no-scrollbar">
              {featuredCampaigns.map((campaign) => (
                <button key={campaign.id} onClick={() => onSelectCampaign(campaign.id)} aria-label={`Open ${campaign.title} campaign`} className="w-full shrink-0 snap-center overflow-hidden rounded-2xl border border-border bg-secondary active:scale-[0.99] transition-transform">
                  {campaign.bannerKey ? <img src={`/manus-storage/${campaign.bannerKey}`} alt={`${campaign.title} campaign banner`} className="h-36 w-full object-cover" /> : <div className="h-36 w-full bg-gradient-to-br from-accent/30 to-secondary" />}
                </button>
              ))}
            </div>
          </section>
        )}
        {/* Portfolio Card */}
        <div className="glass-card mb-8 relative overflow-hidden">
          <div
            className="absolute inset-0 pointer-events-none opacity-60"
            style={{
              background:
                'radial-gradient(circle at 15% 0%, var(--accent) 0%, transparent 45%), radial-gradient(circle at 100% 100%, var(--accent) 0%, transparent 35%)',
              opacity: 0.12,
            }}
          />
          <div className="relative">
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-sm">Total Portfolio</p>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={toggleHideBalance}
                  className="paxi-icon-button flex items-center justify-center text-muted-foreground hover:bg-foreground/5 hover:text-foreground"
                  title={hideBalance ? 'Show balance' : 'Hide balance'}
                  aria-label={hideBalance ? 'Show balance' : 'Hide balance'}
                >
                  {hideBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={() => void loadBalances({ force: true })}
                  disabled={refreshInFlight.current}
                  className="paxi-icon-button flex items-center justify-center text-muted-foreground hover:bg-foreground/5 hover:text-foreground disabled:opacity-50"
                  title="Refresh balances"
                  aria-label="Refresh balances"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>
            <div className="flex items-end gap-3 mb-6">
              <PortfolioValue hidden={hideBalance} loading={isLoading && balanceList.length === 0} value={portfolioValue} hasValue={hasPortfolioData} currency={currency} fiatRate={fiatRate} />
              {!hideBalance && !(isLoading && balanceList.length === 0) && portfolioChangePercent != null && (
                <span
                  className={`flex flex-col gap-0.5 text-sm font-semibold mb-1.5 ${
                    portfolioChangePercent >= 0 ? 'text-emerald-400' : 'text-red-400'
                  }`}
                >
                  <span className="flex items-center gap-1">
                    {portfolioChangePercent >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    {portfolioChangePercent >= 0 ? '+' : ''}{portfolioChangePercent.toFixed(2)}% 24h
                  </span>
                  <span className="text-[11px] font-medium">{portfolioChangeValue != null ? `${portfolioChangeValue >= 0 ? '+' : '-'}${formatFiat(Math.abs(portfolioChangeValue), currency, fiatRate)}` : '—'}</span>
                </span>
              )}
            </div>

          {/* Wallet Address */}
          <div className="mb-4 rounded-xl border border-border/70 bg-secondary/50 p-3">
            <p className="text-xs text-muted-foreground mb-1">Wallet Address (EVM)</p>
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-mono text-accent truncate">{walletAddress}</p>
              <button
                type="button"
                onClick={handleCopyAddress}
                className="paxi-icon-button flex h-11 w-11 items-center justify-center shrink-0 text-muted-foreground hover:bg-foreground/5 hover:text-foreground"
                aria-label="Copy address"
              >
                {isCopied ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-4 gap-2">
            <button
              type="button"
              onClick={onSend}
              className="paxi-pressable flex min-h-[4.25rem] flex-col items-center justify-center gap-1 rounded-xl border border-accent/45 bg-accent/15 py-3 text-xs font-semibold text-accent transition-all hover:bg-accent/25"
            >
              <Send className="w-4 h-4" />
              Send
            </button>
            <button
              type="button"
              onClick={onReceive}
              className="paxi-pressable flex min-h-[4.25rem] flex-col items-center justify-center gap-1 rounded-xl border border-accent/45 bg-accent/15 py-3 text-xs font-semibold text-accent transition-all hover:bg-accent/25"
            >
              <ArrowDownToLine className="w-4 h-4" />
              Receive
            </button>
            <button
              type="button"
              onClick={() => onNavigate('trade')}
              className="paxi-pressable flex min-h-[4.25rem] flex-col items-center justify-center gap-1 rounded-xl border border-accent/45 bg-accent/15 py-3 text-xs font-semibold text-accent transition-all hover:bg-accent/25"
            >
              <ArrowLeftRight className="w-4 h-4" />
              Swap
            </button>
            <button
              type="button"
              disabled
              className="relative flex min-h-[4.25rem] cursor-not-allowed flex-col items-center justify-center gap-1 rounded-xl border border-border bg-muted/50 py-3 text-xs font-semibold text-muted-foreground"
            >
              <span className="absolute -top-1.5 -right-1 bg-secondary border border-border text-[9px] font-bold text-muted-foreground px-1.5 py-0.5 rounded-full leading-none">
                Soon
              </span>
              <CreditCard className="w-4 h-4" />
              Buy
            </button>
          </div>
          </div>
        </div>

        <div className="mb-6">
          <AssetSearchDrawer balances={balances} onSelectAsset={onSelectAsset} onAddToken={onAddToken} />
        </div>

        {/* Tabs */}
        <div className="mb-6 flex items-center justify-between border-b border-foreground/10">
          <div className="flex gap-1" role="tablist" aria-label="Wallet content">
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'portfolio'}
              onClick={() => setActiveTabChecked('portfolio')}
              className={`min-h-11 rounded-t-lg px-3 pb-3 pt-2 text-sm font-semibold transition-colors ${
                activeTab === 'portfolio' ? 'text-accent border-b-2 border-accent' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Assets
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'history'}
              onClick={() => setActiveTabChecked('history')}
              className={`min-h-11 rounded-t-lg px-3 pb-3 pt-2 text-sm font-semibold transition-colors ${
                activeTab === 'history' ? 'text-accent border-b-2 border-accent' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              History
            </button>
          </div>
          {activeTab === 'portfolio' && (
            <button
              type="button"
              onClick={() => onAddToken()}
              className="paxi-pressable flex min-h-11 items-center gap-1 px-2 pb-3 pt-2 text-xs font-medium text-accent transition-colors hover:text-accent/80"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Token
            </button>
          )}
        </div>

        {/* Assets Tab */}
        {activeTab === 'portfolio' && (
          <div className="min-h-[22rem] space-y-3">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              {([
                ['all', 'All'],
                ['tokens', 'Tokens'],
                ['nfts', 'NFTs'],
                ['other', 'Other'],
              ] as Array<[AssetSection, string]>).map(([section, label]) => (
                <button
                  key={section}
                  type="button"
                  aria-pressed={assetSection === section}
                  onClick={() => setAssetSection(section)}
                  className={`paxi-chip shrink-0 text-xs font-semibold ${assetSection === section ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'}`}
                >
                  {label}
                </button>
              ))}
            </div>
            {isLoading && balanceList.length === 0
              ? Array.from({ length: 5 }).map((_, i) => <AssetRowSkeleton key={i} delay={i * 60} />)
              : (() => {
              const customTokens = getCustomTokens();
              const customKeys = new Set(customTokens.map((t) => assetKey(customTokenToAsset(t))));
              const allAssets = [...ASSETS, ...customTokens.map(customTokenToAsset)];
              const visibleAssets = allAssets.filter((asset) => assetSectionIncludes(assetSection, portfolioAssetKind(asset)));
              if (visibleAssets.length === 0) {
                return (
                  <div className="glass-card p-6 text-center text-sm text-muted-foreground">
                    {assetSection === 'nfts' ? 'Coming soon — NFT inventory is not indexed yet.' : assetSection === 'other' ? 'Coming soon — staked and DeFi positions are not available yet.' : 'No assets found on this device.'}
                  </div>
                );
              }
              return visibleAssets.map((asset, i) => {
                const b = balances[assetKey(asset)];
                const stillLoading = loadingSymbols.has(assetKey(asset));
                const isRemovable = customKeys.has(assetKey(asset));
                const usdValue = b?.balance != null && b?.usdPrice != null ? b.balance * b.usdPrice : null;
                const verificationLabel = isAssetVerified(asset) ? (getTrustedAssetLabel(asset) ?? 'Verified asset listing') : null;
                const resolvedIconUrl = getAssetLogoUrl(asset);
                return (
                  <SwipeToRemove key={assetKey(asset)} disabled={!isRemovable} onRemove={() => handleRemoveToken(asset)}>
                    <button
                      type="button"
                      onClick={() => onSelectAsset(asset, b)}
                      className="paxi-pressable flex min-h-[4.75rem] w-full items-center justify-between glass-card p-4 text-left transition-colors hover:bg-foreground/5"
                    >
                      <div className="flex items-center gap-3">
                        <AssetLogo src={resolvedIconUrl} alt={asset.symbol} fallback={asset.icon} size="md" />
                        <div>
                          <p className="font-semibold text-foreground flex items-center gap-1">
                            {asset.symbol}
                            {verificationLabel && <VerifiedBadge compact label={verificationLabel} />}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {asset.name} · {NETWORKS[asset.network]?.label ?? asset.network}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-foreground tabular-nums">
                          {hideBalance
                            ? MASK
                            : b?.balance != null
                              ? b.balance.toLocaleString(undefined, { maximumFractionDigits: 6 })
                              : stillLoading
                                ? '…'
                                : '—'}
                        </p>
                        <div className="flex items-center justify-end gap-1.5 mt-0.5">
                          <p className="text-xs text-muted-foreground tabular-nums">
                            {hideBalance
                              ? MASK
                              : usdValue != null
                                ? `≈ ${formatFiat(usdValue, currency, fiatRate)}`
                                : stillLoading
                                  ? 'loading…'
                                  : '—'}
                          </p>
                          {!hideBalance && b?.change24h != null && (
                            <span
                              className={`inline-flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                                b.change24h >= 0 ? 'bg-emerald-400/15 text-emerald-400' : 'bg-red-400/15 text-red-400'
                              }`}
                            >
                              {b.change24h >= 0 ? (
                                <TrendingUp className="w-2.5 h-2.5" />
                              ) : (
                                <TrendingDown className="w-2.5 h-2.5" />
                              )}
                              {Math.abs(b.change24h).toFixed(1)}%
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  </SwipeToRemove>
                );
              });
            })()}
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="min-h-[22rem]">
            {isHistoryLoading && txRecords.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-12 text-muted-foreground text-sm">
                <RefreshCw className="w-5 h-5 animate-spin" />
                Loading transaction history…
              </div>
            ) : (
              <TransactionList
                records={txRecords}
                prices={Object.fromEntries(
                  balanceList.filter((b) => b.usdPrice != null).map((b) => [b.asset.symbol, b.usdPrice as number])
                )}
              />
            )}
          </div>
        )}
      </div>
      <BottomNav active="assets" onNavigate={onNavigate} />
    </div>
  );
}

/** Shimmering placeholder shown in place of an asset row while balances are still loading for the first time. */
function AssetRowSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div
      style={{ animationDelay: `${delay}ms` }}
      className="glass-card flex items-center justify-between p-4 animate-in fade-in duration-300 fill-mode-both"
    >
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-foreground/10 animate-pulse" />
        <div className="space-y-1.5">
          <div className="h-3.5 w-16 rounded bg-foreground/10 animate-pulse" />
          <div className="h-2.5 w-24 rounded bg-foreground/10 animate-pulse" />
        </div>
      </div>
      <div className="text-right space-y-1.5">
        <div className="h-3.5 w-14 rounded bg-foreground/10 animate-pulse ml-auto" />
        <div className="h-2.5 w-12 rounded bg-foreground/10 animate-pulse ml-auto" />
      </div>
    </div>
  );
}

/** The big portfolio number - counts up/down smoothly when the value changes (refresh, new prices), instead of jumping instantly. */
function PortfolioValue({ hidden, loading, value, hasValue, currency, fiatRate }: { hidden: boolean; loading: boolean; value: number; hasValue: boolean; currency: import('@/lib/currency').FiatCurrency; fiatRate: number | null }) {
  const animated = useCountUp(value);

  if (hidden) return <h2 className="text-4xl font-bold text-foreground">{MASK}</h2>;
  if (loading || !hasValue) return <h2 className="text-4xl font-bold text-foreground">—</h2>;

  return <h2 className="text-4xl font-bold text-foreground tabular-nums">{formatFiat(animated, currency, fiatRate)}</h2>;
}
