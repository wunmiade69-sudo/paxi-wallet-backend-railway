import { useEffect, useState } from "react";
import {
  Copy,
  Send,
  ArrowDownToLine,
  RefreshCw,
  Eye,
  EyeOff,
  ArrowLeftRight,
  CreditCard,
  Check,
  Plus,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { useCountUp } from "@/hooks/useCountUp";
import { useRef } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { getStoredAddress, getUnlockedMnemonic } from "@/lib/wallet/vault";
import { getAddressForChainType } from "@/lib/wallet/engine";
import {
  fetchAllBalancesStreaming,
  type AssetBalance,
} from "@/lib/wallet/balances";
import {
  ASSETS,
  assetKey,
  NETWORKS,
  normalizeIdentifier,
  type AssetConfig,
} from "@/lib/wallet/chains";
import {
  customTokenToAsset,
  getCustomTokens,
  removeCustomToken,
} from "@/lib/wallet/customTokens";
import { getTxRecords, type TxRecord } from "@/lib/wallet/txHistory";
import { getHistoryStaleWhileRevalidate } from "@/lib/wallet/txIndexer";
import { safeGetLocalStorage, safeSetLocalStorage } from "@/lib/safeStorage";
import {
  convertUsdToFiat,
  fetchFiatRates,
  formatFiat,
  getStoredFiatCurrency,
  isFiatCurrency,
  type FiatCurrency,
  type FiatRates,
} from "@/lib/wallet/fiat";
import { useDepositNotifications } from "@/lib/wallet/depositNotifications";
import {
  getBalanceSnapshot,
  setBalanceSnapshot,
} from "@/lib/wallet/balanceCache";
import TransactionList from "@/components/TransactionList";
import BottomNav, { type NavTab } from "@/components/BottomNav";
import SwipeToRemove from "@/components/SwipeToRemove";
import PaxiLogo from "@/components/PaxiLogo";
import VerifiedBadge from "@/components/VerifiedBadge";
import {
  getAssetLogoUrl,
  getTrustedAssetLabel,
  isTrustedAsset,
} from "@/lib/appInfo";

const HIDE_BALANCE_KEY = "paxi-hide-balance";
const MASK = "••••••";

interface DashboardProps {
  onSend: () => void;
  onReceive: () => void;
  onAddToken: () => void;
  onSelectAsset: (
    asset: AssetConfig,
    balance: AssetBalance | undefined
  ) => void;
  onSelectCampaign: (campaignId: number) => void;
  onNavigate: (tab: NavTab) => void;
}

export default function Dashboard({
  onSend,
  onReceive,
  onAddToken,
  onSelectAsset,
  onSelectCampaign,
  onNavigate,
}: DashboardProps) {
  const [walletAddress, setWalletAddress] = useState("");
  const [isCopied, setIsCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"portfolio" | "history">(
    "portfolio"
  );
  const [balances, setBalances] = useState<Record<string, AssetBalance>>({});
  const [loadingSymbols, setLoadingSymbols] = useState<Set<string>>(new Set());
  const [hideBalance, setHideBalance] = useState(
    () => safeGetLocalStorage(HIDE_BALANCE_KEY) === "true"
  );
  const [txRecords, setTxRecords] = useState<TxRecord[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  // Bumped after removing a custom token - localStorage is the source of
  // truth for custom tokens (read fresh in the render below), this just
  // forces React to re-render and pick up the change.
  const [customTokenVersion, setCustomTokenVersion] = useState(0);
  const [fiatCurrency, setFiatCurrency] = useState<FiatCurrency>(() =>
    getStoredFiatCurrency()
  );
  const [fiatRates, setFiatRates] = useState<FiatRates>({});
  const [fiatRatesLoading, setFiatRatesLoading] = useState(false);
  const refreshInFlight = useRef(false);

  const address = getStoredAddress();
  useDepositNotifications(address);

  const toggleHideBalance = () => {
    setHideBalance(prev => {
      const next = !prev;
      safeSetLocalStorage(HIDE_BALANCE_KEY, String(next));
      return next;
    });
  };

  useEffect(() => {
    if (address) setWalletAddress(address);
  }, [address]);

  useEffect(() => {
    const handleCurrencyChange = (event: Event) => {
      const next = (event as CustomEvent<string>).detail;
      if (isFiatCurrency(next)) setFiatCurrency(next);
    };
    window.addEventListener("paxi-currency-change", handleCurrencyChange);
    return () =>
      window.removeEventListener("paxi-currency-change", handleCurrencyChange);
  }, []);

  useEffect(() => {
    if (fiatCurrency === "USD") {
      setFiatRates({});
      setFiatRatesLoading(false);
      return;
    }

    const controller = new AbortController();
    setFiatRatesLoading(true);
    void fetchFiatRates(controller.signal)
      .then(setFiatRates)
      .catch(() => {
        if (!controller.signal.aborted) setFiatRates({});
      })
      .finally(() => {
        if (!controller.signal.aborted) setFiatRatesLoading(false);
      });

    return () => controller.abort();
  }, [fiatCurrency]);

  const loadBalances = async ({ force = false }: { force?: boolean } = {}) => {
    if (!address || refreshInFlight.current) return;

    const cached = getBalanceSnapshot(address);
    if (!force && cached) {
      setBalances(cached);
      setLoadingSymbols(new Set());
      return;
    }

    refreshInFlight.current = true;
    const allAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
    setLoadingSymbols(new Set(allAssets.map(assetKey)));
    const mnemonic = getUnlockedMnemonic();
    const solAddress = mnemonic
      ? (getAddressForChainType(mnemonic, "sol") ?? undefined)
      : undefined;
    const btcAddress = mnemonic
      ? (getAddressForChainType(mnemonic, "btc") ?? undefined)
      : undefined;
    const nextBalances: Record<string, AssetBalance> = cached ?? {};

    try {
      await fetchAllBalancesStreaming(
        address,
        result => {
          nextBalances[assetKey(result.asset)] = result;
          setBalances({ ...nextBalances });
          setBalanceSnapshot(address, nextBalances);
          setLoadingSymbols(prev => {
            const next = new Set(prev);
            next.delete(assetKey(result.asset));
            return next;
          });
        },
        solAddress,
        btcAddress
      );
    } catch {
      toast.error("Could not refresh balances. Check your connection.");
      setLoadingSymbols(new Set());
    } finally {
      refreshInFlight.current = false;
    }
  };

  const handleRemoveToken = (asset: AssetConfig) => {
    if (!asset.contractAddress) return;
    removeCustomToken(asset.contractAddress, asset.network);
    setBalances(prev => {
      const next = { ...prev };
      delete next[assetKey(asset)];
      if (address) setBalanceSnapshot(address, next);
      return next;
    });
    setCustomTokenVersion(v => v + 1);
    toast.success(`${asset.symbol} removed`);
  };

  useEffect(() => {
    if (address) {
      const cached = getBalanceSnapshot(address);
      if (cached) {
        setBalances(cached);
        setLoadingSymbols(new Set());
      } else {
        void loadBalances();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, customTokenVersion]);

  const balanceList = Object.values(balances);
  const isLoading = loadingSymbols.size > 0;

  // Fetched once for the whole list rather than per-asset - a query per row
  // would mean dozens of requests just to show a checkmark.
  const { data: verifiedListings } = trpc.listings.listVerified.useQuery();
  const { data: featuredCampaigns } = trpc.campaigns.featured.useQuery();
  const verifiedKeys = new Set(
    (verifiedListings ?? []).map(
      l => `${l.network}:${normalizeIdentifier(l.network, l.contractAddress)}`
    )
  );
  const isAssetVerified = (asset: AssetConfig) => {
    if (isTrustedAsset(asset)) return true;
    if (!asset.contractAddress) return false;
    return verifiedKeys.has(
      `${asset.network}:${normalizeIdentifier(asset.network, asset.contractAddress)}`
    );
  };

  const portfolioValue = balanceList.reduce((total, b) => {
    if (b.balance == null || b.usdPrice == null) return total;
    return total + b.balance * b.usdPrice;
  }, 0);

  // Weighted 24h change: reconstruct what the portfolio was worth 24h ago
  // per-asset (today's value / (1 + change%)), then compare totals - so an
  // asset that's a bigger share of the portfolio moves the number more,
  // same as how a real portfolio's % change works.
  const portfolioValue24hAgo = balanceList.reduce((total, b) => {
    if (b.balance == null || b.usdPrice == null) return total;
    const valueToday = b.balance * b.usdPrice;
    const changeFraction = (b.change24h ?? 0) / 100;
    const valueYesterday =
      changeFraction !== -1 ? valueToday / (1 + changeFraction) : valueToday;
    return total + valueYesterday;
  }, 0);
  const portfolioChangePercent =
    portfolioValue24hAgo > 0
      ? ((portfolioValue - portfolioValue24hAgo) / portfolioValue24hAgo) * 100
      : 0;
  const displayedPortfolioValue = convertUsdToFiat(
    portfolioValue,
    fiatCurrency,
    fiatRates
  );
  const fiatUnavailable =
    fiatCurrency !== "USD" &&
    displayedPortfolioValue == null &&
    portfolioValue > 0;

  const setActiveTabChecked = (tab: "portfolio" | "history") => {
    if (tab === "history") {
      setTxRecords(getTxRecords()); // instant paint from local log
      if (address) {
        const cached = getHistoryStaleWhileRevalidate(address, fresh => {
          setTxRecords(fresh.records);
          setIsHistoryLoading(false);
        });
        if (cached.length > 0)
          setTxRecords(cached); // cache beats the bare local log if we have it
        else setIsHistoryLoading(true);
      }
    }
    setActiveTab(tab);
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    setIsCopied(true);
    toast.success("Wallet address copied!");
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <PaxiLogo
              size="sm"
              priority
              className="h-9 w-9 border-accent/70 shadow-[0_0_20px_rgba(245,158,11,0.2)]"
            />
            <div>
              <h1 className="text-lg font-black tracking-[0.16em] text-accent">
                PAXI
              </h1>
              <p className="mt-0.5 text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                Secure wallet
              </p>
            </div>
          </div>
          <span className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.14em] text-foreground/55">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Ready
          </span>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto px-6 py-8">
        {featuredCampaigns && featuredCampaigns.length > 0 && (
          <section className="mb-6" aria-label="Featured campaigns">
            <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto pb-1 no-scrollbar">
              {featuredCampaigns.map(campaign => (
                <button
                  key={campaign.id}
                  onClick={() => onSelectCampaign(campaign.id)}
                  aria-label={`Open ${campaign.title} campaign`}
                  className="w-full shrink-0 snap-center overflow-hidden rounded-2xl border border-border bg-secondary active:scale-[0.99] transition-transform"
                >
                  {campaign.bannerKey ? (
                    <img
                      src={`/manus-storage/${campaign.bannerKey}`}
                      alt={`${campaign.title} campaign banner`}
                      className="h-36 w-full object-cover"
                    />
                  ) : (
                    <div className="h-36 w-full bg-gradient-to-br from-accent/30 to-secondary" />
                  )}
                </button>
              ))}
            </div>
          </section>
        )}
        {/* Portfolio Card */}
        <div className="glass-card mb-8 animate-fade-in relative overflow-hidden">
          <div
            className="absolute inset-0 pointer-events-none opacity-60"
            style={{
              background:
                "radial-gradient(circle at 15% 0%, var(--accent) 0%, transparent 45%), radial-gradient(circle at 100% 100%, var(--accent) 0%, transparent 35%)",
              opacity: 0.12,
            }}
          />
          <div className="relative">
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-sm">Total Portfolio</p>
              <div className="flex items-center gap-1">
                <button
                  onClick={toggleHideBalance}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                  title={hideBalance ? "Show balance" : "Hide balance"}
                  aria-label={hideBalance ? "Show balance" : "Hide balance"}
                >
                  {hideBalance ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
                <button
                  onClick={() => void loadBalances({ force: true })}
                  disabled={refreshInFlight.current}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all disabled:opacity-50"
                  title="Refresh balances"
                  aria-label="Refresh balances"
                >
                  <RefreshCw
                    className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`}
                  />
                </button>
              </div>
            </div>
            <div className="flex items-end gap-3 mb-6">
              <PortfolioValue
                hidden={hideBalance}
                loading={isLoading && balanceList.length === 0}
                value={displayedPortfolioValue}
                currency={fiatCurrency}
                unavailable={
                  fiatUnavailable ||
                  (fiatCurrency !== "USD" &&
                    fiatRatesLoading &&
                    portfolioValue > 0)
                }
              />
              {!hideBalance &&
                !(isLoading && balanceList.length === 0) &&
                portfolioValue > 0 && (
                  <span
                    className={`flex items-center gap-1 text-sm font-semibold mb-1.5 ${
                      portfolioChangePercent >= 0
                        ? "text-emerald-400"
                        : "text-red-400"
                    }`}
                  >
                    {portfolioChangePercent >= 0 ? (
                      <TrendingUp className="w-3.5 h-3.5" />
                    ) : (
                      <TrendingDown className="w-3.5 h-3.5" />
                    )}
                    {portfolioChangePercent >= 0 ? "+" : ""}
                    {portfolioChangePercent.toFixed(2)}% Today
                  </span>
                )}
            </div>

            {/* Wallet Address */}
            <div className="bg-secondary/50 rounded-lg p-3 mb-4">
              <p className="text-xs text-muted-foreground mb-1">
                Wallet Address (EVM)
              </p>
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs font-mono text-accent truncate">
                  {walletAddress}
                </p>
                <button
                  onClick={handleCopyAddress}
                  className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                  aria-label="Copy address"
                >
                  {isCopied ? (
                    <Check className="w-4 h-4 text-accent" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={onSend}
                className="bg-accent/20 hover:bg-accent/30 border border-accent/50 rounded-lg py-3 text-xs font-semibold text-accent transition-all active:scale-95 flex flex-col items-center gap-1"
              >
                <Send className="w-4 h-4" />
                Send
              </button>
              <button
                onClick={onReceive}
                className="bg-accent/20 hover:bg-accent/30 border border-accent/50 rounded-lg py-3 text-xs font-semibold text-accent transition-all active:scale-95 flex flex-col items-center gap-1"
              >
                <ArrowDownToLine className="w-4 h-4" />
                Receive
              </button>
              <button
                onClick={() => onNavigate("trade")}
                className="bg-accent/20 hover:bg-accent/30 border border-accent/50 rounded-lg py-3 text-xs font-semibold text-accent transition-all active:scale-95 flex flex-col items-center gap-1"
              >
                <ArrowLeftRight className="w-4 h-4" />
                Swap
              </button>
              <button
                disabled
                className="relative bg-muted/50 border border-border rounded-lg py-3 text-xs font-semibold text-muted-foreground cursor-not-allowed flex flex-col items-center gap-1"
              >
                <span className="absolute -top-1.5 -right-1 bg-secondary border border-border text-[9px] font-bold text-muted-foreground px-1.5 py-0.5 rounded-full leading-none">
                  Soon
                </span>
                <CreditCard className="w-4 h-4" />
                Buy
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center justify-between mb-6 border-b border-foreground/5">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTabChecked("portfolio")}
              className={`pb-3 px-2 text-sm font-semibold transition-colors ${
                activeTab === "portfolio"
                  ? "text-accent border-b-2 border-accent"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Assets
            </button>
            <button
              onClick={() => setActiveTabChecked("history")}
              className={`pb-3 px-2 text-sm font-semibold transition-colors ${
                activeTab === "history"
                  ? "text-accent border-b-2 border-accent"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              History
            </button>
          </div>
          {activeTab === "portfolio" && (
            <button
              onClick={onAddToken}
              className="flex items-center gap-1 text-xs font-medium text-accent hover:text-accent/80 transition-colors pb-3 px-2"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Token
            </button>
          )}
        </div>

        {/* Assets Tab */}
        {activeTab === "portfolio" && (
          <div className="space-y-3 animate-fade-in">
            {isLoading && balanceList.length === 0
              ? Array.from({ length: 5 }).map((_, i) => (
                  <AssetRowSkeleton key={i} delay={i * 60} />
                ))
              : (() => {
                  const customTokens = getCustomTokens();
                  const customKeys = new Set(
                    customTokens.map(t => assetKey(customTokenToAsset(t)))
                  );
                  const allAssets = [
                    ...ASSETS,
                    ...customTokens.map(customTokenToAsset),
                  ];
                  return allAssets.map((asset, i) => {
                    const b = balances[assetKey(asset)];
                    const stillLoading = loadingSymbols.has(assetKey(asset));
                    const isRemovable = customKeys.has(assetKey(asset));
                    const usdValue =
                      b?.balance != null && b?.usdPrice != null
                        ? b.balance * b.usdPrice
                        : null;
                    const fiatValue =
                      usdValue != null
                        ? convertUsdToFiat(usdValue, fiatCurrency, fiatRates)
                        : null;
                    const verificationLabel = isAssetVerified(asset)
                      ? (getTrustedAssetLabel(asset) ??
                        "Verified asset listing")
                      : null;
                    const resolvedIconUrl = getAssetLogoUrl(asset);
                    return (
                      <SwipeToRemove
                        key={assetKey(asset)}
                        disabled={!isRemovable}
                        onRemove={() => handleRemoveToken(asset)}
                      >
                        <button
                          onClick={() => onSelectAsset(asset, b)}
                          style={{
                            animationDelay: `${Math.min(i, 10) * 40}ms`,
                          }}
                          className="w-full glass-card flex items-center justify-between p-4 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both"
                        >
                          <div className="flex items-center gap-3">
                            {resolvedIconUrl ? (
                              <img
                                src={resolvedIconUrl}
                                alt={asset.symbol}
                                className="w-8 h-8 rounded-full bg-foreground/5 object-contain"
                                onError={e => {
                                  (
                                    e.currentTarget as HTMLImageElement
                                  ).style.display = "none";
                                  (
                                    e.currentTarget
                                      .nextElementSibling as HTMLElement
                                  ).style.display = "inline";
                                }}
                              />
                            ) : null}
                            <span
                              className="text-2xl"
                              style={{
                                display: resolvedIconUrl ? "none" : "inline",
                              }}
                            >
                              {asset.icon}
                            </span>
                            <div>
                              <p className="font-semibold text-foreground flex items-center gap-1">
                                {asset.symbol}
                                {verificationLabel && (
                                  <VerifiedBadge
                                    compact
                                    label={verificationLabel}
                                  />
                                )}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {asset.name} ·{" "}
                                {NETWORKS[asset.network]?.label ??
                                  asset.network}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-foreground tabular-nums">
                              {hideBalance
                                ? MASK
                                : stillLoading
                                  ? "…"
                                  : b?.balance != null
                                    ? b.balance.toLocaleString(undefined, {
                                        maximumFractionDigits: 6,
                                      })
                                    : "—"}
                            </p>
                            <div className="flex items-center justify-end gap-1.5 mt-0.5">
                              <p className="text-xs text-muted-foreground tabular-nums">
                                {hideBalance
                                  ? MASK
                                  : stillLoading
                                    ? "loading…"
                                    : fiatValue != null
                                      ? `≈ ${formatFiat(fiatValue, fiatCurrency)}`
                                      : usdValue != null &&
                                          fiatCurrency !== "USD"
                                        ? fiatRatesLoading
                                          ? "loading rate…"
                                          : "rate unavailable"
                                        : "no price feed"}
                              </p>
                              {!hideBalance && b?.change24h != null && (
                                <span
                                  className={`inline-flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                                    b.change24h >= 0
                                      ? "bg-emerald-400/15 text-emerald-400"
                                      : "bg-red-400/15 text-red-400"
                                  }`}
                                >
                                  {b.change24h >= 0 ? (
                                    <TrendingUp className="w-2.5 h-2.5" />
                                  ) : (
                                    <TrendingDown className="w-2.5 h-2.5" />
                                  )}
                                  {Math.abs(b.change24h).toFixed(1)}%
                                </span>
                              )}
                            </div>
                          </div>
                        </button>
                      </SwipeToRemove>
                    );
                  });
                })()}
          </div>
        )}

        {/* History Tab */}
        {activeTab === "history" && (
          <div className="animate-fade-in">
            {isHistoryLoading && txRecords.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-12 text-muted-foreground text-sm">
                <RefreshCw className="w-5 h-5 animate-spin" />
                Loading transaction history…
              </div>
            ) : (
              <TransactionList
                records={txRecords}
                prices={Object.fromEntries(
                  balanceList
                    .filter(b => b.usdPrice != null)
                    .map(b => [b.asset.symbol, b.usdPrice as number])
                )}
                currency={fiatCurrency}
                fiatRates={fiatRates}
              />
            )}
          </div>
        )}
      </div>
      <BottomNav active="assets" onNavigate={onNavigate} />
    </div>
  );
}

/** Shimmering placeholder shown in place of an asset row while balances are still loading for the first time. */
function AssetRowSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div
      style={{ animationDelay: `${delay}ms` }}
      className="glass-card flex items-center justify-between p-4 animate-in fade-in duration-300 fill-mode-both"
    >
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-foreground/10 animate-pulse" />
        <div className="space-y-1.5">
          <div className="h-3.5 w-16 rounded bg-foreground/10 animate-pulse" />
          <div className="h-2.5 w-24 rounded bg-foreground/10 animate-pulse" />
        </div>
      </div>
      <div className="text-right space-y-1.5">
        <div className="h-3.5 w-14 rounded bg-foreground/10 animate-pulse ml-auto" />
        <div className="h-2.5 w-12 rounded bg-foreground/10 animate-pulse ml-auto" />
      </div>
    </div>
  );
}

/** The big portfolio number - counts up/down smoothly when the value changes (refresh, new prices), instead of jumping instantly. */
function PortfolioValue({
  hidden,
  loading,
  value,
  currency,
  unavailable,
}: {
  hidden: boolean;
  loading: boolean;
  value: number | null;
  currency: FiatCurrency;
  unavailable: boolean;
}) {
  const animated = useCountUp(value ?? 0);

  if (hidden)
    return <h2 className="text-4xl font-bold text-foreground">{MASK}</h2>;
  if (loading || unavailable || value == null)
    return <h2 className="text-4xl font-bold text-foreground">—</h2>;

  return (
    <h2 className="text-4xl font-bold text-foreground tabular-nums">
      {formatFiat(animated, currency)}
    </h2>
  );
}
