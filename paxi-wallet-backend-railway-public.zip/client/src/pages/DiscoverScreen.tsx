import { useEffect, useState } from 'react';
import { Compass, ArrowUpRight, Star, Clock, X, Link2, Repeat2, Layers, Landmark, Image, Route, LayoutGrid, Gamepad2, Users, CreditCard, GraduationCap, Coins, Sparkles, CheckCircle2, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import AssetLogo from '@/components/AssetLogo';
import NotificationBell from '@/components/NotificationBell';
import NetworkPickerDrawer from '@/components/NetworkPickerDrawer';
import { trpc } from '@/lib/trpc';
import {
  CURATED_DAPPS,
  addRecent,
  resolveDappLogo,
  getFavorites,
  getRecents,
  isFavorite,
  normalizeUrl,
  removeRecent,
  toggleFavorite,
  formatCompactUsd,
  type DappEntry,
  toDiscoverEntry,
} from '@/lib/wallet/discover';
import { DISCOVER_CATEGORY_LABELS, type DiscoverCategory, type DiscoverEntry, type RiskStatus, type VerificationStatus } from '@/lib/phase3Models';
import { NETWORKS } from '@/lib/wallet/chains';
import { describeUserFacingError } from '@/lib/userFacingError';

interface DiscoverScreenProps {
  onNavigate: (tab: NavTab) => void;
  onWeb3Browser: () => void;
  onSelectCampaign: (campaignId: number) => void;
  onNotifications: () => void;
}

type CategoryFilter = 'All' | DiscoverCategory;

const CATEGORY_META: Record<DiscoverCategory, { icon: typeof Repeat2 }> = {
  defi: { icon: Repeat2 },
  exchanges: { icon: Layers },
  bridge: { icon: Route },
  lending: { icon: Landmark },
  nft: { icon: Image },
  games: { icon: Gamepad2 },
  social: { icon: Users },
  payments: { icon: CreditCard },
  staking: { icon: Coins },
  paxi: { icon: Sparkles },
  earn: { icon: Coins },
  learn: { icon: GraduationCap },
  trending: { icon: Sparkles },
};

const FEATURED = CURATED_DAPPS.filter((d) => d.featured);
const DISCOVER_ENTRIES: DiscoverEntry[] = CURATED_DAPPS.map(toDiscoverEntry);
const FILTERS: CategoryFilter[] = [
  'All',
  ...Object.keys(DISCOVER_CATEGORY_LABELS).filter((category): category is DiscoverCategory =>
    DISCOVER_ENTRIES.some((entry) => entry.category === category),
  ),
];

/** A protocol counts as "Hot" off real 7-day TVL growth (DefiLlama), not a guess — see server/discoverStats.ts. */
const HOT_7D_GROWTH_THRESHOLD_PCT = 5;

function formatNetworkNames(networks: string[]): string {
  return networks.length
    ? networks.map((network) => NETWORKS[network]?.label ?? network).join(' · ')
    : 'Network details pending';
}

export default function DiscoverScreen({ onNavigate, onWeb3Browser, onSelectCampaign, onNotifications }: DiscoverScreenProps) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<CategoryFilter>('All');
  const [chainFilter, setChainFilter] = useState('All');
  const [recents, setRecents] = useState(getRecents());
  const [favorites, setFavorites] = useState(getFavorites());
  const { data: campaigns, isLoading: campaignsLoading, isError: campaignsError } = trpc.campaigns.listActive.useQuery();
  const { data: protocolStats } = trpc.discover.protocolStats.useQuery(undefined, {
    staleTime: 10 * 60_000,
    retry: 1,
  });

  useEffect(() => {
    setRecents(getRecents());
    setFavorites(getFavorites());
  }, []);

  const openLink = (url: string) => {
    try {
      const safeUrl = normalizeUrl(url);
      window.open(safeUrl, '_blank', 'noopener,noreferrer');
      addRecent(safeUrl);
      setRecents(getRecents());
    } catch (err) {
      toast.error(describeUserFacingError(err, 'This link cannot be opened safely.'));
    }
  };

  const handleGo = () => {
    const trimmed = query.trim();
    if (!trimmed) {
      toast.error('Search for a dApp or paste a link first.');
      return;
    }
    const looksLikeUrl = /^https?:\/\//i.test(trimmed) || /^(?:www\.)?[^\s/]+\.[^\s/]+(?:\/|$)/i.test(trimmed);
    if (!looksLikeUrl) {
      setFilter('All');
      return;
    }
    try {
      const url = normalizeUrl(trimmed);
      openLink(url);
      setQuery('');
    } catch (err) {
      toast.error(describeUserFacingError(err, 'Enter a valid HTTPS link.'));
    }
  };

  const handleToggleFavorite = (url: string) => {
    toggleFavorite(url);
    setFavorites(getFavorites());
  };

  const selectedNetwork = chainFilter === 'All' ? undefined : NETWORKS[chainFilter];
  const normalizedQuery = query.trim().toLowerCase();
  const visibleDapps = DISCOVER_ENTRIES.filter((d) => {
    const matchesCategory = filter === 'All' || d.category === filter;
    const matchesChain = chainFilter === 'All' || d.supportedChains.includes(chainFilter);
    const matchesQuery = !normalizedQuery || [d.name, d.description, d.domain, d.category, ...d.supportedChains].some((value) => (value ?? '').toLowerCase().includes(normalizedQuery));
    return matchesCategory && matchesChain && matchesQuery;
  });

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-24">
      <div className="paxi-page-header sticky top-0 z-40">
          <div className="mx-auto flex max-w-md items-end justify-between gap-3 px-4 py-4 sm:px-6">
            <div className="min-w-0">
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Explore the ecosystem</p>
              <h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground">Discover</h1>
              <p className="mt-1 text-xs text-muted-foreground">Find useful apps, markets, and campaigns in one place</p>
              <p className="mt-1 text-[10px] text-muted-foreground/80">Listings are curated for discovery and are not security endorsements.</p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <NotificationBell onOpen={onNotifications} />
              <div className="w-[9.5rem] sm:w-44">
              <NetworkPickerDrawer
                label="Discover network"
                networks={Object.values(NETWORKS)}
                selected={selectedNetwork}
                onSelect={setChainFilter}
                onSelectAll={() => setChainFilter('All')}
                allLabel="All networks"
              />
              </div>
            </div>
          </div>
      </div>

      <div className="mx-auto max-w-md space-y-7 px-4 py-6 sm:px-6">
        {/* Link bar */}
        <div className="flex items-center gap-2">
          <div className="relative min-w-0 flex-1">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleGo()}
              aria-label="Search apps or open a secure link"
              type="search"
              placeholder="Search apps or paste a secure link…"
              className="paxi-field w-full px-3.5 py-2.5 pr-9 text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Clear search"
                className="absolute right-1.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-foreground/10 hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={handleGo}
            className="paxi-pressable flex min-h-11 shrink-0 items-center rounded-xl bg-accent px-4 py-2.5 text-sm font-semibold text-accent-foreground transition-all hover:bg-accent/90"
          >
            Go
          </button>
        </div>

        {/* Featured - the one place this screen spends visual boldness: bigger cards, a
            gradient wash, so the handful of dapps most people actually want feel found
            rather than buried in an alphabetical list. */}
        <section>
          <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5 px-1">Featured</h2>
          <div className="flex gap-3 overflow-x-auto pb-1 -mx-6 px-6 no-scrollbar snap-x snap-mandatory">
            {FEATURED.map((dapp, i) => {
              const stat = dapp.id ? protocolStats?.[dapp.id] : undefined;
              const isHot = typeof stat?.change7dPct === 'number' && stat.change7dPct >= HOT_7D_GROWTH_THRESHOLD_PCT;
              return (
              <button
                key={dapp.url}
                onClick={() => openLink(dapp.url)}
                style={{ animationDelay: `${i * 60}ms` }}
                type="button"
                className="paxi-pressable animate-in fade-in slide-in-from-bottom-2 duration-300 fill-mode-both snap-start shrink-0 w-44 rounded-2xl border border-accent/20 bg-gradient-to-br from-accent/20 via-secondary to-secondary p-4 text-left transition-all hover:border-accent/40"
              >
                <div className="flex items-start justify-between gap-2">
                  <FeaturedLogo dapp={dapp} />
                  {isHot && (
                    <span className="flex shrink-0 items-center gap-1 rounded-full bg-emerald-400/15 px-2 py-1 text-[10px] font-semibold text-emerald-300">
                      <TrendingUp className="h-2.5 w-2.5" /> Hot
                    </span>
                  )}
                </div>
                <div className="mt-3 flex items-center gap-1">
                  <p className="min-w-0 truncate text-sm font-semibold text-foreground">{dapp.name}</p>
                  <VerifiedTick verification={dapp.verification ?? 'unknown'} />
                </div>
                <p className="mt-0.5 line-clamp-2 text-[11px] leading-snug text-muted-foreground">{dapp.description}</p>
                <div className="mt-2 flex items-center justify-between gap-1.5">
                  <span className="min-w-0 truncate rounded-full bg-foreground/10 px-2 py-1 text-[10px] font-medium text-muted-foreground">
                    {formatNetworkNames(dapp.supportedChains ?? [])}
                  </span>
                  {stat ? (
                    <span className="shrink-0 whitespace-nowrap text-[10px] font-semibold text-accent">{formatCompactUsd(stat.tvlUsd)} TVL</span>
                  ) : (
                    <RiskPill risk={dapp.risk ?? 'unknown'} />
                  )}
                </div>
              </button>
              );
            })}
          </div>
        </section>

          {campaignsLoading && (
            <div className="flex gap-3 overflow-x-auto px-1 pb-1 no-scrollbar" aria-label="Loading featured campaigns" aria-busy="true">
              {Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="w-64 shrink-0 overflow-hidden rounded-2xl border border-border bg-secondary/40">
                  <div className="h-28 w-full animate-pulse bg-secondary" />
                  <div className="space-y-2 p-3">
                    <div className="h-3 w-2/3 animate-pulse rounded bg-secondary" />
                    <div className="h-2.5 w-full animate-pulse rounded bg-secondary" />
                    <div className="h-2.5 w-1/2 animate-pulse rounded bg-secondary" />
                  </div>
                </div>
              ))}
            </div>
          )}
          {campaignsError && <div className="rounded-xl border border-border bg-secondary/40 p-4 text-xs text-muted-foreground">Featured campaigns are unavailable right now.</div>}
          {campaigns && campaigns.length > 0 && (
          <section>
            <div className="mb-2.5 flex items-center justify-between px-1"><h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Featured campaigns</h2><span className="text-[10px] font-semibold uppercase tracking-wide text-emerald-300">Live</span></div>
            <div className="flex gap-3 overflow-x-auto px-1 pb-1 no-scrollbar snap-x snap-mandatory">
              {campaigns.slice(0, 8).map((campaign) => (
                <button key={campaign.id} type="button" onClick={() => onSelectCampaign(campaign.id)} className="paxi-pressable snap-start shrink-0 w-64 overflow-hidden rounded-2xl border border-border bg-secondary text-left transition-transform">
                  {campaign.bannerKey ? <img src={`/manus-storage/${campaign.bannerKey}`} alt="" className="h-28 w-full object-cover" /> : <div className="h-28 bg-gradient-to-br from-accent/30 to-secondary" />}
                  <div className="space-y-2 p-3"><div className="flex items-center gap-2">{campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-7 w-7 rounded-lg object-cover" />}<p className="truncate text-sm font-semibold text-foreground">{campaign.title}</p></div><p className="line-clamp-2 text-xs text-muted-foreground">{campaign.description || `Earn ${campaign.rewardAmount} ${campaign.rewardTokenSymbol} with PAXI`}</p><div className="flex items-center justify-between text-[10px]"><span className="font-semibold text-emerald-300">● LIVE</span><span className="text-muted-foreground">{campaign.winnersCount}/{campaign.maxWinners} slots claimed</span></div></div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Open the selected destination in the browser for full site compatibility. */}
        <button
          onClick={onWeb3Browser}
          type="button"
          className="paxi-pressable flex min-h-16 w-full items-center gap-3 glass-card !p-4 text-left transition-all hover:bg-foreground/5"
        >
          <span className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
            <Link2 className="w-4.5 h-4.5 text-accent" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-foreground text-sm">Explore dApps</p>
            <p className="text-xs text-muted-foreground truncate">
              Open a curated destination in your browser, then return to Paxi when you are ready to connect.
            </p>
          </div>
          <ArrowUpRight className="w-4 h-4 text-muted-foreground shrink-0" />
        </button>

        {/* Favorites */}
        {favorites.length > 0 && (
          <section>
            <h2 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5 px-1">
              <Star className="w-3.5 h-3.5" /> Favorites
            </h2>
            <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
              {favorites.map((link, i) => (
                <LinkRow
                  key={link.id}
                  index={i}
                  label={link.label}
                  url={link.url}
                  iconUrl={resolveDappLogo({ url: link.url })}
                  onOpen={() => openLink(link.url)}
                  onToggleFavorite={() => handleToggleFavorite(link.url)}
                  isFav
                />
              ))}
            </div>
          </section>
        )}

        {/* Recents */}
        {recents.length > 0 && (
          <section>
            <h2 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5 px-1">
              <Clock className="w-3.5 h-3.5" /> Recently Opened
            </h2>
            <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
              {recents.map((link, i) => (
                <LinkRow
                  key={link.id}
                  index={i}
                  label={link.label}
                  url={link.url}
                  iconUrl={resolveDappLogo({ url: link.url })}
                  onOpen={() => openLink(link.url)}
                  onToggleFavorite={() => handleToggleFavorite(link.url)}
                  isFav={isFavorite(link.url)}
                  onRemove={() => {
                    removeRecent(link.id);
                    setRecents(getRecents());
                  }}
                />
              ))}
            </div>
          </section>
        )}

        {/* Directory - category pills filter one shared list instead of stacking every
            category as its own always-visible section, so scanning scales past 8 dapps. */}
        <section>
          <div className="mb-3 flex items-center justify-between gap-3 px-1">
            <p className="text-[10px] text-muted-foreground">
              {visibleDapps.length} curated dApp{visibleDapps.length === 1 ? '' : 's'}
            </p>
            <p className="shrink-0 text-[10px] font-semibold uppercase tracking-wide text-accent">
              {selectedNetwork?.label ?? 'All networks'}
            </p>
          </div>
          <div className="flex items-center gap-1.5 mb-3 px-1 overflow-x-auto no-scrollbar">
            {FILTERS.map((f) => {
              const Icon = f === 'All' ? LayoutGrid : CATEGORY_META[f].icon;
              const active = filter === f;
              return (
                <button
                  key={f}
                  type="button"
                  onClick={() => setFilter(f)}
                  aria-pressed={active}
                  className={`paxi-chip flex items-center gap-1.5 shrink-0 text-xs font-semibold transition-all ${
                    active
                      ? 'bg-accent text-accent-foreground'
                      : 'bg-secondary text-muted-foreground hover:text-foreground border border-border'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {f === 'All' ? 'All' : DISCOVER_CATEGORY_LABELS[f]}
                </button>
              );
            })}
          </div>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            {visibleDapps.length > 0 ? visibleDapps.map((dapp, i) => (
              <LinkRow
                key={dapp.id}
                index={i}
                label={dapp.name}
                description={dapp.description}
                meta={dapp.status !== 'available' ? dapp.status : undefined}
                chainSummary={formatNetworkNames(dapp.supportedChains)}
                verification={dapp.verification}
                risk={dapp.risk}
                tvlUsd={protocolStats?.[dapp.id]?.tvlUsd}
                url={dapp.url ?? ''}
                iconUrl={resolveDappLogo(dapp)}
                cacheKey={`dapp:${dapp.id ?? dapp.url}`}
                onOpen={() => dapp.url && openLink(dapp.url)}
                onToggleFavorite={() => dapp.url && handleToggleFavorite(dapp.url)}
                isFav={dapp.url ? isFavorite(dapp.url) : false}
              />
            )) : (
              <div className="p-6 text-center text-sm text-muted-foreground">{normalizedQuery ? 'No curated dApps match this search.' : chainFilter !== 'All' ? 'No curated dApps support this network yet.' : 'No curated dApps are available for this selection.'}</div>
            )}
          </div>
        </section>

        {favorites.length === 0 && recents.length === 0 && (
          <div className="text-center py-2">
            <div className="w-12 h-12 rounded-full bg-foreground/5 flex items-center justify-center mx-auto mb-3">
              <Compass className="w-5 h-5 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">Choose a featured app above, or search for a destination to get started.</p>
          </div>
        )}
      </div>

      <BottomNav active="discover" onNavigate={onNavigate} />
    </div>
  );
}

function FeaturedLogo({ dapp }: { dapp: DappEntry }) {
  return <AssetLogo src={resolveDappLogo(dapp)} cacheKey={`dapp:${dapp.id ?? dapp.url}`} fallback={dapp.name.charAt(0)} size="md" aria-hidden={true} className="border-white/10 bg-white text-accent" />;
}

/** Inline check next to a name — only rendered when the catalog actually marks
    an entry verified. No entry is verified today, so this renders nothing yet;
    it's wired to the real field so it lights up the moment that data exists. */
function VerifiedTick({ verification }: { verification: VerificationStatus }) {
  if (verification !== 'verified') return null;
  return <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-400" aria-label="Verified" />;
}

/** Shows a risk badge only when a real signal exists; missing risk data is not
    presented as a warning or a fabricated rating. */
function RiskPill({ risk }: { risk: RiskStatus }) {
  if (risk === 'unknown') return null;
  const meta: Record<RiskStatus, { label: string; className: string }> = {
    good: { label: 'Low risk', className: 'bg-emerald-400/15 text-emerald-300' },
    review: { label: 'Needs review', className: 'bg-amber-400/15 text-amber-300' },
    warning: { label: 'High risk', className: 'bg-red-400/15 text-red-300' },
    unknown: { label: '', className: '' },
  };
  const { label, className } = meta[risk];
  return <span className={`shrink-0 whitespace-nowrap rounded-full px-2 py-1 text-[10px] font-semibold ${className}`}>{label}</span>;
}

function LinkRow({
  index,
  label,
  description,
  meta,
  chainSummary,
  verification,
  risk,
  tvlUsd,
  url,
  iconUrl,
  cacheKey,
  onOpen,
  onToggleFavorite,
  isFav,
  onRemove,
}: {
  index: number;
  label: string;
  description?: string;
  meta?: string;
  chainSummary?: string;
  verification?: VerificationStatus;
  risk?: RiskStatus;
  tvlUsd?: number;
  url: string;
  iconUrl?: string;
  cacheKey?: string;
  onOpen: () => void;
  onToggleFavorite: () => void;
  isFav: boolean;
  onRemove?: () => void;
}) {
  return (
    <div
      style={{ animationDelay: `${Math.min(index, 8) * 40}ms` }}
      className="animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both flex min-h-[4.75rem] items-center gap-3 px-4 py-3.5"
    >
      <button type="button" onClick={onOpen} className="paxi-pressable flex min-h-11 min-w-0 flex-1 items-center gap-3 text-left">
        <AssetLogo src={iconUrl} cacheKey={cacheKey} fallback={label.charAt(0)} size="sm" aria-hidden={true} className="border-white/10 bg-white" />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1">
            <p className="min-w-0 truncate text-sm font-semibold text-foreground">{label}</p>
            {verification && <VerifiedTick verification={verification} />}
          </div>
          <p className="text-xs text-muted-foreground truncate">{description ?? url}</p>
          {meta && <p className="text-[10px] text-muted-foreground/80 truncate mt-0.5">{meta}</p>}
          {risk && (
            <div className="mt-1 flex items-center gap-1.5">
              {chainSummary && <span className="min-w-0 truncate rounded-full bg-foreground/10 px-2 py-0.5 text-[10px] font-medium text-muted-foreground">{chainSummary}</span>}
              {typeof tvlUsd === 'number' && <span className="shrink-0 whitespace-nowrap text-[10px] font-semibold text-accent">{formatCompactUsd(tvlUsd)} TVL</span>}
              <RiskPill risk={risk} />
            </div>
          )}
        </div>
      </button>
      <div className="flex items-center gap-0.5 shrink-0">
        <button
          type="button"
          onClick={onToggleFavorite}
          className={`paxi-icon-button flex items-center justify-center transition-all hover:bg-foreground/5 ${
            isFav ? 'text-accent' : 'text-muted-foreground hover:text-foreground'
          }`}
          aria-label="Toggle favorite"
        >
          <Star className="w-4 h-4" fill={isFav ? 'currentColor' : 'none'} />
        </button>
        {onRemove && (
          <button
            type="button"
            onClick={onRemove}
            className="paxi-icon-button flex items-center justify-center text-muted-foreground transition-all hover:bg-destructive/10 hover:text-destructive"
            aria-label="Remove from recent"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        <button
          type="button"
          onClick={onOpen}
          className="paxi-icon-button flex items-center justify-center text-muted-foreground transition-all hover:bg-foreground/5 hover:text-foreground"
          aria-label="Open link"
        >
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
