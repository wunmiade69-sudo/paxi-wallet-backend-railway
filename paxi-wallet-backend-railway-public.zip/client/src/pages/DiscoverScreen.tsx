import { useEffect, useState } from 'react';
import { Compass, ArrowUpRight, Star, Clock, X, Link2, Repeat2, Layers, Landmark, Image, Route, LayoutGrid } from 'lucide-react';
import { toast } from 'sonner';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import { trpc } from '@/lib/trpc';
import {
  CURATED_DAPPS,
  addRecent,
  faviconFor,
  getFavorites,
  getRecents,
  isFavorite,
  normalizeUrl,
  removeRecent,
  toggleFavorite,
  type DappEntry,
} from '@/lib/wallet/discover';

interface DiscoverScreenProps {
  onNavigate: (tab: NavTab) => void;
  onWeb3Browser: () => void;
  onSelectCampaign: (campaignId: number) => void;
}

type CategoryFilter = 'All' | DappEntry['category'];

const CATEGORY_META: Record<DappEntry['category'], { icon: typeof Repeat2 }> = {
  DEX: { icon: Repeat2 },
  Aggregator: { icon: Layers },
  Lending: { icon: Landmark },
  NFT: { icon: Image },
  Bridge: { icon: Route },
};

const FILTERS: CategoryFilter[] = ['All', 'DEX', 'Aggregator', 'Lending', 'NFT', 'Bridge'];
const FEATURED = CURATED_DAPPS.filter((d) => d.featured);

export default function DiscoverScreen({ onNavigate, onWeb3Browser, onSelectCampaign }: DiscoverScreenProps) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<CategoryFilter>('All');
  const [recents, setRecents] = useState(getRecents());
  const [favorites, setFavorites] = useState(getFavorites());
  const { data: campaigns } = trpc.campaigns.listActive.useQuery();

  useEffect(() => {
    setRecents(getRecents());
    setFavorites(getFavorites());
  }, []);

  const openLink = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
    addRecent(url);
    setRecents(getRecents());
  };

  const handleGo = () => {
    try {
      const url = normalizeUrl(query);
      openLink(url);
      setQuery('');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Enter a valid link');
    }
  };

  const handleToggleFavorite = (url: string) => {
    toggleFavorite(url);
    setFavorites(getFavorites());
  };

  const visibleDapps = filter === 'All' ? CURATED_DAPPS : CURATED_DAPPS.filter((d) => d.category === filter);

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4">
          <h1 className="text-2xl font-bold text-accent">Discover</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Trusted dapps, one tap from your wallet</p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-7">
        {/* Link bar */}
        <div className="flex items-center gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleGo()}
            placeholder="Paste a dapp or airdrop link…"
            className="flex-1 bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
          />
          <button
            onClick={handleGo}
            className="shrink-0 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm px-4 py-2.5 rounded-lg transition-all active:scale-95"
          >
            Open
          </button>
        </div>

        {/* Featured - the one place this screen spends visual boldness: bigger cards, a
            gradient wash, so the handful of dapps most people actually want feel found
            rather than buried in an alphabetical list. */}
        <section>
          <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5 px-1">Featured</h2>
          <div className="flex gap-3 overflow-x-auto pb-1 -mx-6 px-6 no-scrollbar snap-x snap-mandatory">
            {FEATURED.map((dapp, i) => (
              <button
                key={dapp.url}
                onClick={() => openLink(dapp.url)}
                style={{ animationDelay: `${i * 60}ms` }}
                className="animate-in fade-in slide-in-from-bottom-2 duration-300 fill-mode-both snap-start shrink-0 w-40 rounded-2xl bg-gradient-to-br from-accent/20 via-secondary to-secondary border border-accent/20 p-4 text-left hover:border-accent/40 active:scale-[0.97] transition-all"
              >
                <FeaturedLogo dapp={dapp} />
                <p className="font-semibold text-foreground text-sm mt-3 truncate">{dapp.name}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2 leading-snug">{dapp.description}</p>
              </button>
            ))}
          </div>
        </section>

        {campaigns && campaigns.length > 0 && (
          <section>
            <div className="mb-2.5 flex items-center justify-between px-1"><h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Featured campaigns</h2><span className="text-[10px] font-semibold uppercase tracking-wide text-emerald-300">Live</span></div>
            <div className="flex gap-3 overflow-x-auto px-1 pb-1 no-scrollbar snap-x snap-mandatory">
              {campaigns.slice(0, 8).map((campaign) => (
                <button key={campaign.id} onClick={() => onSelectCampaign(campaign.id)} className="snap-start shrink-0 w-64 overflow-hidden rounded-2xl border border-border bg-secondary text-left active:scale-[0.98] transition-transform">
                  {campaign.bannerKey ? <img src={`/manus-storage/${campaign.bannerKey}`} alt="" className="h-28 w-full object-cover" /> : <div className="h-28 bg-gradient-to-br from-accent/30 to-secondary" />}
                  <div className="space-y-2 p-3"><div className="flex items-center gap-2">{campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-7 w-7 rounded-lg object-cover" />}<p className="truncate text-sm font-semibold text-foreground">{campaign.title}</p></div><p className="line-clamp-2 text-xs text-muted-foreground">{campaign.description || `Earn ${campaign.rewardAmount} ${campaign.rewardTokenSymbol} with PAXI`}</p><div className="flex items-center justify-between text-[10px]"><span className="font-semibold text-emerald-300">● LIVE</span><span className="text-muted-foreground">{campaign.winnersCount}/{campaign.maxWinners} slots claimed</span></div></div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* dApps open in your regular browser (their own site, full compatibility) rather than
            an embedded view here - this card is the missing link back: once a dApp shows its
            "Connect Wallet" QR/URI, this is where you come to actually pair it to Paxi. */}
        <button
          onClick={onWeb3Browser}
          className="w-full flex items-center gap-3 glass-card !p-4 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all"
        >
          <span className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
            <Link2 className="w-4.5 h-4.5 text-accent" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-foreground text-sm">Explore dApps</p>
            <p className="text-xs text-muted-foreground truncate">
              Browse trusted dApps - opens in your regular browser. In-app pairing isn't available yet.
            </p>
          </div>
          <ArrowUpRight className="w-4 h-4 text-muted-foreground shrink-0" />
        </button>

        {/* Favorites */}
        {favorites.length > 0 && (
          <section>
            <h2 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5 px-1">
              <Star className="w-3.5 h-3.5" /> Favorites
            </h2>
            <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
              {favorites.map((link, i) => (
                <LinkRow
                  key={link.id}
                  index={i}
                  label={link.label}
                  url={link.url}
                  iconUrl={faviconFor(link.url)}
                  onOpen={() => openLink(link.url)}
                  onToggleFavorite={() => handleToggleFavorite(link.url)}
                  isFav
                />
              ))}
            </div>
          </section>
        )}

        {/* Recents */}
        {recents.length > 0 && (
          <section>
            <h2 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2.5 px-1">
              <Clock className="w-3.5 h-3.5" /> Recently Opened
            </h2>
            <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
              {recents.map((link, i) => (
                <LinkRow
                  key={link.id}
                  index={i}
                  label={link.label}
                  url={link.url}
                  iconUrl={faviconFor(link.url)}
                  onOpen={() => openLink(link.url)}
                  onToggleFavorite={() => handleToggleFavorite(link.url)}
                  isFav={isFavorite(link.url)}
                  onRemove={() => {
                    removeRecent(link.id);
                    setRecents(getRecents());
                  }}
                />
              ))}
            </div>
          </section>
        )}

        {/* Directory - category pills filter one shared list instead of stacking every
            category as its own always-visible section, so scanning scales past 8 dapps. */}
        <section>
          <div className="flex items-center gap-1.5 mb-3 px-1 overflow-x-auto no-scrollbar">
            {FILTERS.map((f) => {
              const Icon = f === 'All' ? LayoutGrid : CATEGORY_META[f].icon;
              const active = filter === f;
              return (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`flex items-center gap-1.5 shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition-all active:scale-95 ${
                    active
                      ? 'bg-accent text-accent-foreground'
                      : 'bg-secondary text-muted-foreground hover:text-foreground border border-border'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {f}
                </button>
              );
            })}
          </div>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            {visibleDapps.map((dapp, i) => (
              <LinkRow
                key={dapp.url}
                index={i}
                label={dapp.name}
                description={dapp.description}
                url={dapp.url}
                iconUrl={faviconFor(dapp.url)}
                onOpen={() => openLink(dapp.url)}
                onToggleFavorite={() => handleToggleFavorite(dapp.url)}
                isFav={isFavorite(dapp.url)}
              />
            ))}
          </div>
        </section>

        {favorites.length === 0 && recents.length === 0 && (
          <div className="text-center py-2">
            <div className="w-12 h-12 rounded-full bg-foreground/5 flex items-center justify-center mx-auto mb-3">
              <Compass className="w-5 h-5 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground">Tap a dapp above, or paste any link to open it.</p>
          </div>
        )}
      </div>

      <BottomNav active="discover" onNavigate={onNavigate} />
    </div>
  );
}

function FeaturedLogo({ dapp }: { dapp: DappEntry }) {
  const [failed, setFailed] = useState(false);
  if (!failed) {
    return (
      <img
        src={faviconFor(dapp.url, 128)}
        alt=""
        onError={() => setFailed(true)}
        className="w-10 h-10 rounded-full bg-white object-contain border border-white/10"
      />
    );
  }
  return (
    <span className="w-10 h-10 rounded-full bg-accent/15 flex items-center justify-center font-bold text-accent uppercase">
      {dapp.name.charAt(0)}
    </span>
  );
}

function LinkRow({
  index,
  label,
  description,
  url,
  iconUrl,
  onOpen,
  onToggleFavorite,
  isFav,
  onRemove,
}: {
  index: number;
  label: string;
  description?: string;
  url: string;
  iconUrl?: string;
  onOpen: () => void;
  onToggleFavorite: () => void;
  isFav: boolean;
  onRemove?: () => void;
}) {
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <div
      style={{ animationDelay: `${Math.min(index, 8) * 40}ms` }}
      className="animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both flex items-center gap-3 px-4 py-3.5"
    >
      <button onClick={onOpen} className="flex items-center gap-3 flex-1 min-w-0 text-left">
        {iconUrl && !imgFailed ? (
          <img
            src={iconUrl}
            alt=""
            onError={() => setImgFailed(true)}
            className="w-9 h-9 rounded-full bg-white object-contain shrink-0 border border-white/10"
          />
        ) : (
          <span className="w-9 h-9 rounded-full bg-accent/10 flex items-center justify-center font-bold text-accent shrink-0 uppercase">
            {label.charAt(0)}
          </span>
        )}
        <div className="min-w-0">
          <p className="font-semibold text-foreground text-sm truncate">{label}</p>
          <p className="text-xs text-muted-foreground truncate">{description ?? url}</p>
        </div>
      </button>
      <div className="flex items-center gap-0.5 shrink-0">
        <button
          onClick={onToggleFavorite}
          className={`w-8 h-8 rounded-full flex items-center justify-center transition-all active:scale-90 hover:bg-foreground/5 ${
            isFav ? 'text-accent' : 'text-muted-foreground hover:text-foreground'
          }`}
          aria-label="Toggle favorite"
        >
          <Star className="w-4 h-4" fill={isFav ? 'currentColor' : 'none'} />
        </button>
        {onRemove && (
          <button
            onClick={onRemove}
            className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 active:scale-90 transition-all"
            aria-label="Remove from recent"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        <button
          onClick={onOpen}
          className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
          aria-label="Open link"
        >
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
