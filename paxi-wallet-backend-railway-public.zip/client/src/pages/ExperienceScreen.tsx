import { useState } from "react";
import {
  ArrowLeft,
  X,
  ChevronRight,
  ChevronLeft,
  PlayCircle,
  Wallet,
  Send,
  Repeat,
  Compass,
  ShieldCheck,
  PartyPopper,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface ExperienceScreenProps {
  onBack: () => void;
}

interface Slide {
  icon: typeof Wallet;
  title: string;
  body: string;
}

const SLIDES: Slide[] = [
  {
    icon: PartyPopper,
    title: "Welcome back to PAXI",
    body: "Here's a quick refresher on what your wallet can do - skip anytime.",
  },
  {
    icon: Wallet,
    title: "Multiple wallets, one PIN",
    body: "Add, import, or watch as many wallets as you like from Me → Manage Wallets. They all unlock together.",
  },
  {
    icon: Send,
    title: "Send & receive",
    body: "Tap Send or Receive from the dashboard. Save frequent addresses to your Address Book so you never mistype one.",
  },
  {
    icon: Repeat,
    title: "Swap & Bridge",
    body: "Trade supported assets or move them between supported networks. Quotes come from the configured provider path and should be reviewed before signing.",
  },
  {
    icon: Compass,
    title: "Discover dapps",
    body: "Browse popular dapps or paste a link to open it in your regular browser. In-app dapp signing and WalletConnect pairing are not available in this beta.",
  },
  {
    icon: ShieldCheck,
    title: "Keep your phrase safe",
    body: "Your recovery phrase is the only backup for your funds. Never share it - not even with PAXI support.",
  },
];

const TIPS: { title: string; body: string }[] = [
  {
    title: "Hide your balance",
    body: "Tap the eye icon on the dashboard to blur your portfolio value in public.",
  },
  {
    title: "Star your favorite dapps",
    body: "In Discover, tap the star on any dapp or link to pin it for one-tap access next time.",
  },
  {
    title: "Rename your wallets",
    body: 'In Manage Wallets, tap the pencil icon to label wallets by purpose - "Trading", "Savings", etc.',
  },
  {
    title: "Double-check the network",
    body: "Before sending, confirm the recipient is on the same network as the asset you're sending.",
  },
];

export default function ExperienceScreen({ onBack }: ExperienceScreenProps) {
  const [tutorialOpen, setTutorialOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">Experience</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <button
          onClick={() => setTutorialOpen(true)}
          className="w-full glass-card flex items-center gap-3 text-left hover:bg-foreground/5 transition-colors"
        >
          <PlayCircle className="w-8 h-8 text-accent shrink-0" />
          <div>
            <p className="text-sm font-semibold text-foreground">
              Replay Tutorial
            </p>
            <p className="text-xs text-muted-foreground">
              A quick tour of the app's main features
            </p>
          </div>
        </button>

        <div>
          <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">
            Quick Tips
          </h2>
          <div className="glass-card !p-0 overflow-hidden">
            <Accordion type="single" collapsible className="px-4">
              {TIPS.map((tip, i) => (
                <AccordionItem
                  key={i}
                  value={`tip-${i}`}
                  className="border-white/5"
                >
                  <AccordionTrigger className="hover:no-underline">
                    <span className="text-sm font-semibold text-foreground">
                      {tip.title}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground leading-relaxed">
                    {tip.body}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>

      {tutorialOpen && (
        <TutorialOverlay onClose={() => setTutorialOpen(false)} />
      )}
    </div>
  );
}

function TutorialOverlay({ onClose }: { onClose: () => void }) {
  const [index, setIndex] = useState(0);
  const slide = SLIDES[index];
  const Icon = slide.icon;
  const isLast = index === SLIDES.length - 1;

  return (
    <div className="fixed inset-0 z-50 bg-background flex flex-col px-6 py-8">
      <div className="flex justify-end">
        <button
          onClick={onClose}
          className="text-muted-foreground hover:text-foreground transition-colors p-1.5"
          aria-label="Close tutorial"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full text-center gap-4">
        <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center">
          <Icon className="w-8 h-8 text-accent" />
        </div>
        <h2 className="text-xl font-bold text-foreground">{slide.title}</h2>
        <p className="text-sm text-muted-foreground max-w-xs">{slide.body}</p>
      </div>

      <div className="flex justify-center gap-1.5 mb-6">
        {SLIDES.map((_, i) => (
          <span
            key={i}
            className={`h-1.5 rounded-full transition-all ${i === index ? "w-6 bg-accent" : "w-1.5 bg-muted"}`}
          />
        ))}
      </div>

      <div className="max-w-md mx-auto w-full flex items-center gap-3">
        <button
          onClick={() => setIndex(i => Math.max(0, i - 1))}
          disabled={index === 0}
          className="flex items-center gap-1 text-sm text-muted-foreground disabled:opacity-30 hover:text-foreground transition-colors px-2 py-2"
        >
          <ChevronLeft className="w-4 h-4" />
          Back
        </button>
        <button
          onClick={() => (isLast ? onClose() : setIndex(i => i + 1))}
          className="flex-1 flex items-center justify-center gap-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-colors"
        >
          {isLast ? "Done" : "Next"}
          {!isLast && <ChevronRight className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}
