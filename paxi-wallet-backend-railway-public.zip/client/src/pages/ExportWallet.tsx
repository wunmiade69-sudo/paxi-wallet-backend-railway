import { useState } from 'react';
import { ArrowLeft, AlertTriangle, Copy } from 'lucide-react';
import { toast } from 'sonner';
import { unlockWithPIN } from '@/lib/wallet/vault';
import { exportEncryptedKeystore, walletFromMnemonic } from '@/lib/wallet/engine';
import SensitiveExportGate from '@/components/SensitiveExportGate';

interface ExportWalletProps {
  onBack: () => void;
}

export default function ExportWallet({ onBack }: ExportWalletProps) {
  const [pin, setPin] = useState('');
  const [mnemonic, setMnemonic] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [isChecking, setIsChecking] = useState(false);

  const [keystorePassword, setKeystorePassword] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [showPrivateKey, setShowPrivateKey] = useState(false);
  const [protectedAction, setProtectedAction] = useState<'keystore' | 'reveal-key' | 'copy-key' | null>(null);

  const handleVerify = async () => {
    setIsChecking(true);
    setError('');
    try {
      const phrase = await unlockWithPIN(pin);
      setMnemonic(phrase);
    } catch {
      setError('Incorrect PIN.');
    } finally {
      setIsChecking(false);
    }
  };

  const handleDownloadKeystore = async () => {
    if (!mnemonic) return;
    if (keystorePassword.length < 8) {
      toast.error('Use a keystore password of at least 8 characters.');
      return;
    }
    setIsExporting(true);
    try {
      const json = await exportEncryptedKeystore(mnemonic, keystorePassword);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'paxi-wallet-keystore.json';
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Encrypted keystore downloaded. Store it and its password separately.');
    } catch {
      toast.error('Failed to create keystore file.');
    } finally {
      setIsExporting(false);
    }
  };

  const authorizeProtectedAction = async () => {
    const action = protectedAction;
    setProtectedAction(null);
    if (action === 'reveal-key') setShowPrivateKey(true);
    if (action === 'copy-key' && privateKey) {
      await navigator.clipboard.writeText(privateKey);
      toast.success('Private key copied - clear your clipboard after use.');
    }
    if (action === 'keystore') await handleDownloadKeystore();
  };

  const privateKey = mnemonic ? walletFromMnemonic(mnemonic).privateKey : '';

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-2xl font-bold text-accent">Export Wallet</h1>
        <div className="w-10" />
      </div>

      <div className="max-w-md mx-auto w-full flex-1">
        {!mnemonic ? (
          <div className="space-y-4">
            <p className="text-muted-foreground text-sm">Enter your PIN to export your wallet.</p>
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
              className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground text-center tracking-[0.5em] text-xl"
              placeholder="••••••"
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
            <button
              onClick={handleVerify}
              disabled={pin.length !== 6 || isChecking}
              className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              {isChecking ? 'Checking...' : 'Verify PIN'}
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-4">
              <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-sm text-destructive">
                Exported files and private keys give full control of your funds. Keep them offline and
                never share them.
              </p>
            </div>

            <div className="glass-card space-y-3">
              <h3 className="font-semibold text-foreground">Encrypted Keystore (recommended)</h3>
              <p className="text-xs text-muted-foreground">
                A password-protected JSON file, compatible with most Ethereum-family wallets.
              </p>
              <input
                type="password"
                value={keystorePassword}
                onChange={(e) => setKeystorePassword(e.target.value)}
                placeholder="Choose a keystore password (min 8 chars)"
                className="w-full bg-secondary/50 border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm"
              />
              <button
                onClick={() => setProtectedAction('keystore')}
                disabled={isExporting}
                className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
              >
                {isExporting ? 'Encrypting...' : 'Download Keystore File'}
              </button>
            </div>

            <div className="glass-card space-y-3">
              <h3 className="font-semibold text-foreground">Raw Private Key</h3>
              <p className="text-xs text-muted-foreground">
                Only for importing into another wallet you trust. Anyone who sees this can steal your funds.
              </p>
              {showPrivateKey ? (
                <p className="text-xs font-mono text-accent break-all bg-secondary/50 rounded-lg p-3">{privateKey}</p>
              ) : (
                <button
                  onClick={() => setProtectedAction('reveal-key')}
                  className="w-full bg-secondary hover:bg-muted text-foreground rounded-lg py-3 transition-colors text-sm"
                >
                  Tap to reveal private key
                </button>
              )}
              {showPrivateKey && (
                <button
                  onClick={() => setProtectedAction('copy-key')}
                  className="w-full flex items-center justify-center gap-2 bg-secondary hover:bg-muted text-foreground rounded-lg py-3 transition-colors text-sm"
                >
                  <Copy className="w-4 h-4" />
                  Copy Private Key
                </button>
              )}
            </div>

            <button
              onClick={onBack}
              className="w-full bg-secondary hover:bg-muted text-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              Done
            </button>
          </div>
        )}
      </div>
      <SensitiveExportGate
        open={protectedAction !== null}
        actionLabel={protectedAction === 'keystore'
          ? 'Download the encrypted wallet keystore'
          : protectedAction === 'reveal-key'
            ? 'Reveal the raw private key'
            : 'Copy the raw private key to the clipboard'}
        onAuthorized={() => { void authorizeProtectedAction(); }}
        onCancel={() => setProtectedAction(null)}
      />
    </div>
  );
}
