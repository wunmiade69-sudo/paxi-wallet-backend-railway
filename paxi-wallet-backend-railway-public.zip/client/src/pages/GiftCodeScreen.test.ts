import { describe, expect, it } from 'vitest';
import { describeGiftCodeError, formatGiftCodeAssetIdentity, normalizeCodeInput } from './GiftCodeScreen';

describe('Gift Code redemption contract', () => {
  it('normalizes user-entered codes without changing server-owned values', () => {
    expect(normalizeCodeInput('  gift-ab12_cd  ')).toBe('GIFT-AB12_CD');
  });

  it.each([
    ['Gift code not found', 'That Gift Code is not valid. Check the characters and try again.'],
    ['Gift code has expired', 'This Gift Code has expired and cannot be redeemed.'],
    ['Gift code already redeemed by this user', 'This Gift Code has already been redeemed by this wallet.'],
    ['Gift code is no longer available', 'This Gift Code is no longer available. Its limit may have been reached or it may be paused.'],
    ['Wallet is not eligible', 'This wallet is not eligible to redeem this Gift Code.'],
    ['Database not available', 'The secure redemption service is temporarily unavailable. Please try again.'],
  ])('maps server state %s to a safe user message', (serverMessage, expected) => {
    expect(describeGiftCodeError(serverMessage)).toBe(expected);
  });

  it('keeps contract identity distinct from symbol-only display', () => {
    expect(formatGiftCodeAssetIdentity({
      assetSymbol: 'USDT',
      assetNetwork: 'bsc',
      assetContractAddress: '0x2222222222222222222222222222222222222222',
    })).toBe('USDT on BSC · 0x2222222222222222222222222222222222222222');
  });

  it('labels native rewards with their canonical network identity', () => {
    expect(formatGiftCodeAssetIdentity({ assetSymbol: 'ETH', assetNetwork: 'ethereum', assetContractAddress: null })).toBe('ETH on ETHEREUM · native asset');
  });
});
