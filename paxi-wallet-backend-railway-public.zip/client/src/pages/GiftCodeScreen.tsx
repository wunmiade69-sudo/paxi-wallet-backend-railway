import { useState } from 'react';
import { ArrowLeft, CheckCircle2, Gift, Loader2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { getStoredAddress } from '@/lib/wallet/vault';

export default function GiftCodeScreen({ onBack }: { onBack: () => void }) {
  const [code, setCode] = useState('');
  const [receipt, setReceipt] = useState<{ amount: string; symbol: string; network: string; status: string } | null>(null);
  const address = getStoredAddress();
  const redeem = trpc.giftCodes.redeem.useMutation({
    onSuccess: (ledger) => {
      setReceipt({ amount: ledger.amount, symbol: ledger.assetSymbol, network: ledger.assetNetwork, status: ledger.status });
      setCode('');
      toast.success('Gift Code redeemed');
    },
    onError: (error) => toast.error(error.message),
  });

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 border-b border-foreground/5 bg-secondary/50 backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center gap-3 px-6 py-4">
          <button onClick={onBack} className="rounded-full p-1 text-muted-foreground hover:text-foreground" aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
          <div><p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-accent/80">Rewards</p><h1 className="text-xl font-bold text-foreground">Gift Codes</h1></div>
        </div>
      </div>

      <main className="mx-auto max-w-md space-y-5 px-6 py-6">
        {!receipt ? (
          <>
            <section className="glass-card space-y-3 p-5 text-center">
              <Gift className="mx-auto h-10 w-10 text-accent" />
              <h2 className="text-lg font-semibold text-foreground">Redeem a Gift Code</h2>
              <p className="text-sm leading-6 text-muted-foreground">Enter a code to receive the configured token directly in your connected wallet. The reward is shown only after the blockchain transfer is confirmed.</p>
            </section>
            <section className="space-y-4 rounded-2xl border border-border bg-secondary/40 p-4">
              <label className="block space-y-2"><span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Gift Code</span><input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="GIFT-…" maxLength={32} autoCapitalize="characters" className="w-full rounded-xl border border-border bg-background px-4 py-3 font-mono text-sm tracking-wider text-foreground outline-none focus:border-accent" /></label>
              <div className="rounded-xl bg-background/60 p-3"><p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Recipient wallet</p><p className="mt-1 break-all font-mono text-xs text-foreground">{address ?? 'No wallet found on this device'}</p></div>
              <button disabled={!address || code.trim().length < 6 || redeem.isPending} onClick={() => address && redeem.mutate({ code, recipientWalletAddress: address })} className="flex w-full items-center justify-center gap-2 rounded-xl bg-accent py-3 text-sm font-semibold text-accent-foreground disabled:cursor-not-allowed disabled:opacity-50">{redeem.isPending && <Loader2 className="h-4 w-4 animate-spin" />}{redeem.isPending ? 'Verifying and redeeming…' : 'Redeem Gift Code'}</button>
            </section>
            <p className="flex items-center justify-center gap-2 text-center text-xs text-muted-foreground"><ShieldCheck className="h-3.5 w-3.5 text-accent" /> One redemption per wallet and code.</p>
          </>
        ) : (
          <section className="space-y-5 rounded-2xl border border-accent/30 bg-accent/5 p-6 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-accent/30 bg-accent/10"><CheckCircle2 className="h-9 w-9 text-accent" /></div>
            <div><p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-accent/80">Transaction Receipt</p><h2 className="mt-2 text-2xl font-bold text-foreground">Reward confirmed</h2><p className="mt-2 text-sm text-muted-foreground">The reward transfer was verified on-chain before it was recorded in your reward ledger.</p></div>
            <div className="rounded-xl bg-background/70 p-4 text-left"><div className="flex items-center justify-between gap-4"><span className="text-xs text-muted-foreground">Amount</span><span className="font-semibold text-foreground">{receipt.amount} {receipt.symbol}</span></div><div className="mt-3 flex items-center justify-between gap-4"><span className="text-xs text-muted-foreground">Network</span><span className="text-sm font-semibold capitalize text-foreground">{receipt.network}</span></div><div className="mt-3 flex items-center justify-between gap-4"><span className="text-xs text-muted-foreground">Ledger status</span><span className="text-sm font-semibold capitalize text-accent">{receipt.status}</span></div></div>
            <button onClick={onBack} className="w-full rounded-xl bg-accent py-3 text-sm font-semibold text-accent-foreground">Done</button>
          </section>
        )}
      </main>
    </div>
  );
}
