import { AlertCircle, ArrowLeft, CheckCircle2, Gift, Loader2, ShieldCheck, WalletCards } from 'lucide-react';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { getStoredAddress } from '@/lib/wallet/vault';

interface GiftCodeScreenProps {
  onBack: () => void;
}

type FeedbackTone = 'error' | 'info' | 'success';

export function normalizeCodeInput(value: string): string {
  return value.trim().toUpperCase();
}

export function describeGiftCodeError(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('not found') || lower.includes('invalid gift') || lower.includes('invalid code')) {
    return 'That Gift Code is not valid. Check the characters and try again.';
  }
  if (lower.includes('expired')) return 'This Gift Code has expired and cannot be redeemed.';
  if (lower.includes('already redeemed')) return 'This Gift Code has already been redeemed by this wallet.';
  if (lower.includes('no longer available') || lower.includes('concurrently')) {
    return 'This Gift Code is no longer available. Its limit may have been reached or it may be paused.';
  }
  if (lower.includes('eligible') || lower.includes('eligibility')) return 'This wallet is not eligible to redeem this Gift Code.';
  if (lower.includes('recipient wallet')) return 'Enter a valid BSC recipient wallet for this WPAXI reward.';
  if (lower.includes('database') || lower.includes('temporar') || lower.includes('try again')) {
    return 'The secure redemption service is temporarily unavailable. Please try again.';
  }
  return 'We could not process this Gift Code. Please try again.';
}

export function formatGiftCodeAssetIdentity(preview: { assetSymbol: string; assetNetwork: string; assetContractAddress: string | null }): string {
  const chain = preview.assetNetwork.toUpperCase();
  return preview.assetContractAddress
    ? `${preview.assetSymbol} on ${chain} · ${preview.assetContractAddress}`
    : `${preview.assetSymbol} on ${chain} · native asset`;
}

function Feedback({ tone, children }: { tone: FeedbackTone; children: ReactNode }) {
  const toneClass = tone === 'success'
    ? 'border-emerald-400/25 bg-emerald-400/10 text-emerald-100'
    : tone === 'error'
      ? 'border-rose-400/25 bg-rose-400/10 text-rose-100'
      : 'border-accent/20 bg-accent/10 text-foreground';
  const Icon = tone === 'success' ? CheckCircle2 : tone === 'error' ? AlertCircle : ShieldCheck;
  return <div role={tone === 'error' ? 'alert' : 'status'} className={`flex items-start gap-3 rounded-2xl border p-4 text-sm ${toneClass}`}><Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" /><p>{children}</p></div>;
}

export default function GiftCodeScreen({ onBack }: GiftCodeScreenProps) {
  const [code, setCode] = useState('');
  const [recipientWalletAddress, setRecipientWalletAddress] = useState(() => getStoredAddress() ?? '');
  const [confirmed, setConfirmed] = useState(false);
  const [localError, setLocalError] = useState('');
  const normalizedCode = useMemo(() => normalizeCodeInput(code), [code]);

  const preview = trpc.giftCodes.preview.useQuery(
    { code: normalizedCode },
    { enabled: false, retry: false },
  );
  const redeem = trpc.giftCodes.redeem.useMutation({
    onSuccess: () => {
      setConfirmed(true);
      setLocalError('');
      toast.success('Gift Code redeemed');
    },
    onError: (error) => {
      setConfirmed(false);
      setLocalError(describeGiftCodeError(error.message));
    },
  });

  useEffect(() => {
    setConfirmed(false);
    setLocalError('');
  }, [normalizedCode]);

  const previewData = preview.data;
  const previewError = preview.error ? describeGiftCodeError(preview.error.message) : '';
  const canValidate = normalizedCode.length >= 6 && !preview.isFetching;
  const requiresRecipient = Boolean(previewData?.requiresRecipientWallet);
  const canConfirm = Boolean(previewData) && (!requiresRecipient || /^0x[0-9a-fA-F]{40}$/.test(recipientWalletAddress.trim())) && !redeem.isPending;

  const validateCode = async () => {
    setLocalError('');
    setConfirmed(false);
    if (normalizedCode.length < 6) {
      setLocalError('Enter the Gift Code exactly as provided.');
      return;
    }
    await preview.refetch();
  };

  const redeemCode = () => {
    if (!previewData || !canConfirm || redeem.isPending) return;
    setLocalError('');
    redeem.mutate({
      code: normalizedCode,
      ...(requiresRecipient ? { recipientWalletAddress: recipientWalletAddress.trim() } : {}),
    });
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background px-4 pb-24 pt-5 sm:px-6 sm:pt-8">
      <div className="mx-auto max-w-md">
        <header className="mb-7 flex items-center justify-between">
          <button type="button" onClick={onBack} className="paxi-pressable flex min-h-11 items-center gap-1 rounded-xl px-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground" aria-label="Back to Me">
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            Back
          </button>
          <div className="flex items-center gap-2 text-accent"><Gift className="h-5 w-5" aria-hidden="true" /><h1 className="text-xl font-bold tracking-tight">Gift Code</h1></div>
          <span className="w-14" aria-hidden="true" />
        </header>

        <main className="space-y-5">
          <section className="glass-card overflow-hidden border border-accent/20 p-5">
            <div className="mb-5 flex items-start gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-accent/15 text-accent"><Gift className="h-5 w-5" aria-hidden="true" /></span>
              <div><p className="text-lg font-bold text-foreground">Redeem a Gift Code</p><p className="mt-1 text-sm leading-6 text-muted-foreground">Review the reward and network before you confirm. Redemption is protected by the wallet service.</p></div>
            </div>
            <label htmlFor="gift-code" className="mb-2 block text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">Gift Code</label>
            <input
              id="gift-code"
              value={code}
              onChange={(event) => setCode(event.target.value.toUpperCase())}
              onKeyDown={(event) => { if (event.key === 'Enter') void validateCode(); }}
              autoCapitalize="characters"
              autoCorrect="off"
              autoComplete="off"
              spellCheck={false}
              inputMode="text"
              placeholder="GIFT-XXXXXXXX"
              className="min-h-12 w-full rounded-xl border border-border bg-background/70 px-4 font-mono text-sm tracking-[0.08em] text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20"
              aria-describedby="gift-code-help"
            />
            <p id="gift-code-help" className="mt-2 text-xs text-muted-foreground">Codes are checked securely. The raw code is never shown in the reward ledger.</p>
            <button type="button" onClick={() => void validateCode()} disabled={!canValidate} className="paxi-pressable mt-4 flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 text-sm font-bold text-accent-foreground transition hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50">
              {preview.isFetching ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <ShieldCheck className="h-4 w-4" aria-hidden="true" />}
              {preview.isFetching ? 'Checking securely…' : 'Validate Gift Code'}
            </button>
          </section>

          {(localError || previewError) && <Feedback tone="error">{localError || previewError}</Feedback>}

          {previewData && !confirmed && (
            <section className="glass-card space-y-4 border border-accent/20 p-5" aria-labelledby="gift-confirm-title">
              <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-semibold uppercase tracking-[0.14em] text-accent">Confirmation</p><h2 id="gift-confirm-title" className="mt-1 text-lg font-bold text-foreground">Review this reward</h2></div><WalletCards className="h-5 w-5 text-accent" aria-hidden="true" /></div>
              <div className="rounded-2xl bg-secondary/60 p-4"><p className="text-xs text-muted-foreground">Reward amount</p><p className="mt-1 text-2xl font-bold text-foreground">{previewData.rewardAmount} {previewData.assetSymbol}</p><p className="mt-2 break-words text-xs leading-5 text-muted-foreground">Asset identity: {formatGiftCodeAssetIdentity(previewData)}</p></div>
              <div className="grid grid-cols-2 gap-3 text-sm"><div className="rounded-xl bg-secondary/40 p-3"><p className="text-xs text-muted-foreground">Remaining uses</p><p className="mt-1 font-semibold text-foreground">{previewData.redemptionsRemaining} of {previewData.maxRedemptions}</p></div><div className="rounded-xl bg-secondary/40 p-3"><p className="text-xs text-muted-foreground">Fulfillment</p><p className="mt-1 font-semibold capitalize text-foreground">{previewData.fulfillment}</p></div></div>
              {requiresRecipient && <div><label htmlFor="recipient-wallet" className="mb-2 block text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">BSC recipient wallet</label><input id="recipient-wallet" value={recipientWalletAddress} onChange={(event) => setRecipientWalletAddress(event.target.value)} placeholder="0x…" spellCheck={false} autoComplete="off" className="min-h-12 w-full rounded-xl border border-border bg-background/70 px-4 font-mono text-xs text-foreground outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20" /><p className="mt-2 text-xs leading-5 text-muted-foreground">WPAXI is recorded as claimable after redemption; this step does not broadcast a transfer.</p></div>}
              <button type="button" onClick={redeemCode} disabled={!canConfirm} className="paxi-pressable flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 text-sm font-bold text-accent-foreground transition hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-50">
                {redeem.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <CheckCircle2 className="h-4 w-4" aria-hidden="true" />}
                {redeem.isPending ? 'Redeeming securely…' : 'Confirm redemption'}
              </button>
            </section>
          )}

          {confirmed && redeem.data && <Feedback tone="success">{redeem.data.status === 'claimable' ? `Reward recorded as claimable: ${redeem.data.amount} ${redeem.data.assetSymbol} on ${redeem.data.assetNetwork.toUpperCase()}.` : `Reward credited: ${redeem.data.amount} ${redeem.data.assetSymbol} on ${redeem.data.assetNetwork.toUpperCase()}.`}</Feedback>}

          <p className="px-2 text-center text-xs leading-5 text-muted-foreground">Never share a Gift Code with a website or person you do not trust. The server rechecks expiry, availability, ownership, and limits when you confirm.</p>
        </main>
      </div>
    </div>
  );
}
