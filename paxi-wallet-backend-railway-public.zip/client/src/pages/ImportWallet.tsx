import { useState } from 'react';
import { ArrowLeft, ClipboardPaste, Info, KeyRound } from 'lucide-react';
import { isValidMnemonic, isValidPrivateKey } from '@/lib/wallet/engine';

interface ImportWalletProps {
  onImportPhrase: (phrase: string) => void;
  onImportPrivateKey: (privateKey: string) => void;
  onBack: () => void;
}

type Mode = 'phrase' | 'key';

export default function ImportWallet({ onImportPhrase, onImportPrivateKey, onBack }: ImportWalletProps) {
  const [mode, setMode] = useState<Mode>('phrase');
  const [phrase, setPhrase] = useState('');
  const [privateKey, setPrivateKey] = useState('');
  const [error, setError] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (mode === 'phrase') setPhrase(text);
      else setPrivateKey(text);
      setError('');
    } catch {
      setError('Unable to read from clipboard. Please paste it manually.');
    }
  };

  const handleContinue = () => {
    setIsValidating(true);
    setError('');

    if (mode === 'phrase') {
      if (!phrase.trim()) {
        setError('Enter your recovery phrase to continue.');
        setIsValidating(false);
        return;
      }
      if (!isValidMnemonic(phrase)) {
        setError('This recovery phrase is invalid. Check the words and word order, then try again.');
        setIsValidating(false);
        return;
      }
      try {
        onImportPhrase(phrase);
      } catch {
        setError('Could not import this wallet. Please check your recovery phrase and try again.');
        setIsValidating(false);
      }
      return;
    }

    if (!privateKey.trim()) {
      setError('Enter your private key to continue.');
      setIsValidating(false);
      return;
    }
    if (!isValidPrivateKey(privateKey)) {
      setError('This private key is invalid. It should be 64 hex characters, with or without "0x".');
      setIsValidating(false);
      return;
    }
    try {
      onImportPrivateKey(privateKey);
    } catch {
      setError('Could not import this account. Please check your private key and try again.');
      setIsValidating(false);
    }
  };

  const wordCount = phrase.trim().split(/\s+/).filter((w) => w).length;
  const canContinue = mode === 'phrase' ? wordCount === 12 : isValidPrivateKey(privateKey);

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-lg font-semibold text-foreground">Import Wallet</h1>
        <div className="w-12" />
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full">
        <div className="mb-8 text-center">
          <p className="text-muted-foreground text-xs font-medium uppercase tracking-wide">Step 1 of 4</p>
          <div className="flex gap-2 mt-2 justify-center">
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
          </div>
        </div>

        <h2 className="text-2xl font-bold text-foreground mb-2 text-center">Restore Your Wallet</h2>
        <p className="text-muted-foreground text-sm text-center mb-5 max-w-xs">
          {mode === 'phrase'
            ? 'Enter your 12-word recovery phrase, separated by spaces, to restore access to your wallet.'
            : 'Enter a private key to import a single EVM account, without a recovery phrase.'}
        </p>

        {/* Mode toggle */}
        <div className="w-full flex bg-secondary border border-border rounded-lg p-1 mb-6">
          <button
            onClick={() => {
              setMode('phrase');
              setError('');
            }}
            className={`flex-1 text-sm font-semibold py-2 rounded-md transition-all ${
              mode === 'phrase' ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Recovery Phrase
          </button>
          <button
            onClick={() => {
              setMode('key');
              setError('');
            }}
            className={`flex-1 text-sm font-semibold py-2 rounded-md transition-all ${
              mode === 'key' ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Private Key
          </button>
        </div>

        <div className="w-full glass-card mb-6">
          {mode === 'phrase' ? (
            <textarea
              value={phrase}
              onChange={(e) => {
                setPhrase(e.target.value);
                setError('');
              }}
              placeholder="Enter your 12-word recovery phrase, separated by spaces"
              className="w-full h-32 bg-secondary/50 border border-accent/30 rounded-lg p-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent/60 resize-none"
            />
          ) : (
            <textarea
              value={privateKey}
              onChange={(e) => {
                setPrivateKey(e.target.value);
                setError('');
              }}
              placeholder="Enter your private key (0x...)"
              className="w-full h-24 bg-secondary/50 border border-accent/30 rounded-lg p-4 text-foreground placeholder:text-muted-foreground font-mono text-sm focus:outline-none focus:border-accent/60 resize-none"
            />
          )}
        </div>

        <div className="w-full flex items-center justify-between mb-6 px-1">
          {mode === 'phrase' ? (
            <p className="text-sm text-muted-foreground">
              Words: <span className={wordCount === 12 ? 'text-accent font-medium' : 'text-muted-foreground'}>{wordCount}</span>/12
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">
              {privateKey.trim() ? (isValidPrivateKey(privateKey) ? <span className="text-accent font-medium">Looks valid</span> : 'Invalid format') : ' '}
            </p>
          )}
          <button onClick={handlePaste} className="flex items-center gap-1.5 text-sm text-accent hover:text-accent/80 transition-colors">
            <ClipboardPaste className="w-3.5 h-3.5" />
            Paste
          </button>
        </div>

        {error && (
          <div className="w-full bg-destructive/10 border border-destructive/30 rounded-lg p-4 mb-6">
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        <div className="w-full flex items-start gap-2.5 bg-accent/10 border border-accent/30 rounded-lg p-4 mb-8">
          {mode === 'phrase' ? (
            <>
              <Info className="w-4 h-4 text-accent shrink-0 mt-0.5" />
              <p className="text-sm text-foreground/80">
                Enter your recovery phrase exactly as it was given to you, in the correct order. We never store or
                transmit it.
              </p>
            </>
          ) : (
            <>
              <KeyRound className="w-4 h-4 text-accent shrink-0 mt-0.5" />
              <p className="text-sm text-foreground/80">
                A private key only unlocks EVM chains (Ethereum, BSC, Polygon, Arbitrum) - unlike a recovery phrase,
                it can't also derive a Bitcoin or Solana address for you.
              </p>
            </>
          )}
        </div>

        <button
          onClick={handleContinue}
          disabled={!canContinue || isValidating}
          className="w-full py-3 bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 disabled:from-muted disabled:to-muted text-accent-foreground disabled:text-muted-foreground font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:cursor-not-allowed disabled:transform-none"
        >
          {isValidating ? 'Importing…' : 'Continue'}
        </button>
      </div>
    </div>
  );
}
