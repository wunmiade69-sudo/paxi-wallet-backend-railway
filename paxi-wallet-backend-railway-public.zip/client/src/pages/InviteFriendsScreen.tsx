import { useState } from "react";
import { ArrowLeft, Copy, Share2, Check, Gift, Clock } from "lucide-react";
import { toast } from "sonner";
import { getStoredAddress } from "@/lib/wallet/vault";
import { getReferralCode, getReferralLink } from "@/lib/wallet/referral";

interface InviteFriendsScreenProps {
  onBack: () => void;
}

export default function InviteFriendsScreen({
  onBack,
}: InviteFriendsScreenProps) {
  const [copied, setCopied] = useState<"code" | "link" | null>(null);
  const address = getStoredAddress();
  const code = address ? getReferralCode(address) : null;
  const link = address ? getReferralLink(address) : null;

  const handleCopy = (value: string, which: "code" | "link") => {
    navigator.clipboard.writeText(value);
    setCopied(which);
    toast.success(
      which === "code" ? "Referral code copied" : "Referral link copied"
    );
    setTimeout(() => setCopied(null), 1500);
  };

  const handleShare = async () => {
    if (!link) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Join me on PAXI Wallet",
          text: "Use my invite link:",
          url: link,
        });
      } catch {
        // user cancelled the share sheet - not an error
      }
    } else {
      handleCopy(link, "link");
    }
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">Invite Friends</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-5">
        <div className="glass-card text-center space-y-1 py-6">
          <Gift className="w-8 h-8 text-accent mx-auto mb-1" />
          <p className="text-foreground font-semibold">
            Invite friends, earn WPAXI
          </p>
          <p className="text-xs text-muted-foreground max-w-xs mx-auto">
            Share your link now - rewards activate once the WPAXI token
            launches.
          </p>
        </div>

        {!address ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No wallet found on this device yet.
          </p>
        ) : (
          <>
            <div>
              <label className="text-xs text-muted-foreground mb-2 block px-1">
                Your referral code
              </label>
              <div className="glass-card flex items-center justify-between gap-3">
                <span className="font-mono text-accent font-semibold text-sm truncate">
                  {code}
                </span>
                <button
                  onClick={() => handleCopy(code!, "code")}
                  className="shrink-0 flex items-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-xs font-semibold px-3 py-2 rounded-lg transition-all active:scale-95"
                >
                  {copied === "code" ? (
                    <Check className="w-3.5 h-3.5 text-accent" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  Copy
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs text-muted-foreground mb-2 block px-1">
                Your referral link
              </label>
              <div className="glass-card flex items-center justify-between gap-3">
                <span className="font-mono text-foreground text-xs truncate">
                  {link ??
                    "Unavailable until the public PAXI domain is configured"}
                </span>
                <button
                  onClick={() => link && handleCopy(link, "link")}
                  disabled={!link}
                  className="shrink-0 flex items-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-xs font-semibold px-3 py-2 rounded-lg transition-all active:scale-95 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {copied === "link" ? (
                    <Check className="w-3.5 h-3.5 text-accent" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  Copy
                </button>
              </div>
              {!link && (
                <p className="text-xs text-amber-400 mt-2 px-1">
                  Sharing is disabled for this build until VITE_PAXI_PUBLIC_URL
                  is set.
                </p>
              )}
            </div>

            <button
              onClick={handleShare}
              disabled={!link}
              className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Share2 className="w-4 h-4" />
              {link ? "Share Invite" : "Referral sharing unavailable"}
            </button>

            <div className="glass-card space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  Friends invited
                </span>
                <span className="text-sm font-semibold text-foreground">—</span>
              </div>
              <div className="flex items-center justify-between border-t border-white/5 pt-2">
                <span className="text-sm text-muted-foreground">
                  WPAXI earned
                </span>
                <span className="flex items-center gap-1.5 text-sm font-semibold text-yellow-400">
                  <Clock className="w-3.5 h-3.5" />
                  Pending launch
                </span>
              </div>
              <p className="text-xs text-muted-foreground pt-1">
                Invite tracking and reward crediting go live once the WPAXI
                token and referral backend are deployed. Your code stays the
                same, so anything shared today will still count.
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
