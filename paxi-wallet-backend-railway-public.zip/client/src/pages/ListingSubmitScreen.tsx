import { useState } from 'react';
import { ArrowLeft, Upload, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import type { ListingResubmissionDraft } from './MyListingsScreen';
import NetworkPickerDrawer, { NetworkGlyph } from '@/components/NetworkPickerDrawer';
import { NETWORKS as WALLET_NETWORKS, type NetworkConfig } from '@/lib/wallet/chains';
import { describeUserFacingError } from '@/lib/userFacingError';

interface ListingSubmitScreenProps {
  onBack: () => void;
  onViewListings: () => void;
  resubmission?: ListingResubmissionDraft | null;
}

const LISTING_NETWORKS = [WALLET_NETWORKS.bsc, WALLET_NETWORKS.ethereum].filter((network): network is NetworkConfig => Boolean(network));
const STABLECOIN_LABELS: Record<string, string> = { bsc: 'USDT/USDC (BEP-20)', ethereum: 'USDT/USDC (ERC-20)' };

export default function ListingSubmitScreen({ onBack, onViewListings, resubmission }: ListingSubmitScreenProps) {
  const [network, setNetwork] = useState(resubmission?.network ?? LISTING_NETWORKS[0].id);
  const [contractAddress, setContractAddress] = useState(resubmission?.contractAddress ?? '');
  const [symbol, setSymbol] = useState(resubmission?.symbol ?? '');
  const [name, setName] = useState(resubmission?.name ?? '');
  const [logo, setLogo] = useState<string | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(resubmission?.logoKey ? `/manus-storage/${resubmission.logoKey}` : null);
  const [twitter, setTwitter] = useState(resubmission?.socials?.twitter ?? '');
  const [telegram, setTelegram] = useState(resubmission?.socials?.telegram ?? '');
  const [website, setWebsite] = useState(resubmission?.socials?.website ?? '');
  const [discord, setDiscord] = useState(resubmission?.socials?.discord ?? '');
  const [plan, setPlan] = useState(resubmission?.plan ?? '');
  const [feeTxHash, setFeeTxHash] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [autoVerified, setAutoVerified] = useState(false);
  const listingFee = trpc.fees.getConfig.useQuery({ operation: 'listing', chainType: network });
  const treasury = trpc.fees.getTreasury.useQuery();
  const myListings = trpc.listings.myListings.useQuery();

  const submit = trpc.listings.submitCommunityListing.useMutation({
    onSuccess: (res) => {
      setAutoVerified(res.autoVerified);
      setSubmitted(true);
    },
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t submit this listing. Please try again.')),
  });

  const selectedNetwork = LISTING_NETWORKS.find((item) => item.id === network) ?? LISTING_NETWORKS[0];
  const paymentAssetLabel = STABLECOIN_LABELS[selectedNetwork.id] ?? 'USDT/USDC';
  const listingFeeUsd = listingFee.data?.fixedUsd ?? '—';
  const paymentReady = Boolean(listingFee.data?.isActive && listingFee.data.fixedUsd !== '0' && treasury.data?.treasuryAddress);

  const handleLogoFile = (file: File | undefined) => {
    if (!file) return;
    if (file.size > 500 * 1024) {
      toast.error('Logo must be under 500KB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setLogo(result);
      setLogoPreview(result);
    };
    reader.readAsDataURL(file);
  };

  const canSubmit =
    contractAddress.trim().length > 0 &&
    symbol.trim().length > 0 &&
    name.trim().length > 0 &&
    logo &&
    plan.trim().length > 0 &&
    feeTxHash.trim().length > 0 &&
    paymentReady;

  const handleSubmit = () => {
    if (!logo) return;
    submit.mutate({
      network,
      contractAddress: contractAddress.trim(),
      symbol: symbol.trim(),
      name: name.trim(),
      logo,
      socials: {
        ...(twitter && { twitter }),
        ...(telegram && { telegram }),
        ...(website && { website }),
        ...(discord && { discord }),
      },
      plan: plan.trim(),
      feeTxHash: feeTxHash.trim(),
      ...(resubmission ? { resubmissionListingId: resubmission.id } : {}),
    });
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="max-w-md text-center space-y-4">
          <CheckCircle2 className="w-14 h-14 text-accent mx-auto" />
          <h1 className="text-xl font-bold text-foreground">
            {autoVerified ? "You're verified!" : resubmission ? 'Resubmitted for review' : 'Submitted for review'}
          </h1>
          <p className="text-sm text-muted-foreground">
            {autoVerified
              ? 'Your token already has enough real trading liquidity, so it was verified automatically - no waiting on manual review. You should see the verified badge in Discover right away.'
              : "Your token listing was submitted and your payment was verified on-chain. Our team will review your information and you'll see the verified badge in Discover once approved."}
          </p>
          <button
            onClick={onViewListings}
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm px-6 py-3 rounded-lg transition-all active:scale-[0.98]"
          >
            View My Listings
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">{resubmission ? 'Fix & Resubmit Listing' : 'List Your Token'}</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div className="glass-card p-4 space-y-1.5">
          <p className="text-sm text-foreground font-medium">Get a verified badge in Discover</p>
          <p className="text-xs text-muted-foreground">
            A one-time ${listingFeeUsd} fee gets your token reviewed for a verified listing. Pay in{' '}
            {paymentAssetLabel} to Paxi's address below, then paste the transaction hash to submit.
          </p>
        </div>

        {resubmission && <div className="rounded-lg bg-amber-400/10 p-3 text-xs text-amber-100">The network, contract, name, and symbol are locked to your rejected listing. Update the project information, upload a current logo, and provide verified payment evidence to resubmit.</div>}

        <Field label="Network">
          {resubmission ? (
            <div className="flex items-center gap-3 rounded-lg border border-border bg-secondary px-3 py-3 opacity-70">
              <NetworkGlyph network={selectedNetwork} size={28} />
              <span className="text-sm font-medium text-foreground">{selectedNetwork.label}</span>
            </div>
          ) : (
            <NetworkPickerDrawer label="Listing payment network" networks={LISTING_NETWORKS} selected={selectedNetwork} onSelect={setNetwork} />
          )}
        </Field>

        <Field label="Token Contract Address">
          <TextInput value={contractAddress} onChange={setContractAddress} placeholder="0x..." disabled={Boolean(resubmission)} />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Symbol">
            <TextInput value={symbol} onChange={setSymbol} placeholder="PAXI" disabled={Boolean(resubmission)} />
          </Field>
          <Field label="Name">
            <TextInput value={name} onChange={setName} placeholder="Paxi Token" disabled={Boolean(resubmission)} />
          </Field>
        </div>

        <Field label="Logo (max 500KB)">
          <label className="flex items-center gap-3 bg-secondary border border-dashed border-border rounded-lg py-3 px-3.5 cursor-pointer">
            {logoPreview ? (
              <img src={logoPreview} alt="Logo preview" className="w-10 h-10 rounded-full object-cover" />
            ) : (
              <Upload className="w-5 h-5 text-muted-foreground" />
            )}
            <span className="text-sm text-muted-foreground">{logoPreview ? (resubmission && !logo ? 'Upload a current logo to resubmit' : 'Change logo') : 'Upload logo image'}</span>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              onChange={(e) => handleLogoFile(e.target.files?.[0])}
            />
          </label>
        </Field>

        <div className="space-y-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground px-1">Social Links</p>
          <TextInput value={twitter} onChange={setTwitter} placeholder="Twitter/X URL (optional)" />
          <TextInput value={telegram} onChange={setTelegram} placeholder="Telegram URL (optional)" />
          <TextInput value={website} onChange={setWebsite} placeholder="Website URL (optional)" />
          <TextInput value={discord} onChange={setDiscord} placeholder="Discord URL (optional)" />
        </div>

        <Field label="Your plans for this token">
          <textarea
            value={plan}
            onChange={(e) => setPlan(e.target.value)}
            rows={4}
            placeholder="Tell us about your project, roadmap, and community plans..."
            className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50 resize-none"
          />
        </Field>

        <div className="glass-card p-4 space-y-2">
          <p className="text-sm text-foreground font-medium">Pay the ${listingFeeUsd} listing fee</p>
          <p className="text-xs text-muted-foreground break-all">
            Send {paymentAssetLabel} to:{' '}
            <span className="text-foreground font-mono">{treasury.data?.treasuryAddress ?? 'Loading treasury…'}</span>
          </p>
          <Field label="Payment transaction hash">
            <TextInput value={feeTxHash} onChange={setFeeTxHash} placeholder="0x..." />
          </Field>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!canSubmit || submit.isPending}
          className="w-full bg-accent hover:bg-accent/90 disabled:opacity-40 disabled:cursor-not-allowed text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-all active:scale-[0.98]"
        >
          {submit.isPending ? 'Verifying payment…' : resubmission ? 'Resubmit for Review' : 'Submit for Review'}
        </button>

        {!paymentReady && !listingFee.isLoading && (
          <p className="text-xs text-amber-300 text-center">Listing payments are temporarily unavailable. Please try again later.</p>
        )}

        {myListings.data && myListings.data.length > 0 && <button onClick={onViewListings} className="w-full text-center text-xs font-semibold text-accent underline underline-offset-4">View all listing statuses</button>}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs font-medium text-muted-foreground px-1">{label}</p>
      {children}
    </div>
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
    />
  );
}
