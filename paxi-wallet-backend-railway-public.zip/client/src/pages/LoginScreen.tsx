import { useEffect, useState } from 'react';
import { Delete, Fingerprint, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { authenticateWithBiometric, isBiometricAvailable } from '@/lib/wallet/biometric';
import { isBiometricEnabledOnVault, unlockWithBiometric, unlockWithPIN } from '@/lib/wallet/vault';

interface LoginScreenProps {
  onUnlocked: () => void;
}

export default function LoginScreen({ onUnlocked }: LoginScreenProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [isUnlocking, setIsUnlocking] = useState(false);
  const [biometricReady, setBiometricReady] = useState(false);
  const [shake, setShake] = useState(false);

  useEffect(() => {
    (async () => {
      const supported = await isBiometricAvailable();
      const enabled = isBiometricEnabledOnVault();
      setBiometricReady(supported && enabled);
      if (supported && enabled) {
        handleBiometricUnlock();
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleKeyPress = (digit: string) => {
    if (pin.length < 6) {
      setError('');
      const next = pin + digit;
      setPin(next);
      if (next.length === 6) handlePinUnlock(next);
    }
  };

  const handleBackspace = () => setPin(pin.slice(0, -1));

  const handlePinUnlock = async (fullPin: string) => {
    setIsUnlocking(true);
    setError('');
    try {
      await unlockWithPIN(fullPin);
      onUnlocked();
    } catch {
      setError('Incorrect PIN. Please try again.');
      setPin('');
      setShake(true);
      setTimeout(() => setShake(false), 420);
    } finally {
      setIsUnlocking(false);
    }
  };

  const handleBiometricUnlock = async () => {
    setError('');
    try {
      const ok = await authenticateWithBiometric();
      if (!ok) return;
      await unlockWithBiometric();
      onUnlocked();
    } catch {
      toast.error('Biometric unlock failed. Enter your PIN instead.');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8 relative overflow-x-hidden">
      {/* Soft ambient glow behind the lock badge - purely decorative */}
      <div
        className="pointer-events-none absolute left-1/2 top-24 -translate-x-1/2 w-64 h-64 rounded-full bg-accent/20 blur-3xl"
        aria-hidden
      />

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full relative">
        <div className="w-16 h-16 rounded-2xl bg-accent/10 border border-accent/25 flex items-center justify-center mb-5 shadow-lg shadow-accent/10">
          <Lock className="w-7 h-7 text-accent" strokeWidth={2.25} />
        </div>
        <h1 className="text-3xl font-bold text-foreground tracking-tight mb-1.5 text-center">Welcome back</h1>
        <p className="text-muted-foreground text-sm text-center mb-10">Enter your PIN to unlock your wallet</p>

        <div className={`flex justify-center gap-3.5 mb-10 ${shake ? 'animate-shake' : ''}`}>
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className={`w-3.5 h-3.5 rounded-full transition-all duration-150 ${
                i < pin.length ? 'bg-accent scale-110 shadow-md shadow-accent/40' : 'bg-secondary border border-border'
              } ${error ? 'ring-2 ring-destructive/40' : ''}`}
            />
          ))}
        </div>

        {error && (
          <div className="w-full flex items-center justify-center mb-6 -mt-4">
            <p className="text-sm text-destructive font-medium">{error}</p>
          </div>
        )}

        <div className="w-full grid grid-cols-3 gap-4 max-w-[280px] mx-auto">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
            <button
              key={digit}
              onClick={() => handleKeyPress(digit.toString())}
              disabled={isUnlocking}
              className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 active:bg-muted border border-border/60 text-foreground font-semibold text-xl transition-all duration-100 disabled:opacity-40"
            >
              {digit}
            </button>
          ))}
          {biometricReady ? (
            <button
              onClick={handleBiometricUnlock}
              className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 border border-border/60 text-accent transition-all duration-100 flex items-center justify-center"
              title="Unlock with biometrics"
            >
              <Fingerprint className="w-5 h-5" />
            </button>
          ) : (
            <div />
          )}
          <button
            onClick={() => handleKeyPress('0')}
            disabled={isUnlocking}
            className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 active:bg-muted border border-border/60 text-foreground font-semibold text-xl transition-all duration-100 disabled:opacity-40"
          >
            0
          </button>
          <button
            onClick={handleBackspace}
            disabled={isUnlocking}
            className="aspect-square rounded-full hover:bg-destructive/10 active:scale-95 text-muted-foreground hover:text-destructive transition-all duration-100 disabled:opacity-40 flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {isUnlocking && <p className="text-muted-foreground text-sm text-center mt-8 animate-pulse">Unlocking…</p>}
      </div>
    </div>
  );
}
