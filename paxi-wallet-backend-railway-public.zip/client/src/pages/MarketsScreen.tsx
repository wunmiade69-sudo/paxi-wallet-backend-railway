import { useEffect, useState } from "react";
import {
  Search,
  TrendingUp,
  TrendingDown,
  BarChart3,
  LayoutGrid,
  Loader2,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  AlertTriangle,
} from "lucide-react";
import BottomNav, { type NavTab } from "@/components/BottomNav";
import VerifiedBadge from "@/components/VerifiedBadge";
import {
  getTrustedMarketLabel,
  isOfficialPaxiMarketToken,
  PAXI_LOGO_URL,
} from "@/lib/appInfo";
import { trpc } from "@/lib/trpc";
import type { AssetConfig } from "@/lib/wallet/chains";
import { ASSETS } from "@/lib/wallet/chains";
import { customTokenToAsset, getCustomTokens } from "@/lib/wallet/customTokens";
import type { AssetBalance } from "@/lib/wallet/balances";

interface MarketsScreenProps {
  onNavigate: (tab: NavTab) => void;
  onSelectAsset: (
    asset: AssetConfig,
    balance: AssetBalance | undefined
  ) => void;
  onSelectToken: (coinId: string) => void;
}

type SortMode =
  | "market_cap_desc"
  | "price_change_percentage_24h_desc"
  | "price_change_percentage_24h_asc"
  | "volume_desc";

const SORT_TABS: Array<{
  id: SortMode;
  label: string;
  icon: typeof LayoutGrid;
}> = [
  { id: "market_cap_desc", label: "All", icon: LayoutGrid },
  {
    id: "price_change_percentage_24h_desc",
    label: "Top Gainers",
    icon: TrendingUp,
  },
  {
    id: "price_change_percentage_24h_asc",
    label: "Top Losers",
    icon: TrendingDown,
  },
  { id: "volume_desc", label: "Volume", icon: BarChart3 },
];

function MarketTokenIcon({ src, symbol }: { src: string; symbol: string }) {
  const [failed, setFailed] = useState(!src);
  if (failed) {
    return (
      <span className="w-8 h-8 rounded-full shrink-0 bg-accent/15 text-accent flex items-center justify-center text-xs font-bold">
        {symbol.slice(0, 2).toUpperCase()}
      </span>
    );
  }
  return (
    <img
      src={src}
      alt={symbol}
      className="w-8 h-8 rounded-full shrink-0 object-contain bg-foreground/5"
      onError={() => setFailed(true)}
    />
  );
}

/**
 * Real global market data via CoinGecko (server/marketData.ts) - thousands
 * of tokens, fetched from a real provider rather than hand-maintained.
 * Tapping a token you actually hold in this wallet opens its real asset
 * screen (send/receive/swap); tapping any other token is browse-only for
 * now (full external Token Detail page is the next step).
 */
export default function MarketsScreen({
  onNavigate,
  onSelectAsset,
  onSelectToken,
}: MarketsScreenProps) {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [sortMode, setSortMode] = useState<SortMode>("market_cap_desc");
  const [page, setPage] = useState(1);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 400);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    setPage(1);
  }, [sortMode, debouncedQuery]);

  const isSearching = debouncedQuery.length > 0;

  const listQuery = trpc.market.list.useQuery(
    { page, perPage: 50, order: sortMode },
    { enabled: !isSearching, placeholderData: prev => prev }
  );
  const discoveryQuery = trpc.market.discover.useQuery(
    { query: debouncedQuery },
    { enabled: isSearching }
  );

  const tokens = listQuery.data ?? [];
  const discoveryResults = discoveryQuery.data?.results ?? [];
  const isLoading = isSearching
    ? discoveryQuery.isLoading
    : listQuery.isLoading;
  const isFetchingPage =
    !isSearching && listQuery.isFetching && !listQuery.isLoading;

  // Wallet-held assets, so tapping a token you actually hold opens the real
  // asset screen instead of just browsing - matched loosely by symbol.
  const walletAssets = [
    ...ASSETS,
    ...getCustomTokens().map(customTokenToAsset),
  ];
  const walletAssetBySymbol = new Map(
    walletAssets.map(a => [a.symbol.toUpperCase(), a])
  );

  const handleRowTap = (symbol: string, coinId: string) => {
    const asset = walletAssetBySymbol.get(symbol.toUpperCase());
    if (asset) {
      onSelectAsset(asset, undefined);
    } else {
      onSelectToken(coinId);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 flex flex-col">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 space-y-3">
          <h1 className="text-2xl font-bold text-accent">Markets</h1>

          <div className="relative">
            <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search any token"
              className="w-full bg-secondary border border-border rounded-lg py-2.5 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
            />
          </div>

          {!isSearching && (
            <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
              {SORT_TABS.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setSortMode(id)}
                  className={`shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                    sortMode === id
                      ? "bg-accent text-accent-foreground"
                      : "bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-md mx-auto w-full px-6 py-4 flex-1">
        {isLoading &&
        (isSearching ? discoveryResults.length : tokens.length) === 0 ? (
          <div className="flex justify-center py-16">
            <Loader2 className="w-6 h-6 text-accent animate-spin" />
          </div>
        ) : isSearching ? (
          discoveryResults.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <p>
                {discoveryQuery.data?.message ??
                  `No tokens match "${debouncedQuery}"`}
              </p>
            </div>
          ) : (
            <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
              {discoveryResults.map((result, i) => {
                const isHeld = walletAssetBySymbol.has(
                  result.symbol.toUpperCase()
                );
                return (
                  <button
                    key={result.canonicalIdentity}
                    onClick={() =>
                      handleRowTap(
                        result.symbol,
                        result.coinId ?? result.canonicalIdentity
                      )
                    }
                    style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}
                    className="w-full px-4 py-3.5 text-left hover:bg-foreground/5 active:bg-foreground/10 transition-colors animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both"
                  >
                    <div className="flex items-center gap-3">
                      <MarketTokenIcon
                        src={result.logoUrl ?? ""}
                        symbol={result.symbol}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground text-sm flex items-center gap-1.5">
                          {result.symbol}
                          {result.trust === "verified" ? (
                            <span className="text-[9px] text-emerald-400 flex items-center gap-0.5">
                              <ShieldCheck className="w-3 h-3" />
                              VERIFIED
                            </span>
                          ) : (
                            <span className="text-[9px] text-orange-300 flex items-center gap-0.5">
                              <AlertTriangle className="w-3 h-3" />
                              UNVERIFIED
                            </span>
                          )}
                          {isHeld && (
                            <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-accent/15 text-accent">
                              HELD
                            </span>
                          )}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {result.name} · {result.chainName}
                        </p>
                        <p className="text-[10px] text-muted-foreground font-mono truncate">
                          {result.contractAddress}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-semibold text-foreground text-sm">
                          {result.priceUsd == null
                            ? "—"
                            : `$${result.priceUsd.toLocaleString(undefined, { maximumFractionDigits: result.priceUsd < 1 ? 6 : 2 })}`}
                        </p>
                        <p
                          className={`text-xs ${result.change24h == null ? "text-muted-foreground" : result.change24h >= 0 ? "text-emerald-400" : "text-red-400"}`}
                        >
                          {result.change24h == null
                            ? "—"
                            : `${result.change24h >= 0 ? "+" : ""}${result.change24h.toFixed(2)}%`}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 flex gap-3 text-[10px] text-muted-foreground">
                      <span>
                        Liquidity{" "}
                        {result.liquidityUsd == null
                          ? "—"
                          : `$${result.liquidityUsd.toLocaleString()}`}
                      </span>
                      <span>
                        Vol 24h{" "}
                        {result.volume24hUsd == null
                          ? "—"
                          : `$${result.volume24hUsd.toLocaleString()}`}
                      </span>
                      <span>{result.dataFreshness}</span>
                      <span>{result.security.replace("_", " ")}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )
        ) : tokens.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <p>Could not load market data.</p>
          </div>
        ) : (
          <>
            <div
              className={`glass-card divide-y divide-white/5 !p-0 overflow-hidden transition-opacity ${isFetchingPage ? "opacity-50" : ""}`}
            >
              {tokens.map((t, i) => {
                const isHeld = walletAssetBySymbol.has(t.symbol.toUpperCase());
                const isOfficialPaxi = isOfficialPaxiMarketToken(t);
                const verifiedMarketLabel = getTrustedMarketLabel(t);
                return (
                  <button
                    key={t.id}
                    onClick={() => handleRowTap(t.symbol, t.id)}
                    style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}
                    className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-foreground/5 active:bg-foreground/10 transition-colors animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both"
                  >
                    {t.marketCapRank && (
                      <span className="w-5 text-xs text-muted-foreground text-center shrink-0">
                        {t.marketCapRank}
                      </span>
                    )}
                    <MarketTokenIcon
                      src={isOfficialPaxi ? PAXI_LOGO_URL : t.image}
                      symbol={t.symbol}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground text-sm flex items-center gap-1.5">
                        {t.symbol}
                        {verifiedMarketLabel && (
                          <VerifiedBadge compact label={verifiedMarketLabel} />
                        )}
                        {isHeld && (
                          <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-accent/15 text-accent">
                            HELD
                          </span>
                        )}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">
                        {t.name}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-semibold text-foreground text-sm">
                        $
                        {t.currentPrice?.toLocaleString(undefined, {
                          maximumFractionDigits: t.currentPrice < 1 ? 6 : 2,
                        })}
                      </p>
                      <p
                        className={`text-xs ${t.priceChangePercent24h == null ? "text-muted-foreground" : t.priceChangePercent24h >= 0 ? "text-emerald-400" : "text-red-400"}`}
                      >
                        {t.priceChangePercent24h != null
                          ? `${t.priceChangePercent24h >= 0 ? "+" : ""}${t.priceChangePercent24h.toFixed(2)}%`
                          : "—"}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {!isSearching && (
              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="flex items-center gap-1 text-sm text-muted-foreground disabled:opacity-30 px-3 py-1.5 rounded-lg hover:bg-foreground/5 active:scale-95 transition-all"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Prev
                </button>
                <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                  {isFetchingPage && (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  )}
                  Page {page}
                </span>
                <button
                  onClick={() => setPage(p => p + 1)}
                  className="flex items-center gap-1 text-sm text-accent px-3 py-1.5 rounded-lg hover:bg-accent/10 active:scale-95 transition-all"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        )}
      </div>
      <BottomNav active="markets" onNavigate={onNavigate} />
    </div>
  );
}
