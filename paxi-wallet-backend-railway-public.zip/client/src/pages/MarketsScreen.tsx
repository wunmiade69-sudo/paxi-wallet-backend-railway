import { useEffect, useState } from 'react';
import { Search, TrendingUp, TrendingDown, BarChart3, LayoutGrid, Loader2, ChevronLeft, ChevronRight, ShieldAlert, Star, Clock3, X } from 'lucide-react';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import AssetLogo from '@/components/AssetLogo';
import NotificationBell from '@/components/NotificationBell';
import { trpc } from '@/lib/trpc';
import type { AssetConfig } from '@/lib/wallet/chains';
import { ASSETS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import type { AssetBalance } from '@/lib/wallet/balances';
import { assetIdentityKey, canonicalMarketIdentityKey, canonicalNativeIdentityKey, shortenCanonicalIdentifier } from '@/lib/marketIdentity';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { notifyForPriceMovement } from '@/lib/phase3Local';
import { getTrustedMarketLabel, isOfficialPaxiMarketToken, PAXI_LOGO_URL } from '@/lib/appInfo';
import { getBalanceSnapshot } from '@/lib/wallet/balanceCache';
import { getStoredAddress } from '@/lib/wallet/vault';
import { getMarketWatchlist, marketWatchlistKey, toggleMarketWatchlist, type MarketWatchlistItem } from '@/lib/marketWatchlist';

export interface MarketTokenSelection {
  coinId: string | null;
  chain: string | null;
  contractAddress: string | null;
  symbol: string;
  name: string;
}

interface MarketsScreenProps {
  onNavigate: (tab: NavTab) => void;
  balanceSnapshot?: Record<string, AssetBalance>;
  onSelectAsset: (asset: AssetConfig, balance: AssetBalance | undefined) => void;
  onSelectToken: (token: MarketTokenSelection) => void;
  onNotifications: () => void;
}

type SortMode = 'market_cap_desc' | 'price_change_percentage_24h_desc' | 'price_change_percentage_24h_asc' | 'volume_desc';

const SORT_TABS: Array<{ id: SortMode; label: string; icon: typeof LayoutGrid }> = [
  { id: 'market_cap_desc', label: 'All', icon: LayoutGrid },
  { id: 'price_change_percentage_24h_desc', label: 'Top Gainers', icon: TrendingUp },
  { id: 'price_change_percentage_24h_asc', label: 'Top Losers', icon: TrendingDown },
  { id: 'volume_desc', label: 'Volume', icon: BarChart3 },
];

/**
 * Real global market data via CoinGecko (server/marketData.ts) - thousands
 * of tokens, fetched from a real provider rather than hand-maintained.
 * Tapping a token you actually hold in this wallet opens its real asset
 * screen (send/receive/swap); tapping any other token is browse-only for
 * now (full external Token Detail page is the next step).
 */
export default function MarketsScreen({ onNavigate, balanceSnapshot, onSelectAsset, onSelectToken, onNotifications }: MarketsScreenProps) {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('market_cap_desc');
  const [page, setPage] = useState(1);
  const [watchlistItems, setWatchlistItems] = useState<MarketWatchlistItem[]>(() => getMarketWatchlist());
  const [watchlistFilter, setWatchlistFilter] = useState<'all' | 'watchlist'>('all');
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 400);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    setPage(1);
  }, [sortMode, debouncedQuery]);

  const isSearching = debouncedQuery.length > 0;

  const listQuery = trpc.market.list.useQuery(
    { page, perPage: 50, order: sortMode },
    { enabled: !isSearching, placeholderData: (prev) => prev }
  );
  const searchQuery = trpc.market.search.useQuery({ query: debouncedQuery }, { enabled: isSearching });

  const tokens = isSearching ? (searchQuery.data ?? []) : (listQuery.data?.items ?? []);
  const securityCandidates = tokens
    .filter((token) => token.contractAddress && ['ethereum', 'bsc', 'polygon', 'arbitrum', 'base'].includes(token.chain ?? ''))
    .slice(0, 8);
  const securityBatch = trpc.security.checkContracts.useQuery(
    { contracts: securityCandidates.map((token) => ({ network: token.chain as 'ethereum' | 'bsc' | 'polygon' | 'arbitrum' | 'base', contractAddress: token.contractAddress! })) },
    { enabled: securityCandidates.length > 0, staleTime: 5 * 60_000, refetchOnWindowFocus: false },
  );
  const securityByKey = new Map((securityBatch.data ?? []).map((item) => [item.key, item] as const));
  const visibleTokens = watchlistFilter === 'watchlist'
    ? tokens.filter((token) => {
      const key = marketWatchlistKey(token);
      return Boolean(key && watchlistItems.some((item) => item.key === key));
    })
    : tokens;
  const hasNextPage = isSearching ? false : Boolean(listQuery.data?.hasMore);
  const isLoading = isSearching ? searchQuery.isLoading : listQuery.isLoading;

  useEffect(() => {
    for (const token of tokens) {
      if (!Number.isFinite(Number(token.currentPrice)) || Number(token.currentPrice) <= 0) continue;
      const assetKey = token.chain && token.contractAddress
        ? canonicalMarketIdentityKey(token.chain, token.contractAddress)
        : token.coinId ?? token.id;
      notifyForPriceMovement({
        assetKey,
        symbol: token.symbol,
        currentPrice: Number(token.currentPrice),
        chain: token.chain,
        contractOrMint: token.contractAddress,
        coinId: token.coinId,
      });
    }
  }, [tokens]);
  const isFetchingPage = !isSearching && listQuery.isFetching && !listQuery.isLoading;
  const freshnessLabel = isFetchingPage ? 'Refreshing' : tokens.length > 0 ? 'Updated just now' : 'Waiting for data';
  const toggleTokenWatchlist = (token: (typeof tokens)[number]) => {
    const key = marketWatchlistKey(token);
    if (!key) return;
    toggleMarketWatchlist({
      key,
      symbol: token.symbol,
      name: token.name,
      chain: token.chain,
      contractAddress: token.contractAddress,
      coinId: token.coinId ?? null,
      image: token.image,
    });
    setWatchlistItems(getMarketWatchlist());
  };
  const pricedTokens = tokens.filter((token) => typeof token.currentPrice === 'number' && Number.isFinite(token.currentPrice));
  const topGainer = [...pricedTokens].filter((token) => token.priceChangePercent24h != null).sort((a, b) => (b.priceChangePercent24h ?? -Infinity) - (a.priceChangePercent24h ?? -Infinity))[0];
  const averageMove = pricedTokens.length
    ? pricedTokens.reduce((sum, token) => sum + (token.priceChangePercent24h ?? 0), 0) / pricedTokens.length
    : null;

  // Held-asset matching is intentionally canonical. Symbol-only matching can
  // open the wrong token when the same symbol exists on multiple chains.
  const walletAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
  const walletAssetByIdentity = new Map(
    walletAssets
      .map((asset) => [assetIdentityKey(asset), asset] as const)
      .filter((entry): entry is readonly [string, AssetConfig] => entry[0] !== null),
  );

  const cachedWalletBalances = getStoredAddress() ? getBalanceSnapshot(getStoredAddress()!) ?? {} : {};
  const knownBalances = { ...cachedWalletBalances, ...(balanceSnapshot ?? {}) };

  const handleRowTap = (token: (typeof tokens)[number]) => {
    const key = token.chain && token.contractAddress
      ? canonicalMarketIdentityKey(token.chain, token.contractAddress)
      : token.chain && token.identifier === 'native'
        ? canonicalNativeIdentityKey(token.chain)
        : null;
    const asset = key ? walletAssetByIdentity.get(key) : undefined;
    if (asset) onSelectAsset(asset, knownBalances[assetIdentityKey(asset) ?? '']);
    else onSelectToken({
      coinId: token.coinId ?? null,
      chain: token.chain ?? null,
      contractAddress: token.contractAddress ?? null,
      symbol: token.symbol,
      name: token.name,
    });
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-24 flex flex-col">
      <div className="paxi-page-header sticky top-0 z-40">
        <div className="mx-auto max-w-md space-y-3 px-4 py-4 sm:px-6">
          <div>
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Market intelligence</p>
                <h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground">Markets</h1>
                <p className="mt-1 inline-flex items-center gap-1.5 text-[10px] font-medium text-muted-foreground" aria-live="polite">
                  <Clock3 className="h-3 w-3" aria-hidden={true} />
                  {freshnessLabel}
                </p>
              </div>
              <NotificationBell onOpen={onNotifications} />
            </div>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              type="search"
              aria-label="Search market tokens"
              placeholder="Search by token or symbol"
              className="paxi-field w-full py-2.5 pl-9 pr-9 text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Clear search"
                className="absolute right-1.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-foreground/10 hover:text-foreground"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {!isSearching && (
            <div className="space-y-2">
              <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
                <button
                  type="button"
                  onClick={() => setWatchlistFilter('all')}
                  aria-pressed={watchlistFilter === 'all'}
                  className={`paxi-chip shrink-0 flex items-center gap-1 text-xs font-semibold ${watchlistFilter === 'all' ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}
                >
                  <LayoutGrid className="h-3.5 w-3.5" /> All assets
                </button>
                <button
                  type="button"
                  onClick={() => setWatchlistFilter('watchlist')}
                  aria-pressed={watchlistFilter === 'watchlist'}
                  className={`paxi-chip shrink-0 flex items-center gap-1 text-xs font-semibold ${watchlistFilter === 'watchlist' ? 'bg-amber-400/15 text-amber-300' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}
                >
                  <Star className={`h-3.5 w-3.5 ${watchlistFilter === 'watchlist' ? 'fill-current' : ''}`} /> Watchlist <span className="rounded-full bg-foreground/10 px-1.5 py-0.5 text-[10px]">{watchlistItems.length}</span>
                </button>
              </div>
              <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
              {SORT_TABS.map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setSortMode(id)}
                    aria-pressed={sortMode === id}
                    className={`paxi-chip shrink-0 flex items-center gap-1 text-xs font-semibold ${
                      sortMode === id ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
                    }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                </button>
              ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mx-auto w-full max-w-md flex-1 px-4 py-5 sm:px-6">
        {isLoading && tokens.length === 0 ? (
          <div className="glass-card space-y-3 p-5" aria-label="Loading market data" aria-busy="true">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="flex items-center gap-3 py-2">
                <div className="h-10 w-10 animate-pulse rounded-full bg-secondary" />
                <div className="min-w-0 flex-1 space-y-2"><div className="h-3 w-24 animate-pulse rounded bg-secondary" /><div className="h-2.5 w-36 animate-pulse rounded bg-secondary" /></div>
                <div className="space-y-2"><div className="ml-auto h-3 w-16 animate-pulse rounded bg-secondary" /><div className="ml-auto h-2.5 w-10 animate-pulse rounded bg-secondary" /></div>
              </div>
            ))}
            <div className="flex items-center justify-center gap-2 pt-1 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Updating prices</div>
          </div>
        ) : visibleTokens.length === 0 ? (
          <div className="glass-card px-6 py-12 text-center" aria-live="polite">
            {watchlistFilter === 'watchlist' && !isSearching ? <Star className="mx-auto mb-3 h-7 w-7 text-amber-300/80" aria-hidden={true} /> : <BarChart3 className="mx-auto mb-3 h-7 w-7 text-muted-foreground" aria-hidden={true} />}
            <p className="text-sm font-medium text-foreground">{watchlistFilter === 'watchlist' && !isSearching ? (watchlistItems.length ? 'No saved assets on this market page' : 'Your watchlist is empty') : isSearching ? `No tokens match "${debouncedQuery}"` : 'Market data is unavailable right now.'}</p>
            <p className="mt-1 text-xs text-muted-foreground">{watchlistFilter === 'watchlist' && !isSearching ? (watchlistItems.length ? 'Search for the saved token or switch to All assets.' : 'Star an asset to keep it close at hand.') : isSearching ? 'Try a different symbol or token name.' : 'Please try again in a moment.'}</p>
          </div>
        ) : (
          <>
            {!isSearching && watchlistFilter === 'all' && pricedTokens.length > 0 && (
              <section className="mb-5 space-y-3" aria-labelledby="market-pulse-title">
                <div className="flex items-end justify-between gap-3 px-1">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-accent">Live market</p>
                    <h2 id="market-pulse-title" className="mt-1 text-lg font-semibold tracking-tight text-foreground">Market pulse</h2>
                  </div>
                  <span className="inline-flex items-center gap-1.5 text-[10px] font-medium text-muted-foreground">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" aria-hidden={true} />
                    Provider-sourced
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <article className="relative overflow-hidden rounded-2xl border border-accent/20 bg-gradient-to-br from-accent/15 via-card to-card p-4 shadow-sm">
                    <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-accent/15 blur-2xl" aria-hidden={true} />
                    <p className="relative text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Top mover</p>
                    <div className="relative mt-3 flex items-center gap-2.5">
                      <AssetLogo src={topGainer?.image} fallback={topGainer?.symbol?.slice(0, 3) || '—'} size="sm" aria-hidden={true} />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-foreground">{topGainer?.symbol || '—'}</p>
                        <p className={`text-xs font-semibold ${(topGainer?.priceChangePercent24h ?? 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {topGainer?.priceChangePercent24h == null ? 'Unavailable' : `${topGainer.priceChangePercent24h >= 0 ? '+' : ''}${topGainer.priceChangePercent24h.toFixed(2)}%`}
                        </p>
                      </div>
                    </div>
                  </article>
                  <article className={`relative overflow-hidden rounded-2xl border p-4 shadow-sm ${averageMove == null ? 'border-border/70 bg-card/80' : averageMove >= 0 ? 'border-emerald-400/20 bg-gradient-to-br from-emerald-400/15 via-card to-card' : 'border-red-400/20 bg-gradient-to-br from-red-400/15 via-card to-card'}`}>
                    <div className={`pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full blur-2xl ${averageMove == null ? 'bg-transparent' : averageMove >= 0 ? 'bg-emerald-400/15' : 'bg-red-400/15'}`} aria-hidden={true} />
                    <p className="relative text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Visible trend</p>
                    <div className="relative mt-3 flex items-center gap-2.5">
                      <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${averageMove == null ? 'bg-secondary text-muted-foreground' : averageMove >= 0 ? 'bg-emerald-400/15 text-emerald-400' : 'bg-red-400/15 text-red-400'}`} aria-hidden={true}>
                        {averageMove != null && averageMove < 0 ? <TrendingDown className="h-4 w-4" /> : <TrendingUp className="h-4 w-4" />}
                      </span>
                      <div className="min-w-0">
                        <p className={`text-sm font-semibold tabular-nums ${averageMove == null ? 'text-muted-foreground' : averageMove >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {averageMove == null ? '—' : `${averageMove >= 0 ? '+' : ''}${averageMove.toFixed(2)}%`}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">Average 24H change</p>
                      </div>
                    </div>
                  </article>
                </div>
                <div className="rounded-2xl border border-border/70 bg-card/65 px-4 py-3">
                  <div className="mb-2 flex items-center justify-between text-[10px] font-medium text-muted-foreground">
                    <span>Market movement · {pricedTokens.length} visible assets</span>
                    <span>24H</span>
                  </div>
                  <div className="flex h-12 items-end gap-1.5" aria-label="Visible market movement bars">
                    {pricedTokens.slice(0, 12).map((token, index) => {
                      const movement = token.priceChangePercent24h ?? 0;
                      const height = Math.max(16, Math.min(100, 26 + Math.abs(movement) * 7));
                      return <span key={`${token.id}-${index}`} title={`${token.symbol}: ${movement >= 0 ? '+' : ''}${movement.toFixed(2)}%`} className={`min-w-0 flex-1 rounded-t-sm ${movement >= 0 ? 'bg-accent/75' : 'bg-red-400/70'}`} style={{ height: `${height}%` }} />;
                    })}
                  </div>
                </div>
              </section>
            )}
            <div className="mb-2 flex items-center justify-between px-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
              <span>{isSearching ? 'Search results' : 'Tracked assets'}</span>
              <span>Price · 24H</span>
            </div>
            <div className={`glass-card divide-y divide-white/5 !p-0 overflow-hidden transition-opacity ${isFetchingPage ? 'opacity-50' : ''}`}>
              {visibleTokens.map((t, i) => {
                const identityKey = t.chain && t.contractAddress
                  ? canonicalMarketIdentityKey(t.chain, t.contractAddress)
                  : t.chain && t.identifier === 'native'
                    ? canonicalNativeIdentityKey(t.chain)
                    : null;
                const isHeld = Boolean(identityKey && walletAssetByIdentity.has(identityKey));
                const trustedLabel = getTrustedMarketLabel({ id: t.id, symbol: t.symbol, name: t.name });
                const officialPaxi = isOfficialPaxiMarketToken({ symbol: t.symbol, name: t.name });
                const watchKey = marketWatchlistKey(t);
                  const isWatchlisted = Boolean(watchKey && watchlistItems.some((item) => item.key === watchKey));
                const securitySignal = t.chain && t.contractAddress ? securityByKey.get(`${t.chain}:${t.contractAddress.toLowerCase()}`) : undefined;
                const securityLabel = securitySignal?.status === 'high-risk' ? 'High-risk contract' : securitySignal?.status === 'safe' ? 'Security review available' : securitySignal ? 'Security status unknown' : undefined;
                return (
                  <div
                    key={`${t.chain ?? 'unknown'}:${t.contractAddress ?? t.coinId ?? t.id}`}
                    style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}
                    className="flex min-h-[4.75rem] w-full items-center gap-1 border-b border-white/5 last:border-b-0 animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both"
                  >
                    <button
                      type="button"
                      onClick={() => handleRowTap(t)}
                      className="paxi-pressable flex min-w-0 flex-1 items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-foreground/5 active:bg-foreground/10"
                    >
                      {t.marketCapRank && <span className="w-5 shrink-0 text-center text-xs text-muted-foreground">{t.marketCapRank}</span>}
                      <AssetLogo src={officialPaxi ? PAXI_LOGO_URL : t.image} fallback={t.symbol.slice(0, 3) || '?'} size="md" aria-hidden={true} />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                          <span className="min-w-[3ch] shrink truncate">{t.symbol || 'UNKNOWN'}</span>
                          {isHeld && <span className="paxi-status min-h-5 shrink-0 bg-accent/15 px-1.5 py-0.5 text-[9px] text-accent">Held</span>}
                          {trustedLabel
                            ? <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent/12 text-accent" title={officialPaxi ? 'Official PAXI asset' : trustedLabel}>{officialPaxi ? <span className="text-[10px] font-bold leading-none">✓</span> : <ShieldAlert className="h-3 w-3" aria-hidden={true} />}</span>
                            : <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500/15 text-amber-300" title="Provider market data only; PAXI has not verified this asset identity"><ShieldAlert className="h-3 w-3" aria-hidden={true} /></span>}
                          {securityLabel && <span className={`h-2 w-2 shrink-0 rounded-full ${securitySignal?.status === 'high-risk' ? 'bg-red-400' : securitySignal?.status === 'safe' ? 'bg-emerald-400' : 'bg-amber-300'}`} title={securityLabel} aria-label={securityLabel} />}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">{t.name || 'Unknown token'}{t.chain ? ` · ${CHAIN_LABELS[t.chain] ?? t.chain}` : ''}</p>
                        {t.contractAddress && <p className="truncate font-mono text-[10px] text-muted-foreground/70">{shortenCanonicalIdentifier(t.contractAddress)}</p>}
                        <p className="truncate text-[10px] text-muted-foreground/70">
                          {t.marketCap != null || t.volume24h != null
                            ? [t.marketCap != null ? `Cap ${formatCompactUsd(t.marketCap)}` : null, t.volume24h != null ? `Vol ${formatCompactUsd(t.volume24h)}` : null].filter(Boolean).join(' · ')
                            : t.contractAddress ? 'Contract identified · market data' : 'Market data · contract unavailable'}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className="text-sm font-semibold text-foreground">{t.currentPrice != null ? formatUsd(t.currentPrice, currency, fiatRate) : '—'}</p>
                        <p className={`text-xs ${t.priceChangePercent24h == null ? 'text-muted-foreground' : t.priceChangePercent24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{t.priceChangePercent24h != null ? `${t.priceChangePercent24h >= 0 ? '+' : ''}${t.priceChangePercent24h.toFixed(2)}%` : '—'}</p>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleTokenWatchlist(t)}
                      disabled={!watchKey}
                      aria-label={isWatchlisted ? `Remove ${t.symbol} from watchlist` : `Add ${t.symbol} to watchlist`}
                      aria-pressed={isWatchlisted}
                      className={`mr-2 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-colors ${isWatchlisted ? 'bg-amber-400/15 text-amber-300' : 'text-muted-foreground hover:bg-foreground/5 hover:text-foreground'} disabled:cursor-not-allowed disabled:opacity-30`}
                    >
                      <Star className={`h-4 w-4 ${isWatchlisted ? 'fill-current' : ''}`} aria-hidden={true} />
                    </button>
                  </div>
                );
              })}
            </div>

            {!isSearching && watchlistFilter === 'all' && (
              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  type="button"
                  className="paxi-pressable flex min-h-11 items-center gap-1 rounded-lg px-3 py-1.5 text-sm text-muted-foreground transition-all hover:bg-foreground/5 disabled:opacity-30"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Prev
                </button>
                <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                  {isFetchingPage && <Loader2 className="w-3 h-3 animate-spin" />}
                  Page {page}
                </span>
                <button
                  onClick={() => setPage((p) => p + 1)}
                  disabled={!hasNextPage || isFetchingPage}
                  type="button"
                  aria-label={hasNextPage ? 'Next market page' : 'No more market results'}
                  className="paxi-pressable flex min-h-11 items-center gap-1 rounded-lg px-3 py-1.5 text-sm text-accent transition-all hover:bg-accent/10 disabled:opacity-30 disabled:hover:bg-transparent"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        )}
      </div>
      <BottomNav active="markets" onNavigate={onNavigate} />
    </div>
  );
}

const CHAIN_LABELS: Record<string, string> = {
  ethereum: 'Ethereum',
  bsc: 'BNB Smart Chain',
  solana: 'Solana',
  polygon: 'Polygon',
  arbitrum: 'Arbitrum',
  bitcoin: 'Bitcoin',
  base: 'Base',
};


function formatUsd(value: number | null, currency: import('@/lib/currency').FiatCurrency, fiatRate: number | null): string {
  return formatFiat(value, currency, fiatRate);
}

/** Compact USD magnitude (e.g. $1.2B, $340M) for market cap / volume row meta. Always USD: these are provider magnitudes, not a fiat-converted price. */
function formatCompactUsd(value: number): string {
  const abs = Math.abs(value);
  if (abs >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(abs >= 10_000_000_000 ? 0 : 1)}B`;
  if (abs >= 1_000_000) return `$${(value / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1)}M`;
  if (abs >= 1_000) return `$${(value / 1_000).toFixed(abs >= 10_000 ? 0 : 1)}K`;
  return `$${value.toFixed(0)}`;
}
