import { useI18n } from "@/lib/i18n";
import {
  ChevronRight,
  PieChart,
  Wallet,
  ArrowLeftRight,
  Sparkles,
  BookUser,
  Gift,
  BookOpen,
  Info,
  Settings as SettingsIcon,
  Rocket,
  Globe2,
  Copy,
  Check,
  LifeBuoy,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import BottomNav, { type NavTab } from "@/components/BottomNav";
import { getStoredAddress, getWallets } from "@/lib/wallet/vault";

interface MeScreenProps {
  onNavigate: (tab: NavTab) => void;
  onSettings: () => void;
  onAssetOverview: () => void;
  onTransactionRecords: () => void;
  onAddressBook: () => void;
  onManageWallets: () => void;
  onWalletGuide: () => void;
  onExperience: () => void;
  onInviteFriends: () => void;
  onGiftCodes: () => void;
  onAboutUs: () => void;
  onCreateToken: () => void;
  onWeb3Browser: () => void;
  onSupport: () => void;
}

function shortAddress(address: string) {
  return `${address.slice(0, 6)}…${address.slice(-4)}`;
}

export default function MeScreen({
  onNavigate,
  onSettings,
  onAssetOverview,
  onTransactionRecords,
  onAddressBook,
  onManageWallets,
  onWalletGuide,
  onExperience,
  onInviteFriends,
  onGiftCodes,
  onAboutUs,
  onCreateToken,
  onWeb3Browser,
  onSupport,
}: MeScreenProps) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);
  const address = getStoredAddress();
  const walletCount = getWallets().length;

  const handleCopy = () => {
    if (!address) return;
    navigator.clipboard.writeText(address);
    setCopied(true);
    toast.success("Address copied");
    setTimeout(() => setCopied(false), 2000);
  };

  const groups: Array<
    Array<{
      label: string;
      icon: typeof Wallet;
      onClick: () => void;
      badge?: boolean;
    }>
  > = [
    [
      {
        label: t("me_asset_overview"),
        icon: PieChart,
        onClick: onAssetOverview,
      },
      { label: t("me_manage_wallets"), icon: Wallet, onClick: onManageWallets },
      {
        label: t("me_transaction_records"),
        icon: ArrowLeftRight,
        onClick: onTransactionRecords,
      },
    ],
    [{ label: t("me_create_token"), icon: Rocket, onClick: onCreateToken }],
    [
      { label: "Web3 Browser", icon: Globe2, onClick: onWeb3Browser },
      { label: "Experience", icon: Sparkles, onClick: onExperience },
      { label: "Address Book", icon: BookUser, onClick: onAddressBook },
    ],
    [
      { label: "Gift Codes", icon: Gift, onClick: onGiftCodes },
      { label: "Invite Friends", icon: Gift, onClick: onInviteFriends },
      { label: "Wallet Guide", icon: BookOpen, onClick: onWalletGuide },
      { label: "Help & Support", icon: LifeBuoy, onClick: onSupport },
      { label: "About Us", icon: Info, onClick: onAboutUs },
      { label: "Settings", icon: SettingsIcon, onClick: onSettings },
    ],
  ];

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-accent">Me</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-4">
        {/* Identity card - gives this screen a "you" before the menu, and doubles as a quick
            way to copy your address without a trip to Receive. */}
        {address && (
          <button
            onClick={handleCopy}
            className="w-full glass-card !p-4 flex items-center gap-3 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all animate-in fade-in duration-300"
          >
            <span className="w-11 h-11 rounded-full bg-gradient-to-br from-accent/40 to-accent/10 border border-accent/25 flex items-center justify-center font-bold text-accent shrink-0">
              {address.slice(2, 4).toUpperCase()}
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-foreground text-sm font-mono truncate">
                {shortAddress(address)}
              </p>
              <p className="text-xs text-muted-foreground">
                {walletCount} wallet{walletCount === 1 ? "" : "s"} on this
                device
              </p>
            </div>
            {copied ? (
              <Check className="w-4 h-4 text-accent shrink-0" />
            ) : (
              <Copy className="w-4 h-4 text-muted-foreground shrink-0" />
            )}
          </button>
        )}

        {groups.map((items, gi) => (
          <div
            key={gi}
            style={{ animationDelay: `${gi * 60}ms` }}
            className="glass-card divide-y divide-white/5 overflow-hidden animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both"
          >
            {items.map(({ label, icon: Icon, onClick, badge }) => (
              <button
                key={label}
                onClick={onClick}
                className="w-full flex items-center justify-between py-3.5 px-1 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-accent" />
                  </span>
                  <span className="text-foreground text-sm font-medium">
                    {label}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  {badge && (
                    <span className="w-2 h-2 rounded-full bg-orange-500" />
                  )}
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </button>
            ))}
          </div>
        ))}
      </div>

      <BottomNav active="me" onNavigate={onNavigate} />
    </div>
  );
}
