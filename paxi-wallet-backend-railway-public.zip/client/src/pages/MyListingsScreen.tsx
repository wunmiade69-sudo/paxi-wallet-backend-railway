import { ArrowLeft, BadgeCheck, CircleCheck, CircleX, Clock3, CreditCard, RotateCcw, ShieldCheck } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { listingCanBeResubmitted, listingIsCampaignEligible, listingStatusLabel } from '@/lib/listingStatus';

export interface ListingResubmissionDraft {
  id: number;
  network: string;
  contractAddress: string;
  symbol: string;
  name: string;
  logoKey: string | null;
  socials: Record<string, string> | null;
  plan: string | null;
}

interface MyListingsScreenProps {
  onBack: () => void;
  onCreateListing: () => void;
  onResubmit: (listing: ListingResubmissionDraft) => void;
}

const statusStyle = {
  pending: { className: 'bg-amber-400/10 text-amber-300', icon: Clock3 },
  verified: { className: 'bg-emerald-400/10 text-emerald-300', icon: CircleCheck },
  rejected: { className: 'bg-destructive/10 text-destructive', icon: CircleX },
} as const;

function formatDate(value: Date | string) {
  return new Date(value).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function networkLabel(network: string) {
  const labels: Record<string, string> = { bsc: 'BNB Smart Chain', ethereum: 'Ethereum', polygon: 'Polygon', arbitrum: 'Arbitrum', solana: 'Solana' };
  return labels[network] ?? network;
}

export default function MyListingsScreen({ onBack, onCreateListing, onResubmit }: MyListingsScreenProps) {
  const { data: listings, isLoading, error } = trpc.listings.myListings.useQuery();

  return (
    <div className="min-h-screen bg-background pb-12">
      <div className="sticky top-0 z-40 border-b border-foreground/5 bg-secondary/50 backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center gap-3 px-6 py-4">
          <button onClick={onBack} aria-label="Back" className="text-muted-foreground hover:text-foreground"><ArrowLeft className="h-5 w-5" /></button>
          <div className="min-w-0 flex-1">
            <h1 className="text-lg font-bold text-foreground">My Listings</h1>
            <p className="text-xs text-muted-foreground">Verification and campaign eligibility</p>
          </div>
          <button onClick={onCreateListing} className="rounded-lg bg-accent px-3 py-2 text-xs font-semibold text-accent-foreground active:scale-[0.98]">New listing</button>
        </div>
      </div>

      <div className="mx-auto max-w-md space-y-4 px-6 py-6">
        {isLoading && <p className="text-sm text-muted-foreground">Loading your listings…</p>}
        {error && <p className="text-sm text-destructive">Unable to load listings right now. Please try again.</p>}
        {!isLoading && !error && listings?.length === 0 && (
          <div className="glass-card space-y-3 p-5 text-center">
            <BadgeCheck className="mx-auto h-8 w-8 text-accent" />
            <p className="font-semibold text-foreground">No listings yet</p>
            <p className="text-sm text-muted-foreground">List a token to begin the verification process before creating a campaign.</p>
            <button onClick={onCreateListing} className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground">Create listing</button>
          </div>
        )}

        {listings?.map((listing) => {
          const presentation = statusStyle[listing.status];
          const StatusIcon = presentation.icon;
          return (
            <article key={listing.id} className="glass-card space-y-4 p-4">
              <div className="flex items-start gap-3">
                {listing.logoKey ? <img src={`/manus-storage/${listing.logoKey}`} alt="" className="h-11 w-11 rounded-full object-cover" /> : <span className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/10 font-bold text-accent">{listing.symbol.slice(0, 1)}</span>}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-base font-semibold text-foreground">{listing.name} <span className="text-muted-foreground">{listing.symbol}</span></p>
                  <p className="text-xs text-muted-foreground">{networkLabel(listing.network)}</p>
                </div>
                <span className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold uppercase tracking-wide ${presentation.className}`}><StatusIcon className="h-3 w-3" />{listingStatusLabel(listing.status)}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg bg-secondary/80 p-3"><p className="text-muted-foreground">Listing fee</p><p className="mt-1 font-semibold text-foreground">${listing.feeAmountUsd ?? '—'}</p></div>
                <div className="rounded-lg bg-secondary/80 p-3"><p className="text-muted-foreground">Payment</p><p className="mt-1 inline-flex items-center gap-1 font-semibold text-emerald-300"><CreditCard className="h-3 w-3" />Verified</p></div>
              </div>

              <div className="space-y-1 text-xs text-muted-foreground">
                <p className="break-all"><span className="text-foreground/80">Contract</span> · <span className="font-mono">{listing.contractAddress}</span></p>
                <p><span className="text-foreground/80">Submitted</span> · {formatDate(listing.createdAt)}</p>
              </div>

              {listingIsCampaignEligible(listing.status) && <div className="flex items-center gap-2 rounded-lg bg-emerald-400/10 p-3 text-xs text-emerald-200"><ShieldCheck className="h-4 w-4 shrink-0" />Eligible for campaigns. Campaign contracts will be locked to this approved token identity.</div>}
              {listing.status === 'pending' && <div className="rounded-lg bg-amber-400/10 p-3 text-xs text-amber-100">Payment was verified. The token is waiting for PAXI review before it can run a campaign.</div>}
              {listingCanBeResubmitted(listing.status) && (
                <div className="space-y-3 rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
                  <p><span className="font-semibold">Reason:</span> {listing.rejectionReason ?? 'The listing did not meet review requirements.'}</p>
                  <button onClick={() => onResubmit({ id: listing.id, network: listing.network, contractAddress: listing.contractAddress, symbol: listing.symbol, name: listing.name, logoKey: listing.logoKey, socials: listing.socials as Record<string, string> | null, plan: listing.plan })} className="inline-flex items-center gap-1.5 rounded-md bg-destructive px-3 py-2 font-semibold text-white active:scale-[0.98]"><RotateCcw className="h-3.5 w-3.5" />Fix & resubmit</button>
                </div>
              )}

              {listing.events.length > 0 && <div className="border-t border-white/5 pt-3"><p className="mb-2 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Status history</p><div className="space-y-1.5">{listing.events.slice(0, 3).map((event) => <p key={event.id} className="text-xs text-muted-foreground"><span className="font-medium text-foreground/85">{event.eventType.replace('_', ' ')}</span> · {formatDate(event.createdAt)}</p>)}</div></div>}
            </article>
          );
        })}
      </div>
    </div>
  );
}
