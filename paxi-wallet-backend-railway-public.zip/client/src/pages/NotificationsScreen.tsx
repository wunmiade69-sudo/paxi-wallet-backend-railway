import { useEffect, useState } from 'react';
import { ArrowLeft, Bell, CheckCircle2, CircleAlert, Info } from 'lucide-react';
import type { NotificationRecord, NotificationTarget } from '@/lib/phase3Models';
import { getNotifications, markNotificationRead, subscribeToNotifications } from '@/lib/phase3Local';

const ICONS: Record<NotificationRecord['type'], typeof Bell> = {
  'incoming-transaction': Bell,
  'transaction-submitted': Info,
  'transaction-confirmed': CheckCircle2,
  'transaction-failed': CircleAlert,
  'swap-completed': CheckCircle2,
  'bridge-completed': CheckCircle2,
  'security-warning': CircleAlert,
  'price-alert': Bell,
  'ecosystem-announcement': Info,
};

export default function NotificationsScreen({ onBack, onOpenTarget }: { onBack: () => void; onOpenTarget?: (target: NotificationTarget) => void }) {
  const [notifications, setNotifications] = useState(() => getNotifications().sort((a, b) => b.createdAt - a.createdAt));
  useEffect(() => subscribeToNotifications(() => setNotifications(getNotifications().sort((a, b) => b.createdAt - a.createdAt))), []);
  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-10">
      <div className="paxi-page-header sticky top-0 z-40">
        <div className="mx-auto flex max-w-md items-center gap-3 px-4 py-4 sm:px-6">
          <button type="button" onClick={onBack} className="paxi-icon-button flex items-center justify-center text-muted-foreground hover:bg-foreground/5 hover:text-foreground" aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
          <div><p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Activity</p><h1 className="mt-1 text-lg font-bold text-foreground">Notifications</h1></div>
        </div>
      </div>
      <main className="mx-auto max-w-md space-y-3 px-4 py-6 sm:px-6" aria-live="polite">
        {notifications.length === 0 ? (
          <div className="glass-card p-8 text-center space-y-3">
            <Bell className="mx-auto h-9 w-9 text-muted-foreground" aria-hidden="true" />
            <p className="font-semibold text-foreground">No notifications</p>
            <p className="text-sm text-muted-foreground">Your wallet activity and important updates will appear here.</p>
          </div>
        ) : notifications.map((notification) => {
          const Icon = ICONS[notification.type] ?? Bell;
          const handleOpen = () => {
            const readAt = Date.now();
            markNotificationRead(notification.id);
            setNotifications((current) => current.map((item) => item.id === notification.id ? { ...item, read: true, readAt: item.readAt ?? readAt } : item));
            if (notification.target && notification.target.navigation !== 'none') onOpenTarget?.(notification.target);
          };
          return (
            <button key={notification.id} type="button" aria-label={`${notification.read ? 'Read' : 'Unread'} notification: ${notification.title}`} onClick={handleOpen} className={`paxi-pressable flex min-h-[5.25rem] w-full items-start gap-3 text-left glass-card p-4 transition-all hover:bg-foreground/5 ${notification.read ? 'opacity-75' : 'border-accent/20'}`}>
              <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${notification.read ? 'bg-secondary text-muted-foreground' : 'bg-accent/15 text-accent'}`}><Icon className="h-4 w-4" aria-hidden="true" /></span>
              <div className="min-w-0"><div className="flex items-start gap-2"><p className="font-semibold text-sm text-foreground">{notification.title}</p>{!notification.read && <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" aria-label="Unread" />}</div><p className="mt-1 text-xs leading-relaxed text-muted-foreground">{notification.body}</p><p className="mt-2 text-[10px] text-muted-foreground">{new Date(notification.createdAt).toLocaleString()}{notification.target?.navigation !== 'none' ? ' · Open details' : ''}</p></div>
            </button>
          );
        })}
      </main>
    </div>
  );
}
