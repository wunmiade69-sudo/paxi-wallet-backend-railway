import { useState } from 'react';
import { ArrowLeft, Delete, ShieldCheck } from 'lucide-react';

function validatePIN(pin: string): boolean {
  return /^\d{6}$/.test(pin);
}

interface PINSetupProps {
  onPINSet: (pin: string) => void;
  onBack: () => void;
}

/** Styled to match LoginScreen's unlock UI (dot indicators, circular keypad, ambient glow,
 * auto-advance, shake-on-error) so creating a PIN and later unlocking with it feel like the
 * same product instead of two different UI generations. */
export default function PINSetup({ onPINSet, onBack }: PINSetupProps) {
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [step, setStep] = useState<'create' | 'confirm'>('create');
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [shake, setShake] = useState(false);

  const currentPin = step === 'create' ? pin : confirmPin;

  const fail = (message: string) => {
    setError(message);
    setShake(true);
    setTimeout(() => setShake(false), 420);
  };

  const finishCreateStep = (fullPin: string) => {
    if (!validatePIN(fullPin)) {
      fail('Your PIN must be exactly 6 digits.');
      setPin('');
      return;
    }
    setStep('confirm');
    setError('');
  };

  const finishConfirmStep = (fullConfirm: string) => {
    if (fullConfirm !== pin) {
      fail("Those PINs don't match. Please try again.");
      setPin('');
      setConfirmPin('');
      setStep('create');
      return;
    }
    setError('');
    setIsProcessing(true);
    setTimeout(() => onPINSet(pin), 500);
  };

  const handleKeyPress = (digit: string) => {
    if (isProcessing || currentPin.length >= 6) return;
    setError('');
    const next = currentPin + digit;
    if (step === 'create') {
      setPin(next);
      if (next.length === 6) finishCreateStep(next);
    } else {
      setConfirmPin(next);
      if (next.length === 6) finishConfirmStep(next);
    }
  };

  const handleBackspace = () => {
    if (isProcessing) return;
    if (step === 'create') setPin(pin.slice(0, -1));
    else setConfirmPin(confirmPin.slice(0, -1));
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8 relative overflow-x-hidden">
      {/* Soft ambient glow behind the badge - purely decorative, matches LoginScreen */}
      <div
        className="pointer-events-none absolute left-1/2 top-24 -translate-x-1/2 w-64 h-64 rounded-full bg-accent/20 blur-3xl"
        aria-hidden
      />

      <div className="flex items-center justify-between mb-2 relative">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <div className="w-12" />
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full relative">
        <div className="mb-5 text-center">
          <p className="text-muted-foreground text-xs font-medium uppercase tracking-wide">Step 3 of 4</p>
          <div className="flex gap-2 mt-2 justify-center">
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
          </div>
        </div>

        <div className="w-16 h-16 rounded-2xl bg-accent/10 border border-accent/25 flex items-center justify-center mb-5 shadow-lg shadow-accent/10">
          <ShieldCheck className="w-7 h-7 text-accent" strokeWidth={2.25} />
        </div>

        <h1 className="text-3xl font-bold text-foreground tracking-tight mb-1.5 text-center">
          {step === 'create' ? 'Create a PIN' : 'Confirm your PIN'}
        </h1>
        <p className="text-muted-foreground text-sm text-center mb-10 max-w-xs">
          {step === 'create'
            ? 'Choose a 6-digit PIN to unlock the app. It never leaves this device.'
            : 'Enter the same 6-digit PIN once more to confirm it.'}
        </p>

        <div className={`flex justify-center gap-3.5 mb-10 ${shake ? 'animate-shake' : ''}`}>
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className={`w-3.5 h-3.5 rounded-full transition-all duration-150 ${
                i < currentPin.length ? 'bg-accent scale-110 shadow-md shadow-accent/40' : 'bg-secondary border border-border'
              } ${error ? 'ring-2 ring-destructive/40' : ''}`}
            />
          ))}
        </div>

        {error && (
          <div className="w-full flex items-center justify-center mb-6 -mt-4">
            <p className="text-sm text-destructive font-medium">{error}</p>
          </div>
        )}

        <div className="w-full grid grid-cols-3 gap-4 max-w-[280px] mx-auto">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
            <button
              key={digit}
              onClick={() => handleKeyPress(digit.toString())}
              disabled={isProcessing}
              className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 active:bg-muted border border-border/60 text-foreground font-semibold text-xl transition-all duration-100 disabled:opacity-40"
            >
              {digit}
            </button>
          ))}
          <div />
          <button
            onClick={() => handleKeyPress('0')}
            disabled={isProcessing}
            className="aspect-square rounded-full bg-secondary/70 hover:bg-secondary active:scale-95 active:bg-muted border border-border/60 text-foreground font-semibold text-xl transition-all duration-100 disabled:opacity-40"
          >
            0
          </button>
          <button
            onClick={handleBackspace}
            disabled={isProcessing}
            className="aspect-square rounded-full hover:bg-destructive/10 active:scale-95 text-muted-foreground hover:text-destructive transition-all duration-100 disabled:opacity-40 flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {isProcessing ? (
          <p className="text-muted-foreground text-sm text-center mt-8 animate-pulse">Setting PIN…</p>
        ) : (
          <div className="flex items-center gap-1.5 mt-8 text-xs text-muted-foreground">
            <ShieldCheck className="w-3.5 h-3.5" />
            <p>Your PIN is stored only on this device and is never sent to us.</p>
          </div>
        )}
      </div>
    </div>
  );
}
