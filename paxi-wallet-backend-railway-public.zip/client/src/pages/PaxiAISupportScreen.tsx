import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ShieldAlert, Sparkles, MessageCircle, TicketPlus, Send, Loader2, Check, BookOpen, Flag } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface PaxiAISupportScreenProps {
  onBack: () => void;
  onWalletGuide: () => void;
  onReportIssue: () => void;
}

interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

const WELCOME: ChatTurn = {
  role: 'assistant',
  content: "Hi! I'm PAXI AI. Ask me anything about sending, swapping, bridging, or security — or file a support ticket below if you need a human.",
};

const MAX_HISTORY_TURNS = 30;

export default function PaxiAISupportScreen({ onBack, onWalletGuide, onReportIssue }: PaxiAISupportScreenProps) {
  const [mode, setMode] = useState<'chat' | 'ticket'>('chat');

  return (
    <div className="min-h-screen bg-background pb-10 flex flex-col">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button type="button" onClick={onBack} className="text-muted-foreground hover:text-foreground" aria-label="Back">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-accent" />
            <h1 className="text-lg font-bold text-accent">PAXI AI</h1>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto w-full px-4 py-4 flex flex-col gap-4 flex-1">
        <div className="rounded-xl border border-yellow-400/20 bg-yellow-400/5 p-3 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 text-yellow-300 shrink-0 mt-0.5" />
          <p className="text-xs text-yellow-100/80">PAXI AI will never ask for your seed phrase, private key, or PIN. Never share these with anyone.</p>
        </div>

        <div className="flex rounded-xl border border-white/10 overflow-hidden" role="tablist" aria-label="Support options">
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'chat'}
            onClick={() => setMode('chat')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors ${mode === 'chat' ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <MessageCircle className="w-3.5 h-3.5" /> Chat with PAXI AI
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'ticket'}
            onClick={() => setMode('ticket')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors ${mode === 'ticket' ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <TicketPlus className="w-3.5 h-3.5" /> File a Ticket
          </button>
        </div>

        {mode === 'chat' ? <ChatPanel /> : <TicketPanel />}

        <div className="space-y-2 pt-1">
          <button type="button" onClick={onWalletGuide} className="w-full glass-card p-4 flex items-center gap-3 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all">
            <BookOpen className="w-5 h-5 text-accent shrink-0" />
            <span>
              <span className="block text-sm font-semibold text-foreground">Help Centre</span>
              <span className="block text-xs text-muted-foreground mt-0.5">Security and wallet-use guidance</span>
            </span>
          </button>
          <button type="button" onClick={onReportIssue} className="w-full glass-card p-4 flex items-center gap-3 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all">
            <Flag className="w-5 h-5 text-accent shrink-0" />
            <span>
              <span className="block text-sm font-semibold text-foreground">Report a problem</span>
              <span className="block text-xs text-muted-foreground mt-0.5">Share details so our team can help</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatPanel() {
  const [turns, setTurns] = useState<ChatTurn[]>([WELCOME]);
  const [input, setInput] = useState('');
  const messagesRef = useRef<HTMLDivElement>(null);

  const chatMutation = trpc.support.chat.useMutation({
    onSuccess: (reply) => setTurns((prev): ChatTurn[] => [...prev, { role: 'assistant' as const, content: reply }].slice(-MAX_HISTORY_TURNS)),
    onError: () => setTurns((prev): ChatTurn[] => [...prev, { role: 'assistant' as const, content: "Sorry, I couldn't respond right now. Try filing a support ticket instead." }].slice(-MAX_HISTORY_TURNS)),
  });

  useEffect(() => {
    messagesRef.current?.scrollTo({ top: messagesRef.current.scrollHeight, behavior: 'smooth' });
  }, [turns, chatMutation.isPending]);

  const send = () => {
    const trimmed = input.trim();
    if (!trimmed || chatMutation.isPending) return;
    const next: ChatTurn[] = [...turns, { role: 'user' as const, content: trimmed }].slice(-MAX_HISTORY_TURNS);
    setTurns(next);
    setInput('');
    chatMutation.mutate({ history: next });
  };

  return (
    <div className="flex flex-col rounded-2xl border border-white/10 bg-white/[0.03] overflow-hidden" style={{ minHeight: '380px' }}>
      <div ref={messagesRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-3" aria-live="polite">
        {turns.map((turn, i) => (
          <div key={`${turn.role}-${i}`} className={`flex ${turn.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {turn.role === 'assistant' && (
              <span className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center mr-2 shrink-0 mt-1">
                <Sparkles className="w-3 h-3 text-accent" />
              </span>
            )}
            <div className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${turn.role === 'user' ? 'bg-accent text-accent-foreground' : 'bg-white/[0.06] text-foreground/90'}`}>
              {turn.content}
            </div>
          </div>
        ))}
        {chatMutation.isPending && (
          <div className="flex justify-start items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
              <Sparkles className="w-3 h-3 text-accent" />
            </span>
            <div className="flex items-center gap-1.5 rounded-2xl bg-white/[0.06] px-3.5 py-2 text-xs text-muted-foreground">
              <Loader2 className="w-3 h-3 animate-spin" /> PAXI AI is typing…
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 border-t border-white/10 p-3">
        <input
          value={input}
          maxLength={4000}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
          placeholder="Ask PAXI AI anything…"
          aria-label="Message PAXI AI"
          className="flex-1 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-foreground outline-none focus:border-accent/40 placeholder:text-muted-foreground/50"
        />
        <button
          type="button"
          onClick={send}
          disabled={chatMutation.isPending || !input.trim()}
          aria-label="Send message"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground disabled:opacity-40 active:scale-95 transition-transform"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function TicketPanel() {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const submit = trpc.support.submitTicket.useMutation();

  if (submit.isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-6 py-10 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-400/10">
          <Check className="h-6 w-6 text-emerald-300" />
        </span>
        <p className="text-sm font-bold text-foreground">Ticket #{submit.data.id} submitted</p>
        <p className="text-xs text-muted-foreground leading-relaxed">Our team has been notified and will follow up. You can close this screen.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
      <p className="text-[11px] text-muted-foreground">Do not include your seed phrase, private key, or PIN.</p>
      <input
        value={subject}
        maxLength={200}
        onChange={(e) => setSubject(e.target.value)}
        placeholder="Subject"
        aria-label="Ticket subject"
        className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2.5 text-xs text-foreground outline-none focus:border-accent/40 placeholder:text-muted-foreground/50"
      />
      <textarea
        value={message}
        maxLength={5000}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Describe your issue in detail…"
        aria-label="Ticket details"
        rows={5}
        className="resize-none rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2.5 text-xs text-foreground outline-none focus:border-accent/40 placeholder:text-muted-foreground/50"
      />
      <input
        value={email}
        type="email"
        maxLength={255}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email address (optional, for follow-up)"
        aria-label="Optional contact email"
        className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2.5 text-xs text-foreground outline-none focus:border-accent/40 placeholder:text-muted-foreground/50"
      />
      {submit.isError && (
        <p className="text-[11px] text-red-300" role="alert">Could not submit — please check the fields and try again.</p>
      )}
      <button
        type="button"
        onClick={() => submit.mutate({ subject: subject.trim(), message: message.trim(), contactEmail: email.trim() || undefined })}
        disabled={submit.isPending || subject.trim().length < 3 || message.trim().length < 10}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-accent py-3 text-xs font-bold text-accent-foreground disabled:opacity-40 active:scale-[0.98] transition-transform"
      >
        {submit.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <TicketPlus className="h-3.5 w-3.5" />}
        {submit.isPending ? 'Submitting…' : 'Submit ticket'}
      </button>
    </div>
  );
}
