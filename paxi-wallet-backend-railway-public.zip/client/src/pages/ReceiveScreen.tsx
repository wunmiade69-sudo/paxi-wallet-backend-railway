import { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { toast } from 'sonner';
import { ArrowLeft, Copy, Check, Info, AlertTriangle, Share2 } from 'lucide-react';
import { getStoredAddress, getUnlockedMnemonic, isActiveWalletPrivateKeyImport, isActiveWalletWatchOnly } from '@/lib/wallet/vault';
import { getAddressForChainType } from '@/lib/wallet/engine';
import { NETWORKS } from '@/lib/wallet/chains';
import NetworkPickerDrawer from '@/components/NetworkPickerDrawer';

interface ReceiveScreenProps {
  onBack: () => void;
}

export default function ReceiveScreen({ onBack }: ReceiveScreenProps) {
  const allNetworks = Object.values(NETWORKS);
  const [networkId, setNetworkId] = useState(allNetworks[0].id);
  const [isCopied, setIsCopied] = useState(false);

  const network = NETWORKS[networkId];
  const evmAddress = getStoredAddress() ?? '';
  const mnemonic = getUnlockedMnemonic();
  const solAddress = mnemonic ? getAddressForChainType(mnemonic, 'sol') : null;
  const btcAddress = mnemonic ? getAddressForChainType(mnemonic, 'btc') : null;

  // Every chain type this wallet supports (evm/sol/btc) can derive a real address - the only
  // reason one might be missing right now is that sol/btc need the mnemonic unlocked first.
  const displayAddress =
    network.chainType === 'evm' ? evmAddress : network.chainType === 'sol' ? solAddress : btcAddress;
  const needsUnlock = (network.chainType === 'sol' || network.chainType === 'btc') && !mnemonic;
  const isPrivateKeyOnly = (network.chainType === 'sol' || network.chainType === 'btc') && isActiveWalletPrivateKeyImport();
  const isWatchOnly = (network.chainType === 'sol' || network.chainType === 'btc') && isActiveWalletWatchOnly();

  const handleCopy = () => {
    if (!displayAddress) return;
    navigator.clipboard.writeText(displayAddress);
    setIsCopied(true);
    toast.success('Address copied!');
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleShare = async () => {
    if (!displayAddress) return;
    const text = `My ${network.label} address:\n${displayAddress}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: `${network.label} address`, text });
      } catch {
        // user cancelled the share sheet - not an error
      }
    } else {
      await navigator.clipboard.writeText(text);
      toast.success('Address copied!');
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background px-4 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto mb-6 flex max-w-md items-center justify-between sm:mb-8">
        <button type="button" onClick={onBack} className="paxi-pressable flex min-h-11 items-center gap-1 rounded-xl px-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Back
        </button>
        <h1 className="text-xl font-bold tracking-tight text-foreground">Receive</h1>
        <div className="w-14" aria-hidden="true" />
      </div>

      <div className="mx-auto w-full max-w-md space-y-6">
        <div>
          <label className="text-sm text-muted-foreground mb-2 block">Network</label>
          <NetworkPickerDrawer
            label="Choose a network"
            networks={allNetworks}
            selected={network}
            onSelect={setNetworkId}
          />
        </div>

        {displayAddress ? (
          <>
            <div className="glass-card flex flex-col items-center rounded-2xl py-8 animate-in fade-in zoom-in-95 duration-300">
              <div className="bg-white p-4 rounded-xl">
                <QRCodeSVG value={displayAddress} size={200} />
              </div>
              <p className="text-xs text-muted-foreground mt-4">Scan to receive funds on {network.label}</p>
            </div>

            <div className="rounded-xl border border-border/70 bg-secondary p-4">
              <p className="text-xs text-muted-foreground mb-2">Your Address</p>
              <div className="flex items-center gap-1">
                <p className="text-sm font-mono text-accent flex-1 break-all">{displayAddress}</p>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="paxi-icon-button flex h-11 w-11 items-center justify-center shrink-0 text-muted-foreground hover:bg-foreground/5 hover:text-foreground"
                  aria-label="Copy address"
                >
                  {isCopied ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={handleShare}
              className="paxi-pressable flex min-h-12 w-full items-center justify-center gap-2 rounded-xl border border-border bg-secondary py-3 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              <Share2 className="w-4 h-4" />
              Share Address
            </button>

            <div className="paxi-alert-info flex items-start gap-2.5 rounded-xl p-4">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
              <p className="text-sm text-foreground/80">
                {network.chainType === 'evm'
                  ? `This address works for every EVM network (Ethereum, BNB Smart Chain, Polygon, Arbitrum). Only send assets that exist on ${network.label} to it.`
                  : network.chainType === 'sol'
                    ? `This is your Solana address. Only send SOL or Solana SPL tokens (like Solana USDT/USDC) to it.`
                    : `This is your Bitcoin address (native SegWit, bc1...). Only send BTC to it.`}
              </p>
            </div>
          </>
        ) : (
          <div className="paxi-alert-warning flex items-start gap-2.5 rounded-xl p-4">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-500" aria-hidden="true" />
            <p className="text-sm text-yellow-300">
              {isPrivateKeyOnly
                ? `This account was imported from a private key, so it is EVM-only. Private keys cannot derive a ${network.label} address.`
                : isWatchOnly
                  ? `This is a watch-only account. Add or switch to a recovery-phrase wallet to activate a ${network.label} receiving address.`
                  : needsUnlock
                    ? `Unlock your recovery-phrase wallet to view your ${network.label} address.`
                    : `Could not derive an address for ${network.label}.`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
