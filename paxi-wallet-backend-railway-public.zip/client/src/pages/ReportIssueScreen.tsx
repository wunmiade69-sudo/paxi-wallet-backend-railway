import { useState } from 'react';
import { ArrowLeft, Check, Loader2, ShieldAlert, TicketPlus } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface ReportIssueScreenProps {
  onBack: () => void;
}

const SEVERITIES: Array<{ id: 'low' | 'medium' | 'high'; label: string; hint: string }> = [
  { id: 'low', label: 'Minor', hint: 'Cosmetic or small annoyance' },
  { id: 'medium', label: 'Moderate', hint: 'Something is broken but I can work around it' },
  { id: 'high', label: 'Severe', hint: "Can't use the app, or funds/safety related" },
];

export default function ReportIssueScreen({ onBack }: ReportIssueScreenProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<'low' | 'medium' | 'high'>('medium');
  const submit = trpc.support.submitTicket.useMutation();

  const canSubmit = title.trim().length > 0 && description.trim().length > 0;

  const handleSubmit = () => submit.mutate({ subject: `[${severity.toUpperCase()}] ${title.trim()}`, message: `${description.trim()}\n\nSeverity: ${severity}` });

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Report an Issue</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div className="glass-card p-4 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 text-accent mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">Your report is sent to the authenticated PAXI support queue. Never include your seed phrase, private key, or PIN.</p>
        </div>

        {submit.isSuccess ? (
          <div className="glass-card p-8 text-center space-y-3 border border-emerald-400/20">
            <Check className="w-9 h-9 mx-auto text-emerald-300" />
            <p className="font-semibold text-foreground">Ticket #{submit.data.id} submitted</p>
            <p className="text-sm text-muted-foreground">Status: {submit.data.status.replaceAll('_', ' ')}</p>
            <button type="button" onClick={onBack} className="w-full rounded-xl bg-accent py-3 text-sm font-semibold text-accent-foreground">Back to Me</button>
          </div>
        ) : <>

        <div className="space-y-1.5">
          <p className="text-xs font-medium text-muted-foreground px-1">What went wrong?</p>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Short summary, e.g. 'Swap fails on BSC'"
            className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
          />
        </div>

        <div className="space-y-1.5">
          <p className="text-xs font-medium text-muted-foreground px-1">Details</p>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            placeholder="What did you do, what happened, what did you expect instead?"
            className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50 resize-none"
          />
        </div>

        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground px-1">Severity</p>
          <div className="space-y-2">
            {SEVERITIES.map((s) => (
              <button
                key={s.id}
                onClick={() => setSeverity(s.id)}
                className={`w-full text-left glass-card p-3 flex items-center justify-between transition-all active:scale-[0.99] ${
                  severity === s.id ? 'ring-1 ring-accent' : ''
                }`}
              >
                <div>
                  <p className="text-sm font-semibold text-foreground">{s.label}</p>
                  <p className="text-xs text-muted-foreground">{s.hint}</p>
                </div>
                <span
                  className={`w-4 h-4 rounded-full border shrink-0 flex items-center justify-center ${
                    severity === s.id ? 'border-accent' : 'border-border'
                  }`}
                >
                  {severity === s.id && <span className="w-2 h-2 rounded-full bg-accent" />}
                </span>
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!canSubmit || submit.isPending}
          className="w-full bg-accent hover:bg-accent/90 disabled:opacity-40 disabled:cursor-not-allowed text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-all active:scale-[0.98]"
        >
          {submit.isPending ? <><Loader2 className="mr-2 inline h-4 w-4 animate-spin" />Submitting…</> : <><TicketPlus className="mr-2 inline h-4 w-4" />Submit support ticket</>}
        </button>
        {submit.isError && <p className="text-sm text-destructive" role="alert">The support queue is unavailable. Please try again later.</p>}
        </>}
      </div>
    </div>
  );
}
