import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/SendScreen.tsx"), "utf8");

describe("SendScreen Phase 5G fee and address boundary", () => {
  it("uses network-specific recipient guidance instead of an EVM-only placeholder", () => {
    expect(source).toContain("isEvm ? '0x...' : isSol ? 'Solana address' : isBtc ? 'Bitcoin address'");
  });

  it("shows and settles a server-owned PAXI fee before the direct transfer", () => {
    expect(source).toContain("trpcVanilla.fees.getSendQuote.mutate");
    expect(source).toContain("PAXI service fee");
    expect(source).toContain("toAddress: feeTreasury");
    expect(source).toContain("trpcVanilla.fees.recordSend.mutate");
  });

  it("does not continue when a supported fee settlement path is unavailable", () => {
    expect(source).toContain("PAXI service-fee settlement is unavailable");
    expect(source).toContain("disabled={!isSendSupported || (isEvm && !sendFeeQuote?.supported)}");
  });

  it("broadcasts supported Solana and Bitcoin sends without an EVM service-fee operation", () => {
    expect(source).toContain("sendSolanaAsset({ mnemonic, asset, toAddress: recipient, amount })");
    expect(source).toContain("sendBitcoinAsset({ mnemonic, toAddress: recipient, amountBtc: amount })");
    expect(source).toContain("if (!isEvm)");
  });

  it("recovers durable operations and resumes bounded reconciliation without rebroadcasting", () => {
    expect(source).toContain("trpcVanilla.fees.getSendOperation.query");
    expect(source).toContain("trpcVanilla.fees.reconcileSend.mutate");
    expect(source).toContain("setTimeout(() => void pollDurableOperation(), 15_000)");
    expect(source).toContain("Known transactions will not be rebroadcast");
  });
});
