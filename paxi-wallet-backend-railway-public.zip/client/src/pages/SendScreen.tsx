import { useEffect, useState } from 'react';
import { ArrowLeft, AlertTriangle, BookUser } from 'lucide-react';
import { toast } from 'sonner';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { ASSETS, NETWORKS, assetKey } from '@/lib/wallet/chains';
import { isValidAddressForChainType } from '@/lib/wallet/engine';
import { estimateEvmGasFee, fetchAssetBalanceExact, fetchEvmBalanceExact } from '@/lib/wallet/balances';
import { estimateEvmAssetTransferGasFee, sendEvmAsset, sendSolanaAsset, waitForEvmConfirmation } from '@/lib/wallet/send';
import { estimateBitcoinMaxSend, sendBitcoinAsset } from '@/lib/wallet/bitcoin';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';
import { SecurityStatusBadge, PaxiShieldPanel } from '@/components/PaxiShieldPanel';
import { describeTxError } from '@/lib/wallet/errors';
import { getStoredAddress, getUnlockedMnemonic, isActiveWalletWatchOnly, isActiveWalletPrivateKeyImport } from '@/lib/wallet/vault';
import { getAddressForChainType, walletFromMnemonic } from '@/lib/wallet/engine';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { ensureTxRecord, updateTxRecord, type TxRecord } from '@/lib/wallet/txHistory';
import { notifyForTransaction } from '@/lib/phase3Local';
import { trpcVanilla } from '@/lib/trpcVanilla';
import { validateSendBalances } from '@shared/sendFeeGuards';
import { isSendFeeSettlementSupported, sendFeeUnavailableReason } from '@shared/sendFeeSupport';
import { parseExactBaseUnits, parseExactBaseUnitsAllowZero, formatBaseUnits, InvalidDecimalAmountError } from '@shared/exactDecimal';
import { clearSendRecovery, loadLatestSendRecovery, loadSendRecovery, saveSendRecovery } from '@/lib/wallet/sendRecovery';
import AssetPickerDrawer from '@/components/AssetPickerDrawer';
import AddressBookScreen from '@/pages/AddressBookScreen';
import TransactionReceipt from '@/components/TransactionReceipt';

interface SendScreenProps {
  onBack: () => void;
}

type Step = 'form' | 'confirm' | 'sending' | 'done';

type SendFeeQuoteView = {
  supported: boolean;
  reason?: string;
  network: string;
  assetAddress: string | null;
  assetSymbol: string;
  assetDecimals: number;
  amount: string;
  amountUsd: string;
  networkFeeNative: string;
  networkFeeUsd: string;
  paxiFeeAmount: string;
  paxiFeeUsd: string;
  totalDebitUsd: string;
  totalWalletDebitUsd: string;
  recipientReceives: string;
  feeCurrency: string;
  treasury: string | null;
  quoteId: string;
  operationId: string;
  expiresAt: string;
};

function displayAmount(value: number, decimals: number): string {
  if (!Number.isFinite(value)) return 'Unavailable';
  return value.toFixed(Math.min(Math.max(decimals, 2), 8)).replace(/0+$/, '').replace(/\\.$/, '') || '0';
}

function displayExactNativeAmount(value: string): string {
  try {
    return formatBaseUnits(parseExactBaseUnitsAllowZero(value, 18), 18);
  } catch {
    return 'Unavailable';
  }
}

export default function SendScreen({ onBack }: SendScreenProps) {
  const allAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
  // Keyed by symbol+network, not bare symbol - USDT/USDC each exist on more
  // than one chain, and picking one by symbol alone would silently resolve
  // to whichever entry happens to come first in the list.
  const [selectedKey, setSelectedKey] = useState(assetKey(allAssets[0]));
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<Step>('form');
  const [error, setError] = useState('');
  const [gasEstimate, setGasEstimate] = useState<Awaited<ReturnType<typeof estimateEvmGasFee>>>(null);
  const [txResult, setTxResult] = useState<TxRecord | null>(null);
  const [showContacts, setShowContacts] = useState(false);
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [balance, setBalance] = useState<string | null>(null);
  const [balanceLoading, setBalanceLoading] = useState(false);
  const [sendFeeQuote, setSendFeeQuote] = useState<SendFeeQuoteView | null>(null);
  const [operationId, setOperationId] = useState('');
  const [sendQuoteId, setSendQuoteId] = useState('');
  const [feeTransactionHash, setFeeTransactionHash] = useState<string | null>(null);
  const [mainTransactionHash, setMainTransactionHash] = useState<string | null>(null);
  const [, setDurableOperationState] = useState<string | null>(null);

  const asset = allAssets.find((a) => assetKey(a) === selectedKey) ?? allAssets[0];
  const network = NETWORKS[asset.network];
  const fromAddress = getStoredAddress() ?? '';
  const isEvm = network.chainType === 'evm';
  const isSol = network.chainType === 'sol';
  const isBtc = network.chainType === 'btc';
  const isSendSupported = isEvm || isSol || isBtc;
  const isPaxiFeeSettlementSupported = isSendFeeSettlementSupported(asset.network);
  const isWatchOnly = isActiveWalletWatchOnly();

  useEffect(() => {
    let cancelled = false;
    setError('');
    setGasEstimate(null);
    setSendFeeQuote(null);
    setFeeTransactionHash(null);
    setMainTransactionHash(null);
    setOperationId('');
    setSendQuoteId('');
    setDurableOperationState(null);
    const recovered = recipient && amount
      ? loadSendRecovery({ network: asset.network, walletAddress: fromAddress, recipient, assetSymbol: asset.symbol, amount })
      : loadLatestSendRecovery({ network: asset.network, walletAddress: fromAddress });
    if (recovered) {
      // Reconstruct the form from the local pointer only; the durable server
      // record is fetched below and remains authoritative for all hashes/state.
      if (!recipient) setRecipient(recovered.recipient);
      if (!amount) setAmount(recovered.amount);
      if (!recipient || !amount) {
        const recoveredAsset = allAssets.find((candidate) => candidate.network === recovered.network
          && (recovered.assetAddress
            ? candidate.contractAddress?.toLowerCase() === recovered.assetAddress.toLowerCase()
            : candidate.isNative));
        if (recoveredAsset) setSelectedKey(assetKey(recoveredAsset));
      }
      setOperationId(recovered.operationId);
      setSendQuoteId(recovered.quoteId);
      setFeeTransactionHash(recovered.feeTransactionHash);
      setMainTransactionHash(recovered.transactionHash);
      setError('A previous SEND attempt was found. Status will be checked without rebroadcasting known transactions.');
      let pollTimer: ReturnType<typeof setTimeout> | undefined;
      const terminalStates = new Set(['CONFIRMED', 'FAILED']);
      const pollDurableOperation = async (): Promise<void> => {
        if (cancelled) return;
        try {
          const operation = await trpcVanilla.fees.getSendOperation.query({ operationId: recovered.operationId });
          if (!operation || cancelled) return;
          setDurableOperationState(operation.state);
          if (operation.feeTransactionHash) setFeeTransactionHash(operation.feeTransactionHash);
          const recoveredAsset = allAssets.find((candidate) => candidate.network === operation.network
            && (operation.contractAddress
              ? candidate.contractAddress?.toLowerCase() === operation.contractAddress.toLowerCase()
              : candidate.isNative));
          const historyAsset = recoveredAsset ?? asset;
          if (operation.sendTransactionHash) {
            setMainTransactionHash(operation.sendTransactionHash);
            const history = ensureTxRecord({
              type: 'send',
              networkId: operation.network,
              hash: operation.sendTransactionHash,
              explorerUrl: network.explorerTx?.(operation.sendTransactionHash),
              fromSymbol: historyAsset.symbol,
              fromAmount: operation.transferAmount,
              counterparty: operation.recipientAddress,
              feeAmount: operation.paxiServiceFee,
              feeSymbol: operation.assetIdentity,
              status: operation.state === 'CONFIRMED' ? 'confirmed' : operation.state === 'FAILED' ? 'failed' : 'pending',
            });
            if (operation.state === 'CONFIRMED' || operation.state === 'FAILED') {
              setTxResult({ ...history, status: operation.state === 'CONFIRMED' ? 'confirmed' : 'failed' });
            }
          }
          if (terminalStates.has(operation.state)) {
            setStep(operation.state === 'CONFIRMED' ? 'done' : 'confirm');
            if (operation.state === 'FAILED') setError('The durable SEND operation failed. Review the transaction and try again.');
            return;
          }
          if (operation.state === 'QUOTED') {
            setStep('confirm');
            setError(`Recovered durable SEND operation ${operation.operationId}; review the quote before broadcasting.`);
            return;
          }
          // Reconciliation is safe because it only receives already-known hashes;
          // it never constructs or broadcasts a replacement transaction.
          if (operation.feeTransactionHash || operation.sendTransactionHash) {
            await trpcVanilla.fees.reconcileSend.mutate({
              network: operation.network as 'ethereum' | 'bsc',
              walletAddress: operation.linkedWalletAddress,
              recipient: operation.recipientAddress,
              assetAddress: operation.contractAddress,
              assetSymbol: historyAsset.symbol,
              assetDecimals: historyAsset.decimals,
              amount: operation.transferAmount,
              networkFeeNative: operation.networkFee,
              quoteId: operation.quoteId,
              operationId: operation.operationId,
              feeTransactionHash: operation.feeTransactionHash,
              transactionHash: operation.sendTransactionHash,
            });
          }
          setStep('sending');
          setError(`Recovered durable SEND operation ${operation.operationId} in ${operation.state} state. Known transactions will not be rebroadcast.`);
          pollTimer = setTimeout(() => void pollDurableOperation(), 15_000);
        } catch {
          if (!cancelled) {
            setError('A previous SEND attempt was found. Durable status is temporarily unavailable; known transactions will not be rebroadcast.');
            pollTimer = setTimeout(() => void pollDurableOperation(), 15_000);
          }
        }
      };
      void pollDurableOperation();
      return () => {
        cancelled = true;
        if (pollTimer) clearTimeout(pollTimer);
      };
    }
    return () => { cancelled = true; };
  }, [selectedKey, recipient, amount]);

  useEffect(() => {
    if (!fromAddress) return;
    let cancelled = false;
    setBalance(null);
    setBalanceLoading(true);
    const mnemonic = getUnlockedMnemonic();
    const solAddress = mnemonic ? (getAddressForChainType(mnemonic, 'sol') ?? undefined) : undefined;
    const btcAddress = mnemonic ? (getAddressForChainType(mnemonic, 'btc') ?? undefined) : undefined;
    fetchAssetBalanceExact(asset, fromAddress, solAddress, btcAddress)
      .then((b) => {
        if (!cancelled) setBalance(b);
      })
      .finally(() => {
        if (!cancelled) setBalanceLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedKey]);

  const handleMax = async () => {
    if (balance == null) return;
    if (!asset.isNative) {
      setAmount(balance);
      return;
    }
    setError('');
    try {
      if (isBtc) {
        const mnemonic = getUnlockedMnemonic();
        const btcAddress = mnemonic ? getAddressForChainType(mnemonic, 'btc') : undefined;
        if (!btcAddress) throw new Error('Unlock your wallet to derive a Bitcoin address.');
        const estimate = await estimateBitcoinMaxSend(btcAddress);
        setAmount(estimate.amountBtc);
        return;
      }

      // Account-based native assets need a network-fee reserve, or Review would
      // fail immediately after selecting the apparent full balance. The 20%
      // headroom is computed as exact bigint base-unit arithmetic on the
      // fee estimate; the only Number() conversion happens at the very end,
      // to produce the suggested value for the amount input - it is not an
      // authorization decision. The real balance/fee check further down in
      // handleReview re-derives everything exactly via validateSendBalances.
      let reserveUnits = parseExactBaseUnitsAllowZero('0.00001', asset.decimals); // conservative Solana fallback
      if (isEvm && network.rpcUrl) {
        const estimate = await estimateEvmGasFee(asset.network, fromAddress, recipient || fromAddress, '0');
        if (estimate) {
          const feeUnits = parseExactBaseUnitsAllowZero(estimate.estimatedFeeNative, asset.decimals);
          reserveUnits = (feeUnits * 6n) / 5n; // 20% headroom over the estimate, exact
        }
      }
      const balanceUnits = parseExactBaseUnitsAllowZero(balance, asset.decimals);
      const suggestedUnits = balanceUnits > reserveUnits ? balanceUnits - reserveUnits : 0n;
      setAmount(formatBaseUnits(suggestedUnits, asset.decimals));
    } catch (err) {
      setError(describeTxError(err));
    }
  };

  const handleReview = async () => {
    setError('');
    if (!isSendSupported) {
      setError(`${asset.symbol} sending is coming soon. Please choose another supported asset.`);
      return;
    }
    if (!recipient || !isValidAddressForChainType(recipient, network.chainType)) {
      setError('Enter a valid recipient address for this network.');
      return;
    }
    // Parse exactly BEFORE any comparison or conversion - this rejects
    // malformed, negative, scientific-notation, and over-precise input the
    // same way it would be rejected further down the pipeline, rather than
    // silently letting a bad string reach a Number() cast first.
    let amountUnits: bigint;
    try {
      amountUnits = parseExactBaseUnits(amount, asset.decimals);
    } catch (err) {
      setError(err instanceof InvalidDecimalAmountError ? 'Enter a valid amount greater than 0.' : 'Enter an amount greater than 0.');
      return;
    }
    if (balance != null && amountUnits > parseExactBaseUnitsAllowZero(balance, asset.decimals)) {
      setError(`You only have ${balance} ${asset.symbol} available.`);
      return;
    }
    if (isEvm && !isPaxiFeeSettlementSupported) {
      setSendFeeQuote({
        supported: false,
        reason: sendFeeUnavailableReason(asset.network),
        network: asset.network,
        assetAddress: asset.contractAddress ?? null,
        assetSymbol: asset.symbol,
        assetDecimals: asset.decimals,
        amount, amountUsd: '0', networkFeeNative: '0', networkFeeUsd: '0',
        paxiFeeAmount: '0', paxiFeeUsd: '0', totalDebitUsd: '0', totalWalletDebitUsd: '0',
        recipientReceives: amount, feeCurrency: asset.symbol, treasury: null,
        quoteId: '', operationId: '', expiresAt: '',
      });
      setGasEstimate(null);
      setStep('confirm');
      return;
    }

    if (!network.rpcUrl) {
      setError(`${network.label} is not available right now. Please try again later or choose another network.`);
      return;
    }

    if (!isEvm) {
      setSendFeeQuote({
        supported: false,
        reason: sendFeeUnavailableReason(asset.network),
        network: asset.network,
        assetAddress: asset.contractAddress ?? null,
        assetSymbol: asset.symbol,
        assetDecimals: asset.decimals,
        amount,
        amountUsd: '0',
        networkFeeNative: '0',
        networkFeeUsd: '0',
        paxiFeeAmount: '0',
        paxiFeeUsd: '0',
        totalDebitUsd: '0',
        totalWalletDebitUsd: '0',
        recipientReceives: amount,
        feeCurrency: asset.symbol,
        treasury: null,
        quoteId: '',
        operationId: '',
        expiresAt: '',
      });
      setGasEstimate(null);
      setStep('confirm');
      return;
    }

    try {
      // Establish cryptographic wallet ownership before the server issues a
      // fee quote. This is an off-chain signature only: no transaction or gas.
      const mnemonic = getUnlockedMnemonic();
      if (!mnemonic) throw new Error('Session locked. Please unlock your wallet again.');
      const challenge = await trpcVanilla.walletLink.challenge.mutate({ walletAddress: fromAddress });
      const signer = walletFromMnemonic(mnemonic);
      const signature = await signer.signMessage(challenge.message);
      await trpcVanilla.walletLink.verify.mutate({
        walletAddress: fromAddress,
        message: challenge.message,
        signature,
      });

      const mainEstimate = await estimateEvmGasFee(asset.network, fromAddress, recipient, asset.isNative ? amount : '0');
      if (!mainEstimate) throw new Error('Could not estimate the network fee. Try again shortly.');
      const initialQuote = await trpcVanilla.fees.getSendQuote.mutate({
        network: asset.network as 'ethereum' | 'bsc',
        walletAddress: fromAddress,
        recipient,
        assetAddress: asset.contractAddress ?? null,
        assetSymbol: asset.symbol,
        assetDecimals: asset.decimals,
        amount,
        networkFeeNative: mainEstimate.estimatedFeeNative,
      });
      if (!initialQuote.supported || (initialQuote.paxiFeeAmount !== '0' && !initialQuote.treasury)) {
        throw new Error(initialQuote.reason ?? 'PAXI service-fee settlement is unavailable on this network.');
      }

      // Native-fee amounts are always 18-decimal EVM native units here
      // (this branch only runs for isEvm). Accumulate as exact bigint wei,
      // never as a floating-point sum of decimal strings.
      let totalNetworkFeeUnits = parseExactBaseUnitsAllowZero(mainEstimate.estimatedFeeNative, 18);
      if (initialQuote.paxiFeeAmount !== '0') {
        const feeTreasury = initialQuote.treasury;
        if (!feeTreasury) throw new Error('PAXI treasury is unavailable for this fee.');
        const feeEstimate = await estimateEvmAssetTransferGasFee({
          network: asset.network,
          fromAddress,
          asset,
          toAddress: feeTreasury,
          amount: initialQuote.paxiFeeAmount,
        });
        if (!feeEstimate) throw new Error('Could not estimate the PAXI service-fee transaction. Try again shortly.');
        totalNetworkFeeUnits += parseExactBaseUnitsAllowZero(feeEstimate.estimatedFeeNative, 18);
      }
      const totalNetworkFeeNative = formatBaseUnits(totalNetworkFeeUnits, 18);

      const quote = await trpcVanilla.fees.getSendQuote.mutate({
        network: asset.network as 'ethereum' | 'bsc',
        walletAddress: fromAddress,
        recipient,
        assetAddress: asset.contractAddress ?? null,
        assetSymbol: asset.symbol,
        assetDecimals: asset.decimals,
        amount,
        networkFeeNative: totalNetworkFeeNative,
      });
      if (!quote.supported || (quote.paxiFeeAmount !== '0' && !quote.treasury)) throw new Error(quote.reason ?? 'PAXI service-fee settlement is unavailable on this network.');

      const currentAssetBalance = await fetchEvmBalanceExact(asset, fromAddress);
      if (currentAssetBalance == null) throw new Error(`Unable to verify your ${asset.symbol} balance.`);
      const nativeAsset = ASSETS.find((candidate) => candidate.network === asset.network && candidate.isNative);
      if (!nativeAsset) throw new Error('Native asset configuration is unavailable for this network.');
      const nativeBalance = await fetchEvmBalanceExact(nativeAsset, fromAddress);
      if (nativeBalance == null) throw new Error(`Unable to verify your ${network.nativeSymbol} balance.`);
      validateSendBalances({
        assetBalanceUnits: BigInt(currentAssetBalance),
        amountUnits,
        serviceFeeUnits: parseExactBaseUnitsAllowZero(quote.paxiFeeAmount, asset.decimals),
        nativeBalanceUnits: BigInt(nativeBalance),
        networkFeeNativeUnits: totalNetworkFeeUnits,
        isNativeAsset: asset.isNative,
      });

      setOperationId(quote.operationId);
      setSendQuoteId(quote.quoteId);
      setSendFeeQuote(quote);
      // Persist the durable operation pointer before broadcasting anything.
      // This makes reload during quote/fee-pending recoverable without ever
      // authorizing a second broadcast from client-only state.
      saveSendRecovery({
        operationId: quote.operationId,
        quoteId: quote.quoteId,
        network: asset.network,
        walletAddress: fromAddress,
        recipient,
        assetAddress: asset.contractAddress ?? null,
        assetSymbol: asset.symbol,
        amount,
        feeTransactionHash: null,
        transactionHash: null,
      });
      setGasEstimate({ ...mainEstimate, estimatedFeeNative: totalNetworkFeeNative });
      setStep('confirm');
    } catch (err) {
      setError(describeTxError(err));
    }
  };

  const handleConfirmSend = async () => {
    const mnemonic = getUnlockedMnemonic();
    if (!mnemonic) {
      setError('Session locked. Please unlock your wallet again.');
      setStep('form');
      return;
    }
      if (!isEvm || !sendFeeQuote?.supported || !operationId || (sendFeeQuote.paxiFeeAmount !== '0' && !sendFeeQuote.treasury)) {
      setError(sendFeeQuote?.reason ?? 'PAXI service-fee settlement is unavailable for this SEND.');
      return;
    }
    setStep('sending');
    setError('');
    try {
      let feeHash = feeTransactionHash;
      if (sendFeeQuote.paxiFeeAmount !== '0') {
        if (!feeHash) {
          const feeTreasury = sendFeeQuote.treasury;
          if (!feeTreasury) throw new Error('PAXI treasury is unavailable for this fee.');
          const feeResult = await sendEvmAsset({
            mnemonic,
            asset,
            toAddress: feeTreasury,
            amount: sendFeeQuote.paxiFeeAmount,
          });
          feeHash = feeResult.hash;
          setFeeTransactionHash(feeHash);
          saveSendRecovery({ operationId, quoteId: sendQuoteId, network: asset.network, walletAddress: fromAddress, recipient, assetAddress: asset.contractAddress ?? null, assetSymbol: asset.symbol, amount, feeTransactionHash: feeHash, transactionHash: mainTransactionHash });
        }
        try {
          await waitForEvmConfirmation({ network: asset.network, hash: feeHash });
        } catch (err) {
          if (/failed on-chain/i.test(err instanceof Error ? err.message : '')) setFeeTransactionHash(null);
          throw err;
        }
      }

      let mainHash = mainTransactionHash;
      let explorerUrl: string | undefined;
      if (!mainHash) {
        const mainResult = await sendEvmAsset({ mnemonic, asset, toAddress: recipient, amount });
        mainHash = mainResult.hash;
        explorerUrl = mainResult.explorerUrl;
        setMainTransactionHash(mainHash);
        saveSendRecovery({ operationId, quoteId: sendQuoteId, network: asset.network, walletAddress: fromAddress, recipient, assetAddress: asset.contractAddress ?? null, assetSymbol: asset.symbol, amount, feeTransactionHash: feeHash, transactionHash: mainHash });
      }
      const localRecord = ensureTxRecord({
        type: 'send',
        networkId: asset.network,
        hash: mainHash,
        explorerUrl: explorerUrl ?? network.explorerTx?.(mainHash),
        fromSymbol: asset.symbol,
        fromAmount: amount,
        counterparty: recipient,
        feeAmount: sendFeeQuote.paxiFeeAmount,
        feeSymbol: sendFeeQuote.feeCurrency,
        status: 'pending',
      });
      await waitForEvmConfirmation({ network: asset.network, hash: mainHash });
      await trpcVanilla.fees.recordSend.mutate({
        network: asset.network as 'ethereum' | 'bsc',
        walletAddress: fromAddress,
        recipient,
        assetAddress: asset.contractAddress ?? null,
        assetSymbol: asset.symbol,
        assetDecimals: asset.decimals,
        amount,
        networkFeeNative: sendFeeQuote.networkFeeNative,
        quoteId: sendQuoteId,
        operationId,
        feeTransactionHash: feeHash,
        transactionHash: mainHash,
      });

      updateTxRecord(mainHash, { status: 'confirmed', feeAmount: sendFeeQuote.paxiFeeAmount, feeSymbol: sendFeeQuote.feeCurrency }, false);
      clearSendRecovery();
      setStep('done');
      toast.success('Transaction confirmed');
      setTxResult({ ...localRecord, status: 'confirmed' });
      notifyForTransaction({
        hash: mainHash,
        networkId: asset.network,
        type: 'send',
        status: 'confirmed',
        symbol: asset.symbol,
        amount,
        source: 'local-wallet',
      });
    } catch (err) {
      setError(describeTxError(err));
      setStep('confirm');
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background px-4 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto mb-6 flex max-w-md items-center justify-between sm:mb-8">
        <button type="button" onClick={onBack} className="paxi-pressable flex min-h-11 items-center gap-1 rounded-xl px-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Back
        </button>
        <h1 className="text-xl font-bold tracking-tight text-foreground">Send</h1>
        <div className="w-14" aria-hidden="true" />
      </div>

      <div className="mx-auto w-full max-w-md">
        {step === 'form' && (
          <div className="space-y-4">
            {isWatchOnly && (
              <div className="paxi-alert-warning flex items-start gap-2.5 rounded-xl p-4">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-500" aria-hidden="true" />
                <p className="text-sm text-yellow-400">
                  This is a watch-only wallet - there are no keys stored on this device to sign with. Switch to a
                  wallet you hold the keys for to send.
                </p>
              </div>
            )}
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Asset</label>
              <AssetPickerDrawer
                label="Choose asset to send"
                assets={allAssets}
                selected={asset}
                showNetwork
                onSelect={(a) => setSelectedKey(assetKey(a))}
              />
              {!isSendSupported && (
                <p className="flex items-start gap-1.5 text-xs text-yellow-400 mt-2">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>
                    {asset.symbol} sending isn't wired up yet (needs a {network.chainType.toUpperCase()}{' '}
                    signing library). UI is ready; broadcasting isn't.
                  </span>
                </p>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm text-muted-foreground">Recipient Address</label>
                <button
                  type="button"
                  onClick={() => setShowContacts(true)}
                  className="paxi-pressable flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs font-medium text-accent transition-colors hover:bg-accent/10 hover:text-accent/80"
                >
                  <BookUser className="w-3.5 h-3.5" />
                  Contacts
                </button>
              </div>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder={isEvm ? '0x...' : isSol ? 'Solana address' : isBtc ? 'Bitcoin address' : 'Recipient address'}
                aria-label="Recipient address"
                className="paxi-field w-full p-3 text-foreground placeholder:text-muted-foreground font-mono text-sm"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm text-muted-foreground">Amount</label>
                <p className="text-xs text-muted-foreground">
                  {balanceLoading ? 'Loading balance…' : balance != null ? `Balance: ${balance} ${asset.symbol}` : ''}
                </p>
              </div>
              <div className="relative">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  aria-label={`Amount in ${asset.symbol}`}
                  inputMode="decimal"
                  className="paxi-field w-full p-3 pr-28 text-foreground placeholder:text-muted-foreground"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                  {balance != null && parseExactBaseUnitsAllowZero(balance, asset.decimals) > 0n && (
                    <button
                      type="button"
                      onClick={handleMax}
                      className="paxi-pressable min-h-9 rounded-full bg-accent/10 px-3 py-1 text-[11px] font-bold text-accent transition-colors hover:bg-accent/20"
                    >
                      MAX
                    </button>
                  )}
                  <span className="text-muted-foreground text-sm">{asset.symbol}</span>
                </div>
              </div>
            </div>

            {error && (
              <div className="paxi-alert-error rounded-xl p-3" role="alert">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <button
              onClick={handleReview}
              disabled={isWatchOnly || (isEvm && !isPaxiFeeSettlementSupported)}
              className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-3 rounded-lg transition-colors"
            >
              Review Transaction
            </button>
          </div>
        )}

        {step === 'sending' && (
          <div className="text-center py-16">
            <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-accent border-t-transparent" role="status" aria-label="Broadcasting transaction" />
            <p className="text-muted-foreground">Broadcasting transaction...</p>
          </div>
        )}

        {step === 'done' && txResult && (
          <TransactionReceipt record={txResult} onClose={onBack} />
        )}
      </div>

      <Drawer open={showContacts} onOpenChange={setShowContacts}>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader className="text-left">
            <DrawerTitle>Pick a contact</DrawerTitle>
          </DrawerHeader>
          <div className="overflow-y-auto">
            <AddressBookScreen
              embedded
              onBack={() => setShowContacts(false)}
              onPick={(address, savedNetwork) => {
                if (savedNetwork !== asset.network) {
                  toast.error(`This contact is saved for ${NETWORKS[savedNetwork]?.label ?? savedNetwork}, not ${network.label}.`);
                  return;
                }
                setRecipient(address);
                setShowContacts(false);
              }}
            />
          </div>
        </DrawerContent>
      </Drawer>

      <Drawer open={step === 'confirm'} onOpenChange={(open) => !open && setStep('form')}>
        <DrawerContent className="max-h-[92vh]">
          <DrawerHeader className="text-left pb-2">
            <div className="flex items-center justify-between">
              <DrawerTitle>Review Transaction</DrawerTitle>
              <SecurityStatusBadge network={asset.network} contractAddress={asset.contractAddress} isNative={asset.isNative} />
            </div>
          </DrawerHeader>

          <div className="overflow-y-auto px-4 pb-6 space-y-4">
            <div className="glass-card p-4">
              <p className="text-xs text-muted-foreground">You Send</p>
              <p className="text-xl font-bold text-foreground">
                {amount} {asset.symbol}
              </p>
            </div>

            <div className="glass-card p-4 space-y-2.5 text-sm">
              <div className="flex justify-between gap-4">
                <span className="text-muted-foreground">Recipient</span>
                <span className="text-foreground font-mono text-xs text-right max-w-[60%] break-all">{recipient}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Network</span>
                <span className="text-foreground">{network.label}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-border">
                <span className="text-muted-foreground">Network fee</span>
                <span className="text-foreground">
                  {gasEstimate ? `${displayExactNativeAmount(gasEstimate.estimatedFeeNative)} ${network.nativeSymbol}` : 'Unavailable'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">PAXI service fee</span>
                <span className="text-foreground">
                  {sendFeeQuote?.supported ? `${sendFeeQuote.paxiFeeAmount} ${sendFeeQuote.feeCurrency}` : 'Unavailable on this network'}
                </span>
              </div>
              {sendFeeQuote?.supported && (
                <>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total wallet debit</span>
                    <span className="text-foreground">{sendFeeQuote.totalWalletDebitUsd} USD equivalent</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Recipient receives</span>
                    <span className="text-foreground">{sendFeeQuote.recipientReceives} {asset.symbol}</span>
                  </div>
                  <p className="pt-2 text-xs text-muted-foreground">
                    The service fee is a separate, user-approved transfer to the PAXI treasury before your transfer. Your recipient receives the full amount shown above.
                  </p>
                </>
              )}
            </div>

            {sendFeeQuote && !sendFeeQuote.supported && (
              <div className="paxi-alert-warning rounded-xl p-3" role="alert">
                <p className="text-sm text-yellow-300">{sendFeeQuote.reason ?? 'PAXI service-fee settlement is unavailable on this network.'}</p>
              </div>
            )}

            <PaxiShieldPanel network={asset.network} contractAddress={asset.contractAddress} isNative={asset.isNative} />

            <div className="paxi-alert-warning flex items-start gap-2.5 rounded-xl p-3">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-500" aria-hidden="true" />
              <p className="text-xs text-yellow-300">
                This sends a real on-chain transaction. Double-check the address - it can't be reversed.
              </p>
            </div>

            {error && (
              <div className="paxi-alert-error rounded-xl p-3" role="alert">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep('form')}
                className="paxi-pressable min-h-12 flex-1 rounded-xl border border-border bg-secondary py-3 font-semibold text-foreground transition-colors hover:bg-muted"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setShowAuthGate(true)}
                disabled={!sendFeeQuote?.supported}
                className="paxi-pressable min-h-12 flex-1 rounded-xl bg-accent py-3 font-semibold text-accent-foreground transition-colors hover:bg-accent/90 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground"
              >
                Continue
              </button>
            </div>
          </div>
        </DrawerContent>
      </Drawer>

      <TransactionAuthSheet
        open={showAuthGate}
        actionLabel={`Send ${amount} ${asset.symbol}`}
        onSuccess={() => {
          setShowAuthGate(false);
          handleConfirmSend();
        }}
        onCancel={() => setShowAuthGate(false)}
      />
    </div>
  );
}
