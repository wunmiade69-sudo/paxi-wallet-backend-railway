import { useState } from "react";
import {
  LogOut,
  ChevronRight,
  ArrowLeft,
  ShieldCheck,
  Upload,
  Moon,
  Fingerprint,
  Globe,
  Coins,
  Trash2,
  Flag,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "@/contexts/ThemeContext";
import {
  disableBiometricUnlock,
  enableBiometricForCurrentSession,
  isBiometricEnabledOnVault,
  unlockWithPIN,
  wipeVault,
} from "@/lib/wallet/vault";
import { useI18n, LANGUAGES, type LangCode } from "@/lib/i18n";
import { safeGetLocalStorage, safeSetLocalStorage } from "@/lib/safeStorage";
import {
  FIAT_CURRENCIES,
  getStoredFiatCurrency,
  type FiatCurrency,
} from "@/lib/wallet/fiat";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";

interface SettingsScreenProps {
  onBack: () => void;
  onLogout: () => void;
  onBackupWallet: () => void;
  onExportWallet: () => void;
  onReportIssue: () => void;
}

function Row({
  icon: Icon,
  label,
  value,
  onClick,
  disabled,
}: {
  icon: typeof Moon;
  label: string;
  value?: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-foreground/5 active:scale-[0.99] transition-all text-left disabled:opacity-50 disabled:active:scale-100"
    >
      <span className="flex items-center gap-3">
        <span className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
          <Icon className="w-4 h-4 text-accent" />
        </span>
        <span className="text-sm text-foreground font-medium">{label}</span>
      </span>
      {value !== undefined ? (
        typeof value === "string" ? (
          <span className="text-xs text-muted-foreground">{value}</span>
        ) : (
          value
        )
      ) : (
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      )}
    </button>
  );
}

export default function SettingsScreen({
  onBack,
  onLogout,
  onBackupWallet,
  onExportWallet,
  onReportIssue,
}: SettingsScreenProps) {
  const { theme, toggleTheme, switchable } = useTheme();
  const { lang, setLang, t } = useI18n();
  const [currency, setCurrency] = useState<FiatCurrency>(() =>
    getStoredFiatCurrency()
  );
  const [biometricOn, setBiometricOn] = useState(isBiometricEnabledOnVault());
  const [showLanguagePicker, setShowLanguagePicker] = useState(false);

  const [showWipeConfirm, setShowWipeConfirm] = useState(false);
  const [wipePin, setWipePin] = useState("");
  const [wipeError, setWipeError] = useState("");
  const [wiping, setWiping] = useState(false);

  const handleCurrencyChange = () => {
    const idx = FIAT_CURRENCIES.indexOf(currency);
    const next = FIAT_CURRENCIES[(idx + 1) % FIAT_CURRENCIES.length];
    setCurrency(next);
    safeSetLocalStorage("paxi-currency", next);
    window.dispatchEvent(
      new CustomEvent("paxi-currency-change", { detail: next })
    );
  };

  const handleSelectLanguage = (code: LangCode) => {
    setLang(code);
    setShowLanguagePicker(false);
    toast.success(`${LANGUAGES.find(l => l.code === code)?.label} selected`);
  };

  const handleToggleBiometric = async () => {
    if (biometricOn) {
      disableBiometricUnlock();
      setBiometricOn(false);
      toast.success("Biometric unlock disabled");
      return;
    }
    try {
      await enableBiometricForCurrentSession();
      setBiometricOn(true);
      toast.success("Biometric unlock enabled");
    } catch (err) {
      toast.error(
        err instanceof Error
          ? err.message
          : "Could not enable biometric unlock on this device."
      );
    }
  };

  const handleWipe = async () => {
    setWipeError("");
    setWiping(true);
    try {
      await unlockWithPIN(wipePin); // throws on a wrong PIN - the last check before an irreversible action
      await wipeVault();
      window.location.reload();
    } catch {
      setWipeError("Incorrect PIN.");
      setWiping(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-lg font-semibold text-foreground">
          {t("settings_title")}
        </h1>
        <div className="w-12" />
      </div>

      <div className="max-w-md mx-auto w-full space-y-6">
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">
            {t("settings_wallet")}
          </h4>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            <Row
              icon={ShieldCheck}
              label={t("settings_backup")}
              onClick={onBackupWallet}
            />
            <Row
              icon={Upload}
              label={t("settings_export")}
              onClick={onExportWallet}
            />
          </div>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">
            {t("settings_preferences")}
          </h4>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            <Row
              icon={Moon}
              label={t("settings_dark_mode")}
              value={theme === "dark" ? "On" : "Off"}
              onClick={switchable ? toggleTheme : undefined}
              disabled={!switchable}
            />
            <Row
              icon={Fingerprint}
              label={t("settings_biometric")}
              value={biometricOn ? "On" : "Off"}
              onClick={handleToggleBiometric}
            />
            <Row
              icon={Globe}
              label={t("settings_language")}
              value={LANGUAGES.find(l => l.code === lang)?.label}
              onClick={() => setShowLanguagePicker(v => !v)}
            />
            <Row
              icon={Coins}
              label={t("settings_currency")}
              value={currency}
              onClick={handleCurrencyChange}
            />
          </div>
          {showLanguagePicker && (
            <div className="mt-2 glass-card !p-0 overflow-hidden divide-y divide-white/5 animate-in fade-in slide-in-from-top-1 duration-200">
              {LANGUAGES.map(l => (
                <button
                  key={l.code}
                  onClick={() => handleSelectLanguage(l.code)}
                  className={`w-full flex items-center justify-between px-4 py-2.5 text-sm transition-colors ${
                    l.code === lang
                      ? "text-accent font-semibold bg-accent/5"
                      : "text-foreground/80 hover:bg-foreground/5"
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="glass-card !p-0 overflow-hidden">
          <Row
            icon={Flag}
            label={t("settings_report_issue")}
            onClick={onReportIssue}
          />
        </div>

        <div className="space-y-2">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center px-4 py-3 bg-destructive/10 hover:bg-destructive/15 border border-destructive/30 rounded-lg text-sm text-destructive transition-all active:scale-[0.99] font-semibold"
          >
            <LogOut className="w-4 h-4 mr-2" />
            {t("settings_lock")}
          </button>
          <button
            onClick={() => {
              setWipePin("");
              setWipeError("");
              setShowWipeConfirm(true);
            }}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-secondary hover:bg-destructive/10 border border-border hover:border-destructive/40 rounded-lg text-sm text-muted-foreground hover:text-destructive transition-all active:scale-[0.99]"
          >
            <Trash2 className="w-4 h-4" />
            {t("settings_remove")}
          </button>
        </div>
      </div>

      <Drawer
        open={showWipeConfirm}
        onOpenChange={v => !wiping && setShowWipeConfirm(v)}
      >
        <DrawerContent>
          <DrawerHeader className="text-left">
            <DrawerTitle>Remove wallet from this device?</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6 space-y-4 max-w-md mx-auto w-full">
            <div className="flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-3.5">
              <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-sm text-destructive">
                This erases every wallet on this device. Make sure you've backed
                up your recovery phrase(s) first - this can't be undone.
              </p>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground px-0.5">
                Enter your PIN to confirm
              </label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={wipePin}
                onChange={e => {
                  setWipePin(e.target.value.replace(/\D/g, ""));
                  setWipeError("");
                }}
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground text-center tracking-[0.5em] text-xl"
                placeholder="••••••"
              />
              {wipeError && (
                <p className="text-xs text-destructive px-0.5">{wipeError}</p>
              )}
            </div>
            <button
              onClick={handleWipe}
              disabled={wipePin.length !== 6 || wiping}
              className="w-full bg-destructive hover:bg-destructive/90 disabled:opacity-40 text-white font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              {wiping ? "Removing…" : "Erase This Device"}
            </button>
            <button
              onClick={() => setShowWipeConfirm(false)}
              disabled={wiping}
              className="w-full text-muted-foreground text-sm py-1"
            >
              Cancel
            </button>
          </div>
        </DrawerContent>
      </Drawer>
    </div>
  );
}
