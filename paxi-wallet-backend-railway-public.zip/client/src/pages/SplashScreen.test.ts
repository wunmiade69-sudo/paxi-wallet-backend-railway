import { describe, expect, it } from 'vitest';
import { SPLASH_DURATION_MS, SPLASH_EXIT_DURATION_MS } from './SplashScreen';

describe('PAXI opening splash timing', () => {
  it('keeps the opening state brief while allowing a short fade into the welcome screen', () => {
    expect(SPLASH_DURATION_MS).toBe(1800);
    expect(SPLASH_EXIT_DURATION_MS).toBe(220);
    expect(SPLASH_DURATION_MS + SPLASH_EXIT_DURATION_MS).toBeLessThan(2500);
  });
});
