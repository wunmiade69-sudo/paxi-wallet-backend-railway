import { useEffect, useState } from 'react';
import PaxiLogo from '@/components/PaxiLogo';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SPLASH_DURATION_MS = 1800;
export const SPLASH_EXIT_DURATION_MS = 220;

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    let completeTimer: number | undefined;
    const splashTimer = window.setTimeout(() => {
      setIsExiting(true);
      completeTimer = window.setTimeout(onComplete, SPLASH_EXIT_DURATION_MS);
    }, SPLASH_DURATION_MS);

    return () => {
      window.clearTimeout(splashTimer);
      if (completeTimer !== undefined) window.clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return (
    <div className={`fixed inset-0 z-50 overflow-hidden bg-[#09090b] text-foreground transition-opacity duration-200 ease-out ${isExiting ? 'pointer-events-none opacity-0' : 'opacity-100'}`}>
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,rgba(245,158,11,0.16),transparent_23%),radial-gradient(circle_at_50%_83%,rgba(245,158,11,0.06),transparent_32%)]" />
      <div className="relative flex min-h-screen items-center justify-center px-6">
        <section className="flex w-full max-w-sm flex-col items-center text-center animate-fade-in" aria-label="PAXI Wallet startup">
          <div className="relative animate-slide-up">
            <div className="absolute -inset-8 rounded-full bg-accent/10 blur-3xl" />
            <PaxiLogo size="lg" priority className="relative h-28 w-28 border-accent/80 shadow-[0_0_42px_rgba(245,158,11,0.28)] sm:h-32 sm:w-32" />
          </div>

          <div className="mt-7 animate-slide-up" style={{ animationDelay: '0.08s' }}>
            <p className="text-3xl font-black tracking-[0.26em] text-accent sm:text-4xl">PAXI</p>
            <div className="mx-auto mt-5 h-px w-16 bg-gradient-to-r from-transparent via-accent/80 to-transparent" />
            <p className="mt-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-foreground/65">Private. Non-custodial.</p>
          </div>

          <div className="mt-12 flex flex-col items-center gap-3 animate-slide-up" style={{ animationDelay: '0.16s' }}>
            <div className="flex items-center gap-2" aria-label="Loading PAXI Wallet">
              {[0, 1, 2].map((delay) => (
                <span key={delay} className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse" style={{ animationDelay: `${delay * 0.18}s` }} />
              ))}
            </div>
            <p className="text-[10px] font-medium uppercase tracking-[0.22em] text-muted-foreground">Starting your secure wallet</p>
          </div>
        </section>
      </div>
    </div>
  );
}
