import { useMemo, useState } from "react";
import {
  ArrowLeft,
  Bot,
  ChevronRight,
  LifeBuoy,
  Loader2,
  MessageSquare,
  RefreshCw,
  Send,
  ShieldAlert,
  Ticket,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import { AIChatBox } from "@/components/AIChatBox";
import { trpc } from "@/lib/trpc";
import { getStoredAddress } from "@/lib/wallet/vault";

interface SupportScreenProps {
  onBack: () => void;
  transactionContext?: {
    chain?: string;
    transactionHash?: string;
    transactionStatus?: string;
    timestamp?: string;
    error?: string;
    tokenPair?: string;
    quoteStatus?: string;
  };
  tokenContext?: {
    chain?: string;
    contractAddress?: string;
    price?: string;
    liquidity?: string;
    volume?: string;
    securityResult?: string;
    verificationState?: string;
    freshness?: string;
  };
}

const SAFETY_NOTICE =
  "PAXI Support will never ask for your recovery phrase, private key, PIN, password, or authentication codes.";

const QUICK_PROMPTS = [
  "Why is my transaction pending?",
  "Help me with a swap",
  "Check a security warning",
  "Find a token",
  "Explain this transaction",
  "Contact human support",
];

type TicketTab = "ai" | "tickets" | "new";
type SupportMessage = { role: "user" | "assistant"; content: string };

function formatDate(value: Date | string | null | undefined) {
  if (!value) return "Unknown";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Unknown" : date.toLocaleString();
}

export default function SupportScreen({
  onBack,
  transactionContext,
  tokenContext,
}: SupportScreenProps) {
  const [tab, setTab] = useState<TicketTab>("ai");
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [lastPrompt, setLastPrompt] = useState("");
  const [aiError, setAiError] = useState<string | null>(null);
  const [escalationVisible, setEscalationVisible] = useState(false);
  const [selectedTicketKey, setSelectedTicketKey] = useState<string | null>(
    null
  );
  const [reply, setReply] = useState("");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("general");

  const address = useMemo(() => getStoredAddress() ?? undefined, []);
  const safeContext = useMemo(
    () => ({
      publicAddress: address,
      ...transactionContext,
      ...tokenContext,
      simulationAvailable: false,
    }),
    [address, tokenContext, transactionContext]
  );

  const tickets = trpc.support.myTickets.useQuery(undefined, {
    enabled: tab === "tickets" || tab === "new",
  });
  const selectedTicket = trpc.support.ticket.useQuery(
    { ticketKey: selectedTicketKey ?? "" },
    { enabled: Boolean(selectedTicketKey) }
  );

  const askAI = trpc.support.askAI.useMutation({
    onSuccess: result => {
      setMessages(current => [
        ...current,
        { role: "assistant", content: result.answer },
      ]);
      setAiError(null);
      setEscalationVisible(result.escalationSuggested);
    },
    onError: error => {
      setAiError(
        error.message ||
          "PAXI Assistant is temporarily unavailable. You can retry or contact human support."
      );
      setEscalationVisible(true);
    },
  });

  const createTicket = trpc.support.createTicket.useMutation({
    onSuccess: ticket => {
      toast.success(`Ticket ${ticket.ticketKey} created`);
      setSubject("");
      setDescription("");
      setSelectedTicketKey(ticket.ticketKey);
      setTab("tickets");
      tickets.refetch();
    },
    onError: error => toast.error(error.message),
  });

  const requestHuman = trpc.support.requestHuman.useMutation({
    onSuccess: ticket => {
      toast.success(`Human support ticket ${ticket.ticketKey} created`);
      setSelectedTicketKey(ticket.ticketKey);
      setEscalationVisible(false);
      setTab("tickets");
      tickets.refetch();
    },
    onError: error => toast.error(error.message),
  });

  const addMessage = trpc.support.addMessage.useMutation({
    onSuccess: () => {
      setReply("");
      selectedTicket.refetch();
      tickets.refetch();
    },
    onError: error => toast.error(error.message),
  });

  const sendAIMessage = (content: string, retry = false) => {
    const trimmed = content.trim();
    if (!trimmed || askAI.isPending) return;
    const nextMessages = retry
      ? messages
      : [...messages, { role: "user" as const, content: trimmed }];
    if (!retry) setMessages(nextMessages);
    setLastPrompt(trimmed);
    setAiError(null);
    askAI.mutate({ messages: nextMessages, diagnosticContext: safeContext });
  };

  const escalateToHuman = () => {
    const summary = [
      lastPrompt
        ? `User question: ${lastPrompt}`
        : "User requested human support.",
      transactionContext?.transactionHash
        ? `Transaction: ${transactionContext.transactionHash}`
        : null,
      tokenContext?.contractAddress
        ? `Token contract: ${tokenContext.contractAddress}`
        : null,
    ]
      .filter(Boolean)
      .join("\n");
    requestHuman.mutate({
      subject: "PAXI AI escalation",
      description: summary,
      diagnosticContext: safeContext,
      dedupeKey: `ai-escalation:${lastPrompt.slice(0, 64)}`,
      priority: "NORMAL",
    });
  };

  const submitTicket = () => {
    if (!subject.trim() || !description.trim() || createTicket.isPending)
      return;
    createTicket.mutate({
      category,
      subject,
      description,
      diagnosticContext: safeContext,
      dedupeKey: `support:${Date.now()}:${subject.slice(0, 20)}`,
    });
  };

  const submitReply = () => {
    if (!selectedTicketKey || !reply.trim() || addMessage.isPending) return;
    addMessage.mutate({
      ticketKey: selectedTicketKey,
      body: reply,
      clientMessageKey: `reply:${selectedTicketKey}:${Date.now()}`,
    });
  };

  return (
    <div className="min-h-screen bg-background pb-8">
      <div className="sticky top-0 z-40 border-b border-foreground/5 bg-secondary/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center gap-3 px-6 py-4">
          <button
            onClick={onBack}
            className="-ml-2 rounded-lg p-2 hover:bg-foreground/5"
            aria-label="Back"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-accent">Help & Support</h1>
            <p className="text-xs text-muted-foreground">
              Real support tools for the controlled beta
            </p>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-md space-y-4 px-6 py-5">
        <div className="flex gap-2 rounded-xl border border-orange-400/30 bg-orange-500/10 p-3 text-xs text-orange-100">
          <ShieldAlert className="h-4 w-4 shrink-0 text-orange-300" />
          <span>{SAFETY_NOTICE}</span>
        </div>

        {(transactionContext || tokenContext) && (
          <div className="rounded-lg border border-accent/20 bg-accent/5 p-3 text-xs text-muted-foreground">
            <p className="font-semibold text-accent">Safe context attached</p>
            <p className="mt-1">
              PAXI Assistant is using this public, read-only context. Signing
              secrets are never included.
            </p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-2">
          {(
            [
              ["ai", Bot, "Ask PAXI AI"],
              ["tickets", Ticket, "My Tickets"],
              ["new", UserRound, "Contact Human"],
            ] as const
          ).map(([id, Icon, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex flex-col items-center gap-1 rounded-lg border p-2.5 text-xs font-semibold ${tab === id ? "border-accent bg-accent/15 text-accent" : "border-border text-muted-foreground"}`}
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>

        {tab === "ai" && (
          <div className="space-y-3">
            <div>
              <h2 className="text-lg font-semibold text-foreground">
                PAXI Assistant
              </h2>
              <p className="text-sm text-muted-foreground">
                How can I help you today?
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Get help with your wallet, transactions, swaps, security and
                tokens.
              </p>
            </div>

            <AIChatBox
              messages={messages}
              onSendMessage={content => sendAIMessage(content)}
              isLoading={askAI.isPending}
              emptyStateMessage="Choose a safe help topic or ask your own question."
              suggestedPrompts={QUICK_PROMPTS}
              placeholder="Ask about your wallet or transaction…"
              height="470px"
              className="border-accent/20 bg-card/60"
            />

            {askAI.isPending && (
              <p className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="h-3 w-3 animate-spin" />
                PAXI Assistant is checking…
              </p>
            )}

            {aiError && (
              <div className="rounded-lg border border-red-400/30 bg-red-500/10 p-3 text-sm">
                <p className="text-red-200">{aiError}</p>
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={() => sendAIMessage(lastPrompt, true)}
                    disabled={!lastPrompt || askAI.isPending}
                    className="inline-flex items-center gap-1 rounded-md border border-red-300/30 px-3 py-1.5 text-xs text-red-100 disabled:opacity-40"
                  >
                    <RefreshCw className="h-3 w-3" /> Retry
                  </button>
                  <button
                    onClick={() => setTab("new")}
                    className="rounded-md bg-accent px-3 py-1.5 text-xs text-accent-foreground"
                  >
                    Contact human support
                  </button>
                </div>
              </div>
            )}

            {escalationVisible && (
              <div className="rounded-lg border border-accent/30 bg-accent/10 p-3 text-sm">
                <p className="font-semibold text-accent">
                  I couldn&apos;t safely resolve this.
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Create a ticket with safe diagnostic context, continue with
                  PAXI Assistant, or close this message.
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    onClick={escalateToHuman}
                    disabled={requestHuman.isPending}
                    className="rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-accent-foreground disabled:opacity-40"
                  >
                    {requestHuman.isPending
                      ? "Creating ticket…"
                      : "Create Support Ticket"}
                  </button>
                  <button
                    onClick={() => setTab("new")}
                    className="rounded-md border border-border px-3 py-1.5 text-xs"
                  >
                    Open ticket form
                  </button>
                  <button
                    onClick={() => setEscalationVisible(false)}
                    className="rounded-md border border-border px-3 py-1.5 text-xs"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "tickets" && (
          <div className="space-y-3">
            {selectedTicketKey ? (
              <div className="space-y-3">
                <button
                  onClick={() => setSelectedTicketKey(null)}
                  className="text-xs text-accent"
                >
                  ← Back to ticket list
                </button>
                {selectedTicket.isLoading ? (
                  <Loader2 className="mx-auto h-5 w-5 animate-spin" />
                ) : selectedTicket.data ? (
                  <>
                    <div className="glass-card !p-4 space-y-2">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-xs text-muted-foreground">
                            {selectedTicket.data.ticket.ticketKey}
                          </p>
                          <h2 className="font-semibold">
                            {selectedTicket.data.ticket.subject}
                          </h2>
                        </div>
                        <span className="rounded-full bg-accent/15 px-2 py-1 text-[10px] font-semibold text-accent">
                          {selectedTicket.data.ticket.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                        <span>
                          Category: {selectedTicket.data.ticket.category}
                        </span>
                        <span>
                          Priority: {selectedTicket.data.ticket.priority}
                        </span>
                        <span>
                          Created:{" "}
                          {formatDate(selectedTicket.data.ticket.createdAt)}
                        </span>
                        <span>
                          Updated:{" "}
                          {formatDate(selectedTicket.data.ticket.updatedAt)}
                        </span>
                      </div>
                    </div>
                    <div className="glass-card !p-3 space-y-3">
                      {selectedTicket.data.messages.map(message => (
                        <div
                          key={message.id}
                          className={`rounded-lg p-3 text-sm ${message.authorType === "USER" ? "ml-5 bg-accent/15" : "mr-5 bg-secondary"}`}
                        >
                          <div className="mb-1 flex justify-between gap-2 text-[10px] text-muted-foreground">
                            <span>
                              {message.authorType === "SUPPORT"
                                ? "PAXI Support"
                                : message.authorType}
                            </span>
                            <span>{formatDate(message.createdAt)}</span>
                          </div>
                          <p className="whitespace-pre-wrap">{message.body}</p>
                        </div>
                      ))}
                    </div>
                    {!["RESOLVED", "CLOSED"].includes(
                      selectedTicket.data.ticket.status
                    ) && (
                      <div className="flex gap-2">
                        <textarea
                          value={reply}
                          onChange={event => setReply(event.target.value)}
                          placeholder="Reply to human support. Never include wallet secrets."
                          rows={3}
                          className="flex-1 resize-none rounded-lg border border-border bg-secondary px-3 py-2 text-sm"
                        />
                        <button
                          onClick={submitReply}
                          disabled={!reply.trim() || addMessage.isPending}
                          className="self-end rounded-lg bg-accent px-3 py-2 text-accent-foreground disabled:opacity-40"
                          aria-label="Reply to ticket"
                        >
                          {addMessage.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Send className="h-4 w-4" />
                          )}
                        </button>
                      </div>
                    )}
                  </>
                ) : (
                  <p className="py-10 text-center text-sm text-muted-foreground">
                    Ticket not found or no longer available.
                  </p>
                )}
              </div>
            ) : (
              <>
                {tickets.isLoading ? (
                  <Loader2 className="mx-auto h-5 w-5 animate-spin" />
                ) : tickets.data?.length ? (
                  tickets.data.map(ticket => (
                    <button
                      key={ticket.ticketKey}
                      onClick={() => setSelectedTicketKey(ticket.ticketKey)}
                      className="glass-card !p-4 flex w-full items-center gap-3 text-left"
                    >
                      <MessageSquare className="h-5 w-5 text-accent" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">
                          {ticket.subject}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {ticket.ticketKey} · {ticket.status} ·{" "}
                          {ticket.priority}
                        </p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </button>
                  ))
                ) : (
                  <div className="py-12 text-center text-sm text-muted-foreground">
                    No support tickets yet.
                  </div>
                )}
                <button
                  onClick={() => setTab("new")}
                  className="w-full rounded-lg border border-accent/40 py-2.5 text-sm font-semibold text-accent"
                >
                  Report a Problem
                </button>
              </>
            )}
          </div>
        )}

        {tab === "new" && (
          <div className="glass-card !p-4 space-y-3">
            <div className="flex items-center gap-2">
              <LifeBuoy className="h-5 w-5 text-accent" />
              <h2 className="font-semibold">Contact Human Support</h2>
            </div>
            <p className="text-xs text-muted-foreground">
              Share only safe diagnostic information. Never include signing
              secrets.
            </p>
            <select
              value={category}
              onChange={event => setCategory(event.target.value)}
              className="w-full rounded-lg border border-border bg-secondary px-3 py-2.5 text-sm"
            >
              <option value="general">General question</option>
              <option value="transaction">Transaction problem</option>
              <option value="swap">Swap problem</option>
              <option value="bridge">Bridge problem</option>
              <option value="suspicious_token">Report suspicious token</option>
              <option value="scam_phishing">Report scam or phishing</option>
            </select>
            <input
              value={subject}
              onChange={event => setSubject(event.target.value)}
              placeholder="Subject"
              className="w-full rounded-lg border border-border bg-secondary px-3 py-2.5 text-sm"
            />
            <textarea
              value={description}
              onChange={event => setDescription(event.target.value)}
              placeholder="Describe the issue and include a transaction hash only if relevant"
              rows={7}
              className="w-full resize-none rounded-lg border border-border bg-secondary px-3 py-2.5 text-sm"
            />
            <button
              onClick={submitTicket}
              disabled={
                !subject.trim() || !description.trim() || createTicket.isPending
              }
              className="w-full rounded-lg bg-accent py-2.5 text-sm font-semibold text-accent-foreground disabled:opacity-40"
            >
              {createTicket.isPending
                ? "Creating ticket…"
                : "Create Support Ticket"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
