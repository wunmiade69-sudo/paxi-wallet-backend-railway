import { ArrowLeft, Clock3, Inbox, Loader2, RefreshCw, TicketCheck } from 'lucide-react';
import { trpc } from '@/lib/trpc';

const STATUS_LABELS: Record<string, string> = {
  open: 'Open',
  in_progress: 'In progress',
  waiting_on_user: 'Waiting for you',
  resolved: 'Resolved',
  closed: 'Closed',
};

const STATUS_STYLES: Record<string, string> = {
  open: 'border-sky-400/25 bg-sky-400/10 text-sky-300',
  in_progress: 'border-amber-400/25 bg-amber-400/10 text-amber-300',
  waiting_on_user: 'border-violet-400/25 bg-violet-400/10 text-violet-300',
  resolved: 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300',
  closed: 'border-border bg-secondary text-muted-foreground',
};

export default function SupportTicketsScreen({ onBack }: { onBack: () => void }) {
  const tickets = trpc.support.myTickets.useQuery(undefined, { retry: 1 });

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 border-b border-foreground/5 bg-secondary/50 backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center justify-between px-6 py-4">
          <button type="button" onClick={onBack} className="text-muted-foreground transition-colors hover:text-foreground" aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
          <h1 className="text-lg font-bold text-accent">Support tickets</h1>
          <button type="button" onClick={() => tickets.refetch()} className="text-muted-foreground transition-colors hover:text-foreground" aria-label="Refresh tickets"><RefreshCw className={`h-4 w-4 ${tickets.isFetching ? 'animate-spin' : ''}`} /></button>
        </div>
      </div>

      <main className="mx-auto max-w-md space-y-4 px-6 py-6">
        <div className="glass-card flex items-start gap-3 border border-accent/15 p-4">
          <TicketCheck className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
          <p className="text-xs leading-5 text-muted-foreground">Your ticket status comes from the PAXI support queue. Support will never need your seed phrase, private key, or PIN.</p>
        </div>

        {tickets.isLoading && <div className="glass-card flex items-center justify-center gap-2 p-8 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading your tickets…</div>}
        {tickets.isError && <div className="glass-card space-y-3 p-8 text-center"><p className="font-semibold text-foreground">Ticket history unavailable</p><p className="text-sm text-muted-foreground">We could not load your support history. Try again when the support service is available.</p><button type="button" onClick={() => tickets.refetch()} className="rounded-xl bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground">Try again</button></div>}
        {tickets.data && tickets.data.length === 0 && <div className="glass-card space-y-3 p-8 text-center"><Inbox className="mx-auto h-9 w-9 text-muted-foreground" /><p className="font-semibold text-foreground">No support tickets yet</p><p className="text-sm text-muted-foreground">Tickets you submit from Report a problem or PAXI AI will appear here.</p></div>}
        {tickets.data?.map((ticket) => (
          <article key={ticket.id} className="glass-card space-y-3 border border-border/80 p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0"><p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Ticket #{ticket.id}</p><h2 className="mt-1 truncate text-sm font-semibold text-foreground">{ticket.subject}</h2></div>
              <span className={`shrink-0 rounded-full border px-2 py-1 text-[10px] font-semibold ${STATUS_STYLES[ticket.status] ?? STATUS_STYLES.closed}`}>{STATUS_LABELS[ticket.status] ?? ticket.status}</span>
            </div>
            <p className="line-clamp-3 text-xs leading-5 text-muted-foreground">{ticket.message}</p>
            <div className="flex items-center justify-between gap-2 text-[10px] text-muted-foreground"><span className="rounded-full bg-secondary px-2 py-1">{ticket.category.replaceAll('_', ' ')}</span><span className="flex items-center gap-1"><Clock3 className="h-3 w-3" />{new Date(ticket.updatedAt ?? ticket.createdAt).toLocaleDateString()}</span></div>
            {ticket.resolutionNote && <div className="rounded-lg border border-emerald-400/20 bg-emerald-400/5 p-3 text-xs text-muted-foreground"><span className="font-semibold text-emerald-300">Support note: </span>{ticket.resolutionNote}</div>}
          </article>
        ))}
      </main>
    </div>
  );
}
