import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDownUp, ArrowLeftRight, AlertTriangle, Loader2, History } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { ASSETS, NETWORKS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { getStoredAddress, getUnlockedMnemonic } from '@/lib/wallet/vault';
import { fetchAssetBalance } from '@/lib/wallet/balances';
import { describeTxError } from '@/lib/wallet/errors';
import { addTxRecord, getTxRecords, type TxRecord } from '@/lib/wallet/txHistory';
import { notifyForTransaction } from '@/lib/phase3Local';
import AssetPickerDrawer from '@/components/AssetPickerDrawer';
import NetworkPickerDrawer from '@/components/NetworkPickerDrawer';
import {
  executeSwap,
  fetchSwapQuote,
  isSwappable,
  type SwapQuote,
} from '@/lib/wallet/swap';
import { isSolanaSwappable, getSolanaSwapQuote, executeSolanaSwap, SOL_TREASURY_ADDRESS } from '@/lib/wallet/jupiterSwap';
import { getAddressForChainType } from '@/lib/wallet/engine';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { SecurityStatusBadge, PaxiShieldPanel } from '@/components/PaxiShieldPanel';
import TransactionReceipt from '@/components/TransactionReceipt';
import { isActiveWalletPrivateKeyImport } from '@/lib/wallet/vault';
import { getHistoryStaleWhileRevalidate } from '@/lib/wallet/txIndexer';
import { formatWalletAmount, formatWalletInputAmount } from '@/lib/wallet/amountFormatting';

type Step = 'form' | 'confirm' | 'approving' | 'swapping' | 'done';

const SLIPPAGE_BPS = 100; // 1% - user is guaranteed at least this much of the quoted amount

/** Same-chain swap: asset picker, live multi-DEX quote, confirm, execute. Rendered inside TradeScreen's "Swap" tab. */
export default function SwapPanel() {
  const allAssets = useMemo(() => [...ASSETS, ...getCustomTokens().map(customTokenToAsset)], []);
  const swappableAssets = useMemo(
    () => allAssets.filter((a) => isSwappable(a) || isSolanaSwappable(a)),
    [allAssets]
  );
  const networkIds = useMemo(
    () => Array.from(new Set(swappableAssets.map((a) => a.network))),
    [swappableAssets]
  );

  const [networkId, setNetworkId] = useState(networkIds[0] ?? 'ethereum');
  const assetsOnNetwork = swappableAssets.filter((a) => a.network === networkId);

  const [fromSymbol, setFromSymbol] = useState(assetsOnNetwork[0]?.symbol ?? '');
  const [toSymbol, setToSymbol] = useState(assetsOnNetwork[1]?.symbol ?? assetsOnNetwork[0]?.symbol ?? '');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<Step>('form');
  const [error, setError] = useState('');
  const [quote, setQuote] = useState<SwapQuote | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [result, setResult] = useState<TxRecord | null>(null);
  const [fromBalance, setFromBalance] = useState<number | null>(null);
  const [balanceLoading, setBalanceLoading] = useState(false);
  const [showAuthGate, setShowAuthGate] = useState(false);
  const quoteRequestId = useRef(0);

  const fromAsset = assetsOnNetwork.find((a) => a.symbol === fromSymbol) ?? assetsOnNetwork[0];
  const toAsset = assetsOnNetwork.find((a) => a.symbol === toSymbol) ?? assetsOnNetwork[1] ?? assetsOnNetwork[0];
  const network = NETWORKS[networkId];
  const address = getStoredAddress() ?? '';
  const isSol = network.chainType === 'sol';
  const solFeeEnabled = isSol && Boolean(SOL_TREASURY_ADDRESS);
  const treasuryNetwork = networkId === 'bsc' ? 'bsc' : networkId === 'polygon' ? 'polygon' : networkId === 'arbitrum' ? 'arbitrum' : 'ethereum';
  const evmTreasury = trpc.fees.getTreasuryForNetwork.useQuery({ network: treasuryNetwork });
  const evmFeeConfig = trpc.fees.getConfig.useQuery({ operation: 'swap_evm', chainType: 'evm' });
  const serverFeeBps = !isSol && evmFeeConfig.data?.isActive ? evmFeeConfig.data.percentageBps : 0;
  const serverFeeAddress = !isSol && evmTreasury.data?.settlementEnabled ? evmTreasury.data.address : null;
  const mnemonicForBalance = getUnlockedMnemonic();
  const solAddress = isSol && mnemonicForBalance ? getAddressForChainType(mnemonicForBalance, 'sol') : null;

  const numericAmount = Number(amount);
  const insufficientBalance =
    fromBalance !== null && !isNaN(numericAmount) && numericAmount > 0 && numericAmount > fromBalance;

  // Live balance of whatever's in the "You pay" field, so the wallet can say
  // "Insufficient balance" up front instead of letting an on-chain revert do it.
  useEffect(() => {
    let cancelled = false;
    if (!fromAsset || (!address && !solAddress)) {
      setFromBalance(null);
      return;
    }
    setBalanceLoading(true);
    fetchAssetBalance(fromAsset, address, solAddress ?? undefined)
      .then((b) => {
        if (!cancelled) setFromBalance(b);
      })
      .finally(() => {
        if (!cancelled) setBalanceLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [fromAsset, address, solAddress]);

  // Network changed -> reset asset pickers to that network's first two assets.
  useEffect(() => {
    const onNet = swappableAssets.filter((a) => a.network === networkId);
    setFromSymbol(onNet[0]?.symbol ?? '');
    setToSymbol(onNet[1]?.symbol ?? onNet[0]?.symbol ?? '');
    setAmount('');
    setQuote(null);
    setError('');
  }, [networkId, swappableAssets]);

  // Debounced quote fetch whenever the trade inputs change.
  useEffect(() => {
    setError('');
    setQuote(null);
    const parsedAmount = Number(amount);
    if (!fromAsset || !toAsset || fromAsset.symbol === toAsset.symbol || !amount || isNaN(parsedAmount) || parsedAmount <= 0) {
      return;
    }
    if (!address && !solAddress) {
      setError('Session locked. Please unlock your wallet again.');
      return;
    }
    if (isSol && !solAddress) {
      setError(
        isActiveWalletPrivateKeyImport()
          ? "This account can't swap on Solana - it was imported from a private key, so it's EVM-only."
          : 'Unlock your wallet to get a Solana address before swapping.'
      );
      return;
    }
    // Don't burn a quote request on an amount we already know exceeds the balance -
    // show "Insufficient balance" immediately instead (see render below).
    if (fromBalance !== null && parsedAmount > fromBalance) {
      return;
    }
    setQuoting(true);
    const requestId = ++quoteRequestId.current;
    let active = true;
    const timer = setTimeout(async () => {
      try {
        const q = isSol
          ? await getSolanaSwapQuote({
              fromAsset,
              toAsset,
              amount,
              slippageBps: SLIPPAGE_BPS,
            })
          : await fetchSwapQuote({
              networkId,
              srcAsset: fromAsset,
              destAsset: toAsset,
              amount,
              userAddress: address,
              slippageBps: SLIPPAGE_BPS,
              feeBps: serverFeeBps,
              feeAddress: serverFeeAddress,
            });

        if (active && requestId === quoteRequestId.current) setQuote(q);
      } catch (err) {
        if (active && requestId === quoteRequestId.current) setError(describeTxError(err));
      } finally {
        if (active && requestId === quoteRequestId.current) setQuoting(false);
      }
    }, 500);
    return () => {
      active = false;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fromSymbol, toSymbol, amount, networkId, fromBalance, serverFeeBps, serverFeeAddress, address, solAddress, isSol]);

  const flipAssets = () => {
    setFromSymbol(toAsset.symbol);
    setToSymbol(fromAsset.symbol);
    setAmount('');
    setQuote(null);
  };

  const setMaxAmount = () => {
    if (fromBalance === null) return;
    // Native coin needs a sliver left for gas, otherwise the swap would revert anyway.
    const max = fromAsset?.isNative ? Math.max(0, fromBalance - 0.0005) : fromBalance;
    setAmount(max > 0 ? formatWalletInputAmount(max, fromAsset?.decimals) : '0');
  };

  const handleReview = () => {
    if (insufficientBalance) {
      setError('Insufficient balance for this amount.');
      return;
    }
    if (!quote) {
      setError('Wait for a quote before continuing.');
      return;
    }
    setStep('confirm');
  };

  const handleConfirmSwap = async () => {
    const mnemonic = getUnlockedMnemonic();
    if (!mnemonic || !quote) {
      setError('Session locked. Please unlock your wallet again.');
      setStep('form');
      return;
    }
    if (isSol && !solAddress) {
      setError(
        isActiveWalletPrivateKeyImport()
          ? "This account can't swap on Solana - it was imported from a private key, so it's EVM-only."
          : 'Unlock your wallet to get a Solana address before swapping.'
      );
      setStep('form');
      return;
    }
    setError('');
    setStep('swapping');
    try {
      const res = isSol
        ? await executeSolanaSwap({ mnemonic, quote: quote as SwapQuote & { _jupiterRaw: any }, toAsset })
        : await executeSwap({
            mnemonic,
            networkId,
            srcAsset: fromAsset,
            destAsset: toAsset,
            quote,
            slippageBps: SLIPPAGE_BPS,
            userAddress: address,
            onStatus: (status) => setStep(status),
          });
      setStep('done');
      toast.success(res.status === 'confirmed' ? 'Swap confirmed' : 'Swap broadcast');
      const record = addTxRecord({
        type: 'swap',
        networkId,
        hash: res.swapHash,
        explorerUrl: res.explorerUrl,
        fromSymbol: fromAsset.symbol,
        fromAmount: amount,
        toSymbol: toAsset.symbol,
        toAmount: quote.destAmountFormatted,
        status: res.status ?? 'pending',
      });
      setResult(record);
      notifyForTransaction({
        hash: res.swapHash,
        networkId,
        type: 'swap',
        status: res.status === 'confirmed' ? 'confirmed' : 'submitted',
        symbol: fromAsset.symbol,
        amount,
        source: 'local-wallet',
      });
    } catch (err) {
      setError(describeTxError(err));
      setStep('confirm');
    }
  };

  const resetForm = () => {
    setAmount('');
    setQuote(null);
    setResult(null);
    setError('');
    setStep('form');
  };

  const [recentSwaps, setRecentSwaps] = useState<TxRecord[]>([]);
  const [selectedReceipt, setSelectedReceipt] = useState<TxRecord | null>(null);

  useEffect(() => {
    // Instant paint from the local log, then swap in the real resolved status (confirmed/failed)
    // once it's back - this list used to just show raw local records, permanently "Pending"
    // even for swaps confirmed weeks ago.
    setRecentSwaps(getTxRecords().filter((r) => r.type === 'swap').slice(0, 3));
    if (!address) return;
    getHistoryStaleWhileRevalidate(address, (fresh) => {
      setRecentSwaps(fresh.records.filter((r) => r.type === 'swap').slice(0, 3));
    });
  }, [step, address]); // re-read right after a swap completes (step flips to 'done')

  if (swappableAssets.length < 2) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
        <ArrowLeftRight className="w-10 h-10 text-muted-foreground" />
        <p className="text-foreground font-semibold">Not enough swappable assets yet</p>
        <p className="text-sm text-muted-foreground max-w-xs">
          Swaps need at least two assets on the same network (EVM or Solana). Add a token first.
        </p>
      </div>
    );
  }

  return (
    <>
    <div className="max-w-md mx-auto w-full px-5 py-6">
      {step === 'form' && (
          <div className="space-y-4">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <label className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Network</label>
                <span className="text-[10px] text-muted-foreground">Choose a live route</span>
              </div>
              <NetworkPickerDrawer
                label="Choose network"
                networks={networkIds.map((id) => NETWORKS[id])}
                selected={NETWORKS[networkId]}
                onSelect={setNetworkId}
              />
            </div>

            <div className="rounded-3xl border border-white/[0.09] bg-white/[0.035] p-4 shadow-[0_18px_50px_rgba(0,0,0,0.16)] space-y-3">
              <div className="flex items-center justify-between">
                  <label className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">You pay</label>
                <span className="text-xs text-muted-foreground">
                  {balanceLoading ? (
                    'Balance: …'
                  ) : fromBalance !== null ? (
                    <>Balance: {formatWalletAmount(fromBalance)} {fromAsset?.symbol}</>
                  ) : null}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className={`flex-1 min-w-0 bg-transparent text-[32px] font-semibold tracking-[-0.04em] outline-none placeholder:text-muted-foreground ${
                    insufficientBalance ? 'text-destructive' : 'text-foreground'
                  }`}
                />
                <AssetPickerDrawer
                  label="You pay"
                  assets={assetsOnNetwork}
                  selected={fromAsset}
                  disabledSymbol={toSymbol}
                  onSelect={(a) => setFromSymbol(a.symbol)}
                />
              </div>
              <div className="flex items-center justify-between pt-0.5">
                {insufficientBalance ? (
                  <p className="text-xs text-destructive">Insufficient balance</p>
                ) : (
                  <span />
                )}
                {fromBalance !== null && fromBalance > 0 && (
                  <div className="flex items-center gap-1.5">
                    {[25, 50, 75].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => {
                          const raw = (fromBalance * pct) / 100;
                          const val = fromAsset?.isNative ? Math.max(0, raw - 0.0005 * (pct / 100)) : raw;
                          setAmount(val > 0 ? formatWalletInputAmount(val, fromAsset?.decimals) : '0');
                        }}
                        className="text-xs text-muted-foreground hover:text-accent hover:bg-accent/10 rounded px-1.5 py-0.5 transition-colors"
                      >
                        {pct}%
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={setMaxAmount}
                      className="text-xs font-semibold text-accent hover:bg-accent/10 rounded px-1.5 py-0.5 transition-colors"
                    >
                      Max
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-center -my-3 relative z-10">
              <button
                onClick={flipAssets}
                className="bg-secondary border-4 border-background rounded-full p-2 hover:bg-muted hover:rotate-180 transition-all duration-300"
                aria-label="Flip assets"
              >
                <ArrowDownUp className="w-4 h-4 text-accent" />
              </button>
            </div>

            <div className="rounded-3xl border border-white/[0.09] bg-white/[0.035] p-4 shadow-[0_18px_50px_rgba(0,0,0,0.16)] space-y-3">
              <label className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">You receive</label>
              <div className="flex items-center gap-3">
                  <div className="flex-1 min-w-0 text-[32px] font-semibold tracking-[-0.04em] text-foreground truncate">
                  {quoting ? (
                    <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                  ) : quote ? (
                    formatWalletAmount(quote.destAmountFormatted)
                  ) : (
                    <span className="text-muted-foreground">0.00</span>
                  )}
                </div>
                <AssetPickerDrawer
                  label="You receive"
                  assets={assetsOnNetwork}
                  selected={toAsset}
                  disabledSymbol={fromSymbol}
                  onSelect={(a) => setToSymbol(a.symbol)}
                />
              </div>
            </div>

            {quote && (
              <div className="rounded-3xl border border-accent/15 bg-gradient-to-br from-accent/[0.08] via-white/[0.035] to-transparent p-4 shadow-[0_18px_50px_rgba(0,0,0,0.16)] space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-accent/90">Live quote</span>
                  <SecurityStatusBadge network={toAsset.network} contractAddress={toAsset.contractAddress} isNative={toAsset.isNative} />
                </div>
                <div className="space-y-2.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Rate</span>
                    <span className="text-foreground font-medium">
                      1 {fromAsset.symbol} ≈ {quote.rate.toPrecision(6)} {toAsset.symbol}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      {isSol ? 'Solana service fee' : 'PAXI service fee'}
                    </span>
                    <span className="text-foreground font-medium">
                      {isSol && !solFeeEnabled
                        ? 'Unavailable on this network'
                        : quote.feeBps > 0
                          ? `${quote.feeAmountFormatted} ${(isSol ? toAsset : fromAsset).symbol} (${(quote.feeBps / 100).toFixed(2)}%)`
                          : 'Unavailable on this network'}
                    </span>
                  </div>
                  {quote.routeNames.length > 0 && (
                    <div className="flex justify-between gap-3 pt-2.5 border-t border-border">
                      <span className="text-muted-foreground shrink-0">Routed via</span>
                      <span className="text-foreground font-medium text-right">{quote.routeNames.join(', ')}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {error && (
              <div className="flex items-start gap-3 rounded-2xl border border-red-400/20 bg-red-400/[0.07] p-3.5">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-400/10 text-red-300">!</span>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-red-200">Unable to quote</p>
                  <p className="mt-1 text-sm leading-5 text-red-100/75">{error}</p>
                </div>
              </div>
            )}

            <button
              onClick={handleReview}
              disabled={!quote || quoting || insufficientBalance}
              className="w-full rounded-2xl bg-accent py-3.5 font-semibold text-accent-foreground shadow-[0_14px_30px_rgba(245,158,11,0.16)] transition-colors hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {insufficientBalance ? 'Insufficient balance' : 'Review Swap'}
            </button>

            <p className="px-4 text-center text-[11px] leading-5 text-muted-foreground">
              Quotes use available routes · {isSol && !solFeeEnabled ? 'Solana service fee not available yet' : quote ? `${(quote.feeBps / 100).toFixed(2)}% service fee when configured` : 'Service fee shown before confirmation'} · {(SLIPPAGE_BPS / 100).toFixed(1)}% slippage tolerance
            </p>

            {recentSwaps.length > 0 && (
              <div className="pt-2">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                  <History className="w-3.5 h-3.5" />
                  Recent swaps
                </div>
                <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
                  {recentSwaps.map((r) => {
                    const status = r.status ?? 'confirmed';
                    return (
                      <button
                        key={r.id}
                        onClick={() => setSelectedReceipt(r)}
                        className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-foreground/5 active:scale-[0.99] transition-all text-left"
                      >
                        <span className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${status === 'failed' ? 'bg-destructive/10 text-destructive' : status === 'pending' ? 'bg-amber-400/10 text-amber-400' : 'bg-accent/10 text-accent'}`}>
                          <ArrowDownUp className="w-4 h-4" />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-2 min-w-0">
                            <span className="text-sm font-semibold text-foreground truncate">
                              {formatAmount(r.fromAmount)} {r.fromSymbol} <span className="text-muted-foreground font-normal">→</span> {formatAmount(r.toAmount)} {r.toSymbol}
                            </span>
                          </span>
                          <span className="flex items-center gap-2 mt-1 text-[11px] text-muted-foreground">
                            <span>{NETWORKS[r.networkId]?.label ?? r.networkId}</span>
                            <span className="text-foreground/20">•</span>
                            <span>{new Date(r.timestamp).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</span>
                          </span>
                        </span>
                        <span className="text-right shrink-0">
                          <span className="block text-xs font-semibold text-foreground">+{formatAmount(r.toAmount)} {r.toSymbol}</span>
                          <span className={`inline-flex mt-1 text-[10px] font-semibold ${status === 'failed' ? 'text-destructive' : status === 'pending' ? 'text-amber-400' : 'text-accent'}`}>
                            {status === 'failed' ? 'Failed' : status === 'pending' ? 'Pending' : 'Successful'}
                          </span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {selectedReceipt && (
          <TransactionReceipt record={selectedReceipt} onClose={() => setSelectedReceipt(null)} primaryActionLabel="Close" />
        )}

        {(step === 'approving' || step === 'swapping') && (
          <div className="text-center py-16">
            <div className="animate-spin w-10 h-10 border-4 border-accent border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-muted-foreground">
              {step === 'approving' ? `Approving ${fromAsset.symbol} for swapping...` : 'Broadcasting swap...'}
            </p>
          </div>
        )}

        {step === 'done' && result && (
          <TransactionReceipt record={result} onClose={resetForm} />
        )}
    </div>

    <Drawer open={step === 'confirm' && !!quote} onOpenChange={(open) => !open && setStep('form')}>
      <DrawerContent className="max-h-[92vh] border-white/10 bg-[#0d0b0b]">
        <DrawerHeader className="border-b border-white/[0.07] px-5 pb-4 pt-2 text-left">
          <div className="mb-1 h-1 w-10 rounded-full bg-white/15" />
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-accent/80">Review before signing</p>
              <DrawerTitle className="mt-1 text-xl tracking-[-0.02em]">Swap Preview</DrawerTitle>
            </div>
            {quote && <SecurityStatusBadge network={toAsset.network} contractAddress={toAsset.contractAddress} isNative={toAsset.isNative} />}
          </div>
        </DrawerHeader>

        {quote && (
          <div className="overflow-y-auto px-4 pb-6 space-y-4">
            <PaxiShieldPanel network={toAsset.network} contractAddress={toAsset.contractAddress} isNative={toAsset.isNative} />

            <div className="flex items-start gap-3 rounded-2xl border border-amber-300/20 bg-amber-300/[0.07] p-3.5">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-300/10"><AlertTriangle className="h-4 w-4 text-amber-300" /></span>
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.12em] text-amber-200">Final review</p>
                <p className="mt-1 text-sm leading-5 text-amber-100/75">This is an irreversible on-chain transaction. {isSol && !solFeeEnabled ? 'Solana wallet fee collection is disabled until a verified treasury is configured.' : 'The wallet fee is included in the quoted amount.'}</p>
              </div>
            </div>

            {error && (
              <div className="flex items-start gap-3 rounded-2xl border border-red-400/20 bg-red-400/[0.07] p-3.5">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-400/10 text-red-300">!</span>
                <p className="text-sm leading-5 text-red-100/75">{error}</p>
              </div>
            )}

            <div className="flex gap-3 border-t border-white/[0.07] pt-4">
              <button
                onClick={() => setStep('form')}
                className="flex-1 rounded-2xl border border-white/10 bg-white/[0.04] py-3.5 font-semibold text-foreground transition-colors hover:bg-white/[0.08]"
              >
                Reject
              </button>
              <button
                onClick={() => setShowAuthGate(true)}
                className="flex-1 rounded-2xl bg-accent py-3.5 font-semibold text-accent-foreground shadow-[0_12px_26px_rgba(245,158,11,0.18)] transition-colors hover:bg-accent/90"
              >
                Swap
              </button>
            </div>
          </div>
        )}
      </DrawerContent>
    </Drawer>

    <TransactionAuthSheet
      open={showAuthGate}
      actionLabel={`Swap ${amount} ${fromSymbol} → ${toSymbol}`}
      onSuccess={() => {
        setShowAuthGate(false);
        handleConfirmSwap();
      }}
      onCancel={() => setShowAuthGate(false)}
    />
    </>
  );
}

function formatAmount(amount: string | number | undefined): string {
  return amount === undefined ? '?' : formatWalletAmount(amount);
}
