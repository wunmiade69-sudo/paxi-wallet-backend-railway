import { useState } from 'react';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import SwapPanel from './SwapPanel';
import BridgePanel from './BridgePanel';
import ThorchainSwapPanel from './ThorchainSwapPanel';

interface SwapScreenProps {
  onNavigate: (tab: NavTab) => void;
}

type TradeTab = 'swap' | 'bridge' | 'btc-swap';

/** The "Trade" bottom-nav tab: same-chain Swap, cross-chain Bridge, and BTC Swap (via THORChain), switchable at the top. */
export default function SwapScreen({ onNavigate }: SwapScreenProps) {
  const [tab, setTab] = useState<TradeTab>('swap');

  return (
    <div className="min-h-screen bg-background pb-24 flex flex-col">
      <div className="sticky top-0 z-40 border-b border-white/[0.07] bg-background/90 backdrop-blur-2xl">
        <div className="max-w-md mx-auto px-6 pb-4 pt-5">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-accent/80">PAXI execution desk</p>
              <h1 className="mt-1 text-[28px] font-bold tracking-[-0.03em] text-foreground">Trade</h1>
            </div>
            <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-emerald-300">Live routes</span>
          </div>
          <div className="grid grid-cols-3 gap-1 rounded-2xl border border-white/[0.08] bg-white/[0.03] p-1">
            <button
              onClick={() => setTab('swap')}
              className={`min-h-10 rounded-xl px-2 py-2 text-xs font-semibold transition-colors ${
                tab === 'swap' ? 'bg-accent text-accent-foreground shadow-[0_6px_20px_rgba(245,158,11,0.18)]' : 'text-muted-foreground hover:bg-white/[0.04] hover:text-foreground'
              }`}
            >
              Swap
            </button>
            <button
              onClick={() => setTab('bridge')}
              className={`min-h-10 rounded-xl px-2 py-2 text-xs font-semibold transition-colors ${
                tab === 'bridge' ? 'bg-accent text-accent-foreground shadow-[0_6px_20px_rgba(245,158,11,0.18)]' : 'text-muted-foreground hover:bg-white/[0.04] hover:text-foreground'
              }`}
            >
              Bridge
            </button>
            <button
              onClick={() => setTab('btc-swap')}
              className={`min-h-10 rounded-xl px-2 py-2 text-xs font-semibold transition-colors ${
                tab === 'btc-swap' ? 'bg-accent text-accent-foreground shadow-[0_6px_20px_rgba(245,158,11,0.18)]' : 'text-muted-foreground hover:bg-white/[0.04] hover:text-foreground'
              }`}
            >
              BTC Swap
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {tab === 'swap' ? <SwapPanel /> : tab === 'bridge' ? <BridgePanel /> : <ThorchainSwapPanel />}
      </div>

      <BottomNav active="trade" onNavigate={onNavigate} />
    </div>
  );
}
