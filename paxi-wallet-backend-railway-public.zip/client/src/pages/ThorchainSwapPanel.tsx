import { useEffect, useState } from 'react';
import { ArrowRight, Loader2, AlertTriangle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { getUnlockedMnemonic, isActiveWalletPrivateKeyImport, isActiveWalletWatchOnly } from '@/lib/wallet/vault';
import { getAddressForChainType } from '@/lib/wallet/engine';
import { estimateBitcoinMaxSend, fetchBitcoinBalance } from '@/lib/wallet/bitcoin';
import { isThorchainTradingHaltedError, describeTxError } from '@/lib/wallet/errors';
import { parseExactBaseUnits } from '@shared/exactDecimal';
import {
  THORCHAIN_DEST_ASSETS,
  getThorchainSwapQuote,
  executeThorchainSwap,
  pollThorchainSwapStatus,
  type ThorchainQuote,
  type ThorchainSwapStatus,
} from '@/lib/wallet/thorchain';
import { addTxRecord, updateTxRecord, type TxRecord } from '@/lib/wallet/txHistory';
import { notifyForTransaction } from '@/lib/phase3Local';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';
import TransactionReceipt from '@/components/TransactionReceipt';

type Step = 'form' | 'confirm' | 'sending' | 'tracking' | 'done';

/** THORChain's own chain prefix (before the ".") in its asset notation, e.g. "ETH.ETH" -> "ETH". Mapped to
 * this wallet's own network ids so the resulting TxRecord/receipt render with the right chain label. */
const THOR_PREFIX_TO_NETWORK: Record<string, string> = { ETH: 'ethereum', BSC: 'bsc' };

function destNetworkId(thorId: string): string {
  return THOR_PREFIX_TO_NETWORK[thorId.split('.')[0]] ?? thorId.split('.')[0].toLowerCase();
}

function destSymbol(thorId: string): string {
  return thorId.split('.')[1]?.split('-')[0] ?? thorId;
}

/**
 * Cross-chain BTC -> (ETH/BSC/etc) swap via THORChain - a genuinely
 * different mechanism from same-chain Swap (see thorchain.ts header),
 * so this is its own panel rather than bolted onto SwapPanel's same-chain
 * assumptions.
 */
export default function ThorchainSwapPanel() {
  const mnemonic = getUnlockedMnemonic();
  const btcAddress = mnemonic ? getAddressForChainType(mnemonic, 'btc') : null;
  const evmAddress = mnemonic ? getAddressForChainType(mnemonic, 'evm') : null;

  const [destAssetId, setDestAssetId] = useState(THORCHAIN_DEST_ASSETS[0].thorId);
  const [destinationAddress, setDestinationAddress] = useState(evmAddress ?? '');
  const [amount, setAmount] = useState('');
  const [btcBalance, setBtcBalance] = useState<string | null>(null);
  const [spendableBtc, setSpendableBtc] = useState<string | null>(null);
  const [btcAvailability, setBtcAvailability] = useState<'loading' | 'ready' | 'no-utxos' | 'unavailable'>('loading');
  const [btcAvailabilityMessage, setBtcAvailabilityMessage] = useState('Checking spendable Bitcoin…');
  const [quote, setQuote] = useState<ThorchainQuote | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [step, setStep] = useState<Step>('form');
  const [error, setError] = useState('');
  const [tradingHalted, setTradingHalted] = useState(false);
  const [result, setResult] = useState<{ hash: string; explorerUrl?: string } | null>(null);
  const [swapStatus, setSwapStatus] = useState<ThorchainSwapStatus>('pending');
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [txRecord, setTxRecord] = useState<TxRecord | null>(null);

  const destAsset = THORCHAIN_DEST_ASSETS.find((a) => a.thorId === destAssetId) ?? THORCHAIN_DEST_ASSETS[0];

  useEffect(() => {
    if (!btcAddress) {
      setBtcBalance(null);
      setSpendableBtc(null);
      return;
    }
    let cancelled = false;
    setBtcAvailability('loading');
    setBtcAvailabilityMessage('Checking spendable Bitcoin and current network fee…');
    void Promise.allSettled([fetchBitcoinBalance(btcAddress), estimateBitcoinMaxSend(btcAddress)]).then(([balanceResult, spendableResult]) => {
      if (cancelled) return;
      setBtcBalance(balanceResult.status === 'fulfilled' ? balanceResult.value : null);
      if (spendableResult.status === 'fulfilled') {
        setSpendableBtc(spendableResult.value.amountBtc);
        setBtcAvailability('ready');
        setBtcAvailabilityMessage(`Up to ${spendableResult.value.amountBtc} BTC is available after the estimated network fee.`);
      } else {
        setSpendableBtc(null);
        const message = spendableResult.reason instanceof Error ? spendableResult.reason.message : 'Bitcoin UTXOs are not available yet.';
        const hasNoUtxos = message.toLowerCase().includes('no spendable bitcoin');
        setBtcAvailability(hasNoUtxos ? 'no-utxos' : 'unavailable');
        setBtcAvailabilityMessage(hasNoUtxos ? 'No spendable Bitcoin UTXOs were found. BTC must be received and confirmed before a THORChain swap can be sent.' : message);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [btcAddress]);

  // Debounced quote fetch.
  useEffect(() => {
    setQuote(null);
    setError('');
    setTradingHalted(false);
    let parsed: bigint;
    try {
      parsed = parseExactBaseUnits(amount, 8);
    } catch {
      return;
    }
    if (parsed <= 0n || !destinationAddress) return;
    setQuoting(true);
    const timer = setTimeout(async () => {
      try {
        const q = await getThorchainSwapQuote({ destAsset, destinationAddress, amountBtc: amount });
        setQuote(q);
      } catch (err) {
        setTradingHalted(isThorchainTradingHaltedError(err));
        setError(describeTxError(err));
      } finally {
        setQuoting(false);
      }
    }, 600);
    return () => clearTimeout(timer);
  }, [amount, destAssetId, destinationAddress]);

  // Poll for completion once broadcast, while the "tracking" screen is showing.
  useEffect(() => {
    if (step !== 'tracking' || !result) return;
    const interval = setInterval(async () => {
      const status = await pollThorchainSwapStatus(result.hash);
      setSwapStatus(status);
      if (status === 'completed') {
        updateTxRecord(result.hash, { status: 'confirmed' }, true, 'bitcoin');
        setTxRecord((prev) => (prev ? { ...prev, status: 'confirmed' } : prev));
        notifyForTransaction({
          hash: result.hash,
          networkId: 'bitcoin',
          type: 'bridge',
          status: 'confirmed',
          symbol: 'BTC',
          amount: txRecord?.fromAmount ?? '',
          source: 'local-wallet',
        });
        setStep('done');
        clearInterval(interval);
      }
    }, 15000);
    return () => clearInterval(interval);
  }, [step, result]);

  const insufficientBalance = (() => {
    if (spendableBtc === null) return false;
    try {
      return parseExactBaseUnits(amount, 8) > parseExactBaseUnits(spendableBtc, 8);
    } catch {
      return false;
    }
  })();
  const isPrivateKeyOnly = isActiveWalletPrivateKeyImport();
  const isWatchOnly = isActiveWalletWatchOnly();

  const handleConfirm = async () => {
    if (tradingHalted) {
      setError('THORChain swaps are temporarily paused. No funds were sent.');
      return;
    }
    if (!mnemonic || !quote) {
      setError('Unlock your wallet and get a quote first.');
      return;
    }
    setStep('sending');
    setError('');
    try {
      const res = await executeThorchainSwap({ mnemonic, quote });
      setResult(res);
      const record = addTxRecord({
        type: 'bridge',
        networkId: 'bitcoin',
        toNetworkId: destNetworkId(destAssetId),
        hash: res.hash,
        explorerUrl: res.explorerUrl,
        fromSymbol: 'BTC',
        fromAmount: amount,
        toSymbol: destSymbol(destAssetId),
        toAmount: quote.expectedAmountOutFormatted,
        status: 'pending',
      });
      setTxRecord(record);
      notifyForTransaction({
        hash: res.hash,
        networkId: 'bitcoin',
        type: 'bridge',
        status: 'submitted',
        symbol: 'BTC',
        amount,
        source: 'local-wallet',
      });
      setStep('tracking');
      toast.success('Bitcoin sent to THORChain - swap in progress');
    } catch (err) {
      setError(describeTxError(err));
      setStep('confirm');
    }
  };

  // PIN confirmed - close the sheet and broadcast the real Bitcoin transaction.
  const handleAuthSuccess = () => {
    setShowAuthGate(false);
    handleConfirm();
  };

  const resetForm = () => {
    setAmount('');
    setQuote(null);
    setResult(null);
    setTxRecord(null);
    setError('');
    setSwapStatus('pending');
    setStep('form');
  };

  if (!btcAddress) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
        <AlertTriangle className="w-10 h-10 text-muted-foreground" />
        <p className="text-foreground font-semibold">Bitcoin swap unavailable for this account</p>
        <p className="text-sm text-muted-foreground max-w-xs">
          {isPrivateKeyOnly
            ? 'This wallet was imported from an EVM private key. Private keys cannot derive Bitcoin or Solana addresses. Import or create a recovery-phrase wallet to use BTC Thorchain and Solana.'
            : isWatchOnly
              ? 'This is a watch-only account. Add or switch to a recovery-phrase wallet to activate a Bitcoin address for THORChain.'
              : 'Unlock your recovery-phrase wallet to derive the Bitcoin address needed for a THORChain swap.'}
        </p>
      </div>
    );
  }

  if (step === 'done' && txRecord) {
    return <TransactionReceipt record={txRecord} onClose={resetForm} />;
  }

  if (step === 'tracking') {
    return (
      <div className="max-w-md mx-auto w-full px-6 py-10 text-center space-y-4">
        <Clock className="w-14 h-14 text-amber-400 mx-auto" />
        <h2 className="text-lg font-bold text-foreground">Swap in progress</h2>
        <p className="text-sm text-muted-foreground">
          THORChain is processing your deposit (status: {swapStatus}). This can take several minutes - safe to close
          this screen and check back in History.
        </p>
        {result?.explorerUrl && (
          <a href={result.explorerUrl} target="_blank" rel="noreferrer" className="text-xs text-accent underline break-all">
            View Bitcoin transaction
          </a>
        )}
        <button
          onClick={resetForm}
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-colors mt-4"
        >
          Done
        </button>
      </div>
    );
  }

  if (step === 'confirm' && quote) {
    return (
      <div className="max-w-md mx-auto w-full px-6 py-6 space-y-5">
        <div className="glass-card p-4 space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">You send</span>
            <span className="text-foreground font-semibold">{amount} BTC</span>
          </div>
          <div className="flex justify-center">
            <ArrowRight className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">You receive (est.)</span>
            <span className="text-foreground font-semibold">
              {quote.expectedAmountOutFormatted} {destAsset.label}
            </span>
          </div>
          {quote.totalFeesUsd && (
            <div className="flex items-center justify-between text-xs pt-2 border-t border-border">
              <span className="text-muted-foreground">THORChain network fee</span>
              <span className="text-foreground">~${quote.totalFeesUsd}</span>
            </div>
          )}
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Destination address</span>
            <span className="text-foreground font-mono break-all text-right max-w-[60%]">{destinationAddress}</span>
          </div>
        </div>

        {quote.warning && (
          <p className="flex items-start gap-1.5 text-xs text-amber-400">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            {quote.warning}
          </p>
        )}

        <p className="text-xs text-muted-foreground">
          This sends a real, irreversible Bitcoin transaction to THORChain's vault. Double-check the destination
          address - it must be a real address on {destAsset.label.split('(')[0].trim()} that you control.
        </p>

        {error && <p className="text-xs text-destructive">{error}</p>}

        <div className="flex gap-2">
          <button
            onClick={() => setStep('form')}
            className="flex-1 bg-secondary text-muted-foreground font-semibold text-sm py-3 rounded-lg"
          >
            Back
          </button>
          <button
            onClick={() => setShowAuthGate(true)}
            className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-colors"
          >
            Confirm Swap
          </button>
        </div>

        <TransactionAuthSheet
          open={showAuthGate}
          actionLabel={`Swap ${amount} BTC → ${destSymbol(destAssetId)}`}
          onSuccess={handleAuthSuccess}
          onCancel={() => setShowAuthGate(false)}
        />
      </div>
    );
  }

  if (step === 'sending') {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 px-6 py-16">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
        <p className="text-sm text-muted-foreground">Broadcasting Bitcoin transaction…</p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto w-full px-6 py-6 space-y-5">
      <div className="rounded-3xl border border-white/[0.09] bg-gradient-to-br from-white/[0.05] to-transparent p-4 shadow-[0_18px_50px_rgba(0,0,0,0.16)]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-accent/80">Cross-chain route</p>
            <p className="mt-1 text-base font-semibold text-foreground">BTC via THORChain</p>
          </div>
          <span className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">BTC → EVM</span>
        </div>
        <p className="mt-3 text-xs leading-5 text-muted-foreground">Send real Bitcoin to a THORChain vault and receive the selected asset on its destination network. Bitcoin confirmations can take several minutes.</p>
      </div>

      {tradingHalted && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-300/20 bg-amber-300/[0.07] p-4">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-300/10 text-amber-200">!</span>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-amber-200">THORChain maintenance</p>
            <p className="mt-1 text-sm leading-5 text-amber-100/75">Trading is temporarily paused upstream. Your wallet is safe and no Bitcoin has been sent. Quotes will be available again when the route resumes.</p>
          </div>
        </div>
      )}

      <div className="space-y-1.5">
        <p className="text-xs font-medium text-muted-foreground px-1">
          You send (spendable BTC after fee: {spendableBtc !== null ? spendableBtc : btcBalance !== null ? `${btcBalance} total` : 'checking…'})
        </p>
        <input
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="0.001"
          inputMode="decimal"
          className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground outline-none focus:border-accent/50"
        />
        {btcAvailability !== 'ready' && <p className={`text-xs ${btcAvailability === 'loading' ? 'text-muted-foreground' : 'text-amber-400'}`}>{btcAvailabilityMessage}</p>}
        {insufficientBalance && <p className="text-xs text-destructive">This amount is above the spendable BTC limit after the estimated network fee.</p>}
      </div>

      <div className="space-y-1.5">
        <p className="text-xs font-medium text-muted-foreground px-1">You receive</p>
        <select
          value={destAssetId}
          onChange={(e) => setDestAssetId(e.target.value)}
          className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground outline-none focus:border-accent/50"
        >
          {THORCHAIN_DEST_ASSETS.map((a) => (
            <option key={a.thorId} value={a.thorId}>
              {a.label}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-1.5">
        <p className="text-xs font-medium text-muted-foreground px-1">Destination address</p>
        <input
          value={destinationAddress}
          onChange={(e) => setDestinationAddress(e.target.value)}
          placeholder="0x..."
          className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground font-mono outline-none focus:border-accent/50"
        />
        <p className="text-[11px] text-muted-foreground">
          Defaults to your own Paxi wallet address on that chain - change only if sending elsewhere.
        </p>
      </div>

      {error && !tradingHalted && <p className="rounded-2xl border border-red-400/20 bg-red-400/[0.07] p-3.5 text-sm leading-5 text-red-100/75">{error}</p>}

      <button
        onClick={() => quote && setStep('confirm')}
        disabled={!quote || quoting || insufficientBalance || btcAvailability !== 'ready' || tradingHalted}
        className="w-full rounded-2xl bg-accent py-3.5 text-sm font-semibold text-accent-foreground shadow-[0_14px_30px_rgba(245,158,11,0.16)] transition-colors hover:bg-accent/90 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {quoting ? 'Getting quote…' : quote ? 'Review Swap' : 'Enter an amount'}
      </button>
    </div>
  );
}
