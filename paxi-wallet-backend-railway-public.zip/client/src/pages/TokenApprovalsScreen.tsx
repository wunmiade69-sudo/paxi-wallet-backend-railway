import { ArrowLeft, ShieldAlert } from 'lucide-react';
import { getTokenApprovals } from '@/lib/phase3Local';

export default function TokenApprovalsScreen({ onBack }: { onBack: () => void }) {
  const approvals = getTokenApprovals();
  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground" aria-label="Back"><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="text-lg font-bold text-accent">Token Approvals</h1>
        </div>
      </div>
      <main className="max-w-md mx-auto px-6 py-6 space-y-4">
        <div className="glass-card p-4 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-yellow-400 mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">Approval data is security-sensitive. PAXI will only show records returned by a validated EVM scanner; it will not label an approval as dangerous without a validated signal.</p>
        </div>
        {approvals.length === 0 ? (
          <div className="glass-card p-8 text-center space-y-3">
            <p className="font-semibold text-foreground">Approval scanning unavailable</p>
            <p className="text-sm text-muted-foreground">No approval records were loaded. Revoke transactions are not enabled from this screen.</p>
          </div>
        ) : approvals.map((approval) => (
          <div key={approval.id} className="glass-card p-4 space-y-2">
            <div className="flex justify-between gap-3"><span className="font-semibold text-foreground">{approval.token}</span><span className="text-xs text-muted-foreground">{approval.network}</span></div>
            <p className="text-xs text-muted-foreground">Spender: <span className="font-mono text-foreground">{approval.spender}</span></p>
            <p className="text-xs text-muted-foreground">Allowance: <span className="text-foreground">{approval.allowance ?? '—'}</span></p>
            <p className="text-xs text-muted-foreground">Risk: <span className="text-foreground">{approval.risk}</span></p>
          </div>
        ))}
      </main>
    </div>
  );
}
