import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, ArrowLeft, CheckCircle2, ExternalLink, Loader2, ShieldAlert, ShieldCheck } from 'lucide-react';
import { isAddress } from 'ethers';
import { toast } from 'sonner';
import { getTokenApprovals } from '@/lib/phase3Local';
import { NETWORKS } from '@/lib/wallet/chains';
import { getStoredAddress, getUnlockedMnemonic } from '@/lib/wallet/vault';
import { estimateApprovalRevoke, revokeErc20Approval } from '@/lib/wallet/revokeApproval';
import { waitForEvmConfirmation } from '@/lib/wallet/send';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';

const EVM_NETWORKS = Object.values(NETWORKS).filter((network) => network.chainType === 'evm');

type RevokeState = 'idle' | 'review' | 'sending' | 'done';

export default function TokenApprovalsScreen({ onBack }: { onBack: () => void }) {
  const approvals = getTokenApprovals();
  const [networkId, setNetworkId] = useState(EVM_NETWORKS[0]?.id ?? 'ethereum');
  const [tokenAddress, setTokenAddress] = useState('');
  const [spender, setSpender] = useState('');
  const [networkFee, setNetworkFee] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [state, setState] = useState<RevokeState>('idle');
  const [authOpen, setAuthOpen] = useState(false);
  const [txHash, setTxHash] = useState('');
  const [txExplorerUrl, setTxExplorerUrl] = useState<string | undefined>();
  const [checking, setChecking] = useState(false);
  const walletAddress = getStoredAddress() ?? '';
  const network = NETWORKS[networkId];
  const mnemonic = getUnlockedMnemonic();

  const canReview = useMemo(() => Boolean(
    mnemonic && walletAddress && network?.chainType === 'evm' && isAddress(tokenAddress.trim()) && isAddress(spender.trim()),
  ), [mnemonic, network, spender, tokenAddress, walletAddress]);

  useEffect(() => {
    let cancelled = false;
    if (!canReview) {
      setNetworkFee(null);
      return;
    }
    setChecking(true);
    estimateApprovalRevoke({ network: networkId, owner: walletAddress, tokenAddress: tokenAddress.trim(), spender: spender.trim() })
      .then((estimate) => {
        if (!cancelled) setNetworkFee(estimate?.networkFeeNative ?? null);
      })
      .finally(() => {
        if (!cancelled) setChecking(false);
      });
    return () => { cancelled = true; };
  }, [canReview, networkId, spender, tokenAddress, walletAddress]);

  const validate = (): boolean => {
    setError('');
    if (!mnemonic) {
      setError('Unlock your wallet before revoking an approval.');
      return false;
    }
    if (!network || network.chainType !== 'evm') {
      setError('Approval revocation is only available on EVM networks.');
      return false;
    }
    if (!isAddress(tokenAddress.trim())) {
      setError('Enter a valid ERC-20 token contract address.');
      return false;
    }
    if (!isAddress(spender.trim())) {
      setError('Enter a valid spender contract address.');
      return false;
    }
    return true;
  };

  const handleReview = () => {
    if (validate()) setState('review');
  };

  const handleRevoke = async () => {
    if (!validate() || !mnemonic) return;
    setState('sending');
    try {
      const result = await revokeErc20Approval({
        mnemonic,
        network: networkId,
        tokenAddress: tokenAddress.trim(),
        spender: spender.trim(),
      });
      setTxHash(result.hash);
      setTxExplorerUrl(result.explorerUrl);
      try {
        await waitForEvmConfirmation({ network: networkId, hash: result.hash, timeoutMs: 180_000 });
      } catch (confirmationError) {
        // The transaction was already broadcast. Keep the hash and make the status uncertainty explicit.
        setError(confirmationError instanceof Error ? confirmationError.message : 'The revoke was broadcast, but confirmation is still pending.');
      }
      setState('done');
      toast.success('Approval revoked on-chain');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The approval could not be revoked.');
      setState('review');
    }
  };

  const reset = () => {
    setState('idle');
    setError('');
    setTxHash('');
    setTxExplorerUrl(undefined);
    setNetworkFee(null);
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button type="button" onClick={onBack} className="min-h-11 text-muted-foreground hover:text-foreground" aria-label="Back"><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="text-lg font-bold text-accent">Token Approvals</h1>
        </div>
      </div>
      <main className="max-w-md mx-auto px-6 py-6 space-y-4">
        <div className="glass-card p-4 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-yellow-400 mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">Approvals let smart contracts move tokens from your wallet. Revoke only the spender you intend to remove. Revoking costs network gas and does not undo transactions already completed.</p>
        </div>

        {approvals.length > 0 && approvals.map((approval) => (
          <div key={approval.id} className="glass-card p-4 space-y-3">
            <div className="flex justify-between gap-3"><span className="font-semibold text-foreground">{approval.token}</span><span className="text-xs text-muted-foreground">{approval.network}</span></div>
            <p className="text-xs text-muted-foreground">Spender: <span className="font-mono text-foreground">{approval.spender}</span></p>
            <p className="text-xs text-muted-foreground">Allowance: <span className="text-foreground">{approval.allowance ?? '—'}</span></p>
            <button type="button" onClick={() => { setTokenAddress(approval.contract); setSpender(approval.spender); setNetworkId(approval.network); }} className="min-h-11 rounded-xl bg-accent px-3 py-2 text-xs font-semibold text-accent-foreground">Review revoke</button>
          </div>
        ))}

        <section className="glass-card p-4 space-y-4" aria-labelledby="revoke-known-title">
          <div>
            <p id="revoke-known-title" className="flex items-center gap-2 font-semibold text-foreground"><ShieldCheck className="h-4 w-4 text-accent" /> Revoke a known approval</p>
            <p className="mt-1 text-xs text-muted-foreground">Approval scanning is not available yet. If you have verified the token and spender addresses from a trusted explorer or scanner, you can revoke the allowance here by setting it to zero.</p>
          </div>
          <label className="block text-xs text-muted-foreground">Network<select value={networkId} onChange={(event) => setNetworkId(event.target.value)} disabled={state !== 'idle'} className="paxi-field mt-1.5 w-full text-foreground"><option value="">Choose network</option>{EVM_NETWORKS.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select></label>
          <label className="block text-xs text-muted-foreground">Token contract<input value={tokenAddress} onChange={(event) => setTokenAddress(event.target.value)} disabled={state !== 'idle'} placeholder="0x…" spellCheck={false} className="paxi-field mt-1.5 w-full font-mono text-sm text-foreground" /></label>
          <label className="block text-xs text-muted-foreground">Spender contract<input value={spender} onChange={(event) => setSpender(event.target.value)} disabled={state !== 'idle'} placeholder="0x…" spellCheck={false} className="paxi-field mt-1.5 w-full font-mono text-sm text-foreground" /></label>

          {error && <p className="paxi-alert-error rounded-xl p-3 text-sm" role="alert">{error}</p>}

          {state === 'idle' && <button type="button" onClick={handleReview} disabled={!canReview} className="min-h-12 w-full rounded-xl bg-accent py-3 font-semibold text-accent-foreground disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground">Review revoke</button>}

          {state === 'review' && (
            <div className="space-y-3 rounded-xl border border-amber-400/25 bg-amber-400/10 p-3">
              <div className="flex items-start gap-2"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /><p className="text-xs text-amber-100">This will submit `approve(spender, 0)` for the token contract. It removes the spender's allowance on {network.label}; it does not transfer or recover tokens.</p></div>
              <div className="space-y-1 text-xs text-muted-foreground"><p>Token: <span className="font-mono text-foreground">{tokenAddress}</span></p><p>Spender: <span className="font-mono text-foreground">{spender}</span></p><p>Network fee: <span className="text-foreground">{checking ? 'Estimating…' : networkFee ? `${networkFee} ${network.nativeSymbol}` : 'Estimate unavailable'}</span></p></div>
              <div className="flex gap-2"><button type="button" onClick={reset} className="min-h-11 flex-1 rounded-xl border border-border bg-secondary py-2 text-sm font-semibold text-foreground">Edit</button><button type="button" onClick={() => setAuthOpen(true)} className="min-h-11 flex-1 rounded-xl bg-accent py-2 text-sm font-semibold text-accent-foreground">Revoke approval</button></div>
            </div>
          )}

          {state === 'sending' && <div className="flex items-center justify-center gap-2 rounded-xl border border-border bg-secondary p-4 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Broadcasting revoke transaction…</div>}

          {state === 'done' && <div className="space-y-3 rounded-xl border border-emerald-400/25 bg-emerald-400/10 p-3"><div className="flex items-center gap-2 text-sm font-semibold text-emerald-300"><CheckCircle2 className="h-4 w-4" /> Revoke transaction broadcast</div><p className="break-all font-mono text-xs text-muted-foreground">{txHash}</p>{txExplorerUrl && <a href={txExplorerUrl} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-accent">View on explorer <ExternalLink className="h-3.5 w-3.5" /></a>}<button type="button" onClick={reset} className="min-h-11 w-full rounded-xl border border-border bg-secondary py-2 text-sm font-semibold text-foreground">Revoke another approval</button></div>}
        </section>
      </main>
      <TransactionAuthSheet open={authOpen} actionLabel={`Revoke token approval on ${network.label}`} onSuccess={() => { setAuthOpen(false); void handleRevoke(); }} onCancel={() => setAuthOpen(false)} />
    </div>
  );
}
