import { useEffect, useState } from 'react';
import { ArrowLeft, Globe, ExternalLink, TrendingUp, TrendingDown, Loader2, Copy, Check, PlusCircle, BadgeCheck, AlertTriangle, Star } from 'lucide-react';
import ProfessionalMarketChart, { ChartLoadingState, ChartUnavailableState } from '@/components/ProfessionalMarketChart';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { ASSETS, NETWORKS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { formatFiat, formatFiatCompact, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { getTrustedMarketLabel } from '@/lib/appInfo';
import AssetLogo from '@/components/AssetLogo';
import { canonicalMarketIdentityKey, canonicalNativeIdentityKey } from '@/lib/marketIdentity';
import { isMarketWatchlisted, marketWatchlistKey, toggleMarketWatchlist } from '@/lib/marketWatchlist';

export interface TokenDetailSelection {
  coinId: string | null;
  chain: string | null;
  contractAddress: string | null;
  symbol: string;
  name: string;
}

interface TokenDetailScreenProps {
  tokenIdentity: TokenDetailSelection;
  onBack: () => void;
  onAddToWallet: (networkId: string, contractAddress: string) => void;
}

/** CoinGecko's platform slug (from TokenDetail.platformId) -> this wallet's own network id.
 * Only chains this wallet actually supports importing tokens on are listed - an unlisted
 * platform (e.g. a chain we don't support yet) just means no "Add to Wallet" button shows. */
const PLATFORM_TO_NETWORK: Record<string, string> = {
  ethereum: 'ethereum',
  'binance-smart-chain': 'bsc',
  bsc: 'bsc',
  'polygon-pos': 'polygon',
  polygon: 'polygon',
  'arbitrum-one': 'arbitrum',
  arbitrum: 'arbitrum',
  solana: 'solana',
};

type Timeframe = '1H' | '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL';
type DetailTab = 'chart' | 'stats' | 'security';
const TIMEFRAMES: Timeframe[] = ['1H', '1D', '1W', '1M', '3M', '1Y', 'ALL'];
const PROVIDER_LABELS: Record<string, string> = {
  coingecko: 'CoinGecko',
  dexpaprika: 'DexPaprika',
  birdeye: 'Birdeye',
};

function marketSourceLabel(sources: string[] | undefined, fallback: string | undefined): string {
  const names = Array.from(new Set((sources?.length ? sources : fallback ? [fallback] : []).map((source) => PROVIDER_LABELS[source] ?? source)));
  return names.length ? names.join(' + ') : 'Unavailable';
}

/**
 * Read-only market detail for any CoinGecko-listed token, including ones
 * this wallet doesn't hold - complements AssetDetailScreen (which is for
 * wallet-held assets with send/receive/swap). Real data throughout;
 * no fabricated numbers.
 */
export default function TokenDetailScreen({ tokenIdentity, onBack, onAddToWallet }: TokenDetailScreenProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [detailTab, setDetailTab] = useState<DetailTab>('chart');
  const [addressCopied, setAddressCopied] = useState(false);
  const [isWatchlisted, setIsWatchlisted] = useState(false);
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  const marketInput = {
    chain: tokenIdentity.chain ?? undefined,
    contractAddress: tokenIdentity.contractAddress ?? undefined,
    coinId: tokenIdentity.coinId ?? undefined,
  };
  const { data: token, isLoading: loadingToken } = trpc.market.detail.useQuery(marketInput);
  // market.detail resolves an ambiguous identity (coinId only, e.g. from the
  // general Markets list) to a real chain + contract address via CoinGecko's
  // platform data. market.chart must target that SAME resolved identity -
  // querying it with the original ambiguous input independently made it
  // fall back to CoinGecko's coin-level aggregate chart instead of the
  // specific on-chain token's chart, which is what looked like "the wrong
  // chart" after tapping a searched/listed token.
  const chartInput = {
    chain: token?.chain ?? marketInput.chain,
    contractAddress: token?.contractAddress ?? marketInput.contractAddress,
    coinId: token?.coinId ?? token?.id ?? marketInput.coinId,
    timeframe,
  };
  const { data: chartData, isLoading: loadingChart } = trpc.market.chart.useQuery(chartInput, { enabled: !loadingToken });
  const securityNetworks = ['ethereum', 'bsc', 'polygon', 'arbitrum', 'base'] as const;
  const securityEnabled = token?.contractAddress != null && securityNetworks.includes(token.chain as typeof securityNetworks[number]);
  const securityNetwork = securityNetworks.includes(token?.chain as typeof securityNetworks[number]) ? token!.chain as typeof securityNetworks[number] : 'ethereum';
  const { data: securityReport, isLoading: loadingSecurity } = trpc.security.checkContract.useQuery(
    { network: securityNetwork, contractAddress: token?.contractAddress ?? '0x0000000000000000000000000000000000000000' },
    { enabled: securityEnabled },
  );
  // Cross-exchange reference price (Binance/OKX/Gate.io/Bybit/KuCoin median) -
  // only meaningful for a chain's own native coin, which is what those
  // exchanges list directly.
  const { data: cexReference } = trpc.market.cexReference.useQuery(
    { chain: token?.chain ?? '' },
    { enabled: Boolean(token?.chain) && token?.identifier === 'native' },
  );

  const points = (chartData?.points ?? []).map((point) => ({
    ...point,
    price: point.close ?? undefined,
  }));
  const priceChange24h = token?.priceChangePercent24h ?? null;
  const isUp = priceChange24h != null && priceChange24h >= 0;
  const logoCacheKey = token?.chain && token.contractAddress
    ? canonicalMarketIdentityKey(token.chain, token.contractAddress)
    : token?.chain
      ? canonicalNativeIdentityKey(token.chain)
      : `market:${token?.id ?? tokenIdentity.symbol}`;
  const watchlistKey = token ? marketWatchlistKey({ chain: token.chain, contractAddress: token.contractAddress, coinId: token.coinId ?? token.id, identifier: token.identifier }) : null;

  useEffect(() => {
    setIsWatchlisted(isMarketWatchlisted(watchlistKey));
  }, [watchlistKey]);

  const toggleWatchlist = () => {
    if (!token || !watchlistKey) return;
    toggleMarketWatchlist({
      key: watchlistKey,
      symbol: token.symbol,
      name: token.name,
      chain: token.chain,
      contractAddress: token.contractAddress,
      coinId: token.coinId ?? token.id,
      image: token.image,
    });
    setIsWatchlisted(isMarketWatchlisted(watchlistKey));
  };

  const importNetworkId = token?.chain ? PLATFORM_TO_NETWORK[token.chain] ?? token.chain : token?.platformId ? PLATFORM_TO_NETWORK[token.platformId] : undefined;
  const alreadyHeld = Boolean(
    token?.contractAddress &&
      importNetworkId &&
      [...ASSETS, ...getCustomTokens().map(customTokenToAsset)].some(
        (a) => a.network === importNetworkId && a.contractAddress &&
          (['ethereum', 'bsc', 'polygon', 'arbitrum'].includes(importNetworkId)
            ? a.contractAddress.toLowerCase() === token.contractAddress!.toLowerCase()
            : a.contractAddress === token.contractAddress)
      )
  );

  const handleCopyAddress = () => {
    if (!token?.contractAddress) return;
    navigator.clipboard.writeText(token.contractAddress);
    setAddressCopied(true);
    toast.success('Contract address copied');
    setTimeout(() => setAddressCopied(false), 2000);
  };

  if (loadingToken) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-accent animate-spin" />
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <div className="w-12 h-12 rounded-full bg-destructive/10 border border-destructive/25 flex items-center justify-center mb-3">
          <AlertTriangle className="w-5 h-5 text-destructive" />
        </div>
        <p className="text-foreground font-semibold">Couldn't load this token</p>
        <button onClick={onBack} className="text-accent text-sm mt-3 font-medium">
          Go back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button type="button" onClick={onBack} className="paxi-icon-button shrink-0 text-muted-foreground hover:text-foreground" aria-label="Back to markets">
            <ArrowLeft className="w-5 h-5" aria-hidden={true} />
          </button>
          <AssetLogo src={token.image} alt={token.symbol} fallback={(token.symbol || tokenIdentity.symbol).slice(0, 3)} size="sm" cacheKey={logoCacheKey} />
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-bold text-foreground">{token.symbol || tokenIdentity.symbol}</h1>
            <p className="truncate text-[10px] text-muted-foreground">{token.name || 'Market asset'}</p>
          </div>
          <button
            type="button"
            onClick={toggleWatchlist}
            disabled={!watchlistKey}
            aria-label={isWatchlisted ? `Remove ${token.symbol} from watchlist` : `Add ${token.symbol} to watchlist`}
            aria-pressed={isWatchlisted}
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-colors ${isWatchlisted ? 'bg-amber-400/15 text-amber-300' : 'text-muted-foreground hover:bg-foreground/5 hover:text-foreground'} disabled:cursor-not-allowed disabled:opacity-30`}
          >
            <Star className={`h-4 w-4 ${isWatchlisted ? 'fill-current' : ''}`} aria-hidden={true} />
          </button>
        </div>
      </div>

      <main className="mx-auto max-w-xl space-y-6 px-5 py-6 sm:px-6">
        <section className="relative overflow-hidden rounded-3xl border border-accent/20 bg-gradient-to-br from-accent/15 via-card to-card p-5 shadow-sm" aria-labelledby="token-market-title">
          <div className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-accent/15 blur-3xl" aria-hidden={true} />
          <div className="relative flex items-start justify-between gap-4">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-accent">Market overview</p>
              <h2 id="token-market-title" className="mt-2 text-3xl font-semibold tracking-tight text-foreground tabular-nums">
                {formatFiat(token.currentPrice, currency, fiatRate)}
              </h2>
              <p className="mt-1 text-xs text-muted-foreground">{marketSourceLabel(token.sources, token.source)} · {token.chain ? NETWORKS[token.chain]?.label ?? token.chain : 'Provider market data'}</p>
              {cexReference && (
                <p className="mt-0.5 text-xs text-muted-foreground">
                  CEX ref: {formatFiat(cexReference.medianPriceUsd, currency, fiatRate)} ({cexReference.sourceCount} exchanges)
                </p>
              )}
            </div>
            <div className={`flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1.5 text-xs font-semibold ${priceChange24h == null ? 'border-border/70 bg-secondary/70 text-muted-foreground' : isUp ? 'border-emerald-400/20 bg-emerald-400/10 text-emerald-400' : 'border-red-400/20 bg-red-400/10 text-red-400'}`}>
              {priceChange24h == null ? null : isUp ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
              {priceChange24h != null ? `${isUp ? '+' : ''}${priceChange24h.toFixed(2)}%` : '—'}
            </div>
          </div>
          <div className="relative mt-5 grid grid-cols-3 gap-2 border-t border-foreground/10 pt-4">
            <MiniMetric label="Market cap" value={formatFiatCompact(token.marketCap, currency, fiatRate)} />
            <MiniMetric label="Volume 24H" value={formatFiatCompact(token.volume24h, currency, fiatRate)} />
            <MiniMetric label="Liquidity" value={token.liquidity != null ? formatFiatCompact(token.liquidity, currency, fiatRate) : '—'} />
          </div>
        </section>


        <div className="flex gap-1 rounded-xl border border-border/70 bg-secondary/70 p-1" role="tablist" aria-label="Token detail views">
          {(['chart', 'stats', 'security'] as DetailTab[]).map((view) => (
            <button
              key={view}
              type="button"
              role="tab"
              aria-selected={detailTab === view}
              onClick={() => setDetailTab(view)}
              className={`min-h-11 flex-1 rounded-lg px-2 py-2 text-xs font-semibold capitalize transition-colors sm:text-sm ${detailTab === view ? 'bg-accent text-accent-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
            >
              {view}
            </button>
          ))}
        </div>

        {detailTab === 'chart' && <>
        <section className="glass-card overflow-hidden !p-0" aria-labelledby="price-chart-title">
          <div className="flex items-center justify-between gap-3 border-b border-foreground/10 px-4 py-3.5">
            <div>
              <h3 id="price-chart-title" className="text-sm font-semibold text-foreground">Price action</h3>
              <p className="mt-0.5 text-[10px] text-muted-foreground">{points.length > 1 ? `${points.length} provider points` : 'Historical market data'}</p>
            </div>
            <span className="inline-flex items-center gap-1.5 text-[10px] font-medium text-muted-foreground">
              <span className={`h-1.5 w-1.5 rounded-full ${loadingChart ? 'bg-amber-300' : chartData?.points && points.length > 1 ? 'bg-emerald-400' : 'bg-muted-foreground'}`} aria-hidden={true} />
              {loadingChart ? 'Updating' : chartData?.points && points.length > 1 ? 'Live source' : 'Unavailable'}
            </span>
          </div>
          <div className="min-h-48 px-2 pb-2 pt-1">
            {loadingChart ? (
              <ChartLoadingState height={220} />
            ) : chartData?.points == null || points.length < 2 ? (
              <ChartUnavailableState height={220} message="Historical chart unavailable for this asset." />
            ) : (
              <ProfessionalMarketChart
                data={points}
                positive={isUp}
                source={marketSourceLabel(token.sources, token.source)}
                livePrice={token.currentPrice}
                height={220}
              />
            )}
          </div>
        </section>

        <div className="flex items-center gap-2 overflow-x-auto rounded-2xl border border-border/70 bg-secondary/55 p-1" role="tablist" aria-label="Chart timeframe">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              type="button"
              role="tab"
              aria-selected={timeframe === tf}
              onClick={() => setTimeframe(tf)}
              className={`min-h-10 flex-1 shrink-0 rounded-xl px-3 py-1.5 text-xs font-semibold transition-colors ${
                timeframe === tf ? 'bg-accent text-accent-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
        </>}

        {detailTab === 'stats' && <>
        <div className="glass-card p-4 grid grid-cols-2 gap-4">
          <Stat label="Market Cap" value={formatFiatCompact(token.marketCap, currency, fiatRate)} />
          <Stat label="Liquidity" value={token.liquidity != null ? formatFiatCompact(token.liquidity, currency, fiatRate) : 'Liquidity unavailable'} />
          <Stat label="Volume (24H)" value={formatFiatCompact(token.volume24h, currency, fiatRate)} />
          <Stat label="Circulating Supply" value={token.circulatingSupply != null ? formatCompact(token.circulatingSupply) : '—'} />
          <Stat label="Max Supply" value={token.maxSupply != null ? formatCompact(token.maxSupply) : '—'} />
        </div>

        {token.description && detailTab === 'stats' && (
          <div className="glass-card p-4">
            <p className="text-sm font-semibold text-foreground mb-1.5">About {token.name}</p>
            <p className="text-xs text-muted-foreground leading-relaxed">{token.description}</p>
          </div>
        )}

        </>}

        {token.contractAddress && detailTab === 'security' && (
          <div className="glass-card p-4">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs text-muted-foreground">
                Contract Address {importNetworkId && `(${NETWORKS[importNetworkId]?.label ?? importNetworkId})`}
              </p>
              <button
                onClick={handleCopyAddress}
                className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                aria-label="Copy contract address"
              >
                {addressCopied ? <Check className="w-3.5 h-3.5 text-accent" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <p className="text-xs font-mono text-foreground break-all">{token.contractAddress}</p>
            <p className="text-[10px] text-muted-foreground mt-2">
              Market data: {getTrustedMarketLabel({ id: token.id, symbol: token.symbol, name: token.name }) ?? 'Not verified'} · Source: {marketSourceLabel(token.sources, token.source)} · Security check:{' '}
              {loadingSecurity ? 'Checking' : securityReport ? `${securityReport.riskLevel} risk indicators (multi-provider)` : 'Not available'}
            </p>

            {securityReport && (
              <div className="mt-3 grid grid-cols-2 gap-2 rounded-lg border border-border/60 bg-secondary/40 p-3 text-[11px]">
                <SecurityFact label="Contract source" value={securityReport.checks.verifiedContract === true ? 'Verified' : securityReport.checks.verifiedContract === false ? 'Not verified' : 'Unknown'} />
                <SecurityFact label="Honeypot check" value={securityReport.checks.noHoneypot === true ? 'No issue reported' : securityReport.checks.noHoneypot === false ? 'Risk reported' : 'Unknown'} />
                <SecurityFact label="Liquidity lock" value={securityReport.checks.liquidityLocked === true ? 'Reported locked' : securityReport.checks.liquidityLocked === false ? 'Not reported locked' : 'Unknown'} />
                <SecurityFact label="Buy / sell tax" value={securityReport.buyTaxPercent != null || securityReport.sellTaxPercent != null ? `${securityReport.buyTaxPercent?.toFixed(2) ?? '—'}% / ${securityReport.sellTaxPercent?.toFixed(2) ?? '—'}%` : 'Unavailable'} />
                {securityReport.secondary && <SecurityFact label="Honeypot.is" value={securityReport.secondary.honeypotIsHoneypot === true ? 'Risk reported' : securityReport.secondary.honeypotIsHoneypot === false ? 'No honeypot reported' : 'Unavailable'} />}
                {securityReport.secondary && <SecurityFact label="Chainabuse" value={securityReport.secondary.chainabuseReportCount == null ? 'Unavailable' : securityReport.secondary.chainabuseReportCount > 0 ? `${securityReport.secondary.chainabuseReportCount} report(s)` : 'No reports found'} />}
              </div>
            )}

            {importNetworkId && (
              <div className="mt-3 pt-3 border-t border-white/5">
                {alreadyHeld ? (
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-accent">
                    <BadgeCheck className="w-3.5 h-3.5" />
                    Already in your wallet
                  </p>
                ) : (
                  <button
                    onClick={() => onAddToWallet(importNetworkId, token.contractAddress!)}
                    className="flex items-center gap-1.5 text-xs font-semibold text-accent hover:text-accent/80 transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    Add to Wallet
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {detailTab === 'security' && !token.contractAddress && (
          <div className="glass-card border border-border/70 p-4">
            <p className="text-sm font-semibold text-foreground">Security check unavailable</p>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">No contract identity was returned for this asset. Market data alone does not verify this token or establish that it is safe.</p>
          </div>
        )}

        <div className="flex gap-3">
          {token.homepage && (
            <a
              href={token.homepage}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-sm font-semibold py-2.5 rounded-lg transition-colors"
            >
              <Globe className="w-4 h-4" /> Website
            </a>
          )}
          {token.explorerUrl && (
            <a
              href={token.explorerUrl}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-sm font-semibold py-2.5 rounded-lg transition-colors"
            >
              <ExternalLink className="w-4 h-4" /> Explorer
            </a>
          )}
        </div>
      </main>
    </div>
  );
}

function SecurityFact({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-semibold text-foreground">{value}</p>
    </div>
  );
}

function MiniMetric({ label, value }: { label: string; value: string }) {
  return <div className="min-w-0"><p className="truncate text-[10px] text-muted-foreground">{label}</p><p className="mt-1 truncate text-xs font-semibold tabular-nums text-foreground">{value}</p></div>;
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold text-foreground mt-0.5">{value}</p>
    </div>
  );
}

function formatCompact(n: number): string {
  return n.toLocaleString(undefined, { notation: 'compact', maximumFractionDigits: 2 });
}
