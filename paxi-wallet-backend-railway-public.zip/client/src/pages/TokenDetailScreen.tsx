import { useState } from "react";
import {
  ArrowLeft,
  Globe,
  ExternalLink,
  TrendingUp,
  TrendingDown,
  Loader2,
  Copy,
  Check,
  PlusCircle,
  BadgeCheck,
  AlertTriangle,
} from "lucide-react";
import ProfessionalMarketChart from "@/components/ProfessionalMarketChart";
import VerifiedBadge from "@/components/VerifiedBadge";
import {
  getTrustedMarketLabel,
  isOfficialPaxiToken,
  PAXI_LOGO_URL,
} from "@/lib/appInfo";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { ASSETS, NETWORKS } from "@/lib/wallet/chains";
import { customTokenToAsset, getCustomTokens } from "@/lib/wallet/customTokens";

interface TokenDetailScreenProps {
  coinId: string;
  onBack: () => void;
  onAddToWallet: (networkId: string, contractAddress: string) => void;
}

/** CoinGecko's platform slug (from TokenDetail.platformId) -> this wallet's own network id.
 * Only chains this wallet actually supports importing tokens on are listed - an unlisted
 * platform (e.g. a chain we don't support yet) just means no "Add to Wallet" button shows. */
const PLATFORM_TO_NETWORK: Record<string, string> = {
  ethereum: "ethereum",
  "binance-smart-chain": "bsc",
  "polygon-pos": "polygon",
  "arbitrum-one": "arbitrum",
  solana: "solana",
};

type Timeframe = "1H" | "1D" | "1W" | "1M" | "1Y" | "ALL";
const TIMEFRAMES: Timeframe[] = ["1H", "1D", "1W", "1M", "1Y", "ALL"];

/**
 * Read-only market detail for any CoinGecko-listed token, including ones
 * this wallet doesn't hold - complements AssetDetailScreen (which is for
 * wallet-held assets with send/receive/swap). Real data throughout;
 * no fabricated numbers.
 */
export default function TokenDetailScreen({
  coinId,
  onBack,
  onAddToWallet,
}: TokenDetailScreenProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>("1D");
  const [addressCopied, setAddressCopied] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  const [canonicalChainId, canonicalContractAddress] = coinId.includes(":")
    ? coinId.split(":", 2)
    : [undefined, undefined];

  const legacyTokenQuery = trpc.market.detail.useQuery(
    { coinId },
    { enabled: !canonicalChainId, refetchInterval: 15_000, staleTime: 10_000 }
  );
  const canonicalTokenQuery = trpc.market.detailByIdentity.useQuery(
    {
      chainId: canonicalChainId ?? "unknown",
      contractAddress: canonicalContractAddress ?? "unknown",
    },
    {
      enabled: Boolean(canonicalChainId && canonicalContractAddress),
      refetchInterval: 15_000,
      staleTime: 10_000,
    }
  );
  const token = canonicalTokenQuery.data
    ? {
        id: canonicalTokenQuery.data.id,
        name: canonicalTokenQuery.data.name,
        symbol: canonicalTokenQuery.data.symbol,
        image: canonicalTokenQuery.data.logoUrl ?? "",
        currentPrice: canonicalTokenQuery.data.priceUsd,
        priceChangePercent24h: canonicalTokenQuery.data.change24h,
        marketCap: canonicalTokenQuery.data.marketCapUsd,
        volume24h: canonicalTokenQuery.data.volume24hUsd,
        circulatingSupply: null,
        maxSupply: null,
        description: null,
        homepage: null,
        explorerUrl: canonicalTokenQuery.data.explorerUrl,
        contractAddress:
          canonicalTokenQuery.data.contractAddress === "native"
            ? null
            : canonicalTokenQuery.data.contractAddress,
        platformId: canonicalTokenQuery.data.chainId,
        discoveryTrust: canonicalTokenQuery.data.trust,
        security: canonicalTokenQuery.data.security,
        freshness: canonicalTokenQuery.data.dataFreshness,
      }
    : legacyTokenQuery.data;
  const loadingToken =
    legacyTokenQuery.isLoading || canonicalTokenQuery.isLoading;

  const importNetworkId =
    canonicalChainId ??
    (token?.platformId
      ? (PLATFORM_TO_NETWORK[token.platformId] ?? token.platformId)
      : undefined);
  const livePriceQuery = trpc.market.assetPrice.useQuery(
    {
      network: importNetworkId ?? "unknown",
      contractAddress: token?.contractAddress ?? "unknown",
      symbol: token?.symbol,
    },
    {
      enabled: Boolean(importNetworkId && token?.contractAddress),
      refetchInterval: 15_000,
      staleTime: 10_000,
    }
  );
  const {
    data: chartData,
    isLoading: loadingChart,
    error: chartError,
    refetch: refetchChart,
  } = trpc.market.chart.useQuery(
    { coinId: canonicalChainId ? "" : coinId, timeframe },
    { enabled: !canonicalChainId, refetchInterval: 30_000, staleTime: 15_000 }
  );

  const isUp = (token?.priceChangePercent24h ?? 0) >= 0;
  const livePrice =
    livePriceQuery.data?.priceUsd ?? token?.currentPrice ?? null;
  const trustedMarketLabel = getTrustedMarketLabel(token ?? {});
  const isOfficialPaxi = isOfficialPaxiToken({
    network: importNetworkId,
    contractAddress: token?.contractAddress,
    symbol: token?.symbol,
  });
  const alreadyHeld = Boolean(
    token?.contractAddress &&
    importNetworkId &&
    [...ASSETS, ...getCustomTokens().map(customTokenToAsset)].some(
      a =>
        a.network === importNetworkId &&
        a.contractAddress?.toLowerCase() ===
          token.contractAddress?.toLowerCase()
    )
  );

  const handleCopyAddress = () => {
    if (!token?.contractAddress) return;
    navigator.clipboard.writeText(token.contractAddress);
    setAddressCopied(true);
    toast.success("Contract address copied");
    setTimeout(() => setAddressCopied(false), 2000);
  };

  if (loadingToken) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-accent animate-spin" />
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <div className="w-12 h-12 rounded-full bg-destructive/10 border border-destructive/25 flex items-center justify-center mb-3">
          <AlertTriangle className="w-5 h-5 text-destructive" />
        </div>
        <p className="text-foreground font-semibold">
          Couldn't load this token
        </p>
        <button
          onClick={onBack}
          className="text-accent text-sm mt-3 font-medium"
        >
          Go back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button
            onClick={onBack}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          {(isOfficialPaxi ? PAXI_LOGO_URL : token.image) && !imageFailed ? (
            <img
              src={isOfficialPaxi ? PAXI_LOGO_URL : token.image}
              alt={token.symbol}
              className="w-6 h-6 rounded-full object-contain"
              onError={() => setImageFailed(true)}
            />
          ) : (
            <span className="w-6 h-6 rounded-full bg-accent/15 text-accent flex items-center justify-center text-[9px] font-bold">
              {token.symbol.slice(0, 2).toUpperCase()}
            </span>
          )}
          <h1 className="text-lg font-bold text-foreground">{token.symbol}</h1>
          {trustedMarketLabel && <VerifiedBadge label={trustedMarketLabel} />}
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div>
          <p className="text-3xl font-bold text-foreground tabular-nums">
            $
            {livePrice != null
              ? livePrice.toLocaleString(undefined, {
                  maximumFractionDigits: livePrice < 1 ? 6 : 2,
                })
              : "—"}
          </p>
          <p
            className={`flex items-center gap-1 text-sm font-semibold mt-1 ${isUp ? "text-emerald-400" : "text-red-400"}`}
          >
            {isUp ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5" />
            )}
            {token.priceChangePercent24h != null
              ? `${isUp ? "+" : ""}${token.priceChangePercent24h.toFixed(2)}% (24H)`
              : "—"}
          </p>
        </div>

        <div className="glass-card min-h-64 flex items-center justify-center !p-2">
          {loadingChart ? (
            <p className="text-sm text-muted-foreground">
              Loading professional chart…
            </p>
          ) : chartError ? (
            <p className="text-sm text-muted-foreground text-center px-4">
              Market history is temporarily unavailable. The live price remains
              available above.
            </p>
          ) : chartData && chartData.length > 0 ? (
            <ProfessionalMarketChart
              data={chartData ?? []}
              positive={isUp}
              source={chartData?.[0]?.source}
              fallback={Boolean(chartData?.some(point => point.fallback))}
              livePrice={livePrice}
              height={250}
            />
          ) : (
            <div className="px-5 text-center">
              <p className="text-sm font-medium text-foreground">
                Historical data is not available from the current providers.
              </p>
              <p className="mt-2 text-xs leading-5 text-muted-foreground">
                The live price above is still current. This can occur if an
                exchange does not list the selected asset or a provider is
                temporarily rate-limited.
              </p>
              <button
                onClick={() => void refetchChart()}
                className="mt-3 text-xs font-semibold text-accent hover:text-accent/80"
              >
                Retry chart
              </button>
            </div>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
          {TIMEFRAMES.map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                timeframe === tf
                  ? "bg-accent text-accent-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {"security" in token && (
          <div className="glass-card p-4 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">PAXI Shield</p>
              <span
                className={`text-xs font-semibold ${token.security === "safe" ? "text-emerald-400" : token.security === "high_risk" ? "text-red-400" : "text-orange-300"}`}
              >
                {token.security === "safe"
                  ? "SAFE"
                  : token.security === "high_risk"
                    ? "HIGH RISK"
                    : token.security.toUpperCase()}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Discovery data: {token.freshness}. Market presence does not prove
              legitimacy; verify the contract address before interacting.
            </p>
          </div>
        )}

        <div className="glass-card p-4 grid grid-cols-2 gap-4">
          <Stat
            label="Market Cap"
            value={
              token.marketCap == null ? "—" : formatUsdCompact(token.marketCap)
            }
          />
          <Stat
            label="Volume (24H)"
            value={
              token.volume24h == null ? "—" : formatUsdCompact(token.volume24h)
            }
          />
          <Stat
            label="Circulating Supply"
            value={
              token.circulatingSupply
                ? formatCompact(token.circulatingSupply)
                : "—"
            }
          />
          <Stat
            label="Max Supply"
            value={
              token.maxSupply ? formatCompact(token.maxSupply) : "Unlimited"
            }
          />
        </div>

        {token.description && (
          <div className="glass-card p-4">
            <p className="text-sm font-semibold text-foreground mb-1.5">
              About {token.name}
            </p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {token.description}
            </p>
          </div>
        )}

        {token.contractAddress && (
          <div className="rounded-xl border border-orange-400/30 bg-orange-500/10 p-3 text-xs text-orange-100">
            Anyone can create a token using any name or symbol. Verify the
            contract address before interacting.
          </div>
        )}

        {token.contractAddress && (
          <div className="glass-card p-4">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs text-muted-foreground">
                Contract Address{" "}
                {importNetworkId &&
                  `(${NETWORKS[importNetworkId]?.label ?? importNetworkId})`}
              </p>
              <button
                onClick={handleCopyAddress}
                className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                aria-label="Copy contract address"
              >
                {addressCopied ? (
                  <Check className="w-3.5 h-3.5 text-accent" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
            <p className="text-xs font-mono text-foreground break-all">
              {token.contractAddress}
            </p>

            {importNetworkId && (
              <div className="mt-3 pt-3 border-t border-white/5">
                {alreadyHeld ? (
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-accent">
                    <BadgeCheck className="w-3.5 h-3.5" />
                    Already in your wallet
                  </p>
                ) : (
                  <button
                    onClick={() =>
                      onAddToWallet(importNetworkId, token.contractAddress!)
                    }
                    className="flex items-center gap-1.5 text-xs font-semibold text-accent hover:text-accent/80 transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    Add to Wallet
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        <div className="flex gap-3">
          {token.homepage && (
            <a
              href={token.homepage}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-sm font-semibold py-2.5 rounded-lg transition-colors"
            >
              <Globe className="w-4 h-4" /> Website
            </a>
          )}
          {token.explorerUrl && (
            <a
              href={token.explorerUrl}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-sm font-semibold py-2.5 rounded-lg transition-colors"
            >
              <ExternalLink className="w-4 h-4" /> Explorer
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold text-foreground mt-0.5">{value}</p>
    </div>
  );
}

function formatUsdCompact(n: number): string {
  if (!n) return "—";
  return `$${n.toLocaleString(undefined, { notation: "compact", maximumFractionDigits: 2 })}`;
}
function formatCompact(n: number): string {
  return n.toLocaleString(undefined, {
    notation: "compact",
    maximumFractionDigits: 2,
  });
}
