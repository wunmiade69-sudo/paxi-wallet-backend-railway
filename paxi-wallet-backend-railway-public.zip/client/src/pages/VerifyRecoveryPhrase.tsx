import { useEffect, useState } from 'react';
import { ArrowLeft, AlertTriangle } from 'lucide-react';

function parseRecoveryPhrase(phrase: string): string[] {
  return phrase.trim().toLowerCase().split(/\s+/);
}

interface VerifyRecoveryPhraseProps {
  recoveryPhrase: string;
  onVerified: () => void;
  onBack: () => void;
}

export default function VerifyRecoveryPhrase({
  recoveryPhrase,
  onVerified,
  onBack,
}: VerifyRecoveryPhraseProps) {
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  useEffect(() => {
    const words = parseRecoveryPhrase(recoveryPhrase);
    // Shuffle words for verification
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    setAvailableWords(shuffled);
  }, [recoveryPhrase]);

  const handleSelectWord = (word: string) => {
    setSelectedWords([...selectedWords, word]);
    setAvailableWords(availableWords.filter(w => w !== word));
    setError('');
  };

  const handleRemoveWord = (index: number) => {
    const word = selectedWords[index];
    setAvailableWords([...availableWords, word]);
    setSelectedWords(selectedWords.filter((_, i) => i !== index));
    setError('');
  };

  const handleVerify = () => {
    setIsVerifying(true);
    const selectedPhrase = selectedWords.join(' ');
    
    if (selectedPhrase === recoveryPhrase) {
      setTimeout(() => {
        onVerified();
      }, 500);
    } else {
      setError('Phrase does not match. Please try again.');
      setSelectedWords([]);
      setAvailableWords([...availableWords, ...selectedWords].sort(() => Math.random() - 0.5));
      setIsVerifying(false);
    }
  };

  const isComplete = selectedWords.length === 12;

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-2xl font-bold text-accent">Verify Phrase</h1>
        <div className="w-10" />
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full">
        {/* Step indicator */}
        <div className="mb-8 text-center">
          <p className="text-muted-foreground text-sm">Step 2 of 4</p>
          <div className="flex gap-2 mt-2 justify-center">
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-accent rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
            <div className="w-2 h-2 bg-muted rounded-full" />
          </div>
        </div>

        {/* Title */}
        <h2 className="text-3xl font-bold text-foreground mb-2 text-center">Verify Your Phrase</h2>
        <p className="text-muted-foreground text-center mb-8">
          Select the words in the correct order to verify your recovery phrase.
        </p>

        {/* Selected Words */}
        <div className="glass-card mb-6">
          <p className="text-xs text-muted-foreground mb-3">Selected words:</p>
          <div className="min-h-24 flex flex-wrap gap-2">
            {selectedWords.length === 0 ? (
              <p className="text-muted-foreground text-sm w-full text-center py-8">
                Select words below...
              </p>
            ) : (
              selectedWords.map((word, index) => (
                <button
                  key={index}
                  onClick={() => handleRemoveWord(index)}
                  className="bg-accent/20 border border-accent/50 rounded-lg px-3 py-2 text-sm text-accent hover:bg-accent/30 transition-colors flex items-center gap-2"
                >
                  <span className="text-xs text-muted-foreground">{index + 1}.</span>
                  {word}
                  <span className="text-xs">×</span>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-3 mb-6">
            <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {/* Available Words */}
        <div className="glass-card mb-6 flex-1 overflow-y-auto">
          <p className="text-xs text-muted-foreground mb-3 sticky top-0 bg-secondary/50 py-2">
            Available words ({availableWords.length} remaining):
          </p>
          <div className="flex flex-wrap gap-2">
            {availableWords.map((word) => (
              <button
                key={word}
                onClick={() => handleSelectWord(word)}
                className="bg-secondary hover:bg-muted border border-border rounded-lg px-3 py-2 text-sm text-foreground transition-colors"
              >
                {word}
              </button>
            ))}
          </div>
        </div>

        {/* Verify Button */}
        <button
          onClick={handleVerify}
          disabled={!isComplete || isVerifying}
          className="w-full py-3 bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 disabled:from-muted disabled:to-muted text-accent-foreground disabled:text-muted-foreground font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 active:scale-95 disabled:cursor-not-allowed"
        >
          {isVerifying ? 'Verifying...' : 'Verify Phrase'}
        </button>
      </div>
    </div>
  );
}
