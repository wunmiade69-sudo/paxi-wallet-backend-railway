import { ArrowLeft, ShieldAlert, Wallet, Send, QrCode, Repeat, ArrowLeftRight, Eye, KeyRound, Fingerprint } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

interface WalletGuideScreenProps {
  onBack: () => void;
}

interface GuideEntry {
  icon: typeof Wallet;
  question: string;
  answer: string;
}

interface GuideSection {
  title: string;
  entries: GuideEntry[];
}

const sections: GuideSection[] = [
  {
    title: 'Security basics',
    entries: [
      {
        icon: ShieldAlert,
        question: 'What is my recovery phrase, and why does it matter?',
        answer:
          "Your 12-word recovery phrase is the only way to restore your wallet if you lose this device. It IS your wallet - anyone who has it can move your funds, and PAXI support can never recover it for you. Write it on paper, store it somewhere private, and never type it into a website, chat, or screenshot it.",
      },
      {
        icon: KeyRound,
        question: 'What does my PIN actually protect?',
        answer:
          'Your PIN encrypts your recovery phrase on this device (AES-256, derived via PBKDF2). It is never sent anywhere or stored in plain text - it only ever exists in memory for the moment it is checked. If you forget it, your recovery phrase is the only way back in.',
      },
      {
        icon: Fingerprint,
        question: 'Is Face ID / fingerprint unlock actually secure?',
        answer:
          'Yes - biometric unlock uses your device\'s real platform authenticator (WebAuthn), not just a UI toggle. A successful scan unwraps a device-bound key that decrypts your PIN, which then unlocks your wallet exactly as if you had typed it.',
      },
    ],
  },
  {
    title: 'Managing wallets',
    entries: [
      {
        icon: Wallet,
        question: 'Can I have more than one wallet?',
        answer:
          'Yes. Go to Me → Manage Wallets to create a new wallet, import one with its recovery phrase, or add a watch-only address. Every signing wallet on this device shares the same PIN, so switching between them doesn\'t ask you to re-enter it.',
      },
      {
        icon: Eye,
        question: 'What is a "watch-only" wallet?',
        answer:
          "A watch-only wallet lets you track an address's balance and activity without holding its keys on this device - useful for keeping an eye on a cold-storage or hardware-wallet address. You can view it, but you can't send from it here.",
      },
      {
        icon: ShieldAlert,
        question: 'What happens if I remove a wallet?',
        answer:
          "Removing a wallet from Manage Wallets only takes it off this device's list - your funds are untouched and the wallet still exists on-chain. As long as you still have its recovery phrase, you can import it again anytime. You can't remove your only signing wallet this way; use Settings → Remove Wallet for a full device reset.",
      },
    ],
  },
  {
    title: 'Sending & receiving',
    entries: [
      {
        icon: Send,
        question: 'How do I send crypto?',
        answer:
          'From the dashboard, tap Send, pick the asset, enter or paste the recipient address (or pick a saved contact), and review the gas fee before confirming. Double-check the address - blockchain transactions can\'t be reversed once sent.',
      },
      {
        icon: QrCode,
        question: 'How do I receive crypto?',
        answer:
          'Tap Receive to show your address as a QR code others can scan, or copy it directly. Make sure whoever is sending uses the same network your asset is on (e.g. don\'t send an ERC-20 token to a BSC-only address).',
      },
    ],
  },
  {
    title: 'Swap & bridge',
    entries: [
      {
        icon: Repeat,
        question: 'How does Swap pick a price?',
        answer:
          "Swap quotes are routed across 300+ liquidity sources (Uniswap, PancakeSwap, Curve, and more) and priced to find the best route, splitting across pools when that's cheaper. A small 0.3% wallet fee is built into the quote - there's no separate charge.",
      },
      {
        icon: ArrowLeftRight,
        question: 'What does Bridge do?',
        answer:
          'Bridge moves an asset from one network to another (for example, Ethereum to BSC) via an aggregator that finds the best underlying route. Currently only EVM-to-EVM destinations are supported; Bitcoin and Solana are shown but disabled until this wallet can derive addresses for them.',
      },
    ],
  },
];

export default function WalletGuideScreen({ onBack }: WalletGuideScreenProps) {
  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">Wallet Guide</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <p className="text-sm text-muted-foreground">
          Everything worth knowing about using PAXI Wallet safely, in one place.
        </p>

        {sections.map((section) => (
          <div key={section.title}>
            <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">
              {section.title}
            </h2>
            <div className="glass-card !p-0 overflow-hidden">
              <Accordion type="single" collapsible className="px-4">
                {section.entries.map((entry, i) => {
                  const Icon = entry.icon;
                  return (
                    <AccordionItem key={i} value={`${section.title}-${i}`} className="border-white/5">
                      <AccordionTrigger className="hover:no-underline">
                        <span className="flex items-center gap-2.5 text-sm font-semibold text-foreground">
                          <Icon className="w-4 h-4 text-accent shrink-0" />
                          {entry.question}
                        </span>
                      </AccordionTrigger>
                      <AccordionContent className="text-sm text-muted-foreground leading-relaxed pl-6.5">
                        {entry.answer}
                      </AccordionContent>
                    </AccordionItem>
                  );
                })}
              </Accordion>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
