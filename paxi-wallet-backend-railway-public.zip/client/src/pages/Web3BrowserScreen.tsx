import { ArrowLeft, Compass, ExternalLink } from 'lucide-react';

interface Web3BrowserScreenProps {
  onBack: () => void;
}

const DAPP_DIRECTORY = [
  { name: 'Uniswap', url: 'https://app.uniswap.org', description: 'Swap tokens on Ethereum' },
  { name: 'PancakeSwap', url: 'https://pancakeswap.finance', description: 'Swap tokens on BNB Smart Chain' },
  { name: 'OpenSea', url: 'https://opensea.io', description: 'NFT marketplace' },
  { name: 'Etherscan', url: 'https://etherscan.io', description: 'Ethereum block explorer' },
];

/**
 * dApp discovery intentionally opens external sites in the regular browser.
 * In-app pairing remains temporarily unavailable while security checks are completed.
 */
export default function Web3BrowserScreen({ onBack }: Web3BrowserScreenProps) {
  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground" aria-label="Back">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Web3 Browser</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div className="glass-card p-4 space-y-2 border border-amber-400/30">
          <p className="text-sm text-foreground font-medium flex items-center gap-2">
            <Compass className="w-4 h-4 text-amber-400" />
            dApp discovery only
          </p>
          <p className="text-xs text-muted-foreground">
            dApps open in your regular browser. In-app wallet pairing is temporarily unavailable while we complete
            security checks.
          </p>
        </div>

        <div className="space-y-3">
          {DAPP_DIRECTORY.map((dapp) => (
            <a
              key={dapp.url}
              href={dapp.url}
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card !p-4 flex items-center gap-3 hover:bg-foreground/5 transition-colors"
            >
              <span className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                <ExternalLink className="w-4 h-4 text-accent" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-foreground">{dapp.name}</span>
                <span className="block text-xs text-muted-foreground truncate">{dapp.description}</span>
              </span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
