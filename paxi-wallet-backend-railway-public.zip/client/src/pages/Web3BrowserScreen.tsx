import { ArrowLeft, Compass, ExternalLink } from 'lucide-react';
import AssetLogo from '@/components/AssetLogo';
import { CURATED_DAPPS, resolveDappLogo, type DappEntry } from '@/lib/wallet/discover';

interface Web3BrowserScreenProps {
  onBack: () => void;
}

const DAPP_DIRECTORY = CURATED_DAPPS;

/** dApp discovery intentionally opens curated destinations in the regular browser. */
export default function Web3BrowserScreen({ onBack }: Web3BrowserScreenProps) {
  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground" aria-label="Back">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Web3 Browser</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div className="glass-card p-4 space-y-2 border border-amber-400/30">
          <p className="text-sm text-foreground font-medium flex items-center gap-2">
            <Compass className="w-4 h-4 text-amber-400" />
            dApp discovery only
          </p>
          <p className="text-xs text-muted-foreground">
            Curated destinations open in your regular browser for full site compatibility. Review every connection request before approving it.
          </p>
        </div>

        <div className="space-y-3">
          {DAPP_DIRECTORY.map((dapp: DappEntry) => (
            <a
              key={dapp.url}
              href={dapp.url}
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card !p-4 flex items-center gap-3 hover:bg-foreground/5 transition-colors"
            >
              <AssetLogo src={resolveDappLogo(dapp)} cacheKey={`dapp:${dapp.id ?? dapp.url}`} fallback={dapp.name.charAt(0)} size="md" aria-hidden={true} className="border-white/10 bg-white" />
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-foreground">{dapp.name}</span>
                <span className="block text-xs text-muted-foreground truncate">{dapp.description}</span>
              </span>
              <ExternalLink className="w-4 h-4 text-muted-foreground shrink-0" />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
