import { ArrowRight, Download, KeyRound, ShieldCheck } from 'lucide-react';

interface WelcomeScreenProps {
  onCreateWallet: () => void;
  onImportWallet: () => void;
}

export default function WelcomeScreen({ onCreateWallet, onImportWallet }: WelcomeScreenProps) {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#09090b] text-foreground">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_16%,rgba(245,158,11,0.09),transparent_28%),radial-gradient(circle_at_86%_87%,rgba(245,158,11,0.06),transparent_31%)]" />

      <main className="relative mx-auto flex min-h-screen w-full max-w-md flex-col px-6 py-8 sm:py-10">
        <header className="flex items-center justify-between animate-fade-in">
          <span className="text-[10px] font-semibold uppercase tracking-[0.26em] text-foreground/60">PAXI WALLET</span>
          <span className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-accent/90"><span className="h-1.5 w-1.5 rounded-full bg-accent" /> Private by design</span>
        </header>

        <section className="flex flex-1 flex-col justify-center py-12">
          <div className="animate-slide-up">
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-accent/85">Your secure wallet</p>
            <h1 className="mt-4 text-4xl font-bold leading-[1.08] tracking-[-0.04em] text-foreground sm:text-5xl">Your wallet.<br /><span className="text-foreground/60">Your control.</span></h1>
            <p className="mt-5 max-w-sm text-base leading-relaxed text-muted-foreground">Create a new wallet or restore one you already control. PAXI never takes custody of your assets.</p>
          </div>

          <div className="mt-8 h-px w-full bg-gradient-to-r from-accent/45 via-white/10 to-transparent animate-fade-in" style={{ animationDelay: '0.08s' }} />

          <div className="mt-6 space-y-3 animate-slide-up" style={{ animationDelay: '0.14s' }}>
            <button
              onClick={onCreateWallet}
              className="group flex w-full items-center gap-4 rounded-2xl border border-accent/35 bg-[linear-gradient(135deg,rgba(245,158,11,0.13),rgba(245,158,11,0.035))] px-5 py-4 text-left transition-colors duration-200 hover:border-accent/55 hover:bg-accent/[0.16] active:scale-[0.98]"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-accent/25 bg-accent/10">
                <ShieldCheck className="h-5 w-5 text-accent" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-base font-semibold text-foreground">Create a wallet</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">Set up a new encrypted recovery phrase</span>
              </span>
              <ArrowRight className="h-5 w-5 text-accent transition-transform duration-200 group-hover:translate-x-0.5" />
            </button>

            <button
              onClick={onImportWallet}
              className="group flex w-full items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.025] px-5 py-4 text-left transition-colors duration-200 hover:border-white/20 hover:bg-white/[0.055] active:scale-[0.98]"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-black/20">
                <Download className="h-5 w-5 text-accent" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-base font-bold text-foreground">Import an existing wallet</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">Use a recovery phrase or private key</span>
              </span>
              <ArrowRight className="h-5 w-5 text-foreground/45 transition-transform duration-200 group-hover:translate-x-0.5" />
            </button>
          </div>

          <div className="mt-7 flex items-center gap-2 text-xs leading-relaxed text-muted-foreground animate-fade-in" style={{ animationDelay: '0.26s' }}>
            <KeyRound className="h-3.5 w-3.5 text-accent/80" />
            <span>Your recovery phrase stays encrypted on this device.</span>
          </div>
        </section>

        <p className="text-center text-[10px] uppercase tracking-[0.18em] text-muted-foreground/55">Self-custody · No account required</p>
      </main>
    </div>
  );
}
