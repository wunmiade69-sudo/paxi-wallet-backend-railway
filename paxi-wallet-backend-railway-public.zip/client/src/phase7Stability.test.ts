import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const dashboardPath = fileURLToPath(new URL("./pages/Dashboard.tsx", import.meta.url));
const countUpPath = fileURLToPath(new URL("./hooks/useCountUp.ts", import.meta.url));
const chartPath = fileURLToPath(new URL("./components/ProfessionalMarketChart.tsx", import.meta.url));
const appPath = fileURLToPath(new URL("./App.tsx", import.meta.url));
const sendPath = fileURLToPath(new URL("./pages/SendScreen.tsx", import.meta.url));
const swapPath = fileURLToPath(new URL("./pages/SwapPanel.tsx", import.meta.url));
const bridgePath = fileURLToPath(new URL("./pages/BridgePanel.tsx", import.meta.url));
const thorchainPath = fileURLToPath(new URL("./pages/ThorchainSwapPanel.tsx", import.meta.url));
const marketsPath = fileURLToPath(new URL("./pages/MarketsScreen.tsx", import.meta.url));

describe("Phase 7 stability safeguards", () => {
  it("keeps cached asset values visible during a background refresh", () => {
    const source = readFileSync(dashboardPath, "utf8");

    expect(source).toContain("const missingKeys = allAssets");
    expect(source).toContain("const pendingBalancesRef = useRef<Record<string, AssetBalance> | null>(null);");
    expect(source).toContain("setTimeout(() => {");
    expect(source).toContain("b?.balance != null");
    expect(source).toContain("b?.balance != null\n                              ? b.balance.toLocaleString");
  });

  it("refreshes only newly missing asset keys when cached values already exist", () => {
    const source = readFileSync(dashboardPath, "utf8");

    expect(source).toContain("const missingKeys = allAssets.map(assetKey).filter((key) => !cached?.[key]);");
    expect(source).toContain("allAssets.filter((asset) => missingKeys.includes(assetKey(asset)))");
    expect(source).toContain("setLoadingSymbols(new Set(missingKeys))");
  });

  it("publishes the cached wallet balance snapshot into Markets held-asset navigation", () => {
    const appSource = readFileSync(appPath, "utf8");
    const marketsSource = readFileSync(marketsPath, "utf8");

    expect(appSource).toContain("const [balanceSnapshot, setBalanceSnapshot] = useState<Record<string, AssetBalance>>({});");
    expect(appSource).toContain("balanceSnapshot={balanceSnapshot}");
    expect(marketsSource).toContain("const knownBalances = { ...cachedWalletBalances, ...(balanceSnapshot ?? {}) };");
    expect(marketsSource).toContain("onSelectAsset(asset, knownBalances[assetIdentityKey(asset) ?? ''])");
  });

  it("continues cosmetic total animation from the last displayed frame", () => {
    const source = readFileSync(countUpPath, "utf8");

    expect(source).toContain("const displayRef = useRef(target);");
    expect(source).toContain("const from = displayRef.current;");
    expect(source).toContain("displayRef.current = current;");
    expect(source).not.toContain("const fromRef = useRef(target);");
  });

  it("keeps top-level tab scroll containers independent and mounted", () => {
    const source = readFileSync(appPath, "utf8");

    expect(source).toContain("h-[100dvh] overflow-y-auto overscroll-y-contain");
    expect(source).toContain("meContextScreens");
    expect(source).toContain("paxi-ai-support");
    expect(source).toContain("<Dashboard");
    expect(source).toContain("<MarketsScreen");
    expect(source).toContain("<MeScreen");
  });

  it("exposes one origin-aware notification entry point on data tabs", () => {
    const source = readFileSync(appPath, "utf8");

    expect(source).toContain("openNotifications('dashboard')");
    expect(source).toContain("openNotifications('markets')");
    expect(source).toContain("openNotifications('discover')");
    expect(source).toContain("setCurrentScreen(notificationOrigin)");
  });

  it("threads exact transaction hashes through the shared notification producer", () => {
    for (const producerPath of [sendPath, swapPath, bridgePath, thorchainPath]) {
      const source = readFileSync(producerPath, "utf8");
      expect(source).toContain("notifyForTransaction");
      expect(source).toContain("source: 'local-wallet'");
    }
    const appSource = readFileSync(appPath, "utf8");
    expect(appSource).toContain("target.entityType === 'transaction' ? target.hash ?? null : null");
    expect(appSource).toContain("initialHash={selectedTransactionHash ?? undefined}");
  });

  it("explicitly enables mobile chart gestures without changing the data pipeline", () => {
    const source = readFileSync(chartPath, "utf8");

    expect(source).toContain("normalizeChartSeries");
    expect(source).toContain("handleScroll:");
    expect(source).toContain("horzTouchDrag: true");
    expect(source).toContain("handleScale:");
    expect(source).toContain("pinch: true");
  });
});
