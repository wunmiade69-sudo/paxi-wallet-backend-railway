import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const mePath = fileURLToPath(new URL("./pages/MeScreen.tsx", import.meta.url));
const appPath = fileURLToPath(new URL("./App.tsx", import.meta.url));
const transactionListPath = fileURLToPath(new URL("./components/TransactionList.tsx", import.meta.url));
const discoverPath = fileURLToPath(new URL("./pages/DiscoverScreen.tsx", import.meta.url));
const discoverPolicyPath = fileURLToPath(new URL("./lib/wallet/discover.ts", import.meta.url));

const read = (path: string) => readFileSync(path, "utf8");

describe("Phase 7G UI safety contracts", () => {
  it("derives Me security state from local evidence and keeps unknown states explicit", () => {
    const source = read(mePath);

    expect(source).toContain("getConnectedDapps()");
    expect(source).toContain("getTokenApprovals()");
    expect(source).toContain("isBiometricEnabledOnVault()");
    expect(source).toMatch(/status:\s*(?:hasEncryptedWallet|isActiveWalletBackupVerified\(\)|isBiometricEnabledOnVault\(\)|approvals\.length > 0 \? 'warning' : )[^,]+/);
    expect(source).toContain("PAXI never stores the recovery phrase.");
    expect(source).not.toContain("onWalletGuide");
  });

  it("keeps All and combined Swap/Bridge history as distinct entry points", () => {
    const me = read(mePath);
    const app = read(appPath);
    const list = read(transactionListPath);

    expect(me).toContain("onTransactionRecords('all')");
    expect(me).toContain("onTransactionRecords('swap-bridge')");
    expect(app).toContain("transactionHistoryFilter");
    expect(app).toContain("initialFilter={transactionHistoryFilter}");
    expect(list).toContain("TransactionFilter = 'all' | TxType | 'swap-bridge'");
    expect(list).toContain("Swaps & Bridges");
  });

  it("keeps Discover curated and honest about safety and unavailable campaign data", () => {
    const source = read(discoverPath);
    const policy = read(discoverPolicyPath);

    expect(source).toContain("Listings are curated for discovery and are not security endorsements.");
    expect(policy).toContain("Only HTTPS links can be opened.");
    expect(source).toContain("Featured campaigns are unavailable right now.");
    expect(source).toContain("No curated dApps support this network yet.");
  });
});
