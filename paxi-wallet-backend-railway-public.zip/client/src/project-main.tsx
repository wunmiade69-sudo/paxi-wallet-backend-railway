import ProjectOwnerWorkspace from "@/workspaces/ProjectOwnerWorkspace";
import { renderWorkspace } from "@/workspaces/bootstrap";

renderWorkspace(<ProjectOwnerWorkspace />);
