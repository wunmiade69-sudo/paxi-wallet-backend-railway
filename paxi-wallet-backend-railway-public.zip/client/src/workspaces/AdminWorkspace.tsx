export { default } from "@/pages/AdminScreen";

/**
 * Legacy import compatibility only. The canonical administrator surface is
 * the protected AdminScreen shipped through admin-main.tsx.
 */
