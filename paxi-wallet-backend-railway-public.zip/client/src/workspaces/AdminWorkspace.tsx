import { useState } from "react";
import { Activity, BarChart3, ClipboardCheck, FileText, Gift, LayoutDashboard, ListChecks, ShieldAlert, ShieldCheck, Users } from "lucide-react";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import AdminReviewScreen from "@/pages/AdminReviewScreen";
import AdminGiftCodesScreen from "@/pages/AdminGiftCodesScreen";

type AdminSection = "overview" | "listings" | "campaigns" | "claims" | "gift-codes" | "audit" | "health";

const sections: Array<{ id: AdminSection; label: string; icon: typeof LayoutDashboard }> = [
  { id: "overview", label: "Dashboard", icon: LayoutDashboard },
  { id: "listings", label: "Token Listings", icon: ClipboardCheck },
  { id: "campaigns", label: "Campaigns", icon: ListChecks },
  { id: "claims", label: "Claims", icon: Gift },
  { id: "gift-codes", label: "Gift Codes", icon: Gift },
  { id: "audit", label: "Audit Logs", icon: FileText },
  { id: "health", label: "System Health", icon: Activity },
];

export default function AdminWorkspace() {
  const auth = trpc.auth.me.useQuery();
  if (auth.isLoading) return <WorkspaceLoading label="Checking PAXI administrator access…" />;
  if (!auth.data) return <AccessDenied title="PAXI Admin is a separate protected application" detail="Sign in with an authorized PAXI administrator account to continue." action="Sign in" onAction={startLogin} />;
  if (auth.data.role !== "admin") return <AccessDenied title="Administrator access required" detail="This workspace is intentionally separated from PAXI Wallet and only accepts authorized administrator accounts." />;
  return <AdminConsole />;
}

function AdminConsole() {
  const [section, setSection] = useState<AdminSection>("overview");
  const operations = trpc.campaigns.adminListOperational.useQuery();
  const audits = trpc.admin.auditEvents.useQuery({ limit: 50 }, { enabled: section === "audit" });
  const activeCampaigns = operations.data?.filter((campaign) => campaign.status === "active").length ?? 0;
  const featuredCampaigns = operations.data?.filter((campaign) => campaign.isFeatured).length ?? 0;

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-foreground lg:flex">
      <aside className="border-b border-white/10 bg-[#0f0f12] lg:min-h-screen lg:w-72 lg:border-b-0 lg:border-r">
        <div className="border-b border-white/10 px-6 py-6"><p className="text-xs font-semibold tracking-[0.24em] text-accent">PAXI</p><h1 className="mt-1 text-xl font-bold">Admin Console</h1><p className="mt-1 text-xs text-muted-foreground">Restricted operations workspace</p></div>
        <nav className="flex gap-1 overflow-x-auto p-3 lg:flex-col lg:overflow-visible" aria-label="PAXI administrator navigation">
          {sections.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setSection(id)} aria-current={section === id ? "page" : undefined} className={`flex shrink-0 items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium ${section === id ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"}`}><Icon className="h-4 w-4" />{label}</button>)}
        </nav>
      </aside>
      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
        {section === "overview" && <section className="mx-auto max-w-6xl space-y-6"><div><p className="text-xs font-semibold tracking-[0.2em] text-accent">CONTROL PLANE</p><h2 className="mt-2 text-3xl font-bold">PAXI operations at a glance</h2><p className="mt-2 max-w-2xl text-sm text-muted-foreground">Reviewing, suspension, featuring, and payout confirmation remain server-enforced administrator actions and are recorded in the audit ledger.</p></div><div className="grid gap-4 sm:grid-cols-3"><Metric label="Active campaigns" value={operations.isLoading ? "—" : String(activeCampaigns)} icon={BarChart3} /><Metric label="Featured campaigns" value={operations.isLoading ? "—" : String(featuredCampaigns)} icon={ShieldCheck} /><Metric label="Operational campaigns" value={operations.isLoading ? "—" : String(operations.data?.length ?? 0)} icon={Users} /></div><div className="grid gap-3 sm:grid-cols-2"><ActionCard title="Review token listings" description="Approve or reject verified payment submissions." onClick={() => setSection("listings")} /><ActionCard title="Review campaigns" description="Moderate funded campaign assets and publishing." onClick={() => setSection("campaigns")} /></div></section>}
        {section === "listings" && <AdminReviewScreen onBack={() => setSection("overview")} initialTab="listings" />}
        {section === "campaigns" && <AdminReviewScreen onBack={() => setSection("overview")} initialTab="campaign-review" />}
        {section === "claims" && <AdminReviewScreen onBack={() => setSection("overview")} initialTab="campaigns" />}
        {section === "gift-codes" && <AdminGiftCodesScreen onBack={() => setSection("overview")} />}
        {section === "audit" && <section className="mx-auto max-w-6xl"><p className="text-xs font-semibold tracking-[0.2em] text-accent">IMMUTABLE LEDGER</p><h2 className="mt-2 text-3xl font-bold">Administrator audit events</h2><p className="mt-2 text-sm text-muted-foreground">Every sensitive listing, campaign, and payout decision recorded after this control plane update appears here.</p><div className="mt-6 overflow-x-auto border border-white/10"><table className="w-full min-w-[720px] text-left text-sm"><thead className="bg-white/5 text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">Time</th><th className="px-4 py-3">Action</th><th className="px-4 py-3">Resource</th><th className="px-4 py-3">Administrator</th></tr></thead><tbody>{audits.isLoading ? <tr><td className="px-4 py-5 text-muted-foreground" colSpan={4}>Loading immutable audit events…</td></tr> : audits.data?.length ? audits.data.map((event) => <tr key={event.id} className="border-t border-white/5"><td className="px-4 py-3 text-muted-foreground">{new Date(event.createdAt).toLocaleString()}</td><td className="px-4 py-3 font-medium">{event.action}</td><td className="px-4 py-3">{event.resourceType}{event.resourceId ? ` #${event.resourceId}` : ""}</td><td className="px-4 py-3 font-mono text-xs text-muted-foreground">{event.actorOpenId}</td></tr>) : <tr><td className="px-4 py-5 text-muted-foreground" colSpan={4}>No administrator events have been recorded yet.</td></tr>}</tbody></table></div></section>}
        {section === "health" && <section className="mx-auto max-w-4xl"><p className="text-xs font-semibold tracking-[0.2em] text-accent">SERVICE POSTURE</p><h2 className="mt-2 text-3xl font-bold">System health</h2><div className="mt-6 border border-white/10 bg-white/[0.02] p-5"><div className="flex items-center gap-3"><ShieldAlert className="h-5 w-5 text-accent" /><div><p className="font-semibold">Operational controls are server-authoritative</p><p className="mt-1 text-sm text-muted-foreground">Use deployment monitoring for infrastructure health. This console exposes no operational secrets and does not mutate infrastructure.</p></div></div></div></section>}
      </main>
    </div>
  );
}

function Metric({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Activity }) { return <div className="border border-white/10 bg-white/[0.02] p-5"><Icon className="h-5 w-5 text-accent" /><p className="mt-5 text-3xl font-bold tabular-nums">{value}</p><p className="mt-1 text-sm text-muted-foreground">{label}</p></div>; }
function ActionCard({ title, description, onClick }: { title: string; description: string; onClick: () => void }) { return <button onClick={onClick} className="border border-white/10 bg-white/[0.02] p-5 text-left hover:border-accent/50"><p className="font-semibold">{title}</p><p className="mt-1 text-sm text-muted-foreground">{description}</p></button>; }
function WorkspaceLoading({ label }: { label: string }) { return <div className="flex min-h-screen items-center justify-center bg-[#0a0a0b] text-sm text-muted-foreground">{label}</div>; }
function AccessDenied({ title, detail, action, onAction }: { title: string; detail: string; action?: string; onAction?: () => void }) { return <div className="flex min-h-screen items-center justify-center bg-[#0a0a0b] px-6 text-center"><div className="max-w-md border border-white/10 bg-white/[0.02] p-8"><ShieldAlert className="mx-auto h-8 w-8 text-accent" /><h1 className="mt-4 text-xl font-bold">{title}</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">{detail}</p>{action && onAction && <button onClick={onAction} className="mt-6 rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground">{action}</button>}</div></div>; }
