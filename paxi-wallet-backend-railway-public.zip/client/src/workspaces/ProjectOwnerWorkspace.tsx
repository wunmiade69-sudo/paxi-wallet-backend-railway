import { useState } from "react";
import { BriefcaseBusiness, FilePlus2, Megaphone, ShieldCheck } from "lucide-react";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import ListingSubmitScreen from "@/pages/ListingSubmitScreen";
import MyListingsScreen from "@/pages/MyListingsScreen";
import CampaignCreateScreen from "@/pages/CampaignCreateScreen";
import MyCampaignsScreen from "@/pages/MyCampaignsScreen";

type OwnerView = "overview" | "listings" | "campaigns" | "new-listing" | "new-campaign";

export default function ProjectOwnerWorkspace() {
  const auth = trpc.auth.me.useQuery();
  if (auth.isLoading) return <div className="flex min-h-screen items-center justify-center bg-[#0a0a0b] text-sm text-muted-foreground">Checking project workspace access…</div>;
  if (!auth.data) return <div className="flex min-h-screen items-center justify-center bg-[#0a0a0b] px-6 text-center"><div className="max-w-md border border-white/10 bg-white/[0.02] p-8"><BriefcaseBusiness className="mx-auto h-8 w-8 text-accent" /><h1 className="mt-4 text-xl font-bold">PAXI Project Dashboard</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">This separate workspace is for project owners managing their own verified listings and campaigns.</p><button onClick={startLogin} className="mt-6 rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground">Sign in</button></div></div>;
  return <ProjectWorkspaceContent />;
}

function ProjectWorkspaceContent() {
  const [view, setView] = useState<OwnerView>("overview");
  const listings = trpc.listings.myListings.useQuery();
  const campaigns = trpc.campaigns.myCampaigns.useQuery();
  if (view === "listings") return <MyListingsScreen onBack={() => setView("overview")} onCreateListing={() => setView("new-listing")} onResubmit={() => setView("new-listing")} />;
  if (view === "campaigns") return <MyCampaignsScreen onBack={() => setView("overview")} onCreate={() => setView("new-campaign")} />;
  if (view === "new-listing") return <ListingSubmitScreen onBack={() => setView("listings")} onViewListings={() => setView("listings")} />;
  if (view === "new-campaign") return <CampaignCreateScreen onBack={() => setView("campaigns")} onViewCampaigns={() => setView("campaigns")} />;
  const verifiedListings = listings.data?.filter((listing) => listing.status === "verified").length ?? 0;
  const activeCampaigns = campaigns.data?.filter((campaign) => campaign.status === "active").length ?? 0;
  return <div className="min-h-screen bg-[#0a0a0b] text-foreground"><header className="border-b border-white/10 bg-[#0f0f12]"><div className="mx-auto max-w-6xl px-6 py-6"><p className="text-xs font-semibold tracking-[0.24em] text-accent">PAXI</p><h1 className="mt-1 text-2xl font-bold">Project Dashboard</h1><p className="mt-1 text-sm text-muted-foreground">Manage only your verified listings and campaign submissions.</p></div></header><main className="mx-auto max-w-6xl space-y-6 px-6 py-8"><div className="grid gap-4 sm:grid-cols-3"><OwnerMetric label="My listings" value={listings.isLoading ? "—" : String(listings.data?.length ?? 0)} icon={FilePlus2} /><OwnerMetric label="Verified listings" value={listings.isLoading ? "—" : String(verifiedListings)} icon={ShieldCheck} /><OwnerMetric label="Live campaigns" value={campaigns.isLoading ? "—" : String(activeCampaigns)} icon={Megaphone} /></div><div className="grid gap-4 sm:grid-cols-2"><OwnerAction title="Manage listings" description="Submit, review, and resubmit your token listings." onClick={() => setView("listings")} /><OwnerAction title="Manage campaigns" description="Create campaigns from approved listings and monitor moderation status." onClick={() => setView("campaigns")} /></div><p className="border-l-2 border-accent/70 pl-3 text-sm text-muted-foreground">Platform-wide reviews, featured placement, reward payouts, fee configuration, and audit data are intentionally unavailable here. They belong only to PAXI Admin.</p></main></div>;
}

function OwnerMetric({ label, value, icon: Icon }: { label: string; value: string; icon: typeof BriefcaseBusiness }) { return <div className="border border-white/10 bg-white/[0.02] p-5"><Icon className="h-5 w-5 text-accent" /><p className="mt-5 text-3xl font-bold">{value}</p><p className="mt-1 text-sm text-muted-foreground">{label}</p></div>; }
function OwnerAction({ title, description, onClick }: { title: string; description: string; onClick: () => void }) { return <button onClick={onClick} className="border border-white/10 bg-white/[0.02] p-5 text-left hover:border-accent/50"><p className="font-semibold">{title}</p><p className="mt-1 text-sm text-muted-foreground">{description}</p></button>; }
