import { trpc } from "@/lib/trpc";
import { COOKIE_NAME, UNAUTHED_ERR_MSG } from "@shared/const";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink, TRPCClientError } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "@/components/ErrorBoundary";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { I18nProvider } from "@/lib/i18n";
import { walletQueryClientDefaults } from "@/lib/queryClientOptions";
import { startLogin } from "@/const";
import "@/index.css";

export function renderWorkspace(element: React.ReactNode) {
  const queryClient = new QueryClient({ defaultOptions: walletQueryClientDefaults });
  const redirectToLoginIfUnauthorized = (error: unknown) => {
    if (error instanceof TRPCClientError && error.message === UNAUTHED_ERR_MSG) startLogin();
  };
  queryClient.getQueryCache().subscribe((event) => {
    if (event.type === "updated" && event.action.type === "error") redirectToLoginIfUnauthorized(event.query.state.error);
  });
  queryClient.getMutationCache().subscribe((event) => {
    if (event.type === "updated" && event.action.type === "error") redirectToLoginIfUnauthorized(event.mutation.state.error);
  });

  const client = trpc.createClient({
    links: [httpBatchLink({
      url: "/api/trpc",
      transformer: superjson,
      headers() {
        try {
          const raw = sessionStorage.getItem("manus-cookie");
          const pair = raw?.split(";").find((value) => value.trim().startsWith(`${COOKIE_NAME}=`));
          const token = pair?.trim().slice(`${COOKIE_NAME}=`.length);
          return token ? { Authorization: `Bearer ${token}` } : {};
        } catch {
          return {};
        }
      },
      fetch(input, init) {
        return globalThis.fetch(input, { ...(init ?? {}), credentials: "include" });
      },
    })],
  });

  createRoot(document.getElementById("root")!).render(
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <trpc.Provider client={client} queryClient={queryClient}>
            <QueryClientProvider client={queryClient}>
              <I18nProvider>{element}</I18nProvider>
            </QueryClientProvider>
          </trpc.Provider>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>,
  );
}
