// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * PaxiTokenFactory
 * =================
 * Lets a wallet create a standard BEP20/ERC20 token in one transaction while
 * paying Paxi's creation fee (in USDT/USDC) in the same transaction. The fee
 * is pulled via transferFrom, so it forwards atomically - there's no way to
 * deploy a token through this contract without the fee landing in treasury.
 *
 * ============================ DEPLOYMENT (BSC MAINNET) ============================
 * This repo doesn't deploy contracts for you - deploying costs real BNB gas
 * from a wallet you control, so it has to be a deliberate action you take.
 * Easiest path, no local tooling required:
 *
 *   1. Go to https://remix.ethereum.org
 *   2. Create a new file, paste this whole contract in
 *   3. Left sidebar -> Solidity Compiler -> select 0.8.20+ -> Compile
 *   4. Left sidebar -> Deploy & Run Transactions
 *      - Environment: "Injected Provider" (connect MetaMask, set to BSC Mainnet)
 *      - Contract: PaxiTokenFactory
 *      - Constructor args:
 *          _treasury  = 0x7f522D2639DE092d67668b5A2122bADA2d9B035f   (your Paxi address)
 *          _feeToken  = 0x55d398326f99059fF775485246999027B3197955   (USDT on BSC)
 *          _feeAmount = 500000                                       (0.50 USDT, 6 decimals)
 *   5. Click Deploy, confirm in MetaMask (this costs real BNB gas)
 *   6. Copy the deployed contract address
 *   7. Paste it into client/src/lib/wallet/tokenFactory.ts:
 *          FACTORY_ADDRESSES.bsc = '0xYourDeployedAddress'
 *
 * Before pointing real users at this: get the contract reviewed by someone
 * other than the person who wrote it. It's small and uses well-worn patterns,
 * but "small and simple" isn't the same as "audited" - this handles other
 * people's money.
 * ===================================================================================
 */

interface IERC20Fee {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

/// @notice Minimal, standard BEP20/ERC20 token. No mint/burn/pause/blacklist -
/// what you deploy is exactly what it looks like, on purpose (keeps it simple
/// to audit and hard to rug via a hidden admin function).
contract PaxiToken {
    string public name;
    string public symbol;
    uint8 public constant decimals = 18;
    uint256 public totalSupply;
    address public immutable creator;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    constructor(string memory _name, string memory _symbol, uint256 _supply, address _creator) {
        name = _name;
        symbol = _symbol;
        totalSupply = _supply;
        creator = _creator;
        balanceOf[_creator] = _supply;
        emit Transfer(address(0), _creator, _supply);
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 allowed = allowance[from][msg.sender];
        require(allowed >= amount, "PaxiToken: allowance exceeded");
        if (allowed != type(uint256).max) {
            allowance[from][msg.sender] = allowed - amount;
        }
        _transfer(from, to, amount);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal {
        require(to != address(0), "PaxiToken: transfer to zero address");
        uint256 bal = balanceOf[from];
        require(bal >= amount, "PaxiToken: insufficient balance");
        unchecked {
            balanceOf[from] = bal - amount;
        }
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
    }
}

contract PaxiTokenFactory {
    address public immutable treasury;
    IERC20Fee public immutable feeToken;
    uint256 public feeAmount;
    address public owner;

    event TokenCreated(
        address indexed tokenAddress,
        address indexed creator,
        string name,
        string symbol,
        uint256 supply,
        uint256 feePaid
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "PaxiTokenFactory: not owner");
        _;
    }

    constructor(address _treasury, address _feeToken, uint256 _feeAmount) {
        require(_treasury != address(0), "PaxiTokenFactory: treasury required");
        require(_feeToken != address(0), "PaxiTokenFactory: fee token required");
        treasury = _treasury;
        feeToken = IERC20Fee(_feeToken);
        feeAmount = _feeAmount;
        owner = msg.sender;
    }

    /// @notice Update the fee if $0.50's token-denominated value needs adjusting later.
    function setFeeAmount(uint256 _feeAmount) external onlyOwner {
        feeAmount = _feeAmount;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "PaxiTokenFactory: zero address");
        owner = newOwner;
    }

    /// @notice Deploys a new token and pays the creation fee, atomically.
    /// @dev Caller must `approve(factoryAddress, feeAmount)` on the fee token first
    /// (standard two-step ERC20 pattern - the client handles this automatically).
    function createToken(string calldata tokenName, string calldata tokenSymbol, uint256 initialSupply)
        external
        returns (address tokenAddress)
    {
        require(bytes(tokenName).length > 0, "PaxiTokenFactory: name required");
        require(bytes(tokenSymbol).length > 0, "PaxiTokenFactory: symbol required");
        require(initialSupply > 0, "PaxiTokenFactory: supply required");

        bool paid = feeToken.transferFrom(msg.sender, treasury, feeAmount);
        require(paid, "PaxiTokenFactory: fee transfer failed");

        PaxiToken token = new PaxiToken(tokenName, tokenSymbol, initialSupply, msg.sender);
        tokenAddress = address(token);

        emit TokenCreated(tokenAddress, msg.sender, tokenName, tokenSymbol, initialSupply, feeAmount);
    }
}
