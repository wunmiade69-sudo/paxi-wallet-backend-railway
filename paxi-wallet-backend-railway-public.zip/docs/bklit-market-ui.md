# Bklit-Inspired Market Interface

## Overview

PAXI’s Markets screen now uses a Bklit-inspired visual language for crypto market exploration: compact data cards, a calm dark surface hierarchy, accent-based positive/negative movement, provider-sourced status labeling, dense tabular token rows, and a responsive movement bar visualization. The implementation reuses the existing PAXI market APIs and `AssetLogo`/Tailwind design system rather than creating a parallel data provider or trading flow.

Bklit’s composable chart documentation informed the visual direction: dense chart surfaces, readable axes/labels, hover-friendly data presentation, and clear separation between chart data and surrounding controls.[1] The existing PAXI `ProfessionalMarketChart` continues to use the established Lightweight Charts integration for token-detail OHLC/line charts; this pass does not replace wallet, quote, signing, or broadcast behavior.

## Implemented surface

| Area | Implementation |
|---|---|
| Market pulse header | Added a provider-sourced live-market label and market-pulse section. |
| Top mover card | Derives the strongest visible 24-hour mover from the real current page response. |
| Visible trend card | Shows the average 24-hour change of visible priced assets; it is explicitly labeled as a visible-page metric, not a fabricated global market index. |
| Movement bars | Renders a compact, accessible 24-hour movement visualization from the visible provider response. Bars are not synthetic price history. |
| Asset list | Preserves canonical wallet-asset matching, market-data-only labels, provider attribution, pagination, and existing navigation. |
| Token detail chart | Preserves the existing professional chart and real chart endpoint. |

## Data and safety boundaries

All summary values derive from the `market.list` response already used by the page. No new transaction endpoint, wallet balance mutation, quote path, signing path, or broadcast path was added. Existing security labels remain visible for assets that are market-data-only. Market data is not treated as token verification.

The movement cards use JavaScript numbers only because the market provider’s normalized price-change fields are already non-settlement market display data. Blockchain base units, fees, balances, and transaction amounts remain on their established exact-string/bigint paths.

## Validation

```text
npm run check: PASS
Targeted market/token UI tests: PASS — 2 files, 7 tests
npm run build: PASS — 3459 modules transformed
```

## References

[1]: https://bklit.com/docs/components/line-chart "Bklit UI Line Chart documentation"
[2]: https://bklit.com/docs/components/candlestick-chart "Bklit UI Candlestick Chart documentation"
[3]: https://github.com/bklit/bklit-ui "Bklit UI GitHub repository"

## Refinement pass

The Markets screen now exposes a canonical-identity watchlist control on each asset row. Watchlist entries are stored locally under a versioned key, limited to 100 entries, validated on read, and keyed by chain plus contract/mint, native-chain identity, or normalized provider coin ID. Symbols and names are never used as the sole identity.

The market header reports an explicit provider freshness state and the rows remain responsive by hiding secondary verification badges at narrow widths while preserving the underlying market-data-only status. The token-detail chart now includes a Bklit-inspired framed price-action surface, live-source state, responsive timeframe tabs, and an accessible hover readout that shows timestamp, localized price, and OHLC values when available. The chart continues to use the existing Lightweight Charts data path and does not affect transaction construction or signing.

Additional validation:

```text
npm run check: PASS
Focused UI/watchlist suite: PASS — 4 files, 15 tests
```
