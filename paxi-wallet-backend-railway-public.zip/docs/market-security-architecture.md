# PAXI Wallet Market and Security Architecture

## Market data

Wallet token valuation now follows the canonical path `priceEngine -> fetchAggregatedMarket -> registered providers -> validation and consensus -> Redis/MySQL cache -> wallet UI`. Existing DexPaprika, DexScreener, GeckoTerminal, and CoinGecko adapters remain registered. Birdeye is an optional server-side adapter using `BIRDEYE_API_KEY`, `BIRDEYE_API_BASE_URL`, `X-API-KEY`, and `x-chain`. DexScanner is an explicitly opt-in adapter: it remains disabled unless a deployment supplies `DEXSCANNER_API_BASE_URL` and `DEXSCANNER_API_KEY` for a documented response contract. No undocumented public endpoint or guessed response field is treated as valid data.

The aggregator performs provider fan-out with `Promise.allSettled`, rejects invalid or non-positive prices, groups markets by provider, selects the strongest market per provider using liquidity, volume, and freshness, filters price outliers, and returns a median consensus with source provenance, liquidity, volume, confidence, and staleness. Redis and MySQL caches remain in the read path, and the existing on-chain reserve fallback remains available when no provider produces a usable price. Provider HTTP calls retain timeout, circuit-breaker, cooldown, response-size, malformed-JSON, and rate-limit handling. Provider health records successes, failures, latency, rate limits, and the last failure without exposing credentials.

Charts continue to use the existing candle service and its provider-specific compatibility and fallback logic. A provider is not asked for a timeframe it cannot support, and missing candles are not synthesized.

## Security intelligence

The security router retains the existing GoPlus-backed `checkContract` procedure for backward compatibility and exposes a typed `scan` procedure for `contract`, `address`, `transaction`, `approval`, and `dapp` targets. PAXI Shield uses `scan`, so contract, address, approval, transaction, and dApp results share the same conservative result path. Contract reports are persisted into the existing `securityReports` table with the provider, score, checks, label, and timestamp. A report is never labeled safe merely because data is absent.

Moralis is an optional server-only intelligence source and is not part of price consensus. When `MORALIS_API_KEY` is configured, documented wallet-history data can contribute address/activity signals and documented ERC20 approval data can identify unlimited allowances and unverified or spam spenders. If Moralis is unavailable, unsupported for a chain, or not configured, the result is explicitly `UNKNOWN` and the wallet remains able to continue the requested flow. Transaction and dApp scans remain unknown until a documented provider and independently validated implementation are available.

Security events are emitted with event type, network, target type, hashed target identity, provider, confidence, and risk state. Raw seed phrases, private keys, PINs, passwords, authentication secrets, and raw wallet material are never sent to external providers or written to security events.

## Environment variables

| Variable | Purpose |
|---|---|
| `BIRDEYE_API_KEY` | Optional server-only Birdeye credential |
| `BIRDEYE_API_BASE_URL` | Birdeye base URL; defaults to the public API host |
| `DEXSCANNER_API_BASE_URL` | Optional documented DexScanner-compatible endpoint |
| `DEXSCANNER_API_KEY` | Optional server-only DexScanner credential |
| `MORALIS_API_KEY` | Optional server-only Moralis security-intelligence credential |

All are declared as placeholders in `.env.example`; none use `VITE_` prefixes.

## Limitations

Birdeye data is unavailable when its key is not configured or when the provider does not return a valid token price. DexScanner is intentionally disabled until a documented endpoint contract is supplied by the deployment operator. Moralis address and approval intelligence is optional, and transaction simulation, transaction-specific risk, and dApp reputation remain `UNKNOWN` rather than being inferred. `UNKNOWN` is informational and does not mean malicious or automatically block a legitimate transaction.
