# Phase 5G P2.4 — RPC, Confirmation, and Reconciliation Hardening

**Author:** Manus AI  
**Status:** Implemented for local review; **not production approved**

## Scope and audit result

The supplied project was audited before modification. The existing SEND flow performed signing and broadcasting in the browser, waited for confirmation against a single client RPC URL, and only persisted the fee and activity records after both transactions had fully confirmed. Fee and activity persistence already had operation and transaction idempotency barriers, but their status models were limited to `pending`, `confirmed`, and `failed`. The client retained fee and SEND hashes only in component state, so an app restart could lose the recovery context.

The prior RPC implementation had a shared helper, but endpoint mappings were duplicated in the adapter registry and fee verification module. Failover returned a generic error and did not expose a stable provider-error taxonomy. Confirmation defaults were EVM-oriented, and the client’s local confirmation result was not itself authoritative because final recording still depended on server verification.

| Audit question | Before this work | Current behavior |
|---|---|---|
| Confirmation depth | EVM defaults were used by the client and server; one shared policy existed but lacked explicit non-EVM semantics | EVM depth remains configurable per network; Solana and Bitcoin now have distinct policy representations; server verification remains authoritative |
| RPC endpoint selection | Shared helper plus duplicated hardcoded adapter URLs | Central registry-backed endpoint ordering for supported networks |
| Fallback | Sequential fallback existed for HTTP/provider calls | Sequential primary → fallback 1 → fallback 2 behavior with bounded delays and circuit isolation |
| Timeout after broadcast | Generic timeout/error surfaced; hashes remained only in component state | Explicit unknown-status error; known hashes are persisted locally and retained for reconciliation |
| Confirmed fee reconciliation | Performed only during final `recordSend` | Existing verification remains authoritative; reconciliation endpoint can re-check known fee and SEND hashes |
| Confirmed SEND reconciliation | Final `recordSend` verified receipt, depth, sender/recipient/asset semantics | New non-throwing reconciliation result distinguishes pending, confirming, confirmed, failed, and unknown |
| Client disconnect after broadcast | Recovery context could be lost when the screen was discarded | Recovery record is stored locally for up to 24 hours and never triggers automatic rebroadcast |
| Retry behavior | Existing operation idempotency existed only at final record time | Known hashes are reused; reconciliation endpoint is available by `operationId`/quote binding; final record remains idempotent |
| Server lifecycle states | No complete SEND lifecycle state model | Typed lifecycle and transition validation added; durable database lifecycle migration remains a limitation noted below |

## Files changed

The implementation changed the shared RPC registry, chain environment mappings, adapter registry, confirmation policy, transaction verifier, SEND fee service/router, client SEND screen and recovery storage, plus focused tests. A few pre-existing TypeScript blockers were also corrected: transaction-aware persistence helpers now accept Drizzle transaction executors, and stale listing/campaign treasury references were corrected.

The main files are `server/chains/rpc.ts`, `server/chains/profiles.ts`, `server/chains/registry.ts`, `shared/confirmationPolicy.ts`, `shared/sendLifecycle.ts`, `server/wallet/transactionVerifier.ts`, `server/fees/sendFee.ts`, `server/routers/fees.ts`, `client/src/lib/wallet/send.ts`, `client/src/lib/wallet/sendRecovery.ts`, and `client/src/pages/SendScreen.tsx`. Tests were extended in `server/chains/rpc.test.ts`, `shared/sendLifecycle.test.ts`, `server/fees/sendFee.test.ts`, and `client/src/pages/SendScreen.test.ts`.

## RPC architecture and failover

The server now obtains endpoints from one registry derived from the canonical chain definitions. EVM adapters obtain their primary URL from that registry rather than carrying separate hardcoded URLs. The supported network set is explicit: Ethereum, BSC, Polygon, Arbitrum, Solana, and Bitcoin. Bitcoin remains represented by its existing Bitcoin provider family rather than being treated as an EVM JSON-RPC chain.

Configured endpoint names are `ETH_RPC_URL`, `ETH_RPC_FALLBACK_URL`, `ETH_RPC_FALLBACK_URL_2`, `BSC_RPC_URL`, `BSC_RPC_FALLBACK_URL`, `BSC_RPC_FALLBACK_URL_2`, `POLYGON_RPC_URL`, `POLYGON_RPC_FALLBACK_URL`, `POLYGON_RPC_FALLBACK_URL_2`, `ARBITRUM_RPC_URL`, `ARBITRUM_RPC_FALLBACK_URL`, `ARBITRUM_RPC_FALLBACK_URL_2`, `SOLANA_RPC_URL`, `SOLANA_RPC_FALLBACK_URL`, `SOLANA_RPC_FALLBACK_URL_2`, `BTC_RPC_URL`, `BTC_FALLBACK_URL`, and `BTC_FALLBACK_URL_2`. Only code-consumed names are represented in the registry; no `.env.example` was present in the supplied archive, so no unused environment file was created.

Failover is deterministic and bounded. Each endpoint is attempted once per operation in registry order, circuit breakers isolate unhealthy endpoints, provider requests use a bounded timeout, and a controlled `RpcProviderError` is returned after exhaustion. Errors are classified as `RPC_TIMEOUT`, `RPC_UNAVAILABLE`, `RPC_RATE_LIMITED`, or `RPC_INVALID_RESPONSE`. Provider failure is not translated into a transaction-level failure.

## Confirmation policy

EVM networks use configurable confirmation depths with existing defaults of Ethereum 2, BSC 3, Polygon 2, and Arbitrum 2. The server may override these with bounded integer environment values such as `ETHEREUM_CONFIRMATIONS` or `BSC_CONFIRMATIONS`; the existing implementation derives the key from the network name. Solana is represented with `finalized` commitment semantics, and Bitcoin is represented with UTXO confirmation depth rather than EVM block arithmetic.

A mined receipt is not automatically final. The server checks the latest block, calculates receipt depth, and only invokes the confirmed semantic verifier after the configured threshold. This leaves room for re-checking a receipt before final recording and avoids claiming finality from a single observation.

## SEND state machine

A typed lifecycle has been added with the required states: `CREATED`, `QUOTED`, `AWAITING_FEE`, `FEE_SUBMITTED`, `FEE_CONFIRMING`, `FEE_CONFIRMED`, `SEND_SUBMITTED`, `SEND_CONFIRMING`, `SEND_CONFIRMED`, `COMPLETED`, `FAILED`, `REJECTED`, and `RECONCILIATION_REQUIRED`. Invalid transitions fail closed. User-facing mapping distinguishes Pending, Confirming, Confirmed, Failed, Rejected, and Needs verification.

The existing order remains fee first, then main SEND, followed by server verification and atomic final recording. No real SEND fee settlement flag was enabled and no production transaction or migration was executed.

## Reconciliation and retry behavior

The transaction verifier now exposes a non-throwing `reconcileEvmTransaction` result. It returns `pending` when no receipt exists, `confirming` when a successful receipt lacks required depth, `confirmed` only after the existing semantic verifier accepts the transaction, `failed` only for an on-chain failure or semantic mismatch, and `unknown` for provider or verification availability problems.

A protected `fees.reconcileSend` procedure validates the immutable quote binding and re-checks known fee and SEND hashes. It returns the lifecycle state without broadcasting. The browser also stores the operation, quote, network, wallet, recipient, asset, amount, fee hash, and SEND hash in a short-lived local recovery record. When a matching SEND is reopened, known hashes are restored and no transaction is rebroadcast merely because confirmation timed out.

Existing final recording remains guarded by the immutable quote, operation ID, transaction hash, fee-payment ledger, and activity/fee uniqueness constraints. A conflicting operation or transaction fails closed.

## Security considerations

The changes preserve local signing and do not send mnemonic, seed phrase, private key, or signing material to the server. Provider keys are server-side environment values and are not placed in `VITE_*` variables. Server confirmation continues to verify chain, receipt status, confirmation depth, sender, recipient, asset, amount, treasury, and quote-bound transaction hashes. The server does not trust client success flags.

## Tests added and validation

The new focused behavioral tests cover RPC failure classification, endpoint failover, controlled provider errors, lifecycle happy-path transitions, invalid transitions, and user-facing state mapping. Existing SEND fee and RPC tests were retained and corrected where stale expectations conflicted with the current API or required upward rounding.

| Command | Result |
|---|---|
| `npm run check` | Passed with no TypeScript errors |
| `npm test -- --run shared/sendLifecycle.test.ts server/chains/rpc.test.ts server/fees/sendFee.test.ts` | Passed: 2 files, 17 tests |
| `npm test -- --run` | Passed: 81 files, 336 tests |
| `npm run build` | Passed; Vite client and server bundle built successfully, with existing chunk-size/dynamic-import warnings |
| `npm run lint` | Unavailable: the supplied `package.json` has no `lint` script |
| Production/staging verification | Not performed |

## Remaining limitations

The supplied schema still stores activity and fee status in the legacy three-value enums and does not include a dedicated durable `sendOperations` table containing the complete lifecycle and recovery hashes. The typed lifecycle and reconciliation endpoint therefore provide the hardening boundary, while full server-side lifecycle persistence should be added in the next controlled schema phase rather than silently introducing a production migration here.

The current client confirmation helper still contacts a client RPC for progress display; this is not treated as authoritative because final recording calls server verification. The server reconciliation path is presently EVM-focused; Solana and Bitcoin retain their separate provider/transaction architectures and require chain-specific reconciliation workers before they can share the same operation endpoint. Fee reconciliation reuses the existing semantic verifier and should receive a dedicated fee-result taxonomy and exact amount/treasury test matrix in the follow-up behavioral money-path phase.

The project remains **NOT PRODUCTION APPROVED**. Authenticated end-to-end testing, provider configuration, security review, controlled staging validation, dependency review, and live provider verification remain launch gates. Real SEND fee settlement remains off.
