# Phase 5G P2.5 Internal Audit Checklist

## P2.4 implemented

P2.4 added a registry-backed RPC/fallback layer, confirmation-depth policies, immutable SEND quote snapshots and fingerprints, fee-payment ledger protection, SEND lifecycle types, local recovery records, server-side EVM transaction verification, and a `fees.reconcileSend` endpoint.

## Already correct

The current code uses integer base-unit arithmetic for SEND amounts and service-fee conversion, binds quotes to the authenticated user and operation, avoids live repricing during final recording, verifies linked-wallet ownership, calls the global fee ledger during final recording, checks successful receipts and confirmation depth, and preserves Ethereum/BSC-only SEND fee settlement claims.

## P2.5 must add

P2.5 must add a canonical reconciliation result taxonomy, preserve detailed distinctions for ownership/asset/chain/amount/quote/RPC/replay/application failures, verify exact fee and SEND semantics, harden transaction-hash substitution and operation conflict behavior, expose durable lifecycle state sufficient for reload/restart/retry, and add actual behavioral tests for the required money-path matrix.

## Must remain unchanged

Do not begin P2.6, deploy production migrations, enable real fee settlement, send funds, touch treasury configuration, add unsupported non-EVM SEND settlement claims, store signing material, or redesign unrelated wallet features.

## Initial blockers observed

The existing transaction reconciler collapses semantic mismatches and provider failures into broad `failed`/`unknown` results. `reconcileSend` returns lifecycle labels such as `AWAITING_FEE` and `COMPLETED` rather than a canonical P2.5 result. The immutable quote loader checks expiry before returning a typed result. The final recorder does not compare an existing record's fee hash when the operation is already present, and it does not verify the SEND amount in the transaction verifier itself. The schema lacks a durable server-side SEND operation table. Existing SEND tests are arithmetic/policy smoke tests and do not cover the required behavioral matrix.
