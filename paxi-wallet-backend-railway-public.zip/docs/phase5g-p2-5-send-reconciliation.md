# Phase 5G P2.5 — SEND Reconciliation

**Status:** Implemented for local review; **not production approved**.

## 1. Scope

This phase is limited to SEND fee reconciliation and money-path verification. P2.6, production deployment, production migrations, treasury interaction, real SEND fee settlement, and unrelated wallet redesign were not performed.

## 2. P2.4 findings

P2.4 already provided centralized RPC fallback, confirmation policies, immutable quote snapshots, linked-wallet checks, a global fee-payment ledger, lifecycle types, local recovery, and a non-throwing EVM reconciler. The audit found that its transaction status vocabulary was too broad, fee and SEND amount checks were not consistently bound at the reconciler boundary, operation conflicts did not compare both hashes, and the server still lacked a dedicated durable SEND operation table.

## 3. Reconciliation model

The server now exposes `SendReconciliationResult` with canonical codes including `PENDING`, `CONFIRMING`, `CONFIRMED`, `FAILED`, `REJECTED`, ownership/treasury/asset/amount/chain/recipient mismatches, replay and operation conflicts, quote errors, RPC errors, transaction-not-found, and `RECONCILIATION_REQUIRED`. Reconciliation does not broadcast or reprice.

## 4. Fee verification

Fee reconciliation passes the quote-bound payer, treasury, asset, and exact base-unit fee amount into the EVM verifier. ERC-20 fee verification continues to require the actual matching `Transfer` event and on-chain decimals. Treasury mismatches are mapped to `WRONG_TREASURY` at the SEND reconciliation boundary.

## 5. SEND verification

The EVM verifier now accepts an exact expected base-unit amount and checks native transaction value or the matching ERC-20 `Transfer` event, in addition to chain, sender, recipient, asset, receipt success, and confirmation depth. Final SEND recording passes the quote-bound expected amount into that verifier.

## 6. Quote binding

Existing immutable quote binding remains authoritative. Reconciliation calls the existing quote loader and does not calculate a new price or fee. Expired or modified quotes are rejected with typed reconciliation results rather than silently repriced.

## 7. Replay protection

Existing final recording continues to call the global database-backed fee ledger. Idempotent operation replay now compares both the SEND transaction hash and fee transaction hash, returning an operation conflict if either changes.

## 8. Wallet ownership

The existing linked-wallet ownership mechanism remains required. Client-provided success flags and transaction metadata are not used as proof.

## 9. Durable state

The existing fee record and quote tables remain in use, and no new production migration was executed. A dedicated durable `sendOperations` table containing every lifecycle field requested by P2.5 remains a blocker for complete restart-safe server lifecycle persistence.

## 10. Recovery behavior

Reconciliation continues to operate on known hashes and never rebroadcasts a fee or SEND transaction. The current local recovery mechanism remains available, but full server-side operation persistence is not claimed complete.

## 11. RPC behavior

The existing primary/fallback RPC architecture remains in place. Provider failures are represented separately from on-chain transaction failure. The detailed `RPC_TIMEOUT` distinction depends on the lower-level provider error code and is preserved when available.

## 12. Tests

Added behavioral tests cover no-hash pending reconciliation, verifier mismatch classification, realistic 2 ETH, 10 BNB, 100 USDT, 1,000,000 USDT and minimum-USD-quantum exact arithmetic, overpayment policy behavior, total-debit identity, and the complete required canonical-code vocabulary. Focused result: **56 passed, 0 failed**. These tests do not claim the full 35-case live database/RPC behavioral matrix is complete.

## 13. Validation

| Check | Result |
|---|---|
| TypeScript (`npm run check`) | Passed |
| Focused tests | Passed: 56 tests |
| Full tests | Passed: 82 files, 378 tests |
| Build | Passed |
| Lint | Not available: no `lint` script exists; command exits non-zero |
| Audit | Failed: `npm audit --omit=dev` reports 16 dependency vulnerabilities (7 low, 9 moderate) |

## 14. Remaining blockers

The dedicated durable server-side SEND operation record is not implemented. Full mocked database/RPC behavioral coverage for hash substitution, concurrent ledger races, wrong payer/treasury/asset/chain, quote expiry and mutation, failed fee plus failed SEND combinations, and fallback exhaustion remains to be completed before declaring P2.5 behaviorally complete.

## 15. Production status

**NOT PRODUCTION APPROVED.** SEND fee settlement remains off. No real funds were sent, no treasury was touched, and no production migration was executed.
