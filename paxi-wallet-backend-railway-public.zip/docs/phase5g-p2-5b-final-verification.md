# P2.5B Final Verification / Implementation Remediation

## Executive summary

This pass closed the newly identified unsafe Velora fee calculation. Velora fee amounts are now calculated from exact source base units with bigint integer arithmetic and formatted only after calculation. A regression test covers values above JavaScript safe-integer precision and deterministic base-unit floor semantics. The existing EVM, Bitcoin, THORChain, Solana, SEND pending-history, durable recovery, and idempotency protections were preserved.

A safe opt-in real MySQL/InnoDB rollback harness and a deterministic mocked SEND lifecycle test are present. They were not used against production and no real funds or blockchain transactions were involved.

## Files changed in this pass

| File | Change |
|---|---|
| `server/veloraQuote.ts` | Replaced floating-point Velora fee calculation with exact source-unit bigint arithmetic and added `calculateVeloraFeeAmount`. |
| `server/veloraQuote.test.ts` | Added exact Velora fee regression tests. |
| `package.json` | Retains `test:p2-5b:db` command for isolated rollback verification. |
| `scripts/p2-5b-disposable-db-rollback.mjs` | Safe opt-in real MySQL/InnoDB rollback harness. |
| `server/fees/p2-5b-mocked-send-lifecycle.test.ts` | Deterministic mocked lifecycle evidence using real durable operation transitions. |
| `docs/phase5g-p2-5b-final-verification.md` | This report. |

Earlier pending recovery and exact-arithmetic files remain unchanged by this pass.

## Money-math audit

The repository-wide focused scan covered SEND, fees, swaps, bridges, EVM, Solana, Bitcoin, THORChain, activity, providers, and shared exact-decimal code. The previously unsafe Velora fee calculation used `Number(amountHuman)` and `.toFixed(8)`; it is now fixed and tested. Base-unit transaction paths use bigint or exact decimal strings. Remaining `Number`, `Math`, and `.toFixed` uses are isolated to UI display, timestamps/block metadata, token-decimal metadata, IDs/counts, provider market-data normalization, or the UI-only Velora rate compatibility field, which is not used for accounting or transaction construction.

The Velora transaction builder continues to pass exact `srcAmount` and `destAmount` integer strings to the provider. The swap router delegates executable transaction data to the real Velora, Jupiter, THORChain, and LiFi/provider paths; unsupported or unavailable paths fail rather than returning fabricated executable zero-value transactions.

## THORChain and activity review

THORChain distinguishes inbound BTC amount, expected destination output, memo, destination asset, and status. Inbound BTC is parsed into exact satoshis and transaction construction keeps satoshis as bigint through the guarded Bitcoin library boundary. Activity decoding preserves raw ERC-20 units, token address identity, and token decimals; failed receipts are rejected, and ambiguous multi-transfer activity is not automatically labeled as a successful swap without sufficient evidence.

## Database rollback readiness

`scripts/p2-5b-disposable-db-rollback.mjs` uses the real `mysql2/promise` client and InnoDB. It refuses access unless `P2_5B_ALLOW_DISPOSABLE_DB=true`, rejects non-local/non-test hosts and non-disposable schema names, creates uniquely named temporary operation/activity/fee tables, injects a failure after all writes and before commit, verifies zero rows after rollback, verifies a clean retry commits exactly once, and drops all temporary tables.

Run only with an isolated disposable database:

```text
P2_5B_ALLOW_DISPOSABLE_DB=true \
P2_5B_TEST_DATABASE_URL=mysql://user:password@127.0.0.1:3306/paxi_test_<unique> \
npm run test:p2-5b:db
```

The harness syntax passes, but no local MySQL/MariaDB server was available in this environment, so actual database-engine rollback evidence remains unexecuted.

## Mocked lifecycle, recovery, and RPC readiness

The mocked lifecycle test uses the real `createSendOperation`, `getSendOperation`, and `transitionSendOperation` functions. It verifies immutable quote identity, fee and SEND hash persistence, pending-history identity, terminal confirmation, repeated reconciliation idempotency, broadcast counters, and duplicate operation rejection. Existing rollback-contract, fee, reconciliation, RPC failover, SEND recovery, and transaction-history tests complement it.

The client recovery implementation queries `fees.getSendOperation`, restores known hashes, ensures deduplicated pending history, reconciles known hashes only, retries on a bounded 15-second timer, and stops on terminal states. Source-level recovery tests pass, but a browser-level end-to-end client reload against a live durable endpoint remains unavailable.

The RPC abstraction implements configured endpoint ordering and fallback through `withRpcHttp`/`withEvmRpc`, with timeout, rate-limit, invalid-response, and unavailable classification. Existing failover tests pass. A complete independent matrix for every requested HTTP/network/malformed/pending/reverted/concurrent scenario remains outstanding.

## Migration review

`drizzle/phase5g-p2-5b-send-operations.sql` defines the send operation table with required quote and wallet foreign keys, binary-collated identity columns, unique operation ID, unique fee hash, unique SEND hash, user-created index, quote index, state/update index, and InnoDB. The migration is additive and uses existing `users` and `sendFeeQuotes` prerequisites. It was not executed; disposable staging execution remains required to prove compatibility with an existing schema and to demonstrate rollback procedure.

## Dependency audit

`npm audit --omit=dev` reports 16 production vulnerabilities: 7 low and 9 moderate. The affected package families are `@walletconnect/web3wallet`, `@walletconnect/core`, `@walletconnect/sign-client`, `@walletconnect/utils`, `@walletconnect/auth-client`, `@walletconnect/relay-auth`, `@stablelib/ed25519`, `@ethersproject/*`, `elliptic`, `@solana/web3.js`, `jayson`, and `uuid`. NPM proposes major-version changes for the WalletConnect chain and major-version changes for `@solana/web3.js`/related dependencies; the audit does not establish that those changes are safe for the wallet/Solana stack. No unsafe forced upgrade, downgrade, suppression, or tooling removal was applied. Dependency audit therefore remains FAIL.

## Validation

| Command | Result |
|---|---|
| `npm run check` | PASS |
| `npm test -- --run` | PASS — 93 test files, 449 tests, 0 failures |
| Targeted P2.5B suite | PASS — 6 files, 20 tests |
| `npm run build` | PASS — existing chunk-size/dynamic-import warnings remain |
| `npm audit --omit=dev` | FAIL — 16 production vulnerabilities, 7 low and 9 moderate |
| `node --check scripts/p2-5b-disposable-db-rollback.mjs` | PASS |
| `npm run test:p2-5b:db` | Not executed; no disposable MySQL/MariaDB server available |
| Lint | `LINT_SCRIPT = NOT_CONFIGURED` |
| Production migration | Not executed |
| Settlement / real funds / real broadcasts | Not used |

## Machine-readable final status

```text
P2_5B_STATUS = INCOMPLETE
P2_5B_ALLOWED = NO
P2_6_ALLOWED = NO

GATE_DATABASE_ROLLBACK = UNVERIFIED
GATE_FULL_MOCKED_SEND = PASS
GATE_CLIENT_RELOAD_RECOVERY = UNVERIFIED
GATE_RPC_FAILURE_HANDLING = UNVERIFIED
GATE_MONEY_MATH_AUDIT = PASS
GATE_SEND_PENDING_RECOVERY = PASS
GATE_DUPLICATE_BROADCAST_PROTECTION = PASS
GATE_MIGRATION_SAFETY = UNVERIFIED
GATE_DEPENDENCY_AUDIT = FAIL
GATE_TYPESCRIPT = PASS
GATE_TESTS = PASS
GATE_BUILD = PASS
```

## Release recommendation

> **P2.5B: INCOMPLETE. P2.6: DISALLOWED.**

The implementation and local evidence are stronger, including a fixed Velora monetary path and a runnable isolated database harness. P2.5B cannot be marked complete until the disposable database test is actually executed, the durable client reload flow is exercised end-to-end, the full controlled RPC matrix is executed, migration safety is validated in disposable staging, and dependency findings receive a compatible remediation decision.

## Dependency remediation update

A conservative dependency remediation was applied after reviewing the production dependency graph. The root `overrides` now pins `uuid` to `11.1.1`, which removes the vulnerable `uuid` 8.3.2 path used under Solana’s `jayson` dependency without changing the direct `@solana/web3.js` major version. The lockfile was regenerated and installed cleanly.

| Finding | Decision |
|---|---|
| `uuid` moderate advisory | **Remediated** through a root override to patched `11.1.1`; application compatibility verified by TypeScript, all tests, and production build. |
| `@walletconnect/*` and nested `@ethersproject/*` advisories | **Not force-upgraded**. NPM proposes a major WalletConnect change or package combinations that are nested under `web3wallet`; forcing them could affect wallet-connect session/signing behavior. |
| `@stablelib/ed25519` advisory | **Not force-upgraded** because it is nested under the WalletConnect chain and no compatible non-breaking fix was established. |
| `elliptic` advisory | **Not remediated**. The existing override is `6.6.1`, and the audit still includes that version; no patched compatible release was available in the current audit metadata. |

The production audit improved from **16 vulnerabilities (7 low, 9 moderate)** to **13 vulnerabilities (7 low, 6 moderate)**. No high or critical production vulnerabilities are reported. The audit still exits non-zero because unresolved low/moderate advisories remain. No unsafe `npm audit fix`, major downgrade, security-tool suppression, or removal of wallet functionality was performed.

Post-remediation compatibility results:

```text
npm run check: PASS
npm test -- --run: PASS — 93 test files, 449 tests
npm run build: PASS
npm audit --omit=dev: FAIL — 13 vulnerabilities (7 low, 6 moderate)
```

The dependency gate therefore remains `FAIL`, but the remediation reduced the advisory count without breaking the application test or build surface.

```text
DEPENDENCY_REMEDIATION = PARTIAL
DEPENDENCY_VULNERABILITIES_BEFORE = 16
DEPENDENCY_VULNERABILITIES_AFTER = 13
DEPENDENCY_HIGH_CRITICAL_AFTER = 0
```
