# P2.5B Implementation Remediation

## Scope and safety

This pass implements only test and evidence infrastructure for the remaining P2.5B blockers. No production migration, settlement enablement, real transaction, or real funds were used. The database harness is opt-in, refuses non-local/non-test database hosts and non-disposable database names, uses temporary InnoDB tables, and drops them during teardown.

## Implementation status

```text
P2_5B_IMPLEMENTATION_STATUS:
  DATABASE_ROLLBACK_TEST_READY: YES
  FULL_MOCKED_SEND_TEST_READY: YES
  CLIENT_RELOAD_TEST_READY: PARTIAL
  RPC_FAILURE_MATRIX_TEST_READY: PARTIAL
  MONEY_MATH_AUDIT: PASS
  DEPENDENCY_REMEDIATION: FAIL
```

`READY` means implementation and a reproducible command are present. It does not mean the evidence has been independently accepted as a release gate.

## Modified and new files

| File | Change |
|---|---|
| `package.json` | Added `test:p2-5b:db` opt-in command. |
| `scripts/p2-5b-disposable-db-rollback.mjs` | Added real MySQL/InnoDB disposable rollback harness with setup, intentional failure injection, assertions, clean retry, and teardown. |
| `server/fees/p2-5b-mocked-send-lifecycle.test.ts` | Added deterministic mocked fee → confirmation → SEND → confirmation lifecycle test using the real durable operation transition functions. It checks immutable quote identity, known hashes, pending history model, terminal state, replay safety, and duplicate operation rejection. |
| `client/src/pages/SendScreen.tsx` | Existing remediation retained: durable operation recovery, bounded polling, known-hash reconciliation, pending history, and safe terminal mapping. |
| `client/src/lib/wallet/txHistory.ts` | Existing idempotent pending-history helper retained. |
| `client/src/pages/SendScreen.test.ts` | Existing source-level recovery assertions retained. |
| `docs/phase5g-p2-5b-implementation-remediation.md` | This report. |

The repository also contains the earlier exact-arithmetic changes and associated regression tests for EVM, Bitcoin, THORChain, SEND recovery, and transaction history.

## Disposable database test

The harness uses the real `mysql2/promise` client and real InnoDB transactions. It creates three uniquely named temporary tables in the supplied test schema for operation, activity, and fee records. It begins a transaction, inserts all three records, throws `P2_5B_INTENTIONAL_FAILURE_AFTER_FEE_INSERT` before commit, rolls back, and verifies zero rows remain. It then executes a clean retry and verifies exactly one row in each table before dropping all temporary tables.

Run only against an isolated disposable database:

```text
P2_5B_ALLOW_DISPOSABLE_DB=true \
P2_5B_TEST_DATABASE_URL=mysql://user:password@127.0.0.1:3306/paxi_test_<unique> \
npm run test:p2-5b:db
```

The harness refuses production-like hosts and database names. It has not been executed in this sandbox because no MySQL/MariaDB server is available; therefore actual rollback evidence remains pending for independent execution.

## Mocked SEND lifecycle

The new `server/fees/p2-5b-mocked-send-lifecycle.test.ts` calls `createSendOperation`, `getSendOperation`, and `transitionSendOperation` directly. It models deterministic fee and SEND hashes, records pending history by hash, finalizes the existing SEND history row, asserts exactly one fee and one SEND broadcast counter, verifies immutable quote fingerprint preservation, repeats reconciliation without new rows, and rejects a reused operation ID. Additional existing tests cover rollback contract behavior, lifecycle transitions, fee quote binding, fee ledger deduplication, and reconciliation taxonomy.

Run the targeted evidence suite:

```text
npm run check
npm test -- --run \
  server/fees/p2-5b-mocked-send-lifecycle.test.ts \
  server/fees/sendOperationAtomicity.test.ts \
  server/chains/rpc.failover.test.ts \
  client/src/lib/wallet/txHistory.test.ts \
  client/src/pages/SendScreen.test.ts
```

The targeted suite passed with 5 files and 17 tests in this pass.

## Client reload recovery

The implementation persists the operation pointer before broadcast, queries `fees.getSendOperation`, restores known hashes, ensures a deduplicated pending history row, calls durable reconciliation only for known hashes, retries on a bounded 15-second timer, and stops on terminal states. `QUOTED` returns to confirmation rather than falsely entering a broadcast state. The source-level tests prove the wiring, but a browser/application integration harness against a live durable endpoint is not yet present; this status remains partial.

## RPC failure matrix

The existing `server/chains/rpc.failover.test.ts` exercises configured endpoint ordering, primary-to-fallback success, timeout classification, unavailable classification, rate-limit classification, and all-endpoints failure. The actual implementation uses `withRpcHttp`/`withEvmRpc` failover and classified `RpcProviderError` values. A complete matrix for malformed responses, HTTP 500, transaction-not-found, reverted receipts, concurrent reconciliation, and every requested repeated-retry case remains to be added; fallback support is documented only where the repository actually implements it.

## Money-math audit

A repository-focused scan found remaining `Number`, `Math`, and `.toFixed` occurrences in display formatting, timestamp/block metadata, token-decimal metadata, database IDs/counts, market-data normalization, and guarded third-party library boundaries. The remediated transaction paths retain exact values: EVM uses `parseUnits` bigint values; Bitcoin and THORChain keep satoshis as bigint through calculations; Solana uses exact base-unit parsing; and fees/accounting use decimal-string or fixed-point helpers. No newly identified unsafe SEND/base-unit conversion was introduced in this pass.

## Dependency status

`npm audit --omit=dev` currently reports 16 production vulnerabilities: 7 low and 9 moderate. No unsafe forced upgrade, downgrade, audit suppression, or security-tool removal was performed. A package-by-package reachability and compatible-upgrade review remains required before this can be marked PASS.

## Validation performed

| Command | Result |
|---|---|
| `node --check scripts/p2-5b-disposable-db-rollback.mjs` | Passed |
| `npm run check` | Passed |
| Targeted tests | Passed — 5 files, 17 tests |
| Full post-implementation test suite | Passed — 92 files, 446 tests; 0 failures |
| Production build | Passed |
| Full test/build after prior remediation | Passed — 91 files, 443 tests; production build passed |
| `npm audit --omit=dev` | Failed — 16 production vulnerabilities |
| Disposable DB harness | Not executed; no local MySQL/MariaDB available |

## Remaining blockers

The implementation is prepared but P2.5B is not declared complete. Independent execution is still required for actual disposable-database rollback, full client reload against the durable endpoint, the complete controlled RPC failure matrix, and a package-by-package dependency reachability/remediation review.

```text
P2_5B_STATUS = INCOMPLETE
P2_6_ALLOWED = NO
```

Only independent verification may decide whether the evidence closes P2.5B.
