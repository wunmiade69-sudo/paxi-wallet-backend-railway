# Phase 5G P2.5B — Durable SEND Lifecycle + Money-Path Validation

**Verdict: P2.5B INCOMPLETE — READY FOR STAGING MIGRATION REVIEW, NOT SAFE FOR PRODUCTION.**

## 1. Files changed

The implementation adds `drizzle/schema.ts` definitions for `sendOperations`, `shared/sendOperationLifecycle.ts`, `server/fees/sendOperations.ts`, a protected `fees.getSendOperation` endpoint, durable lifecycle integration in `server/fees/sendFee.ts`, `drizzle/phase5g-p2-5b-send-operations.sql`, `scripts/applySendOperationsSchema.ts`, the separate `db:send-operations` package command, and durable lifecycle tests under `server/fees/sendOperationLifecycle.test.ts`.

Existing P2.5 quote binding, linked-wallet ownership, EVM semantic verification, global fee ledger, fallback RPC architecture, and real-settlement-off behavior were preserved.

## 2. Database/schema changes

The new `sendOperations` table binds one operation to the authenticated user, linked wallet, immutable quote and fingerprint, network, asset identity, contract, recipient, transfer amounts, fee amounts, network fee, total wallet debit, fee and SEND hashes, lifecycle state, failure/reconciliation codes, quote expiry, timestamps, and confirmation time. It stores no private keys, seed phrases, mnemonics, or signing material.

The table includes unique operation, fee-hash, and SEND-hash constraints, user/created, quote, and state/update indexes, and foreign keys to `users` and `sendFeeQuotes`. The global cross-product fee transaction uniqueness remains enforced by the existing `feePaymentLedger` unique transaction-hash constraint.

## 3. SEND operation state machine

The durable state machine supports `QUOTED`, `FEE_BROADCAST`, `FEE_CONFIRMED`, `SEND_BROADCAST`, `CONFIRMED`, `FAILED`, and `RECONCILIATION_REQUIRED`. Invalid transitions fail closed. Reconciliation updates known durable state and never rebroadcasts an unknown transaction.

## 4. Quote binding design

Issuing a quote now creates the durable operation from the server-owned quote snapshot and fingerprint. Recording and reconciliation continue to validate the original quote, user, linked wallet, network, asset, recipient, amount, treasury, fee, and expiry. Neither path performs a fresh live repricing.

## 5. Fee ledger design

SEND continues to claim the existing global fee ledger inside the final database transaction. The ledger’s unique fee-transaction-hash constraint prevents reuse across SEND, listing, token creation, and campaign products, including concurrent duplicate attempts. Existing operation retries compare both fee and SEND hashes and fail with `OPERATION_CONFLICT` when either differs.

## 6. Wallet ownership enforcement

The existing server-side linked-wallet proof mechanism remains authoritative. The verifier additionally proves the transaction sender, chain, asset, treasury, exact fee amount, receipt success, and confirmation depth. Unsupported networks remain explicit unavailable paths; no Polygon, Arbitrum, Solana, or Bitcoin SEND fee settlement was enabled.

## 7. Atomic persistence and recovery

A confirmed SEND now persists the durable operation transition, activity event, and fee record within the same database transaction. Reconciliation persists pending, broadcast, confirmed, failed, and reconciliation-required observations by known hashes. The client is not permitted to infer that a missing confirmation authorizes a second broadcast.

## 8. Test matrix and results

The repository’s configured test roots execute the new durable lifecycle tests plus the expanded mocked money-path tests. The focused suite now covers concurrent fee-hash ownership, cross-product replay, idempotent retries, durable state transitions, client reload storage recovery, 18-decimal ETH/BNB arithmetic, six-decimal USDT arithmetic, dust rounding, fee caps, total-debit identity, and unsupported networks. The focused result is **82 passed, 0 failed**. The final full run passed **84 test files and 399 tests** with zero failures.

The implemented test coverage includes realistic ETH/BNB/USDT arithmetic, 18-decimal exactness, minimum USD quantum, fee rounding, total-debit identity, canonical reconciliation code vocabulary, mismatch classification, pending/no-hash behavior, valid/invalid durable state transitions, a mocked concurrent fee-hash race, cross-product fee replay, idempotent ledger retry, durable state persistence, client reload recovery from known broadcast storage, fee-cap enforcement, dust rejection, and unsupported-network fail-closed behavior. Full mocked database/RPC coverage for every listed P2.5B scenario—including database failure rollback, client reload against the durable status endpoint, and a mocked full fee-plus-SEND confirmation path—still requires additional tests before claiming complete behavioral proof.

## 9. Migration status

The clean follow-up migration is `drizzle/phase5g-p2-5b-send-operations.sql`. The idempotent staging command is `npm run db:send-operations`, implemented by `scripts/applySendOperationsSchema.ts`. It was **not executed**. It must be reviewed and applied only in staging after verifying the prerequisite `users` and `sendFeeQuotes` tables and backup/rollback procedures.

## 10. Railway environment variables

No new Railway environment variables are required. Existing RPC endpoint, fallback, confirmation-depth, treasury, database, and settlement feature-flag configuration remains unchanged. The new migration command requires the existing `DATABASE_URL` only when deliberately run against staging.

## 11. Validation

| Check | Result |
|---|---|
| TypeScript | Passed in focused validation (`npm run check`) |
| Focused tests | Passed: 5 files, 82 tests |
| Full tests | Passed: 84 files, 399 tests |
| Build | Passed |
| Lint | No lint script exists in `package.json` |
| Dependency audit | Failed: 16 production dependency vulnerabilities (7 low, 9 moderate) |
| Production migration | Not run |
| Real transactions/treasury | Not performed |

## 12. Security confirmations

No private keys, seed phrases, mnemonics, raw signing material, server wallet secrets, or custodial wallet logic were added. Real SEND fee settlement remains OFF.

## 13. Production-readiness verdict

**P2.5B INCOMPLETE.** The durable schema and core lifecycle integration are present, but the complete required behavioral matrix and final full validation run are not yet proven. **READY FOR STAGING MIGRATION REVIEW. NOT SAFE FOR PRODUCTION.**

## Machine-readable status

P2.5B_STATUS

CODE: FAIL
BIGINT_MATH: PASS
IMMUTABLE_QUOTE: PASS
TOTAL_DEBIT: PASS
GLOBAL_FEE_LEDGER: PASS
WALLET_OWNERSHIP: PASS
ATOMIC_PERSISTENCE: PASS
DATABASE_ROLLBACK: FAIL
FULL_MOCKED_SEND: FAIL
CLIENT_RELOAD_RECOVERY: FAIL
RPC_FAILURE_HANDLING: FAIL
RECONCILIATION: PASS
RETRY_SAFETY: PASS
CROSS_PRODUCT_REPLAY: PASS
USDT_CANONICAL_IDENTITY: PASS
AUTOMATED_TESTS: PASS
BUILD: PASS
MIGRATION_APPLIED: NO
REAL_FUNDS_USED: NO
MAINNET_SETTLEMENT_ENABLED: NO
P2.6_ALLOWED: NO

Rule: `P2.6_ALLOWED = YES` only when every required P2.5B gate passes. P2.5B remains incomplete and P2.6 must not start.
