# PAXI Phase 5G Part 1 — Fee Architecture Completion

**Scope completed.** This work is limited to the PAXI fee architecture requested for Phase 5G Part 1. No provider expansion, charts, Discover, search, notification redesign, admin redesign, public API keys, deployment, production SQL, migrations, or real-funds transactions were run.

## Executive result

The missing **SEND fee architecture is now implemented for EVM Ethereum and BSC only**, using a server-priced quote, a separately displayed same-asset PAXI fee, a user-approved fee transfer to the centralized treasury, a user-approved recipient transfer, local wallet signing, confirmed receipt checks, durable activity and fee records, and a canonical operation identifier for retries.

Solana, Bitcoin/THORChain, bridges, and EVM Polygon/Arbitrum remain explicitly unavailable for PAXI service-fee settlement. A treasury environment variable alone does not activate those paths.

> A nonzero SEND service fee is never silently subtracted from the recipient amount. The recipient receives the full reviewed transfer amount; the PAXI fee is a separate, user-approved transaction.

## Exact files changed

| File | Change |
|---|---|
| [`server/fees/feeConfig.ts`](../server/fees/feeConfig.ts) | Added the `send` operation and its server-owned default schedule entry. |
| [`server/fees/treasury.ts`](../server/fees/treasury.ts) | Centralized chain-specific treasury configuration; added explicit configured, validated, construction, broadcast, confirmation, and settlement states; invalid non-EVM addresses now fail closed. |
| [`drizzle/schema.ts`](../drizzle/schema.ts) | Added `send` to fee enums and added backward-compatible nullable audit metadata: operation ID, wallet, asset, fee currency/amount, decimals, treasury, fee transaction hash, failure reason, and idempotency index. |
| [`drizzle/phase5g-part1-send-fees.sql`](../drizzle/phase5g-part1-send-fees.sql) | Added a review-only migration artifact. It was not executed. |
| [`server/fees/feeEngine.ts`](../server/fees/feeEngine.ts) | Added canonical operation-ID idempotency and expanded fee audit persistence. SEND records require an operation ID. |
| [`server/fees/sendFee.ts`](../server/fees/sendFee.ts) | Added server-priced EVM SEND quote, safety limits, same-asset fee amount conversion, balance guards, confirmed-fee verification, confirmed-send verification, activity recording, fee recording, and retry handling. |
| [`server/feeVerification.ts`](../server/feeVerification.ts) | Added confirmed EVM same-asset transfer verification proving payer, treasury, asset contract, on-chain decimals, amount, and receipt success. |
| [`server/wallet/transactionVerifier.ts`](../server/wallet/transactionVerifier.ts) | Added optional expected recipient and asset checks and actual confirmed network-fee reporting. |
| [`server/routers/fees.ts`](../server/routers/fees.ts) | Added authenticated `getSendQuote` and `recordSend` procedures and exposed the `send` operation in the fee schema. |
| [`client/src/lib/wallet/send.ts`](../client/src/lib/wallet/send.ts) | Added EVM confirmation waiting and fee-transfer gas estimation; signing remains local to the wallet boundary. |
| [`client/src/lib/wallet/balances.ts`](../client/src/lib/wallet/balances.ts) | Exported the existing EVM balance reader for native-gas and asset-balance checks. |
| [`client/src/pages/SendScreen.tsx`](../client/src/pages/SendScreen.tsx) | Added server quote flow, fee-first execution, operation-ID recovery, balance checks, understandable fee breakdown, and disabled controls for unsupported settlement. |
| [`shared/sendFeeGuards.ts`](../shared/sendFeeGuards.ts) | Added browser-safe deterministic native/token balance validation. |
| [`server/fees/sendFee.test.ts`](../server/fees/sendFee.test.ts) | Added focused SEND fee math, zero-fee, maximum-fee, balance, unsupported-network, and operation-ID tests. |
| [`server/fees/treasury.test.ts`](../server/fees/treasury.test.ts) | Updated unavailable-state assertions. |
| [`client/src/pages/SendScreen.test.ts`](../client/src/pages/SendScreen.test.ts) | Replaced the obsolete “not applied” assertion with SEND fee-flow and unsupported-state assertions. |
| [`docs/phase5g-part1-fee-audit.md`](./phase5g-part1-fee-audit.md) | This audit and completion report. |

## Evidence-based operation matrix

| Operation | Network/native gas fee | PAXI fee and currency | Treasury and calculation source | Construction, confirmation, authentication, signing, broadcast | Records, notification, idempotency, recovery | Current status |
|---|---|---|---|---|---|---|
| **SEND** | EVM gas is estimated before review and actual gas is read from confirmed receipts. Native and token transfers use chain-native EVM rules. | For Ethereum/BSC, server-owned `send` configuration is calculated from server-owned asset pricing. The fee is converted into same-asset base units and shown separately from the amount. | `PAXI_TREASURY_ADDRESS` is validated as an EVM address. Fee calculation uses `getFeeConfig("send", "evm")` plus canonical server pricing. | Review → display → auth sheet → local fee transfer signing → fee confirmation → local recipient transfer signing → recipient confirmation → server receipt verification. No private key or seed phrase is sent to the server. | `recordActivity` writes a trusted confirmed SEND event; `recordFee` writes the immutable fee audit record. Local transaction history and local confirmation notification are created. The canonical operation ID and unique database index make repeated record requests idempotent. A timeout preserves known fee/main hashes so retry confirms rather than rebroadcasts. | **PAXI fee settlement supported on Ethereum and BSC.** |
| **EVM SWAP** | Existing Velora route gas estimate and client-side local signing/broadcast. | Existing server-owned `swap_evm` partner fee construction reports source-asset fee units when a settlement-enabled treasury exists. | Central EVM treasury configuration. Existing fee verification boundary remains Ethereum/BSC. | Existing quote → unsigned transaction → approval if needed → local signing → broadcast/optional receipt wait. | Existing local history/activity behavior; no new canonical operation-ID persistence was added to swaps in Part 1. | **Partial existing support; full lifecycle remains incomplete.** |
| **SOLANA SWAP** | Existing Jupiter/Solana native fees. | No verified PAXI fee transfer instruction; the prior empty treasury placeholder is not treated as activation. | `PAXI_SOLANA_TREASURY_ADDRESS` is validation-only; settlement stages remain false. | Existing local Jupiter signing/broadcast only. | No PAXI fee record or durable PAXI operation record. | **PAXI fee settlement unavailable.** |
| **BTC/THORCHAIN SWAP** | Existing Bitcoin UTXO and fee-rate logic plus THORChain provider fees. | No PAXI fee output or verification. | `PAXI_BITCOIN_TREASURY_ADDRESS` is validation-only; settlement stages remain false. | Existing local signing, broadcast, and status polling. | No PAXI fee record or durable PAXI operation record. | **PAXI fee settlement unavailable.** |
| **EVM BRIDGE** | Existing LI.FI/provider estimates and client-side EVM signing/broadcast. | Existing LI.FI integrator fee is only a provider estimate, not a verified PAXI fee. | No server-owned bridge fee construction. | Existing quote, approval, signing, and broadcast path. | No PAXI fee record or canonical fee operation ID. | **PAXI fee settlement unavailable.** |
| **SOLANA BRIDGE** | Existing provider/Solana native fees. | No verified PAXI fee. | No active Solana treasury settlement. | Existing client-side route signing/broadcast. | No PAXI fee record or canonical fee operation ID. | **PAXI fee settlement unavailable.** |
| **BTC BRIDGE** | Existing THORChain/Bitcoin provider and miner-fee handling. | No PAXI fee output. | Bitcoin treasury is validation-only. | Existing client-side construction, signing, broadcast, and tracking. | No PAXI fee record or canonical fee operation ID. | **PAXI fee settlement unavailable.** |
| **TOKEN CREATION / LISTING** | Existing creation gas estimate and fee-payment transaction; listing accepts a payment hash. | Existing fixed server-owned fee paid in USDT/USDC. | `PAXI_TREASURY_ADDRESS`; confirmed Ethereum/BSC stablecoin transfer verification. | Existing local stablecoin payment, creation/deployment, server verification, and listing persistence. | Existing flow-specific fee/activity records and payment-hash reuse protection. | **Existing support remains limited to Ethereum/BSC fee verification.** |

## Supported chains and exact flow

The completed SEND settlement boundary is **Ethereum and BSC**. For a nonzero fee, the user approves two separate EVM transactions on the same chain: first the fee transfer from the sending wallet to the validated `PAXI_TREASURY_ADDRESS`, then the requested transfer to the recipient. The server verifies both confirmed receipts before creating the trusted activity event and immutable fee record.

The following remain unsupported for PAXI fee settlement: **Solana, Bitcoin, THORChain swaps, all bridge operations, Polygon SEND, Arbitrum SEND, and EVM swap lifecycle persistence**. Polygon and Arbitrum treasury addresses can be format-validated, but their fee settlement stages remain disabled because the current verification architecture does not safely confirm settlement there.

## Treasury variables

| Variable | Chain family | Runtime meaning |
|---|---|---|
| `PAXI_TREASURY_ADDRESS` | Ethereum, BSC, Polygon, Arbitrum | Public EVM treasury destination. SEND settlement is enabled only for Ethereum and BSC. |
| `PAXI_SOLANA_TREASURY_ADDRESS` | Solana | Public Solana destination. It is format-validated only; fee settlement remains unavailable. |
| `PAXI_BITCOIN_TREASURY_ADDRESS` | Bitcoin | Public Bitcoin destination. It is format-validated only; fee settlement remains unavailable. |

No private keys, seed phrases, or raw signing secrets are stored or requested.

## Fee calculation examples

With a 50 bps SEND configuration, an asset price of `$2,000`, and a transfer of `0.50` units, the server calculates an asset value of `$1,000` and a PAXI fee of `$5.00`, which is `0.0025` units of the same asset before rounding up to the asset’s supported base unit. If estimated main-transfer gas is `0.0012` native units and the fee-transfer gas estimate is `0.0008` native units, the review shows the combined network-fee estimate as `0.0020` native units, the PAXI fee as `0.0025` asset units, total USD-equivalent debit as the transfer value plus the service fee plus network-fee estimate, and recipient receives exactly `0.50` asset units.

If the fee configuration is zero, the quote remains valid without requiring a treasury or a fee transaction. Safety limits reject a configured SEND rate above **1,000 bps** or a calculated SEND fee above **$10,000**.

## Idempotency and recovery

The client generates a canonical operation identifier before confirmation. The server stores it in `feeRecords` with a unique `(userOpenId, operationId)` index. A repeated record request returns the existing record when the operation and transaction match, and rejects reuse with a different transaction. Fee transaction hashes are also checked against prior fee records.

A timeout after the fee broadcast preserves the fee hash and retries confirmation without creating another fee transfer. A timeout after the main broadcast preserves the main hash and retries confirmation without creating another recipient transfer. Concurrent record requests are protected by the operation ID, activity-event identity, and transaction-hash checks.

## Tests added and validation

The focused suite passed with **3 test files and 14 tests**:

```text
npx vitest run server/fees/sendFee.test.ts server/fees/treasury.test.ts client/src/pages/SendScreen.test.ts
3 passed, 14 tests passed
```

The TypeScript check passed:

```text
npm run check
```

The production build completed and produced `dist/index.js` plus the client bundles. Vite emitted only existing-style bundle-size/dynamic-import warnings; the largest client chunk is approximately 1.66 MB before gzip.

The requested full-suite command was started:

```text
npm test -- --run
```

It progressed through the passing tests but stalled at the network-dependent `server/jupiter.test.ts` stage and was stopped after the timeout. Therefore, the full-suite result is **incomplete rather than passing**. No lint script exists in `package.json`, so lint validation is **not available**.

## Remaining blockers

The new schema requires the review-only SQL migration [`drizzle/phase5g-part1-send-fees.sql`](../drizzle/phase5g-part1-send-fees.sql) to be applied through the project’s normal migration process before the deployed database can persist the new SEND metadata. It was intentionally not run because the task explicitly prohibited database migrations and production SQL.

The project’s current server verification infrastructure does not safely implement Solana, Bitcoin, bridge, Polygon, or Arbitrum PAXI settlement. Those paths remain explicitly unavailable rather than being represented as active merely because environment variables exist.

The existing notification mechanism is local client notification creation after confirmed recording; the inspected schema does not provide a durable server notification table. This Part 1 work does not redesign notifications.

**Phase 5G Part 1 is complete and stops here.**
