# Phase 5G Part 1B — P2.1 Confirmation Policy

## Scope

This phase replaces the previous hard-coded single-confirmation EVM wait with a chain-aware confirmation policy and makes server-side financial verification enforce the same minimum.

## Defaults

- Ethereum: 2 confirmations
- BNB Chain: 3 confirmations
- Polygon: 2 confirmations
- Arbitrum: 2 confirmations
- Unknown EVM networks: 2 confirmations

A confirmation count includes the mined block as confirmation 1 (`latestBlock - receiptBlock + 1`).

## Server overrides

The backend can raise a chain's minimum without changing source code:

```text
ETHEREUM_CONFIRMATIONS=6
BSC_CONFIRMATIONS=6
POLYGON_CONFIRMATIONS=4
ARBITRUM_CONFIRMATIONS=4
```

Only integer values from 1 through 100 are accepted. Invalid values fall back to the safe built-in default. These are not secrets.

## Enforcement points

1. Client EVM confirmation waits for the chain-specific default depth before proceeding.
2. `verifyConfirmedEvmTransaction` checks the current receipt depth on the server before accepting a SEND.
3. `verifyFeePayment` checks receipt depth before accepting a fee payment.

The server remains authoritative. A transaction that is mined but has not reached the required depth is not financially recorded.

## Safety behavior

- No transaction is rebroadcast merely because confirmation depth has not been reached.
- Existing retry behavior continues to reuse known transaction hashes.
- Timeout errors tell the user to retry confirmation rather than send again.
- No production migration, credentials, signing, or broadcast was performed in this phase.
