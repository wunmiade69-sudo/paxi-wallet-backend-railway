# Phase 5G Part 1B — P2.2 Fee-Asset Safety

## Scope

Protect non-zero SEND fee settlement from arbitrary ERC-20 transfer-tax, rebasing, and other non-standard token behavior.

## Policy

The PAXI SEND fee is settled in the same asset being sent. P2.2 therefore fails closed for non-zero service fees:

- Native ETH on Ethereum and BNB on BSC are allowed.
- Canonical USDT and USDC contracts are allowed.
- Arbitrary/custom ERC-20s are rejected for non-zero PAXI SEND fee settlement.
- Zero-fee mode is unchanged: it does not block ordinary ERC-20 sends merely because the token is outside the fee allowlist.

The canonical contract and decimals are resolved through the shared canonical registry.

## Verification

`verifyEvmAssetTransfer` applies the same policy before verifying the receipt. For ERC-20 fees it requires the token contract, payer, treasury, and transfer amount to match the quoted operation. The receipt's treasury-directed Transfer event represents the amount credited according to the token contract's event semantics.

This phase intentionally does not claim universal detection of malicious or unusual token mechanics. Instead, unsupported fee assets are rejected before settlement.

## No production activation

No database migration, Railway deployment, credentials, signing, or real-funds operation was performed. Real SEND fee settlement remains off until the remaining Part 1B gates are complete and staging validation succeeds.
