# Phase 5G Part 1B — P2.3 Network Availability

## Scope

Make SEND fee settlement availability explicit and consistent for Ethereum, BSC, Polygon, Arbitrum, Solana, and Bitcoin.

## Implemented

- Added one shared support matrix: `shared/sendFeeSupport.ts`.
- Ethereum and BSC are the only networks marked as PAXI SEND-fee-settlement supported.
- Polygon and Arbitrum no longer fall through to a generic schema failure in the SEND UI. The client identifies them before requesting a quote and shows an explicit unavailable state.
- Solana and Bitcoin use the same shared unavailable-copy helper.
- The Review button is disabled for EVM networks without a verified PAXI fee settlement path.
- Server settlement remains fail-closed through the same support matrix.
- Added unit tests for the support matrix and user-facing reasons.

## Security boundary

This phase does **not** enable fee settlement for Polygon, Arbitrum, Solana, or Bitcoin. No treasury address is treated as sufficient to activate a chain. A future chain must first implement and test chain-native collection, payer verification, receipt verification, replay protection, and reconciliation before it is added to the supported matrix.

## Validation

The source was inspected after the patch. The local environment does not contain installed dependencies (`vitest` is unavailable), so the new test suite could not be executed here. No production database, Railway deployment, wallet signing, broadcast, or real funds were used.
