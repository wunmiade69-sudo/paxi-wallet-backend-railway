# Provider API Audit Notes

## Birdeye

Official documentation: [Birdeye Getting Started](https://docs.birdeye.so/reference) and [Birdeye API sample/reference overview](https://docs.birdeye.so/docs/premium-apis-1).

The documented authentication mechanism is the server-side `X-API-KEY` header plus an `x-chain` header. The official examples use `https://public-api.birdeye.so/defi/price?address=...` for current token price. The documentation lists token overview, price, price history, OHLCV by token/pair, token market data, token security, search, and pair overview APIs. The adapter must keep the API key server-side and must treat unavailable/unauthorized package access as a provider failure rather than fabricate fields.

## DexScreener

Official documentation: [DEX Screener API Reference](https://docs.dexscreener.com/api/reference).

The documented token-pairs path is `GET /token-pairs/v1/{chainId}/{tokenAddress}` and its pair payload provides chain, pair, base/quote token, price, volume, price change, liquidity, FDV, market cap, and pair timestamps. The existing PAXI adapter already uses this documented normalized shape.

## DexScanner

Search did not identify a separate current official DexScanner API reference. The implementation therefore must not invent a public endpoint or response schema. The adapter is designed as an explicitly disabled, opt-in adapter requiring `DEXSCANNER_API_BASE_URL` and `DEXSCANNER_API_KEY`; when unset it returns no markets. A deployment may enable it only after supplying a documented endpoint contract and mapping response fields to the shared provider schema.

## Moralis security intelligence

Official documentation confirms the ERC20 approvals endpoint as `GET /{address}/approvals?chain={chain}` on the Moralis EVM wallet API, with `X-API-Key` authentication and documented chain values including `eth`, `0x1`, `bsc`, and `0x38`. Official wallet history examples use `GET https://deep-index.moralis.io/api/v2.2/wallets/{address}/history?chain=eth&order=DESC` with `X-API-Key`. These endpoints are suitable for optional server-side approval and address/activity intelligence. No private wallet material is ever included in these requests.
