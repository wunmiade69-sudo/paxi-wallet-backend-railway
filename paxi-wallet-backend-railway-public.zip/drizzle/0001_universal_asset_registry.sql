CREATE TABLE `chains` (
	`id` varchar(32) NOT NULL,
	`name` varchar(64) NOT NULL,
	`chainType` enum('evm','btc','sol','ton') NOT NULL,
	`chainId` int,
	`rpcUrl` varchar(500),
	`explorerUrl` varchar(255),
	`nativeSymbol` varchar(32) NOT NULL,
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chains_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chainId` varchar(32) NOT NULL,
	`assetType` enum('native','token') NOT NULL,
	`identifier` varchar(128) NOT NULL,
	`symbol` varchar(32) NOT NULL,
	`name` varchar(128) NOT NULL,
	`decimals` int NOT NULL DEFAULT 18,
	`logoUrl` varchar(500),
	`status` enum('active','blocked','spam') NOT NULL DEFAULT 'active',
	`verificationStatus` enum('unverified','registered','verified') NOT NULL DEFAULT 'unverified',
	`sourceListingId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `assets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assetMetadata` (
	`assetId` int NOT NULL,
	`description` text,
	`website` varchar(500),
	`twitter` varchar(255),
	`telegram` varchar(255),
	`discord` varchar(255),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `assetMetadata_assetId` PRIMARY KEY(`assetId`)
);
--> statement-breakpoint
ALTER TABLE `assets` ADD CONSTRAINT `assets_chainId_chains_id_fk` FOREIGN KEY (`chainId`) REFERENCES `chains`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `assets` ADD CONSTRAINT `assets_sourceListingId_tokenListings_id_fk` FOREIGN KEY (`sourceListingId`) REFERENCES `tokenListings`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `assetMetadata` ADD CONSTRAINT `assetMetadata_assetId_assets_id_fk` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
CREATE UNIQUE INDEX `assets_chain_identifier_idx` ON `assets` (`chainId`,`identifier`);
