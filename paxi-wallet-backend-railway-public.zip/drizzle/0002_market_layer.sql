CREATE TABLE `dexes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chainId` varchar(32) NOT NULL,
	`name` varchar(64) NOT NULL,
	`factoryAddress` varchar(128),
	`routerAddress` varchar(128),
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dexes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `liquidityPools` (
	`id` int AUTO_INCREMENT NOT NULL,
	`chainId` varchar(32) NOT NULL,
	`dexId` int NOT NULL,
	`poolAddress` varchar(128) NOT NULL,
	`asset0Id` int NOT NULL,
	`asset1Id` int NOT NULL,
	`liquidityUsd` varchar(32),
	`volume24hUsd` varchar(32),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `liquidityPools_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `markets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assetId` int NOT NULL,
	`venueType` enum('dex','cex') NOT NULL,
	`venueId` varchar(64) NOT NULL,
	`pairAssetId` int,
	`poolId` int,
	`symbol` varchar(32),
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `markets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assetMarketData` (
	`assetId` int NOT NULL,
	`priceUsd` varchar(32),
	`priceChange1h` varchar(16),
	`priceChange24h` varchar(16),
	`priceChange7d` varchar(16),
	`volume24hUsd` varchar(32),
	`liquidityUsd` varchar(32),
	`marketCapUsd` varchar(32),
	`fdvUsd` varchar(32),
	`source` varchar(32),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `assetMarketData_assetId` PRIMARY KEY(`assetId`)
);
--> statement-breakpoint
ALTER TABLE `dexes` ADD CONSTRAINT `dexes_chainId_chains_id_fk` FOREIGN KEY (`chainId`) REFERENCES `chains`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `liquidityPools` ADD CONSTRAINT `liquidityPools_chainId_chains_id_fk` FOREIGN KEY (`chainId`) REFERENCES `chains`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `liquidityPools` ADD CONSTRAINT `liquidityPools_dexId_dexes_id_fk` FOREIGN KEY (`dexId`) REFERENCES `dexes`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `liquidityPools` ADD CONSTRAINT `liquidityPools_asset0Id_assets_id_fk` FOREIGN KEY (`asset0Id`) REFERENCES `assets`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `liquidityPools` ADD CONSTRAINT `liquidityPools_asset1Id_assets_id_fk` FOREIGN KEY (`asset1Id`) REFERENCES `assets`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `markets` ADD CONSTRAINT `markets_assetId_assets_id_fk` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `markets` ADD CONSTRAINT `markets_pairAssetId_assets_id_fk` FOREIGN KEY (`pairAssetId`) REFERENCES `assets`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `markets` ADD CONSTRAINT `markets_poolId_liquidityPools_id_fk` FOREIGN KEY (`poolId`) REFERENCES `liquidityPools`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE `assetMarketData` ADD CONSTRAINT `assetMarketData_assetId_assets_id_fk` FOREIGN KEY (`assetId`) REFERENCES `assets`(`id`) ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
CREATE UNIQUE INDEX `dexes_chain_name_idx` ON `dexes` (`chainId`,`name`);
--> statement-breakpoint
CREATE UNIQUE INDEX `liquidityPools_chain_address_idx` ON `liquidityPools` (`chainId`,`poolAddress`);
--> statement-breakpoint
CREATE UNIQUE INDEX `markets_asset_venue_idx` ON `markets` (`assetId`,`venueType`,`venueId`);
