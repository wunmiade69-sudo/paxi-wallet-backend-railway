DROP INDEX `markets_asset_venue_idx` ON `markets`;
--> statement-breakpoint
CREATE UNIQUE INDEX `markets_asset_venue_pool_idx` ON `markets` (`assetId`,`venueType`,`venueId`,`poolId`);
