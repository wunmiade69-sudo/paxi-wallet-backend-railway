CREATE UNIQUE INDEX `markets_asset_venue_symbol_idx` ON `markets` (`assetId`,`venueType`,`venueId`,`symbol`);
