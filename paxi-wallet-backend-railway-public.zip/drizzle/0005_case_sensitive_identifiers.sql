-- Run drizzle/checks/pre_migration_duplicate_check.sql (query 1) first and
-- confirm it returns no rows before applying this.
--
-- MySQL's default utf8mb4 collations (utf8mb4_general_ci / utf8mb4_0900_ai_ci)
-- are case-INSENSITIVE - "AbC" and "abc" compare equal, both in WHERE clauses
-- and in unique-index enforcement. That's fine for EVM addresses, which the
-- app already normalizes to lowercase (normalizeIdentifier in
-- server/assetRegistry.ts), but it silently defeats the point of preserving
-- case for Solana/Bitcoin/TON addresses: the app can correctly keep two
-- differently-cased Solana addresses distinct in TypeScript, and the
-- database can still treat them as the same row.
--
-- utf8mb4_bin compares byte-for-byte, so casing is preserved at the DB layer
-- too - assets_chain_identifier_idx (chainId, identifier) now actually does
-- what normalizeIdentifier() assumes it does.
ALTER TABLE `assets`
  MODIFY `identifier` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL;
