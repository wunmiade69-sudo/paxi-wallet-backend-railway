-- Campaign reward-token escrow and verified payout hardening.
-- Forward-only migration; existing stablecoin listing-fee columns remain intact.

ALTER TABLE `campaigns`
  ADD COLUMN `rewardEscrowRequiredAmount` VARCHAR(128) NULL AFTER `poolFundedAmountUsd`,
  ADD COLUMN `rewardEscrowTokenDecimals` INT NULL AFTER `rewardEscrowRequiredAmount`,
  ADD COLUMN `rewardEscrowAmountUnits` VARCHAR(128) NULL AFTER `rewardEscrowTokenDecimals`,
  ADD COLUMN `rewardEscrowRecipient` VARCHAR(128) NULL AFTER `rewardEscrowAmountUnits`,
  ADD COLUMN `rewardEscrowFundedTxHash` VARCHAR(128) NULL AFTER `rewardEscrowRecipient`,
  ADD COLUMN `rewardEscrowFundedAt` TIMESTAMP NULL AFTER `rewardEscrowFundedTxHash`,
  ADD COLUMN `rewardEscrowVerification` JSON NULL AFTER `rewardEscrowFundedAt`,
  ADD UNIQUE KEY `campaigns_reward_escrow_funded_tx_hash_idx` (`rewardEscrowFundedTxHash`);

ALTER TABLE `campaignEntries`
  ADD COLUMN `payoutWalletAddress` VARCHAR(128) NULL AFTER `userOpenId`;

CREATE TABLE `campaignRewardEscrowVerifications` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `campaignId` INT NOT NULL,
  `transactionHash` VARCHAR(128) NOT NULL,
  `network` VARCHAR(32) NOT NULL,
  `tokenContractAddress` VARCHAR(128) NOT NULL,
  `senderAddress` VARCHAR(128) NOT NULL,
  `escrowRecipient` VARCHAR(128) NOT NULL,
  `tokenDecimals` INT NOT NULL,
  `amountUnits` VARCHAR(128) NOT NULL,
  `status` ENUM('verified','rejected') NOT NULL,
  `verificationData` JSON NULL,
  `createdAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignRewardEscrow_transaction_hash_idx` (`transactionHash`),
  KEY `campaignRewardEscrow_campaign_status_idx` (`campaignId`, `status`, `createdAt`),
  CONSTRAINT `campaignRewardEscrowVerifications_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
