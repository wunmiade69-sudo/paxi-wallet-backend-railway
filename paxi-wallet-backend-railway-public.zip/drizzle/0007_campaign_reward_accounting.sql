-- Forward-only migration. Do not edit or re-run already-applied migrations.

ALTER TABLE `campaigns`
  ADD COLUMN `rewardRequiredAmountUnits` VARCHAR(128) NULL AFTER `rewardEscrowAmountUnits`,
  ADD COLUMN `rewardEscrowedAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardRequiredAmountUnits`,
  ADD COLUMN `rewardReservedAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardEscrowedAmountUnits`,
  ADD COLUMN `rewardClaimedAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardReservedAmountUnits`,
  ADD COLUMN `rewardRemainingAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardClaimedAmountUnits`,
  ADD COLUMN `rewardAccountingUpdatedAt` TIMESTAMP NULL AFTER `rewardRemainingAmountUnits`;

CREATE TABLE `campaignPayouts` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `campaignId` INT NOT NULL,
  `entryId` INT NOT NULL,
  `idempotencyKey` VARCHAR(191) NOT NULL,
  `network` VARCHAR(32) NOT NULL,
  `tokenContractAddress` VARCHAR(128) NOT NULL,
  `recipientAddress` VARCHAR(128) NOT NULL,
  `senderAddress` VARCHAR(128) NULL,
  `amountUnits` VARCHAR(128) NOT NULL,
  `nonce` INT NULL,
  `nonceKey` VARCHAR(191) NULL,
  `transactionHash` VARCHAR(128) NULL,
  `status` ENUM('reserved','broadcast','confirmed','failed') NOT NULL DEFAULT 'reserved',
  `lastError` TEXT NULL,
  `confirmedBlockNumber` INT NULL,
  `createdAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `broadcastAt` TIMESTAMP NULL,
  `confirmedAt` TIMESTAMP NULL,
  `updatedAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaignPayouts_entry_idx` (`entryId`),
  UNIQUE KEY `campaignPayouts_idempotency_idx` (`idempotencyKey`),
  UNIQUE KEY `campaignPayouts_transaction_idx` (`transactionHash`),
  UNIQUE KEY `campaignPayouts_nonce_idx` (`nonceKey`),
  KEY `campaignPayouts_campaign_status_idx` (`campaignId`, `status`, `createdAt`),
  CONSTRAINT `campaignPayouts_campaign_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`),
  CONSTRAINT `campaignPayouts_entry_fk` FOREIGN KEY (`entryId`) REFERENCES `campaignEntries` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
