ALTER TABLE `campaignPayouts`
  MODIFY COLUMN `status` ENUM('reserved','broadcast','confirmed','failed','recovery_required') NOT NULL DEFAULT 'reserved',
  ADD COLUMN `broadcastLeaseUntil` TIMESTAMP NULL AFTER `lastError`;
