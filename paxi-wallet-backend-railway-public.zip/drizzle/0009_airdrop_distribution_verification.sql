-- Forward-only airdrop distribution verification safeguards.
ALTER TABLE `airdropAllocations`
  ADD COLUMN `recipientWalletAddress` varchar(128) NULL AFTER `userOpenId`;

ALTER TABLE `airdropDistributions`
  ADD UNIQUE KEY `airdropDistributions_distribution_tx_hash_idx` (`distributionTxHash`);

-- Existing rows remain incomplete until their distribution is independently verified.
UPDATE `airdropDistributions`
SET `status` = 'approved'
WHERE `status` = 'complete'
  AND (`distributionTxHash` IS NULL OR `distributionTxHash` = '');
