-- Gift Code multi-chain asset binding and fulfillment state.
-- Forward-only migration; safe to apply after the existing rewards schema.

ALTER TABLE `giftCodes`
  ADD COLUMN `assetId` INT NULL AFTER `codeHint`;

ALTER TABLE `giftCodeRedemptions`
  ADD COLUMN `recipientWalletAddress` VARCHAR(128) NULL AFTER `rewardLedgerId`,
  ADD COLUMN `fulfillmentStatus` ENUM('not_required','pending','broadcast','confirmed','failed') NOT NULL DEFAULT 'pending' AFTER `recipientWalletAddress`,
  ADD COLUMN `transactionHash` VARCHAR(128) NULL AFTER `fulfillmentStatus`,
  ADD COLUMN `fulfillmentError` TEXT NULL AFTER `transactionHash`,
  ADD COLUMN `fulfilledAt` TIMESTAMP(3) NULL AFTER `fulfillmentError`;

ALTER TABLE `giftCodeRedemptions`
  ADD UNIQUE KEY `giftCodeRedemptions_transaction_idx` (`transactionHash`);

ALTER TABLE `giftCodes`
  ADD CONSTRAINT `giftCodes_asset_fk` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`);

UPDATE `giftCodeRedemptions`
SET `fulfillmentStatus` = 'not_required'
WHERE `status` = 'credited' AND `rewardLedgerId` IS NOT NULL;
