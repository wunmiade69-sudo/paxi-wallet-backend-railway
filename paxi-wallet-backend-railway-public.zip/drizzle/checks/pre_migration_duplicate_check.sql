-- Run these BEFORE applying 0005_case_sensitive_identifiers.sql (and, if you
-- haven't already, before 0004_fix_cex_market_uniqueness.sql). Both migrations
-- add unique constraints; if the queries below return any rows, resolve those
-- duplicates first (the migration will otherwise fail outright on collision -
-- annoying but safe - or silently keep whichever duplicate MySQL's dedup
-- picks, which is not safe. Check first).

-- 1. Assets that only differ by casing, once you stop case-folding them.
--    Expected to be empty for EVM chains (always stored lowercase already).
--    For Solana/BTC/TON, any row here is two "different" DB rows that were
--    actually meant to be (or were accidentally treated as) the same asset.
SELECT chainId, identifier, COUNT(*) AS collisions
FROM assets
WHERE chainId IN ('solana', 'bitcoin')
GROUP BY chainId, LOWER(identifier)
HAVING COUNT(*) > 1;

-- 2. CEX markets that would collide under the new (assetId, venueType,
--    venueId, symbol) unique index. Should be empty since nothing writes
--    CEX market rows yet (see markets table docs in drizzle/schema.ts) -
--    included so this stays a routine pre-migration check, not a one-off.
SELECT assetId, venueType, venueId, symbol, COUNT(*) AS collisions
FROM markets
WHERE venueType = 'cex'
GROUP BY assetId, venueType, venueId, symbol
HAVING COUNT(*) > 1;
