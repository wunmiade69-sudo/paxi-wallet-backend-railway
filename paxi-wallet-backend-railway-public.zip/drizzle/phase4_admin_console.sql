-- PAXI Wallet Phase 4 Admin Console migration artifact.
-- REVIEW ONLY: this file is intentionally not executed by this task.
-- Apply through the existing controlled database deployment process after review,
-- backups, and a maintenance window if required by the operator.

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `adminRole` varchar(32) NULL,
  ADD COLUMN IF NOT EXISTS `suspendedAt` timestamp NULL,
  ADD COLUMN IF NOT EXISTS `suspensionReason` text NULL;

-- Additive columns for the existing append-only audit ledger. These preserve
-- historical rows while making actor role, outcome, state transitions, and
-- constrained request metadata directly searchable.
ALTER TABLE `adminAuditEvents`
  ADD COLUMN IF NOT EXISTS `actorRole` varchar(32) NULL,
  ADD COLUMN IF NOT EXISTS `result` enum('success','failure','denied') NOT NULL DEFAULT 'success',
  ADD COLUMN IF NOT EXISTS `reason` text NULL,
  ADD COLUMN IF NOT EXISTS `previousState` json NULL,
  ADD COLUMN IF NOT EXISTS `newState` json NULL,
  ADD COLUMN IF NOT EXISTS `requestMetadata` json NULL;

CREATE TABLE IF NOT EXISTS `adminApprovalRequests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requestedByOpenId` varchar(64) NOT NULL,
  `approvedByOpenId` varchar(64) NULL,
  `executedByOpenId` varchar(64) NULL,
  `action` varchar(80) NOT NULL,
  `resourceType` varchar(48) NOT NULL,
  `resourceId` int NULL,
  `payload` json NOT NULL,
  `status` enum('pending','approved','rejected','executed') NOT NULL DEFAULT 'pending',
  `requestReason` text NOT NULL,
  `decisionReason` text NULL,
  `requestedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `decidedAt` timestamp NULL,
  `executedAt` timestamp NULL,
  PRIMARY KEY (`id`),
  KEY `adminApprovalRequests_status_requested_idx` (`status`,`requestedAt`),
  KEY `adminApprovalRequests_resource_idx` (`resourceType`,`resourceId`,`requestedAt`),
  CONSTRAINT `adminApprovalRequests_requestedBy_fk` FOREIGN KEY (`requestedByOpenId`) REFERENCES `users` (`openId`),
  CONSTRAINT `adminApprovalRequests_approvedBy_fk` FOREIGN KEY (`approvedByOpenId`) REFERENCES `users` (`openId`),
  CONSTRAINT `adminApprovalRequests_executedBy_fk` FOREIGN KEY (`executedByOpenId`) REFERENCES `users` (`openId`)
);

CREATE TABLE IF NOT EXISTS `adminFeatureFlags` (
  `key` varchar(80) NOT NULL,
  `enabled` boolean NOT NULL DEFAULT false,
  `config` json NULL,
  `updatedByOpenId` varchar(64) NOT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key`),
  CONSTRAINT `adminFeatureFlags_updatedBy_fk` FOREIGN KEY (`updatedByOpenId`) REFERENCES `users` (`openId`)
);

CREATE TABLE IF NOT EXISTS `adminAnnouncements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kind` enum('system','security','maintenance','provider_outage','ecosystem') NOT NULL,
  `title` varchar(160) NOT NULL,
  `message` text NOT NULL,
  `status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
  `createdByOpenId` varchar(64) NOT NULL,
  `publishedAt` timestamp NULL,
  `archivedAt` timestamp NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `adminAnnouncements_status_created_idx` (`status`,`createdAt`),
  CONSTRAINT `adminAnnouncements_createdBy_fk` FOREIGN KEY (`createdByOpenId`) REFERENCES `users` (`openId`)
);

-- adminAuditEvents is append-only by application policy. Do not add update/delete
-- procedures for it. The table itself is declared in drizzle/schema.ts and must
-- be present before enabling the protected Admin procedures.
