-- Phase 5G P2.5A — server-issued SEND quote snapshots.
-- Apply before phase5g-p2-5b-send-operations.sql.
-- The table stores quote data only; it never stores keys, mnemonics, or signing material.
CREATE TABLE IF NOT EXISTS `sendFeeQuotes` (
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `userOpenId` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `operationId` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `fingerprint` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `network` varchar(32) NOT NULL,
  `walletAddress` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `recipient` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `assetAddress` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `assetSymbol` varchar(32) NOT NULL,
  `assetDecimals` int NOT NULL,
  `amount` varchar(128) NOT NULL,
  `amountUsd` varchar(32) NOT NULL,
  `networkFeeNative` varchar(128) NOT NULL,
  `networkFeeUsd` varchar(32) NOT NULL,
  `paxiFeeAmountUnits` varchar(128) NOT NULL,
  `paxiFeeAmount` varchar(128) NOT NULL,
  `paxiFeeUsd` varchar(32) NOT NULL,
  `totalDebitUsd` varchar(32) NOT NULL,
  `feeCurrency` varchar(32) NOT NULL,
  `treasury` varchar(128) DEFAULT NULL,
  `createdAt` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expiresAt` timestamp(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sendFeeQuotes_user_operation_idx` (`userOpenId`,`operationId`),
  KEY `sendFeeQuotes_fingerprint_idx` (`fingerprint`),
  KEY `sendFeeQuotes_user_created_idx` (`userOpenId`,`createdAt`),
  CONSTRAINT `sendFeeQuotes_user_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
