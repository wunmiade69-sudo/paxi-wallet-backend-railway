-- PAXI Phase 5G Part 1: SEND fee architecture
-- Review-only migration. Do not run automatically; apply through the normal
-- deployment migration process after schema review and backup verification.

ALTER TABLE `feeConfig`
  MODIFY COLUMN `operation` ENUM('send','swap_evm','swap_btc','bridge','create_token','listing') NOT NULL;

ALTER TABLE `feeRecords`
  MODIFY COLUMN `operation` ENUM('send','swap_evm','swap_btc','bridge','create_token','listing') NOT NULL,
  ADD COLUMN `operationId` VARCHAR(128) NULL AFTER `userOpenId`,
  ADD COLUMN `walletAddress` VARCHAR(128) NULL AFTER `operationId`,
  ADD COLUMN `asset` VARCHAR(128) NULL AFTER `chainType`,
  ADD COLUMN `feeCurrency` VARCHAR(32) NULL AFTER `asset`,
  ADD COLUMN `feeAmount` VARCHAR(128) NULL AFTER `feeCurrency`,
  ADD COLUMN `assetDecimals` INT NULL AFTER `feeAmount`,
  ADD COLUMN `treasury` VARCHAR(128) NULL AFTER `assetDecimals`,
  ADD COLUMN `feeTransactionHash` VARCHAR(128) NULL AFTER `transactionHash`,
  ADD COLUMN `failureReason` TEXT NULL AFTER `feeTransactionHash`,
  ADD UNIQUE KEY `feeRecords_user_operation_idx` (`userOpenId`, `operationId`),
  ADD KEY `feeRecords_fee_transaction_hash_idx` (`feeTransactionHash`);
