-- Phase 5G Part 1B: canonical cross-product fee payment ownership ledger.
-- Review/apply only in an isolated staging database after backup.
CREATE TABLE IF NOT EXISTS `feePaymentLedger` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `transactionHash` varchar(128) NOT NULL,
  `userOpenId` varchar(64) NOT NULL,
  `product` enum('send','listing','create_token','campaign') NOT NULL,
  `operationKey` varchar(191) NOT NULL,
  `network` varchar(32) NOT NULL,
  `payerWallet` varchar(128) DEFAULT NULL,
  `treasury` varchar(128) NOT NULL,
  `asset` varchar(128) DEFAULT NULL,
  `amount` varchar(128) NOT NULL,
  `status` enum('claimed','released') NOT NULL DEFAULT 'claimed',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `feePaymentLedger_transaction_hash_unique` (`transactionHash`),
  UNIQUE KEY `feePaymentLedger_product_operation_unique` (`product`,`operationKey`),
  KEY `feePaymentLedger_user_created_idx` (`userOpenId`,`createdAt`),
  CONSTRAINT `feePaymentLedger_user_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`)
) ENGINE=InnoDB;

-- Do not apply the following on a table containing duplicate fee hashes until
-- duplicates have been reviewed and resolved. This converts the old SEND
-- index into a database-enforced uniqueness boundary.
-- ALTER TABLE `feeRecords`
--   DROP INDEX `feeRecords_fee_transaction_hash_idx`,
--   ADD UNIQUE KEY `feeRecords_fee_transaction_hash_unique` (`feeTransactionHash`);
