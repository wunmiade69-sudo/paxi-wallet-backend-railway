-- PAXI Wallet Phase 6 AI Customer Care migration artifact.
-- REVIEW ONLY: this file is intentionally not executed by this task.
-- Apply through the existing controlled database deployment process after
-- review, backups, and a maintenance window if required by the operator.

CREATE TABLE IF NOT EXISTS `supportTickets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `userOpenId` varchar(64) NULL,
  `walletAddress` varchar(128) NULL,
  `contactEmail` varchar(255) NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `category` enum('wallet_access','transaction_issue','swap_bridge','security_concern','fees_billing','feature_request','other') NOT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `status` enum('open','in_progress','waiting_on_user','resolved','closed') NOT NULL DEFAULT 'open',
  `aiSummary` text NULL,
  `aiSuggestedCategory` varchar(32) NULL,
  `aiSuggestedPriority` varchar(16) NULL,
  `aiConfidencePercent` int NULL,
  `assignedAdminOpenId` varchar(64) NULL,
  `resolutionNote` text NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `resolvedAt` timestamp NULL,
  PRIMARY KEY (`id`),
  KEY `supportTickets_status_priority_idx` (`status`, `priority`, `createdAt`),
  KEY `supportTickets_user_idx` (`userOpenId`, `createdAt`),
  CONSTRAINT `supportTickets_userOpenId_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`),
  CONSTRAINT `supportTickets_assignedAdmin_fk` FOREIGN KEY (`assignedAdminOpenId`) REFERENCES `users` (`openId`)
);
