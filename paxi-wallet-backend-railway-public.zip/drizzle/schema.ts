import { bigint, boolean, index, int, json, mysqlEnum, mysqlTable, primaryKey, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  /** Additive granular role; legacy role remains for backward compatibility. */
  adminRole: mysqlEnum("adminRole", ["super_admin", "operations_admin", "support_admin", "compliance_admin", "content_admin"]),
  suspendedAt: timestamp("suspendedAt"),
  suspensionReason: text("suspensionReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Cryptographically verified wallets belonging to an authenticated user. */
export const walletLinks = mysqlTable(
  "walletLinks",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    walletAddress: varchar("walletAddress", { length: 128 }).notNull(),
    chainType: varchar("chainType", { length: 16 }).notNull(),
    verifiedAt: timestamp("verifiedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userWalletUniqueIdx: uniqueIndex("walletLinks_user_wallet_unique").on(table.userOpenId, table.walletAddress),
    walletIdx: index("walletLinks_wallet_idx").on(table.walletAddress),
  }),
);

/** Short-lived server-issued challenges used for wallet ownership proofs. */
export const walletLinkChallenges = mysqlTable(
  "walletLinkChallenges",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    walletAddress: varchar("walletAddress", { length: 128 }).notNull(),
    nonce: varchar("nonce", { length: 64 }).notNull(),
    message: text("message").notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    challengeNonceUniqueIdx: uniqueIndex("walletLinkChallenges_nonce_unique").on(table.nonce),
    challengeLookupIdx: index("walletLinkChallenges_lookup_idx").on(table.userOpenId, table.walletAddress, table.expiresAt),
  }),
);

/**
 * Every token Paxi knows a logo/verification status for - trusted seeds
 * (USDT, USDC, ...), tokens minted through Paxi's own token-creation tool,
 * and tokens a project submitted + paid to list. Looked up by
 * (contractAddress, network) whenever a token is imported or shown in
 * Discover, so any wallet instance gets the same logo/badge instantly.
 *
 * NOTE: this table only controls the logo + "verified" badge shown in the
 * UI. It must never gate whether a token can be imported or sent/received -
 * that has to keep working for every token, listed or not.
 */
export const tokenListings = mysqlTable(
  "tokenListings",
  {
    id: int("id").autoincrement().primaryKey(),
    /** Checksum/lowercase contract address. Combined with network for uniqueness. */
    contractAddress: varchar("contractAddress", { length: 64 }).notNull(),
    /** Matches NetworkConfig.id from client/src/lib/wallet/chains.ts, e.g. "bsc". */
    network: varchar("network", { length: 32 }).notNull(),
    symbol: varchar("symbol", { length: 32 }).notNull(),
    name: varchar("name", { length: 128 }).notNull(),
    /** Storage key from storagePut() - resolve via /manus-storage/{logoKey}. Used for community/created listings. */
    logoKey: varchar("logoKey", { length: 255 }),
    /** Direct external logo URL - used for seed entries (well-known tokens) instead of storagePut, since there's nothing to review/host ourselves. */
    logoUrl: varchar("logoUrl", { length: 500 }),
    /**
     * seed = pre-loaded trusted list (USDT/USDC/...), free, verified on insert.
     * created = minted via Paxi's own token-creation flow, verified on insert.
     * community = submitted by a project for a paid Discover listing, needs review.
     */
    source: mysqlEnum("source", ["seed", "created", "community"]).notNull(),
    status: mysqlEnum("status", ["pending", "verified", "rejected"])
      .default("pending")
      .notNull(),
    /** Free-form: { twitter?, telegram?, website?, discord? } */
    socials: json("socials").$type<Record<string, string>>(),
    plan: text("plan"),
    /** On-chain hash of the listing/creation fee payment, for admin verification. */
    feeTxHash: varchar("feeTxHash", { length: 128 }),
    feeAmountUsd: varchar("feeAmountUsd", { length: 16 }),
    submittedByOpenId: varchar("submittedByOpenId", { length: 64 }).references(() => users.openId),
    reviewedByOpenId: varchar("reviewedByOpenId", { length: 64 }),
    rejectionReason: text("rejectionReason"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    tokenKey: uniqueIndex("tokenListings_contract_network_idx").on(
      table.contractAddress,
      table.network,
    ),
    statusCreatedIdx: index("tokenListings_status_created_idx").on(table.status, table.createdAt),
    submittedByIdx: index("tokenListings_submitted_by_updated_idx").on(table.submittedByOpenId, table.updatedAt),
    feeTxHashIdx: uniqueIndex("tokenListings_fee_tx_hash_idx").on(table.feeTxHash),
  }),
);

export type TokenListing = typeof tokenListings.$inferSelect;
export type InsertTokenListing = typeof tokenListings.$inferInsert;

/** Immutable owner/admin-facing lifecycle events for paid listing submissions and reviews. */
export const listingEvents = mysqlTable(
  "listingEvents",
  {
    id: int("id").autoincrement().primaryKey(),
    listingId: int("listingId")
      .notNull()
      .references(() => tokenListings.id),
    eventType: mysqlEnum("eventType", ["submitted", "resubmitted", "auto_verified", "verified", "rejected"]).notNull(),
    actorOpenId: varchar("actorOpenId", { length: 64 }),
    message: text("message"),
    feeTxHash: varchar("feeTxHash", { length: 128 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    listingCreatedIdx: index("listingEvents_listing_created_idx").on(table.listingId, table.createdAt),
  }),
);

export type ListingEvent = typeof listingEvents.$inferSelect;

/** Immutable record of sensitive PAXI administrator actions. Never update or delete rows here. */
export const adminAuditEvents = mysqlTable(
  "adminAuditEvents",
  {
    id: int("id").autoincrement().primaryKey(),
    actorOpenId: varchar("actorOpenId", { length: 64 }).notNull().references(() => users.openId),
    action: varchar("action", { length: 80 }).notNull(),
    resourceType: varchar("resourceType", { length: 48 }).notNull(),
    resourceId: int("resourceId"),
    details: json("details").$type<Record<string, unknown>>(),
    /** Server-derived role and outcome fields make audit queries explicit while details preserves compatibility. */
    actorRole: varchar("actorRole", { length: 32 }),
    result: mysqlEnum("result", ["success", "failure", "denied"]).default("success"),
    reason: text("reason"),
    previousState: json("previousState").$type<Record<string, unknown>>(),
    newState: json("newState").$type<Record<string, unknown>>(),
    requestMetadata: json("requestMetadata").$type<Record<string, string | null>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    actorCreatedIdx: index("adminAuditEvents_actor_created_idx").on(table.actorOpenId, table.createdAt),
    resourceCreatedIdx: index("adminAuditEvents_resource_created_idx").on(table.resourceType, table.resourceId, table.createdAt),
  }),
);

export type AdminAuditEvent = typeof adminAuditEvents.$inferSelect;

/**
 * A promo a token owner runs after their listing is verified - e.g. "trade
 * $50 of PAXI, first 100 people get $1.50 back". One listing can have many
 * campaigns (e.g. a new one each month). Requires a funded reward pool
 * before it can go active - see poolFundedTxHash.
 */
export const campaigns = mysqlTable("campaigns", {
  id: int("id").autoincrement().primaryKey(),
  listingId: int("listingId")
    .notNull()
    .references(() => tokenListings.id),
  title: varchar("title", { length: 128 }).notNull(),
  description: text("description"),
  /** Private object-storage keys until an administrator approves public visibility. */
  bannerKey: varchar("bannerKey", { length: 255 }),
  iconKey: varchar("iconKey", { length: 255 }),
  website: varchar("website", { length: 500 }),
  socials: json("socials").$type<Record<string, string>>(),
  /** Only "swap_volume" is supported today - see submitTaskProof for why. */
  taskType: mysqlEnum("taskType", ["swap_volume"]).default("swap_volume").notNull(),
  /** Task requirement: trade at least this many taskToken units inside Paxi's swap. */
  minTokenAmount: varchar("minTokenAmount", { length: 64 }).notNull(),
  taskTokenSymbol: varchar("taskTokenSymbol", { length: 32 }).notNull(),
  taskTokenContractAddress: varchar("taskTokenContractAddress", { length: 64 }),
  taskTokenNetwork: varchar("taskTokenNetwork", { length: 32 }).notNull(),
  /** Reward paid per winning slot. */
  rewardAmount: varchar("rewardAmount", { length: 64 }).notNull(),
  rewardTokenSymbol: varchar("rewardTokenSymbol", { length: 32 }).notNull(),
  rewardTokenContractAddress: varchar("rewardTokenContractAddress", { length: 64 }),
  rewardNetwork: varchar("rewardNetwork", { length: 32 }).notNull(),
  maxWinners: int("maxWinners").notNull(),
  /** Slots claimed so far - only ever incremented inside a locked transaction, see campaigns.ts. */
  winnersCount: int("winnersCount").default(0).notNull(),
  /** Proof the owner deposited the full reward pool (maxWinners * rewardAmount) to the Paxi treasury as escrow. */
  poolRequiredAmountUsd: varchar("poolRequiredAmountUsd", { length: 16 }).notNull(),
  poolFundedTxHash: varchar("poolFundedTxHash", { length: 128 }),
  poolFundedAmountUsd: varchar("poolFundedAmountUsd", { length: 16 }),
  /** Administrator-curated placement on the banner-only wallet home carousel. */
  isFeatured: boolean("isFeatured").default(false).notNull(),
  featuredAt: timestamp("featuredAt"),
  /** Lets PAXI pause new reward claims without changing immutable eligibility evidence. */
  claimsPaused: boolean("claimsPaused").default(false).notNull(),
  status: mysqlEnum("status", ["draft", "pending_review", "active", "suspended", "rejected", "ended", "cancelled"]).default("draft").notNull(),
  startAt: timestamp("startAt"),
  endAt: timestamp("endAt"),
  createdByOpenId: varchar("createdByOpenId", { length: 64 }).notNull().references(() => users.openId),
  submittedAt: timestamp("submittedAt"),
  reviewedAt: timestamp("reviewedAt"),
  reviewedByOpenId: varchar("reviewedByOpenId", { length: 64 }),
  rejectionReason: text("rejectionReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  statusTimelineIdx: index("campaigns_status_timeline_idx").on(table.status, table.startAt, table.endAt),
  featuredTimelineIdx: index("campaigns_featured_timeline_idx").on(table.isFeatured, table.status, table.startAt, table.endAt),
  listingUpdatedIdx: index("campaigns_listing_updated_idx").on(table.listingId, table.updatedAt),
  createdByIdx: index("campaigns_created_by_idx").on(table.createdByOpenId, table.createdAt),
  poolFundedTxHashIdx: uniqueIndex("campaigns_pool_funded_tx_hash_idx").on(table.poolFundedTxHash),
}));

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

/**
 * One row per user per campaign. `slotNumber` is only set once they qualify,
 * and is what makes them a "winner" - assigned atomically (see
 * server/routers/campaigns.ts claimSlot) so two people can never both become
 * winner #100.
 */
export const campaignEntries = mysqlTable(
  "campaignEntries",
  {
    id: int("id").autoincrement().primaryKey(),
    campaignId: int("campaignId")
      .notNull()
      .references(() => campaigns.id),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    /** Accumulated swap volume toward minTokenAmount, as a decimal string. */
    progressAmount: varchar("progressAmount", { length: 64 }).default("0").notNull(),
    /** 1-based winner rank. Null until the task requirement is met. */
    slotNumber: int("slotNumber"),
    qualifiedAt: timestamp("qualifiedAt"),
    /** Swap tx hash that pushed this entry over the requirement. */
    proofTxHash: varchar("proofTxHash", { length: 128 }),
    /** Claimable is an authorised, idempotent request; paid is set only after confirmed reward distribution. */
    payoutStatus: mysqlEnum("payoutStatus", ["pending", "claimable", "paid"]).default("pending").notNull(),
    claimRequestedAt: timestamp("claimRequestedAt"),
    payoutTxHash: varchar("payoutTxHash", { length: 128 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    oneEntryPerUser: uniqueIndex("campaignEntries_campaign_user_idx").on(table.campaignId, table.userOpenId),
    oneUserPerSlot: uniqueIndex("campaignEntries_campaign_slot_idx").on(table.campaignId, table.slotNumber),
    userTimelineIdx: index("campaignEntries_user_created_idx").on(table.userOpenId, table.createdAt),
    proofTxHashIdx: uniqueIndex("campaignEntries_proof_tx_hash_idx").on(table.proofTxHash),
    payoutTxHashIdx: uniqueIndex("campaignEntries_payout_tx_hash_idx").on(table.payoutTxHash),
  }),
);

export type CampaignEntry = typeof campaignEntries.$inferSelect;
export type InsertCampaignEntry = typeof campaignEntries.$inferInsert;

/**
 * Append-only server-side wallet activity ledger. The client localStorage log is
 * intentionally separate: this table is the auditable source used for active-day
 * calculations and external eligibility exports. Amounts are decimal strings so
 * large token quantities never pass through binary floating-point arithmetic.
 */
export const activityEvents = mysqlTable(
  "activityEvents",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    walletAddress: varchar("walletAddress", { length: 128 }).notNull(),
    // FK to chains.id is installed by the idempotent deployment script after all base tables exist.
    chainId: varchar("chainId", { length: 32 }).notNull(),
    eventType: mysqlEnum("eventType", [
      "wallet_creation",
      "token_creation",
      "buy",
      "sell",
      "swap",
      "bridge",
      "send",
      "receive",
      "deposit",
      "withdrawal",
    ]).notNull(),
    transactionHash: varchar("transactionHash", { length: 128 }),
    // FK to assets.id is installed by the idempotent deployment script after all base tables exist.
    assetId: int("assetId"),
    amount: varchar("amount", { length: 128 }),
    amountUsd: varchar("amountUsd", { length: 32 }),
    feeUsd: varchar("feeUsd", { length: 32 }),
    networkFeeUsd: varchar("networkFeeUsd", { length: 32 }),
    paxiFeeUsd: varchar("paxiFeeUsd", { length: 32 }),
    /** Provenance of the operation semantics used for eligibility and rewards. */
    verificationSource: mysqlEnum("verificationSource", ["legacy", "server_semantic", "server_internal"]).default("legacy").notNull(),
    /** Provenance of amountUsd; client-derived values are never authoritative. */
    amountUsdSource: mysqlEnum("amountUsdSource", ["legacy", "onchain_stablecoin", "server_internal", "none"]).default("legacy").notNull(),
    status: mysqlEnum("status", ["pending", "confirmed", "failed"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userCreatedIdx: index("activityEvents_user_created_idx").on(table.userOpenId, table.createdAt),
    userTypeCreatedIdx: index("activityEvents_user_type_created_idx").on(table.userOpenId, table.eventType, table.createdAt),
    transactionHashIdx: index("activityEvents_transaction_hash_idx").on(table.transactionHash),
    chainCreatedIdx: index("activityEvents_chain_created_idx").on(table.chainId, table.createdAt),
    userIdIdx: index("activityEvents_user_id_idx").on(table.userOpenId, table.id),
    trustedSourceIdx: index("activityEvents_user_status_source_idx").on(table.userOpenId, table.status, table.verificationSource, table.createdAt),
    idempotencyIdx: uniqueIndex("activityEvents_user_wallet_tx_type_idx").on(table.userOpenId, table.walletAddress, table.chainId, table.transactionHash, table.eventType),
  }),
);

export type ActivityEvent = typeof activityEvents.$inferSelect;
export type InsertActivityEvent = typeof activityEvents.$inferInsert;

/** Database-owned PAXI fee schedule. Values are never sourced from the client. */
export const feeConfig = mysqlTable(
  "feeConfig",
  {
    id: int("id").autoincrement().primaryKey(),
    operation: mysqlEnum("operation", ["send", "swap_evm", "swap_btc", "bridge", "create_token", "listing"]).notNull(),
    chainType: varchar("chainType", { length: 32 }).notNull(),
    percentageBps: int("percentageBps").default(0).notNull(),
    fixedUsd: varchar("fixedUsd", { length: 32 }).default("0").notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    operationChainIdx: uniqueIndex("feeConfig_operation_chain_idx").on(table.operation, table.chainType),
    activeIdx: index("feeConfig_active_idx").on(table.isActive, table.operation),
  }),
);

export type FeeConfig = typeof feeConfig.$inferSelect;
export type InsertFeeConfig = typeof feeConfig.$inferInsert;

/** Immutable audit record of every backend-calculated fee. */
export const feeRecords = mysqlTable(
  "feeRecords",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    /** Canonical pre-broadcast operation identity for new fee-aware flows. */
    operationId: varchar("operationId", { length: 128 }),
    walletAddress: varchar("walletAddress", { length: 128 }),
    activityEventId: bigint("activityEventId", { mode: "number" }).references(() => activityEvents.id),
    operation: mysqlEnum("operation", ["send", "swap_evm", "swap_btc", "bridge", "create_token", "listing"]).notNull(),
    chainType: varchar("chainType", { length: 32 }).notNull(),
    asset: varchar("asset", { length: 128 }),
    feeCurrency: varchar("feeCurrency", { length: 32 }),
    feeAmount: varchar("feeAmount", { length: 128 }),
    assetDecimals: int("assetDecimals"),
    treasury: varchar("treasury", { length: 128 }),
    inputAmountUsd: varchar("inputAmountUsd", { length: 32 }).notNull(),
    paxiFeeUsd: varchar("paxiFeeUsd", { length: 32 }).notNull(),
    networkFeeUsd: varchar("networkFeeUsd", { length: 32 }).notNull(),
    totalFeeUsd: varchar("totalFeeUsd", { length: 32 }).notNull(),
    transactionHash: varchar("transactionHash", { length: 128 }),
    feeTransactionHash: varchar("feeTransactionHash", { length: 128 }),
    failureReason: text("failureReason"),
    status: mysqlEnum("status", ["pending", "confirmed", "failed"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    activityIdx: uniqueIndex("feeRecords_activity_event_idx").on(table.activityEventId),
    operationIdx: uniqueIndex("feeRecords_user_operation_idx").on(table.userOpenId, table.operationId),
    userCreatedIdx: index("feeRecords_user_created_idx").on(table.userOpenId, table.createdAt),
    transactionHashIdx: index("feeRecords_transaction_hash_idx").on(table.transactionHash),
    feeTransactionHashIdx: index("feeRecords_fee_transaction_hash_idx").on(table.feeTransactionHash),
  }),
);

export type FeeRecord = typeof feeRecords.$inferSelect;
export type InsertFeeRecord = typeof feeRecords.$inferInsert;

/** Server-issued immutable SEND quote snapshot. A quote is bound to the authenticated user and exact transaction inputs until expiry. */
export const sendFeeQuotes = mysqlTable(
  "sendFeeQuotes",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    operationId: varchar("operationId", { length: 128 }).notNull(),
    fingerprint: varchar("fingerprint", { length: 128 }).notNull(),
    network: varchar("network", { length: 32 }).notNull(),
    walletAddress: varchar("walletAddress", { length: 128 }).notNull(),
    recipient: varchar("recipient", { length: 128 }).notNull(),
    assetAddress: varchar("assetAddress", { length: 128 }),
    assetSymbol: varchar("assetSymbol", { length: 32 }).notNull(),
    assetDecimals: int("assetDecimals").notNull(),
    amount: varchar("amount", { length: 128 }).notNull(),
    amountUsd: varchar("amountUsd", { length: 32 }).notNull(),
    networkFeeNative: varchar("networkFeeNative", { length: 128 }).notNull(),
    networkFeeUsd: varchar("networkFeeUsd", { length: 32 }).notNull(),
    paxiFeeAmountUnits: varchar("paxiFeeAmountUnits", { length: 128 }).notNull(),
    paxiFeeAmount: varchar("paxiFeeAmount", { length: 128 }).notNull(),
    paxiFeeUsd: varchar("paxiFeeUsd", { length: 32 }).notNull(),
    totalDebitUsd: varchar("totalDebitUsd", { length: 32 }).notNull(),
    feeCurrency: varchar("feeCurrency", { length: 32 }).notNull(),
    treasury: varchar("treasury", { length: 128 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
  },
  (table) => ({
    userOperationIdx: uniqueIndex("sendFeeQuotes_user_operation_idx").on(table.userOpenId, table.operationId),
    fingerprintIdx: index("sendFeeQuotes_fingerprint_idx").on(table.fingerprint),
    userCreatedIdx: index("sendFeeQuotes_user_created_idx").on(table.userOpenId, table.createdAt),
  }),
);

export type SendFeeQuoteRow = typeof sendFeeQuotes.$inferSelect;
export type InsertSendFeeQuote = typeof sendFeeQuotes.$inferInsert;

/** Durable server-side SEND lifecycle record. It contains transaction identifiers and quote data only; never signing material. */
export const sendOperations = mysqlTable(
  "sendOperations",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    operationId: varchar("operationId", { length: 128 }).notNull(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    linkedWalletAddress: varchar("linkedWalletAddress", { length: 128 }).notNull(),
    quoteId: varchar("quoteId", { length: 64 }).notNull().references(() => sendFeeQuotes.id),
    quoteFingerprint: varchar("quoteFingerprint", { length: 128 }).notNull(),
    network: varchar("network", { length: 32 }).notNull(),
    assetIdentity: varchar("assetIdentity", { length: 160 }).notNull(),
    contractAddress: varchar("contractAddress", { length: 128 }),
    recipientAddress: varchar("recipientAddress", { length: 128 }).notNull(),
    transferAmount: varchar("transferAmount", { length: 128 }).notNull(),
    transferAmountUnits: varchar("transferAmountUnits", { length: 128 }).notNull(),
    transferAmountUsd: varchar("transferAmountUsd", { length: 32 }).notNull(),
    paxiServiceFee: varchar("paxiServiceFee", { length: 128 }).notNull(),
    paxiServiceFeeUnits: varchar("paxiServiceFeeUnits", { length: 128 }).notNull(),
    paxiServiceFeeUsd: varchar("paxiServiceFeeUsd", { length: 32 }).notNull(),
    networkFee: varchar("networkFee", { length: 128 }).notNull(),
    networkFeeUsd: varchar("networkFeeUsd", { length: 32 }).notNull(),
    totalWalletDebitUsd: varchar("totalWalletDebitUsd", { length: 32 }).notNull(),
    feeTransactionHash: varchar("feeTransactionHash", { length: 128 }),
    sendTransactionHash: varchar("sendTransactionHash", { length: 128 }),
    state: mysqlEnum("state", ["QUOTED", "FEE_BROADCAST", "FEE_CONFIRMED", "SEND_BROADCAST", "CONFIRMED", "FAILED", "RECONCILIATION_REQUIRED"]).default("QUOTED").notNull(),
    failureCode: varchar("failureCode", { length: 64 }),
    reconciliationCode: varchar("reconciliationCode", { length: 64 }),
    quoteExpiresAt: timestamp("quoteExpiresAt").notNull(),
    confirmedAt: timestamp("confirmedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    operationUniqueIdx: uniqueIndex("sendOperations_operation_unique").on(table.operationId),
    userCreatedIdx: index("sendOperations_user_created_idx").on(table.userOpenId, table.createdAt),
    quoteIdx: index("sendOperations_quote_idx").on(table.quoteId),
    feeHashUniqueIdx: uniqueIndex("sendOperations_fee_hash_unique").on(table.feeTransactionHash),
    sendHashUniqueIdx: uniqueIndex("sendOperations_send_hash_unique").on(table.sendTransactionHash),
    stateUpdatedIdx: index("sendOperations_state_updated_idx").on(table.state, table.updatedAt),
  }),
);
export type SendOperation = typeof sendOperations.$inferSelect;
export type InsertSendOperation = typeof sendOperations.$inferInsert;

/** Frozen activity/eligibility state for an admin-controlled campaign snapshot. */
export const campaignSnapshots = mysqlTable(
  "campaignSnapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    campaignId: int("campaignId").notNull().references(() => campaigns.id),
    snapshotDate: timestamp("snapshotDate").notNull(),
    status: mysqlEnum("status", ["pending", "frozen", "calculating", "complete", "distributed"]).default("pending").notNull(),
    totalParticipants: int("totalParticipants").default(0).notNull(),
    qualifiedCount: int("qualifiedCount").default(0).notNull(),
    snapshotData: json("snapshotData"),
    frozenAt: timestamp("frozenAt"),
    calculatedAt: timestamp("calculatedAt"),
    distributedAt: timestamp("distributedAt"),
    createdByOpenId: varchar("createdByOpenId", { length: 64 }).notNull().references(() => users.openId),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    campaignDateIdx: uniqueIndex("campaignSnapshots_campaign_date_idx").on(table.campaignId, table.snapshotDate),
    statusCreatedIdx: index("campaignSnapshots_status_created_idx").on(table.status, table.createdAt),
  }),
);

export type CampaignSnapshot = typeof campaignSnapshots.$inferSelect;
export type InsertCampaignSnapshot = typeof campaignSnapshots.$inferInsert;

/** One frozen, per-user activity aggregate belonging to a campaign snapshot. */
export const campaignSnapshotParticipants = mysqlTable(
  "campaignSnapshotParticipants",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    snapshotId: int("snapshotId").notNull().references(() => campaignSnapshots.id),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    wallets: json("wallets").$type<string[]>().notNull(),
    chains: json("chains").$type<string[]>().notNull(),
    activeDays: int("activeDays").default(0).notNull(),
    totalConfirmedEvents: int("totalConfirmedEvents").default(0).notNull(),
    totalVolumeUsd: varchar("totalVolumeUsd", { length: 32 }).default("0").notNull(),
    eventCounts: json("eventCounts").$type<Record<string, number>>().notNull(),
    volumeUsdByType: json("volumeUsdByType").$type<Record<string, string>>().notNull(),
    requirements: json("requirements").$type<Record<string, boolean>>(),
    externalScore: int("externalScore"),
    eligibilityTier: mysqlEnum("eligibilityTier", ["pending", "not_qualified", "minimum", "highest"]).default("pending").notNull(),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    snapshotUserIdx: uniqueIndex("campaignSnapshotParticipants_snapshot_user_idx").on(table.snapshotId, table.userOpenId),
    eligibilityIdx: index("campaignSnapshotParticipants_eligibility_idx").on(table.snapshotId, table.eligibilityTier),
    userIdx: index("campaignSnapshotParticipants_user_idx").on(table.userOpenId, table.createdAt),
  }),
);

export type CampaignSnapshotParticipant = typeof campaignSnapshotParticipants.$inferSelect;
export type InsertCampaignSnapshotParticipant = typeof campaignSnapshotParticipants.$inferInsert;

/**
 * Persisted cache for CoinGecko market data (Markets list, search, Token
 * Detail, and chart series). Backs server/marketData.ts so the Markets
 * screen and Token Detail chart are served from our own DB instead of
 * waiting on a live CoinGecko call on every request, and so the cache
 * survives a server restart instead of resetting like a pure in-memory
 * cache would.
 */
export const marketDataCache = mysqlTable("marketDataCache", {
  /** e.g. "markets:market_cap_desc:1:50", "detail:bitcoin", "chart:bitcoin:7". */
  cacheKey: varchar("cacheKey", { length: 191 }).primaryKey(),
  payload: json("payload").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MarketDataCacheRow = typeof marketDataCache.$inferSelect;
export type InsertMarketDataCacheRow = typeof marketDataCache.$inferInsert;

/**
 * ============================================================================
 * UNIVERSAL ASSET REGISTRY (Phase 1 of the PAXI data-platform architecture)
 * ============================================================================
 * One asset model for every chain instead of a separate table per chain.
 * `tokenListings` above is NOT removed - it stays the source of truth for
 * the paid-listing/fee/review workflow (campaigns.listingId still points at
 * it). These tables are an additive, generalized registry that:
 *   - lets non-BSC / non-created tokens (Solana, TON, BTC-native, or tokens
 *     nobody ever submitted a paid listing for) get a row too
 *   - gives Phase 2 (markets/liquidity) and Phase 3 (candles) a normalized
 *     `assetId` to hang data off, instead of a (network, contractAddress)
 *     string pair everywhere
 * `server/assetRegistry.ts` keeps this in sync with `tokenListings` on every
 * write, so nothing that already depends on `tokenListings` has to change.
 */

/**
 * One row per chain PAXI Wallet supports. Mirrors
 * client/src/lib/wallet/chains.ts BASE_NETWORKS - `id` matches
 * NetworkConfig.id (e.g. "bsc", "ethereum", "solana", "bitcoin") so
 * assets.chainId can be joined straight against the client's network config.
 */
export const chains = mysqlTable("chains", {
  /** Matches NetworkConfig.id from client/src/lib/wallet/chains.ts, e.g. "bsc". */
  id: varchar("id", { length: 32 }).primaryKey(),
  name: varchar("name", { length: 64 }).notNull(),
  /** "evm" | "btc" | "sol" - matches client ChainType. More chain types (e.g. "ton") get added here as they're supported. */
  chainType: mysqlEnum("chainType", ["evm", "btc", "sol", "ton"]).notNull(),
  /** EVM chain ID (1 = Ethereum, 56 = BSC, ...). Null for non-EVM chains. */
  chainId: int("chainId"),
  rpcUrl: varchar("rpcUrl", { length: 500 }),
  explorerUrl: varchar("explorerUrl", { length: 255 }),
  nativeSymbol: varchar("nativeSymbol", { length: 32 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Chain = typeof chains.$inferSelect;
export type InsertChain = typeof chains.$inferInsert;

/**
 * The single source-of-truth row for "what is this asset" across every
 * chain - native coins (BTC, ETH, BNB, SOL) and tokens (ERC-20/BEP-20/SPL)
 * alike. `identifier` means different things per chain: contract address
 * for EVM, mint address for Solana, "native" for a chain's native coin.
 *
 * NOTE (same rule as tokenListings): `status`/`verificationStatus` only
 * ever control the logo + badge shown in the UI. They must never gate
 * whether an asset can be imported, held, or sent/received.
 */
export const assets = mysqlTable(
  "assets",
  {
    id: int("id").autoincrement().primaryKey(),
    chainId: varchar("chainId", { length: 32 })
      .notNull()
      .references(() => chains.id),
    assetType: mysqlEnum("assetType", ["native", "token"]).notNull(),
    /**
     * Contract/mint address - EVM lowercased, everything else (Solana/BTC/
     * TON) case-preserved exactly. Always write/compare through
     * normalizeIdentifier()/addressesEqual() (server/assetRegistry.ts), never
     * `.toLowerCase()` directly - see those functions' docs for why.
     *
     * DB-level note: this column must use a case-sensitive collation
     * (utf8mb4_bin) - MySQL's default utf8mb4 collations are case-
     * INSENSITIVE, which would silently defeat the point of preserving case
     * above at the unique-index level. Applied in
     * drizzle/0005_case_sensitive_identifiers.sql, run after checking
     * drizzle/checks/pre_migration_duplicate_check.sql comes back empty.
     */
    identifier: varchar("identifier", { length: 128 }).notNull(),
    symbol: varchar("symbol", { length: 32 }).notNull(),
    name: varchar("name", { length: 128 }).notNull(),
    decimals: int("decimals").default(18).notNull(),
    logoUrl: varchar("logoUrl", { length: 500 }),
    /** active = normal, blocked = hidden (scam/exploit), spam = auto-flagged. Never gates transfers. */
    status: mysqlEnum("status", ["active", "blocked", "spam"]).default("active").notNull(),
    /** unverified = default for anything auto-discovered, registered = has metadata but not reviewed, verified = badge shown. */
    verificationStatus: mysqlEnum("verificationStatus", ["unverified", "registered", "verified"])
      .default("unverified")
      .notNull(),
    /** Back-reference to the tokenListings row this was synced from, if any - lets assetRegistry.ts upsert idempotently. Null for assets discovered by other means (e.g. a future indexer). */
    sourceListingId: int("sourceListingId").references(() => tokenListings.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    assetKey: uniqueIndex("assets_chain_identifier_idx").on(table.chainId, table.identifier),
    statusUpdatedIdx: index("assets_status_updated_idx").on(table.status, table.updatedAt),
    verificationStatusIdx: index("assets_verification_status_idx").on(table.verificationStatus),
  }),
);

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = typeof assets.$inferInsert;

/**
 * Optional/extended info about an asset, kept separate from the core
 * `assets` row so the hot path (price/balance lookups) never has to touch
 * these wider text columns. One-to-one with `assets` via `assetId`.
 */
export const assetMetadata = mysqlTable("assetMetadata", {
  assetId: int("assetId")
    .primaryKey()
    .references(() => assets.id),
  description: text("description"),
  website: varchar("website", { length: 500 }),
  twitter: varchar("twitter", { length: 255 }),
  telegram: varchar("telegram", { length: 255 }),
  discord: varchar("discord", { length: 255 }),
  /** Address of the token creator/deployer. */
  creator: varchar("creator", { length: 128 }),
  /** 0-100 risk score, where 100 is highest risk (scam/honeypot). */
  riskScore: int("riskScore"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AssetMetadata = typeof assetMetadata.$inferSelect;
export type InsertAssetMetadata = typeof assetMetadata.$inferInsert;

/** Cached, auditable token-safety assessment produced by the Phase 8 risk engine. */
export const securityReports = mysqlTable("securityReports", {
  assetId: int("assetId").primaryKey().references(() => assets.id),
  label: mysqlEnum("label", ["verified", "unverified", "risky", "scam_suspicious"]).notNull(),
  score: int("score"),
  checks: json("checks").$type<Record<string, boolean | number | string | null>>().notNull(),
  provider: varchar("provider", { length: 64 }).notNull(),
  checkedAt: timestamp("checkedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SecurityReport = typeof securityReports.$inferSelect;
export type InsertSecurityReport = typeof securityReports.$inferInsert;

/**
 * ============================================================================
 * MARKET LAYER (Phase 2 of the PAXI data-platform architecture)
 * ============================================================================
 * Builds on the Phase 1 `assets` registry. A token can trade in more than
 * one place (several DEX pools, a CEX listing, ...) - `markets` is the
 * bridge between "this asset" and "this venue", `liquidityPools` holds the
 * on-chain pool details behind a DEX market, and `assetMarketData` is the
 * one canonical, cached price/stat row per asset that the wallet UI reads.
 *
 * These are populated by the SAME external calls the app already makes
 * (DexScreener via dexLiquidity.ts, CoinGecko via marketData.ts) - Phase 2
 * doesn't add new API dependencies, it just persists what's already being
 * fetched instead of throwing it away after one-off use.
 */

/** A DEX PAXI Wallet knows about, per chain. E.g. PancakeSwap on bsc. */
export const dexes = mysqlTable(
  "dexes",
  {
    id: int("id").autoincrement().primaryKey(),
    chainId: varchar("chainId", { length: 32 })
      .notNull()
      .references(() => chains.id),
    name: varchar("name", { length: 64 }).notNull(),
    factoryAddress: varchar("factoryAddress", { length: 128 }),
    routerAddress: varchar("routerAddress", { length: 128 }),
    status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    dexChainNameIdx: uniqueIndex("dexes_chain_name_idx").on(table.chainId, table.name),
  }),
);

export type Dex = typeof dexes.$inferSelect;
export type InsertDex = typeof dexes.$inferInsert;

/** One on-chain pool, e.g. PAXI/WBNB on PancakeSwap. Discovered lazily as tokens are looked up, not pre-crawled. */
export const liquidityPools = mysqlTable(
  "liquidityPools",
  {
    id: int("id").autoincrement().primaryKey(),
    chainId: varchar("chainId", { length: 32 })
      .notNull()
      .references(() => chains.id),
    dexId: int("dexId")
      .notNull()
      .references(() => dexes.id),
    poolAddress: varchar("poolAddress", { length: 128 }).notNull(),
    asset0Id: int("asset0Id")
      .notNull()
      .references(() => assets.id),
    asset1Id: int("asset1Id")
      .notNull()
      .references(() => assets.id),
    /** Decimal-as-string, same convention as campaigns.rewardAmount - avoids float rounding on money values. */
    liquidityUsd: varchar("liquidityUsd", { length: 32 }),
    volume24hUsd: varchar("volume24hUsd", { length: 32 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    poolKey: uniqueIndex("liquidityPools_chain_address_idx").on(table.chainId, table.poolAddress),
  }),
);

export type LiquidityPool = typeof liquidityPools.$inferSelect;
export type InsertLiquidityPool = typeof liquidityPools.$inferInsert;

/** Bridges an asset to a place it trades - a DEX pool or a CEX symbol. An asset can have many markets. */
export const markets = mysqlTable(
  "markets",
  {
    id: int("id").autoincrement().primaryKey(),
    assetId: int("assetId")
      .notNull()
      .references(() => assets.id),
    venueType: mysqlEnum("venueType", ["dex", "cex"]).notNull(),
    /** DEX name (e.g. "PancakeSwap") or CEX name (e.g. "binance"). */
    venueId: varchar("venueId", { length: 64 }).notNull(),
    /** The other side of the pair, e.g. USDT/WBNB's asset row. Null for a CEX symbol like "BNBUSDT" where the quote isn't one of our own assets. */
    pairAssetId: int("pairAssetId").references(() => assets.id),
    poolId: int("poolId").references(() => liquidityPools.id),
    /** CEX ticker symbol, e.g. "BNBUSDT". Null for DEX markets (identified by poolId instead). */
    symbol: varchar("symbol", { length: 32 }),
    status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    // Two indexes, covering the two venue types separately - MySQL treats
    // each NULL as distinct in a unique index, so a nullable column never
    // constrains rows where it's null:
    //  - DEX rows: poolId is always set, symbol always null -> this index
    //    constrains DEX rows (PAXI/USDT vs PAXI/WBNB don't collide) and is a
    //    no-op for CEX rows (all share poolId=null, which never collides).
    //  - CEX rows: symbol is always set, poolId always null -> this index
    //    constrains CEX rows (same venue+symbol only once) and is a no-op
    //    for DEX rows (all share symbol=null, which never collides).
    marketPoolKey: uniqueIndex("markets_asset_venue_pool_idx").on(table.assetId, table.venueType, table.venueId, table.poolId),
    marketSymbolKey: uniqueIndex("markets_asset_venue_symbol_idx").on(table.assetId, table.venueType, table.venueId, table.symbol),
    assetStatusUpdatedIdx: index("markets_asset_status_updated_idx").on(table.assetId, table.status, table.updatedAt),
  }),
);

export type Market = typeof markets.$inferSelect;
export type InsertMarket = typeof markets.$inferInsert;

/**
 * The one canonical, cached price/stat row per asset - what the wallet's
 * Discover/Dashboard/Token Detail screens read. Populated best-effort by
 * whichever source answered (dexLiquidity.ts's DexScreener call,
 * marketData.ts's CoinGecko call, or a future on-chain reserve read) -
 * `source` records which one, so a low-confidence on-chain-only price can
 * later be overwritten by a higher-confidence CEX one without conflict.
 */
export const assetMarketData = mysqlTable("assetMarketData", {
  assetId: int("assetId")
    .primaryKey()
    .references(() => assets.id),
  priceUsd: varchar("priceUsd", { length: 32 }),
  priceChange1h: varchar("priceChange1h", { length: 16 }),
  priceChange24h: varchar("priceChange24h", { length: 16 }),
  priceChange7d: varchar("priceChange7d", { length: 16 }),
  volume24hUsd: varchar("volume24hUsd", { length: 32 }),
  liquidityUsd: varchar("liquidityUsd", { length: 32 }),
  marketCapUsd: varchar("marketCapUsd", { length: 32 }),
  fdvUsd: varchar("fdvUsd", { length: 32 }),
  /** Which source last wrote this row: provider name or provider-aggregate. */
  source: varchar("source", { length: 32 }),
  confidence: varchar("confidence", { length: 8 }),
  providerSources: varchar("providerSources", { length: 255 }),
  sourceUpdatedAt: timestamp("sourceUpdatedAt"),
  isStale: boolean("isStale").default(false).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AssetMarketData = typeof assetMarketData.$inferSelect;
export type InsertAssetMarketData = typeof assetMarketData.$inferInsert;

/**
 * ============================================================================
 * HISTORICAL DATA (Phase 4 of the PAXI data-platform architecture)
 * ============================================================================
 * Powers charts with historical price, volume, and liquidity data.
 * Snapshots are taken periodically from the live price engine; aggregation
 * workers then roll these up into OHLCV candles for different timeframes.
 */

/** Raw price snapshots taken every few minutes. */
export const marketSnapshots = mysqlTable("marketSnapshots", {
  id: int("id").autoincrement().notNull(),
  /** Asset existence is validated by the writer; omitting the FK allows MySQL range partitioning at scale. */
  assetId: int("assetId").notNull(),
  priceUsd: varchar("priceUsd", { length: 32 }).notNull(),
  volume24hUsd: varchar("volume24hUsd", { length: 32 }),
  liquidityUsd: varchar("liquidityUsd", { length: 32 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.id, table.timestamp] }),
  assetTimestampIdx: uniqueIndex("marketSnapshots_asset_timestamp_idx").on(table.assetId, table.timestamp),
}));

export type MarketSnapshot = typeof marketSnapshots.$inferSelect;
export type InsertMarketSnapshot = typeof marketSnapshots.$inferInsert;

/** OHLCV candles for various timeframes. */
export const candles = mysqlTable("candles", {
  id: int("id").autoincrement().notNull(),
  /** Asset existence is validated by the writer; omitting the FK allows MySQL range partitioning at scale. */
  assetId: int("assetId").notNull(),
  /** e.g. "1m", "5m", "15m", "1h", "4h", "1d" */
  timeframe: varchar("timeframe", { length: 8 }).notNull(),
  open: varchar("open", { length: 32 }).notNull(),
  high: varchar("high", { length: 32 }).notNull(),
  low: varchar("low", { length: 32 }).notNull(),
  close: varchar("close", { length: 32 }).notNull(),
  volume: varchar("volume", { length: 32 }),
  timestamp: timestamp("timestamp").notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.id, table.timestamp] }),
  assetTimeframeTimestampIdx: uniqueIndex("candles_asset_timeframe_timestamp_idx").on(table.assetId, table.timeframe, table.timestamp),
}));

export type Candle = typeof candles.$inferSelect;
export type InsertCandle = typeof candles.$inferInsert;


/**
 * User referral identity. A user may have one inviter and a stable invite code;
 * the unique constraints make attribution deterministic and retry-safe.
 */
export const referrals = mysqlTable(
  "referrals",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    inviterOpenId: varchar("inviterOpenId", { length: 64 }).notNull().references(() => users.openId),
    inviteeOpenId: varchar("inviteeOpenId", { length: 64 }).notNull().references(() => users.openId),
    inviteCode: varchar("inviteCode", { length: 32 }).notNull(),
    rewardWalletAddress: varchar("rewardWalletAddress", { length: 128 }),
    status: mysqlEnum("status", ["pending", "qualified", "rejected", "cancelled"]).default("pending").notNull(),
    qualifyingVolumeUsd: varchar("qualifyingVolumeUsd", { length: 32 }).default("0").notNull(),
    rewardLedgerId: bigint("rewardLedgerId", { mode: "number" }),
    qualifiedAt: timestamp("qualifiedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    inviterIdx: index("referrals_inviter_created_idx").on(table.inviterOpenId, table.createdAt),
    inviteeIdx: uniqueIndex("referrals_invitee_idx").on(table.inviteeOpenId),
    inviteCodeIdx: index("referrals_invite_code_idx").on(table.inviteCode),
    rewardLedgerIdx: uniqueIndex("referrals_reward_ledger_idx").on(table.rewardLedgerId),
    inviterInviteeIdx: uniqueIndex("referrals_inviter_invitee_idx").on(table.inviterOpenId, table.inviteeOpenId),
  }),
);
export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

/**
 * Append-only financial/reward ledger. Referral, gift-code, airdrop, and future
 * reward sources must credit this ledger rather than mutating a balance directly.
 */
export const rewardLedger = mysqlTable(
  "rewardLedger",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    sourceType: mysqlEnum("sourceType", ["referral", "gift_code", "airdrop", "campaign", "manual_adjustment"]).notNull(),
    sourceId: varchar("sourceId", { length: 128 }).notNull(),
    assetSymbol: varchar("assetSymbol", { length: 32 }).notNull(),
    assetNetwork: varchar("assetNetwork", { length: 32 }).notNull(),
    assetContractAddress: varchar("assetContractAddress", { length: 128 }),
    amount: varchar("amount", { length: 128 }).notNull(),
    status: mysqlEnum("status", ["pending", "claimable", "claimed", "approved", "distributed", "reversed", "failed"]).default("pending").notNull(),
    idempotencyKey: varchar("idempotencyKey", { length: 191 }).notNull(),
    metadata: json("metadata").$type<Record<string, unknown>>(),
    approvedAt: timestamp("approvedAt"),
    claimableAt: timestamp("claimableAt"),
    claimedAt: timestamp("claimedAt"),
    distributedAt: timestamp("distributedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    idempotencyIdx: uniqueIndex("rewardLedger_idempotency_idx").on(table.idempotencyKey),
    userCreatedIdx: index("rewardLedger_user_created_idx").on(table.userOpenId, table.createdAt),
    sourceIdx: index("rewardLedger_source_idx").on(table.sourceType, table.sourceId),
    statusIdx: index("rewardLedger_status_created_idx").on(table.status, table.createdAt),
  }),
);
export type RewardLedgerEntry = typeof rewardLedger.$inferSelect;
export type InsertRewardLedgerEntry = typeof rewardLedger.$inferInsert;

/** Gift-code campaigns are server-created; only a hash is exposed to validation paths. */
export const giftCodes = mysqlTable(
  "giftCodes",
  {
    id: int("id").autoincrement().primaryKey(),
    codeHash: varchar("codeHash", { length: 128 }).notNull(),
    codeHint: varchar("codeHint", { length: 16 }).notNull(),
    assetSymbol: varchar("assetSymbol", { length: 32 }).notNull(),
    assetNetwork: varchar("assetNetwork", { length: 32 }).notNull(),
    assetContractAddress: varchar("assetContractAddress", { length: 128 }),
    rewardAmount: varchar("rewardAmount", { length: 128 }).notNull(),
    maxRedemptions: int("maxRedemptions").notNull(),
    redemptionCount: int("redemptionCount").default(0).notNull(),
    expiresAt: timestamp("expiresAt"),
    status: mysqlEnum("status", ["active", "paused", "exhausted", "expired", "cancelled"]).default("active").notNull(),
    createdByOpenId: varchar("createdByOpenId", { length: 64 }).notNull().references(() => users.openId),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    codeHashIdx: uniqueIndex("giftCodes_code_hash_idx").on(table.codeHash),
    statusExpiryIdx: index("giftCodes_status_expiry_idx").on(table.status, table.expiresAt),
    creatorIdx: index("giftCodes_creator_created_idx").on(table.createdByOpenId, table.createdAt),
  }),
);
export type GiftCode = typeof giftCodes.$inferSelect;
export type InsertGiftCode = typeof giftCodes.$inferInsert;

export const giftCodeRedemptions = mysqlTable(
  "giftCodeRedemptions",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    giftCodeId: int("giftCodeId").notNull().references(() => giftCodes.id),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    rewardLedgerId: bigint("rewardLedgerId", { mode: "number" }).references(() => rewardLedger.id),
    status: mysqlEnum("status", ["pending", "credited", "rejected", "reversed"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    oneRedemptionPerUser: uniqueIndex("giftCodeRedemptions_code_user_idx").on(table.giftCodeId, table.userOpenId),
    ledgerIdx: uniqueIndex("giftCodeRedemptions_ledger_idx").on(table.rewardLedgerId),
    codeStatusIdx: index("giftCodeRedemptions_code_status_idx").on(table.giftCodeId, table.status),
    userCreatedIdx: index("giftCodeRedemptions_user_created_idx").on(table.userOpenId, table.createdAt),
  }),
);
export type GiftCodeRedemption = typeof giftCodeRedemptions.$inferSelect;
export type InsertGiftCodeRedemption = typeof giftCodeRedemptions.$inferInsert;

/** One configurable requirement row per campaign. The engine evaluates ten rows by default. */
export const campaignRequirements = mysqlTable(
  "campaignRequirements",
  {
    id: int("id").autoincrement().primaryKey(),
    campaignId: int("campaignId").notNull().references(() => campaigns.id),
    requirementKey: varchar("requirementKey", { length: 64 }).notNull(),
    label: varchar("label", { length: 160 }).notNull(),
    requirementType: mysqlEnum("requirementType", ["active_days", "event_count", "volume_usd", "chain_used", "operation_used", "external_score"]).notNull(),
    threshold: varchar("threshold", { length: 128 }).notNull(),
    points: int("points").default(1).notNull(),
    sortOrder: int("sortOrder").default(0).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    config: json("config").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    campaignKeyIdx: uniqueIndex("campaignRequirements_campaign_key_idx").on(table.campaignId, table.requirementKey),
    campaignOrderIdx: index("campaignRequirements_campaign_order_idx").on(table.campaignId, table.sortOrder),
  }),
);
export type CampaignRequirement = typeof campaignRequirements.$inferSelect;
export type InsertCampaignRequirement = typeof campaignRequirements.$inferInsert;

/** Frozen evaluation output for a snapshot participant. */
export const eligibilityResults = mysqlTable(
  "eligibilityResults",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    snapshotId: int("snapshotId").notNull().references(() => campaignSnapshots.id),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    totalRequirements: int("totalRequirements").default(10).notNull(),
    metRequirements: int("metRequirements").default(0).notNull(),
    minimumThreshold: int("minimumThreshold").default(5).notNull(),
    highestThreshold: int("highestThreshold").default(10).notNull(),
    payoutMultiplier: varchar("payoutMultiplier", { length: 32 }).default("0").notNull(),
    requirementResults: json("requirementResults").$type<Record<string, boolean>>().notNull(),
    externalScore: int("externalScore"),
    tier: mysqlEnum("tier", ["not_qualified", "minimum", "highest"]).default("not_qualified").notNull(),
    status: mysqlEnum("status", ["calculated", "reviewed", "approved", "rejected"]).default("calculated").notNull(),
    calculatedAt: timestamp("calculatedAt").defaultNow().notNull(),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    snapshotUserIdx: uniqueIndex("eligibilityResults_snapshot_user_idx").on(table.snapshotId, table.userOpenId),
    snapshotTierIdx: index("eligibilityResults_snapshot_tier_idx").on(table.snapshotId, table.tier),
    userCreatedIdx: index("eligibilityResults_user_created_idx").on(table.userOpenId, table.createdAt),
  }),
);
export type EligibilityResult = typeof eligibilityResults.$inferSelect;
export type InsertEligibilityResult = typeof eligibilityResults.$inferInsert;

/** Campaign-owned payout multipliers for qualified eligibility tiers. */
export const campaignTierMultipliers = mysqlTable(
  "campaignTierMultipliers",
  {
    id: int("id").autoincrement().primaryKey(),
    campaignId: int("campaignId").notNull().references(() => campaigns.id),
    tier: mysqlEnum("tier", ["minimum", "highest"]).notNull(),
    multiplier: varchar("multiplier", { length: 32 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    campaignTierIdx: uniqueIndex("campaignTierMultipliers_campaign_tier_idx").on(table.campaignId, table.tier),
    campaignIdx: index("campaignTierMultipliers_campaign_idx").on(table.campaignId),
  }),
);
export type CampaignTierMultiplier = typeof campaignTierMultipliers.$inferSelect;
export type InsertCampaignTierMultiplier = typeof campaignTierMultipliers.$inferInsert;

/** Airdrop lifecycle container. Allocation and distribution are separate stages. */
export const airdropDistributions = mysqlTable(
  "airdropDistributions",
  {
    id: int("id").autoincrement().primaryKey(),
    campaignId: int("campaignId").references(() => campaigns.id),
    snapshotId: int("snapshotId").references(() => campaignSnapshots.id),
    assetSymbol: varchar("assetSymbol", { length: 32 }).notNull(),
    assetNetwork: varchar("assetNetwork", { length: 32 }).notNull(),
    assetContractAddress: varchar("assetContractAddress", { length: 128 }),
    totalAmount: varchar("totalAmount", { length: 128 }).notNull(),
    allocatedAmount: varchar("allocatedAmount", { length: 128 }).default("0").notNull(),
    distributedAmount: varchar("distributedAmount", { length: 128 }).default("0").notNull(),
    status: mysqlEnum("status", ["draft", "allocated", "review", "approved", "distributing", "complete", "cancelled"]).default("draft").notNull(),
    createdByOpenId: varchar("createdByOpenId", { length: 64 }).notNull().references(() => users.openId),
    approvedByOpenId: varchar("approvedByOpenId", { length: 64 }).references(() => users.openId),
    distributionTxHash: varchar("distributionTxHash", { length: 128 }),
    approvedAt: timestamp("approvedAt"),
    distributedAt: timestamp("distributedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    snapshotIdx: uniqueIndex("airdropDistributions_snapshot_idx").on(table.snapshotId),
    statusCreatedIdx: index("airdropDistributions_status_created_idx").on(table.status, table.createdAt),
    campaignIdx: index("airdropDistributions_campaign_idx").on(table.campaignId, table.createdAt),
  }),
);
export type AirdropDistribution = typeof airdropDistributions.$inferSelect;
export type InsertAirdropDistribution = typeof airdropDistributions.$inferInsert;

export const airdropAllocations = mysqlTable(
  "airdropAllocations",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    distributionId: int("distributionId").notNull().references(() => airdropDistributions.id),
    eligibilityResultId: bigint("eligibilityResultId", { mode: "number" }).references(() => eligibilityResults.id),
    rewardLedgerId: bigint("rewardLedgerId", { mode: "number" }).references(() => rewardLedger.id),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    amount: varchar("amount", { length: 128 }).notNull(),
    tier: mysqlEnum("tier", ["minimum", "highest"]).notNull(),
    status: mysqlEnum("status", ["pending", "approved", "distributed", "failed", "cancelled"]).default("pending").notNull(),
    distributionTxHash: varchar("distributionTxHash", { length: 128 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    distributionUserIdx: uniqueIndex("airdropAllocations_distribution_user_idx").on(table.distributionId, table.userOpenId),
    ledgerIdx: uniqueIndex("airdropAllocations_ledger_idx").on(table.rewardLedgerId),
    statusIdx: index("airdropAllocations_status_idx").on(table.distributionId, table.status),
    userIdx: index("airdropAllocations_user_created_idx").on(table.userOpenId, table.createdAt),
    txIdx: uniqueIndex("airdropAllocations_tx_hash_idx").on(table.distributionTxHash),
  }),
);
export type AirdropAllocation = typeof airdropAllocations.$inferSelect;
export type InsertAirdropAllocation = typeof airdropAllocations.$inferInsert;


/** Stable server-owned invite code for each user. */
export const referralProfiles = mysqlTable(
  "referralProfiles",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    inviteCode: varchar("inviteCode", { length: 32 }).notNull(),
    rewardWalletAddress: varchar("rewardWalletAddress", { length: 128 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdx: uniqueIndex("referralProfiles_user_idx").on(table.userOpenId),
    codeIdx: uniqueIndex("referralProfiles_code_idx").on(table.inviteCode),
  }),
);
export type ReferralProfile = typeof referralProfiles.$inferSelect;
export type InsertReferralProfile = typeof referralProfiles.$inferInsert;


/** Server-owned policy for verified referral trading rewards. */
export const rewardPolicies = mysqlTable(
  "rewardPolicies",
  {
    id: int("id").autoincrement().primaryKey(),
    policyKey: varchar("policyKey", { length: 64 }).notNull(),
    network: varchar("network", { length: 32 }).notNull(),
    qualifyingAssetSymbol: varchar("qualifyingAssetSymbol", { length: 32 }).notNull(),
    qualifyingAssetAddress: varchar("qualifyingAssetAddress", { length: 128 }),
    minimumVolumeUsd: varchar("minimumVolumeUsd", { length: 32 }).notNull(),
    rewardAssetSymbol: varchar("rewardAssetSymbol", { length: 32 }).notNull(),
    rewardAssetNetwork: varchar("rewardAssetNetwork", { length: 32 }).notNull(),
    rewardAmount: varchar("rewardAmount", { length: 64 }).notNull(),
    minimumTradeUsd: varchar("minimumTradeUsd", { length: 32 }).default("0").notNull(),
    cooldownSeconds: int("cooldownSeconds").default(0).notNull(),
    isActive: boolean("isActive").default(false).notNull(),
    config: json("config").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    policyKeyIdx: uniqueIndex("rewardPolicies_policy_key_idx").on(table.policyKey),
    activeNetworkIdx: index("rewardPolicies_active_network_idx").on(table.isActive, table.network),
  }),
);
export type RewardPolicy = typeof rewardPolicies.$inferSelect;
export type InsertRewardPolicy = typeof rewardPolicies.$inferInsert;

/** Append-only verified trade contributions used for referral qualification. */
export const referralTradingVolume = mysqlTable(
  "referralTradingVolume",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    referralId: bigint("referralId", { mode: "number" }).notNull(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    transactionHash: varchar("transactionHash", { length: 128 }).notNull(),
    eventType: mysqlEnum("eventType", ["buy", "sell"]).notNull(),
    network: varchar("network", { length: 32 }).notNull(),
    pairAddress: varchar("pairAddress", { length: 128 }),
    qualifyingAssetAddress: varchar("qualifyingAssetAddress", { length: 128 }),
    volumeUsd: varchar("volumeUsd", { length: 32 }).notNull(),
    verified: boolean("verified").default(false).notNull(),
    riskStatus: mysqlEnum("riskStatus", ["pending", "approved", "rejected"]).default("pending").notNull(),
    riskFlags: json("riskFlags").$type<string[]>(),
    blockNumber: bigint("blockNumber", { mode: "number" }),
    verifiedAt: timestamp("verifiedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    referralCreatedIdx: index("referralTradingVolume_referral_created_idx").on(table.referralId, table.createdAt),
    userCreatedIdx: index("referralTradingVolume_user_created_idx").on(table.userOpenId, table.createdAt),
    transactionIdx: uniqueIndex("referralTradingVolume_tx_event_idx").on(table.transactionHash, table.eventType),
    verificationIdx: index("referralTradingVolume_verification_idx").on(table.verified, table.riskStatus, table.createdAt),
  }),
);
export type ReferralTradingVolume = typeof referralTradingVolume.$inferSelect;
export type InsertReferralTradingVolume = typeof referralTradingVolume.$inferInsert;

/** Rotating WPAXI reward pool registry. Only one verified pool is active per policy. */
export const rewardPools = mysqlTable(
  "rewardPools",
  {
    id: int("id").autoincrement().primaryKey(),
    policyId: int("policyId").notNull().references(() => rewardPolicies.id),
    chainId: varchar("chainId", { length: 32 }).notNull(),
    tokenAddress: varchar("tokenAddress", { length: 128 }).notNull(),
    distributorAddress: varchar("distributorAddress", { length: 128 }),
    tokenSymbol: varchar("tokenSymbol", { length: 32 }).notNull(),
    tokenDecimals: int("tokenDecimals").notNull(),
    totalAllocation: varchar("totalAllocation", { length: 128 }).notNull(),
    allocatedAmount: varchar("allocatedAmount", { length: 128 }).default("0").notNull(),
    remainingAmount: varchar("remainingAmount", { length: 128 }).notNull(),
    status: mysqlEnum("status", ["reserve", "active", "exhausted", "paused", "invalid"]).default("reserve").notNull(),
    priority: int("priority").notNull(),
    verified: boolean("verified").default(false).notNull(),
    verificationData: json("verificationData").$type<Record<string, unknown>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    policyPriorityIdx: uniqueIndex("rewardPools_policy_priority_idx").on(table.policyId, table.priority),
    tokenAddressIdx: uniqueIndex("rewardPools_chain_token_idx").on(table.chainId, table.tokenAddress),
    statusPriorityIdx: index("rewardPools_status_priority_idx").on(table.policyId, table.status, table.priority),
  }),
);
export type RewardPool = typeof rewardPools.$inferSelect;
export type InsertRewardPool = typeof rewardPools.$inferInsert;

/** Claim lifecycle for a reward-ledger entry; no automatic on-chain payout is implied. */
export const rewardClaims = mysqlTable(
  "rewardClaims",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    rewardLedgerId: bigint("rewardLedgerId", { mode: "number" }).notNull(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    recipientWalletAddress: varchar("recipientWalletAddress", { length: 128 }).notNull(),
    poolId: int("poolId"),
    tokenAddress: varchar("tokenAddress", { length: 128 }).notNull(),
    amount: varchar("amount", { length: 128 }).notNull(),
    status: mysqlEnum("status", ["pending", "claimable", "claimed", "failed", "cancelled"]).default("pending").notNull(),
    claimIdempotencyKey: varchar("claimIdempotencyKey", { length: 191 }).notNull(),
    txHash: varchar("txHash", { length: 128 }),
    claimedAt: timestamp("claimedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    rewardIdx: uniqueIndex("rewardClaims_reward_idx").on(table.rewardLedgerId),
    idempotencyIdx: uniqueIndex("rewardClaims_idempotency_idx").on(table.claimIdempotencyKey),
    userStatusIdx: index("rewardClaims_user_status_idx").on(table.userOpenId, table.status, table.createdAt),
    txHashIdx: uniqueIndex("rewardClaims_tx_hash_idx").on(table.txHash),
  }),
);
export type RewardClaim = typeof rewardClaims.$inferSelect;
export type InsertRewardClaim = typeof rewardClaims.$inferInsert;


/**
 * Additive separation-of-duties workflow for high-risk administrative changes.
 * This table is durable application state; Redis is never used as its source of truth.
 */
export const adminApprovalRequests = mysqlTable(
  "adminApprovalRequests",
  {
    id: int("id").autoincrement().primaryKey(),
    requestedByOpenId: varchar("requestedByOpenId", { length: 64 }).notNull().references(() => users.openId),
    approvedByOpenId: varchar("approvedByOpenId", { length: 64 }).references(() => users.openId),
    executedByOpenId: varchar("executedByOpenId", { length: 64 }).references(() => users.openId),
    action: varchar("action", { length: 80 }).notNull(),
    resourceType: varchar("resourceType", { length: 48 }).notNull(),
    resourceId: int("resourceId"),
    payload: json("payload").$type<Record<string, unknown>>().notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected", "executed"]).default("pending").notNull(),
    requestReason: text("requestReason").notNull(),
    decisionReason: text("decisionReason"),
    requestedAt: timestamp("requestedAt").defaultNow().notNull(),
    decidedAt: timestamp("decidedAt"),
    executedAt: timestamp("executedAt"),
  },
  (table) => ({
    statusRequestedIdx: index("adminApprovalRequests_status_requested_idx").on(table.status, table.requestedAt),
    resourceIdx: index("adminApprovalRequests_resource_idx").on(table.resourceType, table.resourceId, table.requestedAt),
  }),
);

export type AdminApprovalRequest = typeof adminApprovalRequests.$inferSelect;
export type InsertAdminApprovalRequest = typeof adminApprovalRequests.$inferInsert;

/** Safe, non-secret operational feature controls. Every write is audited. */
export const adminFeatureFlags = mysqlTable("adminFeatureFlags", {
  key: varchar("key", { length: 80 }).primaryKey(),
  enabled: boolean("enabled").default(false).notNull(),
  config: json("config").$type<Record<string, unknown>>(),
  updatedByOpenId: varchar("updatedByOpenId", { length: 64 }).notNull().references(() => users.openId),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminFeatureFlag = typeof adminFeatureFlags.$inferSelect;
export type InsertAdminFeatureFlag = typeof adminFeatureFlags.$inferInsert;

/** Durable, audited system announcements; promotional messaging remains outside this table. */
export const adminAnnouncements = mysqlTable(
  "adminAnnouncements",
  {
    id: int("id").autoincrement().primaryKey(),
    kind: mysqlEnum("kind", ["system", "security", "maintenance", "provider_outage", "ecosystem"]).notNull(),
    title: varchar("title", { length: 160 }).notNull(),
    message: text("message").notNull(),
    status: mysqlEnum("status", ["draft", "published", "archived"]).default("draft").notNull(),
    createdByOpenId: varchar("createdByOpenId", { length: 64 }).notNull().references(() => users.openId),
    publishedAt: timestamp("publishedAt"),
    archivedAt: timestamp("archivedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    statusCreatedIdx: index("adminAnnouncements_status_created_idx").on(table.status, table.createdAt),
  }),
);

export type AdminAnnouncement = typeof adminAnnouncements.$inferSelect;
export type InsertAdminAnnouncement = typeof adminAnnouncements.$inferInsert;

/**
 * Canonical ownership ledger for on-chain fee payments. A transaction hash
 * can be consumed by exactly one product operation. The database unique key
 * is the authoritative concurrency guard; callers must not rely on a
 * SELECT-then-INSERT race-prone check.
 */
export const feePaymentLedger = mysqlTable(
  "feePaymentLedger",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    transactionHash: varchar("transactionHash", { length: 128 }).notNull(),
    userOpenId: varchar("userOpenId", { length: 64 }).notNull().references(() => users.openId),
    product: mysqlEnum("product", ["send", "listing", "create_token", "campaign"]).notNull(),
    operationKey: varchar("operationKey", { length: 191 }).notNull(),
    network: varchar("network", { length: 32 }).notNull(),
    payerWallet: varchar("payerWallet", { length: 128 }),
    treasury: varchar("treasury", { length: 128 }).notNull(),
    asset: varchar("asset", { length: 128 }),
    amount: varchar("amount", { length: 128 }).notNull(),
    status: mysqlEnum("status", ["claimed", "released"]).default("claimed").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    transactionHashUniqueIdx: uniqueIndex("feePaymentLedger_transaction_hash_unique").on(table.transactionHash),
    productOperationUniqueIdx: uniqueIndex("feePaymentLedger_product_operation_unique").on(table.product, table.operationKey),
    userCreatedIdx: index("feePaymentLedger_user_created_idx").on(table.userOpenId, table.createdAt),
  }),
);

export type FeePaymentLedger = typeof feePaymentLedger.$inferSelect;
export type InsertFeePaymentLedger = typeof feePaymentLedger.$inferInsert;

/**
 * AI customer-care tickets. Every ticket is AI-triaged on submission
 * (category/priority/summary) so the support_admin queue is pre-sorted, but
 * the AI fields are always advisory - an admin can and should override them.
 * userOpenId is nullable because a not-yet-authenticated visitor (e.g. on
 * the marketing site, or before completing wallet login) can still submit a
 * ticket.
 */
export const supportTickets = mysqlTable(
  "supportTickets",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    userOpenId: varchar("userOpenId", { length: 64 }).references(() => users.openId),
    walletAddress: varchar("walletAddress", { length: 128 }),
    contactEmail: varchar("contactEmail", { length: 255 }),
    subject: varchar("subject", { length: 200 }).notNull(),
    message: text("message").notNull(),
    category: mysqlEnum("category", ["wallet_access", "transaction_issue", "swap_bridge", "security_concern", "fees_billing", "feature_request", "other"]).notNull(),
    priority: mysqlEnum("priority", ["low", "normal", "high", "urgent"]).default("normal").notNull(),
    status: mysqlEnum("status", ["open", "in_progress", "waiting_on_user", "resolved", "closed"]).default("open").notNull(),
    aiSummary: text("aiSummary"),
    aiSuggestedCategory: varchar("aiSuggestedCategory", { length: 32 }),
    aiSuggestedPriority: varchar("aiSuggestedPriority", { length: 16 }),
    aiConfidencePercent: int("aiConfidencePercent"),
    assignedAdminOpenId: varchar("assignedAdminOpenId", { length: 64 }).references(() => users.openId),
    resolutionNote: text("resolutionNote"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    resolvedAt: timestamp("resolvedAt"),
  },
  (table) => ({
    statusPriorityIdx: index("supportTickets_status_priority_idx").on(table.status, table.priority, table.createdAt),
    userIdx: index("supportTickets_user_idx").on(table.userOpenId, table.createdAt),
  }),
);

export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = typeof supportTickets.$inferInsert;
