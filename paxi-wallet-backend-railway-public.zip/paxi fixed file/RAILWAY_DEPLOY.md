# Railway deployment

This archive is intentionally flat. Extract `paxi-wallet-backend-railway-public.zip` into the root of the Railway source repository so `Dockerfile`, `railway.toml`, `package.json`, `server/`, `client/`, and the lockfiles are all at the repository root.

Railway should use the included Dockerfile builder. The Dockerfile installs the locked dependency tree, builds the Vite client and bundled Express server, then starts the production server with `npm run start`. Railway supplies the runtime `PORT` environment variable automatically; configure the application secrets and database/API variables in Railway Variables rather than committing them.

Do not place the extracted project inside another nested `paxi-wallet/` directory. The Dockerfile must be at the build context root.
