import { useMemo } from 'react';
import { Wallet, BarChart3, ArrowLeftRight, Compass, User } from 'lucide-react';

export type NavTab = 'assets' | 'markets' | 'trade' | 'discover' | 'me';

interface BottomNavProps {
  activeTab: NavTab;
  onNavigate: (tab: NavTab) => void;
}

const TABS: Array<{ id: NavTab; label: string; icon: typeof Wallet }> = [
  { id: 'assets', label: 'Assets', icon: Wallet },
  { id: 'markets', label: 'Market', icon: BarChart3 },
  { id: 'trade', label: 'Trade', icon: ArrowLeftRight },
  { id: 'discover', label: 'Discover', icon: Compass },
  { id: 'me', label: 'Me', icon: User },
];

export default function BottomNav({ activeTab, onNavigate }: BottomNavProps) {
  return (
    <nav className="paxi-nav-root paxi-fade-in">
      <div className="mx-auto flex max-w-md items-center justify-around px-2 pt-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))]">
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onNavigate(tab.id)}
              className={`group relative flex min-h-[3.5rem] min-w-[3.5rem] flex-1 flex-col items-center justify-center gap-1 rounded-2xl transition-all duration-200 ${
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
              aria-label={tab.label}
              aria-current={isActive ? 'page' : undefined}
            >
              <div className={`relative flex items-center justify-center transition-transform duration-200 ${isActive ? '-translate-y-0.5' : ''}`}>
                <Icon className={`h-[22px] w-[22px] transition-all duration-200 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
                {isActive && (
                  <span className="absolute -bottom-1.5 h-1 w-1 rounded-full bg-primary shadow-[0_0_8px_rgba(212,165,45,0.6)]" />
                )}
              </div>
              <span className={`text-[10px] font-semibold tracking-wide transition-all duration-200 ${isActive ? 'opacity-100' : 'opacity-70 group-hover:opacity-100'}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute inset-0 rounded-2xl bg-primary/5 transition-opacity duration-200" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
