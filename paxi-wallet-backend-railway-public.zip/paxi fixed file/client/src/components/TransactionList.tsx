import { useMemo } from 'react';
import {
  ArrowUpRight, ArrowDownLeft, ArrowLeftRight, RotateCcw,
  ShoppingCart, HelpCircle, Loader2, CheckCircle2, XCircle,
  Clock, AlertCircle
} from 'lucide-react';
import type { TxRecord } from '@/lib/wallet/txHistory';
import { useTransactionStatus, resolveTxDisplayStatus, type TxStatus } from '@/hooks/useTransactionStatus';

type TxType = 'send' | 'receive' | 'swap' | 'bridge' | 'buy' | 'approve' | 'unknown';

function inferTxType(record: TxRecord): TxType {
  const t = record.type?.toLowerCase() ?? '';
  if (t.includes('send') || t.includes('out')) return 'send';
  if (t.includes('receive') || t.includes('in') || t.includes('deposit')) return 'receive';
  if (t.includes('swap')) return 'swap';
  if (t.includes('bridge')) return 'bridge';
  if (t.includes('buy') || t.includes('purchase')) return 'buy';
  if (t.includes('approve')) return 'approve';
  return 'unknown';
}

function TxIcon({ type, status }: { type: TxType; status: TxStatus }) {
  const className = 'h-[18px] w-[18px]';
  switch (type) {
    case 'send': return <ArrowUpRight className={`${className} text-red-400`} />;
    case 'receive': return <ArrowDownLeft className={`${className} text-emerald-400`} />;
    case 'swap': return <ArrowLeftRight className={`${className} text-primary`} />;
    case 'bridge': return <RotateCcw className={`${className} text-blue-400`} />;
    case 'buy': return <ShoppingCart className={`${className} text-purple-400`} />;
    default: return <HelpCircle className={`${className} text-muted-foreground`} />;
  }
}

function StatusBadge({ status }: { status: TxStatus }) {
  const config: Record<TxStatus, { label: string; icon: typeof CheckCircle2; style: string }> = {
    preparing: { label: 'Preparing', icon: Loader2, style: 'paxi-status-preparing' },
    pending: { label: 'Pending', icon: Clock, style: 'paxi-status-pending' },
    submitted: { label: 'Submitted', icon: Clock, style: 'paxi-status-pending' },
    confirmed: { label: 'Successful', icon: CheckCircle2, style: 'paxi-status-success' },
    failed: { label: 'Failed', icon: XCircle, style: 'paxi-status-failed' },
  };

  const { label, icon: Icon, style } = config[status];
  return (
    <span className={`paxi-status ${style}`}>
      <Icon className={`h-3 w-3 ${status === 'preparing' || status === 'pending' ? 'animate-spin' : ''}`} />
      {label}
    </span>
  );
}

function timeAgo(timestamp?: string | number): string {
  if (!timestamp) return '';
  try {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
    return date.toLocaleDateString();
  } catch {
    return '';
  }
}

interface TransactionRowProps {
  record: TxRecord;
  onSelect?: (record: TxRecord) => void;
}

function TransactionRow({ record, onSelect }: TransactionRowProps) {
  const type = inferTxType(record);
  const { status: liveStatus } = useTransactionStatus({
    hash: record.hash ?? '',
    chain: record.chain ?? '',
    enabled: !!record.hash && !!record.chain && !['confirmed', 'failed'].includes(record.status?.toLowerCase() ?? ''),
  });

  const displayStatus = resolveTxDisplayStatus(record.status ?? 'pending', liveStatus);
  const isPending = displayStatus === 'pending' || displayStatus === 'submitted' || displayStatus === 'preparing';

  const amount = record.amount ? parseFloat(record.amount) : 0;
  const isOutgoing = type === 'send' || (amount < 0 && type === 'unknown');
  const amountPrefix = isOutgoing ? '-' : '+';
  const amountColor = isOutgoing ? 'text-foreground' : 'text-emerald-400';

  return (
    <button type="button" onClick={() => onSelect?.(record)} className="paxi-token-row group">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-secondary/80">
        <TxIcon type={type} status={displayStatus} />
      </div>

      <div className="min-w-0 flex-1 text-left">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-foreground capitalize">{type}</span>
          {isPending && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-400" />}
        </div>
        <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
          <span>{record.symbol || record.tokenSymbol || 'Unknown'}</span>
          <span>•</span>
          <span className="font-mono">{record.hash ? `${record.hash.slice(0, 6)}…${record.hash.slice(-4)}` : '—'}</span>
        </div>
      </div>

      <div className="flex flex-col items-end gap-1">
        <span className={`text-sm font-bold tabular-nums ${amountColor}`}>
          {amountPrefix}{Math.abs(amount).toFixed(4)} {record.symbol}
        </span>
        <StatusBadge status={displayStatus} />
        <span className="text-[10px] text-muted-foreground/60">{timeAgo(record.timestamp)}</span>
      </div>
    </button>
  );
}

interface TransactionListProps {
  records: TxRecord[];
  isLoading?: boolean;
  onSelect?: (record: TxRecord) => void;
  emptyMessage?: string;
}

export default function TransactionList({ records, isLoading, onSelect, emptyMessage = 'No transactions yet' }: TransactionListProps) {
  if (isLoading && records.length === 0) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="paxi-skeleton h-[72px] w-full" style={{ animationDelay: `${i * 80}ms` }} />
        ))}
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary/60">
          <Clock className="h-6 w-6 text-muted-foreground/50" />
        </div>
        <p className="text-sm font-medium text-muted-foreground">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {records.map((record, i) => (
        <div key={`${record.hash}-${i}`} className="paxi-slide-up" style={{ animationDelay: `${Math.min(i * 40, 400)}ms` }}>
          <TransactionRow record={record} onSelect={onSelect} />
        </div>
      ))}
    </div>
  );
}
