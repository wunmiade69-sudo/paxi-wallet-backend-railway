import { useMemo } from 'react';
import {
  CheckCircle2, XCircle, Loader2, ArrowUpRight, ArrowDownLeft,
  ArrowLeftRight, ExternalLink, Copy, Share2
} from 'lucide-react';
import { toast } from 'sonner';
import PaxiLogo from './PaxiLogo';
import { useTransactionStatus, resolveTxDisplayStatus, type TxStatus } from '@/hooks/useTransactionStatus';
import type { TxRecord } from '@/lib/wallet/txHistory';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';

interface TransactionReceiptProps {
  record: TxRecord;
  onClose?: () => void;
}

function StatusHeader({ status }: { status: TxStatus }) {
  if (status === 'confirmed') {
    return (
      <div className="flex flex-col items-center gap-3 py-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 ring-1 ring-emerald-500/20">
          <CheckCircle2 className="h-8 w-8 text-emerald-400" />
        </div>
        <span className="text-lg font-bold text-emerald-400">Transaction Successful</span>
      </div>
    );
  }
  if (status === 'failed') {
    return (
      <div className="flex flex-col items-center gap-3 py-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-500/10 ring-1 ring-red-500/20">
          <XCircle className="h-8 w-8 text-red-400" />
        </div>
        <span className="text-lg font-bold text-red-400">Transaction Failed</span>
      </div>
    );
  }
  return (
    <div className="flex flex-col items-center gap-3 py-4">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/10 ring-1 ring-amber-500/20">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
      <span className="text-lg font-bold text-amber-400">Processing…</span>
    </div>
  );
}

function ReceiptRow({ label, value, mono = false, copyable = false }: { label: string; value: string; mono?: boolean; copyable?: boolean }) {
  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    toast.success('Copied to clipboard');
  };

  return (
    <div className="flex items-start justify-between gap-4 py-2.5 border-b border-border/30 last:border-0">
      <span className="text-xs font-medium text-muted-foreground shrink-0">{label}</span>
      <div className="flex items-center gap-2 min-w-0">
        <span className={`text-xs font-semibold text-foreground text-right truncate ${mono ? 'font-mono' : ''}`}>{value}</span>
        {copyable && (
          <button onClick={handleCopy} className="paxi-icon-btn h-6 w-6 rounded-lg shrink-0">
            <Copy className="h-3 w-3" />
          </button>
        )}
      </div>
    </div>
  );
}

export default function TransactionReceipt({ record, onClose }: TransactionReceiptProps) {
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  const { status: liveStatus } = useTransactionStatus({
    hash: record.hash ?? '',
    chain: record.chain ?? '',
    enabled: !!record.hash && !!record.chain && !['confirmed', 'failed'].includes(record.status?.toLowerCase() ?? ''),
  });

  const status = resolveTxDisplayStatus(record.status ?? 'pending', liveStatus);

  const amount = record.amount ? parseFloat(record.amount) : 0;
  const isOutgoing = amount < 0 || record.type?.toLowerCase().includes('send');
  const displayAmount = `${isOutgoing ? '-' : '+'}${Math.abs(amount).toFixed(6)} ${record.symbol || ''}`;

  const dateStr = useMemo(() => {
    if (!record.timestamp) return '—';
    try {
      return new Date(record.timestamp).toLocaleString(undefined, {
        year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit',
      });
    } catch {
      return '—';
    }
  }, [record.timestamp]);

  const explorerUrl = useMemo(() => {
    if (!record.hash || !record.chain) return null;
    const explorers: Record<string, string> = {
      ethereum: 'https://etherscan.io/tx/',
      bsc: 'https://bscscan.com/tx/',
      polygon: 'https://polygonscan.com/tx/',
      arbitrum: 'https://arbiscan.io/tx/',
      solana: 'https://solscan.io/tx/',
      bitcoin: 'https://mempool.space/tx/',
    };
    const base = explorers[record.chain.toLowerCase()];
    return base ? `${base}${record.hash}` : null;
  }, [record.hash, record.chain]);

  const handleShare = async () => {
    const text = `PAXI Transaction\n${displayAmount}\nStatus: ${status}\nHash: ${record.hash ?? '—'}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: 'PAXI Transaction', text });
      } else {
        await navigator.clipboard.writeText(text);
        toast.success('Transaction details copied');
      }
    } catch {
      // User cancelled share
    }
  };

  return (
    <div className="flex min-h-full flex-col bg-background">
      <div className="paxi-header safe-top">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <button onClick={onClose} className="paxi-icon-btn">
            <span className="text-sm font-semibold">Close</span>
          </button>
          <span className="text-sm font-bold">Receipt</span>
          <button onClick={handleShare} className="paxi-icon-btn">
            <Share2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="mx-auto w-full max-w-md flex-1 px-4 py-6">
        <div className="paxi-glass-strong paxi-gold-glow p-6">
          <StatusHeader status={status} />

          <div className="mt-4 text-center">
            <p className="text-2xl font-bold tabular-nums text-foreground">{displayAmount}</p>
            {record.usdValue != null && (
              <p className="mt-1 text-sm font-medium text-muted-foreground">
                ≈ {formatFiat(Math.abs(record.usdValue), currency, fiatRate)}
              </p>
            )}
          </div>

          <div className="mt-6 space-y-0">
            <ReceiptRow label="Status" value={status.charAt(0).toUpperCase() + status.slice(1)} />
            <ReceiptRow label="Type" value={(record.type ?? 'Transfer').replace(/_/g, ' ')} />
            <ReceiptRow label="Token" value={record.symbol || '—'} />
            <ReceiptRow label="Network" value={record.chain?.toUpperCase() ?? '—'} />
            <ReceiptRow label="Date" value={dateStr} />
            <ReceiptRow label="From" value={record.from ? `${record.from.slice(0, 10)}…${record.from.slice(-8)}` : '—'} mono copyable={!!record.from} />
            <ReceiptRow label="To" value={record.to ? `${record.to.slice(0, 10)}…${record.to.slice(-8)}` : '—'} mono copyable={!!record.to} />
            <ReceiptRow label="Transaction Hash" value={record.hash ? `${record.hash.slice(0, 12)}…${record.hash.slice(-8)}` : '—'} mono copyable={!!record.hash} />
            {record.fee != null && (
              <ReceiptRow label="Network Fee" value={`${record.fee} ${record.feeSymbol || record.chain || ''}`} />
            )}
          </div>

          {explorerUrl && (
            <a
              href={explorerUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="paxi-pressable mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-primary/30 bg-primary/10 text-sm font-bold text-primary"
            >
              <ExternalLink className="h-4 w-4" />
              View on Explorer
            </a>
          )}
        </div>

        <div className="mt-8 flex flex-col items-center gap-2 opacity-40">
          <PaxiLogo size="sm" className="h-8 w-8" />
          <span className="text-[10px] font-bold tracking-[0.2em] text-muted-foreground">PAXI WALLET</span>
        </div>
      </div>
    </div>
  );
}
