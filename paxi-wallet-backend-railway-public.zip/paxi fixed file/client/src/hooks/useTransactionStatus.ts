import { useEffect, useRef, useState, useCallback } from 'react';
import { trpc } from '@/lib/trpc';

export type TxStatus = 'preparing' | 'pending' | 'submitted' | 'confirmed' | 'failed';

interface UseTransactionStatusOptions {
  hash: string;
  chain: string;
  enabled?: boolean;
}

interface TransactionStatus {
  status: TxStatus;
  confirmations: number;
  blockNumber?: number;
  error?: string;
  isTerminal: boolean;
}

const TERMINAL_STATES: TxStatus[] = ['confirmed', 'failed'];

export function useTransactionStatus({ hash, chain, enabled = true }: UseTransactionStatusOptions): TransactionStatus {
  const [status, setStatus] = useState<TxStatus>('preparing');
  const [confirmations, setConfirmations] = useState(0);
  const [blockNumber, setBlockNumber] = useState<number | undefined>();
  const [error, setError] = useState<string | undefined>();
  const intervalRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const attemptRef = useRef(0);

  const utils = trpc.useUtils();

  const query = trpc.chains.txStatus.useQuery(
    { hash, chain },
    {
      enabled: enabled && !!hash && !!chain && !TERMINAL_STATES.includes(status),
      refetchInterval: false,
      retry: false,
    }
  );

  const { data, isError, error: queryError } = query;

  useEffect(() => {
    if (!enabled || !hash) return;

    if (isError && queryError) {
      const msg = queryError instanceof Error ? queryError.message : 'Status check failed';
      setError(msg);
      if (attemptRef.current > 6) {
        setStatus('failed');
      }
      return;
    }

    if (!data) return;

    attemptRef.current += 1;

    const backendStatus = data.status?.toLowerCase() ?? 'pending';
    const backendConfirmations = typeof data.confirmations === 'number' ? data.confirmations : 0;
    const backendBlock = typeof data.blockNumber === 'number' ? data.blockNumber : undefined;

    setConfirmations(backendConfirmations);
    setBlockNumber(backendBlock);

    if (backendStatus === 'confirmed' || backendStatus === 'success' || backendConfirmations >= 1) {
      setStatus('confirmed');
      setError(undefined);
    } else if (backendStatus === 'failed' || backendStatus === 'reverted' || backendStatus === 'dropped') {
      setStatus('failed');
      setError(data.errorMessage || 'Transaction failed');
    } else if (backendStatus === 'submitted' || backendStatus === 'broadcasted') {
      setStatus('submitted');
    } else if (backendStatus === 'pending' || backendStatus === 'preparing') {
      setStatus(backendConfirmations > 0 ? 'confirmed' : 'pending');
    } else {
      setStatus(backendConfirmations > 0 ? 'confirmed' : 'pending');
    }
  }, [data, isError, queryError, enabled, hash]);

  useEffect(() => {
    if (!enabled || !hash || !chain) return;
    if (TERMINAL_STATES.includes(status)) {
      if (intervalRef.current) {
        clearTimeout(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    const poll = () => {
      utils.chains.txStatus.invalidate({ hash, chain }).catch(() => {});
      const baseDelay = 2000;
      const maxDelay = 10000;
      const nextDelay = Math.min(baseDelay * Math.pow(1.3, attemptRef.current), maxDelay);
      intervalRef.current = setTimeout(poll, nextDelay);
    };

    intervalRef.current = setTimeout(poll, 1500);

    return () => {
      if (intervalRef.current) {
        clearTimeout(intervalRef.current);
      }
    };
  }, [enabled, hash, chain, status, utils]);

  const isTerminal = TERMINAL_STATES.includes(status);

  return {
    status,
    confirmations,
    blockNumber,
    error,
    isTerminal,
  };
}

export function resolveTxDisplayStatus(recordStatus: string, hookStatus?: TxStatus): TxStatus {
  const s = recordStatus.toLowerCase();
  if (s === 'confirmed' || s === 'success' || hookStatus === 'confirmed') return 'confirmed';
  if (s === 'failed' || s === 'reverted' || hookStatus === 'failed') return 'failed';
  if (s === 'submitted' || s === 'broadcasted' || hookStatus === 'submitted') return 'submitted';
  if (s === 'preparing') return 'preparing';
  return hookStatus ?? 'pending';
}
