import { useEffect, useState, useRef, useMemo } from 'react';
import {
  Copy, Send, ArrowDownToLine, RefreshCw, Eye, EyeOff, ArrowLeftRight,
  CreditCard, Check, Plus, TrendingUp, TrendingDown, Bell, Search,
  Wallet, Sparkles, ChevronRight
} from 'lucide-react';
import { useCountUp } from '@/hooks/useCountUp';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import { getStoredAddress, getUnlockedMnemonic } from '@/lib/wallet/vault';
import { getAddressForChainType } from '@/lib/wallet/engine';
import { fetchAllBalancesStreaming, type AssetBalance } from '@/lib/wallet/balances';
import { ASSETS, assetKey, NETWORKS, type AssetConfig } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens, removeCustomToken } from '@/lib/wallet/customTokens';
import { getTxRecords, type TxRecord } from '@/lib/wallet/txHistory';
import { assetSectionIncludes, portfolioAssetKind, type AssetSection } from '@/lib/phase3Models';
import { getHistoryStaleWhileRevalidate } from '@/lib/wallet/txIndexer';
import { safeGetLocalStorage, safeSetLocalStorage } from '@/lib/safeStorage';
import { useDepositNotifications } from '@/lib/wallet/depositNotifications';
import { getBalanceSnapshot, setBalanceSnapshot } from '@/lib/wallet/balanceCache';
import TransactionList from '@/components/TransactionList';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import SwipeToRemove from '@/components/SwipeToRemove';
import PaxiLogo from '@/components/PaxiLogo';
import AssetLogo from '@/components/AssetLogo';
import AssetSearchDrawer from '@/components/AssetSearchDrawer';
import NotificationBell from '@/components/NotificationBell';
import VerifiedBadge from '@/components/VerifiedBadge';
import { getAssetLogoUrl, getTrustedAssetLabel, isTrustedAsset } from '@/lib/appInfo';
import { canonicalMarketIdentityKey } from '@/lib/marketIdentity';
import type { AssetImportSeed } from '@/lib/assetSearch';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';

const HIDE_BALANCE_KEY = 'paxi-hide-balance';
const MASK = '••••••';

interface DashboardProps {
  onSend: () => void;
  onReceive: () => void;
  onAddToken: (initial?: AssetImportSeed) => void;
  onSelectAsset: (asset: AssetConfig, balance: AssetBalance | undefined) => void;
  onBalancesSnapshot?: (snapshot: Record<string, AssetBalance>) => void;
  onSelectCampaign: (campaignId: number) => void;
  onNavigate: (tab: NavTab) => void;
  onNotifications: () => void;
}

function PortfolioValue({ hidden, loading, value, hasValue, currency, fiatRate }: {
  hidden: boolean; loading: boolean; value: number; hasValue: boolean; currency: string; fiatRate: number;
}) {
  const animated = useCountUp(hidden ? 0 : value, { duration: 900, decimals: 2 });
  if (loading && !hasValue) {
    return <div className="paxi-skeleton h-9 w-40" />;
  }
  if (hidden) {
    return <span className="text-3xl font-black tracking-tight text-foreground">{MASK}</span>;
  }
  return (
    <span className="text-3xl font-black tracking-tight text-foreground">
      {formatFiat(value, currency, fiatRate)}
    </span>
  );
}

function AssetRowSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div className="paxi-skeleton flex h-[72px] w-full items-center gap-3 rounded-2xl px-3.5" style={{ animationDelay: `${delay}ms` }}>
      <div className="h-10 w-10 shrink-0 rounded-full bg-muted/60" />
      <div className="flex-1 space-y-2">
        <div className="h-3.5 w-24 rounded bg-muted/60" />
        <div className="h-3 w-16 rounded bg-muted/60" />
      </div>
      <div className="h-3.5 w-14 rounded bg-muted/60" />
    </div>
  );
}

export default function Dashboard({
  onSend, onReceive, onAddToken, onSelectAsset, onBalancesSnapshot,
  onSelectCampaign, onNavigate, onNotifications
}: DashboardProps) {
  const [walletAddress, setWalletAddress] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'portfolio' | 'history'>('portfolio');
  const [assetSection, setAssetSection] = useState<AssetSection>('all');
  const [balances, setBalances] = useState<Record<string, AssetBalance>>({});
  const [loadingSymbols, setLoadingSymbols] = useState<Set<string>>(new Set());
  const [hideBalance, setHideBalance] = useState(() => safeGetLocalStorage(HIDE_BALANCE_KEY) === 'true');
  const [txRecords, setTxRecords] = useState<TxRecord[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [customTokenVersion, setCustomTokenVersion] = useState(0);
  const refreshInFlight = useRef(false);
  const pendingBalancesRef = useRef<Record<string, AssetBalance> | null>(null);
  const balanceCommitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const address = getStoredAddress();
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);
  useDepositNotifications(address);

  const toggleHideBalance = () => {
    setHideBalance((prev) => {
      const next = !prev;
      safeSetLocalStorage(HIDE_BALANCE_KEY, String(next));
      return next;
    });
  };

  useEffect(() => {
    if (address) setWalletAddress(address);
  }, [address]);

  const loadBalances = async ({ force = false }: { force?: boolean } = {}) => {
    if (!address || refreshInFlight.current) return;
    const cached = getBalanceSnapshot(address);
    const allAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
    const missingKeys = allAssets.map(assetKey).filter((key) => !cached?.[key]);
    if (!force && cached && missingKeys.length === 0) {
      setBalances(cached);
      onBalancesSnapshot?.(cached);
      setLoadingSymbols(new Set());
      return;
    }
    refreshInFlight.current = true;
    const mnemonic = getUnlockedMnemonic();
    const solAddress = mnemonic ? (getAddressForChainType(mnemonic, 'sol') ?? undefined) : undefined;
    const btcAddress = mnemonic ? (getAddressForChainType(mnemonic, 'btc') ?? undefined) : undefined;
    const nextBalances: Record<string, AssetBalance> = cached ?? {};
    const assetsToFetch = force || !cached ? allAssets : allAssets.filter((asset) => missingKeys.includes(assetKey(asset)));
    setLoadingSymbols(new Set(missingKeys));

    const commitBalances = () => {
      if (balanceCommitTimerRef.current) {
        clearTimeout(balanceCommitTimerRef.current);
        balanceCommitTimerRef.current = null;
      }
      const snapshot = pendingBalancesRef.current;
      if (!snapshot) return;
      const stableSnapshot = { ...snapshot };
      pendingBalancesRef.current = null;
      setBalances(stableSnapshot);
      setBalanceSnapshot(address, stableSnapshot);
      onBalancesSnapshot?.(stableSnapshot);
    };

    try {
      await fetchAllBalancesStreaming(
        address,
        (result) => {
          nextBalances[assetKey(result.asset)] = result;
          pendingBalancesRef.current = nextBalances;
          if (!balanceCommitTimerRef.current) {
            balanceCommitTimerRef.current = setTimeout(() => {
              balanceCommitTimerRef.current = null;
              const snapshot = pendingBalancesRef.current;
              if (!snapshot) return;
              const stableSnapshot = { ...snapshot };
              pendingBalancesRef.current = null;
              setBalances(stableSnapshot);
              setBalanceSnapshot(address, stableSnapshot);
              onBalancesSnapshot?.(stableSnapshot);
            }, 100);
          }
          setLoadingSymbols((prev) => {
            const next = new Set(prev);
            next.delete(assetKey(result.asset));
            return next;
          });
        },
        solAddress,
        btcAddress,
        assetsToFetch,
      );
    } catch {
      toast.error('Could not refresh balances. Check your connection.');
      setLoadingSymbols(new Set());
    } finally {
      commitBalances();
      refreshInFlight.current = false;
    }
  };

  const handleRemoveToken = (asset: AssetConfig) => {
    if (!asset.contractAddress) return;
    removeCustomToken(asset.contractAddress, asset.network);
    setBalances((prev) => {
      const next = { ...prev };
      delete next[assetKey(asset)];
      if (address) {
        setBalanceSnapshot(address, next);
        onBalancesSnapshot?.(next);
      }
      return next;
    });
    setCustomTokenVersion((v) => v + 1);
    toast.success(`${asset.symbol} removed`);
  };

  useEffect(() => {
    if (address) {
      const cached = getBalanceSnapshot(address);
      if (cached) {
        setBalances(cached);
        onBalancesSnapshot?.(cached);
        setLoadingSymbols(new Set());
      } else {
        void loadBalances();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, customTokenVersion]);

  const balanceList = Object.values(balances);
  const isLoading = loadingSymbols.size > 0;

  const { data: verifiedListings } = trpc.listings.listVerified.useQuery();
  const { data: featuredCampaigns } = trpc.campaigns.featured.useQuery();

  const verifiedKeys = useMemo(() => new Set(
    (verifiedListings ?? []).map((l) => `${l.network}:${l.contractAddress.toLowerCase()}`)
  ), [verifiedListings]);

  const isAssetVerified = (asset: AssetConfig) => {
    if (isTrustedAsset(asset)) return true;
    if (!asset.contractAddress) return false;
    return verifiedKeys.has(`${asset.network}:${asset.contractAddress.toLowerCase()}`);
  };

  const portfolioValue = balanceList.reduce((total, b) => {
    if (b.balance == null || b.usdPrice == null) return total;
    return total + b.balance * b.usdPrice;
  }, 0);

  const pricedBalances = balanceList.filter((b) => b.balance != null && b.usdPrice != null);
  const hasPortfolioData = pricedBalances.length > 0;
  const hasCompletePortfolioChange = hasPortfolioData && pricedBalances.every((b) => b.change24h != null);

  const portfolioValue24hAgo = hasCompletePortfolioChange
    ? pricedBalances.reduce((total, b) => {
        const valueToday = b.balance! * b.usdPrice!;
        const changeFraction = b.change24h! / 100;
        if (changeFraction === -1) return total;
        return total + valueToday / (1 + changeFraction);
      }, 0)
    : 0;

  const portfolioChangePercent = hasCompletePortfolioChange && portfolioValue24hAgo > 0
    ? ((portfolioValue - portfolioValue24hAgo) / portfolioValue24hAgo) * 100
    : null;
  const portfolioChangeValue = portfolioChangePercent != null ? portfolioValue - portfolioValue24hAgo : null;

  const setActiveTabChecked = (tab: 'portfolio' | 'history') => {
    if (tab === 'history') {
      setTxRecords(getTxRecords());
      if (address) {
        const cached = getHistoryStaleWhileRevalidate(address, (fresh) => {
          setTxRecords(fresh.records);
          setIsHistoryLoading(false);
        });
        if (cached.length > 0) setTxRecords(cached);
        else setIsHistoryLoading(true);
      }
    }
    setActiveTab(tab);
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    setIsCopied(true);
    toast.success('Wallet address copied!');
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-28">
      <header className="paxi-header safe-top">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <PaxiLogo size="sm" className="h-9 w-9" />
            <div>
              <h1 className="text-base font-black tracking-[0.12em] text-foreground">PAXI</h1>
              <p className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Secure Wallet</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={onNotifications} className="paxi-icon-btn relative" aria-label="Notifications">
              <Bell className="h-[18px] w-[18px]" />
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-primary ring-2 ring-background" />
            </button>
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-400 ring-1 ring-emerald-500/20">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Ready
            </span>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-5 sm:px-6">
        {/* Campaign Carousel */}
        {featuredCampaigns && featuredCampaigns.length > 0 && (
          <section className="mb-5 paxi-slide-up" aria-label="Featured campaigns">
            <div className="flex snap-x snap-mandatory gap-3 overflow-x-auto pb-2 no-scrollbar">
              {featuredCampaigns.map((campaign) => (
                <button
                  key={campaign.id}
                  onClick={() => onSelectCampaign(campaign.id)}
                  aria-label={`Open ${campaign.title} campaign`}
                  className="group relative w-[85%] shrink-0 snap-center overflow-hidden rounded-2xl border border-border/50 bg-card transition-all duration-300 hover:border-primary/30 active:scale-[0.99]"
                >
                  {campaign.bannerKey ? (
                    <img
                      src={`/manus-storage/${campaign.bannerKey}`}
                      alt={`${campaign.title} campaign banner`}
                      className="h-36 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-36 w-full items-center justify-center bg-gradient-to-br from-primary/20 via-card to-secondary">
                      <Sparkles className="h-8 w-8 text-primary/50" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    <p className="text-sm font-bold text-foreground">{campaign.title}</p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground line-clamp-1">{campaign.description}</p>
                  </div>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Portfolio Card */}
        <div className="paxi-glass-strong paxi-gold-glow mb-5 p-5 paxi-slide-up" style={{ animationDelay: '50ms' }}>
          <div className="flex items-center justify-between mb-1">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Total Portfolio</p>
            <div className="flex items-center gap-1">
              <button type="button" onClick={toggleHideBalance} className="paxi-icon-btn h-8 w-8" title={hideBalance ? 'Show balance' : 'Hide balance'}>
                {hideBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
              <button type="button" onClick={() => void loadBalances({ force: true })} disabled={refreshInFlight.current} className="paxi-icon-btn h-8 w-8 disabled:opacity-40" title="Refresh balances">
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="flex items-end gap-3 mb-5">
            <PortfolioValue hidden={hideBalance} loading={isLoading && balanceList.length === 0} value={portfolioValue} hasValue={hasPortfolioData} currency={currency} fiatRate={fiatRate} />
            {!hideBalance && !(isLoading && balanceList.length === 0) && portfolioChangePercent != null && (
              <div className={`mb-1.5 flex flex-col items-start gap-0.5 ${portfolioChangePercent >= 0 ? 'paxi-price-up' : 'paxi-price-down'}`}>
                <span className="flex items-center gap-1 text-sm font-bold">
                  {portfolioChangePercent >= 0 ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
                  {portfolioChangePercent >= 0 ? '+' : ''}{portfolioChangePercent.toFixed(2)}%
                </span>
                <span className="text-[11px] font-medium opacity-80">
                  {portfolioChangeValue != null ? `${portfolioChangeValue >= 0 ? '+' : '-'}${formatFiat(Math.abs(portfolioChangeValue), currency, fiatRate)}` : '—'}
                </span>
              </div>
            )}
          </div>

          {/* Wallet Address */}
          <button
            type="button"
            onClick={handleCopyAddress}
            className="group mb-5 flex w-full items-center justify-between gap-2 rounded-xl border border-border/50 bg-secondary/40 px-3 py-2.5 transition-all hover:border-primary/20 hover:bg-secondary/60"
          >
            <div className="min-w-0 text-left">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Wallet Address</p>
              <p className="mt-0.5 truncate font-mono text-xs text-primary/80">{walletAddress || '—'}</p>
            </div>
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary">
              {isCopied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4 text-muted-foreground group-hover:text-foreground" />}
            </div>
          </button>

          {/* Quick Actions */}
          <div className="grid grid-cols-4 gap-2.5">
            {[
              { icon: Send, label: 'Send', onClick: onSend, active: true },
              { icon: ArrowDownToLine, label: 'Receive', onClick: onReceive, active: true },
              { icon: ArrowLeftRight, label: 'Swap', onClick: () => onNavigate('trade'), active: true },
              { icon: CreditCard, label: 'Buy', onClick: () => {}, active: false },
            ].map((action) => (
              <button
                key={action.label}
                type="button"
                onClick={action.onClick}
                disabled={!action.active}
                className={`paxi-pressable group relative flex flex-col items-center justify-center gap-1.5 rounded-xl border py-3 transition-all ${
                  action.active
                    ? 'border-primary/40 bg-primary/10 text-primary hover:bg-primary/20'
                    : 'cursor-not-allowed border-border/40 bg-muted/30 text-muted-foreground'
                }`}
              >
                {!action.active && (
                  <span className="absolute -top-1.5 right-1.5 rounded-full border border-border bg-secondary px-1.5 py-0.5 text-[9px] font-bold leading-none text-muted-foreground">
                    Soon
                  </span>
                )}
                <action.icon className={`h-[18px] w-[18px] ${action.active ? '' : 'opacity-40'}`} />
                <span className="text-[11px] font-bold">{action.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="mb-5 paxi-slide-up" style={{ animationDelay: '100ms' }}>
          <AssetSearchDrawer balances={balances} onSelectAsset={onSelectAsset} onAddToken={onAddToken} />
        </div>

        {/* Tabs */}
        <div className="mb-4 flex items-center justify-between border-b border-border/30 paxi-slide-up" style={{ animationDelay: '120ms' }}>
          <div className="flex gap-1" role="tablist" aria-label="Wallet content">
            {(['portfolio', 'history'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={activeTab === tab}
                onClick={() => setActiveTabChecked(tab)}
                className={`relative min-h-10 rounded-t-xl px-4 pb-3 pt-2 text-sm font-bold transition-all ${
                  activeTab === tab ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab === 'portfolio' ? 'Assets' : 'History'}
                {activeTab === tab && (
                  <span className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-primary shadow-[0_0_8px_rgba(212,165,45,0.4)]" />
                )}
              </button>
            ))}
          </div>
          {activeTab === 'portfolio' && (
            <button type="button" onClick={() => onAddToken()} className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-bold text-primary transition-colors hover:bg-primary/10">
              <Plus className="h-3.5 w-3.5" />
              Add
            </button>
          )}
        </div>

        {/* Assets Tab */}
        {activeTab === 'portfolio' && (
          <div className="min-h-[20rem] space-y-2 paxi-slide-up" style={{ animationDelay: '150ms' }}>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
              {([
                ['all', 'All'],
                ['tokens', 'Tokens'],
                ['nfts', 'NFTs'],
                ['other', 'Other'],
              ] as Array<[AssetSection, string]>).map(([section, label]) => (
                <button
                  key={section}
                  type="button"
                  aria-pressed={assetSection === section}
                  onClick={() => setAssetSection(section)}
                  className={`paxi-chip shrink-0 ${assetSection === section ? 'paxi-chip-active' : 'paxi-chip-inactive'}`}
                >
                  {label}
                </button>
              ))}
            </div>

            {isLoading && balanceList.length === 0 ? (
              <div className="space-y-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <AssetRowSkeleton key={i} delay={i * 80} />
                ))}
              </div>
            ) : (() => {
              const customTokens = getCustomTokens();
              const customKeys = new Set(customTokens.map((t) => assetKey(customTokenToAsset(t))));
              const allAssets = [...ASSETS, ...customTokens.map(customTokenToAsset)];
              const visibleAssets = allAssets.filter((asset) => assetSectionIncludes(assetSection, portfolioAssetKind(asset)));

              if (visibleAssets.length === 0) {
                return (
                  <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary/60">
                      <Wallet className="h-6 w-6 text-muted-foreground/40" />
                    </div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {assetSection === 'nfts' ? 'NFT inventory coming soon' : assetSection === 'other' ? 'DeFi positions coming soon' : 'No assets found'}
                    </p>
                  </div>
                );
              }

              return visibleAssets.map((asset, i) => {
                const b = balances[assetKey(asset)];
                const stillLoading = loadingSymbols.has(assetKey(asset));
                const isRemovable = customKeys.has(assetKey(asset));
                const usdValue = b?.balance != null && b?.usdPrice != null ? b.balance * b.usdPrice : null;
                const verificationLabel = isAssetVerified(asset) ? (getTrustedAssetLabel(asset) ?? 'Verified') : null;
                const resolvedIconUrl = getAssetLogoUrl(asset);

                return (
                  <SwipeToRemove key={assetKey(asset)} disabled={!isRemovable} onRemove={() => handleRemoveToken(asset)}>
                    <button
                      type="button"
                      onClick={() => onSelectAsset(asset, b)}
                      className="paxi-token-row group"
                      style={{ animationDelay: `${Math.min(i * 30, 300)}ms` }}
                    >
                      <div className="relative">
                        <AssetLogo src={resolvedIconUrl} alt={asset.symbol} fallback={asset.icon} size="md" />
                        <div className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-background ring-1 ring-border">
                          <img
                            src={NETWORKS.find((n) => n.id === asset.network)?.icon}
                            alt=""
                            className="h-3 w-3 rounded-full"
                            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                          />
                        </div>
                      </div>

                      <div className="min-w-0 flex-1 text-left">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-bold text-foreground">{asset.symbol}</span>
                          {verificationLabel && <VerifiedBadge compact label={verificationLabel} />}
                        </div>
                        <p className="mt-0.5 text-[11px] font-medium text-muted-foreground">{asset.name}</p>
                      </div>

                      <div className="flex flex-col items-end gap-0.5">
                        {stillLoading && b == null ? (
                          <div className="paxi-skeleton h-4 w-16" />
                        ) : (
                          <>
                            <span className="text-sm font-bold tabular-nums text-foreground">
                              {b?.balance != null ? b.balance.toFixed(b.balance < 0.001 ? 6 : 4) : '0'} {asset.symbol}
                            </span>
                            {usdValue != null && !hideBalance && (
                              <span className="text-[11px] font-medium text-muted-foreground">
                                {formatFiat(usdValue, currency, fiatRate)}
                              </span>
                            )}
                            {b?.change24h != null && (
                              <span className={`flex items-center gap-0.5 text-[10px] font-bold ${b.change24h >= 0 ? 'paxi-price-up' : 'paxi-price-down'}`}>
                                {b.change24h >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                                {b.change24h >= 0 ? '+' : ''}{b.change24h.toFixed(2)}%
                              </span>
                            )}
                          </>
                        )}
                      </div>

                      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/30 transition-colors group-hover:text-muted-foreground" />
                    </button>
                  </SwipeToRemove>
                );
              });
            })()}
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="min-h-[20rem] paxi-slide-up" style={{ animationDelay: '150ms' }}>
            <TransactionList
              records={txRecords}
              isLoading={isHistoryLoading}
              emptyMessage="No transactions yet. Send or receive your first asset."
            />
          </div>
        )}
      </div>

      <BottomNav activeTab="assets" onNavigate={onNavigate} />
    </div>
  );
}
