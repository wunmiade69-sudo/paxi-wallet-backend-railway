import { useEffect, useState, useMemo, useCallback } from 'react';
import {
  Search, TrendingUp, TrendingDown, BarChart3, LayoutGrid,
  Loader2, Star, X, Wallet, Flame, Bell
} from 'lucide-react';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import AssetLogo from '@/components/AssetLogo';
import { trpc } from '@/lib/trpc';
import { ASSETS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import type { AssetBalance } from '@/lib/wallet/balances';
import { canonicalMarketIdentityKey, canonicalNativeIdentityKey } from '@/lib/marketIdentity';
import { formatFiat, formatFiatCompact, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { notifyForPriceMovement } from '@/lib/phase3Local';
import { getTrustedMarketLabel, isOfficialPaxiMarketToken, PAXI_LOGO_URL } from '@/lib/appInfo';
import { getBalanceSnapshot } from '@/lib/wallet/balanceCache';
import { getStoredAddress } from '@/lib/wallet/vault';
import { getMarketWatchlist, marketWatchlistKey, toggleMarketWatchlist, type MarketWatchlistItem } from '@/lib/marketWatchlist';
import type { AssetConfig } from '@/lib/wallet/chains';

export interface MarketTokenSelection {
  coinId: string | null;
  chain: string | null;
  contractAddress: string | null;
  symbol: string;
  name: string;
}

interface MarketsScreenProps {
  onNavigate: (tab: NavTab) => void;
  balanceSnapshot?: Record<string, AssetBalance>;
  onSelectAsset: (asset: AssetConfig, balance: AssetBalance | undefined) => void;
  onSelectToken: (token: MarketTokenSelection) => void;
  onNotifications: () => void;
}

type SortMode = 'market_cap_desc' | 'price_change_percentage_24h_desc' | 'price_change_percentage_24h_asc' | 'volume_desc';

const SORT_TABS: Array<{ id: SortMode; label: string; icon: typeof LayoutGrid }> = [
  { id: 'market_cap_desc', label: 'All', icon: LayoutGrid },
  { id: 'price_change_percentage_24h_desc', label: 'Gainers', icon: TrendingUp },
  { id: 'price_change_percentage_24h_asc', label: 'Losers', icon: TrendingDown },
  { id: 'volume_desc', label: 'Volume', icon: BarChart3 },
];

function MiniSparkline({ data, positive }: { data?: number[]; positive?: boolean }) {
  if (!data || data.length < 2) {
    return <div className="h-8 w-16 rounded bg-muted/40" />;
  }
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * 64;
    const y = 28 - ((v - min) / range) * 24;
    return `${x},${y}`;
  }).join(' ');
  const color = positive !== false ? '#34d399' : '#f87171';
  return (
    <svg width="64" height="32" viewBox="0 0 64 32" className="overflow-visible">
      <polyline fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" points={points} opacity="0.8" />
      <defs>
        <linearGradient id={`grad-${positive}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.15" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,28 ${points} 64,28`} fill={`url(#grad-${positive})`} />
    </svg>
  );
}

function TokenRowSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div className="paxi-skeleton flex h-[68px] w-full items-center gap-3 rounded-2xl px-3.5" style={{ animationDelay: `${delay}ms` }}>
      <div className="h-10 w-10 shrink-0 rounded-full bg-muted/60" />
      <div className="flex-1 space-y-2">
        <div className="h-3.5 w-20 rounded bg-muted/60" />
        <div className="h-3 w-14 rounded bg-muted/60" />
      </div>
      <div className="h-3.5 w-16 rounded bg-muted/60" />
    </div>
  );
}

export default function MarketsScreen({
  onNavigate, balanceSnapshot, onSelectAsset, onSelectToken, onNotifications
}: MarketsScreenProps) {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('market_cap_desc');
  const [page, setPage] = useState(1);
  const [watchlistItems, setWatchlistItems] = useState<MarketWatchlistItem[]>([]);
  const [showSearch, setShowSearch] = useState(false);

  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);
  const address = getStoredAddress();

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    setWatchlistItems(getMarketWatchlist());
    const handler = () => setWatchlistItems(getMarketWatchlist());
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, []);

  const { data: marketPage, isLoading: marketLoading, isError: marketError } = trpc.market.list.useQuery(
    { page, perPage: 50, sort: sortMode, query: debouncedQuery || undefined },
    { staleTime: 30_000, refetchInterval: 60_000 }
  );

  const { data: trendingTokens } = trpc.market.trending.useQuery(undefined, {
    staleTime: 60_000,
    refetchInterval: 120_000,
  });

  const isWatchlisted = useCallback((item: { coinId?: string | null; chain?: string | null; contractAddress?: string | null }) => {
    return watchlistItems.some((w) => {
      if (item.coinId && w.coinId === item.coinId) return true;
      if (item.chain && item.contractAddress && w.chain === item.chain && w.contractAddress?.toLowerCase() === item.contractAddress.toLowerCase()) return true;
      return false;
    });
  }, [watchlistItems]);

  const handleToggleWatchlist = useCallback((item: { coinId?: string | null; chain?: string | null; contractAddress?: string | null; symbol: string; name: string }) => {
    toggleMarketWatchlist({ coinId: item.coinId ?? null, chain: item.chain ?? null, contractAddress: item.contractAddress ?? null, symbol: item.symbol, name: item.name });
    setWatchlistItems(getMarketWatchlist());
    notifyForPriceMovement(item.symbol, isWatchlisted(item) ? 'removed' : 'added');
  }, [isWatchlisted]);

  const allTokens = marketPage?.items ?? [];
  const hasMore = marketPage?.hasMore ?? false;

  const heldAssetForToken = useCallback((token: typeof allTokens[number]) => {
    const allAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
    return allAssets.find((a) => {
      if (token.coinId && a.coinId === token.coinId) return true;
      if (token.platformId && a.network === token.platformId && token.contractAddress && a.contractAddress?.toLowerCase() === token.contractAddress.toLowerCase()) return true;
      return false;
    });
  }, []);

  const handleTokenPress = useCallback((token: typeof allTokens[number]) => {
    const held = heldAssetForToken(token);
    if (held) {
      const bal = balanceSnapshot?.[canonicalMarketIdentityKey(held)] ?? getBalanceSnapshot(address ?? '')?.[canonicalMarketIdentityKey(held)];
      onSelectAsset(held, bal);
      return;
    }
    onSelectToken({
      coinId: token.coinId ?? null,
      chain: token.platformId ?? null,
      contractAddress: token.contractAddress ?? null,
      symbol: token.symbol,
      name: token.name,
    });
  }, [heldAssetForToken, balanceSnapshot, address, onSelectAsset, onSelectToken]);

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-28">
      <header className="paxi-header safe-top">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <h1 className="text-base font-black tracking-wide text-foreground">Market</h1>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowSearch((s) => !s)} className="paxi-icon-btn">
              <Search className="h-[18px] w-[18px]" />
            </button>
            <button onClick={onNotifications} className="paxi-icon-btn relative">
              <Bell className="h-[18px] w-[18px]" />
              <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-primary ring-2 ring-background" />
            </button>
          </div>
        </div>

        {showSearch && (
          <div className="border-b border-border/30 px-4 pb-3 paxi-slide-up">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground/50" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search tokens, chains or addresses..."
                className="paxi-search"
                autoFocus
              />
              {query && (
                <button onClick={() => setQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                  <X className="h-4 w-4 text-muted-foreground" />
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      <div className="mx-auto max-w-md px-4 py-4 sm:px-6">
        {/* Sort Tabs */}
        <div className="mb-4 flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar paxi-slide-up" style={{ animationDelay: '50ms' }}>
          {SORT_TABS.map((tab) => {
            const Icon = tab.icon;
            const active = sortMode === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => { setSortMode(tab.id); setPage(1); }}
                className={`paxi-chip shrink-0 gap-1.5 ${active ? 'paxi-chip-active' : 'paxi-chip-inactive'}`}
              >
                <Icon className="h-3.5 w-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Trending Banner */}
        {!debouncedQuery && sortMode === 'market_cap_desc' && trendingTokens && trendingTokens.length > 0 && (
          <div className="mb-4 paxi-slide-up" style={{ animationDelay: '80ms' }}>
            <div className="paxi-section-header">
              <span className="paxi-section-title flex items-center gap-1.5">
                <Flame className="h-3.5 w-3.5 text-orange-400" />
                Trending
              </span>
            </div>
            <div className="flex snap-x snap-mandatory gap-2 overflow-x-auto no-scrollbar pb-1">
              {trendingTokens.slice(0, 5).map((token, i) => (
                <button
                  key={token.coinId ?? i}
                  onClick={() => handleTokenPress(token)}
                  className="group shrink-0 snap-center rounded-xl border border-border/40 bg-card/60 p-3 transition-all hover:border-primary/30 hover:bg-card"
                >
                  <div className="flex items-center gap-2">
                    <AssetLogo src={token.image} alt={token.symbol} size="sm" />
                    <div>
                      <p className="text-xs font-bold text-foreground">{token.symbol.toUpperCase()}</p>
                      <p className="text-[10px] text-muted-foreground">{token.name}</p>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="text-xs font-bold tabular-nums">{formatFiatCompact(token.current_price, currency, fiatRate)}</span>
                    {token.price_change_percentage_24h != null && (
                      <span className={`text-[10px] font-bold ${token.price_change_percentage_24h >= 0 ? 'paxi-price-up' : 'paxi-price-down'}`}>
                        {token.price_change_percentage_24h >= 0 ? '+' : ''}{token.price_change_percentage_24h.toFixed(2)}%
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Token List */}
        <div className="space-y-1.5">
          {marketLoading && allTokens.length === 0 ? (
            Array.from({ length: 8 }).map((_, i) => <TokenRowSkeleton key={i} delay={i * 60} />)
          ) : marketError ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-red-500/10">
                <TrendingDown className="h-6 w-6 text-red-400" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">Market data unavailable</p>
              <button onClick={() => window.location.reload()} className="rounded-lg bg-primary/10 px-4 py-2 text-xs font-bold text-primary">
                Retry
              </button>
            </div>
          ) : allTokens.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary/60">
                <Search className="h-6 w-6 text-muted-foreground/40" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">No tokens found</p>
            </div>
          ) : (
            allTokens.map((token, i) => {
              const positive = (token.price_change_percentage_24h ?? 0) >= 0;
              const watched = isWatchlisted(token);
              const held = heldAssetForToken(token);

              return (
                <button
                  key={`${token.coinId ?? token.contractAddress}-${i}`}
                  onClick={() => handleTokenPress(token)}
                  className="paxi-token-row group"
                  style={{ animationDelay: `${Math.min(i * 25, 400)}ms` }}
                >
                  <div className="relative shrink-0">
                    <AssetLogo src={token.image} alt={token.symbol} size="md" />
                    {held && (
                      <div className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 ring-1 ring-background">
                        <Wallet className="h-2.5 w-2.5 text-white" />
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1 text-left">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-foreground">{token.symbol.toUpperCase()}</span>
                      {isOfficialPaxiMarketToken(token) && (
                        <span className="rounded bg-primary/10 px-1 py-0 text-[9px] font-bold text-primary">PAXI</span>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <span>{token.name}</span>
                      {token.market_cap != null && (
                        <>
                          <span>•</span>
                          <span>MCap {formatFiatCompact(token.market_cap, currency, fiatRate)}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-0.5">
                    <span className="text-sm font-bold tabular-nums text-foreground">
                      {token.current_price != null ? formatFiatCompact(token.current_price, currency, fiatRate) : '—'}
                    </span>
                    {token.price_change_percentage_24h != null && (
                      <span className={`flex items-center gap-0.5 text-[11px] font-bold ${positive ? 'paxi-price-up' : 'paxi-price-down'}`}>
                        {positive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                        {positive ? '+' : ''}{token.price_change_percentage_24h.toFixed(2)}%
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); handleToggleWatchlist(token); }}
                    className="ml-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-secondary"
                  >
                    <Star className={`h-4 w-4 transition-colors ${watched ? 'fill-primary text-primary' : 'text-muted-foreground/40'}`} />
                  </button>
                </button>
              );
            })
          )}

          {hasMore && !marketLoading && (
            <button
              onClick={() => setPage((p) => p + 1)}
              className="paxi-pressable mt-2 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-border/50 bg-card/40 text-sm font-bold text-muted-foreground hover:text-foreground"
            >
              <Loader2 className="h-4 w-4" />
              Load More
            </button>
          )}
        </div>
      </div>

      <BottomNav activeTab="markets" onNavigate={onNavigate} />
    </div>
  );
}
