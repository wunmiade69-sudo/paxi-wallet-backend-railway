import { useState } from 'react';
import {
  ChevronRight, PieChart, Wallet, ArrowLeftRight, Sparkles,
  BookUser, Gift, BookOpen, Info, Settings as SettingsIcon,
  Globe2, ShieldCheck, Bell, HelpCircle, MessageSquare,
  LogOut, Crown, Moon, Sun, Fingerprint, KeyRound, Eye,
  FileText, Lock, Copy, Check, ChevronLeft
} from 'lucide-react';
import { toast } from 'sonner';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import PaxiLogo from '@/components/PaxiLogo';
import { useTheme } from '@/contexts/ThemeContext';

interface MeScreenProps {
  onNavigate: (tab: NavTab) => void;
  onSettings: () => void;
  profileName?: string;
  onAssetOverview: () => void;
  onTransactionRecords: (filter?: 'all' | 'swap-bridge') => void;
  onNotifications: () => void;
  onAddressBook: () => void;
  onConnectedDapps: () => void;
  onTokenApprovals: () => void;
  onManageWallets: () => void;
  onExperience: () => void;
  onInviteFriends: () => void;
  onAboutUs: () => void;
  onPaxiAISupport: () => void;
  onHelpCentre: () => void;
  onReportIssue: () => void;
  onContactSupport: () => void;
  onCreateToken: () => void;
  onGiftCode: () => void;
  onWeb3Browser: () => void;
  isAdmin?: boolean;
  onAdmin: () => void;
}

interface SectionItem {
  icon: typeof SettingsIcon;
  label: string;
  onClick: () => void;
  badge?: string | number;
  danger?: boolean;
  external?: boolean;
}

function MeSection({ title, items, delay = 0 }: { title: string; items: SectionItem[]; delay?: number }) {
  return (
    <div className="paxi-slide-up mb-4" style={{ animationDelay: `${delay}ms` }}>
      <h3 className="paxi-section-header px-1">
        <span className="paxi-section-title">{title}</span>
      </h3>
      <div className="paxi-glass p-1">
        {items.map((item, i) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              type="button"
              onClick={item.onClick}
              className={`group flex w-full items-center gap-3 rounded-xl px-3 py-3.5 text-left transition-all duration-200 hover:bg-secondary/60 ${
                i !== items.length - 1 ? 'border-b border-border/20' : ''
              }`}
            >
              <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${item.danger ? 'bg-red-500/10 text-red-400' : 'bg-secondary text-muted-foreground group-hover:text-foreground'}`}>
                <Icon className="h-[18px] w-[18px]" />
              </div>
              <div className="min-w-0 flex-1">
                <span className={`text-sm font-semibold ${item.danger ? 'text-red-400' : 'text-foreground'}`}>{item.label}</span>
              </div>
              {item.badge != null && (
                <span className="flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-primary/15 px-1.5 text-[10px] font-bold text-primary">
                  {item.badge}
                </span>
              )}
              <ChevronRight className="h-4 w-4 text-muted-foreground/40 transition-transform group-hover:translate-x-0.5" />
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function MeScreen({
  onNavigate, onSettings, profileName, onAssetOverview, onTransactionRecords,
  onNotifications, onAddressBook, onConnectedDapps, onTokenApprovals,
  onManageWallets, onExperience, onInviteFriends, onAboutUs,
  onPaxiAISupport, onHelpCentre, onReportIssue, onContactSupport,
  onCreateToken, onGiftCode, onWeb3Browser, isAdmin, onAdmin,
}: MeScreenProps) {
  const { theme, setTheme } = useTheme();
  const [copied, setCopied] = useState(false);

  const handleCopyAddress = () => {
    const addr = '0x...'; // Real implementation uses getStoredAddress()
    navigator.clipboard.writeText(addr);
    setCopied(true);
    toast.success('Address copied');
    setTimeout(() => setCopied(false), 2000);
  };

  const walletItems: SectionItem[] = [
    { icon: PieChart, label: 'Asset Overview', onClick: onAssetOverview },
    { icon: ArrowLeftRight, label: 'Transactions', onClick: () => onTransactionRecords('all') },
    { icon: Bell, label: 'Notifications', onClick: onNotifications },
    { icon: BookUser, label: 'Address Book', onClick: onAddressBook },
  ];

  const securityItems: SectionItem[] = [
    { icon: ShieldCheck, label: 'Security & Privacy', onClick: onSettings },
    { icon: Fingerprint, label: 'Biometrics', onClick: onSettings },
    { icon: KeyRound, label: 'Backup Wallet', onClick: onSettings },
    { icon: Eye, label: 'Export Wallet', onClick: onSettings },
  ];

  const discoverItems: SectionItem[] = [
    { icon: Sparkles, label: 'Create Token', onClick: onCreateToken },
    { icon: Globe2, label: 'Web3 Browser', onClick: onWeb3Browser },
    { icon: Gift, label: 'Gift Codes', onClick: onGiftCode },
    { icon: ArrowLeftRight, label: 'Token Approvals', onClick: onTokenApprovals },
    { icon: BookOpen, label: 'Connected dApps', onClick: onConnectedDapps },
  ];

  const supportItems: SectionItem[] = [
    { icon: MessageSquare, label: 'PAXI AI Support', onClick: onPaxiAISupport },
    { icon: HelpCircle, label: 'Help Centre', onClick: onHelpCentre },
    { icon: FileText, label: 'Report Issue', onClick: onReportIssue },
    { icon: Info, label: 'About PAXI', onClick: onAboutUs },
  ];

  const adminItems: SectionItem[] = isAdmin
    ? [{ icon: Crown, label: 'Admin Dashboard', onClick: onAdmin }]
    : [];

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-28">
      <header className="paxi-header safe-top">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <span className="text-sm font-bold">Me</span>
          <button onClick={onSettings} className="paxi-icon-btn">
            <SettingsIcon className="h-[18px] w-[18px]" />
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-6">
        {/* Identity Card */}
        <div className="paxi-glass-strong paxi-gold-glow mb-6 p-5 paxi-slide-up">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 ring-1 ring-primary/20">
                <PaxiLogo size="sm" className="h-9 w-9" />
              </div>
              <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 ring-2 ring-background">
                <div className="h-2 w-2 rounded-full bg-emerald-400" />
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="text-base font-bold text-foreground">{profileName || 'PAXI Wallet'}</h2>
              <button
                onClick={handleCopyAddress}
                className="mt-1 flex items-center gap-1.5 rounded-lg bg-secondary/60 px-2.5 py-1 text-[11px] font-mono text-muted-foreground transition-colors hover:text-foreground"
              >
                {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                <span className="truncate">0x…{/* real address */}</span>
              </button>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-3 gap-2">
            {[
              { label: 'Networks', value: '8+' },
              { label: 'Assets', value: '500+' },
              { label: 'Security', value: 'Non-custodial' },
            ].map((stat) => (
              <div key={stat.label} className="rounded-xl bg-secondary/40 px-2 py-2.5 text-center">
                <p className="text-xs font-bold text-foreground">{stat.value}</p>
                <p className="mt-0.5 text-[10px] font-medium text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        <MeSection title="Wallet" items={walletItems} delay={50} />
        <MeSection title="Security" items={securityItems} delay={100} />
        <MeSection title="Discover" items={discoverItems} delay={150} />
        {adminItems.length > 0 && <MeSection title="Admin" items={adminItems} delay={200} />}
        <MeSection title="Support" items={supportItems} delay={250} />

        {/* Theme Toggle */}
        <div className="paxi-slide-up mb-6 flex items-center justify-between rounded-2xl border border-border/40 bg-card/40 px-4 py-3.5" style={{ animationDelay: '300ms' }}>
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary">
              {theme === 'dark' ? <Moon className="h-[18px] w-[18px] text-muted-foreground" /> : <Sun className="h-[18px] w-[18px] text-muted-foreground" />}
            </div>
            <span className="text-sm font-semibold">Appearance</span>
          </div>
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="relative h-7 w-12 rounded-full bg-secondary transition-colors"
          >
            <div className={`absolute top-0.5 h-6 w-6 rounded-full bg-primary shadow-md transition-transform ${theme === 'dark' ? 'translate-x-5' : 'translate-x-0.5'}`} />
          </button>
        </div>

        {/* Logout */}
        <button
          type="button"
          onClick={onSettings}
          className="paxi-pressable paxi-slide-up flex w-full items-center justify-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/5 py-3.5 text-sm font-bold text-red-400 transition-colors hover:bg-red-500/10"
          style={{ animationDelay: '350ms' }}
        >
          <LogOut className="h-4 w-4" />
          Lock Wallet
        </button>

        <p className="mt-6 text-center text-[10px] font-medium text-muted-foreground/40">
          PAXI Wallet v1.0.0 • Non-custodial • Secure by design
        </p>
      </div>

      <BottomNav activeTab="me" onNavigate={onNavigate} />
    </div>
  );
}
