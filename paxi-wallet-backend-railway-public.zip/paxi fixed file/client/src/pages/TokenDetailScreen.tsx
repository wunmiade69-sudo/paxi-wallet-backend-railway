import { useEffect, useState, useMemo } from 'react';
import {
  ArrowLeft, Globe, ExternalLink, TrendingUp, TrendingDown,
  Loader2, Copy, Check, PlusCircle, AlertTriangle, Star,
  ShieldCheck, ShieldAlert, Info, ArrowUpRight, ArrowDownLeft,
  ArrowLeftRight
} from 'lucide-react';
import ProfessionalMarketChart, { ChartLoadingState, ChartUnavailableState } from '@/components/ProfessionalMarketChart';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { ASSETS, NETWORKS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { formatFiat, formatFiatCompact, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { getTrustedMarketLabel } from '@/lib/appInfo';
import AssetLogo from '@/components/AssetLogo';
import { canonicalMarketIdentityKey, canonicalNativeIdentityKey } from '@/lib/marketIdentity';
import { isMarketWatchlisted, marketWatchlistKey, toggleMarketWatchlist } from '@/lib/marketWatchlist';

export interface TokenDetailSelection {
  coinId: string | null;
  chain: string | null;
  contractAddress: string | null;
  symbol: string;
  name: string;
}

interface TokenDetailScreenProps {
  tokenIdentity: TokenDetailSelection;
  onBack: () => void;
  onAddToWallet: (networkId: string, contractAddress: string) => void;
}

const PLATFORM_TO_NETWORK: Record<string, string> = {
  ethereum: 'ethereum',
  'binance-smart-chain': 'bsc',
  bsc: 'bsc',
  'polygon-pos': 'polygon',
  polygon: 'polygon',
  'arbitrum-one': 'arbitrum',
  arbitrum: 'arbitrum',
  solana: 'solana',
};

type Timeframe = '1H' | '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL';
type DetailTab = 'overview' | 'stats' | 'security';

const TIMEFRAMES: Timeframe[] = ['1H', '1D', '1W', '1M', '3M', '1Y', 'ALL'];
const PROVIDER_LABELS: Record<string, string> = {
  coingecko: 'CoinGecko',
  dexpaprika: 'DexPaprika',
  birdeye: 'Birdeye',
};

function marketSourceLabel(sources: string[] | undefined, fallback: string | undefined): string {
  const names = Array.from(new Set((sources?.length ? sources : fallback ? [fallback] : []).map((s) => PROVIDER_LABELS[s] ?? s)));
  return names.length ? names.join(' + ') : 'Unavailable';
}

function SecurityBadge({ status, message }: { status: 'verified' | 'unverified' | 'high-risk' | 'unavailable'; message?: string }) {
  const configs = {
    verified: { icon: ShieldCheck, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', label: 'Security Checked' },
    unverified: { icon: Info, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', label: 'Unverified Contract' },
    'high-risk': { icon: ShieldAlert, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20', label: 'High Risk' },
    unavailable: { icon: Info, color: 'text-muted-foreground', bg: 'bg-secondary', border: 'border-border/40', label: 'Security Check Unavailable' },
  };
  const cfg = configs[status];
  const Icon = cfg.icon;
  return (
    <div className={`rounded-xl border ${cfg.border} ${cfg.bg} p-4`}>
      <div className="flex items-start gap-3">
        <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${cfg.color}`} />
        <div>
          <p className={`text-sm font-bold ${cfg.color}`}>{cfg.label}</p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            {message || 'Data is informational, not a safety guarantee. Review contract and liquidity information before trading.'}
          </p>
        </div>
      </div>
    </div>
  );
}

function StatCell({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-xl bg-secondary/40 p-3">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="text-sm font-bold text-foreground">{value}</p>
      {sub && <p className="text-[10px] text-muted-foreground">{sub}</p>}
    </div>
  );
}

export default function TokenDetailScreen({ tokenIdentity, onBack, onAddToWallet }: TokenDetailScreenProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [detailTab, setDetailTab] = useState<DetailTab>('overview');
  const [addressCopied, setAddressCopied] = useState(false);
  const [isWatchlisted, setIsWatchlisted] = useState(false);

  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  const { data: detail, isLoading: detailLoading } = trpc.market.tokenDetail.useQuery(
    {
      coinId: tokenIdentity.coinId ?? undefined,
      chain: tokenIdentity.chain ?? undefined,
      contractAddress: tokenIdentity.contractAddress ?? undefined,
    },
    { staleTime: 30_000, enabled: !!tokenIdentity.coinId || !!tokenIdentity.contractAddress }
  );

  const { data: chartData, isLoading: chartLoading } = trpc.market.chart.useQuery(
    {
      coinId: tokenIdentity.coinId ?? undefined,
      chain: tokenIdentity.chain ?? undefined,
      contractAddress: tokenIdentity.contractAddress ?? undefined,
      days: timeframe === '1H' ? '1' : timeframe === '1D' ? '1' : timeframe === '1W' ? '7' : timeframe === '1M' ? '30' : timeframe === '3M' ? '90' : timeframe === '1Y' ? '365' : 'max',
      interval: timeframe === '1H' ? 'hourly' : timeframe === '1D' ? 'hourly' : 'daily',
    },
    { staleTime: 60_000, enabled: !!tokenIdentity.coinId || !!tokenIdentity.contractAddress }
  );

  const { data: security } = trpc.market.security.useQuery(
    {
      chain: tokenIdentity.chain ?? undefined,
      contractAddress: tokenIdentity.contractAddress ?? undefined,
    },
    { staleTime: 120_000, enabled: !!tokenIdentity.contractAddress }
  );

  useEffect(() => {
    setIsWatchlisted(isMarketWatchlisted(tokenIdentity));
  }, [tokenIdentity]);

  const handleToggleWatchlist = () => {
    toggleMarketWatchlist({
      coinId: tokenIdentity.coinId,
      chain: tokenIdentity.chain,
      contractAddress: tokenIdentity.contractAddress,
      symbol: tokenIdentity.symbol,
      name: tokenIdentity.name,
    });
    setIsWatchlisted((w) => !w);
    toast.success(isWatchlisted ? 'Removed from watchlist' : 'Added to watchlist');
  };

  const handleCopyAddress = () => {
    if (!detail?.contractAddress) return;
    navigator.clipboard.writeText(detail.contractAddress);
    setAddressCopied(true);
    toast.success('Address copied');
    setTimeout(() => setAddressCopied(false), 2000);
  };

  const networkId = detail?.platformId ? PLATFORM_TO_NETWORK[detail.platformId] : undefined;
  const canAddToWallet = !!networkId && !!detail?.contractAddress;
  const explorerBase = networkId ? NETWORKS.find((n) => n.id === networkId)?.explorer : undefined;

  const priceChange = detail?.price_change_percentage_24h ?? null;
  const isPositive = priceChange != null && priceChange >= 0;

  if (detailLoading && !detail) {
    return (
      <div className="min-h-screen bg-background">
        <div className="paxi-header safe-top">
          <div className="mx-auto flex max-w-md items-center px-4 py-3">
            <button onClick={onBack} className="paxi-icon-btn -ml-2"><ArrowLeft className="h-5 w-5" /></button>
            <div className="paxi-skeleton mx-auto h-4 w-32" />
          </div>
        </div>
        <div className="mx-auto max-w-md px-4 py-6 space-y-4">
          <div className="paxi-skeleton h-24 w-full rounded-2xl" />
          <div className="paxi-skeleton h-48 w-full rounded-2xl" />
          <div className="grid grid-cols-2 gap-2">
            <div className="paxi-skeleton h-16 rounded-xl" />
            <div className="paxi-skeleton h-16 rounded-xl" />
            <div className="paxi-skeleton h-16 rounded-xl" />
            <div className="paxi-skeleton h-16 rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-8">
      <header className="paxi-header safe-top sticky top-0 z-40">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <button onClick={onBack} className="paxi-icon-btn -ml-2">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <span className="text-sm font-bold">Token Details</span>
          <button onClick={handleToggleWatchlist} className="paxi-icon-btn -mr-2">
            <Star className={`h-5 w-5 transition-colors ${isWatchlisted ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-5">
        {/* Token Identity */}
        <div className="mb-5 flex items-center gap-4 paxi-slide-up">
          <AssetLogo src={detail?.image} alt={tokenIdentity.symbol} size="lg" className="h-14 w-14" />
          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-black text-foreground">{tokenIdentity.name}</h1>
            <div className="mt-1 flex items-center gap-2">
              <span className="rounded-md bg-secondary px-2 py-0.5 text-xs font-bold text-muted-foreground">{tokenIdentity.symbol.toUpperCase()}</span>
              {detail?.platformId && (
                <span className="rounded-md bg-secondary px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  {detail.platformId.replace(/-/g, ' ')}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Price */}
        <div className="mb-5 paxi-slide-up" style={{ animationDelay: '50ms' }}>
          <div className="flex items-end gap-3">
            <span className="text-3xl font-black tracking-tight text-foreground">
              {detail?.current_price != null ? formatFiat(detail.current_price, currency, fiatRate) : '—'}
            </span>
            {priceChange != null && (
              <span className={`mb-1.5 flex items-center gap-1 rounded-lg px-2 py-0.5 text-sm font-bold ${isPositive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                {isPositive ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
                {isPositive ? '+' : ''}{priceChange.toFixed(2)}%
              </span>
            )}
          </div>
          <p className="mt-1 text-xs font-medium text-muted-foreground">24h change</p>
        </div>

        {/* Chart */}
        <div className="mb-5 paxi-slide-up" style={{ animationDelay: '100ms' }}>
          <div className="paxi-glass p-3">
            {chartLoading ? (
              <ChartLoadingState />
            ) : !chartData || chartData.length === 0 ? (
              <ChartUnavailableState />
            ) : (
              <ProfessionalMarketChart data={chartData} positive={isPositive} />
            )}
            <div className="mt-3 flex items-center justify-center gap-1">
              {TIMEFRAMES.map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`rounded-lg px-3 py-1.5 text-[11px] font-bold transition-all ${
                    timeframe === tf
                      ? 'bg-primary/15 text-primary ring-1 ring-primary/30'
                      : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-4 flex border-b border-border/30 paxi-slide-up" style={{ animationDelay: '120ms' }}>
          {(['overview', 'stats', 'security'] as DetailTab[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setDetailTab(tab)}
              className={`relative flex-1 pb-3 pt-2 text-sm font-bold capitalize transition-colors ${
                detailTab === tab ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab}
              {detailTab === tab && (
                <span className="absolute bottom-0 left-4 right-4 h-0.5 rounded-full bg-primary" />
              )}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {detailTab === 'overview' && (
          <div className="space-y-4 paxi-slide-up" style={{ animationDelay: '150ms' }}>
            <div className="grid grid-cols-4 gap-2">
              {[
                { icon: PlusCircle, label: 'Add', onClick: () => canAddToWallet && onAddToWallet(networkId!, detail!.contractAddress!), active: canAddToWallet },
                { icon: ArrowLeftRight, label: 'Swap', onClick: () => {}, active: false },
                { icon: ArrowUpRight, label: 'Send', onClick: () => {}, active: false },
                { icon: ArrowDownLeft, label: 'Buy', onClick: () => {}, active: false },
              ].map((action) => (
                <button
                  key={action.label}
                  onClick={action.onClick}
                  disabled={!action.active}
                  className={`paxi-pressable flex flex-col items-center justify-center gap-1.5 rounded-xl border py-3 transition-all ${
                    action.active
                      ? 'border-primary/40 bg-primary/10 text-primary hover:bg-primary/20'
                      : 'cursor-not-allowed border-border/30 bg-muted/20 text-muted-foreground'
                  }`}
                >
                  <action.icon className="h-[18px] w-[18px]" />
                  <span className="text-[11px] font-bold">{action.label}</span>
                </button>
              ))}
            </div>

            {detail?.contractAddress && (
              <div className="paxi-glass p-3">
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Contract Address</p>
                <div className="flex items-center gap-2">
                  <code className="min-w-0 flex-1 truncate rounded-lg bg-secondary/60 px-3 py-2 text-xs font-mono text-foreground">
                    {detail.contractAddress}
                  </code>
                  <button onClick={handleCopyAddress} className="paxi-icon-btn h-9 w-9 shrink-0">
                    {addressCopied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                  </button>
                  {explorerBase && (
                    <a href={`${explorerBase}/token/${detail.contractAddress}`} target="_blank" rel="noopener noreferrer" className="paxi-icon-btn h-9 w-9 shrink-0">
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                </div>
              </div>
            )}

            {detail?.description && (
              <div className="paxi-glass p-4">
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">About</p>
                <p className="text-xs leading-relaxed text-muted-foreground line-clamp-6">{detail.description}</p>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              {detail?.homepage && (
                <a href={detail.homepage} target="_blank" rel="noopener noreferrer" className="paxi-chip paxi-chip-inactive gap-1">
                  <Globe className="h-3 w-3" /> Website
                </a>
              )}
              {detail?.twitter && (
                <a href={`https://twitter.com/${detail.twitter}`} target="_blank" rel="noopener noreferrer" className="paxi-chip paxi-chip-inactive gap-1">
                  <ExternalLink className="h-3 w-3" /> Twitter
                </a>
              )}
            </div>

            <p className="text-center text-[10px] text-muted-foreground/50">
              Data provided by {marketSourceLabel(detail?.sources, detail?.source)}
            </p>
          </div>
        )}

        {/* Stats Tab */}
        {detailTab === 'stats' && (
          <div className="grid grid-cols-2 gap-2 paxi-slide-up" style={{ animationDelay: '150ms' }}>
            <StatCell label="Market Cap" value={detail?.market_cap != null ? formatFiatCompact(detail.market_cap, currency, fiatRate) : '—'} />
            <StatCell label="Volume (24h)" value={detail?.total_volume != null ? formatFiatCompact(detail.total_volume, currency, fiatRate) : '—'} />
            <StatCell label="Liquidity" value={detail?.liquidity != null ? formatFiatCompact(detail.liquidity, currency, fiatRate) : '—'} />
            <StatCell label="Holders" value={detail?.holders != null ? detail.holders.toLocaleString() : '—'} />
            <StatCell label="All-Time High" value={detail?.ath != null ? formatFiat(detail.ath, currency, fiatRate) : '—'} sub={detail?.ath_date ? new Date(detail.ath_date).toLocaleDateString() : undefined} />
            <StatCell label="Circulating Supply" value={detail?.circulating_supply != null ? detail.circulating_supply.toLocaleString(undefined, { maximumFractionDigits: 0 }) : '—'} />
          </div>
        )}

        {/* Security Tab */}
        {detailTab === 'security' && (
          <div className="space-y-3 paxi-slide-up" style={{ animationDelay: '150ms' }}>
            {!security && !tokenIdentity.contractAddress && (
              <SecurityBadge status="unavailable" message="No contract address available for security analysis." />
            )}
            {!security && !!tokenIdentity.contractAddress && (
              <div className="flex flex-col items-center gap-3 py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">Checking contract security...</p>
              </div>
            )}
            {security && (
              <SecurityBadge
                status={security.verified ? 'verified' : security.highRisk ? 'high-risk' : 'unverified'}
                message={security.message}
              />
            )}
            <div className="rounded-xl border border-border/30 bg-secondary/20 p-4">
              <p className="text-xs font-bold text-foreground mb-1">Security Disclaimer</p>
              <p className="text-[11px] leading-relaxed text-muted-foreground">
                Verified does NOT mean safe. Security information is informational only. Always review the contract, liquidity, and team before trading. Never invest more than you can afford to lose.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
