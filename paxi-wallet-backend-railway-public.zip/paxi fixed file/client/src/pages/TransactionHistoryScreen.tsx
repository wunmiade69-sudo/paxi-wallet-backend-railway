import { useState, useEffect, useMemo } from 'react';
import { ArrowLeft, SlidersHorizontal, X } from 'lucide-react';
import TransactionList from '@/components/TransactionList';
import TransactionReceipt from '@/components/TransactionReceipt';
import { getTxRecords, type TxRecord } from '@/lib/wallet/txHistory';
import { getHistoryStaleWhileRevalidate } from '@/lib/wallet/txIndexer';
import { getStoredAddress } from '@/lib/wallet/vault';

interface TransactionHistoryScreenProps {
  onBack: () => void;
  initialFilter?: 'all' | 'swap-bridge';
  initialHash?: string;
}

export default function TransactionHistoryScreen({ onBack, initialFilter = 'all', initialHash }: TransactionHistoryScreenProps) {
  const [filter, setFilter] = useState<'all' | 'swap-bridge'>(initialFilter);
  const [records, setRecords] = useState<TxRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<TxRecord | null>(null);
  const [showFilter, setShowFilter] = useState(false);

  const address = getStoredAddress();

  useEffect(() => {
    setRecords(getTxRecords());
    if (address) {
      const cached = getHistoryStaleWhileRevalidate(address, (fresh) => {
        setRecords(fresh.records);
        setIsLoading(false);
      });
      if (cached.length > 0) setRecords(cached);
      else setIsLoading(true);
    }
  }, [address]);

  useEffect(() => {
    if (initialHash) {
      const found = records.find((r) => r.hash === initialHash);
      if (found) setSelectedRecord(found);
    }
  }, [initialHash, records]);

  const filteredRecords = useMemo(() => {
    if (filter === 'all') return records;
    return records.filter((r) => {
      const t = r.type?.toLowerCase() ?? '';
      return t.includes('swap') || t.includes('bridge');
    });
  }, [records, filter]);

  if (selectedRecord) {
    return <TransactionReceipt record={selectedRecord} onClose={() => setSelectedRecord(null)} />;
  }

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-8">
      <header className="paxi-header safe-top sticky top-0 z-40">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <button onClick={onBack} className="paxi-icon-btn -ml-2">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <span className="text-sm font-bold">Activity</span>
          <button onClick={() => setShowFilter((s) => !s)} className="paxi-icon-btn -mr-2">
            <SlidersHorizontal className="h-[18px] w-[18px]" />
          </button>
        </div>

        {showFilter && (
          <div className="border-t border-border/30 px-4 py-2 paxi-slide-up">
            <div className="flex gap-2">
              {(['all', 'swap-bridge'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`paxi-chip ${filter === f ? 'paxi-chip-active' : 'paxi-chip-inactive'}`}
                >
                  {f === 'all' ? 'All Transactions' : 'Swaps & Bridges'}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <div className="mx-auto max-w-md px-4 py-4">
        <TransactionList
          records={filteredRecords}
          isLoading={isLoading}
          onSelect={(r) => setSelectedRecord(r)}
          emptyMessage={filter === 'swap-bridge' ? 'No swaps or bridges yet' : 'No transactions yet'}
        />
      </div>
    </div>
  );
}
