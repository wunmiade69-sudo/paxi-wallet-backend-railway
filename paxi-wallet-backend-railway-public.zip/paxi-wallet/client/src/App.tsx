import { useEffect, useState } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ThemeProvider } from './contexts/ThemeContext';
import ErrorBoundary from './components/ErrorBoundary';
import SplashScreen from './pages/SplashScreen';
import WelcomeScreen from './pages/WelcomeScreen';
import CreateWallet from './pages/CreateWallet';
import ImportWallet from './pages/ImportWallet';
import VerifyRecoveryPhrase from './pages/VerifyRecoveryPhrase';
import PINSetup from './pages/PINSetup';
import BiometricSetup from './pages/BiometricSetup';
import LoginScreen from './pages/LoginScreen';
import Dashboard from './pages/Dashboard';
import SendScreen from './pages/SendScreen';
import ReceiveScreen from './pages/ReceiveScreen';
import AddTokenScreen from './pages/AddTokenScreen';
import AssetDetailScreen from './pages/AssetDetailScreen';
import type { AssetConfig } from './lib/wallet/chains';
import type { AssetBalance } from './lib/wallet/balances';
import SettingsScreen from './pages/SettingsScreen';
import BackupWallet from './pages/BackupWallet';
import ExportWallet from './pages/ExportWallet';
import MeScreen from './pages/MeScreen';
import MarketsScreen, { type MarketTokenSelection } from './pages/MarketsScreen';
import SwapScreen from './pages/SwapScreen';
import DiscoverScreen from './pages/DiscoverScreen';
import TransactionHistoryScreen from './pages/TransactionHistoryScreen';
import AddressBookScreen from './pages/AddressBookScreen';
import ConnectedDappsScreen from './pages/ConnectedDappsScreen';
import TokenApprovalsScreen from './pages/TokenApprovalsScreen';
import NotificationsScreen from './pages/NotificationsScreen';
import ManageWalletsScreen from './pages/ManageWalletsScreen';
import WalletGuideScreen from './pages/WalletGuideScreen';
import ExperienceScreen from './pages/ExperienceScreen';
import InviteFriendsScreen from './pages/InviteFriendsScreen';
import AboutUsScreen from './pages/AboutUsScreen';
import CreateTokenScreen from './pages/CreateTokenScreen';
import ReportIssueScreen from './pages/ReportIssueScreen';
import PaxiAISupportScreen from './pages/PaxiAISupportScreen';
import Web3BrowserScreen from './pages/Web3BrowserScreen';
import AdminScreen from './pages/AdminScreen';
import { SUPPORT_EMAIL } from './lib/appInfo';
import TokenDetailScreen, { type TokenDetailSelection } from './pages/TokenDetailScreen';
import CampaignDetailScreen from './pages/CampaignDetailScreen';
import GiftCodeScreen from './pages/GiftCodeScreen';
import { useAuth } from './_core/hooks/useAuth';
import type { NavTab } from './components/BottomNav';
import { generateWallet, importWallet as importWalletEngine, importPrivateKey } from './lib/wallet/engine';
import { createVault, hasWallet, lock } from './lib/wallet/vault';
import { walletConnectManager } from './lib/wallet/walletconnect';

type AppScreen =
  | 'splash'
  | 'welcome'
  | 'create-wallet'
  | 'import-wallet'
  | 'verify-recovery-phrase'
  | 'pin-setup'
  | 'biometric-setup'
  | 'login'
  | 'dashboard'
  | 'send'
  | 'receive'
  | 'add-token'
  | 'asset-detail'
  | 'settings'
  | 'backup-wallet'
  | 'export-wallet'
  | 'me'
  | 'markets'
  | 'trade'
  | 'discover'
  | 'tx-history'
  | 'address-book'
  | 'connected-dapps'
  | 'token-approvals'
  | 'notifications'
  | 'manage-wallets'
  | 'wallet-guide'
  | 'experience'
  | 'invite-friends'
  | 'about-us'
  | 'campaign-detail'
  | 'gift-code'
  | 'create-token'
  | 'report-issue'
  | 'paxi-ai-support'
  | 'web3-browser'
  | 'admin'
  | 'token-detail';

function App() {
  const { user } = useAuth();
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('splash');
  const [pendingMnemonic, setPendingMnemonic] = useState('');
  const [pendingAddress, setPendingAddress] = useState('');
  // Disambiguates the onboarding flow so "Back" from PIN setup and the final createVault()
  // call both know what pendingMnemonic actually holds (a fresh seed, an imported seed, or a
  // raw private key) - see handleBack and handlePINSet below.
  const [pendingFlow, setPendingFlow] = useState<'create' | 'import-phrase' | 'import-key'>('create');
  const [pendingPin, setPendingPin] = useState('');
  const [selectedAsset, setSelectedAsset] = useState<{ asset: AssetConfig; balance: AssetBalance | undefined } | null>(
    null
  );
  const [assetDetailOrigin, setAssetDetailOrigin] = useState<'dashboard' | 'markets'>('dashboard');
  const [selectedMarketToken, setSelectedMarketToken] = useState<MarketTokenSelection | null>(null);
  const [selectedCampaignId, setSelectedCampaignId] = useState<number | null>(null);
  const [tokenToImport, setTokenToImport] = useState<{ networkId: string; contractAddress: string } | null>(null);
  const [reportIssueOrigin, setReportIssueOrigin] = useState<'me' | 'settings'>('settings');

  // On first mount: existing wallet -> ask for PIN/biometric. New device -> welcome.
  useEffect(() => {
    if (hasWallet()) {
      setCurrentScreen('login');
    }
  }, []);

  const handleSplashComplete = () => {
    setCurrentScreen(hasWallet() ? 'login' : 'welcome');
  };

  const handleCreateWallet = () => {
    const generated = generateWallet();
    setPendingMnemonic(generated.mnemonic);
    setPendingAddress(generated.evmAddress);
    setPendingFlow('create');
    setCurrentScreen('create-wallet');
  };

  const handleImportWallet = () => {
    setCurrentScreen('import-wallet');
  };

  const handleRecoveryPhraseGenerated = () => {
    setCurrentScreen('verify-recovery-phrase');
  };

  const handleRecoveryPhraseVerified = () => {
    setCurrentScreen('pin-setup');
  };

  const handleImportPhrase = (phrase: string) => {
    const imported = importWalletEngine(phrase);
    setPendingMnemonic(imported.mnemonic);
    setPendingAddress(imported.evmAddress);
    setPendingFlow('import-phrase');
    setCurrentScreen('pin-setup');
  };

  const handleImportPrivateKey = (privateKey: string) => {
    const imported = importPrivateKey(privateKey);
    setPendingMnemonic(imported.privateKey);
    setPendingAddress(imported.evmAddress);
    setPendingFlow('import-key');
    setCurrentScreen('pin-setup');
  };

  const handlePINSet = async (newPin: string) => {
    // Create the vault right away so biometric setup (next screen) has
    // something to attach to; the PIN is kept in state only long enough
    // to let the user optionally wrap it for biometric unlock.
    await createVault(pendingMnemonic, pendingAddress, newPin, pendingFlow === 'import-key');
    setPendingPin(newPin);
    setCurrentScreen('biometric-setup');
  };

  const handleBiometricSetup = () => {
    // Clear the transient PIN from state now that it's safely in the vault.
    setPendingPin('');
    setPendingMnemonic('');
    setCurrentScreen('dashboard');
  };

  const handleUnlocked = () => {
    setCurrentScreen('dashboard');
  };

  const handleNavigate = (tab: NavTab) => {
    setCurrentScreen(
      tab === 'assets' ? 'dashboard' : tab === 'markets' ? 'markets' : tab === 'trade' ? 'trade' : tab === 'discover' ? 'discover' : 'me'
    );
  };

  const handleLock = () => {
    walletConnectManager.clearSigner();
    lock();
    setCurrentScreen('login');
  };

  const meContextScreens: AppScreen[] = [
    'me',
    'settings',
    'backup-wallet',
    'export-wallet',
    'report-issue',
    'tx-history',
    'address-book',
    'connected-dapps',
    'token-approvals',
    'notifications',
    'manage-wallets',
    'wallet-guide',
    'experience',
    'invite-friends',
    'about-us',
    'create-token',
    'paxi-ai-support',
    'web3-browser',
    'admin',
    'gift-code',
  ];
  const isMeContext = meContextScreens.includes(currentScreen);

  const handleBack = () => {
    if (currentScreen === 'create-wallet') {
      setCurrentScreen('welcome');
    } else if (currentScreen === 'import-wallet') {
      setCurrentScreen('welcome');
    } else if (currentScreen === 'verify-recovery-phrase') {
      setCurrentScreen('create-wallet');
    } else if (currentScreen === 'pin-setup') {
      setCurrentScreen(pendingFlow === 'create' ? 'verify-recovery-phrase' : 'import-wallet');
    } else if (currentScreen === 'biometric-setup') {
      setCurrentScreen('pin-setup');
    } else if (
      currentScreen === 'send' ||
      currentScreen === 'receive' ||
      currentScreen === 'add-token'
    ) {
      setCurrentScreen('dashboard');
    } else if (currentScreen === 'asset-detail') {
      setCurrentScreen(assetDetailOrigin);
    } else if (currentScreen === 'settings') {
      setCurrentScreen('me');
    } else if (currentScreen === 'backup-wallet' || currentScreen === 'export-wallet') {
      setCurrentScreen('settings');
    } else if (currentScreen === 'report-issue') {
      setCurrentScreen(reportIssueOrigin);
    } else if (currentScreen === 'tx-history') {
      setCurrentScreen('me');
    } else if (currentScreen === 'address-book' || currentScreen === 'connected-dapps' || currentScreen === 'token-approvals' || currentScreen === 'notifications') {
      setCurrentScreen('me');
    } else if (currentScreen === 'manage-wallets' || currentScreen === 'wallet-guide') {
      setCurrentScreen('me');
    } else if (currentScreen === 'experience' || currentScreen === 'invite-friends' || currentScreen === 'about-us') {
      setCurrentScreen('me');
    } else if (currentScreen === 'create-token' ||
      currentScreen === 'web3-browser' ||
      currentScreen === 'paxi-ai-support'
    ) {
      setCurrentScreen('me');
    } else if (currentScreen === 'admin' || currentScreen === 'gift-code') {
      setCurrentScreen('me');
    } else if (currentScreen === 'token-detail') {
      setCurrentScreen('markets');
    } else if (currentScreen === 'campaign-detail') {
      setCurrentScreen('discover');
    }
  };

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable={true}>
        <TooltipProvider>
          <Toaster />

          {currentScreen === 'splash' && <SplashScreen onComplete={handleSplashComplete} />}

          {currentScreen === 'welcome' && (
            <WelcomeScreen onCreateWallet={handleCreateWallet} onImportWallet={handleImportWallet} />
          )}

          {currentScreen === 'create-wallet' && (
            <CreateWallet
              mnemonic={pendingMnemonic}
              onRecoveryPhraseGenerated={handleRecoveryPhraseGenerated}
              onBack={handleBack}
            />
          )}

          {currentScreen === 'import-wallet' && (
            <ImportWallet onImportPhrase={handleImportPhrase} onImportPrivateKey={handleImportPrivateKey} onBack={handleBack} />
          )}

          {currentScreen === 'verify-recovery-phrase' && (
            <VerifyRecoveryPhrase
              recoveryPhrase={pendingMnemonic}
              onVerified={handleRecoveryPhraseVerified}
              onBack={handleBack}
            />
          )}

          {currentScreen === 'pin-setup' && <PINSetup onPINSet={handlePINSet} onBack={handleBack} />}

          {currentScreen === 'biometric-setup' && (
            <BiometricSetup pin={pendingPin} onBiometricSetup={handleBiometricSetup} onBack={handleBack} />
          )}

          {currentScreen === 'login' && <LoginScreen onUnlocked={handleUnlocked} />}

          {(currentScreen === 'dashboard' || (currentScreen === 'asset-detail' && assetDetailOrigin === 'dashboard')) && (
            <div className={`h-[100dvh] overflow-y-auto overscroll-y-contain ${currentScreen === 'dashboard' ? '' : 'hidden'}`}>
            <Dashboard
              onSend={() => setCurrentScreen('send')}
              onReceive={() => setCurrentScreen('receive')}
              onAddToken={(initial) => {
                setTokenToImport(initial ?? null);
                setCurrentScreen('add-token');
              }}
              onNavigate={handleNavigate}
              onSelectAsset={(asset, balance) => {
                setSelectedAsset({ asset, balance });
                setAssetDetailOrigin('dashboard');
                setCurrentScreen('asset-detail');
              }}
              onSelectCampaign={(campaignId) => { setSelectedCampaignId(campaignId); setCurrentScreen('campaign-detail');               }}
            />
            </div>
          )}

          {isMeContext && (
            <div className={`h-[100dvh] overflow-y-auto overscroll-y-contain ${currentScreen === 'me' ? '' : 'hidden'}`} aria-hidden={currentScreen !== 'me'}>
            <MeScreen
              onNavigate={handleNavigate}
              onSettings={() => setCurrentScreen('settings')}
              profileName={user?.name ?? undefined}
              onAssetOverview={() => setCurrentScreen('dashboard')}
              onTransactionRecords={() => setCurrentScreen('tx-history')}
              onNotifications={() => setCurrentScreen('notifications')}
              onAddressBook={() => setCurrentScreen('address-book')}
              onConnectedDapps={() => setCurrentScreen('connected-dapps')}
              onTokenApprovals={() => setCurrentScreen('token-approvals')}
              onManageWallets={() => setCurrentScreen('manage-wallets')}
              onWalletGuide={() => setCurrentScreen('wallet-guide')}
              onExperience={() => setCurrentScreen('experience')}
              onInviteFriends={() => setCurrentScreen('invite-friends')}
              onAboutUs={() => setCurrentScreen('about-us')}
              onPaxiAISupport={() => setCurrentScreen('paxi-ai-support')}
              onHelpCentre={() => setCurrentScreen('wallet-guide')}
              onReportIssue={() => { setReportIssueOrigin('me'); setCurrentScreen('report-issue'); }}
              onContactSupport={() => { window.location.href = `mailto:${SUPPORT_EMAIL}`; }}
              onCreateToken={() => setCurrentScreen('create-token')}
              onGiftCode={() => setCurrentScreen('gift-code')}
              onWeb3Browser={() => setCurrentScreen('web3-browser')}
              isAdmin={user?.role === 'admin'}
              onAdmin={() => setCurrentScreen('admin')}
            />
            </div>
          )}
          {(currentScreen === 'markets' || currentScreen === 'token-detail' || (currentScreen === 'asset-detail' && assetDetailOrigin === 'markets')) && (
            <div className={`h-[100dvh] overflow-y-auto overscroll-y-contain ${currentScreen === 'markets' ? '' : 'hidden'}`}>
            <MarketsScreen
              onNavigate={handleNavigate}
              onSelectAsset={(asset, balance) => {
                setSelectedAsset({ asset, balance });
                setAssetDetailOrigin('markets');
                setCurrentScreen('asset-detail');
              }}
              onSelectToken={(token) => {
                setSelectedMarketToken(token);
                setCurrentScreen('token-detail');
              }}
            />
            </div>
          )}
          {currentScreen === 'trade' && <SwapScreen onNavigate={handleNavigate} />}
          {(currentScreen === 'discover' || currentScreen === 'campaign-detail') && (
            <div className={`h-[100dvh] overflow-y-auto overscroll-y-contain ${currentScreen === 'discover' ? '' : 'hidden'}`}>
            <DiscoverScreen onNavigate={handleNavigate} onWeb3Browser={() => setCurrentScreen('web3-browser')} onSelectCampaign={(campaignId) => { setSelectedCampaignId(campaignId); setCurrentScreen('campaign-detail'); }} />
            </div>
          )}

          {currentScreen === 'send' && <SendScreen onBack={handleBack} />}
          {currentScreen === 'receive' && <ReceiveScreen onBack={handleBack} />}
          {currentScreen === 'add-token' && (
            <AddTokenScreen
              onBack={handleBack}
              onAdded={() => {
                setTokenToImport(null);
                setCurrentScreen('dashboard');
              }}
              initialNetworkId={tokenToImport?.networkId}
              initialContractAddress={tokenToImport?.contractAddress}
            />
          )}
          {currentScreen === 'asset-detail' && selectedAsset && (
            <AssetDetailScreen
              asset={selectedAsset.asset}
              balance={selectedAsset.balance}
              onBack={handleBack}
              onSend={() => setCurrentScreen('send')}
              onReceive={() => setCurrentScreen('receive')}
            />
          )}

          {currentScreen === 'settings' && (
            <SettingsScreen
              onBack={handleBack}
              onLogout={handleLock}
              onBackupWallet={() => setCurrentScreen('backup-wallet')}
              onExportWallet={() => setCurrentScreen('export-wallet')}
              onReportIssue={() => { setReportIssueOrigin('settings'); setCurrentScreen('report-issue'); }}
            />
          )}

          {currentScreen === 'report-issue' && <ReportIssueScreen onBack={handleBack} />}
          {currentScreen === 'paxi-ai-support' && <PaxiAISupportScreen onBack={handleBack} onWalletGuide={() => setCurrentScreen('wallet-guide')} onReportIssue={() => setCurrentScreen('report-issue')} />}
          {currentScreen === 'web3-browser' && <Web3BrowserScreen onBack={handleBack} />}
          {currentScreen === 'admin' && <AdminScreen onBack={handleBack} />}
          {currentScreen === 'token-detail' && selectedMarketToken && (
            <TokenDetailScreen
              tokenIdentity={selectedMarketToken as TokenDetailSelection}
              onBack={handleBack}
              onAddToWallet={(networkId, contractAddress) => {
                setTokenToImport({ networkId, contractAddress });
                setCurrentScreen('add-token');
              }}
            />
          )}
          {currentScreen === 'campaign-detail' && selectedCampaignId && <CampaignDetailScreen campaignId={selectedCampaignId} onBack={handleBack} />}
          {currentScreen === 'gift-code' && <GiftCodeScreen onBack={handleBack} />}

          {currentScreen === 'backup-wallet' && (
            <BackupWallet onBack={handleBack} onExportInstead={() => setCurrentScreen('export-wallet')} />
          )}
          {currentScreen === 'export-wallet' && <ExportWallet onBack={handleBack} />}
          {currentScreen === 'tx-history' && <TransactionHistoryScreen onBack={handleBack} />}
          {currentScreen === 'address-book' && <AddressBookScreen onBack={handleBack} />}
          {currentScreen === 'connected-dapps' && <ConnectedDappsScreen onBack={handleBack} />}
          {currentScreen === 'token-approvals' && <TokenApprovalsScreen onBack={handleBack} />}
          {currentScreen === 'notifications' && <NotificationsScreen onBack={handleBack} />}
          {currentScreen === 'manage-wallets' && (
            <ManageWalletsScreen onBack={handleBack} onWalletChanged={() => {}} />
          )}
          {currentScreen === 'wallet-guide' && <WalletGuideScreen onBack={handleBack} />}
          {currentScreen === 'experience' && <ExperienceScreen onBack={handleBack} />}
          {currentScreen === 'invite-friends' && <InviteFriendsScreen onBack={handleBack} />}
          {currentScreen === 'about-us' && <AboutUsScreen onBack={handleBack} />}
          {currentScreen === 'create-token' && <CreateTokenScreen onBack={handleBack} />}
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
