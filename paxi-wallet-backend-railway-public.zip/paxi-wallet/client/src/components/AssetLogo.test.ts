import { describe, expect, it } from 'vitest';
import { isSafeAssetImageUrl } from './AssetLogo';

describe('isSafeAssetImageUrl', () => {
  it('allows absolute HTTP and HTTPS provider logos', () => {
    expect(isSafeAssetImageUrl('https://assets.example.test/token.png')).toBe(true);
    expect(isSafeAssetImageUrl('http://assets.example.test/token.png')).toBe(true);
  });

  it('rejects non-HTTP(S), malformed, and missing sources', () => {
    expect(isSafeAssetImageUrl('javascript:alert(1)')).toBe(false);
    expect(isSafeAssetImageUrl('data:image/svg+xml;base64,abc')).toBe(false);
    expect(isSafeAssetImageUrl('/logos/token.png')).toBe(false);
    expect(isSafeAssetImageUrl('not a URL')).toBe(false);
    expect(isSafeAssetImageUrl(null)).toBe(false);
  });
});
