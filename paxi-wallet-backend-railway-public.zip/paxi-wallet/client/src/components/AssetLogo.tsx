import { useEffect, useState, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface AssetLogoProps {
  src?: string | null;
  alt?: string;
  fallback: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  'aria-hidden'?: boolean;
}

const SIZE_CLASSES: Record<NonNullable<AssetLogoProps['size']>, string> = {
  sm: 'h-8 w-8 text-[10px]',
  md: 'h-10 w-10 text-xs',
  lg: 'h-12 w-12 text-sm',
};

/** Only remote image URLs are allowed; malformed, javascript:, data:, and local values use the caller's fallback. */
export function isSafeAssetImageUrl(src?: string | null): src is string {
  if (!src) return false;
  try {
    const parsed = new URL(src);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

/** Stable logo surface shared by wallet assets and provider-backed market rows. */
export default function AssetLogo({ src, alt = '', fallback, size = 'md', className, 'aria-hidden': ariaHidden }: AssetLogoProps) {
  const [failedSrc, setFailedSrc] = useState<string | null>(null);
  const canShowImage = isSafeAssetImageUrl(src) && failedSrc !== src;

  useEffect(() => {
    setFailedSrc(null);
  }, [src]);

  return (
    <span
      className={cn(
        'relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full border border-foreground/10 bg-secondary font-semibold text-accent',
        SIZE_CLASSES[size],
        className,
      )}
      aria-hidden={ariaHidden ?? (!alt ? true : undefined)}
    >
      <span aria-hidden="true" className="select-none">
        {fallback}
      </span>
      {canShowImage && (
        <img
          src={src ?? undefined}
          alt={alt}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 h-full w-full object-contain bg-secondary"
          onError={() => setFailedSrc(src ?? null)}
        />
      )}
    </span>
  );
}
