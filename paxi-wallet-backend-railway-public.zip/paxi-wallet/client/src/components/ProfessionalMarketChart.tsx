import { useEffect, useMemo, useRef } from 'react';
import { useCurrency, useUsdFiatRate, formatFiat } from '@/lib/currency';
import {
  AreaSeries,
  CandlestickSeries,
  ColorType,
  createChart,
  type IChartApi,
  type Time,
} from 'lightweight-charts';

export interface ProfessionalChartPoint {
  timestamp: number;
  price?: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
  volume?: number | null;
}

interface ProfessionalMarketChartProps {
  data: ProfessionalChartPoint[];
  positive: boolean;
  source?: string;
  fallback?: boolean;
  livePrice?: number | null;
  height?: number;
}

function toEpochSeconds(value: number): number | null {
  if (!Number.isFinite(value) || value <= 0) return null;
  const milliseconds = value < 10_000_000_000 ? value * 1000 : value;
  const seconds = Math.floor(milliseconds / 1000);
  return Number.isFinite(seconds) && seconds > 0 ? seconds : null;
}

export default function ProfessionalMarketChart({
  data,
  positive,
  livePrice = null,
  height = 250,
}: ProfessionalMarketChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const accent = positive ? '#22c55e' : '#f87171';
  const mutedAccent = positive ? 'rgba(34,197,94,0.18)' : 'rgba(248,113,113,0.18)';
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);
  const displayRate = currency === 'USD' ? 1 : fiatRate;

  const normalized = useMemo(() => {
    if (displayRate == null) return [];
    const byTime = new Map<number, ProfessionalChartPoint>();
    const scale = (value: number | undefined) => value == null ? value : Number.isFinite(value) ? value * displayRate : value;
    for (const point of data) {
      const timestamp = toEpochSeconds(Number(point.timestamp));
      const value = Number(point.close ?? point.price);
      if (!timestamp || !Number.isFinite(value)) continue;
      byTime.set(timestamp, { ...point, timestamp: timestamp * 1000, price: value * displayRate, open: scale(point.open), high: scale(point.high), low: scale(point.low), close: scale(point.close) });
    }
    return [...byTime.values()].sort((left, right) => left.timestamp - right.timestamp);
  }, [data, displayRate]);

  const hasOhlc = normalized.some(
    (point) => [point.open, point.high, point.low, point.close].every((value) => Number.isFinite(Number(value)))
  );

  useEffect(() => {
    const container = containerRef.current;
    if (!container || normalized.length === 0) return;

    const chart = createChart(container, {
      width: Math.max(container.clientWidth, 280),
      height,
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#a1a1aa',
        attributionLogo: false,
      },
      grid: {
        vertLines: { color: 'rgba(255,255,255,0.045)' },
        horzLines: { color: 'rgba(255,255,255,0.045)' },
      },
      crosshair: {
        vertLine: { color: accent, width: 1, style: 2, labelBackgroundColor: accent },
        horzLine: { color: accent, width: 1, style: 2, labelBackgroundColor: accent },
      },
      rightPriceScale: {
        borderColor: 'rgba(255,255,255,0.08)',
        entireTextOnly: true,
      },
      timeScale: {
        borderColor: 'rgba(255,255,255,0.08)',
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 2,
        barSpacing: 8,
      },
      localization: {
        priceFormatter: (value: number) => {
          return formatFiat(value, currency, 1);
        },
      },
    });
    chartRef.current = chart;

    let primarySeries: { setData: (data: any[]) => void; createPriceLine?: (options: any) => unknown };
    if (hasOhlc) {
      const series = chart.addSeries(CandlestickSeries, {
        upColor: '#22c55e',
        downColor: '#f87171',
        borderVisible: false,
        wickUpColor: '#22c55e',
        wickDownColor: '#f87171',
      });
      series.setData(
        normalized
          .filter((point) => [point.open, point.high, point.low, point.close].every((value) => Number.isFinite(Number(value))))
          .map((point) => ({
            time: Math.floor(point.timestamp / 1000) as Time,
            open: Number(point.open),
            high: Number(point.high),
            low: Number(point.low),
            close: Number(point.close),
          }))
      );
      primarySeries = series;
    } else {
      const series = chart.addSeries(AreaSeries, {
        lineColor: accent,
        topColor: mutedAccent,
        bottomColor: 'rgba(0,0,0,0)',
        lineWidth: 2,
        crosshairMarkerBackgroundColor: accent,
        crosshairMarkerBorderColor: '#111111',
      });
      series.setData(
        normalized.map((point) => ({
          time: Math.floor(point.timestamp / 1000) as Time,
          value: Number(point.close ?? point.price),
        }))
      );
      primarySeries = series;
    }

    if (Number.isFinite(Number(livePrice)) && primarySeries.createPriceLine) {
      primarySeries.createPriceLine({
        price: Number(livePrice) * displayRate!,
        color: accent,
        lineWidth: 1,
        lineStyle: 2,
        axisLabelVisible: true,
        title: 'LIVE',
      });
    }

    chart.timeScale().fitContent();
    const resizeObserver = new ResizeObserver(() => {
      if (container.clientWidth > 0) chart.applyOptions({ width: container.clientWidth });
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, [accent, currency, displayRate, hasOhlc, height, livePrice, mutedAccent, normalized]);

  if (normalized.length === 0) {
    return (
      <div className="h-full min-h-56 flex items-center justify-center text-sm text-muted-foreground">
        No historical market data is available for this period.
      </div>
    );
  }

  return (
    <div className="relative w-full" style={{ height }} aria-label="Professional market price chart">
      <div ref={containerRef} className="h-full w-full" />
    </div>
  );
}
