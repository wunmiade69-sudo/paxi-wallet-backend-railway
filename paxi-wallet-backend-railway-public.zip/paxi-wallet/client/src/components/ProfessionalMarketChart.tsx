import { useEffect, useMemo, useRef } from 'react';
import { useCurrency, useUsdFiatRate, formatFiat } from '@/lib/currency';
import {
  AreaSeries,
  CandlestickSeries,
  ColorType,
  createChart,
  type IChartApi,
  type Time,
} from 'lightweight-charts';
import {
  hasCompleteOhlc,
  hasSufficientChartData,
  normalizeChartSeries,
  type ChartSeriesInputPoint,
} from '@/lib/chartSeries';

export interface ProfessionalChartPoint extends ChartSeriesInputPoint {
  timestamp: number;
}

interface ProfessionalMarketChartProps {
  data: ProfessionalChartPoint[];
  positive: boolean;
  source?: string;
  fallback?: boolean;
  livePrice?: number | null;
  height?: number;
}

export function ChartLoadingState({ height = 250 }: { height?: number }) {
  return (
    <div
      className="flex w-full items-center justify-center rounded-xl bg-foreground/[0.02] text-sm text-muted-foreground"
      style={{ height }}
      role="status"
      aria-label="Loading historical chart"
    >
      <div className="w-full px-6">
        <div className="mb-3 h-2 w-28 animate-pulse rounded-full bg-foreground/10" />
        <div className="h-24 w-full animate-pulse rounded-lg bg-foreground/[0.05]" />
        <p className="mt-3 text-center text-xs">Loading historical data…</p>
      </div>
    </div>
  );
}

export function ChartUnavailableState({
  height = 250,
  message = 'Historical data unavailable',
}: {
  height?: number;
  message?: string;
}) {
  return (
    <div
      className="flex w-full items-center justify-center rounded-xl bg-foreground/[0.02] px-4 text-center text-sm text-muted-foreground"
      style={{ height }}
      role="status"
    >
      {message}
    </div>
  );
}

export default function ProfessionalMarketChart({
  data,
  positive,
  livePrice = null,
  height = 250,
}: ProfessionalMarketChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const accent = positive ? '#22c55e' : '#f87171';
  const mutedAccent = positive ? 'rgba(34,197,94,0.12)' : 'rgba(248,113,113,0.12)';
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);
  const displayRate = currency === 'USD' ? 1 : fiatRate;

  const normalized = useMemo(
    () => normalizeChartSeries(data, displayRate ?? 0),
    [data, displayRate],
  );
  const candlestickData = useMemo(
    () => normalized.filter(hasCompleteOhlc),
    [normalized],
  );
  const useCandlesticks = candlestickData.length >= 2 && candlestickData.length === normalized.length;
  const hasUsableSeries = hasSufficientChartData(normalized);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !hasUsableSeries) return;

    let chart: IChartApi | null = null;
    let frame = 0;

    const mount = () => {
      if (chart || !containerRef.current) return;
      const width = Math.floor(containerRef.current.getBoundingClientRect().width);
      if (width <= 0) {
        frame = requestAnimationFrame(mount);
        return;
      }

      chart = createChart(containerRef.current, {
        width,
        height,
        layout: {
          background: { type: ColorType.Solid, color: 'transparent' },
          textColor: '#a1a1aa',
          attributionLogo: false,
        },
        grid: {
          vertLines: { color: 'rgba(255,255,255,0.045)' },
          horzLines: { color: 'rgba(255,255,255,0.045)' },
        },
        crosshair: {
          vertLine: { color: accent, width: 1, style: 2, labelBackgroundColor: accent },
          horzLine: { color: accent, width: 1, style: 2, labelBackgroundColor: accent },
        },
        rightPriceScale: {
          borderColor: 'rgba(255,255,255,0.08)',
          entireTextOnly: true,
        },
        timeScale: {
          borderColor: 'rgba(255,255,255,0.08)',
          timeVisible: true,
          secondsVisible: false,
          rightOffset: 2,
          barSpacing: 8,
        },
        handleScroll: {
          mouseWheel: true,
          pressedMouseMove: true,
          horzTouchDrag: true,
          vertTouchDrag: false,
        },
        handleScale: {
          mouseWheel: true,
          pinch: true,
          axisPressedMouseMove: true,
          axisDoubleClickReset: true,
        },
        localization: {
          priceFormatter: (value: number) => formatFiat(value, currency, 1),
        },
      });
      chartRef.current = chart;

      let primarySeries: { setData: (seriesData: any[]) => void; createPriceLine?: (options: any) => unknown };
      if (useCandlesticks) {
        const series = chart.addSeries(CandlestickSeries, {
          upColor: '#22c55e',
          downColor: '#f87171',
          borderVisible: false,
          wickUpColor: '#22c55e',
          wickDownColor: '#f87171',
        });
        series.setData(
          candlestickData.map((point) => ({
            time: point.time as Time,
            open: point.open as number,
            high: point.high as number,
            low: point.low as number,
            close: point.close as number,
          })),
        );
        primarySeries = series;
      } else {
        const series = chart.addSeries(AreaSeries, {
          lineColor: accent,
          topColor: mutedAccent,
          bottomColor: 'rgba(0,0,0,0)',
          lineWidth: 2,
          crosshairMarkerBackgroundColor: accent,
          crosshairMarkerBorderColor: '#111111',
        });
        series.setData(normalized.map((point) => ({ time: point.time as Time, value: point.price })));
        primarySeries = series;
      }

      if (Number.isFinite(Number(livePrice)) && primarySeries.createPriceLine && displayRate != null) {
        primarySeries.createPriceLine({
          price: Number(livePrice) * displayRate,
          color: accent,
          lineWidth: 1,
          lineStyle: 2,
          axisLabelVisible: true,
          title: 'LIVE',
        });
      }

      chart.timeScale().fitContent();
    };

    const resizeObserver = new ResizeObserver((entries) => {
      const width = Math.floor(entries[0]?.contentRect.width ?? 0);
      if (chart && width > 0) chart.applyOptions({ width });
      else if (!chart && width > 0) mount();
    });
    resizeObserver.observe(container);
    mount();

    return () => {
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      chart?.remove();
      chartRef.current = null;
    };
  }, [accent, candlestickData, currency, displayRate, hasUsableSeries, height, livePrice, mutedAccent, normalized, useCandlesticks]);

  if (!hasUsableSeries) {
    return <ChartUnavailableState height={height} />;
  }

  return (
    <div
      className="relative w-full overflow-hidden"
      style={{ height }}
      role="img"
      aria-label="Historical market price chart"
    >
      <div ref={containerRef} className="h-full min-h-0 w-full" />
    </div>
  );
}
