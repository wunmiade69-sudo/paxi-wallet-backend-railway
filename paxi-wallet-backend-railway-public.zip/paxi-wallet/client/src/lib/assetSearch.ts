import type { AssetConfig } from '@/lib/wallet/chains';
import type { CanonicalTokenRecord, TokenFieldSources } from '@/lib/phase3Models';
import { canonicalMarketIdentityKey, marketResultIdentityKey, matchesAssetSearchText } from '@/lib/marketIdentity';

export interface SearchMarketResult {
  id: string;
  chain?: string | null;
  contractAddress?: string | null;
  coinId?: string | null;
  symbol: string;
  name: string;
  image?: string | null;
  decimals?: number | null;
  currentPrice?: number | null;
  marketCap?: number | null;
  volume24h?: number | null;
  liquidity?: number | null;
  verificationStatus?: 'verified' | 'unverified' | 'unknown';
  securityStatus?: 'available' | 'unavailable';
  source?: string;
  sources?: string[];
  fieldSources?: TokenFieldSources;
}

/** Convert a provider result into the shared client canonical record without inventing unavailable fields. */
export function searchResultToCanonicalToken(result: SearchMarketResult): CanonicalTokenRecord | null {
  if (!result.chain) return null;
  const hasContract = Boolean(result.contractAddress);
  const availability = result.currentPrice != null || result.marketCap != null || result.volume24h != null
    ? 'available'
    : result.name || result.symbol
      ? 'unavailable'
      : 'error';
  return {
    identity: {
      kind: 'token',
      chain: result.chain,
      contractOrMint: hasContract ? result.contractAddress ?? undefined : undefined,
    },
    name: result.name || 'Unknown token',
    symbol: result.symbol || '—',
    logoUrl: result.image || undefined,
    decimals: result.decimals ?? null,
    price: result.currentPrice ?? null,
    change24h: null,
    marketCap: result.marketCap ?? null,
    volume24h: result.volume24h ?? null,
    liquidity: result.liquidity ?? null,
    verification: result.verificationStatus ?? 'unknown',
    risk: 'unknown',
    availability,
    fieldSources: result.fieldSources ?? (result.sources ? { identity: result.sources, name: result.sources, symbol: result.sources } : {}),
  };
}

/** Local assets are searchable only after a chain has been selected. */
export function filterLocalAssetsForSearch(
  assets: AssetConfig[],
  selectedNetwork: string | null,
  query: string,
): AssetConfig[] {
  const normalizedQuery = query.trim();
  if (!selectedNetwork || !normalizedQuery) return [];
  return assets.filter(
    (asset) => asset.network === selectedNetwork && matchesAssetSearchText(asset, normalizedQuery),
  );
}

/** Provider results are constrained to the selected chain and deduplicated by canonical identity. */
export function filterProviderAssetsForSearch(
  results: SearchMarketResult[],
  selectedNetwork: string | null,
  query: string,
  localAssets: AssetConfig[],
): SearchMarketResult[] {
  const normalizedQuery = query.trim();
  if (!selectedNetwork || !normalizedQuery) return [];

  const localIdentities = new Set(
    localAssets
      .filter((asset) => asset.contractAddress)
      .map((asset) => canonicalMarketIdentityKey(asset.network, asset.contractAddress!)),
  );
  const queryLower = normalizedQuery.toLowerCase();

  return results
    .filter((result) => result.chain === selectedNetwork)
    .filter((result) => {
      const identity = marketResultIdentityKey(result);
      return !identity || !localIdentities.has(identity);
    })
    .sort((a, b) => {
      const aExact = a.contractAddress?.toLowerCase() === queryLower ? 1 : 0;
      const bExact = b.contractAddress?.toLowerCase() === queryLower ? 1 : 0;
      return bExact - aExact;
    });
}
