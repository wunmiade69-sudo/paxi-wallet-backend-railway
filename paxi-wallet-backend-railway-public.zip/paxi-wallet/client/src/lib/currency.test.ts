import { describe, expect, it } from 'vitest';
import { formatFiat, getStoredCurrency, isFiatCurrency } from './currency';

describe('fiat currency utilities', () => {
  it('accepts only supported currency codes and defaults safely', () => {
    expect(isFiatCurrency('USD')).toBe(true);
    expect(isFiatCurrency('CAD')).toBe(false);
    expect(getStoredCurrency()).toBe('USD');
  });

  it('formats USD values in the selected fiat using a supplied rate', () => {
    expect(formatFiat(10, 'USD', 1)).toBe('$10');
    expect(formatFiat(10, 'EUR', 0.9)).toBe('€9');
  });

  it('does not invent a zero value when the selected fiat rate is unavailable', () => {
    expect(formatFiat(10, 'GBP', null)).toBe('—');
    expect(formatFiat(null, 'USD', 1)).toBe('—');
  });
});
