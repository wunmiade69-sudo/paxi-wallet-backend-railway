import { useEffect, useState } from 'react';
import { safeGetLocalStorage, safeSetLocalStorage } from './safeStorage';

export const SUPPORTED_CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'INR'] as const;
export type FiatCurrency = (typeof SUPPORTED_CURRENCIES)[number];

const CURRENCY_KEY = 'paxi-currency';
const RATE_CACHE_KEY = 'paxi-usd-fiat-rates';
const RATE_CACHE_TTL_MS = 30 * 60 * 1000;
const CURRENCY_EVENT = 'paxi-currency-changed';
const RATE_ENDPOINT = 'https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,INR';

interface RateCache {
  fetchedAt: number;
  rates: Partial<Record<FiatCurrency, number>>;
}

export function getStoredCurrency(): FiatCurrency {
  const stored = safeGetLocalStorage(CURRENCY_KEY);
  return isFiatCurrency(stored) ? stored : 'USD';
}

export function setStoredCurrency(currency: FiatCurrency): void {
  safeSetLocalStorage(CURRENCY_KEY, currency);
  window.dispatchEvent(new CustomEvent(CURRENCY_EVENT, { detail: currency }));
}

export function isFiatCurrency(value: string | null | undefined): value is FiatCurrency {
  return Boolean(value && (SUPPORTED_CURRENCIES as readonly string[]).includes(value));
}

export function formatFiat(usdValue: number | null | undefined, currency: FiatCurrency, usdToCurrencyRate?: number | null): string {
  if (usdValue == null || !Number.isFinite(usdValue)) return '—';
  const rate = currency === 'USD' ? 1 : usdToCurrencyRate;
  if (rate == null || !Number.isFinite(rate) || rate <= 0) return '—';
  const symbols: Record<FiatCurrency, string> = { USD: '$', EUR: '€', GBP: '£', JPY: '¥', INR: '₹' };
  const converted = usdValue * rate;
  const maximumFractionDigits = currency === 'JPY' ? 0 : converted < 1 ? 6 : 2;
  return `${symbols[currency]}${converted.toLocaleString(undefined, { maximumFractionDigits })}`;
}

function readRateCache(): RateCache | null {
  try {
    const raw = safeGetLocalStorage(RATE_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as RateCache;
    return parsed && typeof parsed.fetchedAt === 'number' && parsed.rates ? parsed : null;
  } catch {
    return null;
  }
}

function writeRateCache(cache: RateCache): void {
  safeSetLocalStorage(RATE_CACHE_KEY, JSON.stringify(cache));
}

export async function fetchUsdFiatRates(): Promise<RateCache['rates'] | null> {
  const cached = readRateCache();
  if (cached && Date.now() - cached.fetchedAt < RATE_CACHE_TTL_MS) return cached.rates;
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 8_000);
  try {
    const response = await fetch(RATE_ENDPOINT, { signal: controller.signal });
    if (!response.ok) return cached?.rates ?? null;
    const body = (await response.json()) as { rates?: Record<string, number> };
    const rates: RateCache['rates'] = { USD: 1 };
    for (const currency of SUPPORTED_CURRENCIES) {
      if (currency === 'USD') continue;
      const value = body.rates?.[currency];
      if (typeof value === 'number' && Number.isFinite(value) && value > 0) rates[currency] = value;
    }
    if (Object.keys(rates).length > 1) writeRateCache({ fetchedAt: Date.now(), rates });
    return rates;
  } catch {
    return cached?.rates ?? null;
  } finally {
    window.clearTimeout(timeout);
  }
}

export function useCurrency(): FiatCurrency {
  const [currency, setCurrency] = useState<FiatCurrency>(() => getStoredCurrency());
  useEffect(() => {
    const onChange = () => setCurrency(getStoredCurrency());
    window.addEventListener(CURRENCY_EVENT, onChange);
    window.addEventListener('storage', onChange);
    return () => {
      window.removeEventListener(CURRENCY_EVENT, onChange);
      window.removeEventListener('storage', onChange);
    };
  }, []);
  return currency;
}

export function useUsdFiatRate(currency: FiatCurrency): number | null {
  const [rate, setRate] = useState<number | null>(() => readRateCache()?.rates[currency] ?? (currency === 'USD' ? 1 : null));
  useEffect(() => {
    let active = true;
    setRate(readRateCache()?.rates[currency] ?? (currency === 'USD' ? 1 : null));
    void fetchUsdFiatRates().then((rates) => {
      if (active) setRate(rates?.[currency] ?? (currency === 'USD' ? 1 : null));
    });
    return () => { active = false; };
  }, [currency]);
  return rate;
}
