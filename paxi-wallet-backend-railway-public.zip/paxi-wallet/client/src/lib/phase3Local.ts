import type { ConnectedDappRecord, NotificationRecord, NotificationTarget, TokenApprovalRecord } from '@/lib/phase3Models';
import { walletConnectManager } from '@/lib/wallet/walletconnect';

const NOTIFICATIONS_KEY = 'paxi-notifications';
const NOTIFICATION_PREFERENCES_KEY = 'paxi-notification-preferences';
const PRICE_ALERT_STATE_KEY = 'paxi-price-alert-state';
const PRICE_ALERT_COOLDOWN_MS = 6 * 60 * 60 * 1000;

export interface NotificationPreferences {
  transaction: boolean;
  receivedFunds: boolean;
  priceAlerts: boolean;
  securityWarnings: boolean;
  ecosystemAnnouncements: boolean;
}

const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences = {
  transaction: true,
  receivedFunds: true,
  priceAlerts: false,
  securityWarnings: true,
  ecosystemAnnouncements: false,
};

function readArray<T>(key: string): T[] {
  if (typeof localStorage === 'undefined') return [];
  try {
    const raw = JSON.parse(localStorage.getItem(key) ?? '[]');
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

/**
 * WalletConnect can populate this later. Until a validated session record
 * exists, the UI must show an empty/unknown state rather than inventing a
 * connection or granting a disconnect capability.
 */
function isConnectedDappRecord(record: unknown): record is ConnectedDappRecord {
  if (!record || typeof record !== 'object') return false;
  const value = record as Partial<ConnectedDappRecord>;
  return typeof value.id === 'string' && value.id.length > 0
    && typeof value.name === 'string' && value.name.length > 0
    && typeof value.domain === 'string' && value.domain.length > 0
    && typeof value.network === 'string' && value.network.length > 0
    && (value.status === 'connected' || value.status === 'pending' || value.status === 'disconnected' || value.status === 'unknown')
    && (value.lastUsed === null || typeof value.lastUsed === 'number')
    && Array.isArray(value.permissions) && value.permissions.every((permission) => typeof permission === 'string')
    && typeof value.canDisconnect === 'boolean';
}

export function getConnectedDapps(): ConnectedDappRecord[] {
  return walletConnectManager.sessions.map((session) => ({
    id: session.topic,
    name: session.dapp.name || 'Unknown dApp',
    domain: safeDomain(session.dapp.url),
    network: session.chains.join(', ') || 'unknown',
    status: 'connected' as const,
    lastUsed: null,
    permissions: ['WalletConnect session'],
    canDisconnect: true,
  })).filter(isConnectedDappRecord);
}

export function subscribeToConnectedDapps(listener: () => void): () => void {
  return walletConnectManager.subscribe(listener);
}

export async function disconnectConnectedDapp(id: string): Promise<void> {
  await walletConnectManager.disconnectSession(id);
}

function safeDomain(url: string): string {
  try {
    return new URL(url).hostname || 'unknown';
  } catch {
    return 'unknown';
  }
}

export function getTokenApprovals(): TokenApprovalRecord[] {
  // Approval scanning is intentionally unavailable until a validated EVM
  // indexer/security provider is wired. No UI-generated approval records.
  return [];
}

const NOTIFICATION_TYPES = new Set<NotificationRecord['type']>([
  'incoming-transaction', 'transaction-submitted', 'transaction-confirmed', 'transaction-failed',
  'swap-completed', 'bridge-completed', 'security-warning', 'price-alert',
  'ecosystem-announcement',
]);

function isNotificationTarget(value: unknown): value is NotificationTarget {
  if (!value || typeof value !== 'object') return false;
  const target = value as Partial<NotificationTarget>;
  const validEntity = target.entityType === 'token' || target.entityType === 'transaction' || target.entityType === 'security' || target.entityType === 'system';
  const validNavigation = target.navigation === 'token-detail' || target.navigation === 'asset-detail' || target.navigation === 'tx-history' || target.navigation === 'none';
  const hasIdentity = typeof target.coinId === 'string' || (typeof target.chain === 'string' && typeof target.contractOrMint === 'string');
  return validEntity && validNavigation
    && (target.chain === undefined || typeof target.chain === 'string')
    && (target.contractOrMint === undefined || typeof target.contractOrMint === 'string')
    && (target.coinId === undefined || typeof target.coinId === 'string')
    && (target.navigation === 'none' || target.entityType !== 'token' || hasIdentity);
}

function isNotificationRecord(record: unknown): record is NotificationRecord {
  if (!record || typeof record !== 'object') return false;
  const value = record as Partial<NotificationRecord>;
  return typeof value.id === 'string' && value.id.length > 0
    && typeof value.title === 'string' && value.title.length > 0
    && typeof value.body === 'string' && value.body.length > 0
    && typeof value.createdAt === 'number'
    && typeof value.read === 'boolean'
    && (value.readAt === undefined || typeof value.readAt === 'number')
    && (value.dedupeKey === undefined || typeof value.dedupeKey === 'string')
    && (value.target === undefined || isNotificationTarget(value.target))
    && NOTIFICATION_TYPES.has(value.type as NotificationRecord['type'])
    && (value.source === 'local-wallet' || value.source === 'indexed-transaction' || value.source === 'validated-security-provider' || value.source === 'market-data' || value.source === 'ecosystem-feed');
}

export function getNotifications(): NotificationRecord[] {
  return readArray<NotificationRecord>(NOTIFICATIONS_KEY).filter(isNotificationRecord);
}

export function getNotificationPreferences(): NotificationPreferences {
  if (typeof localStorage === 'undefined') return { ...DEFAULT_NOTIFICATION_PREFERENCES };
  try {
    const raw = JSON.parse(localStorage.getItem(NOTIFICATION_PREFERENCES_KEY) ?? '{}') as Partial<NotificationPreferences>;
    return {
      transaction: raw.transaction ?? DEFAULT_NOTIFICATION_PREFERENCES.transaction,
      receivedFunds: raw.receivedFunds ?? DEFAULT_NOTIFICATION_PREFERENCES.receivedFunds,
      priceAlerts: raw.priceAlerts ?? DEFAULT_NOTIFICATION_PREFERENCES.priceAlerts,
      securityWarnings: raw.securityWarnings ?? DEFAULT_NOTIFICATION_PREFERENCES.securityWarnings,
      ecosystemAnnouncements: raw.ecosystemAnnouncements ?? DEFAULT_NOTIFICATION_PREFERENCES.ecosystemAnnouncements,
    };
  } catch {
    return { ...DEFAULT_NOTIFICATION_PREFERENCES };
  }
}

export function setNotificationPreferences(patch: Partial<NotificationPreferences>): NotificationPreferences {
  const next = { ...getNotificationPreferences(), ...patch };
  if (typeof localStorage !== 'undefined') localStorage.setItem(NOTIFICATION_PREFERENCES_KEY, JSON.stringify(next));
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(NOTIFICATION_EVENT));
  return next;
}

const NOTIFICATION_EVENT = 'paxi-notifications-changed';

function persistNotifications(records: NotificationRecord[]): void {
  if (typeof localStorage === 'undefined') return;
  localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(records.slice(0, 200)));
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(NOTIFICATION_EVENT));
}

/** Adds a real event-backed notification and deduplicates by its stable event id. */
export function addNotification(input: Omit<NotificationRecord, 'id' | 'createdAt' | 'read' | 'readAt'> & { id?: string; createdAt?: number; read?: boolean; readAt?: number }): NotificationRecord {
  const record: NotificationRecord = {
    id: input.id ?? `${input.type}:${input.createdAt ?? Date.now()}:${input.body}`.slice(0, 180),
    createdAt: input.createdAt ?? Date.now(),
    read: input.read ?? false,
    ...(input.readAt !== undefined ? { readAt: input.readAt } : {}),
    ...(input.dedupeKey ? { dedupeKey: input.dedupeKey } : {}),
    ...(input.target ? { target: input.target } : {}),
    type: input.type,
    title: input.title,
    body: input.body,
    source: input.source,
  };
  const existing = getNotifications();
  const duplicate = existing.find((item) => item.id === record.id || (record.dedupeKey !== undefined && item.dedupeKey === record.dedupeKey));
  if (duplicate) return duplicate;
  persistNotifications([record, ...existing]);
  return record;
}

export function markNotificationRead(id: string): void {
  const readAt = Date.now();
  const next = getNotifications().map((item) => item.id === id ? { ...item, read: true, readAt: item.readAt ?? readAt } : item);
  persistNotifications(next);
}

interface PriceAlertState {
  lastPrice: number;
  lastDirection?: 'up' | 'down';
  lastNotifiedAt?: number;
}

export function notifyForPriceMovement(input: {
  assetKey: string;
  symbol: string;
  currentPrice: number | null | undefined;
  thresholdPercent?: number;
  chain?: string | null;
  contractOrMint?: string | null;
  coinId?: string | null;
}): NotificationRecord | null {
  if (!getNotificationPreferences().priceAlerts || typeof window === 'undefined') return null;
  const currentPrice = Number(input.currentPrice);
  const threshold = input.thresholdPercent ?? 1;
  if (!Number.isFinite(currentPrice) || currentPrice <= 0) return null;
  const state = readArray<Record<string, PriceAlertState>>(PRICE_ALERT_STATE_KEY);
  const previous = state.find((entry) => Object.prototype.hasOwnProperty.call(entry, input.assetKey))?.[input.assetKey];
  const now = Date.now();
  const nextState = state.filter((entry) => !Object.prototype.hasOwnProperty.call(entry, input.assetKey));
  if (!previous || !Number.isFinite(previous.lastPrice) || previous.lastPrice <= 0) {
    nextState.unshift({ [input.assetKey]: { lastPrice: currentPrice } });
    localStorage.setItem(PRICE_ALERT_STATE_KEY, JSON.stringify(nextState.slice(0, 200)));
    return null;
  }
  const change = ((currentPrice - previous.lastPrice) / previous.lastPrice) * 100;
  const direction = change >= 0 ? 'up' : 'down';
  nextState.unshift({ [input.assetKey]: { lastPrice: currentPrice, lastDirection: previous.lastDirection, lastNotifiedAt: previous.lastNotifiedAt } });
  if (!Number.isFinite(change) || Math.abs(change) < threshold || (previous.lastDirection === direction && now - (previous.lastNotifiedAt ?? 0) < PRICE_ALERT_COOLDOWN_MS)) {
    localStorage.setItem(PRICE_ALERT_STATE_KEY, JSON.stringify(nextState.slice(0, 200)));
    return null;
  }
  nextState[0] = { [input.assetKey]: { lastPrice: currentPrice, lastDirection: direction, lastNotifiedAt: now } };
  localStorage.setItem(PRICE_ALERT_STATE_KEY, JSON.stringify(nextState.slice(0, 200)));
  const signedChange = `${change >= 0 ? '+' : ''}${change.toFixed(1)}%`;
  const hasCanonicalIdentity = Boolean(input.coinId || (input.chain && input.contractOrMint));
  const target: NotificationTarget | undefined = hasCanonicalIdentity
    ? {
      entityType: 'token',
      navigation: 'token-detail',
      ...(input.chain ? { chain: input.chain } : {}),
      ...(input.contractOrMint ? { contractOrMint: input.contractOrMint } : {}),
      ...(input.coinId ? { coinId: input.coinId } : {}),
    }
    : undefined;
  return addNotification({
    id: `price:${input.assetKey}:${direction}:${Math.floor(now / PRICE_ALERT_COOLDOWN_MS)}`,
    dedupeKey: `price:${input.assetKey}:${direction}:${Math.floor(now / PRICE_ALERT_COOLDOWN_MS)}`,
    type: 'price-alert',
    title: `${input.symbol || 'Asset'} is ${direction} ${signedChange}`,
    body: `Price movement observed from normalized market data · ${input.symbol || 'Asset'}`,
    ...(target ? { target } : {}),
    source: 'market-data',
  });
}

export function subscribeToNotifications(listener: () => void): () => void {
  if (typeof window === 'undefined') return () => undefined;
  window.addEventListener(NOTIFICATION_EVENT, listener);
  window.addEventListener('storage', listener);
  return () => {
    window.removeEventListener(NOTIFICATION_EVENT, listener);
    window.removeEventListener('storage', listener);
  };
}

export function notifyForTransaction(input: {
  hash: string;
  networkId: string;
  type: 'receive' | 'send' | 'swap' | 'bridge';
  status: 'submitted' | 'confirmed' | 'failed';
  symbol: string;
  amount: string;
  timestamp?: number;
  source?: 'local-wallet' | 'indexed-transaction';
}): NotificationRecord | null {
  const preferences = getNotificationPreferences();
  if (input.type === 'receive' ? !preferences.receivedFunds : !preferences.transaction) return null;
  const notificationType: NotificationRecord['type'] = input.status === 'submitted'
    ? 'transaction-submitted'
    : input.status === 'failed'
      ? 'transaction-failed'
      : input.type === 'swap'
        ? 'swap-completed'
        : input.type === 'bridge'
          ? 'bridge-completed'
          : input.type === 'receive'
            ? 'incoming-transaction'
            : 'transaction-confirmed';
  const verb = input.status === 'submitted' ? 'submitted' : input.status === 'failed' ? 'failed' : notificationType === 'incoming-transaction' ? 'confirmed' : 'completed';
  const title = input.type === 'receive' && input.status === 'confirmed'
    ? 'Incoming transaction confirmed'
    : `${input.type[0].toUpperCase()}${input.type.slice(1)} ${verb}`;
  return addNotification({
    id: `tx:${input.networkId}:${input.hash.toLowerCase()}:${input.status}`,
    type: notificationType,
    title,
    body: `${input.amount} ${input.symbol} on ${input.networkId} · ${input.hash.slice(0, 10)}…`,
    createdAt: input.timestamp,
    source: input.source ?? 'indexed-transaction',
  });
}
