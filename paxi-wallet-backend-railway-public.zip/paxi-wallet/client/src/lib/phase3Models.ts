import type { AssetConfig } from '@/lib/wallet/chains';
import type { AssetBalance } from '@/lib/wallet/balances';

/**
 * Extensible portfolio model. The identity rules are deliberately explicit:
 * fungible/native assets use chain + contract/mint (or the documented native
 * sentinel), while NFTs add tokenId. These records are presentation models;
 * they are not authorization or settlement records.
 */
export type PortfolioAssetKind = 'native' | 'token' | 'stablecoin' | 'nft' | 'staked' | 'lp' | 'other';

export type DataAvailability = 'available' | 'unavailable' | 'loading' | 'error';
export type VerificationStatus = 'verified' | 'unverified' | 'unknown';

export type CanonicalTokenField =
  | 'identity'
  | 'name'
  | 'symbol'
  | 'decimals'
  | 'logo'
  | 'price'
  | 'change24h'
  | 'marketCap'
  | 'volume24h'
  | 'liquidity'
  | 'verification'
  | 'risk';

/** Providers or local subsystems that actually supplied each field. */
export type TokenFieldSources = Partial<Record<CanonicalTokenField, string[]>>;

/** Additive client representation shared by discovery, portfolio, and detail adapters. */
export interface CanonicalTokenRecord {
  identity: PortfolioAssetIdentity;
  name: string;
  symbol: string;
  logoUrl?: string;
  decimals: number | null;
  price: number | null;
  change24h: number | null;
  marketCap: number | null;
  volume24h: number | null;
  liquidity: number | null;
  verification: VerificationStatus;
  risk: RiskStatus;
  availability: DataAvailability;
  fieldSources: TokenFieldSources;
}
export type RiskStatus = 'good' | 'review' | 'warning' | 'unknown';

export interface PortfolioAssetIdentity {
  kind: PortfolioAssetKind;
  chain: string;
  /** Token contract or mint. Native assets intentionally omit this field. */
  contractOrMint?: string;
  /** NFT identity extension; not currently populated by the wallet balance engine. */
  tokenId?: string;
}

export interface PortfolioAsset {
  identity: PortfolioAssetIdentity;
  name: string;
  symbol: string;
  logoUrl?: string;
  fallbackGlyph?: string;
  balance: number | null;
  fiatValue: number | null;
  price: number | null;
  change24h: number | null;
  decimals: number | null;
  verification: VerificationStatus;
  risk: RiskStatus;
  availability: DataAvailability;
  /** Additive field-level provenance; unavailable fields are omitted. */
  fieldSources?: TokenFieldSources;
  source: 'wallet-balance-engine' | 'future-indexer' | 'future-provider';
  rawAsset?: AssetConfig;
}

export type AssetSection = 'all' | 'tokens' | 'nfts' | 'other';

export function portfolioAssetKind(asset: AssetConfig): PortfolioAssetKind {
  if (asset.isNative) return 'native';
  const stableSymbols = new Set(['USDT', 'USDC', 'DAI', 'FDUSD', 'USDE']);
  return stableSymbols.has(asset.symbol.toUpperCase()) ? 'stablecoin' : 'token';
}

export function portfolioAssetIdentity(asset: AssetConfig): PortfolioAssetIdentity {
  return {
    kind: portfolioAssetKind(asset),
    chain: asset.network,
    // Native coins have no contract/mint and must not be made to look like tokens.
    contractOrMint: asset.isNative ? undefined : asset.contractAddress,
  };
}

export function toPortfolioAsset(result: AssetBalance): PortfolioAsset {
  const { asset, balance, usdPrice, change24h } = result;
  return {
    identity: portfolioAssetIdentity(asset),
    name: asset.name,
    symbol: asset.symbol,
    logoUrl: asset.iconUrl,
    fallbackGlyph: asset.icon,
    balance,
    fiatValue: balance != null && usdPrice != null ? balance * usdPrice : null,
    price: usdPrice,
    change24h,
    decimals: Number.isFinite(asset.decimals) ? asset.decimals : null,
    verification: 'unknown',
    risk: 'unknown',
    availability: balance == null && usdPrice == null ? 'unavailable' : 'available',
    fieldSources: {
      ...asset.fieldSources,
      identity: asset.fieldSources?.identity ?? ['wallet-balance-engine'],
      name: asset.fieldSources?.name ?? (asset.name ? ['wallet-balance-engine'] : undefined),
      symbol: asset.fieldSources?.symbol ?? (asset.symbol ? ['wallet-balance-engine'] : undefined),
      logo: asset.fieldSources?.logo ?? (asset.iconUrl ? ['wallet-balance-engine'] : undefined),
      decimals: asset.fieldSources?.decimals ?? (Number.isFinite(asset.decimals) ? ['wallet-balance-engine'] : undefined),
      price: result.fieldSources?.price ?? (usdPrice != null ? ['wallet-balance-engine'] : undefined),
      change24h: result.fieldSources?.change24h ?? (change24h != null ? ['wallet-balance-engine'] : undefined),
    },
    source: 'wallet-balance-engine',
    rawAsset: asset,
  };
}

export function assetSectionIncludes(section: AssetSection, kind: PortfolioAssetKind): boolean {
  if (section === 'all') return true;
  if (section === 'tokens') return kind === 'native' || kind === 'token' || kind === 'stablecoin';
  if (section === 'nfts') return kind === 'nft';
  return kind !== 'native' && kind !== 'token' && kind !== 'stablecoin' && kind !== 'nft';
}

export interface DiscoverEntry {
  id: string;
  name: string;
  url?: string;
  logoUrl?: string;
  description: string;
  category: DiscoverCategory;
  supportedChains: string[];
  domain?: string;
  verification: VerificationStatus;
  risk: RiskStatus;
  status: 'available' | 'unavailable' | 'coming-soon';
  featured?: boolean;
  source: 'curated' | 'server-catalog' | 'future-provider';
}

export type DiscoverCategory =
  | 'defi'
  | 'exchanges'
  | 'lending'
  | 'nft'
  | 'games'
  | 'social'
  | 'payments'
  | 'staking'
  | 'paxi'
  | 'earn'
  | 'learn'
  | 'trending';

export const DISCOVER_CATEGORY_LABELS: Record<DiscoverCategory, string> = {
  defi: 'DeFi',
  exchanges: 'Exchanges',
  lending: 'Lending',
  nft: 'NFT',
  games: 'Games',
  social: 'Social',
  payments: 'Payments',
  staking: 'Staking',
  paxi: 'PAXI ecosystem',
  earn: 'Earn',
  learn: 'Learn',
  trending: 'Trending',
};

export interface SecuritySignal {
  id: string;
  label: string;
  status: RiskStatus;
  detail: string;
  source: 'local-device' | 'validated-provider' | 'unknown';
}

export interface SecuritySummary {
  overall: RiskStatus;
  signals: SecuritySignal[];
  disclaimer: string;
}

export interface ConnectedDappRecord {
  id: string;
  name: string;
  domain: string;
  network: string;
  status: 'connected' | 'pending' | 'disconnected' | 'unknown';
  lastUsed: number | null;
  permissions: string[];
  canDisconnect: boolean;
}

export interface TokenApprovalRecord {
  id: string;
  token: string;
  spender: string;
  contract: string;
  network: string;
  allowance: string | null;
  risk: RiskStatus;
  availability: DataAvailability;
}

export type NotificationType =
  | 'incoming-transaction'
  | 'transaction-submitted'
  | 'transaction-confirmed'
  | 'transaction-failed'
  | 'swap-completed'
  | 'bridge-completed'
  | 'security-warning'
  | 'price-alert'
  | 'ecosystem-announcement';

export type NotificationNavigation = 'token-detail' | 'asset-detail' | 'tx-history' | 'none';

/**
 * Optional, non-authorizing navigation context. It is only a pointer to an
 * existing screen; it never grants access to a wallet, transaction, or key.
 */
export interface NotificationTarget {
  entityType: 'token' | 'transaction' | 'security' | 'system';
  chain?: string;
  contractOrMint?: string;
  coinId?: string;
  navigation: NotificationNavigation;
}

export interface NotificationRecord {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  createdAt: number;
  read: boolean;
  readAt?: number;
  dedupeKey?: string;
  target?: NotificationTarget;
  source: 'local-wallet' | 'indexed-transaction' | 'validated-security-provider' | 'market-data' | 'ecosystem-feed';
}

export const EMPTY_SECURITY_SUMMARY: SecuritySummary = {
  overall: 'unknown',
  signals: [
    { id: 'wallet-protection', label: 'Wallet protection', status: 'unknown', detail: 'Protection status is device-local and not independently audited.', source: 'local-device' },
    { id: 'backup', label: 'Backup status', status: 'unknown', detail: 'Confirm your recovery backup from Settings.', source: 'local-device' },
    { id: 'biometrics', label: 'Biometrics', status: 'unknown', detail: 'Biometric availability depends on this device.', source: 'local-device' },
    { id: 'connected-dapps', label: 'Connected dApps', status: 'unknown', detail: 'Review active WalletConnect sessions before signing.', source: 'local-device' },
    { id: 'token-approvals', label: 'Token approvals', status: 'unknown', detail: 'Approval scanning is not available yet.', source: 'unknown' },
  ],
  disclaimer: 'Unknown means PAXI has not independently verified the state; it is not a claim that the wallet is secure.',
};
