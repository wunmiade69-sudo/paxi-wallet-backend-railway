import { beforeEach, describe, expect, it } from 'vitest';
import { addCustomToken, customTokenToAsset, getCustomTokens } from './customTokens';

function installStorage() {
  const values = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
    clear: () => values.clear(),
    key: (index: number) => [...values.keys()][index] ?? null,
    get length() { return values.size; },
  };
}

describe('custom token canonical metadata persistence', () => {
  beforeEach(() => installStorage());

  it('persists field-level sources and carries them into the portfolio asset adapter', () => {
    addCustomToken({
      symbol: 'TKN',
      name: 'Example Token',
      contractAddress: '0x0000000000000000000000000000000000000001',
      network: 'ethereum',
      decimals: 18,
      addedAt: 1,
      iconUrl: 'https://example.com/token.png',
      fieldSources: {
        name: ['evm-contract'],
        symbol: ['evm-contract'],
        decimals: ['evm-contract'],
        logo: ['user-entered'],
      },
    });

    const saved = getCustomTokens()[0];
    expect(saved?.fieldSources?.name).toEqual(['evm-contract']);
    expect(customTokenToAsset(saved!).fieldSources?.logo).toEqual(['user-entered']);
    expect(customTokenToAsset(saved!).iconUrl).toBe('https://example.com/token.png');
  });

  it('does not turn an unsafe custom logo URL into a remote asset source', () => {
    const asset = customTokenToAsset({
      symbol: 'TKN',
      name: 'Example Token',
      contractAddress: '0x0000000000000000000000000000000000000001',
      network: 'ethereum',
      decimals: 18,
      addedAt: 1,
      iconUrl: 'javascript:alert(1)',
      fieldSources: { logo: ['user-entered'] },
    });
    expect(asset.iconUrl).toMatch(/^https:\/\/raw\.githubusercontent\.com\/trustwallet\//);
    expect(asset.fieldSources?.logo).toBeUndefined();
  });
});

