import { describe, expect, it } from "vitest";
import { faviconFor, normalizeUrl, toDiscoverEntry } from "./discover";

describe("Discover link safety", () => {
  it("normalizes bare domains to HTTPS", () => {
    expect(normalizeUrl("app.example.org/path")).toBe("https://app.example.org/path");
  });

  it("rejects HTTP, unsafe schemes, malformed hosts, and embedded credentials", () => {
    expect(() => normalizeUrl("http://example.org")).toThrow(/HTTPS/i);
    expect(() => normalizeUrl("javascript:alert(1)")).toThrow();
    expect(() => normalizeUrl("https://user:password@example.org")).toThrow(/credentials/i);
    expect(() => normalizeUrl("https://localhost")).toThrow();
  });

  it("does not proxy favicons and preserves an entry-specific fallback boundary", () => {
    expect(faviconFor("http://example.org")).toBe("");
    expect(faviconFor("javascript:alert(1)")).toBe("");
    expect(faviconFor("https://dapp.example.org")).toBe("");
  });

  it("preserves curated source and unknown trust state instead of implying verification", () => {
    const entry = toDiscoverEntry({
      id: "example",
      name: "Example DApp",
      url: "https://example.org",
      category: "DEX",
      description: "Example",
      supportedChains: ["ethereum"],
    });

    expect(entry.source).toBe("curated");
    expect(entry.verification).toBe("unknown");
    expect(entry.risk).toBe("unknown");
  });
});
