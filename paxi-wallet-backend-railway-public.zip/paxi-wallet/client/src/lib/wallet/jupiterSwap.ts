/**
 * Solana swap engine via Jupiter Aggregator (quote-api.jup.ag) - the
 * standard multi-DEX router for Solana, the equivalent of what Velora does
 * for EVM in swap.ts. No API key needed for this usage level.
 *
 * Uses the /swap-instructions endpoint (raw instructions) rather than
 * /swap (a pre-compiled, already-signed-shape transaction), specifically
 * so this wallet's own fee-collection instruction can be added into the
 * same transaction - a compiled VersionedTransaction from /swap can't be
 * modified afterward.
 *
 * FEE NOTE (documented limitation, not silently skipped): the platform fee
 * is taken via Jupiter's own platformFeeBps mechanism into an associated
 * token account for the OUTPUT mint, owned by the Solana treasury address.
 * That account is created on-the-fly (paid by the swapper, a few thousand
 * lamports) if it doesn't exist yet - this works for any output token.
 */
import {
  Connection,
  PublicKey,
  TransactionMessage,
  VersionedTransaction,
  AddressLookupTableAccount,
} from '@solana/web3.js';
import { NETWORKS, type AssetConfig } from './chains';
import { deriveSolanaKeypair } from './engine';
import type { SwapQuote } from './swap';

const JUPITER_API_BASE = 'https://quote-api.jup.ag/v6';
const JUPITER_REQUEST_TIMEOUT_MS = 15_000;
export const SOL_WALLET_FEE_BPS = 30; // 0.3%, matches the EVM fee

/** Set this to the Solana address fees should land in - a separate address
 * from the EVM treasury (different curve/chain), still to be provided. */
export const SOL_TREASURY_ADDRESS = ''; // <- fill in before fees can be collected on Solana swaps

const NATIVE_SOL_MINT = 'So11111111111111111111111111111111111111112';

function mintFor(asset: AssetConfig): string {
  return asset.isNative ? NATIVE_SOL_MINT : asset.contractAddress!;
}

async function fetchJupiter(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), JUPITER_REQUEST_TIMEOUT_MS);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

export function isSolanaSwappable(asset: AssetConfig): boolean {
  return NETWORKS[asset.network]?.chainType === 'sol';
}

/** Internal: the raw Jupiter quote, kept alongside the shared SwapQuote shape for use at execute time. */
type SolanaSwapQuote = SwapQuote & { _jupiterRaw: any };

export async function getSolanaSwapQuote(params: {
  fromAsset: AssetConfig;
  toAsset: AssetConfig;
  amount: string; // human units
  slippageBps?: number;
}): Promise<SolanaSwapQuote> {
  const inputMint = mintFor(params.fromAsset);
  const outputMint = mintFor(params.toAsset);
  const amountUnits = Math.round(Number(params.amount) * 10 ** params.fromAsset.decimals);

  const url = new URL(`${JUPITER_API_BASE}/quote`);
  url.searchParams.set('inputMint', inputMint);
  url.searchParams.set('outputMint', outputMint);
  url.searchParams.set('amount', String(amountUnits));
  url.searchParams.set('slippageBps', String(params.slippageBps ?? 100));
  if (SOL_TREASURY_ADDRESS) url.searchParams.set('platformFeeBps', String(SOL_WALLET_FEE_BPS));

  const res = await fetchJupiter(url.toString());
  if (!res.ok) throw new Error('Could not get a Solana swap quote.');
  const quote = await res.json();
  const inputUnits = Number(quote?.inAmount);
  const outputUnits = Number(quote?.outAmount);
  const minimumOutputUnits = Number(quote?.otherAmountThreshold ?? quote?.outAmount);
  if (!Number.isFinite(inputUnits) || inputUnits <= 0 || !Number.isFinite(outputUnits) || outputUnits <= 0 || !Number.isFinite(minimumOutputUnits) || minimumOutputUnits <= 0) {
    throw new Error('Jupiter returned an invalid or unavailable Solana route.');
  }

  const destAmount = outputUnits / 10 ** params.toAsset.decimals;
  const destAmountMin = minimumOutputUnits / 10 ** params.toAsset.decimals;
  const routeNames: string[] = Array.from(new Set<string>(
    (quote.routePlan ?? [])
      .map((r: any) => r.swapInfo?.label)
      .filter((l: unknown): l is string => typeof l === 'string')
  ));
  // Jupiter's platform fee comes out of the OUTPUT (destAsset), unlike the
  // EVM path's fee-from-source display - shown correctly in SwapPanel by
  // labeling this with toAsset.symbol for Solana quotes specifically.
  const feeAmount = SOL_TREASURY_ADDRESS ? destAmount * (SOL_WALLET_FEE_BPS / 10000) : 0;

  return {
    priceRoute: quote,
    srcAmountUnits: String(inputUnits),
    destAmountUnits: String(outputUnits),
    destAmountFormatted: destAmount.toString(),
    destAmountMinFormatted: destAmountMin.toString(),
    rate: destAmount / Number(params.amount),
    feeBps: SOL_TREASURY_ADDRESS ? SOL_WALLET_FEE_BPS : 0,
    feeAmountFormatted: feeAmount.toString(),
    feeAddress: SOL_TREASURY_ADDRESS || null,
    tokenTransferProxy: '',
    gasCostEstimate: null,
    routeNames,
    _jupiterRaw: quote,
  };
}

function instructionFromJson(ix: any) {
  return {
    programId: new PublicKey(ix.programId),
    keys: ix.accounts.map((a: any) => ({
      pubkey: new PublicKey(a.pubkey),
      isSigner: a.isSigner,
      isWritable: a.isWritable,
    })),
    data: Buffer.from(ix.data, 'base64'),
  };
}

export async function executeSolanaSwap(params: {
  mnemonic: string;
  quote: SolanaSwapQuote;
  toAsset: AssetConfig;
}): Promise<{ swapHash: string; explorerUrl?: string; status: 'confirmed' }> {
  const network = NETWORKS[params.toAsset.network];
  if (!network?.rpcUrl) throw new Error('Solana RPC is not configured.');

  const connection = new Connection(network.rpcUrl, 'confirmed');
  const keypair = deriveSolanaKeypair(params.mnemonic);

  const feeAccountBody: Record<string, unknown> = {};
  if (SOL_TREASURY_ADDRESS) {
    const { getAssociatedTokenAddressSafe } = await import('./solanaSplSafe');
    const outputMint = new PublicKey(mintFor(params.toAsset));
    const feeAccount = getAssociatedTokenAddressSafe(outputMint, new PublicKey(SOL_TREASURY_ADDRESS));
    feeAccountBody.feeAccount = feeAccount.toBase58();
  }

  const res = await fetchJupiter(`${JUPITER_API_BASE}/swap-instructions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      quoteResponse: params.quote._jupiterRaw,
      userPublicKey: keypair.publicKey.toBase58(),
      wrapAndUnwrapSol: true,
      ...feeAccountBody,
    }),
  });
  if (!res.ok) throw new Error('Could not build the Solana swap transaction.');
  const data = await res.json();

  const instructions = [
    ...(data.computeBudgetInstructions ?? []).map(instructionFromJson),
    ...(data.setupInstructions ?? []).map(instructionFromJson),
    instructionFromJson(data.swapInstruction),
    ...(data.cleanupInstruction ? [instructionFromJson(data.cleanupInstruction)] : []),
  ];

  const lookupTableAccounts: AddressLookupTableAccount[] = [];
  for (const address of data.addressLookupTableAddresses ?? []) {
    const account = await connection.getAddressLookupTable(new PublicKey(address));
    if (account.value) lookupTableAccounts.push(account.value);
  }

  const { blockhash } = await connection.getLatestBlockhash('confirmed');
  const message = new TransactionMessage({
    payerKey: keypair.publicKey,
    recentBlockhash: blockhash,
    instructions,
  }).compileToV0Message(lookupTableAccounts);

  const tx = new VersionedTransaction(message);
  tx.sign([keypair]);

  const signature = await connection.sendTransaction(tx, { skipPreflight: false, maxRetries: 3 });
  await connection.confirmTransaction(signature, 'confirmed');

  return { swapHash: signature, explorerUrl: network.explorerTx?.(signature), status: 'confirmed' as const };
}
