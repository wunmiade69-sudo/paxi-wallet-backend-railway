import { useEffect, useState } from 'react';
import { ArrowLeft, PlusCircle, Search, Loader2, Coins, BadgeCheck, AlertTriangle, ImagePlus } from 'lucide-react';
import { toast } from 'sonner';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { NETWORKS, addCustomNetwork } from '@/lib/wallet/chains';
import { addCustomToken, lookupTokenMetadata, type TokenMetadataLookup } from '@/lib/wallet/customTokens';
import NetworkPickerDrawer from '@/components/NetworkPickerDrawer';
import { trpc } from '@/lib/trpc';
import { describeUserFacingError } from '@/lib/userFacingError';
import { isOfficialPaxiToken, PAXI_LOGO_URL } from '@/lib/appInfo';

interface AddTokenScreenProps {
  onBack: () => void;
  onAdded: () => void;
  initialNetworkId?: string;
  initialContractAddress?: string;
}

function getImportableNetworkIds() {
  return Object.values(NETWORKS)
    .filter((n) => n.chainType === 'evm' || n.chainType === 'sol')
    .map((n) => n.id);
}

export default function AddTokenScreen({ onBack, onAdded, initialNetworkId, initialContractAddress }: AddTokenScreenProps) {
  const [evmNetworkIds, setEvmNetworkIds] = useState(getImportableNetworkIds);
  const [networkId, setNetworkId] = useState(initialNetworkId ?? evmNetworkIds[0]);
  const [contractAddress, setContractAddress] = useState(initialContractAddress ?? '');
  const [customIconUrl, setCustomIconUrl] = useState('');
  const [preview, setPreview] = useState<TokenMetadataLookup | null>(null);
  const [isLooking, setIsLooking] = useState(false);
  const [error, setError] = useState('');

  const [showAddNetwork, setShowAddNetwork] = useState(false);
  const [netLabel, setNetLabel] = useState('');
  const [netRpcUrl, setNetRpcUrl] = useState('');
  const [netChainId, setNetChainId] = useState('');
  const [netSymbol, setNetSymbol] = useState('');
  const [netError, setNetError] = useState('');

  const network = NETWORKS[networkId];

  // Once a token's on-chain metadata is confirmed, check if Paxi already has a
  // logo/verified badge for it (seeded, created here, or a paid listing) - so
  // people don't have to hunt down a logo URL themselves for known tokens.
  const { data: paxiListing } = trpc.listings.getByToken.useQuery(
    { network: networkId, contractAddress },
    { enabled: Boolean(preview && contractAddress) },
  );
  const isOfficialPaxi = isOfficialPaxiToken({
    network: networkId,
    contractAddress,
    symbol: preview?.symbol,
  });
  const paxiLogoUrl = isOfficialPaxi
    ? PAXI_LOGO_URL
    : paxiListing?.status === 'verified'
      ? paxiListing.logoUrl || (paxiListing.logoKey ? `/manus-storage/${paxiListing.logoKey}` : undefined)
      : undefined;
  // Exact official identity wins over provider metadata and user-entered
  // fallback URLs, so every wallet sees the same PAXI mark after import.
  const effectiveIconUrl = isOfficialPaxi ? PAXI_LOGO_URL : customIconUrl.trim() || paxiLogoUrl || preview?.logoUrl;

  const handleAddNetwork = () => {
    setNetError('');
    if (!netLabel.trim() || !netRpcUrl.trim() || !netChainId.trim() || !netSymbol.trim()) {
      setNetError('Complete every field: name, network URL, chain ID, and native currency symbol.');
      return;
    }
    const chainIdNum = Number(netChainId);
    if (!Number.isInteger(chainIdNum) || chainIdNum <= 0) {
      setNetError('Chain ID should be a whole number, like 137 for Polygon.');
      return;
    }
    try {
      new URL(netRpcUrl.trim());
    } catch {
      setNetError('Enter a valid network URL starting with https://.');
      return;
    }
    const id = `custom-${chainIdNum}`;
    try {
      addCustomNetwork({
        id,
        label: netLabel.trim(),
        chainType: 'evm',
        chainId: chainIdNum,
        rpcUrl: netRpcUrl.trim(),
        nativeSymbol: netSymbol.trim().toUpperCase(),
      });
      toast.success(`${netLabel.trim()} added - you can now import tokens on it`);
      setEvmNetworkIds(getImportableNetworkIds());
      setNetworkId(id);
      setShowAddNetwork(false);
      setNetLabel('');
      setNetRpcUrl('');
      setNetChainId('');
      setNetSymbol('');
    } catch (err) {
      setNetError(describeUserFacingError(err, 'Could not add this network. Please check the details and try again.'));
    }
  };

  const handleLookup = async () => {
    setError('');
    setPreview(null);
    if (!network.rpcUrl) {
      setError(`${network.label} is not available for token lookup right now. Try again later or choose another network.`);
      return;
    }
    setIsLooking(true);
    try {
      const meta = await lookupTokenMetadata(networkId, contractAddress);
      setPreview(meta);
    } catch (err) {
      setError(describeUserFacingError(err, 'Could not read this token. Check the contract address and try again.'));
    } finally {
      setIsLooking(false);
    }
  };

  // Arrived here from "Add to Wallet" on a Token Detail page with the network/address already
  // known - skip straight to looking it up instead of making the person tap "Look Up" again.
  useEffect(() => {
    if (initialNetworkId && initialContractAddress) {
      handleLookup();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAdd = () => {
    if (!preview) return;
    try {
      addCustomToken({
        symbol: preview.symbol,
        name: preview.name,
        contractAddress,
        network: networkId,
        decimals: preview.decimals,
        addedAt: Date.now(),
        iconUrl: effectiveIconUrl,
        fieldSources: {
          ...preview.fieldSources,
          ...(effectiveIconUrl && customIconUrl.trim() ? { logo: ['user-entered'] } : {}),
          ...(effectiveIconUrl && !customIconUrl.trim() && paxiLogoUrl ? { logo: ['paxi-listing'] } : {}),
          ...(effectiveIconUrl && !customIconUrl.trim() && !paxiLogoUrl && preview.logoUrl ? { logo: preview.fieldSources.logo ?? ['provider'] } : {}),
        },
      });
      toast.success(`${preview.symbol} added to your wallet`);
      onAdded();
    } catch (err) {
      setError(describeUserFacingError(err, 'Could not add this token. Please try again.'));
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-lg font-semibold text-foreground">Add Token</h1>
        <div className="w-12" />
      </div>

      <div className="flex-1 max-w-md mx-auto w-full space-y-4">
        <p className="text-sm text-muted-foreground">
          Paste a token's contract address and we'll read its name, symbol, and decimals directly from the
          chain - the same trust-minimized flow used by MetaMask's "Import Token."
        </p>

        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Network</label>
          <NetworkPickerDrawer
            label="Choose a network"
            networks={evmNetworkIds.map((id) => NETWORKS[id])}
            selected={network}
            onSelect={(id) => {
              setNetworkId(id);
              setPreview(null);
              setError('');
            }}
            onFooterInteract={() => setShowAddNetwork(true)}
            footer={
              <button
                type="button"
                className="w-full flex min-h-11 items-center justify-center gap-1.5 text-sm font-medium text-accent transition-colors hover:text-accent/80"
              >
                <PlusCircle className="h-4 w-4" aria-hidden="true" />
                Add a custom network
              </button>
            }
          />
        </div>

        <div className="glass-card space-y-2">
          <label className="text-sm font-medium text-foreground flex items-center gap-1.5">
            <Coins className="w-4 h-4 text-muted-foreground" />
            {network.chainType === 'sol' ? 'Token Mint Address' : 'Token Contract Address'}
          </label>
          <input
            type="text"
            value={contractAddress}
            onChange={(e) => {
              setContractAddress(e.target.value);
              setPreview(null);
              setError('');
            }}
            placeholder={network.chainType === 'sol' ? 'e.g. EPjFWdd5AufqSSqeM2q...' : '0x...'}
            className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground font-mono text-sm focus:outline-none focus:border-accent/60"
          />
        </div>

        {error && (
          <div className="flex items-start gap-2.5 bg-destructive/10 border border-destructive/30 rounded-lg p-3">
            <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {preview && (
          <div className="glass-card space-y-2 animate-in fade-in zoom-in-95 duration-300">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-accent">Token found</p>
            <div className="flex items-center gap-3 pb-1">
              <span className="w-11 h-11 rounded-full bg-accent/10 ring-1 ring-accent/25 flex items-center justify-center font-bold text-accent shrink-0 overflow-hidden">
                {effectiveIconUrl ? (
                  <img src={effectiveIconUrl} alt="" className="w-full h-full object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} />
                ) : (
                  preview.symbol.charAt(0)
                )}
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-foreground text-sm truncate flex items-center gap-1">
                  {preview.symbol}
                  {(isOfficialPaxi || paxiListing?.status === 'verified') && (
                    <BadgeCheck className="w-3.5 h-3.5 text-accent shrink-0" aria-label="Verified on Paxi" />
                  )}
                </p>
                <p className="text-xs text-muted-foreground truncate">{preview.name}</p>
              </div>
            </div>
            <div className="flex justify-between text-sm border-t border-white/5 pt-2">
              <span className="text-muted-foreground">Decimals</span>
              <span className="text-foreground">{preview.decimals}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Network</span>
              <span className="text-foreground">{network.label}</span>
            </div>
            <div className="border-t border-white/5 pt-2 space-y-1.5">
              <label className="text-xs text-muted-foreground flex items-center gap-1.5">
                <ImagePlus className="w-3.5 h-3.5" />
                {paxiLogoUrl ? 'Logo URL (override the verified Paxi logo, optional)' : 'Logo URL (optional)'}
              </label>
              <input
                type="text"
                value={customIconUrl}
                onChange={(e) => setCustomIconUrl(e.target.value)}
                placeholder={paxiLogoUrl ? 'Using verified Paxi logo automatically' : 'https://yoursite.com/logo.png'}
                className="w-full bg-secondary border border-border rounded-lg p-2.5 text-foreground placeholder:text-muted-foreground font-mono text-xs focus:outline-none focus:border-accent/60"
              />
              <p className="text-[11px] text-muted-foreground">
                {isOfficialPaxi
                  ? 'Official PAXI identity recognized. The global PAXI logo will be used automatically.'
                  : paxiLogoUrl
                    ? 'This token is verified on Paxi, so its logo loaded automatically.'
                  : 'Host this yourself - no listing, review, or fee required anywhere.'}
              </p>
            </div>
          </div>
        )}

        {!preview ? (
          <button
            onClick={handleLookup}
            disabled={!contractAddress || isLooking}
            className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
          >
            {isLooking ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Looking up token…
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                Look Up Token
              </>
            )}
          </button>
        ) : (
          <button
            onClick={handleAdd}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-[0.98]"
          >
            Add {preview.symbol} to Wallet
          </button>
        )}
      </div>

      <Drawer open={showAddNetwork} onOpenChange={setShowAddNetwork}>
        <DrawerContent>
          <DrawerHeader className="text-left">
            <DrawerTitle>Add a custom network</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6 space-y-3.5 max-w-md mx-auto w-full">
            <p className="text-xs text-muted-foreground">
              Add any EVM-compatible mainnet by its RPC details - useful for a chain we don't ship by
              default, or to catch a token that only exists there.
            </p>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground px-0.5">Network name</label>
              <input
                type="text"
                value={netLabel}
                onChange={(e) => setNetLabel(e.target.value)}
                placeholder="e.g. Polygon"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground px-0.5">RPC URL</label>
              <input
                type="text"
                value={netRpcUrl}
                onChange={(e) => setNetRpcUrl(e.target.value)}
                placeholder="https://..."
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground font-mono text-sm focus:outline-none focus:border-accent/60"
              />
            </div>
            <div className="flex gap-3">
              <div className="flex-1 space-y-1">
                <label className="text-xs font-medium text-muted-foreground px-0.5">Chain ID</label>
                <input
                  type="text"
                  inputMode="numeric"
                  value={netChainId}
                  onChange={(e) => setNetChainId(e.target.value)}
                  placeholder="e.g. 137"
                  className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
                />
              </div>
              <div className="flex-1 space-y-1">
                <label className="text-xs font-medium text-muted-foreground px-0.5">Native symbol</label>
                <input
                  type="text"
                  value={netSymbol}
                  onChange={(e) => setNetSymbol(e.target.value)}
                  placeholder="e.g. MATIC"
                  className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
                />
              </div>
            </div>
            {netError && (
              <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-lg p-2.5">
                <AlertTriangle className="w-3.5 h-3.5 text-destructive shrink-0 mt-0.5" />
                <p className="text-xs text-destructive">{netError}</p>
              </div>
            )}
            <button
              onClick={handleAddNetwork}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-2.5 rounded-lg transition-all active:scale-[0.98] text-sm"
            >
              Add Network
            </button>
          </div>
        </DrawerContent>
      </Drawer>
    </div>
  );
}
