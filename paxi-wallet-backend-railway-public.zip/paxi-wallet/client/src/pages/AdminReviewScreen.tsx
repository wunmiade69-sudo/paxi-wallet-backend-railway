import { useEffect, useState } from 'react';
import { ArrowLeft, Check, X, Twitter, Send as TelegramIcon, Globe } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { describeUserFacingError } from '@/lib/userFacingError';

export type AdminReviewTab = 'listings' | 'campaign-review' | 'operations' | 'campaigns';

interface AdminReviewScreenProps {
  onBack: () => void;
  initialTab?: AdminReviewTab;
}

export default function AdminReviewScreen({ onBack, initialTab = 'listings' }: AdminReviewScreenProps) {
  const [tab, setTab] = useState<AdminReviewTab>(initialTab);
  useEffect(() => setTab(initialTab), [initialTab]);

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Admin Review</h1>
        </div>
        <div className="max-w-md mx-auto px-6 pb-3 flex gap-2">
          <TabButton active={tab === 'listings'} onClick={() => setTab('listings')} label="Pending Listings" />
          <TabButton active={tab === 'campaign-review'} onClick={() => setTab('campaign-review')} label="Campaign Review" />
          <TabButton active={tab === 'operations'} onClick={() => setTab('operations')} label="Operations" />
          <TabButton active={tab === 'campaigns'} onClick={() => setTab('campaigns')} label="Campaign Payouts" />
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6">
        {tab === 'listings' ? <PendingListings /> : tab === 'campaign-review' ? <PendingCampaignReviews /> : tab === 'operations' ? <CampaignOperations /> : <CampaignPayouts />}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
        active ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'
      }`}
    >
      {label}
    </button>
  );
}

function PendingListings() {
  const utils = trpc.useUtils();
  const { data: pending, isLoading } = trpc.listings.adminListPending.useQuery();
  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const review = trpc.listings.adminReview.useMutation({
    onSuccess: () => {
      utils.listings.adminListPending.invalidate();
      setRejectingId(null);
      setRejectionReason('');
    },
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t update this request. Please try again.')),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!pending || pending.length === 0) {
    return <p className="text-sm text-muted-foreground">No listings waiting for review.</p>;
  }

  return (
    <div className="space-y-4">
      {pending.map((listing) => (
        <div key={listing.id} className="glass-card p-4 space-y-3">
          <div className="flex items-center gap-3">
            {listing.logoKey && (
              <img
                src={`/manus-storage/${listing.logoKey}`}
                alt={listing.symbol}
                className="w-10 h-10 rounded-full object-cover"
              />
            )}
            <div>
              <p className="text-sm font-semibold text-foreground">
                {listing.name} ({listing.symbol})
              </p>
              <p className="text-xs text-muted-foreground font-mono break-all">{listing.contractAddress}</p>
              <p className="text-xs text-muted-foreground">{listing.network}</p>
            </div>
          </div>

          {listing.plan && <p className="text-xs text-foreground/80">{listing.plan}</p>}

          {listing.socials && (
            <div className="flex gap-3 text-muted-foreground">
              {listing.socials.twitter && <Twitter className="w-4 h-4" />}
              {listing.socials.telegram && <TelegramIcon className="w-4 h-4" />}
              {listing.socials.website && <Globe className="w-4 h-4" />}
            </div>
          )}

          <p className="text-xs text-muted-foreground">
            Fee tx: <span className="font-mono break-all">{listing.feeTxHash}</span> (${listing.feeAmountUsd} verified)
          </p>

          {rejectingId === listing.id ? (
            <div className="space-y-2">
              <input
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Reason for rejection..."
                className="w-full bg-secondary border border-border rounded-lg py-2 px-3 text-sm text-foreground outline-none focus:border-accent/50"
              />
              <div className="flex gap-2">
                <button
                  onClick={() =>
                    review.mutate({ id: listing.id, decision: 'rejected', rejectionReason: rejectionReason.trim() || undefined })
                  }
                  className="flex-1 bg-destructive/90 hover:bg-destructive text-white text-xs font-semibold py-2 rounded-lg"
                >
                  Confirm Reject
                </button>
                <button
                  onClick={() => setRejectingId(null)}
                  className="flex-1 bg-secondary text-muted-foreground text-xs font-semibold py-2 rounded-lg"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={() => review.mutate({ id: listing.id, decision: 'verified' })}
                className="flex-1 flex items-center justify-center gap-1.5 bg-accent hover:bg-accent/90 text-accent-foreground text-xs font-semibold py-2 rounded-lg"
              >
                <Check className="w-3.5 h-3.5" /> Approve
              </button>
              <button
                onClick={() => setRejectingId(listing.id)}
                className="flex-1 flex items-center justify-center gap-1.5 bg-secondary text-muted-foreground text-xs font-semibold py-2 rounded-lg"
              >
                <X className="w-3.5 h-3.5" /> Reject
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function PendingCampaignReviews() {
  const utils = trpc.useUtils();
  const { data: pending, isLoading } = trpc.campaigns.adminListPendingReview.useQuery();
  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const review = trpc.campaigns.adminReview.useMutation({
    onSuccess: () => {
      utils.campaigns.adminListPendingReview.invalidate();
      utils.campaigns.listActive.invalidate();
      setRejectingId(null);
      setRejectionReason('');
    },
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t update this request. Please try again.')),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading campaign review queue…</p>;
  if (!pending || pending.length === 0) return <p className="text-sm text-muted-foreground">No funded campaigns are waiting for review.</p>;

  return (
    <div className="space-y-4">
      {pending.map((campaign) => (
        <article key={campaign.id} className="glass-card overflow-hidden !p-0">
          {campaign.bannerKey && <img src={`/manus-storage/${campaign.bannerKey}`} alt="Campaign banner awaiting review" className="h-32 w-full object-cover" />}
          <div className="space-y-3 p-4">
            <div className="flex items-start gap-3">
              {campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-10 w-10 rounded-xl object-cover" />}
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{campaign.title}</p><p className="text-xs text-muted-foreground">{campaign.taskTokenSymbol} · ${campaign.poolRequiredAmountUsd} pool verified</p></div>
            </div>
            {campaign.description && <p className="text-xs text-foreground/80">{campaign.description}</p>}
            <div className="grid grid-cols-2 gap-2 text-xs"><p className="rounded-lg bg-secondary p-2 text-muted-foreground">Reward: <span className="font-semibold text-foreground">{campaign.rewardAmount} {campaign.rewardTokenSymbol}</span></p><p className="rounded-lg bg-secondary p-2 text-muted-foreground">Winners: <span className="font-semibold text-foreground">{campaign.maxWinners}</span></p></div>
            {campaign.website && <p className="break-all text-xs text-accent">{campaign.website}</p>}

            {rejectingId === campaign.id ? (
              <div className="space-y-2"><input value={rejectionReason} onChange={(event) => setRejectionReason(event.target.value)} placeholder="Reason for rejection…" className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm text-foreground outline-none focus:border-accent/50" /><div className="flex gap-2"><button onClick={() => review.mutate({ campaignId: campaign.id, decision: 'rejected', rejectionReason: rejectionReason.trim() || undefined })} className="flex-1 rounded-lg bg-destructive py-2 text-xs font-semibold text-white">Confirm reject</button><button onClick={() => setRejectingId(null)} className="flex-1 rounded-lg bg-secondary py-2 text-xs font-semibold text-muted-foreground">Cancel</button></div></div>
            ) : (
              <div className="flex gap-2"><button onClick={() => review.mutate({ campaignId: campaign.id, decision: 'active' })} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-accent py-2 text-xs font-semibold text-accent-foreground"><Check className="h-3.5 w-3.5" />Approve & publish</button><button onClick={() => setRejectingId(campaign.id)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-secondary py-2 text-xs font-semibold text-muted-foreground"><X className="h-3.5 w-3.5" />Reject</button></div>
            )}
          </div>
        </article>
      ))}
    </div>
  );
}

function CampaignPayouts() {
  const { data: activeCampaigns, isLoading } = trpc.campaigns.listActive.useQuery();
  const [selectedCampaignId, setSelectedCampaignId] = useState<number | null>(null);

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (!activeCampaigns || activeCampaigns.length === 0) {
    return <p className="text-sm text-muted-foreground">No active campaigns.</p>;
  }

  if (selectedCampaignId) {
    return <CampaignEntryList campaignId={selectedCampaignId} onBack={() => setSelectedCampaignId(null)} />;
  }

  return (
    <div className="space-y-3">
      {activeCampaigns.map((c) => (
        <button
          key={c.id}
          onClick={() => setSelectedCampaignId(c.id)}
          className="w-full text-left glass-card p-4 flex items-center justify-between"
        >
          <div>
            <p className="text-sm font-semibold text-foreground">{c.title}</p>
            <p className="text-xs text-muted-foreground">
              {c.winnersCount}/{c.maxWinners} slots claimed
            </p>
          </div>
          <span className="text-xs text-accent font-medium">View →</span>
        </button>
      ))}
    </div>
  );
}

function CampaignOperations() {
  const utils = trpc.useUtils();
  const { data: campaigns, isLoading } = trpc.campaigns.adminListOperational.useQuery();
  const update = trpc.campaigns.adminSetOperations.useMutation({
    onSuccess: () => {
      utils.campaigns.adminListOperational.invalidate();
      utils.campaigns.featured.invalidate();
      utils.campaigns.listActive.invalidate();
      toast.success('Campaign operation updated.');
    },
    onError: (error) => toast.error(describeUserFacingError(error, 'We couldn’t update this campaign. Please try again.')),
  });
  if (isLoading) return <p className="text-sm text-muted-foreground">Loading operational campaigns…</p>;
  if (!campaigns || campaigns.length === 0) return <p className="text-sm text-muted-foreground">No active or suspended campaigns.</p>;
  return <div className="space-y-3">{campaigns.map((campaign) => <article key={campaign.id} className="glass-card space-y-3 p-4"><div className="flex items-start gap-3">{campaign.iconKey && <img src={`/manus-storage/${campaign.iconKey}`} alt="" className="h-9 w-9 rounded-xl object-cover" />}<div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{campaign.title}</p><p className="text-xs text-muted-foreground">{campaign.status} · {campaign.winnersCount}/{campaign.maxWinners} slots</p></div></div><div className="grid grid-cols-2 gap-2"><button onClick={() => update.mutate({ campaignId: campaign.id, isFeatured: !campaign.isFeatured })} className={`rounded-lg py-2 text-xs font-semibold ${campaign.isFeatured ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'}`}>{campaign.isFeatured ? 'Featured on home' : 'Feature on home'}</button><button onClick={() => update.mutate({ campaignId: campaign.id, claimsPaused: !campaign.claimsPaused })} className={`rounded-lg py-2 text-xs font-semibold ${campaign.claimsPaused ? 'bg-amber-400/20 text-amber-200' : 'bg-secondary text-muted-foreground'}`}>{campaign.claimsPaused ? 'Resume claims' : 'Pause claims'}</button><button onClick={() => update.mutate({ campaignId: campaign.id, suspended: campaign.status !== 'suspended' })} className="rounded-lg bg-secondary py-2 text-xs font-semibold text-muted-foreground">{campaign.status === 'suspended' ? 'Resume campaign' : 'Suspend campaign'}</button></div></article>)}</div>;
}

function CampaignEntryList({ campaignId, onBack }: { campaignId: number; onBack: () => void }) {
  const utils = trpc.useUtils();
  const { data: entries, isLoading } = trpc.campaigns.adminListEntries.useQuery({ campaignId });
  const [payoutTxHash, setPayoutTxHash] = useState<Record<number, string>>({});

  const markPayout = trpc.campaigns.markPayout.useMutation({
    onSuccess: () => utils.campaigns.adminListEntries.invalidate({ campaignId }),
    onError: (err) => toast.error(describeUserFacingError(err, 'We couldn’t update this request. Please try again.')),
  });

  return (
    <div className="space-y-3">
      <button onClick={onBack} className="text-xs text-accent font-medium">
        ← Back to campaigns
      </button>
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : !entries || entries.length === 0 ? (
        <p className="text-sm text-muted-foreground">No entries yet.</p>
      ) : (
        entries
          .filter((e) => e.slotNumber != null)
          .sort((a, b) => (a.slotNumber ?? 0) - (b.slotNumber ?? 0))
          .map((entry) => (
            <div key={entry.id} className="glass-card p-4 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-foreground">Winner #{entry.slotNumber}</p>
                <span
                  className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                    entry.payoutStatus === 'paid' ? 'bg-accent/20 text-accent' : 'bg-secondary text-muted-foreground'
                  }`}
                >
                  {entry.payoutStatus}
                </span>
              </div>
              <p className="text-xs text-muted-foreground font-mono break-all">proof: {entry.proofTxHash}</p>
              {entry.payoutStatus === 'claimable' && (
                <div className="flex gap-2">
                  <input
                    value={payoutTxHash[entry.id] ?? ''}
                    onChange={(e) => setPayoutTxHash((s) => ({ ...s, [entry.id]: e.target.value }))}
                    placeholder="Payout tx hash after sending reward"
                    className="flex-1 bg-secondary border border-border rounded-lg py-2 px-3 text-xs text-foreground outline-none focus:border-accent/50"
                  />
                  <button
                    onClick={() =>
                      markPayout.mutate({ entryId: entry.id, payoutTxHash: (payoutTxHash[entry.id] ?? '').trim() })
                    }
                    disabled={!payoutTxHash[entry.id]?.trim()}
                    className="bg-accent hover:bg-accent/90 disabled:opacity-40 text-accent-foreground text-xs font-semibold px-3 rounded-lg"
                  >
                    Mark Paid
                  </button>
                </div>
              )}
            </div>
          ))
      )}
    </div>
  );
}
