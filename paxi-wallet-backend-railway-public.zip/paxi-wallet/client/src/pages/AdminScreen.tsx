import { useState } from "react";
import { AlertTriangle, ArrowLeft, CheckCircle2, Database, Flag, FileClock, Gauge, Megaphone, Network, RefreshCw, ShieldCheck, Users, WalletCards } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { describeUserFacingError } from "@/lib/userFacingError";

type Section = "overview" | "users" | "assets" | "providers" | "transactions" | "security" | "campaigns" | "approvals" | "announcements" | "audit";

const sections: Array<{ id: Section; label: string; icon: typeof Gauge }> = [
  { id: "overview", label: "Overview", icon: Gauge },
  { id: "users", label: "Users", icon: Users },
  { id: "assets", label: "Assets", icon: WalletCards },
  { id: "providers", label: "Providers", icon: Network },
  { id: "transactions", label: "Transactions", icon: FileClock },
  { id: "security", label: "Security", icon: ShieldCheck },
  { id: "campaigns", label: "Campaigns", icon: Flag },
  { id: "approvals", label: "Approvals", icon: CheckCircle2 },
  { id: "announcements", label: "Announcements", icon: Megaphone },
  { id: "audit", label: "Audit log", icon: FileClock },
];

function StatusPill({ value }: { value: string }) {
  const positive = value === "connected" || value === "healthy" || value === "disabled";
  return <span className={`paxi-status min-h-6 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide ${positive ? "bg-emerald-500/15 text-emerald-300" : "bg-amber-500/15 text-amber-200"}`}>{value}</span>;
}

export default function AdminScreen({ onBack }: { onBack: () => void }) {
  const [section, setSection] = useState<Section>("overview");
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementMessage, setAnnouncementMessage] = useState("");
  const [announcementReason, setAnnouncementReason] = useState("");
  const me = trpc.admin.me.useQuery();
  const allowed = Boolean(me.data);
  const dashboard = trpc.admin.dashboard.useQuery(undefined, { enabled: allowed });
  const providers = trpc.admin.providers.status.useQuery(undefined, { enabled: allowed && section === "providers" });
  const users = trpc.admin.users.list.useQuery({ limit: 50 }, { enabled: allowed && section === "users" });
  const assets = trpc.admin.assets.list.useQuery({ limit: 50 }, { enabled: allowed && section === "assets" });
  const transactions = trpc.admin.transactions.list.useQuery({ limit: 50 }, { enabled: allowed && section === "transactions" });
  const security = trpc.admin.security.reports.useQuery({ limit: 50 }, { enabled: allowed && section === "security" });
  const campaigns = trpc.admin.campaigns.overview.useQuery(undefined, { enabled: allowed && section === "campaigns" });
  const approvals = trpc.admin.approvals.list.useQuery({ limit: 50 }, { enabled: allowed && section === "approvals" });
  const announcements = trpc.admin.announcements.list.useQuery({ limit: 50 }, { enabled: allowed && section === "announcements" });
  const audit = trpc.admin.auditEvents.useQuery({ limit: 100 }, { enabled: allowed && section === "audit" });
  const canDecide = Boolean(me.data?.permissions.includes("approvals.decide"));
  const canExecute = Boolean(me.data?.permissions.includes("approvals.execute"));
  const canManageUsers = Boolean(me.data?.permissions.includes("users.manage"));
  const canManageAssets = Boolean(me.data?.permissions.includes("assets.manage"));
  const canVerifyAssets = Boolean(me.data?.permissions.includes("assets.verify"));
  const createAnnouncement = trpc.admin.announcements.create.useMutation({
    onSuccess: () => {
      toast.success("Announcement saved as draft");
      setAnnouncementTitle("");
      setAnnouncementMessage("");
      setAnnouncementReason("");
      void announcements.refetch();
    },
    onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")),
  });
  const decideApproval = trpc.admin.approvals.decide.useMutation({
    onSuccess: () => { toast.success("Approval decision recorded"); void approvals.refetch(); },
    onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")),
  });
  const executeApproval = trpc.admin.approvals.execute.useMutation({
    onSuccess: () => { toast.success("Approved change executed"); void approvals.refetch(); void users.refetch(); void assets.refetch(); },
    onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")),
  });
  const publishAnnouncement = trpc.admin.announcements.publish.useMutation({
    onSuccess: () => { toast.success("Announcement published"); void announcements.refetch(); },
    onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")),
  });
  const archiveAnnouncement = trpc.admin.announcements.archive.useMutation({
    onSuccess: () => { toast.success("Announcement archived"); void announcements.refetch(); },
    onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")),
  });
  const requestSuspension = trpc.admin.users.requestSuspension.useMutation({ onSuccess: () => { toast.success("Suspension request created"); void users.refetch(); void approvals.refetch(); }, onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")) });
  const requestRestore = trpc.admin.users.requestRestore.useMutation({ onSuccess: () => { toast.success("Restore request created"); void users.refetch(); void approvals.refetch(); }, onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")) });
  const requestAssetStatus = trpc.admin.assets.requestStatusChange.useMutation({ onSuccess: () => { toast.success("Asset status request created"); void assets.refetch(); void approvals.refetch(); }, onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")) });
  const requestAssetVerification = trpc.admin.assets.requestVerificationChange.useMutation({ onSuccess: () => { toast.success("Verification request created"); void assets.refetch(); void approvals.refetch(); }, onError: (error) => toast.error(describeUserFacingError(error, "Something went wrong. Please try again.")) });

  const promptReason = (label: string) => {
    const reason = window.prompt(`${label} reason (minimum 10 characters)`)?.trim() ?? "";
    return reason.length >= 10 ? reason : null;
  };

  if (me.isLoading) {
    return <div className="flex min-h-screen items-center justify-center bg-background px-6 text-center text-foreground" role="status">Checking administrative access…</div>;
  }
  if (!allowed) {
    return <div className="flex min-h-screen items-center justify-center bg-background px-6 text-foreground"><div className="glass-card max-w-md space-y-3 p-6 text-center"><AlertTriangle className="mx-auto text-amber-300" aria-hidden="true" /><h1 className="text-xl font-bold">Admin access unavailable</h1><p className="text-sm text-muted-foreground">This workspace is protected by server-side authorization. Your normal wallet access is unchanged.</p><button type="button" onClick={onBack} className="paxi-pressable min-h-11 rounded-xl bg-accent px-4 py-2 text-sm font-semibold text-background">Return</button></div></div>;
  }

  const countEntries = dashboard.data?.counts ? Object.entries(dashboard.data.counts) : [];
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="paxi-page-header sticky top-0 z-40">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-5 py-4">
          <button type="button" onClick={onBack} className="paxi-icon-button flex items-center justify-center text-muted-foreground hover:bg-foreground/5" aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
          <div className="flex-1"><p className="text-xs uppercase tracking-[0.2em] text-accent">PAXI Operations</p><h1 className="text-xl font-bold">Admin Console</h1></div>
          <div className="text-right"><p className="text-xs text-muted-foreground">Role</p><p className="text-sm font-semibold">{me.data?.role?.replace("_", " ")}</p></div>
          <button type="button" onClick={() => void dashboard.refetch()} className="paxi-icon-button flex items-center justify-center text-muted-foreground hover:bg-foreground/5" aria-label="Refresh dashboard"><RefreshCw className="h-4 w-4" /></button>
        </div>
      </header>
      <div className="mx-auto grid max-w-6xl gap-5 px-5 py-5 lg:grid-cols-[220px_1fr]">
        <nav className="glass-card flex gap-1 overflow-x-auto p-2 lg:sticky lg:top-24 lg:block" aria-label="Admin sections">
          {sections.map(({ id, label, icon: Icon }) => <button key={id} type="button" onClick={() => setSection(id)} aria-current={section === id ? "page" : undefined} className={`paxi-pressable flex min-h-11 shrink-0 items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition lg:w-full ${section === id ? "bg-accent/15 text-accent" : "text-muted-foreground hover:bg-foreground/5 hover:text-foreground"}`}><Icon className="h-4 w-4" aria-hidden="true" />{label}</button>)}
        </nav>
        <main className="space-y-5">
          {section === "overview" && <>
            <div className="glass-card p-5"><div className="flex items-start gap-3"><Database className="mt-1 text-accent" /><div><h2 className="font-semibold">Operational overview</h2><p className="mt-1 text-sm text-muted-foreground">Counts come from saved wallet records. Service availability is shown only when it has been checked.</p></div></div></div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{countEntries.map(([key, value]) => <div className="glass-card p-4" key={key}><p className="text-xs capitalize text-muted-foreground">{key.replace(/([A-Z])/g, " $1")}</p><p className="mt-2 text-2xl font-bold">{value}</p></div>)}</div>
            <div className="glass-card grid gap-3 p-5 sm:grid-cols-3">{Object.entries(dashboard.data?.infrastructure ?? {}).map(([key, value]) => <div key={key}><p className="text-xs capitalize text-muted-foreground">{key}</p><div className="mt-2"><StatusPill value={String(value)} /></div></div>)}</div>
          </>}
          {section === "users" && <UserTable rows={users.data ?? []} canManage={canManageUsers} onSuspend={(id) => { const reason = promptReason("Suspension"); if (reason) requestSuspension.mutate({ userId: id, reason }); }} onRestore={(id) => { const reason = promptReason("Restore"); if (reason) requestRestore.mutate({ userId: id, reason }); }} />}
          {section === "assets" && <AssetTable rows={assets.data ?? []} canManage={canManageAssets} canVerify={canVerifyAssets} onStatus={(id, status) => { const reason = promptReason("Asset status change"); if (reason) requestAssetStatus.mutate({ assetId: id, status, reason }); }} onVerification={(id, verificationStatus) => { const reason = promptReason("Verification change"); if (reason) requestAssetVerification.mutate({ assetId: id, verificationStatus, reason }); }} />}
          {section === "providers" && <div className="glass-card p-5 space-y-3"><h2 className="font-semibold">Provider status</h2><p className="text-sm text-muted-foreground">A connected service is listed separately from its latest availability check. An unchecked service is not treated as available.</p>{providers.data?.providers.map((provider) => <div key={provider.id} className="flex items-center justify-between rounded-lg bg-secondary/50 p-3"><div><p className="font-medium">{provider.id}</p><p className="text-xs text-muted-foreground">{provider.note}</p></div><div className="flex gap-2"><StatusPill value={provider.configured ? "connected" : "not connected"} /><StatusPill value={provider.status} /></div></div>)}</div>}
          {section === "transactions" && <DataTable title="Indexed activity" rows={transactions.data ?? []} empty="No durable activity records available." columns={[["eventType", "Event"], ["chainId", "Chain"], ["transactionHash", "Transaction"], ["status", "Status"], ["createdAt", "Created"]]} />}
          {section === "security" && <DataTable title="Security reports" rows={security.data ?? []} empty="No security reports available; missing data remains unverified." columns={[["assetId", "Asset"], ["label", "Label"], ["score", "Score"], ["provider", "Provider"], ["checkedAt", "Checked"]]} />}
          {section === "campaigns" && <div className="glass-card p-5"><h2 className="font-semibold">Campaign operations</h2><p className="mt-1 text-sm text-muted-foreground">Existing campaign workflows remain protected in their feature routers. This summary does not create, approve, or broadcast payouts.</p><div className="mt-4 grid gap-3 sm:grid-cols-3"><Metric label="Campaigns" value={campaigns.data?.campaigns} /><Metric label="Entries" value={campaigns.data?.entries} /><Metric label="Claimable reviews" value={campaigns.data?.pendingReviews} /></div></div>}
          {section === "approvals" && <ApprovalTable rows={approvals.data ?? []} canDecide={canDecide} canExecute={canExecute} currentOpenId={me.data?.openId ?? ""} onDecide={(id, decision) => { const reason = promptReason(decision === "approved" ? "Approval" : "Rejection"); if (reason) decideApproval.mutate({ id, decision, reason }); }} onExecute={(id) => { const reason = promptReason("Execution"); if (reason) executeApproval.mutate({ id, reason }); }} />}
          {section === "audit" && <DataTable title="Immutable audit log" rows={audit.data ?? []} empty="No audit records available." columns={[["action", "Action"], ["resourceType", "Resource"], ["actorOpenId", "Actor"], ["actorRole", "Role"], ["result", "Result"], ["reason", "Reason"], ["createdAt", "Created"]]} />}
          {section === "announcements" && <div className="space-y-5"><div className="glass-card p-5 space-y-3"><h2 className="font-semibold">Create system announcement</h2><p className="text-sm text-muted-foreground">Announcements are durable drafts until explicitly published. Promotional messages are not enabled by this control.</p><input value={announcementTitle} onChange={(event) => setAnnouncementTitle(event.target.value)} aria-label="Announcement title" placeholder="Title" className="paxi-field w-full px-3 py-2 text-sm" /><textarea value={announcementMessage} onChange={(event) => setAnnouncementMessage(event.target.value)} aria-label="Announcement message" placeholder="Message" rows={4} className="paxi-field w-full px-3 py-2 text-sm" /><input value={announcementReason} onChange={(event) => setAnnouncementReason(event.target.value)} aria-label="Announcement audit reason" placeholder="Audit reason (at least 10 characters)" className="paxi-field w-full px-3 py-2 text-sm" /><button type="button" disabled={createAnnouncement.isPending || !announcementTitle || !announcementMessage || announcementReason.length < 10} onClick={() => createAnnouncement.mutate({ kind: "system", title: announcementTitle, message: announcementMessage, reason: announcementReason })} className="paxi-pressable min-h-11 rounded-xl bg-accent px-4 py-2 text-sm font-semibold text-background disabled:opacity-50">Save draft</button></div><AnnouncementTable rows={announcements.data ?? []} onPublish={(id) => { const reason = promptReason("Publish"); if (reason) publishAnnouncement.mutate({ id, reason }); }} onArchive={(id) => { const reason = promptReason("Archive"); if (reason) archiveAnnouncement.mutate({ id, reason }); }} /></div>}
        </main>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value?: number }) { return <div className="rounded-lg bg-secondary/50 p-3"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 text-xl font-bold">{value ?? "—"}</p></div>; }

function UserTable({ rows, canManage, onSuspend, onRestore }: { rows: Array<Record<string, any>>; canManage: boolean; onSuspend: (id: number) => void; onRestore: (id: number) => void }) {
  return <div className="glass-card overflow-hidden"><div className="border-b border-foreground/10 p-5"><h2 className="font-semibold">Users</h2><p className="mt-1 text-xs text-muted-foreground">Only safe account metadata is shown. Suspension and restoration create approval requests; wallet keys and signing material are never exposed.</p></div>{rows.length === 0 ? <p className="p-5 text-sm text-muted-foreground">No user records available.</p> : <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-foreground/10 text-muted-foreground"><th className="px-4 py-3">Name</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Role</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Actions</th></tr></thead><tbody>{rows.map((row) => { const id = Number(row.id); const suspended = Boolean(row.suspendedAt); return <tr key={id} className="border-b border-foreground/5 last:border-0"><td className="px-4 py-3">{formatCell(row.name)}</td><td className="px-4 py-3">{formatCell(row.email)}</td><td className="px-4 py-3">{formatCell(row.adminRole ?? row.role)}</td><td className="px-4 py-3"><StatusPill value={suspended ? "suspended" : "active"} /></td><td className="px-4 py-3">{canManage ? <button onClick={() => suspended ? onRestore(id) : onSuspend(id)} className="rounded-md bg-accent/15 px-2 py-1 font-semibold text-accent">{suspended ? "Request restore" : "Request suspend"}</button> : <span className="text-muted-foreground">Read only</span>}</td></tr>;})}</tbody></table></div>}</div>;
}

function AssetTable({ rows, canManage, canVerify, onStatus, onVerification }: { rows: Array<Record<string, any>>; canManage: boolean; canVerify: boolean; onStatus: (id: number, status: "active" | "blocked" | "spam") => void; onVerification: (id: number, verificationStatus: "unverified" | "registered" | "verified") => void }) {
  return <div className="glass-card overflow-hidden"><div className="border-b border-foreground/10 p-5"><h2 className="font-semibold">Assets</h2><p className="mt-1 text-xs text-muted-foreground">Canonical identity is chain plus contract/mint. Status and verification changes are approval-backed and audited.</p></div>{rows.length === 0 ? <p className="p-5 text-sm text-muted-foreground">No asset records available.</p> : <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-foreground/10 text-muted-foreground"><th className="px-4 py-3">Asset</th><th className="px-4 py-3">Chain / identity</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Verification</th><th className="px-4 py-3">Actions</th></tr></thead><tbody>{rows.map((row) => { const id = Number(row.id); const status = String(row.status ?? "active") as "active" | "blocked" | "spam"; const verificationStatus = String(row.verificationStatus ?? "unverified") as "unverified" | "registered" | "verified"; return <tr key={id} className="border-b border-foreground/5 last:border-0"><td className="px-4 py-3"><p className="font-medium">{formatCell(row.name)} ({formatCell(row.symbol)})</p><p className="text-muted-foreground">{formatCell(row.assetType)}</p></td><td className="max-w-[250px] px-4 py-3"><p>{formatCell(row.chainId)}</p><p className="truncate text-muted-foreground">{formatCell(row.identifier)}</p></td><td className="px-4 py-3"><StatusPill value={status} /></td><td className="px-4 py-3"><StatusPill value={verificationStatus} /></td><td className="px-4 py-3"><div className="flex flex-wrap gap-2">{canManage && <button onClick={() => onStatus(id, status === "active" ? "blocked" : "active")} className="rounded-md bg-accent/15 px-2 py-1 font-semibold text-accent">{status === "active" ? "Request block" : "Request activate"}</button>}{canVerify && <button onClick={() => onVerification(id, verificationStatus === "verified" ? "registered" : "verified")} className="rounded-md bg-foreground/10 px-2 py-1 font-semibold">{verificationStatus === "verified" ? "Request unverify" : "Request verify"}</button>}{!canManage && !canVerify && <span className="text-muted-foreground">Read only</span>}</div></td></tr>;})}</tbody></table></div>}</div>;
}

function ApprovalTable({ rows, canDecide, canExecute, currentOpenId, onDecide, onExecute }: { rows: Array<Record<string, any>>; canDecide: boolean; canExecute: boolean; currentOpenId: string; onDecide: (id: number, decision: "approved" | "rejected") => void; onExecute: (id: number) => void }) {
  return <div className="glass-card overflow-hidden"><div className="border-b border-foreground/10 p-5"><h2 className="font-semibold">Approval workflow</h2><p className="mt-1 text-xs text-muted-foreground">Pending requests can be decided by an eligible approver. Approved requests can be executed by a different eligible administrator. Every transition is server-authorized and audited.</p></div>{rows.length === 0 ? <p className="p-5 text-sm text-muted-foreground">No approval requests available.</p> : <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-foreground/10 text-muted-foreground"><th className="px-4 py-3">Action</th><th className="px-4 py-3">Resource</th><th className="px-4 py-3">Requester</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Reason</th><th className="px-4 py-3">Actions</th></tr></thead><tbody>{rows.map((row) => { const id = Number(row.id); const requestedBy = String(row.requestedByOpenId ?? ""); const canApproveThis = canDecide && row.status === "pending" && requestedBy !== currentOpenId; return <tr key={id} className="border-b border-foreground/5 last:border-0"><td className="px-4 py-3 font-medium">{formatCell(row.action)}</td><td className="px-4 py-3">{formatCell(row.resourceType)}{row.resourceId ? ` #${formatCell(row.resourceId)}` : ""}</td><td className="max-w-[180px] truncate px-4 py-3">{formatCell(row.requestedByOpenId)}</td><td className="px-4 py-3"><StatusPill value={formatCell(row.status)} /></td><td className="max-w-[260px] px-4 py-3">{formatCell(row.requestReason)}</td><td className="px-4 py-3"><div className="flex flex-wrap gap-2">{canApproveThis && <><button onClick={() => onDecide(id, "approved")} className="rounded-md bg-emerald-500/15 px-2 py-1 font-semibold text-emerald-200">Approve</button><button onClick={() => onDecide(id, "rejected")} className="rounded-md bg-rose-500/15 px-2 py-1 font-semibold text-rose-200">Reject</button></>}{canExecute && row.status === "approved" && requestedBy !== currentOpenId && <button onClick={() => onExecute(id)} className="rounded-md bg-accent/15 px-2 py-1 font-semibold text-accent">Execute</button>}{!canApproveThis && !(canExecute && row.status === "approved" && requestedBy !== currentOpenId && String(row.approvedByOpenId ?? "") !== currentOpenId) && <span className="text-muted-foreground">Read only</span>}</div></td></tr>;})}</tbody></table></div>}</div>;
}

function AnnouncementTable({ rows, onPublish, onArchive }: { rows: Array<Record<string, any>>; onPublish: (id: number) => void; onArchive: (id: number) => void }) {
  return <div className="glass-card overflow-hidden"><div className="border-b border-foreground/10 p-5"><h2 className="font-semibold">Announcements</h2><p className="mt-1 text-xs text-muted-foreground">System, security, maintenance, provider-outage, and ecosystem notices are durable and audited.</p></div>{rows.length === 0 ? <p className="p-5 text-sm text-muted-foreground">No announcements available.</p> : <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-foreground/10 text-muted-foreground"><th className="px-4 py-3">Kind</th><th className="px-4 py-3">Title</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Actions</th></tr></thead><tbody>{rows.map((row) => { const id = Number(row.id); const status = String(row.status ?? ""); return <tr key={id} className="border-b border-foreground/5 last:border-0"><td className="px-4 py-3">{formatCell(row.kind)}</td><td className="max-w-[280px] px-4 py-3">{formatCell(row.title)}</td><td className="px-4 py-3"><StatusPill value={status} /></td><td className="px-4 py-3"><div className="flex gap-2">{status !== "published" && status !== "archived" && <button onClick={() => onPublish(id)} className="rounded-md bg-accent/15 px-2 py-1 font-semibold text-accent">Publish</button>}{status !== "archived" && <button onClick={() => onArchive(id)} className="rounded-md bg-foreground/10 px-2 py-1 font-semibold">Archive</button>}</div></td></tr>;})}</tbody></table></div>}</div>;
}

function DataTable({ title, rows, empty, columns }: { title: string; rows: Array<Record<string, unknown>>; empty: string; columns: Array<[string, string]> }) {
  return <div className="glass-card overflow-hidden"><div className="border-b border-foreground/10 p-5"><h2 className="font-semibold">{title}</h2><p className="mt-1 text-xs text-muted-foreground">Server-authorized records only. Sensitive credentials and signing material are never displayed.</p></div>{rows.length === 0 ? <p className="p-5 text-sm text-muted-foreground">{empty}</p> : <div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-foreground/10 text-muted-foreground">{columns.map(([, label]) => <th key={label} className="whitespace-nowrap px-4 py-3 font-medium">{label}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={String(row.id ?? index)} className="border-b border-foreground/5 last:border-0"><>{columns.map(([key]) => <td key={key} className="max-w-[260px] truncate whitespace-nowrap px-4 py-3">{formatCell(row[key])}</td>)}</></tr>)}</tbody></table></div>}</div>;
}

function formatCell(value: unknown): string {
  if (value === null || value === undefined || value === "") return "—";
  if (value instanceof Date) return value.toLocaleString();
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}
