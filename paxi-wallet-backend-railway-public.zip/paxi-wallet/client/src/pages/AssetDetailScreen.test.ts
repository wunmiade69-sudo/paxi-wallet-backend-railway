import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const assetDetailPath = fileURLToPath(new URL("./AssetDetailScreen.tsx", import.meta.url));

describe("asset-detail security visibility", () => {
  it("keeps the PAXI Shield fallback and explicit Chart, Stats, and Security tabs visible for contract assets", () => {
    const source = readFileSync(assetDetailPath, "utf8");

    expect(source).toContain("SecurityStatusBadge");
    expect(source).toContain("PaxiShieldPanel");
    expect(source).toContain("'chart', 'stats', 'security'");
    expect(source).toContain("t === 'chart' ? 'Chart' : t === 'stats' ? 'Stats' : 'Security'");
  });
});
