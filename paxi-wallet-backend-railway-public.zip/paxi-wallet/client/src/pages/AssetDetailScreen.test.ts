import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const assetDetailPath = fileURLToPath(new URL("./AssetDetailScreen.tsx", import.meta.url));

describe("asset-detail security visibility", () => {
  it("keeps the PAXI Shield fallback and explicit Chart, Stats, and Security tabs visible for contract assets", () => {
    const source = readFileSync(assetDetailPath, "utf8");

    expect(source).toContain("SecurityStatusBadge");
    expect(source).toContain("PaxiShieldPanel");
    expect(source).toContain("'chart', 'stats', 'security'");
    expect(source).toContain("t === 'chart' ? 'Chart' : t === 'stats' ? 'Stats' : 'Security'");
    expect(source).toContain("'3M': { timeframe: '3M' }");
  });
});

describe("asset-detail market provenance", () => {
  it("renders provider sources and explicit update/unavailable states", () => {
    const source = readFileSync(assetDetailPath, "utf8");

    expect(source).toContain("formatMarketSources");
    expect(source).toContain("`Source: ${marketSourceLabel}`");
    expect(source).toContain("'Updating market data…'");
    expect(source).toContain("'Market data unavailable'");
  });

  it("does not claim all held-asset market data is live DexScreener data", () => {
    const source = readFileSync(assetDetailPath, "utf8");

    expect(source).toContain("Source: DexScreener.");
    expect(source).not.toContain("Live market data from DexScreener.");
  });

  it("keeps pair liquidity explicit and avoids hardcoded stablecoin pricing", () => {
    const source = readFileSync(assetDetailPath, "utf8");

    expect(source).toContain("Pair liquidity");
    expect(source).not.toContain("stablecoinPrice");
    expect(source).not.toContain("? 1 : null");
  });
});
