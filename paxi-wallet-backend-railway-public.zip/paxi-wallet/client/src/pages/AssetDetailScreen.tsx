import { useEffect, useMemo, useState } from 'react';
import { BarChart, Bar, ResponsiveContainer, YAxis, XAxis, Tooltip, Legend } from 'recharts';
import { ArrowLeft, Globe, Twitter, FileText, ExternalLink, Droplets } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { NETWORKS, type AssetConfig } from '@/lib/wallet/chains';
import {
  fetchDexTokenPanel,
  COINGECKO_IDS,
  type AssetBalance,
  type DexTokenPanel,
} from '@/lib/wallet/balances';
import { getHistoryStaleWhileRevalidate } from '@/lib/wallet/txIndexer';
import { getStoredAddress } from '@/lib/wallet/vault';
import type { TxRecord } from '@/lib/wallet/txHistory';
import { getTxRecords } from '@/lib/wallet/txHistory';
import TransactionList from '@/components/TransactionList';
import ProfessionalMarketChart, { ChartLoadingState, ChartUnavailableState } from '@/components/ProfessionalMarketChart';
import VerifiedBadge from '@/components/VerifiedBadge';
import { getTrustedAssetLabel, isOfficialPaxiToken, isTrustedAsset, PAXI_LOGO_URL } from '@/lib/appInfo';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { formatWalletAmount } from '@/lib/wallet/amountFormatting';
import { PaxiShieldPanel, SecurityStatusBadge } from '@/components/PaxiShieldPanel';
import AssetLogo from '@/components/AssetLogo';

interface AssetDetailScreenProps {
  asset: AssetConfig;
  balance: AssetBalance | undefined;
  onBack: () => void;
  onSend: () => void;
  onReceive: () => void;
}

type RangeKey = '1H' | '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL';
type ViewTab = 'chart' | 'stats' | 'security';

const RANGES: Record<RangeKey, { timeframe: '1H' | '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL' }> = {
  '1H': { timeframe: '1H' },
  '1D': { timeframe: '1D' },
  '1W': { timeframe: '1W' },
  '1M': { timeframe: '1M' },
  '3M': { timeframe: '3M' },
  '1Y': { timeframe: '1Y' },
  'ALL': { timeframe: 'ALL' },
};

const NATIVE_COIN_IDS: Record<string, string> = {
  BNB: 'binancecoin',
  ETH: 'ethereum',
  BTC: 'bitcoin',
  SOL: 'solana',
  POL: 'polygon-ecosystem-token',
};

const MARKET_PROVIDER_LABELS: Record<string, string> = {
  coingecko: 'CoinGecko',
  dexpaprika: 'DexPaprika',
  birdeye: 'Birdeye',
  dexscreener: 'DexScreener',
};

function formatMarketSources(sources: string[] | undefined, fallback?: string | null): string {
  const values = sources?.length ? sources : fallback ? [fallback] : [];
  const labels = Array.from(new Set(values.map((source) => MARKET_PROVIDER_LABELS[source] ?? source)));
  return labels.length ? labels.join(' + ') : 'Unavailable';
}

export default function AssetDetailScreen({ asset, balance, onBack, onSend, onReceive }: AssetDetailScreenProps) {
  const [tab, setTab] = useState<ViewTab>('chart');
  const [range, setRange] = useState<RangeKey>('1D');
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);
  const chartCoinId = asset.isNative
    ? NATIVE_COIN_IDS[asset.symbol]
    : asset.contractAddress
      ? `${asset.network}:${asset.contractAddress}`
      : undefined;
  const canonicalMarketInput = asset.isNative
    ? (chartCoinId ? { chain: asset.network, coinId: chartCoinId } : null)
    : (asset.contractAddress ? { chain: asset.network, contractAddress: asset.contractAddress } : null);
  const chartQuery = trpc.market.chart.useQuery(
    canonicalMarketInput
      ? { ...canonicalMarketInput, timeframe: RANGES[range].timeframe }
      : { coinId: 'unsupported', timeframe: RANGES[range].timeframe },
    { enabled: Boolean(canonicalMarketInput), refetchInterval: 30_000, staleTime: 15_000 }
  );
  const marketDetailQuery = trpc.market.detail.useQuery(
    canonicalMarketInput ?? { coinId: 'unsupported' },
    { enabled: Boolean(canonicalMarketInput), refetchInterval: 30_000, staleTime: 15_000 }
  );
  const nativePriceQuery = trpc.market.nativePrice.useQuery(
    { network: asset.network },
    { enabled: asset.isNative, refetchInterval: 15_000, staleTime: 10_000 }
  );
  const assetPriceQuery = trpc.market.assetPrice.useQuery(
    {
      network: asset.network,
      contractAddress: asset.contractAddress ?? 'unknown',
      symbol: asset.symbol,
      decimals: asset.decimals,
    },
    { enabled: Boolean(!asset.isNative && asset.contractAddress), refetchInterval: 15_000, staleTime: 10_000 }
  );
  const chartResponse = chartQuery.data && !Array.isArray(chartQuery.data) ? chartQuery.data : null;
  const points = useMemo(
    () => (chartResponse?.points ?? (Array.isArray(chartQuery.data) ? chartQuery.data : [])).map((point) => ({
      ...point,
      price: point.close ?? undefined,
      source: chartResponse?.source,
      fallback: chartResponse?.source === 'coingecko',
    })),
    [chartResponse, chartQuery.data],
  );
  const isLoading = chartQuery.isLoading || chartQuery.isFetching;
  const statsCoinId = asset.binanceSymbol ? COINGECKO_IDS[asset.binanceSymbol] : undefined;
  const [dexPanel, setDexPanel] = useState<DexTokenPanel | null>(null);
  const [isDexLoading, setIsDexLoading] = useState(true);
  const [assetTxs, setAssetTxs] = useState<TxRecord[]>([]);
  const [isTxLoading, setIsTxLoading] = useState(true);
  const network = NETWORKS[asset.network];
  const isOfficialPaxi = isOfficialPaxiToken(asset);
  const trustedAssetLabel = getTrustedAssetLabel(asset);
  const isVerifiedAsset = isTrustedAsset(asset);
  const assetIconUrl = isOfficialPaxi ? PAXI_LOGO_URL : asset.iconUrl;
  const hasStatsSource = Boolean(asset.binanceSymbol || asset.contractAddress);
  const hasDetailTabs = Boolean(hasStatsSource || asset.contractAddress);
  // Blockscout (the on-chain indexer used below) only covers Ethereum/BSC - it can find
  // transactions this wallet wasn't even open for. Every other chain (Solana, Bitcoin,
  // Polygon, Arbitrum, ...) falls back to this wallet's own local record of what it sent,
  // swapped, bridged, or created - narrower, but real, instead of showing nothing at all.
  const hasIndexerSource = Boolean(NETWORKS[asset.network] && ['ethereum', 'bsc'].includes(asset.network));

  useEffect(() => {
    const address = getStoredAddress();
    const filterForAsset = (all: TxRecord[]) =>
      all.filter((r) => r.networkId === asset.network && (r.fromSymbol === asset.symbol || r.toSymbol === asset.symbol));

    if (!hasIndexerSource) {
      setAssetTxs(filterForAsset(getTxRecords()));
      setIsTxLoading(false);
      return;
    }
    if (!address) {
      setIsTxLoading(false);
      return;
    }

    const cached = getHistoryStaleWhileRevalidate(address, (fresh) => {
      setAssetTxs(filterForAsset(fresh.records));
      setIsTxLoading(false);
    });
    if (cached.length > 0) {
      setAssetTxs(filterForAsset(cached));
      setIsTxLoading(false);
    } else {
      setIsTxLoading(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [asset.symbol, asset.network]);

  const statsQuery = trpc.market.assetStats.useQuery(
    { coinId: statsCoinId, network: asset.network, contractAddress: asset.contractAddress },
    { enabled: Boolean(statsCoinId || asset.contractAddress) }
  );
  const stats = statsQuery.data ?? null;
  const isStatsLoading = statsQuery.isLoading;

  useEffect(() => {
    if (!asset.contractAddress) {
      setIsDexLoading(false);
      return;
    }
    setIsDexLoading(true);
    fetchDexTokenPanel(asset)
      .then(setDexPanel)
      .finally(() => setIsDexLoading(false));
  }, [asset.contractAddress, asset.network]);

  const first = points[0]?.price ?? points[0]?.close;
  const last = points[points.length - 1]?.price ?? points[points.length - 1]?.close;
  const rangeChangePct = first != null && last != null && first > 0 ? ((last - first) / first) * 100 : null;
  const livePrice = marketDetailQuery.data?.currentPrice ?? nativePriceQuery.data?.priceUsd ?? assetPriceQuery.data?.priceUsd ?? balance?.usdPrice ?? null;
  const displayPrice = livePrice;
  const detailSourceLabel = formatMarketSources(marketDetailQuery.data?.sources, marketDetailQuery.data?.source);
  const statsSourceLabel = formatMarketSources(stats?.sources, stats?.source);
  const chartSourceLabel = formatMarketSources(undefined, chartResponse?.source);
  const marketSourceLabel = detailSourceLabel !== 'Unavailable' ? detailSourceLabel : statsSourceLabel;
  const marketStatusLabel = marketDetailQuery.isFetching || chartQuery.isFetching || statsQuery.isFetching
    ? 'Updating market data…'
    : marketSourceLabel !== 'Unavailable'
      ? `Source: ${marketSourceLabel}`
      : chartSourceLabel !== 'Unavailable'
        ? `Chart source: ${chartSourceLabel}`
        : 'Market data unavailable';
  const isUp = rangeChangePct != null && rangeChangePct >= 0;

  return (
    <div className="min-h-screen overflow-x-hidden bg-background px-4 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto mb-6 flex max-w-md items-center justify-between sm:mb-8">
        <button type="button" onClick={onBack} className="paxi-pressable flex min-h-11 items-center gap-1 rounded-xl px-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Back
        </button>
        <h1 className="text-xl font-bold tracking-tight text-foreground">{asset.symbol}</h1>
        <div className="w-14" aria-hidden="true" />
      </div>

      <div className="mx-auto w-full max-w-md flex-1 space-y-6">
        <div className="flex items-center gap-3">
          <AssetLogo src={assetIconUrl} alt={asset.symbol} fallback={asset.icon} size="md" />
          <div>
            <p className="flex items-center gap-2 text-foreground font-semibold">
              {asset.name}
              {isVerifiedAsset && <VerifiedBadge size="md" label={trustedAssetLabel ?? 'Verified asset'} />}
            </p>
            <p className="text-xs text-muted-foreground">{network.label}</p>
            {!asset.isNative && asset.contractAddress && (
              <div className="mt-2">
                <SecurityStatusBadge network={asset.network} contractAddress={asset.contractAddress} />
              </div>
            )}
          </div>
        </div>

        <div>
              <p className={`text-3xl font-bold text-foreground ${displayPrice == null ? 'paxi-unavailable' : ''}`}>
              {formatFiat(displayPrice, currency, fiatRate)}
          </p>
          {rangeChangePct != null && (
            <p className={`text-sm ${isUp ? 'text-green-400' : 'text-red-400'}`}>
              {isUp ? '+' : ''}
              {rangeChangePct.toFixed(2)}% ({range})
            </p>
          )}
          <p className="mt-1 text-[11px] text-muted-foreground" aria-live="polite">{marketStatusLabel}</p>
        </div>

        {hasDetailTabs && (
          <div className="flex gap-1 rounded-xl border border-border/70 bg-secondary/70 p-1">
            {(['chart', 'stats', 'security'] as ViewTab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                  type="button"
                  aria-pressed={tab === t}
                  className={`flex min-h-11 flex-1 items-center justify-center rounded-lg px-2 py-2 text-xs font-semibold capitalize transition-colors sm:text-sm ${
                  tab === t ? 'bg-accent text-accent-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t === 'chart' ? 'Chart' : t === 'stats' ? 'Stats' : 'Security'}
              </button>
            ))}
          </div>
        )}

        {tab === 'chart' && (
        <>
        <div className="glass-card h-[250px] flex items-center justify-center overflow-hidden">
          {!chartCoinId ? (
            <p className="text-sm text-muted-foreground text-center px-4">
              {asset.contractAddress
                ? "No historical chart for this token yet - that needs a paid data provider. Check the Stats tab for its live price, liquidity, and market cap instead."
                : "No market data available for this token yet."}
            </p>
          ) : isLoading ? (
            <ChartLoadingState height={250} />
          ) : chartQuery.error ? (
            <ChartUnavailableState height={250} message="Chart unavailable · Price may remain available above" />
          ) : (
            <ProfessionalMarketChart
              data={points}
              positive={isUp}
              source={chartResponse?.source}
              fallback={chartResponse?.source === 'coingecko'}
              livePrice={livePrice}
              height={250}
            />
          )}
        </div>

        {chartCoinId && (
          <div className="flex gap-2">
            {(Object.keys(RANGES) as RangeKey[]).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                type="button"
                aria-pressed={range === r}
                className={`paxi-chip flex min-h-11 flex-1 items-center justify-center py-2 text-sm font-semibold transition-colors ${
                  range === r ? 'bg-accent text-accent-foreground' : 'bg-secondary text-foreground/80 hover:bg-muted'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        )}
        </>
        )}

        {tab === 'stats' && (
          <div className="space-y-4">
            {!hasStatsSource && (
              <div className="glass-card">
                <p className="text-sm text-muted-foreground text-center py-6 px-2">No stats available for this token.</p>
              </div>
            )}

            {asset.binanceSymbol && (
              <div className="glass-card space-y-4">
                {isStatsLoading ? (
                  <p className="text-sm text-muted-foreground text-center py-6">Loading stats…</p>
                ) : !stats ? (
                  <p className="text-sm text-muted-foreground text-center py-6">Couldn't load stats. Try again later.</p>
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-y-4 gap-x-3">
                      <div>
                        <p className="text-xs text-muted-foreground">Market Cap</p>
                        <p className="text-foreground font-semibold">
                          {formatFiat(stats.marketCap, currency, fiatRate)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">24h Volume</p>
                        <p className="text-foreground font-semibold">
                          {formatFiat(stats.volume24h, currency, fiatRate)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Circulating Supply</p>
                        <p className="text-foreground font-semibold">
                          {stats.circulatingSupply != null
                            ? `${stats.circulatingSupply.toLocaleString(undefined, { maximumFractionDigits: 0 })}${
                                stats.circulatingSupplyPct != null ? ` (${stats.circulatingSupplyPct.toFixed(1)}%)` : ''
                              }`
                            : '—'}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Created</p>
                        <p className="text-foreground font-semibold">
                          {stats.genesisDate ? new Date(stats.genesisDate).toLocaleDateString() : '—'}
                        </p>
                      </div>
                    </div>

                    {(stats.homepage || stats.twitter || stats.reddit || stats.whitepaper) && (
                      <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
                        {stats.homepage && (
                          <a
                            href={stats.homepage}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-muted rounded-full text-xs text-foreground/80"
                          >
                            <Globe className="w-3.5 h-3.5" /> Website
                          </a>
                        )}
                        {stats.twitter && (
                          <a
                            href={stats.twitter}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-muted rounded-full text-xs text-foreground/80"
                          >
                            <Twitter className="w-3.5 h-3.5" /> X
                          </a>
                        )}
                        {stats.reddit && (
                          <a
                            href={stats.reddit}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-muted rounded-full text-xs text-foreground/80"
                          >
                            Reddit
                          </a>
                        )}
                        {stats.whitepaper && (
                          <a
                            href={stats.whitepaper}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-muted rounded-full text-xs text-foreground/80"
                          >
                            <FileText className="w-3.5 h-3.5" /> Whitepaper
                          </a>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {asset.contractAddress && <DexMarketPanel isLoading={isDexLoading} panel={dexPanel} currency={currency} fiatRate={fiatRate} />}
          </div>
        )}

        {tab === 'security' && asset.contractAddress && (
          <div className="space-y-4">
            <PaxiShieldPanel network={asset.network} contractAddress={asset.contractAddress} />
            <div className="glass-card border border-border/70 p-4">
              <p className="text-xs leading-relaxed text-muted-foreground">
                Security status is provided independently from market data. An unavailable result does not mean the asset is safe; review the contract and network before interacting.
              </p>
            </div>
          </div>
        )}

        <div>
          <h3 className="text-sm font-semibold text-foreground mb-3">Recent Activity</h3>
          {isTxLoading ? (
            <div className="glass-card">
              <p className="text-sm text-muted-foreground text-center py-6">Loading activity…</p>
            </div>
          ) : (
            <TransactionList
              records={assetTxs.slice(0, 8)}
              showFilters={false}
              emptyTitle="No activity yet"
              emptySubtitle={`Send, receive, swap, or bridge ${asset.symbol} and it will show up here.`}
            />
          )}
        </div>

        <div className="glass-card space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Your Balance</span>
            <span className="text-foreground font-semibold">
              {balance?.balance != null ? formatWalletAmount(balance.balance) : '—'}{' '}
              {asset.symbol}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Value</span>
            <span className="text-foreground">
              {balance?.balance != null && balance?.usdPrice != null
                ? formatFiat(balance.balance * balance.usdPrice, currency, fiatRate)
                : '—'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onSend}
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-all active:scale-95"
          >
            Send
          </button>
          <button
            onClick={onReceive}
            className="bg-secondary hover:bg-muted text-foreground font-semibold py-3 rounded-lg transition-all active:scale-95"
          >
            Receive
          </button>
        </div>
      </div>
    </div>
  );
}

function DexMarketPanel({
  isLoading,
  panel,
  currency,
  fiatRate,
}: {
  isLoading: boolean;
  panel: DexTokenPanel | null;
  currency: import('@/lib/currency').FiatCurrency;
  fiatRate: number | null;
}) {
  if (isLoading) {
    return (
      <div className="glass-card">
        <p className="text-sm text-muted-foreground text-center py-6">Loading market & security data…</p>
      </div>
    );
  }

  const market = panel?.market ?? null;
  if (!market) {
    return (
      <div className="glass-card">
        <p className="text-sm text-muted-foreground text-center py-6 px-2">No live DEX pair data found for this token yet.</p>
      </div>
    );
  }

  const txnData = market
    ? [
        { window: '5m', Buys: market.txns.m5.buys, Sells: market.txns.m5.sells },
        { window: '1h', Buys: market.txns.h1.buys, Sells: market.txns.h1.sells },
        { window: '6h', Buys: market.txns.h6.buys, Sells: market.txns.h6.sells },
        { window: '24h', Buys: market.txns.h24.buys, Sells: market.txns.h24.sells },
      ]
    : [];

  return (
    <>
      <div className="glass-card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-accent" /> Market Data
            </h3>
            <a
              href={market.pairUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
            >
              {market.dexId} <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <div className="grid grid-cols-2 gap-y-4 gap-x-3">
            <div>
              <p className="text-xs text-muted-foreground">Pair liquidity</p>
              <p className="text-foreground font-semibold">{formatFiat(market.liquidityUsd, currency, fiatRate)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Market Cap</p>
              <p className="text-foreground font-semibold">{formatFiat(market.marketCap, currency, fiatRate)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">24h Volume</p>
              <p className="text-foreground font-semibold">{formatFiat(market.volume24h, currency, fiatRate)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">24h Change</p>
              <p className={`font-semibold ${market.change24h == null ? 'text-muted-foreground' : market.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {market.change24h != null ? `${market.change24h >= 0 ? '+' : ''}${market.change24h.toFixed(2)}%` : '—'}
              </p>
            </div>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-2">Buys vs Sells</p>
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={txnData} barGap={2}>
                  <XAxis dataKey="window" tick={{ fontSize: 11, fill: '#888' }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip contentStyle={{ background: '#111', border: '1px solid #333', borderRadius: 8 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="Buys" fill="#4ade80" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="Sells" fill="#f87171" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

      <p className="text-[11px] text-muted-foreground px-1">
        Source: DexScreener. Automated market and contract checks are not financial advice - always do your own research before trading.
      </p>
    </>
  );
}
