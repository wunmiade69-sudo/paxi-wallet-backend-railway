import { useI18n } from '@/lib/i18n';
import { ChevronRight, PieChart, Wallet, ArrowLeftRight, Sparkles, BookUser, Gift, BookOpen, Info, Settings as SettingsIcon, Rocket, Globe2, Copy, Check, ShieldCheck, Megaphone, Flag, Mail } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import { getStoredAddress, getWallets } from '@/lib/wallet/vault';
import { EMPTY_SECURITY_SUMMARY } from '@/lib/phase3Models';

interface MeScreenProps {
  onNavigate: (tab: NavTab) => void;
  onSettings: () => void;
  profileName?: string;
  onAssetOverview: () => void;
  onTransactionRecords: () => void;
  onNotifications: () => void;
  onAddressBook: () => void;
  onConnectedDapps: () => void;
  onTokenApprovals: () => void;
  onManageWallets: () => void;
  onWalletGuide: () => void;
  onExperience: () => void;
  onInviteFriends: () => void;
  onAboutUs: () => void;
  onPaxiAISupport: () => void;
  onHelpCentre: () => void;
  onReportIssue: () => void;
  onContactSupport: () => void;
  onCreateToken: () => void;
  onWeb3Browser: () => void;
  isAdmin?: boolean;
  onAdmin?: () => void;
}

function shortAddress(address: string) {
  return `${address.slice(0, 6)}…${address.slice(-4)}`;
}

export default function MeScreen({
  onNavigate,
  onSettings,
  profileName,
  onAssetOverview,
  onTransactionRecords,
  onNotifications,
  onAddressBook,
  onConnectedDapps,
  onTokenApprovals,
  onManageWallets,
  onWalletGuide,
  onExperience,
  onInviteFriends,
  onAboutUs,
  onPaxiAISupport,
  onHelpCentre,
  onReportIssue,
  onContactSupport,
  onCreateToken,
  onWeb3Browser,
  isAdmin = false,
  onAdmin,
}: MeScreenProps) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);
  const address = getStoredAddress();
  const walletCount = getWallets().length;
  const securitySummary = EMPTY_SECURITY_SUMMARY;
  const securityStatusLabel = securitySummary.overall === 'unknown' ? 'Unknown' : securitySummary.overall === 'good' ? 'Good' : securitySummary.overall === 'warning' ? 'Warning' : 'Review';

  const handleCopy = () => {
    if (!address) return;
    navigator.clipboard.writeText(address);
    setCopied(true);
    toast.success('Address copied');
    setTimeout(() => setCopied(false), 2000);
  };

  const groups: Array<Array<{ label: string; icon: typeof Wallet; onClick: () => void; badge?: boolean }>> = [
    [
      { label: t('me_asset_overview'), icon: PieChart, onClick: onAssetOverview },
      { label: t('me_manage_wallets'), icon: Wallet, onClick: onManageWallets },
      { label: 'Address Book', icon: BookUser, onClick: onAddressBook },
      { label: 'Connected dApps', icon: Globe2, onClick: onConnectedDapps },
      { label: 'Token Approvals', icon: ShieldCheck, onClick: onTokenApprovals },
    ],
    [
      { label: t('me_transaction_records'), icon: ArrowLeftRight, onClick: onTransactionRecords },
      { label: 'Notifications', icon: Megaphone, onClick: onNotifications },
      { label: 'Swaps & Bridges', icon: ArrowLeftRight, onClick: onTransactionRecords },
    ],
    [
      { label: t('me_create_token'), icon: Rocket, onClick: onCreateToken },
    ],
    [
      ...(isAdmin && onAdmin ? [{ label: 'Admin Console', icon: ShieldCheck, onClick: onAdmin }] : []),
      { label: 'PAXI AI Support', icon: Sparkles, onClick: onPaxiAISupport },
      { label: 'Help Centre', icon: BookOpen, onClick: onHelpCentre },
      { label: 'Report a problem', icon: Flag, onClick: onReportIssue },
      { label: 'Contact support', icon: Mail, onClick: onContactSupport },
      { label: 'Web3 Browser', icon: Globe2, onClick: onWeb3Browser },
      { label: 'Experience', icon: Sparkles, onClick: onExperience },
      { label: 'Invite Friends', icon: Gift, onClick: onInviteFriends },
      { label: 'About Us', icon: Info, onClick: onAboutUs },
      { label: 'Settings', icon: SettingsIcon, onClick: onSettings },
    ],
  ];
  const groupLabels = ['Wallet & security', 'Activity', 'Tools', 'Support & preferences'];

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-24">
      <div className="paxi-page-header sticky top-0 z-40">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4 sm:px-6">
          <div><p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Your wallet</p><h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground">Me</h1></div>
        </div>
      </div>

      <div className="mx-auto max-w-md space-y-5 px-4 py-6 sm:px-6">
        <section className="flex items-center justify-between gap-3 px-1">
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-11 h-11 rounded-full bg-gradient-to-br from-accent/40 to-accent/10 border border-accent/25 flex items-center justify-center font-bold text-accent shrink-0">{(profileName ?? 'P').slice(0, 1).toUpperCase()}</span>
            <div className="min-w-0"><p className="font-semibold text-foreground truncate">{profileName || 'Local wallet'}</p><p className="text-xs text-muted-foreground">Account status: {address ? 'Wallet ready' : 'Setup required'}</p></div>
          </div>
          <button type="button" onClick={onSettings} className="paxi-icon-button flex items-center justify-center text-muted-foreground hover:bg-foreground/5 hover:text-foreground" aria-label="Open settings"><SettingsIcon className="w-4 h-4" /></button>
        </section>

        {/* Identity card - gives this screen a "you" before the menu, and doubles as a quick
            way to copy your address without a trip to Receive. */}
        {address && (
          <button
            onClick={handleCopy}
            type="button"
            className="paxi-pressable flex min-h-[4.5rem] w-full items-center gap-3 glass-card !p-4 text-left transition-all hover:bg-foreground/5 animate-in fade-in duration-300"
          >
            <span className="w-11 h-11 rounded-full bg-gradient-to-br from-accent/40 to-accent/10 border border-accent/25 flex items-center justify-center font-bold text-accent shrink-0">
              {address.slice(2, 4).toUpperCase()}
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-foreground text-sm font-mono truncate">{shortAddress(address)}</p>
              <p className="text-xs text-muted-foreground">
                {walletCount} wallet{walletCount === 1 ? '' : 's'} on this device
              </p>
            </div>
            {copied ? <Check className="w-4 h-4 text-accent shrink-0" /> : <Copy className="w-4 h-4 text-muted-foreground shrink-0" />}
          </button>
        )}

        <section className="glass-card space-y-3 border border-accent/20 p-4" aria-labelledby="security-centre-title">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p id="security-centre-title" className="text-xs font-semibold uppercase tracking-[0.14em] text-accent">Security Centre</p>
              <p className="text-lg font-bold text-foreground mt-1">Status: {securityStatusLabel}</p>
            </div>
            <ShieldCheck className="w-5 h-5 text-accent" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            {securitySummary.signals.slice(0, 4).map((signal) => (
              <div key={signal.id} className="rounded-lg bg-secondary/60 p-2.5">
                <p className="text-xs text-foreground truncate">{signal.label}</p>
                <p className="text-[10px] text-muted-foreground mt-1 capitalize">{signal.status}</p>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground">{securitySummary.disclaimer}</p>
        </section>

        {groups.map((items, gi) => (
          <section key={gi} aria-labelledby={`me-group-${gi}`} style={{ animationDelay: `${gi * 60}ms` }} className="animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both">
            {items.length > 0 && <h2 id={`me-group-${gi}`} className="mb-2 px-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{groupLabels[gi]}</h2>}
            <div className="glass-card divide-y divide-white/5 overflow-hidden">
            {items.map(({ label, icon: Icon, onClick, badge }) => (
              <button
                key={label}
                type="button"
                onClick={onClick}
                className="paxi-pressable flex min-h-14 w-full items-center justify-between px-3 py-3.5 text-left transition-all hover:bg-foreground/5"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-accent" />
                  </span>
                  <span className="text-foreground text-sm font-medium">{label}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {badge && <span className="w-2 h-2 rounded-full bg-orange-500" />}
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </button>
            ))}
            </div>
          </section>
        ))}
      </div>

      <BottomNav active="me" onNavigate={onNavigate} />
    </div>
  );
}
