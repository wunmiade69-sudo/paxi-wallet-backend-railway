import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/SendScreen.tsx"), "utf8");

describe("SendScreen Phase 7C fee and address boundary", () => {
  it("uses network-specific recipient guidance instead of an EVM-only placeholder", () => {
    expect(source).toContain("isEvm ? '0x...' : isSol ? 'Solana address' : isBtc ? 'Bitcoin address'");
  });

  it("does not claim a PAXI fee is applied to direct sends", () => {
    expect(source).toContain("<span className=\"text-muted-foreground\">PAXI service fee</span>");
    expect(source).toContain("Not applied to this send");
  });
});
