import { useEffect, useState } from 'react';
import { ArrowLeft, AlertTriangle, BookUser } from 'lucide-react';
import { toast } from 'sonner';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { ASSETS, NETWORKS, assetKey } from '@/lib/wallet/chains';
import { isValidAddressForChainType } from '@/lib/wallet/engine';
import { estimateEvmGasFee, fetchAssetBalance } from '@/lib/wallet/balances';
import { sendEvmAsset, sendSolanaAsset } from '@/lib/wallet/send';
import { estimateBitcoinMaxSend, sendBitcoinAsset } from '@/lib/wallet/bitcoin';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';
import { SecurityStatusBadge, PaxiShieldPanel } from '@/components/PaxiShieldPanel';
import { describeTxError } from '@/lib/wallet/errors';
import { getStoredAddress, getUnlockedMnemonic, isActiveWalletWatchOnly, isActiveWalletPrivateKeyImport } from '@/lib/wallet/vault';
import { getAddressForChainType } from '@/lib/wallet/engine';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { addTxRecord, type TxRecord } from '@/lib/wallet/txHistory';
import AssetPickerDrawer from '@/components/AssetPickerDrawer';
import AddressBookScreen from '@/pages/AddressBookScreen';
import TransactionReceipt from '@/components/TransactionReceipt';

interface SendScreenProps {
  onBack: () => void;
}

type Step = 'form' | 'confirm' | 'sending' | 'done';

export default function SendScreen({ onBack }: SendScreenProps) {
  const allAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
  // Keyed by symbol+network, not bare symbol - USDT/USDC each exist on more
  // than one chain, and picking one by symbol alone would silently resolve
  // to whichever entry happens to come first in the list.
  const [selectedKey, setSelectedKey] = useState(assetKey(allAssets[0]));
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<Step>('form');
  const [error, setError] = useState('');
  const [gasEstimate, setGasEstimate] = useState<Awaited<ReturnType<typeof estimateEvmGasFee>>>(null);
  const [txResult, setTxResult] = useState<TxRecord | null>(null);
  const [showContacts, setShowContacts] = useState(false);
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [balance, setBalance] = useState<number | null>(null);
  const [balanceLoading, setBalanceLoading] = useState(false);

  const asset = allAssets.find((a) => assetKey(a) === selectedKey) ?? allAssets[0];
  const network = NETWORKS[asset.network];
  const fromAddress = getStoredAddress() ?? '';
  const isEvm = network.chainType === 'evm';
  const isSol = network.chainType === 'sol';
  const isBtc = network.chainType === 'btc';
  const isSendSupported = isEvm || isSol || isBtc;
  const isWatchOnly = isActiveWalletWatchOnly();

  useEffect(() => {
    setError('');
    setGasEstimate(null);
  }, [selectedKey, recipient, amount]);

  useEffect(() => {
    if (!fromAddress) return;
    let cancelled = false;
    setBalance(null);
    setBalanceLoading(true);
    const mnemonic = getUnlockedMnemonic();
    const solAddress = mnemonic ? (getAddressForChainType(mnemonic, 'sol') ?? undefined) : undefined;
    const btcAddress = mnemonic ? (getAddressForChainType(mnemonic, 'btc') ?? undefined) : undefined;
    fetchAssetBalance(asset, fromAddress, solAddress, btcAddress)
      .then((b) => {
        if (!cancelled) setBalance(b);
      })
      .finally(() => {
        if (!cancelled) setBalanceLoading(false);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedKey]);

  const handleMax = async () => {
    if (balance == null) return;
    if (!asset.isNative) {
      setAmount(String(balance));
      return;
    }
    setError('');
    try {
      if (isBtc) {
        const mnemonic = getUnlockedMnemonic();
        const btcAddress = mnemonic ? getAddressForChainType(mnemonic, 'btc') : undefined;
        if (!btcAddress) throw new Error('Unlock your wallet to derive a Bitcoin address.');
        const estimate = await estimateBitcoinMaxSend(btcAddress);
        setAmount(estimate.amountBtc);
        return;
      }

      // Account-based native assets need a network-fee reserve, or Review would
      // fail immediately after selecting the apparent full balance.
      let reserve = 0.00001; // conservative Solana fallback
      if (isEvm && network.rpcUrl) {
        const estimate = await estimateEvmGasFee(asset.network, fromAddress, recipient || fromAddress, '0');
        if (estimate) reserve = Number(estimate.estimatedFeeNative) * 1.2; // 20% headroom over the estimate
      }
      setAmount(Math.max(0, balance - reserve).toFixed(asset.decimals > 8 ? 8 : asset.decimals));
    } catch (err) {
      setError(describeTxError(err));
    }
  };

  const handleReview = async () => {
    setError('');
    if (!isSendSupported) {
      setError(`${asset.symbol} sending is coming soon. Please choose another supported asset.`);
      return;
    }
    if (!recipient || !isValidAddressForChainType(recipient, network.chainType)) {
      setError('Enter a valid recipient address for this network.');
      return;
    }
    const numericAmount = Number(amount);
    if (!amount || isNaN(numericAmount) || numericAmount <= 0) {
      setError('Enter an amount greater than 0.');
      return;
    }
    if (balance != null && numericAmount > balance) {
      setError(`You only have ${balance.toLocaleString(undefined, { maximumFractionDigits: 6 })} ${asset.symbol} available.`);
      return;
    }
    if (!network.rpcUrl) {
      setError(`${network.label} is not available right now. Please try again later or choose another network.`);
      return;
    }

    if (isEvm) {
      const estimate = await estimateEvmGasFee(asset.network, fromAddress, recipient, asset.isNative ? amount : '0');
      setGasEstimate(estimate);
    } else {
      // Solana fees are small/fixed; Bitcoin's fee is computed internally
      // during send (UTXO selection + sat/vByte rate) - neither needs this
      // EVM-specific up-front estimate.
      setGasEstimate(null);
    }
    setStep('confirm');
  };

  const handleConfirmSend = async () => {
    const mnemonic = getUnlockedMnemonic();
    if (!mnemonic) {
      setError('Session locked. Please unlock your wallet again.');
      setStep('form');
      return;
    }
    if ((isSol || isBtc) && !getAddressForChainType(mnemonic, isSol ? 'sol' : 'btc')) {
      setError(
        isActiveWalletPrivateKeyImport()
          ? `This account can't send ${isSol ? 'Solana' : 'Bitcoin'} - it was imported from a private key, so it's EVM-only.`
          : `Unlock your wallet to get a ${isSol ? 'Solana' : 'Bitcoin'} address before sending.`
      );
      setStep('form');
      return;
    }
    setStep('sending');
    try {
      const result = isSol
        ? await sendSolanaAsset({ mnemonic, asset, toAddress: recipient, amount })
        : isBtc
          ? await sendBitcoinAsset({ mnemonic, toAddress: recipient, amountBtc: amount })
          : await sendEvmAsset({ mnemonic, asset, toAddress: recipient, amount });
      setStep('done');
      toast.success('Transaction broadcast');
      const record = addTxRecord({
        type: 'send',
        networkId: asset.network,
        hash: result.hash,
        explorerUrl: result.explorerUrl,
        fromSymbol: asset.symbol,
        fromAmount: amount,
        counterparty: recipient,
        status: 'pending',
      });
      setTxResult(record);
    } catch (err) {
      setError(describeTxError(err));
      setStep('confirm');
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background px-4 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto mb-6 flex max-w-md items-center justify-between sm:mb-8">
        <button type="button" onClick={onBack} className="paxi-pressable flex min-h-11 items-center gap-1 rounded-xl px-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Back
        </button>
        <h1 className="text-xl font-bold tracking-tight text-foreground">Send</h1>
        <div className="w-14" aria-hidden="true" />
      </div>

      <div className="mx-auto w-full max-w-md">
        {step === 'form' && (
          <div className="space-y-4">
            {isWatchOnly && (
              <div className="paxi-alert-warning flex items-start gap-2.5 rounded-xl p-4">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-500" aria-hidden="true" />
                <p className="text-sm text-yellow-400">
                  This is a watch-only wallet - there are no keys stored on this device to sign with. Switch to a
                  wallet you hold the keys for to send.
                </p>
              </div>
            )}
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Asset</label>
              <AssetPickerDrawer
                label="Choose asset to send"
                assets={allAssets}
                selected={asset}
                showNetwork
                onSelect={(a) => setSelectedKey(assetKey(a))}
              />
              {!isSendSupported && (
                <p className="flex items-start gap-1.5 text-xs text-yellow-400 mt-2">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>
                    {asset.symbol} sending isn't wired up yet (needs a {network.chainType.toUpperCase()}{' '}
                    signing library). UI is ready; broadcasting isn't.
                  </span>
                </p>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm text-muted-foreground">Recipient Address</label>
                <button
                  type="button"
                  onClick={() => setShowContacts(true)}
                  className="paxi-pressable flex min-h-11 items-center gap-1 rounded-lg px-2 text-xs font-medium text-accent transition-colors hover:bg-accent/10 hover:text-accent/80"
                >
                  <BookUser className="w-3.5 h-3.5" />
                  Contacts
                </button>
              </div>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder={isEvm ? '0x...' : isSol ? 'Solana address' : isBtc ? 'Bitcoin address' : 'Recipient address'}
                aria-label="Recipient address"
                className="paxi-field w-full p-3 text-foreground placeholder:text-muted-foreground font-mono text-sm"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm text-muted-foreground">Amount</label>
                <p className="text-xs text-muted-foreground">
                  {balanceLoading ? 'Loading balance…' : balance != null ? `Balance: ${balance.toLocaleString(undefined, { maximumFractionDigits: 6 })} ${asset.symbol}` : ''}
                </p>
              </div>
              <div className="relative">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  aria-label={`Amount in ${asset.symbol}`}
                  inputMode="decimal"
                  className="paxi-field w-full p-3 pr-28 text-foreground placeholder:text-muted-foreground"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                  {balance != null && balance > 0 && (
                    <button
                      type="button"
                      onClick={handleMax}
                      className="paxi-pressable min-h-9 rounded-full bg-accent/10 px-3 py-1 text-[11px] font-bold text-accent transition-colors hover:bg-accent/20"
                    >
                      MAX
                    </button>
                  )}
                  <span className="text-muted-foreground text-sm">{asset.symbol}</span>
                </div>
              </div>
            </div>

            {error && (
              <div className="paxi-alert-error rounded-xl p-3" role="alert">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <button
              onClick={handleReview}
              disabled={isWatchOnly}
              className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-3 rounded-lg transition-colors"
            >
              Review Transaction
            </button>
          </div>
        )}

        {step === 'sending' && (
          <div className="text-center py-16">
            <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-accent border-t-transparent" role="status" aria-label="Broadcasting transaction" />
            <p className="text-muted-foreground">Broadcasting transaction...</p>
          </div>
        )}

        {step === 'done' && txResult && (
          <TransactionReceipt record={txResult} onClose={onBack} />
        )}
      </div>

      <Drawer open={showContacts} onOpenChange={setShowContacts}>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader className="text-left">
            <DrawerTitle>Pick a contact</DrawerTitle>
          </DrawerHeader>
          <div className="overflow-y-auto">
            <AddressBookScreen
              embedded
              onBack={() => setShowContacts(false)}
              onPick={(address, savedNetwork) => {
                if (savedNetwork !== asset.network) {
                  toast.error(`This contact is saved for ${NETWORKS[savedNetwork]?.label ?? savedNetwork}, not ${network.label}.`);
                  return;
                }
                setRecipient(address);
                setShowContacts(false);
              }}
            />
          </div>
        </DrawerContent>
      </Drawer>

      <Drawer open={step === 'confirm'} onOpenChange={(open) => !open && setStep('form')}>
        <DrawerContent className="max-h-[92vh]">
          <DrawerHeader className="text-left pb-2">
            <div className="flex items-center justify-between">
              <DrawerTitle>Review Transaction</DrawerTitle>
              <SecurityStatusBadge network={asset.network} contractAddress={asset.contractAddress} isNative={asset.isNative} />
            </div>
          </DrawerHeader>

          <div className="overflow-y-auto px-4 pb-6 space-y-4">
            <div className="glass-card p-4">
              <p className="text-xs text-muted-foreground">You Send</p>
              <p className="text-xl font-bold text-foreground">
                {amount} {asset.symbol}
              </p>
            </div>

            <div className="glass-card p-4 space-y-2.5 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Recipient</span>
                <span className="text-foreground font-mono text-xs text-right max-w-[60%] break-all">{recipient}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Network</span>
                <span className="text-foreground">{network.label}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-border">
                <span className="text-muted-foreground">Network Fee</span>
                <span className="text-foreground">
                  {gasEstimate ? `${Number(gasEstimate.estimatedFeeNative).toFixed(6)} ${network.nativeSymbol}` : 'Shown during signing'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">PAXI service fee</span>
                <span className="text-foreground">Not applied to this send</span>
              </div>
            </div>

            <PaxiShieldPanel network={asset.network} contractAddress={asset.contractAddress} isNative={asset.isNative} />

            <div className="paxi-alert-warning flex items-start gap-2.5 rounded-xl p-3">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-yellow-500" aria-hidden="true" />
              <p className="text-xs text-yellow-300">
                This sends a real on-chain transaction. Double-check the address - it can't be reversed.
              </p>
            </div>

            {error && (
              <div className="paxi-alert-error rounded-xl p-3" role="alert">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setStep('form')}
                className="paxi-pressable min-h-12 flex-1 rounded-xl border border-border bg-secondary py-3 font-semibold text-foreground transition-colors hover:bg-muted"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => setShowAuthGate(true)}
                className="paxi-pressable min-h-12 flex-1 rounded-xl bg-accent py-3 font-semibold text-accent-foreground transition-colors hover:bg-accent/90"
              >
                Continue
              </button>
            </div>
          </div>
        </DrawerContent>
      </Drawer>

      <TransactionAuthSheet
        open={showAuthGate}
        actionLabel={`Send ${amount} ${asset.symbol}`}
        onSuccess={() => {
          setShowAuthGate(false);
          handleConfirmSend();
        }}
        onCancel={() => setShowAuthGate(false)}
      />
    </div>
  );
}
