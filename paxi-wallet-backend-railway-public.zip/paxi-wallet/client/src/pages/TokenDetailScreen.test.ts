import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const tokenDetailPath = fileURLToPath(new URL("./TokenDetailScreen.tsx", import.meta.url));

describe("market token detail presentation", () => {
  it("uses the shared professional chart and separate Chart, Stats, and Security views", () => {
    const source = readFileSync(tokenDetailPath, "utf8");

    expect(source).toContain("ProfessionalMarketChart");
    expect(source).toContain("ChartLoadingState");
    expect(source).toContain("ChartUnavailableState");
    expect(source).toContain("['chart', 'stats', 'security']");
    expect(source).toContain('role="tablist"');
  });

  it("does not treat missing contract security data as a safe result", () => {
    const source = readFileSync(tokenDetailPath, "utf8");

    expect(source).toContain("Security check unavailable");
    expect(source).toContain("Market data alone does not verify this token or establish that it is safe");
    expect(source).toContain("trpc.security.checkContract.useQuery");
    expect(source).toContain("Not available");
    expect(source).toContain("risk indicators (GoPlus)");
    expect(source).toContain("token.contractAddress");
  });
});
