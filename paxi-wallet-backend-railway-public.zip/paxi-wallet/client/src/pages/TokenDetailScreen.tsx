import { useState } from 'react';
import { ArrowLeft, Globe, ExternalLink, TrendingUp, TrendingDown, Loader2, Copy, Check, PlusCircle, BadgeCheck, AlertTriangle } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { ASSETS, NETWORKS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';

export interface TokenDetailSelection {
  coinId: string | null;
  chain: string | null;
  contractAddress: string | null;
  symbol: string;
  name: string;
}

interface TokenDetailScreenProps {
  tokenIdentity: TokenDetailSelection;
  onBack: () => void;
  onAddToWallet: (networkId: string, contractAddress: string) => void;
}

/** CoinGecko's platform slug (from TokenDetail.platformId) -> this wallet's own network id.
 * Only chains this wallet actually supports importing tokens on are listed - an unlisted
 * platform (e.g. a chain we don't support yet) just means no "Add to Wallet" button shows. */
const PLATFORM_TO_NETWORK: Record<string, string> = {
  ethereum: 'ethereum',
  'binance-smart-chain': 'bsc',
  bsc: 'bsc',
  'polygon-pos': 'polygon',
  polygon: 'polygon',
  'arbitrum-one': 'arbitrum',
  arbitrum: 'arbitrum',
  solana: 'solana',
};

type Timeframe = '1H' | '1D' | '1W' | '1M' | '1Y' | 'ALL';
const TIMEFRAMES: Timeframe[] = ['1H', '1D', '1W', '1M', '1Y', 'ALL'];

/**
 * Read-only market detail for any CoinGecko-listed token, including ones
 * this wallet doesn't hold - complements AssetDetailScreen (which is for
 * wallet-held assets with send/receive/swap). Real data throughout;
 * no fabricated numbers.
 */
export default function TokenDetailScreen({ tokenIdentity, onBack, onAddToWallet }: TokenDetailScreenProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [addressCopied, setAddressCopied] = useState(false);
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  const marketInput = {
    chain: tokenIdentity.chain ?? undefined,
    contractAddress: tokenIdentity.contractAddress ?? undefined,
    coinId: tokenIdentity.coinId ?? undefined,
  };
  const { data: token, isLoading: loadingToken } = trpc.market.detail.useQuery(marketInput);
  const { data: chartData, isLoading: loadingChart } = trpc.market.chart.useQuery({ ...marketInput, timeframe });

  const points = chartData?.points ?? [];
  const isUp = (token?.priceChangePercent24h ?? 0) >= 0;

  const importNetworkId = token?.chain ? PLATFORM_TO_NETWORK[token.chain] ?? token.chain : token?.platformId ? PLATFORM_TO_NETWORK[token.platformId] : undefined;
  const alreadyHeld = Boolean(
    token?.contractAddress &&
      importNetworkId &&
      [...ASSETS, ...getCustomTokens().map(customTokenToAsset)].some(
        (a) => a.network === importNetworkId && a.contractAddress &&
          (['ethereum', 'bsc', 'polygon', 'arbitrum'].includes(importNetworkId)
            ? a.contractAddress.toLowerCase() === token.contractAddress!.toLowerCase()
            : a.contractAddress === token.contractAddress)
      )
  );

  const handleCopyAddress = () => {
    if (!token?.contractAddress) return;
    navigator.clipboard.writeText(token.contractAddress);
    setAddressCopied(true);
    toast.success('Contract address copied');
    setTimeout(() => setAddressCopied(false), 2000);
  };

  if (loadingToken) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-accent animate-spin" />
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
        <div className="w-12 h-12 rounded-full bg-destructive/10 border border-destructive/25 flex items-center justify-center mb-3">
          <AlertTriangle className="w-5 h-5 text-destructive" />
        </div>
        <p className="text-foreground font-semibold">Couldn't load this token</p>
        <button onClick={onBack} className="text-accent text-sm mt-3 font-medium">
          Go back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="w-6 h-6 rounded-full bg-accent/15 text-accent flex items-center justify-center text-[9px] font-bold overflow-hidden">
            {token.image ? <img src={token.image} alt="" className="w-full h-full rounded-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} /> : token.symbol.slice(0, 3)}
          </div>
          <h1 className="text-lg font-bold text-foreground">{token.symbol || tokenIdentity.symbol}</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div>
          <p className="text-3xl font-bold text-foreground tabular-nums">
            {formatFiat(token.currentPrice, currency, fiatRate)}
          </p>
          <p className={`flex items-center gap-1 text-sm font-semibold mt-1 ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
            {isUp ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
            {token.priceChangePercent24h != null ? `${isUp ? '+' : ''}${token.priceChangePercent24h.toFixed(2)}% (24H)` : '—'}
          </p>
        </div>

        <div className="glass-card h-48 flex items-center justify-center !p-2">
          {loadingChart ? (
            <p className="text-sm text-muted-foreground">Loading chart…</p>
          ) : points.length === 0 ? (
            <p className="text-sm text-muted-foreground">Historical chart unavailable for this asset.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={points}>
                <XAxis dataKey="timestamp" hide />
                <YAxis domain={['dataMin', 'dataMax']} hide />
                <Tooltip
                  contentStyle={{ background: '#111', border: '1px solid #333', borderRadius: 8 }}
                  labelFormatter={(t) => {
                    const timestamp = typeof t === 'number' ? t : Number(t);
                    return Number.isFinite(timestamp) ? new Date(timestamp).toLocaleString() : String(t ?? '');
                  }}
                  formatter={(v) => {
                    const numeric = typeof v === 'number' ? v : Number(v);
                    return [formatFiat(Number.isFinite(numeric) ? numeric : null, currency, fiatRate), 'Price'];
                  }}
                />
                <Line type="monotone" dataKey="close" stroke={isUp ? '#4ade80' : '#f87171'} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                timeframe === tf ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        <div className="glass-card p-4 grid grid-cols-2 gap-4">
          <Stat label="Market Cap" value={formatUsdCompact(token.marketCap, currency, fiatRate)} />
          <Stat label="Liquidity" value={formatUsdCompact(token.liquidity, currency, fiatRate)} />
          <Stat label="Volume (24H)" value={formatUsdCompact(token.volume24h, currency, fiatRate)} />
          <Stat label="Circulating Supply" value={token.circulatingSupply ? formatCompact(token.circulatingSupply) : '—'} />
          <Stat label="Max Supply" value={token.maxSupply ? formatCompact(token.maxSupply) : 'Unlimited'} />
        </div>

        {token.description && (
          <div className="glass-card p-4">
            <p className="text-sm font-semibold text-foreground mb-1.5">About {token.name}</p>
            <p className="text-xs text-muted-foreground leading-relaxed">{token.description}</p>
          </div>
        )}

        {token.contractAddress && (
          <div className="glass-card p-4">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs text-muted-foreground">
                Contract Address {importNetworkId && `(${NETWORKS[importNetworkId]?.label ?? importNetworkId})`}
              </p>
              <button
                onClick={handleCopyAddress}
                className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                aria-label="Copy contract address"
              >
                {addressCopied ? <Check className="w-3.5 h-3.5 text-accent" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <p className="text-xs font-mono text-foreground break-all">{token.contractAddress}</p>
            <p className="text-[10px] text-muted-foreground mt-2">{token.verificationStatus === 'verified' ? 'PAXI verified' : 'UNVERIFIED provider discovery'} · Security: {token.securityStatus === 'available' ? 'available' : 'not available'}</p>

            {importNetworkId && (
              <div className="mt-3 pt-3 border-t border-white/5">
                {alreadyHeld ? (
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-accent">
                    <BadgeCheck className="w-3.5 h-3.5" />
                    Already in your wallet
                  </p>
                ) : (
                  <button
                    onClick={() => onAddToWallet(importNetworkId, token.contractAddress!)}
                    className="flex items-center gap-1.5 text-xs font-semibold text-accent hover:text-accent/80 transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    Add to Wallet
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        <div className="flex gap-3">
          {token.homepage && (
            <a
              href={token.homepage}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-sm font-semibold py-2.5 rounded-lg transition-colors"
            >
              <Globe className="w-4 h-4" /> Website
            </a>
          )}
          {token.explorerUrl && (
            <a
              href={token.explorerUrl}
              target="_blank"
              rel="noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-secondary hover:bg-muted text-foreground text-sm font-semibold py-2.5 rounded-lg transition-colors"
            >
              <ExternalLink className="w-4 h-4" /> Explorer
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold text-foreground mt-0.5">{value}</p>
    </div>
  );
}

function formatUsdCompact(n: number | null, currency: import('@/lib/currency').FiatCurrency, fiatRate: number | null): string {
  if (n == null || !Number.isFinite(n) || fiatRate == null) return '—';
  const converted = n * (currency === 'USD' ? 1 : fiatRate);
  const symbols: Record<import('@/lib/currency').FiatCurrency, string> = { USD: '$', EUR: '€', GBP: '£', JPY: '¥', INR: '₹' };
  return `${symbols[currency]}${converted.toLocaleString(undefined, { notation: 'compact', maximumFractionDigits: 2 })}`;
}
function formatCompact(n: number): string {
  return n.toLocaleString(undefined, { notation: 'compact', maximumFractionDigits: 2 });
}
