import { ethers } from "ethers";
import { getCircuitBreaker } from "../resilience/circuitBreaker";

export type RpcNetwork = "ethereum" | "bsc" | "polygon" | "arbitrum" | "solana" | "bitcoin";

const DEFAULT_RPC_URLS: Record<RpcNetwork, string> = {
  ethereum: "https://ethereum-rpc.publicnode.com",
  bsc: "https://bsc-rpc.publicnode.com",
  polygon: "https://polygon-bor-rpc.publicnode.com",
  arbitrum: "https://arbitrum-one-rpc.publicnode.com",
  solana: "https://api.mainnet-beta.solana.com",
  bitcoin: "https://blockstream.info/api",
};

// Only BSC_RPC_URL is confirmed by the existing server environment contract.
// Other networks remain on the built-in public fallback until explicitly configured.
const RPC_ENV_KEYS: Record<RpcNetwork, string | undefined> = {
  ethereum: undefined,
  bsc: "BSC_RPC_URL",
  polygon: undefined,
  arbitrum: undefined,
  solana: undefined,
  bitcoin: undefined,
};

function validRpcUrl(value: string | undefined): string | null {
  if (!value?.trim()) return null;
  try {
    const parsed = new URL(value.trim());
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    if (!parsed.hostname || parsed.username || parsed.password) return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

export function getRpcUrls(network: RpcNetwork): string[] {
  const configuredKey = RPC_ENV_KEYS[network];
  const configured = configuredKey ? [validRpcUrl(process.env[configuredKey])].filter((value): value is string => Boolean(value)) : [];
  const fallback = validRpcUrl(DEFAULT_RPC_URLS[network]);
  return [...new Set([...configured, ...(fallback ? [fallback] : [])])];
}

export function createEvmRpcProvider(network: Exclude<RpcNetwork, "solana" | "bitcoin">, rpcUrl?: string): ethers.JsonRpcProvider {
  const endpoint = rpcUrl ?? getRpcUrls(network)[0];
  const request = new ethers.FetchRequest(endpoint);
  request.timeout = 8_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

export async function withEvmRpc<T>(
  network: Exclude<RpcNetwork, "solana" | "bitcoin">,
  operation: (provider: ethers.JsonRpcProvider) => Promise<T>,
): Promise<T> {
  let lastError: unknown;
  const endpoints = getRpcUrls(network);
  for (const [index, endpoint] of endpoints.entries()) {
    const breaker = getCircuitBreaker(`rpc-${network}-${index}`, { failureThreshold: 3, resetTimeoutMs: 15_000 });
    try {
      return await breaker.execute(() => operation(createEvmRpcProvider(network, endpoint)));
    } catch (error) {
      lastError = error;
    }
  }
  void lastError;
  throw new Error(`RPC unavailable for ${network}`);
}

export async function withRpcHttp<T>(network: RpcNetwork, operation: (endpoint: string) => Promise<T>): Promise<T> {
  let lastError: unknown;
  const endpoints = getRpcUrls(network);
  for (const [index, endpoint] of endpoints.entries()) {
    const breaker = getCircuitBreaker(`rpc-${network}-${index}`, { failureThreshold: 3, resetTimeoutMs: 15_000 });
    try {
      return await breaker.execute(() => operation(endpoint));
    } catch (error) {
      lastError = error;
      if (index < endpoints.length - 1) await new Promise((resolve) => setTimeout(resolve, Math.min(150 * (index + 1), 450)));
    }
  }
  void lastError;
  throw new Error(`RPC unavailable for ${network}`);
}

export function getPrimaryRpcUrl(network: RpcNetwork): string {
  return getRpcUrls(network)[0];
}
