import { describe, expect, it, vi } from "vitest";
import { getContractSecurity } from "./contractSecurity";

describe("contract security safety states", () => {
  it("returns unknown for unsupported chains instead of a safe result", async () => {
    const result = await getContractSecurity("solana", "MintAddress");

    expect(result.status).toBe("unknown");
    expect(result.riskLevel).toBe("UNKNOWN");
    expect(result.score).toBeNull();
  });

  it("returns unknown for malformed EVM identifiers without calling the provider", async () => {
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    const result = await getContractSecurity("ethereum", "not-an-address");

    expect(result.status).toBe("unknown");
    expect(result.score).toBeNull();
    expect(fetchSpy).not.toHaveBeenCalled();
    fetchSpy.mockRestore();
  });
});
