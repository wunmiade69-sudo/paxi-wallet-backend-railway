/**
 * Checks a token's real on-chain liquidity via DexScreener's public API
 * (same source client/src/lib/wallet/dexAnalytics.ts uses) - used to
 * decide whether a community listing can skip manual admin review and go
 * straight to verified. A token nobody can actually trade with real
 * liquidity is exactly the kind of thing admin review exists to catch;
 * one that already has a healthy pool has already proven itself real in a
 * way that's harder to fake than just paying the listing fee.
 *
 * Phase 2: the same DexScreener response used for that auto-verify check
 * is also persisted into the market layer (dexes/liquidityPools/markets/
 * assetMarketData) - no extra API calls, just no longer throwing away data
 * that's already been fetched. Persistence is best-effort: it never blocks
 * or fails the liquidity check itself.
 */
import { and, eq } from "drizzle-orm";
import {
  assetMarketData,
  dexes,
  liquidityPools,
  markets,
  type Asset,
  type InsertAssetMarketData,
  type InsertLiquidityPool,
  type InsertMarket,
} from "../drizzle/schema";
import { getDb } from "./db";
import { addressesEqual, getOrCreateAsset } from "./assetRegistry";
import { setCachedAssetPrice } from "./redis";
import { fetchJson } from "./providers/http";

const DEXSCREENER_API = "https://api.dexscreener.com/latest/dex";

// Mirrors client/src/lib/wallet/dexAnalytics.ts's mapping - keep in sync.
const DEXSCREENER_CHAIN_ID: Record<string, string> = {
  ethereum: "ethereum",
  bsc: "bsc",
  solana: "solana",
  polygon: "polygon",
  arbitrum: "arbitrum",
};

/** Minimum USD liquidity (in the single deepest pair) to auto-verify without admin review. */
export const AUTO_VERIFY_LIQUIDITY_USD = 1000;

export interface DexScreenerPairRaw {
  chainId: string;
  dexId: string;
  pairAddress: string;
  /** DexScreener defines this as the BASE token's price in USD - it is NOT automatically the price of whichever token you looked up. See resolveTokenPriceUsd. */
  priceUsd: string;
  /** Base token's price expressed in quote-token units - lets a quote-side price be derived without a second API call. */
  priceNative?: string;
  liquidity?: { usd?: number };
  volume?: { h24?: number };
  priceChange?: { h24?: number };
  baseToken: { address: string; name: string; symbol: string };
  quoteToken: { address: string; name: string; symbol: string };
  info?: {
    header?: string;
    openGraph?: string;
    websites?: { label: string; url: string }[];
    socials?: { type: string; url: string }[];
  };
}

async function fetchDexScreenerPairs(network: string, contractAddress: string): Promise<DexScreenerPairRaw[]> {
  const chainSlug = DEXSCREENER_CHAIN_ID[network];
  if (!chainSlug) return [];
  try {
    const data = await fetchJson<{ pairs?: DexScreenerPairRaw[] }>(`${DEXSCREENER_API}/tokens/${encodeURIComponent(contractAddress)}`, "dexscreener");
    const pairs: DexScreenerPairRaw[] = Array.isArray(data?.pairs) ? data.pairs : [];
    return pairs.filter((p) => p.chainId === chainSlug);
  } catch {
    return []; // DexScreener hiccup shouldn't block a listing - falls back to manual review
  }
}

/**
 * The USD price of `tokenAddress` within `pair` - correct whether that
 * token is the base or the quote side. DexScreener's `priceUsd` is always
 * the BASE token's price; naively using it for whichever token you looked
 * up silently mispriced anything found as the quote side of its best pair
 * (e.g. looking up USDT and getting matched against a PAXI/USDT pair).
 *
 * Quote-side price is derived from priceUsd / priceNative: priceNative is
 * "how many quote-tokens does 1 base-token cost", so 1 quote-token costs
 * (priceUsd / priceNative) USD. Returns null if the token isn't actually
 * either side of this pair, or priceNative is missing/zero.
 *
 * `chainId` matters here because address comparison must be chain-aware -
 * EVM addresses compare case-insensitively, Solana/BTC/TON addresses are
 * case-sensitive (see addressesEqual in assetRegistry.ts).
 */
export function resolveTokenPriceUsd(chainId: string, pair: DexScreenerPairRaw, tokenAddress: string): number | null {
  const priceUsd = Number(pair.priceUsd);
  if (!Number.isFinite(priceUsd)) return null;

  if (addressesEqual(chainId, pair.baseToken.address, tokenAddress)) return priceUsd;

  if (addressesEqual(chainId, pair.quoteToken.address, tokenAddress)) {
    const priceNative = Number(pair.priceNative);
    if (!Number.isFinite(priceNative) || priceNative <= 0) return null;
    return priceUsd / priceNative;
  }

  return null; // shouldn't happen - caller passed a pair that doesn't involve this token
}

/** Unchanged signature/behavior for existing callers (listings.ts auto-verify check). */
export async function getTokenLiquidityUsd(network: string, contractAddress: string): Promise<number> {
  const pairs = await fetchDexScreenerPairs(network, contractAddress);
  if (pairs.length === 0) return 0;
  const best = pairs.reduce((a, b) => ((b.liquidity?.usd ?? 0) > (a.liquidity?.usd ?? 0) ? b : a));
  const liquidityUsd = Number(best.liquidity?.usd ?? 0);

  // Persist the deepest pair into the market layer. Best-effort - never lets a
  // persistence failure affect the liquidity number the caller already has.
  persistDexSnapshot(network, contractAddress, best).catch((err) =>
    console.warn("[dexLiquidity] persistDexSnapshot failed (non-fatal):", network, contractAddress, err),
  );

  return liquidityUsd;
}

/** Same DexScreener call as getTokenLiquidityUsd, but returns the full snapshot for callers that want price/volume too, not just liquidity. */
export async function getTokenMarketSnapshot(network: string, contractAddress: string): Promise<DexScreenerPairRaw | null> {
  const pairs = await fetchDexScreenerPairs(network, contractAddress);
  if (pairs.length === 0) return null;
  const best = pairs.reduce((a, b) => ((b.liquidity?.usd ?? 0) > (a.liquidity?.usd ?? 0) ? b : a));
  persistDexSnapshot(network, contractAddress, best).catch((err) =>
    console.warn("[dexLiquidity] persistDexSnapshot failed (non-fatal):", network, contractAddress, err),
  );
  return best;
}

async function getOrRegisterDexId(network: string, dexName: string): Promise<number | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const [dex] = await db
    .select({ id: dexes.id })
    .from(dexes)
    .where(and(eq(dexes.chainId, network), eq(dexes.name, dexName)))
    .limit(1);
  if (dex) return dex.id;

  // Unknown DEX for this chain (not in PAXI_DEXES seed) - register it now so future
  // snapshots resolve instantly. name = DexScreener's dexId (e.g. "pancakeswap").
  const values = { chainId: network, name: dexName };
  await db.insert(dexes).values(values).onDuplicateKeyUpdate({ set: values });
  const [row] = await db.select({ id: dexes.id }).from(dexes).where(and(eq(dexes.chainId, network), eq(dexes.name, dexName))).limit(1);
  return row?.id;
}

export async function persistDexSnapshot(network: string, contractAddress: string, pair: DexScreenerPairRaw): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const dexId = await getOrRegisterDexId(network, pair.dexId);
  if (!dexId) return;

  const baseAsset = await getOrCreateAsset({
    chainId: network,
    identifier: pair.baseToken.address,
    symbol: pair.baseToken.symbol,
    name: pair.baseToken.name,
  });
  const quoteAsset = await getOrCreateAsset({
    chainId: network,
    identifier: pair.quoteToken.address,
    symbol: pair.quoteToken.symbol,
    name: pair.quoteToken.name,
  });
  if (!baseAsset || !quoteAsset) return;

  const liquidityUsd = pair.liquidity?.usd != null ? String(pair.liquidity.usd) : null;
  const volume24hUsd = pair.volume?.h24 != null ? String(pair.volume.h24) : null;

  const poolValues: InsertLiquidityPool = {
    chainId: network,
    dexId,
    poolAddress: pair.pairAddress,
    asset0Id: baseAsset.id,
    asset1Id: quoteAsset.id,
    liquidityUsd,
    volume24hUsd,
  };
  await db.insert(liquidityPools).values(poolValues).onDuplicateKeyUpdate({ set: poolValues });

  const [pool] = await db
    .select({ id: liquidityPools.id })
    .from(liquidityPools)
    .where(and(eq(liquidityPools.chainId, network), eq(liquidityPools.poolAddress, pair.pairAddress)))
    .limit(1);

  // The token actually looked up (base OR quote - see resolveTokenPriceUsd) is
  // the one whose canonical assetMarketData row this snapshot updates.
  const isBaseTheLookedUpToken = addressesEqual(network, pair.baseToken.address, contractAddress);
  const pricedAsset: Asset = isBaseTheLookedUpToken ? baseAsset : quoteAsset;
  const pairAsset: Asset = isBaseTheLookedUpToken ? quoteAsset : baseAsset;
  const priceUsd = resolveTokenPriceUsd(network, pair, contractAddress);

  if (pool) {
    const marketValues: InsertMarket = {
      assetId: pricedAsset.id,
      venueType: "dex",
      venueId: pair.dexId,
      pairAssetId: pairAsset.id,
      poolId: pool.id,
      status: "active",
    };
    await db.insert(markets).values(marketValues).onDuplicateKeyUpdate({ set: marketValues });
  }

  if (priceUsd != null) {
    const change24h = isBaseTheLookedUpToken ? (pair.priceChange?.h24 ?? null) : null;
    const marketDataValues: InsertAssetMarketData = {
      assetId: pricedAsset.id,
      priceUsd: String(priceUsd),
      // DexScreener's priceChange/volume are reported for the pair's base
      // token - only trustworthy to attribute directly when the token we're
      // pricing IS the base side. For the quote side, leave them unset
      // rather than silently mislabeling the base token's stats as its own.
      priceChange24h: isBaseTheLookedUpToken && change24h != null ? String(change24h) : undefined,
      volume24hUsd: isBaseTheLookedUpToken ? volume24hUsd : undefined,
      liquidityUsd,
      source: "dexscreener",
    };
    await db.insert(assetMarketData).values(marketDataValues).onDuplicateKeyUpdate({ set: marketDataValues });

    // Keep Redis in step - this write happens outside priceEngine.ts's own
    // refresh path (e.g. during the listings.ts auto-verify check), so
    // without this a stale Redis entry could shadow this fresher MySQL row
    // until its own TTL expires.
    await setCachedAssetPrice(`${network}:${pricedAsset.identifier}`, { priceUsd, change24h, source: "dexscreener" });
  }
}
