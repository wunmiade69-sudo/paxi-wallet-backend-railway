import { describe, expect, it } from "vitest";
import { buildNormalizedFeeBreakdown } from "./feeBreakdown";

describe("normalized fee breakdown", () => {
  it("keeps fee components separate and sums them with exact decimal arithmetic", () => {
    expect(buildNormalizedFeeBreakdown({
      feeCurrency: "usd",
      networkFee: "0.10",
      paxiFee: "0.30",
      routeFee: "0.025001",
      bridgeFee: "0.004999",
      relayerFee: null,
      estimatedReceived: "99.57",
    })).toEqual({
      feeCurrency: "USD",
      networkFee: "0.1",
      paxiFee: "0.3",
      routeFee: "0.025001",
      bridgeFee: "0.004999",
      totalFee: "0.43",
      estimatedReceived: "99.57",
    });
  });

  it("rejects negative, over-precise, and malformed components", () => {
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "USD", paxiFee: "-0.1" })).toThrow();
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "USD", paxiFee: "0.1234567" })).toThrow();
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "USD", paxiFee: "not-a-number" })).toThrow();
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "", paxiFee: "0" })).toThrow();
  });
});
