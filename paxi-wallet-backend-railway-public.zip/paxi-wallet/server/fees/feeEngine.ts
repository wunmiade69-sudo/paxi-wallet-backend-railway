import { and, eq } from "drizzle-orm";
import {
  feeConfig as feeConfigTable,
  feeRecords,
  type FeeRecord,
} from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import {
  DEFAULT_FEE_SCHEDULE,
  type CachedFeeConfig,
  type FeeOperation,
  getCachedFeeConfig,
  setCachedFeeConfig,
} from "./feeConfig";

const USD_SCALE = 1_000_000n;
const USD_PATTERN = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/;
const TX_HASH_PATTERN = /^[A-Za-z0-9:_-]{1,128}$/;
const CHAIN_PATTERN = /^[A-Za-z0-9._:-]{1,32}$/;

export interface FeeCalculation {
  operation: FeeOperation;
  chainType: string;
  inputAmountUsd: string;
  paxiFeeUsd: string;
  networkFeeEstimateUsd: string;
  totalFeeUsd: string;
  breakdown: {
    percentageBps: number;
    percentageFeeUsd: string;
    fixedFeeUsd: string;
    networkFeeUsd: string;
  };
}

export interface RecordFeeParams {
  userOpenId: string;
  operation: FeeOperation;
  chainType: string;
  inputAmountUsd: string;
  networkFeeEstimateUsd?: string;
  activityEventId?: number | null;
  transactionHash?: string | null;
  status?: "pending" | "confirmed" | "failed";
}

function parseUsd(value: string, field: string): bigint {
  if (!USD_PATTERN.test(value)) throw new Error(`${field} must be a non-negative USD amount with at most 6 fractional digits`);
  const [whole, fractional = ""] = value.split(".");
  return BigInt(whole) * USD_SCALE + BigInt(fractional.padEnd(6, "0") || "0");
}

function formatUsd(value: bigint): string {
  if (value < 0n) throw new Error("USD amount cannot be negative");
  const whole = value / USD_SCALE;
  const fractional = (value % USD_SCALE).toString().padStart(6, "0").replace(/0+$/, "");
  return fractional ? `${whole.toString()}.${fractional}` : whole.toString();
}

function addUsd(...values: bigint[]): bigint {
  return values.reduce((sum, value) => sum + value, 0n);
}

function assertPercentageBps(value: number): void {
  if (!Number.isSafeInteger(value) || value < 0 || value > 10_000) {
    throw new Error("Invalid fee percentage");
  }
}

function assertFeeConfig(config: CachedFeeConfig): CachedFeeConfig {
  assertPercentageBps(config.percentageBps);
  parseUsd(config.fixedUsd, "fixedUsd");
  if (!config.chainType || !CHAIN_PATTERN.test(config.chainType)) throw new Error("Invalid fee chain configuration");
  return config;
}

function assertUserOpenId(value: string): void {
  if (!value || value.length > 64) throw new Error("Invalid user identifier");
}

function assertOperation(operation: string): asserts operation is FeeOperation {
  if (!DEFAULT_FEE_SCHEDULE.some((item) => item.operation === operation)) throw new Error("Invalid fee operation");
}

function assertChainType(chainType: string): void {
  if (!CHAIN_PATTERN.test(chainType)) throw new Error("Invalid chain type");
}

function toCachedConfig(row: typeof feeConfigTable.$inferSelect): CachedFeeConfig {
  return {
    operation: row.operation as FeeOperation,
    chainType: row.chainType,
    percentageBps: row.percentageBps,
    fixedUsd: row.fixedUsd,
    isActive: row.isActive,
    updatedAtMs: row.updatedAt.getTime(),
  };
}

export async function getFeeConfig(operation: FeeOperation, chainType: string): Promise<CachedFeeConfig> {
  assertOperation(operation);
  assertChainType(chainType);
  const normalizedChainType = chainType.toLowerCase();
  const cached = await getCachedFeeConfig(operation, normalizedChainType);
  if (cached?.isActive) return assertFeeConfig(cached);

  const db = await getReadDb();
  if (!db) throw new Error("Database not available");
  const [exact] = await db
    .select()
    .from(feeConfigTable)
    .where(and(eq(feeConfigTable.operation, operation), eq(feeConfigTable.chainType, normalizedChainType), eq(feeConfigTable.isActive, true)))
    .limit(1);
  const [fallback] = exact
    ? [exact]
    : await db
        .select()
        .from(feeConfigTable)
        .where(and(eq(feeConfigTable.operation, operation), eq(feeConfigTable.chainType, "any"), eq(feeConfigTable.isActive, true)))
        .limit(1);
  if (!fallback) throw new Error(`No active fee configuration for ${operation}/${normalizedChainType}`);
  const config = assertFeeConfig(toCachedConfig(fallback));
  await setCachedFeeConfig(config);
  return config;
}

export async function calculateFee(
  operation: FeeOperation,
  chainType: string,
  inputAmountUsd: string,
  networkFeeEstimateUsd = "0",
): Promise<FeeCalculation> {
  assertOperation(operation);
  assertChainType(chainType);
  const amountMicros = parseUsd(inputAmountUsd, "inputAmountUsd");
  const networkMicros = parseUsd(networkFeeEstimateUsd, "networkFeeEstimateUsd");
  const config = await getFeeConfig(operation, chainType);
  const percentageMicros = (amountMicros * BigInt(config.percentageBps) + 9_999n) / 10_000n;
  const fixedMicros = parseUsd(config.fixedUsd, "fixedUsd");
  const paxiMicros = addUsd(percentageMicros, fixedMicros);
  const totalMicros = addUsd(paxiMicros, networkMicros);
  return {
    operation,
    chainType: chainType.toLowerCase(),
    inputAmountUsd,
    paxiFeeUsd: formatUsd(paxiMicros),
    networkFeeEstimateUsd: formatUsd(networkMicros),
    totalFeeUsd: formatUsd(totalMicros),
    breakdown: {
      percentageBps: config.percentageBps,
      percentageFeeUsd: formatUsd(percentageMicros),
      fixedFeeUsd: formatUsd(fixedMicros),
      networkFeeUsd: formatUsd(networkMicros),
    },
  };
}

/**
 * Write-only fee audit path. There is intentionally no update operation: a
 * later lifecycle state is a new immutable record or an activity status change.
 */
export async function recordFee(params: RecordFeeParams): Promise<FeeRecord> {
  assertUserOpenId(params.userOpenId);
  assertOperation(params.operation);
  assertChainType(params.chainType);
  if (params.activityEventId != null && (!Number.isSafeInteger(params.activityEventId) || params.activityEventId <= 0)) {
    throw new Error("Invalid activity event id");
  }
  if (params.transactionHash != null && !TX_HASH_PATTERN.test(params.transactionHash)) throw new Error("Invalid transaction hash");

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (params.activityEventId != null) {
    const [existing] = await db.select().from(feeRecords).where(eq(feeRecords.activityEventId, params.activityEventId)).limit(1);
    if (existing) return existing;
  }
  if (params.transactionHash) {
    const [existing] = await db
      .select()
      .from(feeRecords)
      .where(and(eq(feeRecords.userOpenId, params.userOpenId), eq(feeRecords.operation, params.operation), eq(feeRecords.transactionHash, params.transactionHash)))
      .limit(1);
    if (existing) return existing;
  }

  const calculation = await calculateFee(
    params.operation,
    params.chainType,
    params.inputAmountUsd,
    params.networkFeeEstimateUsd ?? "0",
  );
  const insertValues = {
    userOpenId: params.userOpenId,
    activityEventId: params.activityEventId ?? null,
    operation: params.operation,
    chainType: params.chainType.toLowerCase(),
    inputAmountUsd: calculation.inputAmountUsd,
    paxiFeeUsd: calculation.paxiFeeUsd,
    networkFeeUsd: calculation.networkFeeEstimateUsd,
    totalFeeUsd: calculation.totalFeeUsd,
    transactionHash: params.transactionHash ?? null,
    status: params.status ?? "pending",
  } as const;

  try {
    const result = await db.insert(feeRecords).values(insertValues);
    const insertedId = Number((result as unknown as { insertId?: number | string }).insertId);
    if (!Number.isSafeInteger(insertedId) || insertedId <= 0) throw new Error("Fee insert did not return an id");
    const [row] = await db.select().from(feeRecords).where(eq(feeRecords.id, insertedId)).limit(1);
    if (!row) throw new Error("Fee insert could not be reloaded");
    return row;
  } catch (error) {
    if (params.activityEventId != null) {
      const [concurrent] = await db.select().from(feeRecords).where(eq(feeRecords.activityEventId, params.activityEventId)).limit(1);
      if (concurrent) return concurrent;
    }
    if (params.transactionHash) {
      const [concurrent] = await db
        .select()
        .from(feeRecords)
        .where(and(eq(feeRecords.userOpenId, params.userOpenId), eq(feeRecords.operation, params.operation), eq(feeRecords.transactionHash, params.transactionHash)))
        .limit(1);
      if (concurrent) return concurrent;
    }
    throw error;
  }
}

export async function seedDefaultFeeConfig(): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  for (const defaults of DEFAULT_FEE_SCHEDULE) {
    await db
      .insert(feeConfigTable)
      .values({ ...defaults, isActive: true })
      .onDuplicateKeyUpdate({ set: { operation: defaults.operation } });
  }
}
