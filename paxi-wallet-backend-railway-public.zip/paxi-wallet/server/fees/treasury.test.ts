import { describe, expect, it } from "vitest";
import { getTreasuryConfiguration, validateTreasuryAddress } from "./treasury";

describe("chain-aware treasury validation", () => {
  it("normalizes a valid EVM treasury address and rejects malformed values", () => {
    expect(validateTreasuryAddress("ethereum", "0x7f522D2639DE092d67668b5A2122bADA2d9B035f")).toBe(
      "0x7f522D2639DE092d67668b5A2122bADA2d9B035f",
    );
    expect(() => validateTreasuryAddress("bsc", "not-an-evm-address")).toThrow(/Invalid bsc EVM treasury address/);
    expect(() => validateTreasuryAddress("ethereum", "")).toThrow(/required/);
  });

  it("validates Solana addresses independently of EVM addresses", () => {
    const solana = "So11111111111111111111111111111111111111112";
    expect(validateTreasuryAddress("solana", solana)).toBe(solana);
    expect(() => validateTreasuryAddress("solana", "0x0000000000000000000000000000000000000001")).toThrow(/Invalid Solana/);
  });

  it("validates Bitcoin addresses independently of EVM addresses", () => {
    const bitcoin = "1BoatSLRHtKNngkdXEeobR76b53LETtpyT";
    expect(() => validateTreasuryAddress("bitcoin", "0x0000000000000000000000000000000000000001")).toThrow(/Invalid Bitcoin/);
    expect(() => validateTreasuryAddress("bitcoin", bitcoin)).not.toThrow();
  });

  it("fails closed when no EVM treasury is explicitly configured", () => {
    if (process.env.PAXI_TREASURY_ADDRESS) return;
    const ethereum = getTreasuryConfiguration("ethereum");
    expect(ethereum.configured).toBe(false);
    expect(ethereum.settlementEnabled).toBe(false);
    expect(ethereum.address).toBeNull();
    expect(ethereum.reason).toMatch(/PAXI_TREASURY_ADDRESS/);
  });

  it("reports non-EVM settlement as disabled even when validation configuration is present or absent", () => {
    const solana = getTreasuryConfiguration("solana");
    const bitcoin = getTreasuryConfiguration("bitcoin");
    expect(solana.settlementEnabled).toBe(false);
    expect(bitcoin.settlementEnabled).toBe(false);
    expect(solana.reason).toMatch(/not implemented/);
    expect(bitcoin.reason).toMatch(/not implemented/);
  });
});
