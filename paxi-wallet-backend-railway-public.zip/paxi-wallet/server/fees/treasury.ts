import { getAddress } from "ethers";
import { PublicKey } from "@solana/web3.js";
import * as bitcoin from "bitcoinjs-lib";
import { ENV } from "../_core/env";

export type TreasuryNetwork = "ethereum" | "bsc" | "polygon" | "arbitrum" | "solana" | "bitcoin";
export type TreasuryFamily = "evm" | "solana" | "bitcoin";

export interface TreasuryConfiguration {
  network: TreasuryNetwork;
  family: TreasuryFamily;
  address: string | null;
  configured: boolean;
  settlementEnabled: boolean;
  reason?: string;
}

function isEvmNetwork(network: TreasuryNetwork): boolean {
  return ["ethereum", "bsc", "polygon", "arbitrum"].includes(network);
}

export function validateTreasuryAddress(network: TreasuryNetwork, address: string): string {
  const value = address.trim();
  if (!value) throw new Error(`${network} treasury address is required`);

  if (isEvmNetwork(network)) {
    try {
      return getAddress(value);
    } catch {
      throw new Error(`Invalid ${network} EVM treasury address`);
    }
  }

  if (network === "solana") {
    try {
      return new PublicKey(value).toBase58();
    } catch {
      throw new Error("Invalid Solana treasury address");
    }
  }

  try {
    bitcoin.address.toOutputScript(value, bitcoin.networks.bitcoin);
    return value;
  } catch {
    throw new Error("Invalid Bitcoin treasury address");
  }
}

function evmConfiguration(network: TreasuryNetwork): TreasuryConfiguration {
  const address = validateTreasuryAddress(network, ENV.paxiTreasuryAddress);
  return {
    network,
    family: "evm",
    address,
    configured: true,
    settlementEnabled: network === "ethereum" || network === "bsc",
    ...(network === "ethereum" || network === "bsc"
      ? {}
      : { reason: "Address validation is available, but current fee settlement verification is limited to Ethereum and BSC." }),
  };
}

export function getTreasuryConfiguration(network: TreasuryNetwork): TreasuryConfiguration {
  if (isEvmNetwork(network)) return evmConfiguration(network);

  if (network === "solana") {
    if (!ENV.paxiSolanaTreasuryAddress) {
      return {
        network,
        family: "solana",
        address: null,
        configured: false,
        settlementEnabled: false,
        reason: "No Solana treasury is configured; Solana fee settlement is not implemented.",
      };
    }
    return {
      network,
      family: "solana",
      address: validateTreasuryAddress(network, ENV.paxiSolanaTreasuryAddress),
      configured: true,
      settlementEnabled: false,
      reason: "Solana treasury validation is available, but fee settlement verification is not implemented.",
    };
  }

  if (!ENV.paxiBitcoinTreasuryAddress) {
    return {
      network,
      family: "bitcoin",
      address: null,
      configured: false,
      settlementEnabled: false,
      reason: "No Bitcoin treasury is configured; Bitcoin fee settlement is not implemented.",
    };
  }
  return {
    network,
    family: "bitcoin",
    address: validateTreasuryAddress(network, ENV.paxiBitcoinTreasuryAddress),
    configured: true,
    settlementEnabled: false,
    reason: "Bitcoin treasury validation is available, but fee settlement verification is not implemented.",
  };
}

export function listTreasuryConfigurations(): TreasuryConfiguration[] {
  return (["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"] as TreasuryNetwork[]).map(getTreasuryConfiguration);
}
