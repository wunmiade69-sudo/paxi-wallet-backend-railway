import { ENV } from "./_core/env";

export type MarketChain = "ethereum" | "bsc" | "base" | "polygon" | "arbitrum" | "solana" | "bitcoin";

export interface CanonicalMarketIdentity {
  chain: MarketChain | null;
  contractAddress: string | null;
  coinId?: string | null;
}

export interface NormalizedProviderToken {
  id: string;
  symbol: string;
  name: string;
  chain: MarketChain | null;
  contractAddress: string | null;
  decimals: number | null;
  image: string;
  currentPrice: number | null;
  marketCap: number | null;
  marketCapRank: number | null;
  liquidity: number | null;
  volume24h: number | null;
  priceChangePercent24h: number | null;
  verificationStatus: "verified" | "unverified";
  securityStatus: "available" | "unavailable";
  source: "birdeye" | "dexpaprika" | "coingecko";
  /** Providers that contributed at least one normalized field to this identity. */
  sources: Array<"birdeye" | "dexpaprika" | "coingecko">;
  providerId: string | null;
  marketDataAvailable: boolean;
}

export interface NormalizedChartPoint {
  timestamp: number;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number;
  volume: number | null;
}

const BIRDEYE_BASE = "https://public-api.birdeye.so";
const DEXPAPRIKA_BASE = "https://api.dexpaprika.com";
const TIMEOUT_MS = 8_000;

const NETWORK_ALIASES: Record<string, MarketChain> = {
  ethereum: "ethereum",
  eth: "ethereum",
  "binance-smart-chain": "bsc",
  bsc: "bsc",
  bnb: "bsc",
  base: "base",
  "base-mainnet": "base",
  polygon: "polygon",
  "polygon-pos": "polygon",
  arbitrum: "arbitrum",
  "arbitrum-one": "arbitrum",
  solana: "solana",
  bitcoin: "bitcoin",
};

export function normalizeMarketChain(value: unknown): MarketChain | null {
  if (typeof value !== "string") return null;
  return NETWORK_ALIASES[value.trim().toLowerCase()] ?? null;
}

export function normalizeProviderAddress(chain: string | null | undefined, value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > 128) return null;
  return chain && ["ethereum", "bsc", "base", "polygon", "arbitrum"].includes(chain.toLowerCase())
    ? trimmed.toLowerCase()
    : trimmed;
}

export function normalizeAddress(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > 128) return null;
  return trimmed;
}

export function isLikelyAddressQuery(value: string): boolean {
  const query = value.trim();
  return /^0x[a-fA-F0-9]{40}$/.test(query) || /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(query);
}

function finiteNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function stringValue(...values: unknown[]): string {
  for (const value of values) if (typeof value === "string" && value.trim()) return value.trim();
  return "";
}

function safeImage(value: unknown): string {
  const image = stringValue(value);
  return /^https?:\/\//i.test(image) ? image : "";
}

function pickArray(payload: any): any[] {
  const candidates = [payload?.data, payload?.data?.items, payload?.data?.tokens, payload?.data?.results, payload?.items, payload?.tokens, payload?.results, payload];
  return candidates.find(Array.isArray) ?? [];
}

function headersFor(provider: "birdeye" | "dexpaprika", chain?: MarketChain | null): Record<string, string> {
  if (provider === "birdeye") {
    return {
      accept: "application/json",
      ...(ENV.birdeyeApiKey ? { "X-API-KEY": ENV.birdeyeApiKey } : {}),
      ...(chain && chain !== "bitcoin" ? { "x-chain": chain } : {}),
    };
  }
  return {
    accept: "application/json",
    ...(ENV.dexpaprikaApiKey ? { authorization: ENV.dexpaprikaApiKey } : {}),
  };
}

async function fetchJson<T>(url: string, headers: Record<string, string>): Promise<T> {
  const response = await fetch(url, { headers, signal: AbortSignal.timeout(TIMEOUT_MS) });
  if (!response.ok) throw new Error(`provider request failed (${response.status})`);
  return (await response.json()) as T;
}

function normalizeToken(raw: any, source: "birdeye" | "dexpaprika", requestedChain?: MarketChain | null): NormalizedProviderToken | null {
  const chain = normalizeMarketChain(raw?.chain ?? raw?.network ?? raw?.chainId ?? raw?.platform ?? requestedChain);
  const address = normalizeProviderAddress(chain, raw?.address ?? raw?.token_address ?? raw?.tokenAddress ?? raw?.mint ?? raw?.contract_address ?? raw?.contractAddress);
  const symbol = stringValue(raw?.symbol, raw?.ticker, raw?.base_symbol);
  const name = stringValue(raw?.name, raw?.token_name, raw?.base_name) || symbol || "Unknown token";
  if (!symbol && !address) return null;

  const price = finiteNumber(raw?.price_usd ?? raw?.priceUsd ?? raw?.price ?? raw?.summary?.price_usd ?? raw?.price?.value);
  const liquidity = finiteNumber(raw?.liquidity_usd ?? raw?.liquidityUsd ?? raw?.liquidity ?? raw?.summary?.liquidity_usd);
  const volume = finiteNumber(raw?.volume24h_usd ?? raw?.volume24hUsd ?? raw?.volume_24h ?? raw?.volume24h ?? raw?.summary?.volume_24h_usd ?? raw?.volume_usd);
  const change = finiteNumber(raw?.price_change_24h ?? raw?.priceChange24h ?? raw?.price_change_percentage_24h ?? raw?.priceChangePercent24h);
  const providerId = stringValue(raw?.id, raw?.token_id, raw?.address, raw?.mint) || null;

  return {
    id: `${source}:${chain ?? "unknown"}:${address ?? providerId ?? symbol.toLowerCase()}`,
    symbol: symbol.toUpperCase(),
    name,
    chain,
    contractAddress: address,
    decimals: finiteNumber(raw?.decimals),
    image: safeImage(raw?.logoURI ?? raw?.logo_url ?? raw?.logo ?? raw?.image ?? raw?.icon),
    currentPrice: price,
    marketCap: finiteNumber(raw?.market_cap_usd ?? raw?.marketCapUsd ?? raw?.market_cap ?? raw?.marketCap),
    marketCapRank: finiteNumber(raw?.market_cap_rank ?? raw?.marketCapRank),
    liquidity,
    volume24h: volume,
    priceChangePercent24h: change,
    verificationStatus: "unverified",
    securityStatus: "unavailable",
    source,
    sources: [source],
    providerId,
    marketDataAvailable: price !== null || liquidity !== null || volume !== null,
  };
}

function providerIdentityKey(token: NormalizedProviderToken): string {
  if (!token.chain || !token.contractAddress) return `${token.source}:${token.id}`;
  const address = ["ethereum", "bsc", "base", "polygon", "arbitrum"].includes(token.chain)
    ? token.contractAddress.toLowerCase()
    : token.contractAddress;
  return `${token.chain}:${address}`;
}

export function dedupeProviderTokens(tokens: NormalizedProviderToken[]): NormalizedProviderToken[] {
  const byIdentity = new Map<string, NormalizedProviderToken>();
  for (const token of tokens) {
    const identity = providerIdentityKey(token);
    const existing = byIdentity.get(identity);
    if (!existing) {
      byIdentity.set(identity, token);
      continue;
    }
    byIdentity.set(identity, {
      ...existing,
      image: existing.image || token.image,
      currentPrice: existing.currentPrice ?? token.currentPrice,
      marketCap: existing.marketCap ?? token.marketCap,
      marketCapRank: existing.marketCapRank ?? token.marketCapRank,
      liquidity: existing.liquidity ?? token.liquidity,
      volume24h: existing.volume24h ?? token.volume24h,
      priceChangePercent24h: existing.priceChangePercent24h ?? token.priceChangePercent24h,
      decimals: existing.decimals ?? token.decimals,
      source: existing.source === "coingecko" ? token.source : existing.source,
      sources: Array.from(new Set([...existing.sources, ...token.sources])),
      marketDataAvailable: existing.marketDataAvailable || token.marketDataAvailable,
    });
  }
  return Array.from(byIdentity.values());
}

export async function searchBirdeyeTokens(query: string): Promise<NormalizedProviderToken[]> {
  if (!ENV.birdeyeApiKey) return [];
  const chains: MarketChain[] = ["ethereum", "bsc", "solana", "polygon", "arbitrum", "base"];
  const url = `${BIRDEYE_BASE}/defi/v3/search?keyword=${encodeURIComponent(query.trim())}`;
  const results = await Promise.all(chains.map(async (chain) => {
    try {
      const payload = await fetchJson<any>(url, headersFor("birdeye", chain));
      return pickArray(payload)
        .map((item) => normalizeToken(item, "birdeye", chain))
        .filter(Boolean) as NormalizedProviderToken[];
    } catch (error) {
      console.warn(`[marketData] Birdeye ${chain} search unavailable:`, error instanceof Error ? error.message : "provider error");
      return [];
    }
  }));
  return results.flat();
}

export async function searchDexPaprikaTokens(query: string): Promise<NormalizedProviderToken[]> {
  const url = `${DEXPAPRIKA_BASE}/search?query=${encodeURIComponent(query.trim())}`;
  try {
    const payload = await fetchJson<any>(url, headersFor("dexpaprika"));
    return pickArray(payload).map((item) => normalizeToken(item, "dexpaprika")).filter(Boolean) as NormalizedProviderToken[];
  } catch (error) {
    console.warn("[marketData] DexPaprika search unavailable:", error instanceof Error ? error.message : "provider error");
    return [];
  }
}

export async function getBirdeyeToken(identity: CanonicalMarketIdentity): Promise<NormalizedProviderToken | null> {
  if (!ENV.birdeyeApiKey || !identity.chain || !identity.contractAddress) return null;
  const url = `${BIRDEYE_BASE}/defi/token_overview?address=${encodeURIComponent(identity.contractAddress)}`;
  try {
    const payload = await fetchJson<any>(url, headersFor("birdeye", identity.chain));
    return normalizeToken({ ...(payload?.data ?? payload), address: identity.contractAddress }, "birdeye", identity.chain);
  } catch (error) {
    console.warn("[marketData] Birdeye token overview unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

export async function getDexPaprikaToken(identity: CanonicalMarketIdentity): Promise<NormalizedProviderToken | null> {
  if (!identity.chain || !identity.contractAddress) return null;
  const url = `${DEXPAPRIKA_BASE}/networks/${identity.chain}/tokens/${encodeURIComponent(identity.contractAddress)}`;
  try {
    const payload = await fetchJson<any>(url, headersFor("dexpaprika", identity.chain));
    const data = payload?.data ?? payload;
    return normalizeToken({ ...data, address: identity.contractAddress, network: identity.chain }, "dexpaprika", identity.chain);
  } catch (error) {
    console.warn("[marketData] DexPaprika token unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

export interface ProviderChartResult {
  points: NormalizedChartPoint[];
  source: "birdeye" | "dexpaprika";
  historicalAvailable: boolean;
  providerId?: string | null;
}

export type MarketChartTimeframe = "1H" | "1D" | "1W" | "1M" | "3M" | "1Y" | "ALL";

type ChartWindowInput = number | "max" | MarketChartTimeframe;

function chartWindow(input: ChartWindowInput): { timeFrom: number; timeTo: number; birdeyeType: string; dexInterval: string } {
  const timeTo = Math.floor(Date.now() / 1000);
  let windowSeconds: number;
  let birdeyeType: string;
  let dexInterval: string;

  if (typeof input === "string" && input !== "max") {
    switch (input) {
      case "1H":
        windowSeconds = 60 * 60;
        birdeyeType = "1m";
        dexInterval = "1m";
        break;
      case "1D":
        windowSeconds = 24 * 60 * 60;
        birdeyeType = "1H";
        dexInterval = "1h";
        break;
      case "1W":
        windowSeconds = 7 * 24 * 60 * 60;
        birdeyeType = "4H";
        dexInterval = "4h";
        break;
      case "1M":
        windowSeconds = 30 * 24 * 60 * 60;
        birdeyeType = "1D";
        dexInterval = "1d";
        break;
      case "3M":
        windowSeconds = 90 * 24 * 60 * 60;
        birdeyeType = "1D";
        dexInterval = "1d";
        break;
      case "1Y":
      case "ALL":
        windowSeconds = 365 * 24 * 60 * 60;
        birdeyeType = "1D";
        dexInterval = "1d";
        break;
    }
  } else {
    const boundedDays = input === "max" ? 365 : Math.max(1, Math.min(365, input));
    windowSeconds = boundedDays * 24 * 60 * 60;
    if (boundedDays <= 1) {
      birdeyeType = "1H";
      dexInterval = "1h";
    } else if (boundedDays <= 7) {
      birdeyeType = "4H";
      dexInterval = "4h";
    } else {
      birdeyeType = "1D";
      dexInterval = "1d";
    }
  }

  return { timeFrom: timeTo - windowSeconds, timeTo, birdeyeType, dexInterval };
}

function chartPoints(payload: any): NormalizedChartPoint[] {
  return pickArray(payload)
    .map((raw) => normalizeHistoricalPoint({
      ...raw,
      timestamp: raw?.timestamp ?? raw?.time ?? raw?.unixTime ?? raw?.time_close ?? raw?.time_open,
    }))
    .filter(Boolean)
    .sort((a, b) => (a as NormalizedChartPoint).timestamp - (b as NormalizedChartPoint).timestamp) as NormalizedChartPoint[];
}

export async function getBirdeyeChart(identity: CanonicalMarketIdentity, days: ChartWindowInput): Promise<ProviderChartResult | null> {
  if (!ENV.birdeyeApiKey || !identity.chain || identity.chain === "bitcoin" || !identity.contractAddress) return null;
  const window = chartWindow(days);
  const params = new URLSearchParams({
    address: identity.contractAddress,
    time_from: String(window.timeFrom),
    time_to: String(window.timeTo),
    type: window.birdeyeType,
  });
  try {
    const payload = await fetchJson<any>(`${BIRDEYE_BASE}/defi/ohlcv?${params.toString()}`, headersFor("birdeye", identity.chain));
    const points = chartPoints(payload);
    return points.length ? { points, source: "birdeye", historicalAvailable: true, providerId: identity.contractAddress } : null;
  } catch (error) {
    console.warn("[marketData] Birdeye OHLCV unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

function poolAddress(raw: any): string | null {
  return stringValue(raw?.pool_address, raw?.poolAddress, raw?.address, raw?.id) || null;
}

function poolScore(raw: any): number {
  return finiteNumber(raw?.volume_usd ?? raw?.volumeUsd ?? raw?.volume_24h_usd ?? raw?.volume24hUsd ?? raw?.liquidity_usd ?? raw?.liquidityUsd) ?? -1;
}

export async function getDexPaprikaChart(identity: CanonicalMarketIdentity, days: ChartWindowInput): Promise<ProviderChartResult | null> {
  if (!identity.chain || identity.chain === "bitcoin" || !identity.contractAddress) return null;
  const window = chartWindow(days);
  try {
    const poolSearchUrl = `${DEXPAPRIKA_BASE}/networks/${identity.chain}/pools/search?token_address=${encodeURIComponent(identity.contractAddress)}&limit=10`;
    const poolPayload = await fetchJson<any>(poolSearchUrl, headersFor("dexpaprika", identity.chain));
    const pools = pickArray(poolPayload).filter((pool) => poolAddress(pool)).sort((a, b) => poolScore(b) - poolScore(a));
    const selectedPool = pools[0];
    const selectedPoolAddress = selectedPool ? poolAddress(selectedPool) : null;
    if (!selectedPoolAddress) return null;

    const params = new URLSearchParams({
      start: new Date(window.timeFrom * 1000).toISOString(),
      end: new Date(window.timeTo * 1000).toISOString(),
      limit: "366",
      interval: window.dexInterval,
    });
    const ohlcvUrl = `${DEXPAPRIKA_BASE}/networks/${identity.chain}/pools/${encodeURIComponent(selectedPoolAddress)}/ohlcv?${params.toString()}`;
    const payload = await fetchJson<any>(ohlcvUrl, headersFor("dexpaprika", identity.chain));
    const points = chartPoints(payload);
    return points.length ? { points, source: "dexpaprika", historicalAvailable: true, providerId: selectedPoolAddress } : null;
  } catch (error) {
    console.warn("[marketData] DexPaprika OHLCV unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

export function mergeProviderToken(primary: NormalizedProviderToken, secondary: NormalizedProviderToken | null): NormalizedProviderToken {
  if (!secondary) return primary;
  return {
    ...primary,
    image: primary.image || secondary.image,
    symbol: primary.symbol || secondary.symbol,
    name: primary.name || secondary.name,
    currentPrice: primary.currentPrice ?? secondary.currentPrice,
    marketCap: primary.marketCap ?? secondary.marketCap,
    marketCapRank: primary.marketCapRank ?? secondary.marketCapRank,
    liquidity: primary.liquidity ?? secondary.liquidity,
    volume24h: primary.volume24h ?? secondary.volume24h,
    priceChangePercent24h: primary.priceChangePercent24h ?? secondary.priceChangePercent24h,
    decimals: primary.decimals ?? secondary.decimals,
    sources: Array.from(new Set([...primary.sources, ...secondary.sources])),
    marketDataAvailable: primary.marketDataAvailable || secondary.marketDataAvailable,
  };
}

function timestampValue(value: unknown): number | null {
  const numeric = finiteNumber(value);
  if (numeric !== null) return numeric;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

export function normalizeHistoricalPoint(raw: any): NormalizedChartPoint | null {
  const timestamp = timestampValue(raw?.timestamp ?? raw?.time ?? raw?.unixTime ?? raw?.t ?? raw?.time_close ?? raw?.time_open);
  const close = finiteNumber(raw?.close ?? raw?.price ?? raw?.value ?? raw?.c);
  if (timestamp === null || close === null) return null;
  const ts = timestamp < 10_000_000_000 ? timestamp * 1000 : timestamp;
  return {
    timestamp: ts,
    open: finiteNumber(raw?.open ?? raw?.o),
    high: finiteNumber(raw?.high ?? raw?.h),
    low: finiteNumber(raw?.low ?? raw?.l),
    close,
    volume: finiteNumber(raw?.volume ?? raw?.v),
  };
}

export function getProviderEnvStatus(): { birdeyeConfigured: boolean; dexPaprikaConfigured: boolean } {
  return { birdeyeConfigured: Boolean(ENV.birdeyeApiKey), dexPaprikaConfigured: Boolean(ENV.dexpaprikaApiKey) };
}
