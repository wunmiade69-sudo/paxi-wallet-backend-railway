import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

function source(relativePath: string): string {
  return readFileSync(resolve(process.cwd(), relativePath), "utf8");
}

describe("Phase 5 public API hardening", () => {
  it("rate-limits the OAuth callback with the dedicated authentication policy", () => {
    const oauth = source("server/_core/oauth.ts");
    expect(oauth).toMatch(/distributedAuthRateLimit/);
    expect(oauth).toMatch(/app\.get\("\/api\/oauth\/callback",\s*distributedAuthRateLimit/);
  });

  it("uses separate tRPC policies for reads, mutations, and Admin calls", () => {
    const limiter = source("server/_core/distributedRateLimit.ts");
    const bootstrap = source("server/_core/index.ts");
    expect(limiter).toContain('keyPrefix: "trpc-read"');
    expect(limiter).toContain('keyPrefix: "trpc-mutation"');
    expect(limiter).toContain('keyPrefix: "trpc-admin"');
    expect(bootstrap).toContain('app.use("/api/trpc", distributedTrpcRateLimit);');
    expect(bootstrap).not.toContain('app.use("/api/trpc", distributedPublicApiRateLimit);');
  });

  it("bounds market search and identity inputs", () => {
    const market = source("server/routers/market.ts");
    expect(market).toMatch(/query: z\.string\(\)\.trim\(\)\.min\(1\)\.max\(128\)/);
    expect(market).toMatch(/chain: z\.string\(\)\.trim\(\)\.min\(1\)\.max\(32\)/);
    expect(market).toMatch(/contractAddress: z\.string\(\)\.trim\(\)\.min\(1\)\.max\(128\)/);
  });

  it("validates contract-security addresses and encodes the upstream query", () => {
    const securityRouter = source("server/routers/security.ts");
    const provider = source("server/contractSecurity.ts");
    expect(securityRouter).toMatch(/z\.enum\(\["ethereum", "bsc"\]\)/);
    expect(securityRouter).toMatch(/0x\[0-9a-fA-F\]\{40\}/);
    expect(provider).toMatch(/url\.searchParams\.set\("contract_addresses", normalizedAddress\)/);
    expect(provider).toContain("if (!/^0x[0-9a-f]{40}$/.test(normalizedAddress)) return UNSUPPORTED_REPORT;");
  });

  it("never grants unlimited ERC-20 approvals in swap or bridge flows", () => {
    for (const relativePath of ["client/src/lib/wallet/swap.ts", "client/src/lib/wallet/bridge.ts"]) {
      const content = source(relativePath);
      expect(content, relativePath).not.toContain("MaxUint256");
      expect(content, relativePath).toMatch(/\.approve\([^,]+,\s*BigInt\(quote\.srcAmountUnits\)\)/);
    }
  });

  it("keeps the vulnerable SPL-token parser out of production call sites and dependencies", () => {
    for (const relativePath of [
      "client/src/lib/wallet/balances.ts",
      "client/src/lib/wallet/customTokens.ts",
      "client/src/lib/wallet/jupiterSwap.ts",
      "client/src/lib/wallet/send.ts",
    ]) {
      expect(source(relativePath), relativePath).not.toContain("@solana/spl-token");
    }
    const manifest = JSON.parse(readFileSync(resolve(process.cwd(), "package.json"), "utf8")) as {
      dependencies?: Record<string, string>;
    };
    expect(manifest.dependencies?.["@solana/spl-token"]).toBeUndefined();
    const lockfile = source("package-lock.json");
    expect(lockfile).not.toContain('node_modules/@solana/spl-token');
    expect(lockfile).not.toContain('node_modules/@solana/buffer-layout-utils');
    expect(lockfile).not.toContain('node_modules/bigint-buffer');
  });
});
