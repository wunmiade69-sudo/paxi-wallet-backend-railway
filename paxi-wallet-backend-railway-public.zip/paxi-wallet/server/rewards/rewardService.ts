import { createHash, randomBytes } from "node:crypto";
import { and, eq, gt, isNull, lt, or, sql } from "drizzle-orm";
import { ethers } from "ethers";
import {
  giftCodeRedemptions,
  giftCodes,
  referrals,
  referralProfiles,
  rewardClaims,
  rewardLedger,
  type GiftCode,
  type Referral,
  type ReferralProfile,
  type RewardLedgerEntry,
} from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import { allocateFromVerifiedWpaxiPools } from "./rewardPoolAllocation";

const CODE_PATTERN = /^[A-Z0-9][A-Z0-9_-]{5,31}$/;
const DECIMAL_PATTERN = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/;
const MAX_GIFT_REDEMPTIONS = 1_000_000;

function assertUser(value: string): void {
  if (!value || value.length > 64) throw new Error("Invalid user identifier");
}

function assertAmount(value: string): void {
  if (!DECIMAL_PATTERN.test(value) || value === "0") throw new Error("Reward amount must be a positive decimal");
}

function normalizeCode(value: string): string {
  const code = value.trim().toUpperCase();
  if (!CODE_PATTERN.test(code)) throw new Error("Invalid gift or referral code");
  return code;
}

export function hashRewardCode(value: string): string {
  return createHash("sha256").update(normalizeCode(value), "utf8").digest("hex");
}

function newInviteCode(): string {
  return `PAXI-${randomBytes(8).toString("hex").toUpperCase()}`;
}

function newGiftCode(): string {
  return `GIFT-${randomBytes(10).toString("hex").toUpperCase()}`;
}

function affectedRows(result: unknown): number {
  return Number((result as { affectedRows?: number }).affectedRows ?? 0);
}

export async function ensureReferralProfile(userOpenId: string): Promise<ReferralProfile> {
  assertUser(userOpenId);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(referralProfiles).where(eq(referralProfiles.userOpenId, userOpenId)).limit(1);
  if (existing[0]) return existing[0];

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const inviteCode = newInviteCode();
    try {
      await db.insert(referralProfiles).values({ userOpenId, inviteCode });
      const created = await db.select().from(referralProfiles).where(eq(referralProfiles.userOpenId, userOpenId)).limit(1);
      if (created[0]) return created[0];
    } catch {
      const concurrent = await db.select().from(referralProfiles).where(eq(referralProfiles.userOpenId, userOpenId)).limit(1);
      if (concurrent[0]) return concurrent[0];
    }
  }
  throw new Error("Could not create referral profile");
}

export async function attachReferral(inviteeOpenId: string, rawInviteCode: string): Promise<Referral> {
  assertUser(inviteeOpenId);
  const inviteCode = normalizeCode(rawInviteCode);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const profile = await db.select().from(referralProfiles).where(eq(referralProfiles.inviteCode, inviteCode)).limit(1);
  const inviter = profile[0];
  if (!inviter) throw new Error("Referral code not found");
  if (inviter.userOpenId === inviteeOpenId) throw new Error("You cannot refer yourself");

  const existing = await db.select().from(referrals).where(eq(referrals.inviteeOpenId, inviteeOpenId)).limit(1);
  if (existing[0]) {
    if (existing[0].inviterOpenId !== inviter.userOpenId) throw new Error("A referral is already attached to this user");
    return existing[0];
  }

  try {
    await db.insert(referrals).values({
      inviterOpenId: inviter.userOpenId,
      inviteeOpenId,
      inviteCode,
      rewardWalletAddress: inviter.rewardWalletAddress,
      status: "pending",
    });
  } catch {
    const concurrent = await db.select().from(referrals).where(eq(referrals.inviteeOpenId, inviteeOpenId)).limit(1);
    if (concurrent[0]) return concurrent[0];
    throw new Error("Could not attach referral");
  }
  const [created] = await db.select().from(referrals).where(eq(referrals.inviteeOpenId, inviteeOpenId)).limit(1);
  if (!created) throw new Error("Referral was not persisted");
  return created;
}

export async function setReferralRewardWallet(userOpenId: string, walletAddress: string): Promise<ReferralProfile> {
  assertUser(userOpenId);
  if (!ethers.isAddress(walletAddress)) throw new Error("A valid BSC reward wallet address is required");
  const normalizedWallet = ethers.getAddress(walletAddress);
  await ensureReferralProfile(userOpenId);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.transaction(async (tx) => {
    const updated = await tx.update(referralProfiles).set({ rewardWalletAddress: normalizedWallet }).where(eq(referralProfiles.userOpenId, userOpenId));
    if (affectedRows(updated) !== 1) throw new Error("Referral profile was not updated");
    await tx.update(referrals).set({ rewardWalletAddress: normalizedWallet }).where(and(eq(referrals.inviterOpenId, userOpenId), eq(referrals.status, "pending")));
    const [profile] = await tx.select().from(referralProfiles).where(eq(referralProfiles.userOpenId, userOpenId)).limit(1);
    if (!profile) throw new Error("Referral profile was not found after wallet update");
    return profile;
  });
}

export async function listMyReferrals(userOpenId: string): Promise<Referral[]> {
  assertUser(userOpenId);
  const db = await getReadDb();
  if (!db) return [];
  return db.select().from(referrals).where(eq(referrals.inviterOpenId, userOpenId));
}

export interface RewardCreditParams {
  userOpenId: string;
  sourceType: "referral" | "gift_code" | "airdrop" | "campaign" | "manual_adjustment";
  sourceId: string;
  idempotencyKey: string;
  assetSymbol: string;
  assetNetwork: string;
  assetContractAddress?: string | null;
  amount: string;
  metadata?: Record<string, unknown>;
  initialStatus?: "pending" | "claimable" | "approved";
}

export async function creditReward(params: RewardCreditParams): Promise<RewardLedgerEntry> {
  assertUser(params.userOpenId);
  assertAmount(params.amount);
  if (!params.sourceId || params.sourceId.length > 128) throw new Error("Invalid reward source");
  if (!params.idempotencyKey || params.idempotencyKey.length > 191) throw new Error("Invalid reward idempotency key");
  if (!params.assetSymbol || params.assetSymbol.length > 32) throw new Error("Invalid reward asset");
  if (!params.assetNetwork || params.assetNetwork.length > 32) throw new Error("Invalid reward network");

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(rewardLedger).where(eq(rewardLedger.idempotencyKey, params.idempotencyKey)).limit(1);
  if (existing[0]) return existing[0];

  try {
    const result = await db.insert(rewardLedger).values({
      userOpenId: params.userOpenId,
      sourceType: params.sourceType,
      sourceId: params.sourceId,
      assetSymbol: params.assetSymbol,
      assetNetwork: params.assetNetwork,
      assetContractAddress: params.assetContractAddress ?? null,
      amount: params.amount,
      status: params.initialStatus ?? "approved",
      idempotencyKey: params.idempotencyKey,
      metadata: params.metadata,
      approvedAt: params.initialStatus === "approved" || !params.initialStatus ? new Date() : null,
      claimableAt: params.initialStatus === "claimable" ? new Date() : null,
    });
    const insertedId = Number((result as unknown as { insertId?: number | string }).insertId);
    const [created] = await db.select().from(rewardLedger).where(eq(rewardLedger.id, insertedId)).limit(1);
    if (!created) throw new Error("Reward ledger entry could not be reloaded");
    return created;
  } catch (error) {
    const concurrent = await db.select().from(rewardLedger).where(eq(rewardLedger.idempotencyKey, params.idempotencyKey)).limit(1);
    if (concurrent[0]) return concurrent[0];
    throw error;
  }
}

export interface CreateGiftCodeParams {
  createdByOpenId: string;
  assetSymbol: string;
  assetNetwork: string;
  assetContractAddress?: string | null;
  rewardAmount: string;
  maxRedemptions: number;
  expiresAt?: Date | null;
}

export async function createGiftCode(params: CreateGiftCodeParams): Promise<{ giftCode: GiftCode; rawCode: string }> {
  assertUser(params.createdByOpenId);
  assertAmount(params.rewardAmount);
  if (!Number.isSafeInteger(params.maxRedemptions) || params.maxRedemptions <= 0 || params.maxRedemptions > MAX_GIFT_REDEMPTIONS) {
    throw new Error("Invalid maximum redemptions");
  }
  if (params.expiresAt && params.expiresAt.getTime() <= Date.now()) throw new Error("Gift-code expiry must be in the future");

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const rawCode = newGiftCode();
    try {
      await db.insert(giftCodes).values({
        codeHash: hashRewardCode(rawCode),
        codeHint: rawCode.slice(-4),
        assetSymbol: params.assetSymbol.trim().toUpperCase(),
        assetNetwork: params.assetNetwork.trim().toLowerCase(),
        assetContractAddress: params.assetContractAddress ?? null,
        rewardAmount: params.rewardAmount,
        maxRedemptions: params.maxRedemptions,
        expiresAt: params.expiresAt ?? null,
        createdByOpenId: params.createdByOpenId,
      });
      const [giftCode] = await db.select().from(giftCodes).where(eq(giftCodes.codeHash, hashRewardCode(rawCode))).limit(1);
      if (giftCode) return { giftCode, rawCode };
    } catch {
      // Retry only on the extremely unlikely generated-code collision.
    }
  }
  throw new Error("Could not create gift code");
}

export async function redeemGiftCode(userOpenId: string, rawCode: string, requestedRecipientWalletAddress?: string): Promise<RewardLedgerEntry> {
  assertUser(userOpenId);
  const codeHash = hashRewardCode(rawCode);
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.transaction(async (tx) => {
    const [giftCode] = await tx.select().from(giftCodes).where(eq(giftCodes.codeHash, codeHash)).limit(1);
    if (!giftCode) throw new Error("Gift code not found");
    if (giftCode.status !== "active" || giftCode.redemptionCount >= giftCode.maxRedemptions) throw new Error("Gift code is no longer available");
    if (giftCode.expiresAt && giftCode.expiresAt.getTime() <= Date.now()) throw new Error("Gift code has expired");

    const [existing] = await tx.select().from(giftCodeRedemptions).where(and(eq(giftCodeRedemptions.giftCodeId, giftCode.id), eq(giftCodeRedemptions.userOpenId, userOpenId))).limit(1);
    if (existing?.rewardLedgerId) {
      const [ledger] = await tx.select().from(rewardLedger).where(eq(rewardLedger.id, existing.rewardLedgerId)).limit(1);
      if (ledger) return ledger;
    }
    if (existing) throw new Error("Gift code already redeemed by this user");

    const isWpaxi = giftCode.assetNetwork === "bsc" && giftCode.assetSymbol === "WPAXI" && Boolean(giftCode.assetContractAddress);
    let poolId: number | null = null;
    let recipientWalletAddress: string | null = null;
    if (isWpaxi) {
      if (!requestedRecipientWalletAddress || !ethers.isAddress(requestedRecipientWalletAddress)) {
        throw new Error("A valid BSC recipient wallet is required for WPAXI gift-code redemption");
      }
      const allocation = await allocateFromVerifiedWpaxiPools(tx, {
        tokenAddress: giftCode.assetContractAddress!,
        rewardAmount: giftCode.rewardAmount,
      });
      poolId = allocation.pool.id;
      recipientWalletAddress = ethers.getAddress(requestedRecipientWalletAddress);
    }

    const updated = await tx.update(giftCodes).set({
      redemptionCount: sql`${giftCodes.redemptionCount} + 1`,
      status: giftCode.redemptionCount + 1 >= giftCode.maxRedemptions ? "exhausted" : "active",
    }).where(and(eq(giftCodes.id, giftCode.id), eq(giftCodes.status, "active"), lt(giftCodes.redemptionCount, giftCode.maxRedemptions)));
    if (affectedRows(updated) !== 1) throw new Error("Gift code was redeemed concurrently; try again");

    const redemption = await tx.insert(giftCodeRedemptions).values({ giftCodeId: giftCode.id, userOpenId, status: "pending" });
    const redemptionId = Number((redemption as unknown as { insertId?: number | string }).insertId);
    const ledgerStatus = isWpaxi ? "claimable" : "approved";
    const ledgerResult = await tx.insert(rewardLedger).values({
      userOpenId,
      sourceType: "gift_code",
      sourceId: String(giftCode.id),
      assetSymbol: giftCode.assetSymbol,
      assetNetwork: giftCode.assetNetwork,
      assetContractAddress: giftCode.assetContractAddress,
      amount: giftCode.rewardAmount,
      status: ledgerStatus,
      idempotencyKey: `gift-code:${giftCode.id}:user:${userOpenId}`,
      metadata: { giftCodeHint: giftCode.codeHint, redemptionId, ...(poolId ? { poolId, recipientWalletAddress } : {}) },
      approvedAt: isWpaxi ? null : new Date(),
      claimableAt: isWpaxi ? new Date() : null,
    });
    const ledgerId = Number((ledgerResult as unknown as { insertId?: number | string }).insertId);
    if (isWpaxi && poolId && recipientWalletAddress) {
      await tx.insert(rewardClaims).values({
        rewardLedgerId: ledgerId,
        userOpenId,
        recipientWalletAddress,
        poolId,
        tokenAddress: giftCode.assetContractAddress!,
        amount: giftCode.rewardAmount,
        status: "claimable",
        claimIdempotencyKey: `claim:gift-code:${giftCode.id}:user:${userOpenId}`,
      });
    }
    await tx.update(giftCodeRedemptions).set({ rewardLedgerId: ledgerId, status: "credited" }).where(eq(giftCodeRedemptions.id, redemptionId));
    const [ledger] = await tx.select().from(rewardLedger).where(eq(rewardLedger.id, ledgerId)).limit(1);
    if (!ledger) throw new Error("Reward ledger entry was not created");
    return ledger;
  });
}

export async function qualifyReferral(params: {
  referralId: number;
  inviterReward: Omit<RewardCreditParams, "userOpenId" | "sourceType" | "sourceId" | "idempotencyKey">;
  inviteeReward?: Omit<RewardCreditParams, "userOpenId" | "sourceType" | "sourceId" | "idempotencyKey">;
}): Promise<Referral> {
  if (!Number.isSafeInteger(params.referralId) || params.referralId <= 0) throw new Error("Invalid referral id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [referral] = await db.select().from(referrals).where(eq(referrals.id, params.referralId)).limit(1);
  if (!referral) throw new Error("Referral not found");
  if (referral.status === "rejected" || referral.status === "cancelled") throw new Error("Referral is not eligible");

  await creditReward({ ...params.inviterReward, userOpenId: referral.inviterOpenId, sourceType: "referral", sourceId: String(referral.id), idempotencyKey: `referral:${referral.id}:inviter` });
  if (params.inviteeReward) {
    await creditReward({ ...params.inviteeReward, userOpenId: referral.inviteeOpenId, sourceType: "referral", sourceId: String(referral.id), idempotencyKey: `referral:${referral.id}:invitee` });
  }
  await db.update(referrals).set({ status: "qualified", qualifiedAt: new Date() }).where(and(eq(referrals.id, referral.id), eq(referrals.status, "pending")));
  const [updated] = await db.select().from(referrals).where(eq(referrals.id, referral.id)).limit(1);
  if (!updated) throw new Error("Referral disappeared during qualification");
  return updated;
}
