import { z } from "zod";
import { ENV } from "../_core/env";
import { publicProcedure, router } from "../_core/trpc";
import { calculateFee, getFeeConfig } from "../fees/feeEngine";
import { buildNormalizedFeeBreakdown } from "../fees/feeBreakdown";
import type { FeeOperation } from "../fees/feeConfig";
import { getTreasuryConfiguration, listTreasuryConfigurations, type TreasuryNetwork } from "../fees/treasury";

const operationSchema = z.enum(["swap_evm", "swap_btc", "bridge", "create_token", "listing"]);
const chainTypeSchema = z.string().trim().regex(/^[A-Za-z0-9._:-]{1,32}$/);
const usdSchema = z.string().trim().regex(/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/);

export const feesRouter = router({
  getTreasury: publicProcedure.query(() => ({
    treasuryAddress: ENV.paxiTreasuryAddress || null,
    configurations: listTreasuryConfigurations(),
  })),

  getTreasuryForNetwork: publicProcedure
    .input(z.object({ network: z.enum(["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"]) }))
    .query(({ input }) => getTreasuryConfiguration(input.network as TreasuryNetwork)),

  getConfig: publicProcedure
    .input(z.object({ operation: operationSchema, chainType: chainTypeSchema }))
    .query(async ({ input }) => {
      const config = await getFeeConfig(input.operation as FeeOperation, input.chainType);
      return {
        operation: config.operation,
        chainType: config.chainType,
        percentageBps: config.percentageBps,
        fixedUsd: config.fixedUsd,
        isActive: config.isActive,
        updatedAtMs: config.updatedAtMs,
      };
    }),

  calculate: publicProcedure
    .input(
      z.object({
        operation: operationSchema,
        chainType: chainTypeSchema,
        inputAmountUsd: usdSchema,
        // This is only a separate network/gas estimate. It can never change the PAXI configuration or rate.
        networkFeeEstimateUsd: usdSchema.optional(),
      }),
    )
    .query(({ input }) =>
      calculateFee(
        input.operation as FeeOperation,
        input.chainType,
        input.inputAmountUsd,
        input.networkFeeEstimateUsd ?? "0",
      ),
    ),

  /**
   * Read-only preview contract for transaction screens. Provider/route
   * estimates are inputs, but the PAXI service fee is always recalculated from
   * the server-owned fee configuration. This endpoint never signs, broadcasts,
   * or settles a transaction.
   */
  calculateBreakdown: publicProcedure
    .input(
      z.object({
        operation: operationSchema,
        chainType: chainTypeSchema,
        inputAmountUsd: usdSchema,
        feeCurrency: z.literal("USD"),
        networkFee: usdSchema.optional(),
        routeFee: usdSchema.optional(),
        bridgeFee: usdSchema.optional(),
        relayerFee: usdSchema.optional(),
        estimatedReceived: usdSchema.optional(),
      }),
    )
    .query(async ({ input }) => {
      const calculation = await calculateFee(
        input.operation as FeeOperation,
        input.chainType,
        input.inputAmountUsd,
        input.networkFee ?? "0",
      );
      return buildNormalizedFeeBreakdown({
        feeCurrency: input.feeCurrency,
        networkFee: calculation.networkFeeEstimateUsd,
        paxiServiceFee: calculation.paxiFeeUsd,
        routeFee: input.routeFee,
        bridgeFee: input.bridgeFee,
        relayerFee: input.relayerFee,
        estimatedReceived: input.estimatedReceived,
      });
    }),
});
