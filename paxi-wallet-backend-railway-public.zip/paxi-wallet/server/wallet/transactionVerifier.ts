import { ethers } from "ethers";
import { withEvmRpc } from "../chains/rpc";
import { getChainAdapter } from "../chains/registry";
import { requireValidIdentifier } from "../chains/types";
import { decodeEvmActivity, type DecodedEvmActivity } from "./activityDecoder";

export interface VerifiedTransaction extends DecodedEvmActivity {
  walletAddress: string;
  chainId: string;
  transactionHash: string;
  blockTimestampMs: number | null;
}

const TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;

function configuredBridgeAddresses(): Set<string> {
  return new Set(
    (process.env.PAXI_TRUSTED_BRIDGE_ADDRESSES ?? "")
      .split(",")
      .map((value) => value.trim().toLowerCase())
      .filter((value) => ethers.isAddress(value)),
  );
}

/**
 * Confirms a mined EVM transaction, proves wallet involvement, and derives the
 * operation/amounts from receipt semantics. Client-provided event labels and
 * USD values are deliberately not accepted here.
 */
export async function verifyConfirmedEvmTransaction(
  network: string,
  walletAddress: string,
  transactionHash: string,
): Promise<VerifiedTransaction> {
  if (!TX_HASH_RE.test(transactionHash)) throw new Error("Invalid EVM transaction hash");
  const adapter = getChainAdapter(network.toLowerCase());
  if (adapter.family !== "evm" || !adapter.rpcUrl) throw new Error("Server transaction verification is not available for this network");
  const normalizedWallet = requireValidIdentifier(adapter, walletAddress);
  return withEvmRpc(adapter.network as Parameters<typeof withEvmRpc>[0], async (provider) => {
    const receipt = await provider.getTransactionReceipt(transactionHash);
    if (!receipt) throw new Error("Transaction not found or not confirmed");
    if (receipt.status !== 1) throw new Error("Transaction failed on-chain");
    const transaction = await provider.getTransaction(transactionHash);
    if (!transaction) throw new Error("Transaction details unavailable");
    const decoded = await decodeEvmActivity({
      network: adapter.network,
      walletAddress: normalizedWallet,
      transaction,
      receipt,
      provider,
      read: <T>(operation: () => Promise<T>) => operation(),
      trustedBridgeAddresses: configuredBridgeAddresses(),
    });
    const block = await provider.getBlock(receipt.blockNumber);
    const blockTimestampMs = block?.timestamp != null ? block.timestamp * 1000 : null;
    return {
      walletAddress: normalizedWallet,
      chainId: adapter.network,
      transactionHash,
      blockTimestampMs,
      ...decoded,
    };
  });
}
