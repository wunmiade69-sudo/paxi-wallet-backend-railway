SELECT 'table_presence' AS section, t.expected_table,
       CASE WHEN i.TABLE_NAME IS NULL THEN 'MISSING' ELSE 'PRESENT' END AS status,
       COALESCE(i.TABLE_ROWS, 0) AS approx_rows
FROM (
  SELECT 'users' AS expected_table UNION ALL SELECT 'walletLinks' UNION ALL SELECT 'walletLinkChallenges'
  UNION ALL SELECT 'activityEvents' UNION ALL SELECT 'feeConfig' UNION ALL SELECT 'feeRecords'
  UNION ALL SELECT 'sendFeeQuotes' UNION ALL SELECT 'sendOperations' UNION ALL SELECT 'feePaymentLedger'
  UNION ALL SELECT 'tokenListings' UNION ALL SELECT 'listingEvents' UNION ALL SELECT 'campaigns'
  UNION ALL SELECT 'campaignEntries' UNION ALL SELECT 'paxiSchemaDeployments'
) t LEFT JOIN information_schema.TABLES i
  ON i.TABLE_SCHEMA = DATABASE() AND i.TABLE_NAME = t.expected_table
ORDER BY t.expected_table;

SELECT 'table_counts' AS section, 'users' AS table_name, COUNT(*) AS row_count FROM users
UNION ALL SELECT 'table_counts','activityEvents',COUNT(*) FROM activityEvents
UNION ALL SELECT 'table_counts','feeConfig',COUNT(*) FROM feeConfig
UNION ALL SELECT 'table_counts','feeRecords',COUNT(*) FROM feeRecords
UNION ALL SELECT 'table_counts','tokenListings',COUNT(*) FROM tokenListings
UNION ALL SELECT 'table_counts','campaigns',COUNT(*) FROM campaigns
UNION ALL SELECT 'table_counts','campaignEntries',COUNT(*) FROM campaignEntries
UNION ALL SELECT 'table_counts','paxiSchemaDeployments',COUNT(*) FROM paxiSchemaDeployments;

SELECT 'activity_statuses' AS section, status, verificationSource, COUNT(*) AS row_count
FROM activityEvents GROUP BY status, verificationSource ORDER BY row_count DESC;

SELECT 'fee_operations' AS section, operation, status, COUNT(*) AS row_count
FROM feeRecords GROUP BY operation, status ORDER BY operation, status;

SELECT 'fee_config' AS section, id, operation, chainType, percentageBps, fixedUsd, isActive
FROM feeConfig ORDER BY id;

SELECT 'recent_activity' AS section, id, userOpenId, walletAddress, chainId, eventType, status, verificationSource, transactionHash, createdAt
FROM activityEvents ORDER BY id DESC LIMIT 30;

SELECT 'recent_fees' AS section, id, userOpenId, operation, chainType, inputAmountUsd, paxiFeeUsd, networkFeeUsd, totalFeeUsd, transactionHash, status, createdAt
FROM feeRecords ORDER BY id DESC LIMIT 30;

SELECT 'duplicate_activity_idempotency' AS section, userOpenId, walletAddress, chainId, transactionHash, eventType, COUNT(*) AS duplicates
FROM activityEvents GROUP BY userOpenId, walletAddress, chainId, transactionHash, eventType HAVING COUNT(*) > 1;

SELECT 'orphan_fee_users' AS section, f.id, f.userOpenId
FROM feeRecords f LEFT JOIN users u ON u.openId = f.userOpenId WHERE u.openId IS NULL LIMIT 50;

SELECT 'orphan_activity_users' AS section, a.id, a.userOpenId
FROM activityEvents a LEFT JOIN users u ON u.openId = a.userOpenId WHERE u.openId IS NULL LIMIT 50;

SELECT 'deployment_ledger' AS section, id, version, appliedAt, checksum
FROM paxiSchemaDeployments ORDER BY id DESC LIMIT 50;
