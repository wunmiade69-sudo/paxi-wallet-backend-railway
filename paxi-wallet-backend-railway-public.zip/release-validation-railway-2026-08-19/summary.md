# PAXI Wallet — Railway staging and Android QA preparation validation

**Date:** 2026-08-19

## Scope

This validation covers the active backend/web repository checkout after the Railway staging preparation, environment-boundary cleanup, and removal of the unreachable client-side map implementation. It does not claim Railway execution, database migration, Redis provisioning, Android build, physical-device QA, signed release packaging, or live transaction verification.

## Results

| Gate or inspection | Result |
| --- | --- |
| `npm run check` | PASS — exit 0 |
| `npm test -- --run` | PASS — 56 test files, 218 tests; new Railway staging test contributes 5 passing tests |
| `npm run lint` | PASS — exit 0 |
| `npm run build` | PASS — exit 0; existing large wallet chunk and dynamic/static import warnings remain documented |
| `npm audit --omit=dev` | Exit 1 — 21 vulnerabilities: 7 low, 11 moderate, 3 high; no forced breaking remediation applied |
| Built web-bundle secret-name scan | CLEAN for scanned server-only credential names and stale client Forge-key aliases |
| Stale client map path | ABSENT; `client/src/components/Map.tsx` removed and stale VITE Forge-key variables absent from `.env.example` |
| Capacitor/Android project | BLOCKED in this checkout; `capacitor.config.ts`, `android/`, `client/src/lib/mobileRuntime.ts`, and `client/src/lib/nativeDevice.ts` are absent |

## Deployment status

The backend is prepared for controlled Railway staging using a compatible MySQL/TiDB service, Redis where required, `npm run build`, `npm run start`, `npm run db:push`, and `/readyz`. Railway PostgreSQL is not compatible with the current Drizzle/MySQL schema without a separately approved architecture migration. No Railway project or staging credentials were supplied or modified.

## Required next owner actions

Restore or explicitly reattach the separately prepared Capacitor/Android source before attempting `npx cap sync android`, APK compilation, native API-origin checks, or physical-device QA. Then provision compatible staging infrastructure, run backup and migration regression controls, execute the provider/OAuth/LI.FI/PAXI AI checks, and complete the controlled Android matrix with test wallets and non-production funds.
