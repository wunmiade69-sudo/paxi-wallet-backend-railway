# Attached Review Gap Analysis

## Confirmed high-priority gaps

| Review item | Current evidence | Planned correction |
|---|---|---|
| Client-selected activity semantics | `activityRouter.recordVerifiedTransaction` accepts `eventType`, `amount`, and `amountUsd`; `verifyConfirmedEvmTransaction` only confirms receipt/sender/involvement | Introduce server-owned semantic decoding for EVM receipts and reject client operation labels unless they match the decoded result. Treat client amounts as non-authoritative. |
| Client-selected USD value | `recordVerifiedTransaction` writes `params.amountUsd` into confirmed activity rows; snapshots aggregate `activityEvents.amountUsd` | Add server-derived amount/price fields and require confirmed eligibility data to use server-derived USD. Preserve client values only as metadata if needed. |
| WPAXI pool rotation | `issueReferralReward` only reads active verified pools, marks an exhausted pool, and then throws | Under row locks, promote the lowest-priority verified reserve pool within the same transaction and continue issuance. Apply the same behavior to WPAXI gift-code redemption. |
| Referral wallet selection | Referral reward and WPAXI gift-code flows use the inviter/user’s latest confirmed BSC activity wallet | Add explicit reward-wallet binding and update endpoint. Lock the inviter wallet when qualification begins; require an explicit wallet for WPAXI gift-code redemption. |
| PAXI trade-side quantity | `referralTradingVerifier` sums PAXI in plus out | Decode economic direction and select the relevant PAXI in/out side. Keep stablecoin-side USD volume as the qualification authority. |
| Chart shortfall | `chartService.getChartData` returns internal candles whenever any exist, even below requested limit | Fetch provider candles when internal count is below requested limit, merge, deduplicate by millisecond timestamp, and return the newest requested candles. |
| Distributed chart cache | Chart service has no Redis cache helper | Add Redis chart cache keys with timeframe-specific TTLs and graceful fallback when Redis is unavailable. |
| Airdrop multipliers | Airdrop allocation divides the cap equally across eligible users | Add campaign-configurable tier multipliers and allocate proportionally with fixed-scale arithmetic and a deterministic cap/remainder policy. |

## Existing strengths to preserve

The review confirms that the application already has trusted BSC router/pair allowlists, Swap-event validation, duplicate trade protection, verified-pool checks, fixed-scale reward math, Redis locking primitives, millisecond chart timestamp normalization, provider fallback, internal candles, lifecycle statuses, exactly ten active eligibility requirements, review/approval stages, and claim-time on-chain Transfer verification.

## Migration strategy

All schema changes will be added as idempotent Railway deployment scripts and included in `pnpm db:deploy`; raw Drizzle push remains disabled. Existing rows will remain compatible through nullable/defaulted columns, and existing reward claims will retain their original recipient wallet and audit metadata.

## Security invariants

The server will remain the authority for event type, confirmed status, transaction hash, wallet ownership, economic amounts, and eligibility USD values. Client-supplied labels and amounts must not be able to increase qualification, reward allocation, or airdrop payout. Pool rotation and reward issuance must be protected by transaction-scoped row locking and conditional updates.
