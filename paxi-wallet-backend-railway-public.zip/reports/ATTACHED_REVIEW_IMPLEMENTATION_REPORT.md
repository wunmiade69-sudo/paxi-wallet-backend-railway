# Paxi Wallet Attached-Review Implementation Report

**Author:** Manus AI  
**Date:** 12 August 2026  
**Scope:** Production-hardening recommendations supplied in `pasted_content.txt`

## Executive result

The attached review was implemented across the activity ledger, transaction verification, referral rewards, WPAXI pool allocation, chart service, eligibility engine, and airdrop allocator. The implementation was then deployed through the project’s idempotent Railway pipeline and validated with local code gates, live database regression, and production HTTP smoke tests.

The main security boundary is now server-owned: confirmed activity semantics, on-chain token amounts, stablecoin-derived USD volume, reward-wallet selection, reward-pool allocation, and eligibility-source provenance are no longer controlled by ordinary client fields.

## Implemented changes

| Area | Implementation | Operational effect |
|---|---|---|
| Activity semantics | Added `server/wallet/activityDecoder.ts`; EVM receipts now classify buy, sell, swap, bridge, send, and receive from transaction/Transfer-log semantics. | The verified activity endpoint accepts only wallet, chain, and transaction hash. Client event labels and amounts are rejected from the trusted path. |
| USD provenance | Added `activityEvents.verificationSource` and `activityEvents.amountUsdSource`; server-semantic transactions use on-chain stablecoin values when available. | Eligibility snapshots exclude legacy/client-derived activity rows. Native-asset USD is intentionally left null when no authoritative historical quote exists. |
| Timestamp integrity | Verified activity timestamps use the mined block timestamp in millisecond Unix epoch form when available. | Eligibility and active-day calculations are based on chain-confirmed time rather than client submission time. |
| Referral wallet binding | Added `rewardWalletAddress` to referral profiles and referral rows, plus `referrals.setRewardWallet`. | WPAXI referral payouts use an explicitly bound BSC wallet and no longer select the inviter’s latest arbitrary activity wallet. |
| WPAXI pool rotation | Added a transaction-scoped allocator with `FOR UPDATE` locking, active-pool exhaustion, verified reserve promotion, conditional allocation, and retry-safe behavior. | Referral rewards and WPAXI gift-code redemption can rotate into the next verified reserve pool without a manual activation race. |
| Gift-code safety | WPAXI gift-code redemption now requires an explicit BSC recipient wallet. | Gift-code payouts cannot be redirected to a wallet inferred from unrelated activity history. |
| BSC trade measurement | Added directional amount calculation: buy uses PAXI out/stablecoin in; sell uses PAXI in/stablecoin out. | PAXI quantity validation now reflects economic trade direction while USD qualification remains stablecoin-side based. |
| Chart completeness | Internal candles are merged with provider candles whenever internal history is shorter than requested; duplicate timestamps prefer internal candles. | Partial internal history no longer suppresses provider backfill. |
| Chart caching | Added Redis chart cache helpers with timeframe-specific TTLs from 20 seconds for 1-minute candles to 30 minutes for daily candles. | Chart traffic can share cached results across instances while Redis outages degrade to database/provider reads. |
| Eligibility multipliers | Added `campaignTierMultipliers`, persisted `eligibilityResults.payoutMultiplier`, default minimum/highest multipliers of `1`/`2`, and admin tRPC configuration endpoints. | Campaigns retain the exact 0–4, 5–9, and 10/10 tiers while airdrops can weight minimum and highest tiers differently. |
| Airdrop allocation | Replaced equal splits with fixed-scale multiplier-weighted allocation, deterministic rounding remainder assignment, idempotent user allocation, and cap clamping. | Allocations respect configured tier weight and cannot exceed the funded campaign cap. |

## Verification evidence

| Gate | Result | Evidence |
|---|---|---|
| TypeScript | **PASS** | `pnpm check` completed with no errors. |
| Unit tests | **PASS: 21 tests in 7 files** | Includes activity decoder, chart merge, directional referral trade, reward math, security hardening, provider aggregation, and logout tests. [`final-review-local-gates.log`](final-review-local-gates.log) |
| Production build | **PASS** | Vite client build and bundled Node server build completed successfully. Non-fatal circular-chunk and static/dynamic Bitcoin import warnings remain. [`final-review-local-gates.log`](final-review-local-gates.log) |
| Dependency security audit | **PASS with documented upstream exception** | No fixable high/critical production advisories remain. The remaining high advisory is the upstream `bigint-buffer` path through Solana dependencies. [`dependency-audit.json`](dependency-audit.json) |
| Railway schema deployment | **PASS** | `pnpm db:push` completed with all idempotent scripts, including activity provenance, referral wallet fields, campaign multipliers, and WPAXI configuration. [`final-review-db-push.log`](final-review-db-push.log) |
| Live database regression | **PASS** | All database tests passed. The consolidated PAXI deployment ledger reports eight applied entries and one informational legacy Drizzle entry. [`final-review-db-push.log`](final-review-db-push.log) |
| Production HTTP smoke | **PASS** | Health 200, readiness 200 with database true, public chains/assets 200, cross-site mutation 403, protected `rewards.mine` query 401, and invalid LI.FI path 400. [`final-review-http-smoke-2.log`](final-review-http-smoke-2.log), [`final-review-rewards-smoke-2.log`](final-review-rewards-smoke-2.log) |

## Production safeguards and remaining risks

The four WPAXI pools remain intentionally inactive until distributor addresses are supplied, each distributor balance is verified on-chain, the appropriate pool is activated, trusted BSC router and pair allowlists are configured, and the referral policy is activated. The confirmed token and pool addresses remain unchanged from the prior WPAXI report.

Bridge activity is classified as `bridge` only when the destination contract is present in the server-side `PAXI_TRUSTED_BRIDGE_ADDRESSES` allowlist. Without that allowlist, a source-chain outgoing transfer is conservatively recorded as `send` rather than being assigned a bridge label from client input.

Legacy activity rows are preserved for audit history but are excluded from trusted eligibility calculations until they are reverified through the server-owned transaction path. This is deliberately conservative and may reduce historical eligibility totals for users whose old activity was not server-verified.

The remaining dependency advisory is upstream and currently not fixable without an upstream Solana dependency change. Provider chart fallback and Redis graceful degradation remain expected operating modes; they are observable fallbacks rather than silent trust-boundary bypasses.

## Deployment operating rules

All future schema changes must continue to use `pnpm db:push` and idempotent deployment scripts. The disabled `pnpm db:drizzle:push` path must not be used. WPAXI pool activation must remain an administrator-controlled sequence, and reward claims must continue to require on-chain distributor-to-recipient Transfer verification.

## References

[1]: ../pasted_content.txt "Attached user review and implementation recommendations"
[2]: final-review-db-push.log "Railway deployment and database regression evidence"
[3]: final-review-local-gates.log "TypeScript, tests, production build, and dependency audit evidence"
[4]: final-review-http-smoke-2.log "Production HTTP smoke evidence"
[5]: final-review-rewards-smoke-2.log "Protected rewards query authentication evidence"
[6]: dependency-audit.json "Recorded dependency audit output"
