# Bitcoin Hardening and Activity Decoder Validation Report

**Project:** Paxi Wallet
**Validation date:** 13 August 2026
**Scope:** Bitcoin transaction lifecycle hardening, accurate BTC MAX-send estimation, server-side activity decoding, final production validation, and release packaging.

## Executive summary

The latest review round is complete. Bitcoin pending transactions now resolve confirmation state through the server-proxied Blockstream Esplora status endpoint, while the BTC MAX-send action reserves a fee using the same UTXO and virtual-size model as the sender. Server-side EVM activity decoding now rejects failed receipts before semantic classification and has regression coverage for complex multi-hop swaps, bridge transfers, ambiguous outputs, self-transfers, zero-value transfers, and stablecoin valuation behavior.

The implementation was validated with TypeScript compilation, the full Vitest suite, production client/server builds, the idempotent Railway database deployment pipeline, the database regression suite, a production HTTP smoke test, and the dependency audit parser. The final project archive was refreshed after the latest code changes and passed ZIP integrity verification.

## Implemented changes

### Bitcoin Esplora confirmation resolution

`fetchBitcoinTransactionStatus()` in `client/src/lib/wallet/bitcoin.ts` reads `/tx/:txid/status` through the existing `/api/blockscout-proxy` server route. Confirmed responses preserve block height, block hash, and block time. Unconfirmed responses remain pending. This behavior is integrated into `resolvePendingStatus()` in `client/src/lib/wallet/txIndexer.ts`, so Bitcoin records do not receive the EVM-specific stale timeout while they remain unconfirmed.

The existing bounded transaction-status polling hook continues to poll at 0, 2, 4, 6, 10, 15, and 30 seconds, with a five-minute upper bound. Polling stops when the transaction becomes confirmed or failed. This preserves a consistent user-facing lifecycle of **pending → confirmed/failed** without inventing confirmation for an unconfirmed Bitcoin transaction.

### Accurate Bitcoin MAX-send estimation

`computeBitcoinMaxSend()` and `estimateBitcoinMaxSend()` now calculate the maximum spendable amount from the fetched UTXO set. The fee reservation uses `estimateVBytes(inputCount, 2) * feeRate`, matching the conservative two-output model used by `sendBitcoinAsset()`. Fee-rate normalization, empty-UTXO behavior, and insufficient-balance handling are covered by deterministic tests.

`SendScreen.tsx` uses the shared Bitcoin estimator for BTC assets. EVM assets continue to use the EVM gas estimator, and Solana retains its explicit flat reserve. No client-provided PAXI fee is trusted by the backend fee engine.

### Failed-receipt rejection and semantic activity decoding

`server/wallet/activityDecoder.ts` rejects any EVM receipt with `status === 0` before attempting transfer-flow classification. This prevents failed transactions from being recorded as buys, sells, sends, receives, or bridges merely because their logs contain transfer-shaped data.

The decoder also preserves wallet-facing flows in multi-hop aggregator transactions, ignores unrelated contract transfers, uses verified stablecoin outflows as USD provenance, handles bridge destinations through the trusted bridge allowlist, and refuses to invent a primary asset when multiple non-stable outputs are ambiguous.

## Regression coverage

The activity decoder now has 14 regression tests covering the following behaviors:

| Coverage area | Verified behavior |
|---|---|
| Stablecoin-to-token swap | Classified as buy with on-chain stablecoin USD provenance |
| Token-to-stablecoin swap | Classified as sell with correct USD amount |
| Native outgoing transfer | Classified as send without fabricated USD value |
| Native incoming transfer | Classified as receive |
| Multi-hop aggregator swap | Uses the final wallet-facing asset and amount |
| Unrelated contract logs | Excluded from wallet activity semantics |
| Native value plus token transfer | Preserves the token flow rather than misclassifying router value |
| Failed EVM receipt | Rejected before semantic decoding |
| Trusted bridge transfer | Classified as bridge activity |
| Multiple stablecoins | Uses the first verified stablecoin valuation flow |
| Multiple non-stable outputs | Leaves the primary asset unset when ambiguous |
| Self-transfer | Rejected as non-activity |
| Zero-value transfer/transaction | Rejected as non-activity |
| Complex aggregator with explicit asset | Requires and honors an explicit requested asset when needed |

The five Bitcoin tests are located at `server/wallet/bitcoinEstimate.test.ts`, ensuring they are included by the repository's standard `npm test` glob. They cover the fee shape, fee-rate normalization, proxy URL construction, confirmed Esplora parsing, and unconfirmed Esplora parsing.

## Validation results

| Check | Result | Notes |
|---|---:|---|
| `npm run check` | PASS | TypeScript compilation completed without errors |
| `npm test` | PASS | 37 tests across 8 test files |
| `npm run build` | PASS | Vite client build and bundled Express server build completed |
| `npm run db:push` | PASS | Idempotent deployment ledger and database regression checks passed against Railway |
| `npm run security:deps` | PASS | No fixable high/critical production advisory remains |
| Production HTTP smoke test | PASS | Health, readiness, public APIs, CSRF, auth, and LI.FI validation behaved as expected |
| Archive integrity | PASS | ZIP test completed without errors |

The final HTTP smoke-test responses were as follows:

| Endpoint/check | Expected result | Observed result |
|---|---:|---:|
| `GET /healthz` | 200 | 200 with `ok: true` |
| `GET /readyz` | 200 with database available | 200 with `database: true` |
| `GET /api/chains` | 200 | 200; all configured chain adapters returned |
| `GET /api/assets?limit=1` | 200 | 200; live Railway asset/market row returned |
| Cross-site `POST /api/trpc/system.health` | 403 | 403 `Cross-site request blocked` |
| Unauthenticated `GET /api/trpc/rewards.mine` | 401 | 401 `UNAUTHORIZED` |
| Invalid LI.FI path | 400 | 400 `Invalid or disallowed LI.FI path` |

The smoke test intentionally ran with `REDIS_REQUIRED=false` and no Redis URL, so the server logged that distributed rate limiting and workers were disabled for that isolated validation process. The readiness endpoint correctly reported database availability and omitted the Redis assertion because Redis was not required in this mode. Production deployment should continue to provide a managed Redis URL and set the required-mode flag according to the deployment policy.

## Dependency audit disposition

The audit parser reported 21 advisories, including three high-severity upstream advisories involving `@solana/buffer-layout-utils`, `@solana/spl-token`, and `bigint-buffer`. These are classified by the project audit policy as unfixable through a compatible patch because remediation requires a major Solana dependency upgrade. The audit passed because no fixable high or critical production advisory remains. The dependency set should be revisited when the Solana major-version migration is compatible with the wallet integration.

## Release packaging

The final archive was regenerated at:

`/home/ubuntu/paxi-wallet-final-architecture.zip`

SHA-256:

`21e667e8f4c40a65128e1132d0df6787bfca5bdbd7204f7fbe97810f4ca821c8`

The checksum is also stored in `paxi-wallet/archive-final.sha256`. The archive excludes `node_modules`, `.git`, `dist`, and `.manus-logs`, and `unzip -tq` completed without errors.

## Remaining follow-up items

### Native BTC/BNB/SOL chart fallback

Native-asset chart retrieval still relies heavily on CoinGecko after the existing provider chain. A secondary native-asset provider such as CoinCap or Binance can improve resilience during CoinGecko outages or quota pressure. This is a medium-priority improvement and does not block the current release because the existing fallback chain, Redis cache, provider limits, and chart API normalization are already operational.

### Vite chunk optimization

The production build still reports circular manual-chunk warnings and emits a large general vendor chunk. The current build is successful and the bundle remains within the configured warning threshold. Route-level and feature-level lazy loading should be introduced in a separate performance change, with mobile startup measurements and regression testing, rather than risking wallet functionality during this hardening release.

## Release assessment

The latest changes are production-ready for the reviewed scope. The core transaction lifecycle is hardened for EVM and Bitcoin, server-side activity semantics reject failed and ambiguous cases, the Railway schema pipeline is repeatable, and all automated and HTTP validation gates pass. Before broad public rollout, production operations should still enforce managed Redis availability, monitor the known upstream Solana advisories, supply and verify WPAXI distributor addresses through the admin workflow, configure trusted BSC router/pair addresses, and activate the referral policy only after those on-chain safeguards are complete.
