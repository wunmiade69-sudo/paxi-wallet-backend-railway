# Paxi Wallet Production Bug Review Report

**Author:** Manus AI  
**Review date:** 12 August 2026  
**Scope:** Final review pass over the Paxi Wallet multi-provider market, wallet activity, fee, campaign, transaction, deployment, and production-runtime changes.

## Executive assessment

The review pass is complete. The application now has a materially stronger production foundation than at the beginning of this audit: server-owned fee configuration, verified transaction lifecycle transitions, idempotent activity and fee records, race-safe campaign snapshot freezing, primary-consistent snapshot reads, ordered activity streaming, deployment-ledger consolidation, hardened Express 5 routing, Redis degradation controls, and split client vendor bundles.

> **Senior production rating: 8.6/10 for the reviewed scope.**

This is a strong pre-production result, not a claim that the product is fully risk-free or ready for unrestricted financial scale without operational controls. The rating reflects clean local gates, successful Railway schema regression, a passing production HTTP smoke test, and the fact that the remaining issues are identifiable and bounded. The open items below should be closed before calling the platform fully production-grade for millions of users.

## Bugs and defects fixed

| # | Defect | Resolution | Evidence |
|---:|---|---|---|
| 1 | Verified transaction retries inserted a second activity event instead of confirming the pending event. | `recordVerifiedTransaction` now finds the event by user, wallet, chain, transaction hash, and event type, then performs a guarded `pending → confirmed` transition. | [`transactionService.ts`](../server/wallet/transactionService.ts) |
| 2 | BSC USDT/USDC fee verification used Ethereum-style six-decimal assumptions. | BSC stablecoins now use 18 decimals; Ethereum and other configured networks retain their network-specific decimals. | [`feeVerification.ts`](../server/feeVerification.ts) |
| 3 | The client token-factory fee path used a stale six-decimal constant on BSC. | Fee-token decimals are resolved by network and token, with BSC USDT/USDC configured as 18 decimals. | [`tokenFactory.ts`](../client/src/lib/wallet/tokenFactory.ts) |
| 4 | Snapshot reads could observe replica lag immediately after a freeze. | `getSnapshot()` now reads from the primary database for lifecycle-critical state. | [`snapshotService.ts`](../server/campaigns/snapshotService.ts) |
| 5 | Two workers could concurrently freeze the same campaign snapshot. | Snapshot freezing claims `pending → calculating` conditionally before doing work and rolls back the claim on failure. | [`snapshotService.ts`](../server/campaigns/snapshotService.ts) |
| 6 | Snapshot freezing accumulated all eligible users in memory. | Activity events are streamed through an ordered `(userOpenId, id)` cursor, bounded by batch size. | [`snapshotService.ts`](../server/campaigns/snapshotService.ts), [`schema.ts`](../drizzle/schema.ts) |
| 7 | Snapshot finalization could complete before all participant rows were persisted. | Finalization now checks the pending participant count, validates unknown users, and uses retry-safe participant lookup. | [`snapshotService.ts`](../server/campaigns/snapshotService.ts) |
| 8 | Campaign qualification counted only the highest tier. | Both `minimum` (5–9 active days) and `highest` (10/10 active days) are treated as qualified; 0–4 remains not qualified. | [`snapshotService.ts`](../server/campaigns/snapshotService.ts) |
| 9 | Client screens could drift from the server treasury address. | Create Token, List Token, Campaign, Swap, and fee-payment flows now consume the server-owned treasury endpoint or quote authority. | [`fees.ts`](../server/routers/fees.ts), [`CreateTokenScreen.tsx`](../client/src/pages/CreateTokenScreen.tsx), [`ListingSubmitScreen.tsx`](../client/src/pages/ListingSubmitScreen.tsx), [`CampaignCreateScreen.tsx`](../client/src/pages/CampaignCreateScreen.tsx) |
| 10 | Swap execution could use a client-controlled or stale treasury destination. | Swap quotes require a server-provided treasury address, and execution rejects quotes without a valid EVM treasury address. | [`swap.ts`](../client/src/lib/wallet/swap.ts), [`SwapPanel.tsx`](../client/src/pages/SwapPanel.tsx) |
| 11 | SVG uploads created an XSS/content-type bypass risk. | Client file pickers now accept only PNG, JPEG, and WEBP; server-side data-URL and size validation remain in place. | [`CreateTokenScreen.tsx`](../client/src/pages/CreateTokenScreen.tsx), [`ListingSubmitScreen.tsx`](../client/src/pages/ListingSubmitScreen.tsx) |
| 12 | Create Token supply input was not sufficiently constrained before submission. | Supply is validated against a strict decimal pattern before the request is sent. | [`CreateTokenScreen.tsx`](../client/src/pages/CreateTokenScreen.tsx) |
| 13 | A factory configured with a nonzero on-chain fee could double-charge users after the backend fee flow was enabled. | `verifyTokenDeployment` decodes `TokenCreated` and rejects any matching event whose `feePaid` is not zero. The factory owner must set `feeAmount=0` before using the backend-only payment flow. | [`feeVerification.ts`](../server/feeVerification.ts), [`PaxiTokenFactory.sol`](../contracts/PaxiTokenFactory.sol) |
| 14 | Snapshot streaming lacked the required activity cursor index. | Added and deployed `activityEvents_user_id_idx` on `(userOpenId, id)`. | [`schema.ts`](../drizzle/schema.ts), [`applyActivitySchema.ts`](../scripts/applyActivitySchema.ts) |
| 15 | Bridge code retained a stale import and re-export of the removed hardcoded EVM wallet-fee constant. | Removed the import/re-export and updated the bridge documentation to describe backend fee configuration and LI.FI payout setup. | [`bridge.ts`](../client/src/lib/wallet/bridge.ts) |
| 16 | Fixed-fee verification converted database fee strings through JavaScript floating-point numbers. | Listing and token-creation fixed fees now remain exact decimal strings from the database through payment verification, activity recording, and listing persistence. | [`feeVerification.ts`](../server/feeVerification.ts), [`listings.ts`](../server/routers/listings.ts) |
| 17 | Campaign pool funding used binary floating-point multiplication and `.toFixed()` before on-chain verification. | The campaign UI now multiplies decimal USD text using `bigint`; the API validates and stores an exact decimal string. | [`CampaignCreateScreen.tsx`](../client/src/pages/CampaignCreateScreen.tsx), [`campaigns.ts`](../server/routers/campaigns.ts) |
| 18 | Wallet vendor chunking left a monolithic 621 kB minified wallet bundle. | Manual chunks now separate EVM, Solana, and Bitcoin dependencies. The largest wallet-specific chunk is now 283 kB, with no chunk-size warning above the configured 600 kB threshold. | [`vite.config.ts`](../vite.config.ts) |

## Verification evidence

| Gate | Result | Details |
|---|---|---|
| TypeScript | **PASS** | `pnpm check` completed with no diagnostics after the final changes. |
| Unit tests | **PASS** | 3 test files, 9 tests passed. The suite covers provider aggregation, security hardening, circuit breaker behavior, and logout behavior. |
| Production build | **PASS** | Vite client build and esbuild server bundle completed successfully. |
| Dependency security gate | **PASS with tracked upstream exception** | No fixable high/critical production advisories remain. One high advisory remains in the transitive `bigint-buffer` dependency through `@solana/spl-token`; the audit classifies it as upstream and currently unfixable. |
| Railway schema deployment | **PASS** | Idempotent deployment completed against the user-supplied Railway database without raw Drizzle migration execution. |
| Railway regression suite | **PASS** | All database tests passed, including the new activity cursor index assertion, foreign keys, collation checks, partitioning/index checks, fee/snapshot tables, and consolidated deployment ledger. |
| Production HTTP smoke | **PASS** | Latest bundle started on an isolated port with workers disabled: `/healthz=200`, `/readyz=200`, `/api/chains=200`, `/api/assets=200`, and a cross-site POST returned `403`. Readiness reported `database=true`. |

The smoke run intentionally used `ENABLE_WORKERS=false` and `REDIS_REQUIRED=false` to validate the graceful-degradation path. The server correctly logged that Redis was not configured and that distributed limits/workers were disabled. This is useful for boot validation, but it is not a substitute for a Redis-backed scale test.

## Database deployment state

The Railway deployment is in the consolidated idempotent ledger mode with six applied entries:

| Ledger entry | Status |
|---|---|
| `providers-v1` | Applied |
| `scale-partitioning-v1` | Applied |
| `identifier-collation-v1` | Applied |
| `reference-constraints-v1` | Applied |
| `optimization-indexes-v1` | Applied |
| `activity-fees-snapshots-v1` | Applied |

The legacy Drizzle ledger remains informational only. The project correctly avoids the disabled raw `drizzle-kit migrate` path and uses the idempotent deployment scripts for Railway.

## Remaining production risks

### 1. Solana PAXI fee destination is still unconfigured

`SOL_TREASURY_ADDRESS` in [`jupiterSwap.ts`](../client/src/lib/wallet/jupiterSwap.ts) is still empty. The code intentionally disables Jupiter platform fees until a real Solana treasury address is supplied. This prevents misdirected funds, but it also means Solana swaps currently do not collect the intended PAXI fee. A real Solana treasury address and corresponding backend configuration should be added before enabling Solana fee monetization.

### 2. LI.FI payout configuration is external to the repository

The bridge quote carries the backend-configured fee rate, but the actual LI.FI integrator payout destination is configured in the LI.FI Partner Portal per chain family. EVM and Solana payout addresses must be verified operationally before bridge fees are considered collected.

### 3. The upstream `bigint-buffer` advisory remains

The dependency audit reports a high advisory in `bigint-buffer@1.1.5` through `@solana/spl-token → @solana/buffer-layout-utils`. The project audit classifies it as an upstream, currently unfixable advisory. The dependency should be monitored and upgraded when the upstream chain publishes a compatible fix; a lockfile override should not be applied blindly because it could break Solana serialization behavior.

### 4. Bitcoin client code is still pulled into a static path

The production build continues to warn that `bitcoin.ts` is both dynamically and statically imported. This does not fail the build, and vendor bundles are now bounded, but a further lazy-loading pass for Bitcoin-specific screens would reduce initial JavaScript for users who never use Bitcoin.

### 5. Redis is required for the stated millions-of-users operating target

The application degrades safely when Redis is absent, but local in-process fallback cannot provide globally consistent rate limits, queue coordination, or circuit-breaker state across multiple replicas. Production deployment for millions of users should require managed Redis with TLS, connection limits, eviction policy review, monitoring, and failover testing.

### 6. On-chain factory configuration is an operational prerequisite

The deployed BSC factory must have `feeAmount=0` before the backend-only creation-fee flow is enabled. The verifier now rejects nonzero factory fees, so this is a safe failure mode, but deployment readiness must include an explicit owner transaction and a post-change read of `feeAmount`.

### 7. Financial-path test depth should continue to expand

The current automated suite is intentionally lightweight and does not execute live signed transactions or simulate every provider outage, RPC reorganization, queue retry, and multi-replica race. Before handling high-value production volume, add deterministic integration tests using mocked receipts and database transactions, followed by controlled staging tests against testnets and a Redis failover environment.

## Recommended release gates

The reviewed code is suitable for a controlled staging or limited production release after the following gates are completed. First, configure and verify the Solana treasury address if Solana fee collection is part of the launch scope. Second, set and verify the BSC factory `feeAmount` to zero. Third, deploy with mandatory managed Redis and run a multi-replica rate-limit and queue-failover test. Fourth, retain the dependency advisory exception in the release register and monitor upstream remediation. Fifth, complete a security review of the client-side wallet custody and transaction-signing model before advertising the product as a custodial-grade financial platform.

## Files delivered

The refreshed project archive is delivered separately as `paxi-wallet-final-architecture.zip`. The primary report is this file. The project source contains the complete implementation and deployment scripts used for the verification results above.

## References

[1]: ../drizzle/schema.ts "Paxi Wallet database schema"
[2]: ../server/wallet/transactionService.ts "Transaction lifecycle service"
[3]: ../server/wallet/transactionVerifier.ts "EVM transaction verifier"
[4]: ../server/feeVerification.ts "On-chain fee and factory deployment verification"
[5]: ../server/activity/activityService.ts "Activity ledger and eligibility service"
[6]: ../server/campaigns/snapshotService.ts "Campaign snapshot lifecycle service"
[7]: ../server/fees/feeEngine.ts "Backend fee calculation and audit engine"
[8]: ../server/routers/fees.ts "Server-owned fee and treasury endpoints"
[9]: ../server/routers/listings.ts "Listing and token-creation services"
[10]: ../server/routers/campaigns.ts "Campaign funding service"
[11]: ../client/src/lib/wallet/swap.ts "EVM swap quote and execution"
[12]: ../client/src/lib/wallet/bridge.ts "Bridge quote and execution"
[13]: ../client/src/lib/wallet/tokenFactory.ts "Token factory client flow"
[14]: ../client/src/pages/CampaignCreateScreen.tsx "Campaign funding UI"
[15]: ../vite.config.ts "Vite production chunking configuration"
[16]: ../scripts/applyActivitySchema.ts "Idempotent activity schema deployment"
[17]: ../scripts/dbRegressionTest.ts "Railway database regression suite"
[18]: ../scripts/dependencyAudit.mjs "Dependency security gate"
[19]: ../contracts/PaxiTokenFactory.sol "Paxi token factory contract source"
[20]: ../client/src/lib/wallet/jupiterSwap.ts "Solana Jupiter swap integration"
