# Discover logo source findings — 2026-08-27

External sources reviewed on 2026-08-27:

- Uniswap official brand-assets repository: https://github.com/Uniswap/brand-assets
- PancakeSwap official brand guidance and downloadable brand kit: https://docs.pancakeswap.finance/welcome-to-pancakeswap/about-us/brand
- OpenSea official logo resources: https://docs.opensea.io/docs/logos
- Uniswap official site: https://uniswap.org/
- Aave official site: https://aave.com/
- Curve official site: https://curve.finance/
- OpenSea official site: https://opensea.io/

The official PancakeSwap brand page confirms that PancakeSwap publishes downloadable official logo assets, but it does not expose a simple stable direct image URL suitable for the current static catalog without downloading and hosting the asset. The official OpenSea developer documentation likewise identifies official logo resources. The reviewed official sites confirm brand domains but do not establish stable direct image URLs for every curated entry.

Implementation rule: curated Discover entries may carry an explicitly authored HTTPS logo URL, but the logo source does not imply PAXI verification or safety. Domain-based favicon guessing remains disabled. AssetLogo accepts only HTTP(S) values, uses deterministic initials when unavailable, and supports an opt-in identity-scoped successful-logo cache for temporary image failures.

The existing `cdn.simpleicons.org` URLs are explicit HTTP(S) presentation sources, but they are third-party and were not verified as first-party brand assets. They must not be described as official or trusted sources. A future asset pass may replace individual entries only with directly verified first-party assets or locally hosted assets whose licensing and provenance are confirmed. Until then, omission of `logoUrl` and deterministic initials is safer than a fragile or misrepresented source. Discover listing or curation must not imply provider verification, safety, or endorsement.

The requested `https://jumper.exchange/favicon.svg` redirected to `https://jumper.xyz/favicon.svg` and rendered a first-party Jumper mark on 2026-08-27. This source may remain explicitly authored, with no claim that the DApp is PAXI-verified or safe.
