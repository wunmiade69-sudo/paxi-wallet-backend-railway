# Jupiter API verification

Sources consulted on 2026-08-27:

- https://dev.jup.ag/docs/api-reference/tokens/search
- https://dev.jup.ag/docs/guides/how-to-get-token-information
- https://dev.jup.ag/docs/tokens/token-information
- https://dev.jup.ag/docs/price

Verified facts:

- Current official Tokens API base URL is `https://api.jup.ag`.
- Token search endpoint is `GET https://api.jup.ag/tokens/v2/search`.
- Requests require the server-side `x-api-key` header; the key is obtained through the Jupiter Developer Platform portal.
- Search accepts a symbol, name, or mint address through the `query` parameter; exact mint matching is available from the `id` field.
- Token responses can include name, symbol, icon, decimals, USD price, liquidity, market cap, supply, holder count, verification, audit, 24-hour statistics, and update time.
- `audit.isSus` is conditional; its absence is not proof of safety.
- Jupiter documentation says to verify icon URLs from trusted domains before displaying them.
- Jupiter Price API documentation says missing or unreliable prices may be omitted rather than returned as zero; unavailable values must remain null.

Implementation decision:

- Add `JUPITER_API_KEY` only because the server adapter consumes it.
- Never expose the key to client code.
- If the key is missing, the provider fails, or the response does not contain an exact mint match, return null and preserve the existing on-chain fallback for decimals.
