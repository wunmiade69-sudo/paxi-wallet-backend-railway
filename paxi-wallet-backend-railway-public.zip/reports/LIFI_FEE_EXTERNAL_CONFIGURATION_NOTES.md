# LI.FI fee and external configuration notes

These notes record the external LI.FI documentation used during the final fee-hardening audit.

## Verified from official documentation

1. [Monetizing the integration](https://docs.li.fi/introduction/integrating-lifi/monetizing-integration) states that an integrator passes a fee percentage and an integrator string. It documents direct forwarding of fees to the configured fee wallet for EVM, Solana, Sui, and Bitcoin on supported chains.
2. [Fees and Monetization FAQ](https://docs.li.fi/faqs/fees-monetization) defines `fee` as a decimal percentage deducted from the sending token. The example unit is decimal percentage notation, so `0.005` represents 0.5%; the PAXI conversion is `basis points / 10,000`.
3. [FeeForwarder](https://docs.li.fi/introduction/integrating-lifi/fee-forwarder) states that the configured fee wallet is an external partner configuration and that the recipient receives newly forwarded fees at execution time on supported chains. Legacy balances and unsupported deployment coverage require separate operational verification.
4. [Integrator collected-fee data](https://docs.li.fi/api-reference/get-integrators-collected-fees-data-for-all-supported-chains) documents the integrator fee-balance endpoint and states that API authentication is registered through the LI.FI Partner Portal.

## Not verified from repository source

The repository cannot prove that the `paxiwallet` integrator is registered, that a specific LI.FI Partner Portal fee wallet is configured for every supported chain, that production `LIFI_API_KEY` credentials are active, or that a live fee-bearing bridge transaction paid the intended wallet. Those remain external configuration and live-transaction verification requirements.

The local `PAXI_TREASURY_ADDRESS` remains the PAXI application's own public treasury configuration for other fee paths. It is not evidence that LI.FI's externally configured partner payout wallet is the same address.
