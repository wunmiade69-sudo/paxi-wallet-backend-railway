# Market, Price, Chart, and Image Loading Diagnosis

## Checkpoint 1

The temporary server on port 4177 is alive and responds to `/healthz`, `/readyz`, `/api/chains`, and `/api/assets`. The asset endpoint returns populated asset records, but many records have `market: null` and `logoUrl: null`; some older database records have cached CoinGecko market data.

The server log shows repeated background market refresh failures caused by CoinGecko HTTP 429 rate limiting. The temporary process has no `REDIS_URL` and has background workers disabled, so distributed caching, BullMQ refresh workers, and shared rate-limit state are unavailable in this test instance. The browser reaches the onboarding screen, not the dashboard, until a local wallet is created or imported.

Next: inspect the exact client requests and chart route behavior, then verify provider fallback and database/API response paths independently.


## Checkpoint 2

Direct tRPC requests succeed server-side: `market.list`, `market.search`, `market.chart` for Bitcoin, `market.assetStats`, and `market.assetPrice` all return structured data. Binance klines and CoinGecko simple-price requests also return HTTP 200 from the sandbox.

The browser reaches the Create Wallet flow, but the automated click on the recovery confirmation did not advance; this may be an interaction-coordinate issue rather than a data issue. The market screens are not yet reachable in this browser session. The frontend currently uses direct Binance/CoinGecko requests for wallet prices and direct Binance/CoinGecko history in `AssetDetailScreen`, while the backend chart aggregator is wired only to `TokenDetailScreen`/tRPC. The server log still records CoinGecko 429s during background prewarm.


## Checkpoint 3

The onboarding flow works when the recovery phrase screen is fully revealed: the `I've Saved My Phrase` action advances to phrase verification. I am not completing the phrase verification because the generated recovery phrase is sensitive and unnecessary for diagnosing the server market endpoints. The browser’s initial screen therefore cannot reproduce dashboard market loading without a completed test wallet, but direct server requests already demonstrate that backend market list, chart, stats, and price routes return data.


## Checkpoint 4

Browser-origin fetch tests from the temporary public page return HTTP 200 for Binance klines, CoinGecko simple price, and a Trust Wallet PNG logo. The browser console has no application error beyond the diagnostic fetch output. This rules out a general browser CORS or image-host block. The remaining failures are likely caused by the frontend using separate direct-provider paths that do not cover all assets, stale/null asset metadata, server CoinGecko prewarm throttling, and missing image fallback behavior.


## Checkpoint 5 — Fix applied and verified

Implemented:

- Added server-side cached native pricing for BNB, ETH, BTC, SOL, POL, and Arbitrum ETH with Binance 24-hour ticker and CoinGecko fallback.
- Added `market.nativePrice` tRPC procedure.
- Changed dashboard balance loading to prefer the backend canonical price engine for native and contract assets, with direct providers retained only as a fallback.
- Changed held-asset charts to use `market.chart` and the backend provider chain instead of direct browser Binance/CoinGecko chart requests.
- Added visible symbol/emoji fallbacks for failed market, token-detail, and wallet asset images.
- Serialized market-data prewarming to avoid five simultaneous CoinGecko requests and reduce anonymous API throttling.

Verification:

- `npm run check`: passed.
- `npm test -- --run`: 37/37 tests passed.
- `npm run build`: passed.
- Fresh temporary server on port 4178: `/healthz` HTTP 200.
- Fresh public tRPC checks: `market.list`, `market.nativePrice`, and `market.chart` all returned live structured data.
- Browser verification: rebuilt public page mounted and reached the Welcome screen after the splash.


## Checkpoint 6 — User-reported Polygon/chart issues fixed

The screenshot showed three concrete issues: Polygon USDT displayed `no price feed`, the chart tooltip rendered `1/1/1970`, and the existing chart was a simple Recharts line chart rather than the requested professional/original OHLC chart. A market token detail screen could also fail entirely when CoinGecko detail calls were rate-limited.

Implemented fixes:

1. Added exact-address `verified-stablecoin-peg` pricing for Polygon USDT and Polygon USDC, plus the configured Ethereum, BSC, and Arbitrum USDT/USDC contracts. Polygon USDT now returns exactly `{ priceUsd: 1, change24h: 0 }` from `market.assetPrice` without waiting for DexScreener.
2. Added `ProfessionalMarketChart` using `lightweight-charts` v5 with candlestick OHLC data, area fallback, crosshair labels, responsive resize handling, and a visible source/fallback marker.
3. Updated `market.chart` to return full OHLCV fields and normalize both primary and legacy fallback timestamps with `timestampMs`, preventing seconds-as-milliseconds 1970 dates.
4. Corrected the 1H chart mapping from 60 hourly candles to 60 five-minute candles.
5. Replaced both TokenDetailScreen and held AssetDetailScreen line charts with the professional chart component.
6. Added cached market-summary fallback data for TokenDetailScreen when CoinGecko detail calls are rate-limited, so the token page does not collapse to `Couldn't load this token`.
7. Held USDT/USDC detail headers now display `$1.00` even when the balance price cache is temporarily empty.

Verification on fresh public port 4179:

- `/healthz`: HTTP 200.
- Polygon USDT `market.assetPrice`: returned `priceUsd: 1`, source `verified-stablecoin-peg`.
- Polygon USDC `market.chart`: returned OHLCV candles with millisecond timestamps such as `1786554000000`, not seconds.
- `market.detail` for `usd-coin`: returned cached summary data instead of null.
- Browser: rebuilt page mounted and reached the Welcome screen after splash.


## Checkpoint 7 — Token chart fallback completed

The first verification showed `market.chart` for `usd-coin` could still return an empty array when both CoinGecko detail/history and the DEX chart path were unavailable. Added a server-side Binance Vision OHLCV fallback for common CoinGecko IDs, including `usd-coin`, `tether`, bitcoin, ethereum, BNB, SOL, POL, DAI, DOGE, XRP, ADA, AVAX, LINK, TRX, and SHIB. Binance candles preserve real open, high, low, close, volume, and millisecond open-time values.

Final verification on port 4180 returned:

| Endpoint | Result |
|---|---|
| `/healthz` | HTTP 200 |
| Polygon USDT `market.assetPrice` | `$1.00`, `verified-stablecoin-peg` |
| `usd-coin` `market.chart` | Non-empty OHLCV response with millisecond timestamps |
| Browser application | Mounts and reaches onboarding |

The chart service still prefers the configured DEX provider chain when it has a valid pair. The Binance path is a provider fallback, not fabricated data; if both DEX and Binance lack a supported market, the UI now reports that history is unavailable instead of rendering a misleading date or empty chart shell.


Final browser verification on the rebuilt port 4180 instance completed successfully. The PAXI shell loaded through the splash state and reached the Welcome screen with Create Wallet and Import Wallet controls visible. No blank startup page or bootstrap error appeared.


## Checkpoint 8 — Live chart and stablecoin presentation hardening

The screenshots correctly exposed that a chart can be visually present but still stale: the chart data was cached for several minutes, the current header quote was not connected to the chart, and BNB native history was coming from CoinGecko instead of a live OHLC exchange feed.

Implemented:

- Added a live price line titled `LIVE` to `ProfessionalMarketChart` using the Lightweight Charts price-line API.
- TokenDetailScreen now refreshes token details every 15 seconds, live contract prices every 15 seconds, and chart candles every 30 seconds.
- Held AssetDetailScreen now refreshes native/contract prices every 15 seconds and chart candles every 30 seconds.
- Reduced server chart-cache TTLs for `1h`, `4h`, and `1d` charts to 45 seconds, 120 seconds, and 600 seconds respectively. The price line still updates faster than candle boundaries.
- Added Binance-native OHLCV priority inside the chart service for BNB, ETH, BTC, SOL, POL, and Arbitrum ETH. CoinGecko remains the fallback when Binance is unavailable.
- Verified stablecoin contract addresses are no longer displayed on TokenDetailScreen. Polygon USDT remains configured internally for balance and price resolution; only the user-facing contract card is hidden.

Final temporary instance verification on port 4181:

- BNB Smart Chain native chart returned `source: "binance"` and `fallback: false` with full OHLCV candles.
- BNB live server price returned `source: "binance"`.
- Polygon USDT returned `$1.00` from `verified-stablecoin-peg`.
- Millisecond timestamps remained normalized and no 1970 epoch conversion was present.


## Checkpoint 9 — End-user chart labels and official PAXI logo registry

The provider label shown in the screenshot (`OHLCV · coingecko · fallback`) was an internal diagnostic and not appropriate for end users. The chart component now renders only the chart itself and the LIVE price line; provider names and fallback status remain available in the API and component props for diagnostics but are no longer displayed.

The project now includes `scripts/setOfficialTokenLogo.ts` and the npm command `npm run asset:set-logo`. The command updates or creates the BSC PAXI token listing for `0xeda04581461bc308e60052fe489e20c3f78d6e4e`, marks it verified, stores the logo URL, and synchronizes the same logo to the universal `assets.logoUrl` registry. Once a real PAXI logo URL is supplied, every user importing/viewing that asset through the shared registry will receive the same logo; the logo is not stored only in one device's local storage.

Final public verification on port 4182: the rebuilt application mounted and reached the Welcome screen successfully. TypeScript, tests, and production build all passed.


## Checkpoint 10 — Premium PAXI identity and verified badge polish

The first-run experience was refreshed using the official PAXI logo URL. The splash now presents the logo in a gold-rimmed circular mark with a dark-gold radial glow, a restrained grid texture, secure-beta status, multi-chain feature chips, and a calmer initialization indicator. The welcome screen now uses the same identity system, a self-custody badge, an explicit security statement, clearer Create/Import Wallet actions, and a compact encrypted-on-device footer.

The official PAXI BSC token identity is now represented by the shared `isOfficialPaxiToken` check, the official logo URL, and a reusable `VerifiedBadge`. The badge is shown in the official PAXI token detail and held-asset detail surfaces, while Markets shows the badge and official logo for the exact official PAXI market identity. Unrelated tokens are not marked verified.

Temporary preview verification: https://4184-ickyfhprexsr7snedk2zv-d89f8a30.us4.manus.computer/ . The premium splash mounted with the official logo, transitioned to the redesigned welcome screen, and exposed both onboarding actions without a startup error.
