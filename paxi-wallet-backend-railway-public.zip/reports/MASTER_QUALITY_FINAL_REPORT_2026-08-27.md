# PAXI Wallet — Master Quality Final Report

**Date:** 27 August 2026  
**Baseline:** `/tmp/paxi-wallet-rebased-complete/paxi-wallet`  
**Author:** Manus AI  
**Scope:** Local production-quality audit and implementation pass only. No deployment, production migration, production SQL, production secrets, private keys, signing, broadcasting, or real-fund testing was performed.

> **Release classification: BLOCKED — STAGING RESOURCES UNAVAILABLE**

The local implementation and regression gates are substantially cleaner than the inherited baseline, but local test success is not a staging or production approval. Isolated Railway staging resources were not supplied and no staging deployment or chaos/load validation was performed.

## 1. Stage-by-stage status

| Stage | Area | Status | Evidence / disposition |
|---:|---|---|---|
| 1 | Full repository audit | Complete locally | Evidence-based issue map exists in `MASTER_QUALITY_STAGE1_ISSUE_MAP_2026-08-27.md`. |
| 2 | Discover logo regression | Complete locally | Unverified Simple Icons URLs removed; only explicitly authored/verified sources are retained, otherwise initials are used. |
| 3 | Assets search completion | Complete locally | Search remains display-oriented; canonical identity/provenance is preserved at the domain boundary. |
| 4 | Markets search completion | Complete locally | Native identity matching uses `chain:native`; pagination now exposes only provider-derived `hasMore`. |
| 5 | Home search / add token | Complete locally | Duplicate/identity handling remains canonical; EVM on-chain metadata and Solana Jupiter-first metadata are isolated appropriately. |
| 6 | Token metadata and logo resolution | Complete locally | Field-level provenance, safe explicit logos, identity-scoped successful-logo cache, and truthful null handling are present. |
| 7 | Chart system | Complete locally | Charts remain genuine provider candles; Binance transport now uses shared provider resilience. Missing candles are not fabricated. |
| 8 | Liquidity architecture | Complete locally | User-facing DEX data is deepest-pair DexScreener data and is labeled pair-level. Jupiter total liquidity remains semantically separate. |
| 9 | Provider resilience | Complete locally | Shared timeout, response cap, circuit breaker, Redis cooldown, malformed-response degradation, and provider tests are present. |
| 10 | RPC architecture | Complete locally | Server reward/risk/referral paths use canonical RPC failover. Client wallet RPC reads remain only where required for non-custodial wallet behavior. |
| 11 | Fees | Complete locally | Fee capability and treasury configuration remain chain-aware; unsupported Solana/Bitcoin settlement is not enabled by address presence. EVM approvals no longer use unlimited allowances in Swap/Bridge. |
| 12 | Notifications | Complete locally | Shared notification bell/store is retained. Transaction notifications carry exact hash and originating network targets. |
| 13 | Notification frequency | Complete locally | Price alerts retain threshold, direction, cooldown, and deduplication behavior. |
| 14 | Assets refresh / shake | Local code/tests complete | Mounted tab containers and cached state paths remain intact; no browser-session manual verification was performed in this run. |
| 15 | Tab scroll isolation | Local code/tests complete | Existing independent tab-container architecture is preserved and stability assertions pass; no claim of manual browser verification. |
| 16 | Me tab | Audited locally | `onWalletGuide` was not removed blindly because it is consumed by PAXI AI support. Unavailable states remain explicit where data cannot be established. |
| 17 | Admin consolidation | Audited locally | `AdminScreen` and `AdminReviewPanel` remain the active admin experience; `AdminReviewScreen` remains compatibility-only. No contradictory replacement UI was introduced. |
| 18 | UI/UX language | Partial local audit | Product-facing false certainty was corrected where found, including native security status. Admin diagnostics may retain technical terminology. A complete manual copy review still belongs in staging/UI QA. |
| 19 | Design system consistency | Local code/build complete | Existing design system and stable components were preserved; no second visual language was introduced. |
| 20 | Wallet coverage | Local tests complete | EVM, Solana, and Bitcoin assumptions remain separated. Invalid-address, unsupported-chain, insufficient-funds, RPC-failure, and rejection paths are test-covered where implemented. No real-fund execution occurred. |
| 21 | Search / data consistency | Local architecture complete | Canonical chain plus contract/mint/native identity and field provenance are used across the tested token journey. Live cross-screen manual journey was not claimed. |
| 22 | Provider/API inventory | Complete | Definitive implemented/not-implemented provider table is included below. |
| 23 | Environment inventory | Complete | Exact consumed-variable inventory is included below; values are intentionally omitted. |
| 24 | Security and resilience | Complete locally | TypeScript, full tests, build, dependency audit, credential/private-key scan, and merge-marker scan were run. |
| 25 | Final UI regression | Not manually completed | Code-level and source-level tests pass, but no browser takeover/manual UI session was performed. |
| 26 | Currency setting | Complete locally | USD/EUR/GBP conversion path is server-backed through tRPC with local 30-minute cache and stale fallback. |
| 27 | Performance | Local audit complete; staging measurement pending | Duplicate browser provider calls were removed from market/liquidity/chart/security paths. Build still reports a large wallet chunk warning. No p50/p95/p99 production-like measurement was made. |
| 28 | Staging preparation | Blocked | Separate database, Redis, OAuth, provider credentials, and test wallets were not supplied. |
| 29 | Staging load / chaos | Not run | No isolated staging environment exists in this task. |
| 30 | Final release gate | Blocked | Classification is exactly **BLOCKED — STAGING RESOURCES UNAVAILABLE**. |

## 2. Bugs discovered

The highest-impact confirmed defects were duplicated browser-side market/provider calls, symbol-only or contract-only identity assumptions, unverified third-party logo URLs, unconditional Markets pagination, a native security branch styled as green Safe, direct GoPlus/risk-provider transports bypassing the shared boundary, duplicate BSC RPC logic in reward services, fabricated-looking referral-host defaults, and unlimited ERC-20 approval construction in Swap/Bridge. These were corrected or isolated where the existing architecture provided a safe seam.

The remaining material blocker is operational rather than a local compile/test defect: staging resources and controlled staging validation are unavailable. The current build also retains large client chunks and existing bundler warnings.

## 3. Root causes

The recurring root cause was boundary duplication: screens and wallet helpers had accumulated direct provider calls instead of consistently using the existing server domain and canonical resolver. Other root causes were display identifiers being reused as identity, optimistic UI wording in unavailable states, and test mocks retaining queued provider responses between cases. The latter was corrected by resetting provider mocks between native-price cases; explicit provider `null` values are now kept as `null` rather than coerced to zero.

## 4. Files changed

The Master Quality implementation touched the following principal areas. This is a functional inventory, not a claim that unrelated historical files were rewritten.

| Area | Principal files |
|---|---|
| Market, price, chart, currency | `server/priceEngine.ts`, `server/chartService.ts`, `server/currency.ts`, `server/marketData.ts`, `server/marketProviders.ts`, `server/dexLiquidity.ts`, `server/routers/market.ts`, `server/routers.ts` |
| Provider adapters | `server/jupiter.ts`, `server/veloraQuote.ts`, `server/jupiterSwap.ts`, `server/lifiQuote.ts`, `server/thorchain.ts`, `server/providers/http.ts`, `server/contractSecurity.ts`, `server/riskEngine.ts` |
| Swap/bridge boundary | `server/routers/swap.ts`, `client/src/lib/wallet/swap.ts`, `client/src/lib/wallet/jupiterSwap.ts`, `client/src/lib/wallet/thorchain.ts`, `client/src/lib/wallet/bridge.ts` |
| RPC and rewards | `server/chains/rpc.ts`, `server/rewards/referralTradingVerifier.ts`, `server/rewards/rewardClaimService.ts`, `server/rewards/rewardPoolService.ts` |
| Identity and Discover | `client/src/lib/marketIdentity.ts`, `client/src/lib/wallet/discover.ts`, `client/src/pages/MarketsScreen.tsx`, `client/src/components/AssetLogo.tsx`, `client/src/components/PaxiShieldPanel.tsx`, `client/src/lib/wallet/customTokens.ts`, `client/src/lib/currency.ts`, `client/src/lib/wallet/referral.ts` |
| Notifications and navigation | `client/src/lib/phase3Models.ts`, `client/src/lib/phase3Local.ts`, `client/src/App.tsx`, `client/src/pages/TransactionHistoryScreen.tsx`, `client/src/components/TransactionList.tsx`, `client/src/pages/SendScreen.tsx`, `client/src/pages/SwapPanel.tsx`, `client/src/pages/BridgePanel.tsx`, `client/src/pages/ThorchainSwapPanel.tsx` |
| Regression coverage | `server/jupiter.test.ts`, `server/currency.test.ts`, `server/priceEngine.test.ts`, `server/swapProviders.test.ts`, `server/contractSecurity.test.ts`, `server/security-hardening.test.ts`, `client/src/components/AssetLogo.test.ts`, `client/src/lib/wallet/balances.test.ts`, `client/src/lib/wallet/customTokens.metadata.test.ts`, `client/src/lib/wallet/discover.test.ts`, `client/src/lib/wallet/referral.test.ts`, `client/src/pages/AssetDetailScreen.test.ts`, `client/src/phase7Stability.test.ts`, and updated wallet provider tests |

The old browser-only `client/src/lib/wallet/tokenSecurity.ts` direct GoPlus helper was removed because the active security UI uses the server security router.

## 5. Architecture changes

The consistent runtime direction is now **UI → tRPC/domain service → canonical resolver/aggregator → provider adapter → shared resilience → cache → external provider/RPC**. Portfolio quotes use one bounded server batch endpoint. Currency conversion, Jupiter token metadata, Velora quote/build, Jupiter quote/instructions, THORChain quote/status, LI.FI quote, GoPlus, risk liquidity, chart provider calls, and reward verification paths use server-owned boundaries where applicable.

Signing, transaction assembly using wallet-controlled data, wallet-specific RPC reads, and broadcast behavior remain client-side where required by the non-custodial design. No private key or seed is moved to the server.

## 6. Provider changes

Direct browser market, chart, liquidity, security, DEX, and CEX provider calls were removed or isolated. Shared provider HTTP behavior includes bounded timeout, response-size limits, circuit-breaker behavior, Redis cooldown for rate-limit/server failures, and truthful null degradation. Provider listing is not treated as PAXI verification, and an unavailable security result is not treated as safe.

## 7. Search status

Search and add-token flows preserve canonical identity: EVM identity uses chain plus contract, Solana identity uses chain plus mint, and native assets use explicit native identity. Duplicate selection logic is no longer dependent only on display symbol where a counterpart asset identity is available. Provider absence remains an unavailable result rather than a fabricated token.

## 8. Logo status

Discover no longer relies on the previously added unverified `cdn.simpleicons.org` URLs. Explicit first-party sources are retained only where directly verified; otherwise deterministic initials are intentional. `AssetLogo` caches only successful safe HTTP(S) loads under an identity-scoped key, preventing one asset from inheriting another asset’s cached image. No generic favicon aggregator is used.

## 9. Chart status

Charts are backed by genuine provider candles and preserve provider/source semantics. Native chart requests use the shared provider transport. No missing candle, price, or history value is converted into a visual placeholder that could be mistaken for real data.

## 10. Liquidity status

The user-facing DEX card reports the deepest actual DexScreener pair snapshot and is labeled **pair-level liquidity**. It does not claim total protocol liquidity or aggregate chain liquidity. Jupiter total token liquidity, when available for Solana, remains a separate provider-derived field and is not conflated with a DexScreener pair snapshot. Unimplemented Uniswap, PancakeSwap, Raydium, and Orca adapters were not invented.

## 11. Notification status

The shared local notification system and global bell remain the only notification path. Transaction producers in Send, Swap, Bridge, and THORChain use exact broadcast hashes and originating network targets. Notification target validation bounds hashes and preserves backward-compatible local storage. Price alerts retain threshold, cooldown, direction, and deduplication controls.

## 12. Discover status

Discover categories are non-empty where curated data exists, the network picker and search remain in the existing screen architecture, favorites/recents fall back to initials when no explicit image is available, and DApp entries do not infer logos from domains. The logo-source findings are recorded in `DAPP_LOGO_SOURCE_FINDINGS_2026-08-27.md`.

## 13. Assets status

Assets uses the server portfolio quote batch for market values rather than direct Binance, CoinGecko, DexScreener, or browser-side market fallbacks. Wallet balance reads remain client-side only where necessary for non-custodial wallet state. Cached portfolio and local notification behavior are preserved. A full manual browser refresh/navigation session remains pending staging/UI verification.

## 14. Markets status

Markets uses canonical native identity matching (`chain:native`) and does not label every contractless result as held. The server returns a bounded `hasMore` signal based on a real lookahead item rather than invented totals. Next is disabled when the provider gives no evidence of another page. Logos, charts, and liquidity retain their existing shared/domain paths.

## 15. Me status

The Me and support surfaces were audited without removing the active `onWalletGuide` seam: PAXI AI support consumes it. Security, approvals, connected DApps, and transaction areas retain honest unavailable behavior where validated data is absent. No static security claim was promoted to verified state.

## 16. Admin status

Admin remains consolidated around `AdminScreen` and `AdminReviewPanel`, with `AdminReviewScreen` retained as a compatibility re-export. Existing approval protections, audit reasons, role checks, and wallet-key protection were not redesigned. Administrative diagnostics may use technical provider/database terminology; those are not user-facing product claims.

## 17. Wallet status

EVM, Bitcoin, and Solana flows remain separate. Invalid addresses and unsupported networks are rejected through existing validation; RPC failures and transaction rejections remain explicit failure paths. Bitcoin and Solana are not forced through EVM assumptions. No wallet was connected for a real-fund action and no transaction was signed or broadcast during this pass.

## 18. Fee architecture status

The fee system remains server-owned for EVM fee configuration and proof verification. Treasury address presence is not treated as settlement activation. Current capability is EVM-oriented; Solana and Bitcoin fee settlement are not implemented as enabled payment paths. Swap and Bridge ERC-20 approvals now use the exact quoted source amount instead of `MaxUint256`; user signing and broadcast remain local.

## 19. Environment variables actually consumed

The table below lists names observed in the current code. Values are deliberately excluded. Variables used only by migration/maintenance scripts are marked accordingly and must not be added to a deployment merely because they appear in a script.

| Variable | Required/optional | Purpose / side | Provider or subsystem | Actually read |
|---|---|---|---|---|
| `DATABASE_URL` | Required for DB features | Primary server database | MySQL/TiDB | Yes |
| `DATABASE_READ_URL` / `DATABASE_REPLICA_URL` | Optional | Read replica fallback | MySQL/TiDB | Yes |
| `REDIS_URL` | Optional by default | Cache, cooldowns, coordination | Redis-compatible service | Yes |
| `REDIS_REQUIRED` | Optional | Makes Redis part of readiness policy | Redis | Yes |
| `REDIS_TLS_REQUIRED` | Optional | Requires `rediss://` | Redis | Yes |
| `ENABLE_WORKERS` | Optional; default false | Opt-in BullMQ workers | BullMQ/Redis | Yes |
| `WORKER_CONCURRENCY` | Optional | Worker tuning when enabled | BullMQ | Yes |
| `ENABLE_MARKET_PREWARM` | Optional | Market prewarm control | Market domain | Yes |
| `JWT_SECRET` | Required for authenticated production operation | Server cookie/session secret | Auth | Yes |
| `VITE_APP_ID` | Existing app configuration | Client/server app identity | Auth/app | Yes |
| `OAUTH_SERVER_URL` | Required when OAuth is used | OAuth server | Auth | Yes |
| `VITE_OAUTH_PORTAL_URL` | Optional client value | OAuth portal navigation | Client auth | Yes |
| `VITE_WC_PROJECT_ID` | Optional | WalletConnect client project ID | WalletConnect | Yes |
| `OWNER_OPEN_ID` | Optional/role configuration | Owner/admin mapping | Admin | Yes |
| `PAXI_TREASURY_ADDRESS` | Optional until fee settlement is configured | EVM treasury destination | Fees | Yes |
| `PAXI_SOLANA_TREASURY_ADDRESS` | Optional, display/config only | Solana treasury inventory | Fees | Yes |
| `PAXI_BITCOIN_TREASURY_ADDRESS` | Optional, display/config only | Bitcoin treasury inventory | Fees | Yes |
| `PAXI_BSC_FACTORY_ADDRESS` | Optional | BSC factory verification | Campaign/token flows | Yes |
| `PAXI_TRUSTED_BRIDGE_ADDRESSES` | Optional | Trusted bridge verification configuration | Bridge verification | Yes |
| `LIFI_API_KEY` | Optional | Server-side LI.FI requests | LI.FI | Yes |
| `BIRDEYE_API_KEY` | Optional | Solana token/market fallback | Birdeye | Yes |
| `DEXPAPRIKA_API_KEY` | Optional | DEX market fallback | DexPaprika | Yes |
| `JUPITER_API_KEY` | Optional | Jupiter Tokens and swap server calls | Jupiter | Yes |
| `COINGECKO_API_KEY` | Optional | Native-price/chart fallback where configured | CoinGecko | Yes |
| `BSC_RPC_URL` | Optional | Configured BSC RPC override, read dynamically | BSC RPC | Yes |
| `BUILT_IN_FORGE_API_URL` / `BUILT_IN_FORGE_API_KEY` | Optional, feature-specific | Built-in storage/AI services | Forge | Yes |
| `S3_BUCKET` / `S3_REGION` / `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` / `S3_ENDPOINT` | Optional, storage-specific | S3-compatible object storage | S3/R2 | Yes |
| `METRICS_TOKEN` | Optional | Metrics endpoint protection | Metrics | Yes |
| `TRUST_PROXY_HOPS` | Optional | Express proxy trust | Server | Yes |
| `NODE_ENV` | Runtime | Production/development behavior | Node | Yes |
| `PORT` | Runtime/platform supplied | HTTP listener port | Railway/platform | Yes |
| `DATABASE_SSL` / `DB_POOL_SIZE` | Optional | Database transport/pool tuning | MySQL/TiDB | Yes |
| `VITE_FRONTEND_FORGE_API_URL` / `VITE_FRONTEND_FORGE_API_KEY` | Optional client values | Existing map/client feature | Client Forge | Yes |
| `TEST_REDIS_STATUS` | Test-only | Deterministic Redis test seam | Tests | Yes |

**Important:** `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` are not present in the current consumed-variable inventory. The current implementation reads `REDIS_URL` through ioredis. They must not be added or described as active unless the code is intentionally changed and revalidated.

## 20. Tests

The final local run used the repository’s npm scripts and Vitest. The complete suite result was:

| Gate | Result |
|---|---|
| `npm run check` | Passed; TypeScript emitted no errors. |
| `npm test -- --run` | Passed: **76 test files, 294 tests**. |
| Focused Stage 3 provider/security tests | Passed: 19 tests in the final focused run. |
| `npm run lint` | No result because the package has no `lint` script; npm exited with `Missing script: "lint"`. |
| `npm audit --omit=dev` | Completed with exit 1 because **16 inherited vulnerabilities** were reported: 7 low and 9 moderate; no high/critical findings were reported in the command output. |

The suite includes mocked coverage for provider timeout/rate-limit/malformed/null paths, canonical identities, price batching and native fallback, Jupiter exact-mint behavior, currency normalization, logo cache isolation, custom-token metadata fallback, transaction targets/deduplication, approval limits, and wallet/provider boundary behavior. No test uses production credentials or real funds.

## 21. Build

`npm run build` passed. Vite produced the client assets and esbuild produced `dist/index.js` at approximately 478 KB. Existing warnings remain: a Rollup pure-annotation warning, dynamic/static import overlap for wallet modules, and a minified wallet chunk above the 600 KB warning threshold. These are performance follow-ups, not a failed build.

## 22. Security scan

The merge-marker scan found no `<<<<<<<`, `=======`, or `>>>>>>>` markers outside excluded dependency/build directories. The private-key scan found zero PEM private-key markers. The GitHub personal-token pattern scan found zero matches. A broad `sk-` pattern produced only false-positive matches such as source words containing `risk-` and package names containing `task-list-item`; values were redacted during review and no credential was identified. No secrets were copied into the report or archive.

The dependency scan was not “fixed” with `npm audit fix --force`; that prohibited breaking-change action was not run.

## 23. Dependency audit

`npm audit --omit=dev` reported the inherited dependency advisories described above, including transitive WalletConnect/elliptic/uuid-related findings. The audit output itself suggested potentially breaking force fixes. No automatic force upgrade was performed. Dependency remediation requires a separate compatibility review and staging regression pass.

## 24. Staging results

No staging results exist. There was no isolated Railway project/environment with separate database, Redis, OAuth, provider credentials, or test wallets available for this task. Consequently, `/healthz`, `/readyz`, provider-outage behavior, Redis outage behavior, RPC outage behavior, rate limiting, database restart, authentication, and latency percentile measurements were not claimed as validated in staging.

## 25. Remaining limitations

The release remains blocked by unavailable staging resources. Manual browser verification of all Assets, Markets, Discover, Trade, Me, notification deep links, scroll isolation, refresh/return behavior, and mobile layouts remains outstanding. The build’s large wallet chunk remains a performance warning. The dependency audit has 16 inherited low/moderate findings. Live Upstash connectivity is not verified, and the current code consumes `REDIS_URL`, not Upstash REST variables. Provider availability, rate limits, terms, and pricing require final staging credentials and operational review.

The system still intentionally does not claim unsupported capabilities: total protocol liquidity, unimplemented chain fee settlement, unverified asset safety, missing charts, missing logos, or provider results unavailable at runtime. No Uniswap/PancakeSwap/Raydium/Orca adapter was fabricated.

## 26. Exact release classification

> **BLOCKED — STAGING RESOURCES UNAVAILABLE**

This classification is definitive for the current pass. Local gates passing does not authorize production approval. Stage 28/29 may proceed only after explicit authorization and provision of an isolated staging environment containing a separate database, separate Redis, staging OAuth, staging-only provider credentials, test wallets, and testnet funds where necessary. Production secrets, production databases, private keys, seed phrases, signing, real-fund testing, and production deployment remain out of scope.

## References

[1]: https://dev.jup.ag/docs/tokens/v2/search "Jupiter Tokens API — Search"
[2]: https://dev.jup.ag/docs/swap/build-swap-transaction "Jupiter Swap API — Build Swap Transaction"
[3]: https://developers.velora.xyz/ "Velora Developer Documentation"
[4]: https://docs.li.fi/ "LI.FI Developer Documentation"
[5]: https://dev.thorchain.org/ "THORChain Developer Documentation"
[6]: https://docs.railway.com/quick-start "Railway Quick Start Documentation"
