# PAXI Wallet Master Quality — Phase 1 Issue Map

Date: 2026-08-27
Repository baseline: `/tmp/paxi-wallet-rebased-complete/paxi-wallet`

## Scope

This pass is limited to Assets stability, token search, Add Token, Markets held-asset matching, and Token Detail. Broader provider centralization, wallet/RPC, fees, notifications, admin, currency, performance, and staging work remain out of scope for this phase.

## Confirmed baseline behavior

| Area | Evidence | Assessment |
|---|---|---|
| Assets refresh | `Dashboard.tsx` retains the current balance map during streaming refresh, commits snapshots through `balanceCache`, and shows `…` only for never-resolved assets | Existing behavior is aligned; preserve it |
| Asset row keys | Dashboard rows use `assetKey(asset)` and custom-token deletion uses the same canonical key | Existing behavior is aligned |
| Assets search | `AssetSearchDrawer` is a real query path with network filtering and Add Token callback | Verify result identity/logo behavior through tests |
| Add Token | `AddTokenScreen` reads EVM metadata on-chain and Solana metadata through server Jupiter first with on-chain decimals fallback; duplicate persistence is guarded in `customTokens.ts` | Preserve and test truthful failures/post-add path |
| Markets held matching | Markets uses canonical chain + contract/mint or `chain:native`, but passes `undefined` balance to Asset Detail | Concrete defect: must use the existing cached balance snapshot |
| Markets pagination | Markets consumes a server `hasMore` signal and disables Next when absent | Preserve and test |
| Token Detail | Detail/chart/security use server tRPC paths and show unavailable states without fabricated values | Add coverage for held identity, Add-to-Wallet, and truthful fields |
| Logo safety | Shared `AssetLogo` accepts safe HTTP(S) sources and falls back to initials; custom-token persistence still contains a legacy Trust Wallet URL guess | Phase 1 policy requires explicit safe source or initials; remove unverified URL guessing |

## Required implementation decisions

1. Do not redesign wallet reads or provider architecture.
2. Use the existing in-memory `balanceCache` as the only additive seam for Markets-to-Asset Detail balance handoff.
3. Keep canonical identity as chain + contract/mint/native identity; never use symbol/name as identity.
4. Keep unavailable price/chart/liquidity/security data null or visibly unavailable.
5. Do not introduce production resources, migrations, real-fund operations, signing, broadcasts, or live-provider tests.
6. Do not begin the broader Phase 2 work until this phase’s focused tests, full Vitest suite, TypeScript check, and build are clean.
