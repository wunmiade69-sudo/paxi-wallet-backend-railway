# PAXI Wallet Master Quality Phase — Stage 1 Issue Map

**Baseline:** `/tmp/paxi-wallet-rebased-complete/paxi-wallet`

**Scope:** Evidence-based audit of the current repository against the attached master quality specification. This document records verified implementation facts and remaining gaps before further changes. It does not claim live-provider, Railway, staging, or production validation.

## Executive assessment

The repository already contains substantial safety work: canonical chain-plus-contract/mint identity in the token-data presentation path, field-level provenance, null-safe market values, shared provider resilience for the primary market adapters, structured notification targets, origin-aware notification navigation, separate mounted tab scroll containers, a consolidated admin route, and curated Discover logo filtering. Local validation from the immediately preceding phase was green.

The master-quality audit also confirms several remaining gaps. The largest is architectural: held-asset balances and several Trade/wallet utility modules still perform browser-side calls to external market, chart, DEX, fiat-rate, security, and chain services. These paths preserve degraded/offline behavior and must not be removed blindly, but they remain duplicated relative to the required server-side domain-service → canonical resolver → provider adapter → resilience → cache flow. The next implementation work must narrow this gap without touching signing or broadcast boundaries.

## Confirmed completed protections

| Area | Evidence-based status |
|---|---|
| Token identity | Search and presentation adapters retain network plus contract/mint identity; symbol/name alone is not used for canonical token deduplication. |
| Field provenance | Market and client presentation models carry field-level sources; unavailable fields remain omitted or null. |
| Search/Add Token | Add Token persists metadata provenance and applies safe HTTP(S)-only logo handling while preserving trusted PAXI/listing precedence. |
| Market values | Stablecoin peg shortcuts and misleading zero/unknown changes were removed from the canonical price paths audited in the previous phase. |
| Charts | Existing genuine historical chart component and server fallback pipeline are preserved; no synthetic candles were introduced. |
| Liquidity | No-pair results return null in the canonical boundary; held-asset wording identifies the displayed value as pair-level rather than ecosystem aggregate. |
| Provider resilience | CoinGecko, Birdeye, DexPaprika, and DexScreener server paths use the shared resilience helper in the audited market/liquidity modules. |
| Notifications | Structured canonical targets, read state, deduplication, origin-aware navigation, and shared bell entry points are implemented. |
| Discover | Curated categories are filtered to actual entries; explicit safe HTTPS logos are accepted; arbitrary favicon guessing is not used as the primary curated source. |
| Tab isolation | App keeps major tabs mounted in separate `h-[100dvh] overflow-y-auto` containers and hides inactive tabs rather than remounting all tabs. |
| Admin | `AdminScreen` is the shipped consolidated route and embeds the review panel with audited reason dialogs; the legacy review screen is a compatibility shim. |
| Fee truthfulness | Active fee verification is EVM-only for Ethereum/BSC stablecoin proofs; Solana/Bitcoin treasury configuration does not imply enabled settlement. |
| RPC safety | The server has a canonical RPC registry/failover helper with URL validation and only the confirmed `BSC_RPC_URL` environment override. |

## Verified remaining gaps

| Priority | Area | Finding | Safe direction |
|---|---|---|---|
| P0 | Canonical architecture | `client/src/lib/wallet/balances.ts` still fetches Binance and CoinGecko prices/charts directly, and invokes browser DexScreener/on-chain reserve fallbacks after the tRPC attempt. | Add or reuse server procedures for held-asset market snapshots/history, preserving the current client fallback only where it is explicitly required for offline/degraded operation and clearly marked. Do not delete wallet RPC balance reads. |
| P0 | Canonical architecture | `client/src/lib/wallet/dexAnalytics.ts` directly calls DexScreener and a BSC AMM factory from the browser. | Treat this as a wallet-side degraded fallback boundary; centralize user-facing market/liquidity data through the server where a replacement exists, and retain only chain reads required for local wallet operation. |
| P0 | Provider coverage | Jupiter is used client-side for Solana token metadata/swap behavior, but there is no confirmed server-side Jupiter token-intelligence adapter or server secret consumption. | Keep Jupiter server adapter status as NOT IMPLEMENTED for token intelligence until an official endpoint and safe adapter are verified and tested. Do not add a guessed key or expose credentials. |
| P0 | Liquidity model | Server DexScreener support currently selects the deepest matching pair; it does not represent a complete cross-DEX aggregate. | Expose pair-level liquidity and DEX identity explicitly; only add a breakdown when actual unique pool rows are normalized and deduplicated. |
| P1 | Fiat currency | `client/src/lib/currency.ts` persists USD/EUR/GBP preference and converts display values using a cached direct Frankfurter browser request. | Verify all major surfaces consume the same hook and that unavailable conversion remains `—`; consider a server cached rate procedure only if it can be added without breaking offline behavior. |
| P1 | Trade identity | `SwapPanel` and `BridgePanel` select assets by symbol within a configured network and record some activity primarily as symbol/amount strings. | Additive asset identity to transaction records and selection keys where real contract/mint data already exists; do not rewrite signing or quote execution in this phase. |
| P1 | Wallet coverage | Send, Swap, Bridge, BTC Swap, and balance modules contain direct chain/provider operations. | Audit each chain boundary separately; preserve EVM/Solana/Bitcoin distinctions, null/error states, and no-real-funds rule. Do not force BTC/SOL through EVM helpers. |
| P1 | Notifications | Shared notification architecture is present, but transaction producers in Send/Swap/Bridge/BTC paths still need a complete audit for structured targets and meaningful event types. | Thread canonical identity only when the actual asset/network/transaction identifier is available; otherwise preserve a non-navigable truthful record rather than guessing. |
| P1 | Refresh lifecycle | Major tabs are mounted independently, but balance and provider refresh behavior can still duplicate calls when navigation or background refresh occurs. | Add request deduplication/stale-while-revalidate guards at the existing seams; preserve cached portfolio, query, and scroll state. |
| P1 | Me security | Me derives useful local state and shows unknown backup status honestly, but there is no complete security-events entry and some summaries are necessarily local/unknown. | Replace only demonstrably static wording with actual local state or honest unavailable labels; do not imply server/device security facts that cannot be determined. |
| P1 | UI language | Technical wording remains in some diagnostic/admin and user-facing market/detail copy. | Audit user-facing strings and replace technical terms only outside legitimate admin/developer diagnostics. |
| P2 | Logo caching | Safe URL validation exists, but successful custom-token/provider logo persistence and retry/cache behavior are not universal across all client surfaces. | Preserve prior successful logo when a temporary provider failure occurs; never proxy arbitrary user URLs or substitute another token’s logo. |
| P2 | Performance | Existing batching and mounted tabs help, but direct browser provider calls and independent detail fetches can duplicate work. | Measure with deterministic request-count tests around Assets, Markets, Token Detail, and Discover before changing behavior. |
| P2 | Test depth | Existing tests cover canonical models, providers, notifications, Discover safety, liquidity no-pair behavior, and build stability; the master phase additionally asks for wallet invalid-address/unsupported-chain/insufficient-funds/RPC-failure/rejection cases and currency/provider stale-cache coverage. | Add focused deterministic tests using mocks; no live credentials, signing, broadcast, or real funds. |

## Stage-specific assessment

Stages 2, 3, 4, 5, 6, 7, 8, 9, 12, 13, 15, and 17 have meaningful implementation coverage from the prior phase, but require the remaining audit and regression tests described above before they can be called complete for the master phase. Stage 10 has a server RPC registry and failover helper, but frontend chain-specific paths still need a complete inventory. Stage 11 is intentionally limited: EVM fee verification is active only for the implemented networks and operations; Solana/Bitcoin settlement remains unavailable rather than implied by configuration. Stage 16 and Stage 26 require targeted verification of Me security language and currency propagation. Stages 28 and 29 cannot be executed in the current local-only task because isolated Railway staging resources, staging OAuth, separate database/Redis, provider credentials, and testnet wallets are not available.

## Prohibited assumptions and release blockers

No provider should be listed as implemented solely because it was previously suggested. No new Railway variable should be documented unless the current code reads it. No private key, seed phrase, production credential, production database, migration, SQL write, signing operation, broadcast, or real-fund test is permitted. Passing local tests cannot be treated as staging or production readiness.

The current evidence-based release posture is **BLOCKED — STAGING RESOURCES UNAVAILABLE** until isolated staging resources exist and controlled staging/chaos tests are actually executed. Local issues must still be resolved and revalidated before staging preparation.

## Next implementation order

1. Audit and safely reduce duplicated market/chart/liquidity calls in the held-asset path using existing server procedures and explicit degraded fallback semantics.
2. Audit Trade/Send/BTC/Solana identity and notification producers without changing signing/broadcast architecture.
3. Verify currency propagation, Me security language, refresh deduplication, and remaining user-facing technical copy.
4. Add regression tests for every changed boundary, then run check, tests, build, audit, credential/private-key/merge-marker scans, and package only after all local results are recorded.
