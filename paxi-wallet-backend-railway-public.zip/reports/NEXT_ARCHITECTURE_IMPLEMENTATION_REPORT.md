# PAXI Wallet Next Architecture Implementation Report

**Review source:** `/home/ubuntu/upload/pasted_content.txt`  
**Project:** `/home/ubuntu/paxi-wallet-fixed/paxi-wallet`  
**Date:** 12 August 2026  
**Author:** **Manus AI**

## Executive summary

The pasted review correctly identified that the merged PAXI architecture was substantially ahead of the earlier archive, but still had a WalletConnect regression and four missing backend domains: referrals, gift codes, a unified reward ledger, and a configurable ten-requirement eligibility and airdrop pipeline. Those gaps have now been addressed in the current project without replacing the existing market, wallet, bridge, activity, fee, database-resilience, or production-hardening work.

The implementation is intentionally backend-first. It does not place reward rules or reward amounts in the client, and it does not directly mutate user balances. Referral rewards, gift-code rewards, campaign rewards, and airdrop rewards are represented as append-only ledger entries and move through explicit lifecycle states.

## What was implemented

| Architecture area | Implementation | Security/reliability property |
|---|---|---|
| WalletConnect | Restored `client/src/lib/wallet/walletconnect.ts`, `client/src/hooks/useWalletConnect.ts`, and the dApp browser connection UI. | Pairing is opt-in; proposals and requests require explicit approval; signer state is cleared on wallet lock; transaction sender, recipient, chain, data, value, and gas payloads are validated. |
| Referral identity | Added `referralProfiles` and `referrals`. | Invite codes are server-generated and hashed/validated through server-owned profiles; self-referral is rejected; one invitee can have only one attribution. |
| Referral rewards | Added admin-controlled referral qualification in `server/rewards/rewardService.ts`. | Qualification is not client-controlled; inviter and optional invitee credits use idempotency keys and the unified ledger. |
| Gift codes | Added `giftCodes` and `giftCodeRedemptions`. | Raw codes are generated server-side and only hashes are persisted; conditional redemption-count updates prevent over-redemption; one user can redeem a code once. |
| Unified reward ledger | Added `rewardLedger` and `server/routers/rewards.ts`. | Referral, gift-code, campaign, manual, and airdrop credits share one immutable-style audit path with idempotency keys and lifecycle status. |
| Configurable ten-task eligibility | Added `campaignRequirements`, `eligibilityResults`, and `server/eligibility/requirementService.ts`. | Exactly ten active requirements are required for evaluation; the engine calculates `0–4 = not_qualified`, `5–9 = minimum`, and `10/10 = highest`. |
| Airdrop foundation | Added `airdropDistributions`, `airdropAllocations`, and `server/airdrop/airdropService.ts`. | Allocation is capped by the distribution total, limited to minimum/highest tiers, staged through review and approval, and finalized only with an administrator-supplied distribution transaction hash. |
| Deployment safety | Added `scripts/applyRewardsSchema.ts`, `db:rewards`, regression assertions, and ledger version `rewards-eligibility-airdrop-v1`. | Railway changes are idempotent and run through `pnpm db:push`; raw Drizzle migration execution remains disabled. |

## WalletConnect restoration and hardening

The uploaded implementation supplied the missing WalletConnect v2 files and dependencies. The final project uses the compatible dependency generation from the uploaded archive: `@walletconnect/core` 2.17.x, `@walletconnect/utils` 2.17.x, and `@walletconnect/web3wallet` 1.15.x. The WalletConnect libraries are dynamically loaded only when pairing is requested, and Vite now isolates them in a `walletconnect-vendors` chunk.

The restored flow never signs automatically. A dApp proposal is surfaced for explicit connection approval, and every signing or transaction request is surfaced for explicit approval or rejection. The manager now rejects unsupported chains, malformed hexadecimal payloads, invalid recipients, mismatched transaction senders, invalid transaction values, and invalid gas limits. `App.tsx` clears the in-memory signer when the wallet is locked, preventing a connected dApp from using stale mnemonic state after lock.

WalletConnect remains a configuration-gated feature. `VITE_WC_PROJECT_ID` is documented as a public client configuration value, but the feature should remain disabled until a real Cloud/Reown project ID is configured and the integration is reviewed in the target production environment.

## Referral and reward-ledger behavior

The referral profile is created lazily for authenticated users. The server generates a stable invite code, stores only its server-owned representation, and uses it to resolve the inviter. The attach operation prevents self-referral and prevents a second inviter from overwriting an existing invitee attribution.

Referral qualification is administrator-controlled. This is deliberate: anti-abuse review and any business qualification policy remain outside the browser. Once qualified, the service credits the inviter and optional invitee through deterministic idempotency keys. A repeated qualification request therefore returns the existing ledger entries rather than creating duplicates.

The unified ledger does not represent a wallet balance. It is an auditable reward entitlement and distribution record. Direct client balance mutation was not added. Actual token transfers remain a separate, controlled distribution step.

## Gift-code behavior

Gift-code creation is admin-only. Codes are generated using cryptographically secure random bytes, normalized, hashed with SHA-256, and returned in raw form only at creation time. The database stores the hash and a short hint, not the redeemable secret.

Redemption runs inside a database transaction. It checks expiry and status, conditionally increments the redemption count, creates a redemption record, creates the corresponding reward-ledger entry, and links the two records. A unique `(giftCodeId, userOpenId)` constraint and an idempotency key prevent duplicate credits under retries or concurrent requests.

## Eligibility and airdrop lifecycle

A campaign receives ten configurable requirements. If a campaign has no requirements, the server provisions ten defaults covering wallet creation, send, receive, swap, bridge, buy, sell, active-day thresholds, and confirmed activity count. Evaluation refuses to proceed if the number of active requirements is not exactly ten.

The result is persisted per snapshot participant in `eligibilityResults` and mirrored into the existing snapshot participant record for compatibility with the prior external eligibility path. The tier rules are explicit:

| Met requirements | Tier | Qualification |
|---:|---|---|
| 0–4 | `not_qualified` | Not eligible |
| 5–9 | `minimum` | Minimum eligible |
| 10/10 | `highest` | Highest eligible |

Airdrop creation, allocation, approval, and finalization are separate admin operations. Allocation uses decimal-safe fixed-scale arithmetic and stops at the configured total amount. It creates reward-ledger entitlements but does not pretend to broadcast token transfers. Finalization requires an administrator-supplied transaction hash and marks the ledger and allocation records as distributed.

## Railway deployment evidence

The new rewards schema was applied to the user-provided Railway database through the idempotent deployment script. The complete pipeline was then run with `pnpm db:push`. The database regression suite passed all required table, column, index, primary-key, foreign-key, partitioning, and deployment-ledger checks.

The consolidated deployment ledger now contains seven milestones, including `rewards-eligibility-airdrop-v1`. The legacy Drizzle ledger remains informational only, and raw `drizzle-kit migrate` remains intentionally disabled.

## Verification evidence

| Verification | Result |
|---|---|
| TypeScript | Passed with `pnpm check`. |
| Unit tests | 9/9 tests passed across 3 test files. |
| Production build | Passed. WalletConnect is isolated into a `walletconnect-vendors` chunk; the existing Bitcoin dynamic-import warning remains documented. |
| Dependency security gate | Passed the project gate: no fixable high/critical production advisory remains. The upstream `bigint-buffer` advisory remains documented through the Solana dependency chain. |
| Railway deployment | `pnpm db:push` completed successfully. |
| Railway regression | All database regression tests passed. |
| Production HTTP smoke | `/healthz=200`, `/readyz=200`, cross-site mutation `403`, unauthenticated reward query `401`, invalid LI.FI proxy path `400`. |
| Secret isolation | The server-only LI.FI test key and runtime WalletConnect test marker were not found in `dist/public`. |

## Remaining production risks

The WalletConnect package family restored from the uploaded archive is deprecated in favor of Reown WalletKit. It is compatible with the current build and has been isolated from the initial bundle, but a production launch should schedule a controlled migration to the maintained package family and perform a new signing review.

The airdrop service currently records and finalizes a verified distribution transaction hash; it does not itself broadcast token transfers. A production payout worker or multisignature treasury workflow should be connected before real funds are distributed.

Referral anti-abuse currently provides safe attribution and administrator-controlled qualification, but it does not yet include device/IP clustering, funding-source analysis, or an external fraud score. Those controls should be added before referral rewards are economically material.

The dependency gate still reports the unfixable upstream `bigint-buffer` advisory in the Solana dependency chain. The build also retains a warning that Bitcoin is both dynamically and statically imported, and the generic vendor chunk remains above the preferred warning threshold. Neither issue failed the current project gate, but both should remain on the performance and dependency maintenance backlog.

Finally, the new routers are backend foundations. Product UI for referral dashboards, gift-code creation/redemption, eligibility review, and airdrop approvals should be added only after the API contracts are exercised in staging and the treasury approval process is finalized.

## Recommended next sequence

The next production-hardening sequence should be to migrate WalletConnect to maintained Reown WalletKit, add integration tests against a disposable MySQL database for concurrent gift-code redemption and idempotent reward crediting, implement an external anti-abuse review interface, connect the airdrop allocation review to a multisignature payout process, and then add the user/admin UI surfaces on top of the verified API contracts.
