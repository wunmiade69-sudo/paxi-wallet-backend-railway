# Paxi Wallet — npm Migration and Chart Completeness Report

**Author:** Manus AI  
**Date:** 13 August 2026  
**Scope:** Latest attached review fixes

## Executive result

The two high-priority issues identified in the latest review have been implemented and validated. Provider candle over-fetching now remains available through the provider/internal merge stage, and the project’s operational commands are now npm-compatible rather than invoking pnpm internally.

The final npm installation completed successfully and generated `package-lock.json`. The prior pnpm lockfile and workspace override file were removed. The elliptic security override was preserved using npm’s native `overrides` field, and the obsolete Vite JSX-location plugin was removed because its peer dependency range blocked a strict npm installation. `vite-plugin-node-polyfills` was upgraded to a Vite 7-compatible release.

## Implemented changes

| Area | Change | Result |
|---|---|---|
| Chart provider margin | Added `getProviderCandleLimit()` and retain `Math.ceil(limit × 1.25)` candles after normalization/deduplication inside provider loading. | Extra provider history now survives until `mergeChartCandles()` applies the final requested limit. |
| Chart regression coverage | Added a test for `365 → 457` and `1 → 2` provider limits. | The provider-margin contract is now directly regression-tested. |
| Database commands | Replaced internal `pnpm db:*` chaining with `npm run db:*`. | `npm run db:push` is the canonical deployment command. |
| Dependency audit | Changed the audit helper from `pnpm audit` parsing to npm’s `vulnerabilities` JSON format. | npm audit now reports advisories accurately and exits successfully when only documented unfixable upstream high-severity paths remain. |
| Package manager | Removed `pnpm-lock.yaml`, `pnpm-workspace.yaml`, the pnpm dev dependency, and the `packageManager` field. Added npm `overrides` for `elliptic`. | npm is the package manager represented by the repository metadata. |
| Vite compatibility | Removed `@builder.io/vite-plugin-jsx-loc`, whose peer range excluded Vite 7; upgraded `vite-plugin-node-polyfills` to `^0.28.0`. | Strict npm dependency resolution succeeds without `--legacy-peer-deps`. |
| Documentation | Updated the migration runbook, main README, testing guide, feedback document, and asset-registry comments to use npm commands. | Operational instructions match the repository’s package manager. |

## Validation evidence

| Gate | Result | Evidence |
|---|---|---|
| npm installation | **PASS** | `npm install --no-audit --no-fund` completed and generated `package-lock.json`. |
| TypeScript | **PASS** | `npm run check` completed without diagnostics. [`npm-final-gates.log`](npm-final-gates.log) |
| Unit tests | **PASS: 22 tests in 7 files** | Existing suite plus the provider-margin regression. [`npm-final-gates.log`](npm-final-gates.log) |
| Production build | **PASS** | Vite client and esbuild server bundle completed. Existing circular-chunk, Bitcoin static/dynamic import, and Rollup annotation warnings remain non-fatal. [`npm-final-gates.log`](npm-final-gates.log) |
| Dependency audit | **PASS with documented upstream exception** | 21 total npm advisories were reported; 3 high-severity Solana-chain findings were classified as unfixable major-version remediation paths. No fixable high/critical production advisory remains. [`npm-security-audit-fixed.log`](npm-security-audit-fixed.log) |
| Railway deployment | **PASS** | `npm run db:push` completed the idempotent deployment and live regression suite. Eight consolidated deployment milestones and one informational legacy Drizzle entry were confirmed. [`npm-db-push.log`](npm-db-push.log) |
| Production HTTP smoke | **PASS** | Health 200, readiness 200, chains 200, assets 200, cross-site mutation 403, unauthenticated rewards query 401, invalid LI.FI path 400. [`npm-http-smoke.log`](npm-http-smoke.log) |

## Package-manager operating rules

Use the following commands for local and production operations:

```bash
npm install
npm run check
npm test
npm run build
npm run security:deps
npm run db:push
```

Raw Drizzle migration execution remains intentionally disabled. Use the idempotent `npm run db:push` pipeline for Railway and production schema changes. New schema changes must be added as idempotent scripts and included in `npm run db:deploy`, followed by an update to the live regression assertions and deployment ledger.

## Remaining observations

The npm audit still reports upstream Solana dependency findings, including `bigint-buffer`, because npm’s suggested remediation requires a major and incompatible package change to the Solana token dependency chain. The project gate passes because no safe, non-breaking fix is available in the current supported dependency line. This remains a documented dependency risk and should be revisited when the Solana packages provide a compatible patched release.

The production build still emits non-fatal warnings related to manual chunk circularity, a static/dynamic Bitcoin import overlap, and a Rollup pure-comment annotation. These warnings did not prevent the build and are separate optimization follow-ups rather than release-blocking errors.

Native BTC, SOL, and BNB chart history continues to use CoinGecko as the final fallback when no DEX pair is available. This was explicitly classified by the review as a later provider-expansion item, not part of the two high-priority fixes completed here.

## References

1. [Latest attached review](../../upload/pasted_content.txt) — source requirements and identified defects.
2. [Final npm validation log](npm-final-gates.log) — typecheck, tests, build, and dependency gate.
3. [npm Railway deployment log](npm-db-push.log) — idempotent schema deployment and live database regression.
4. [npm HTTP smoke log](npm-http-smoke.log) — production safeguard checks.
5. [npm dependency audit log](npm-security-audit-fixed.log) — parsed npm advisory results and exception handling.
