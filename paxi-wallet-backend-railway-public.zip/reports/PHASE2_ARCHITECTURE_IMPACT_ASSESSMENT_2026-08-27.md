# PAXI Wallet — Phase 2 Architecture Impact Assessment

## Scope and governing requirements

The newly authorized work is the multi-chain data and provider architecture described in `pasted_content.txt`. The implementation must be staged rather than performed as a blind rewrite. The immediate architectural goal is to establish a reusable chain registry, provider capability contracts, canonical identity service, provider registry/orchestrator seams, centralized cache metadata, and resilient request boundaries while preserving the completed Phase 1 user-facing behavior.

The frontend must continue to consume normalized server data through tRPC. Existing non-custodial wallet operations, signing, transaction construction, and broadcast remain outside this market-data architecture and must not be moved to a server or exposed to providers.

## Current repository findings

| Area | Existing implementation | Impact |
|---|---|---|
| Chain definitions | `server/chains/registry.ts` contains static adapters for Ethereum, BNB Chain, Polygon, Arbitrum, Solana, and Bitcoin. Adapters expose family, native symbol, RPC URL, identifier normalization, balance, and explorer behavior. | Extend the existing registry with explicit chain type, native asset, address format, capabilities, provider profile, and primary/secondary/emergency RPC configuration. Preserve adapter lookup compatibility. |
| Canonical identity | Client-side `marketIdentity.ts`, wallet `chains.ts`, and server `assetRegistry.ts` each contain related normalization rules. `server/marketProviders.ts` also has provider-specific chain/address normalization. | Add one server-side identity module and make provider orchestration use it. Keep existing client helpers for UI-local identity, but align their serialized keys and avoid symbol/name/CoinGecko-only identity. |
| Provider contracts | `server/providers/types.ts` already defines `MarketProvider`, `ProviderMarket`, and `ProviderOhlcv`. | Evolve this into capability-specific interfaces and explicit provider definitions rather than creating a second incompatible provider stack. |
| Provider registry | `server/providers/index.ts` currently registers market adapters for DexPaprika, DexScreener, GeckoTerminal, and CoinGecko. | Extend the registry to include capabilities, supported chains, priority, configuration status, and health metadata. Preserve `marketProviders` and `getMarketProvider` as compatibility exports during migration. |
| Legacy market layer | `server/marketProviders.ts` directly implements Birdeye and DexPaprika search/detail/chart normalization and fallback logic. | This is the largest duplication. Wrap or move its normalized functions behind capability adapters first, then remove direct call paths only after parity tests pass. |
| Market service | `server/marketData.ts` handles CoinGecko list/search/detail/chart, Birdeye/DexPaprika search/detail/chart, Redis caching, DB caching, ranking, and response shaping. | Keep its public return contracts for Phase 1 compatibility, but route provider selection through the orchestrator in later migration steps. Do not change truthfulness or null/unavailable semantics. |
| Chart service | `server/chartService.ts` already uses `server/providers/*`, internal DB candles, Redis, and fallback ordering. | Reuse this as the preferred normalized chart seam. Avoid creating a third chart architecture; add common chart contracts and orchestration around it. |
| Resilient transport | `server/providers/http.ts` provides timeout, bounded response reads, Redis cooldown/circuit behavior, and structured provider request execution. | Make this the mandatory transport for external market/provider requests. Audit remaining direct provider `fetch()` calls, especially Bitcoin RPC and legacy market paths, and migrate only where a safe equivalent exists. |
| RPC | `server/chains/rpc.ts` already supports provider URL lists and fallback execution, but environment configuration is limited and some adapter paths still use direct fetch inside a fallback callback. | Extend configuration-driven primary/secondary/emergency endpoints and expose a common RPC operation contract. Do not alter client wallet RPC/signing architecture in this phase. |
| Liquidity | `server/dexLiquidity.ts` contains DexScreener-specific fetching, token-price correction, persistence, Redis updates, and legacy market snapshot functions. | Separate pair-level liquidity normalization from market snapshots and expose it through a liquidity capability. Preserve `Pair liquidity`/`Observed DEX Liquidity` semantics and never use zero as unavailable. |
| Security | Existing GoPlus/server security paths are separate from market normalization. | Introduce a security-provider interface and normalized security snapshot without claiming verification when data is absent. Defer additional providers unless a documented capability gap is demonstrated. |
| Search consumers | Assets and Markets already use server tRPC search and Phase 1 debouncing/dedupe. | Migrate both to a common server search service/orchestrator while preserving the current normalized result shape and canonical identity behavior. |
| Frontend boundary | Phase 1 screens use tRPC and shared `AssetLogo`; no provider URLs should be introduced in client components. | Preserve the boundary. The migration must not add provider-specific fetches, keys, or response objects to frontend components. |

## Recommended target shape

The repository should converge on the existing `server/providers/*` stack rather than add another registry. The proposed structure is:

```text
server/
  identity/
    assetIdentity.ts          # chain-aware server identity resolver
  chains/
    registry.ts               # ChainDefinition + existing adapter compatibility
    profiles.ts               # provider capability profiles
    rpc.ts                    # existing fallback transport, extended safely
  providers/
    types.ts                  # normalized models and capability interfaces
    definitions.ts            # ProviderDefinition metadata
    index.ts                  # registry and compatibility exports
    orchestrator.ts           # capability-aware provider selection/fallback
    http.ts                   # shared resilient HTTP boundary
    adapters/                 # only when an existing provider needs a new contract
  cache/
    keys.ts                   # centralized identity-aware cache keys
    metadata.ts               # created/expires/source/sourceTimestamp envelope
  marketData.ts               # compatibility API backed by orchestration
  chartService.ts             # normalized OHLCV service
  dexLiquidity.ts             # normalized pair/liquidity service
```

The first implementation should be deliberately additive. Existing provider adapters remain available until contract parity tests prove the orchestrated path equivalent. The orchestrator should select a small, chain-appropriate provider set from profiles instead of invoking every provider. Independent capability requests may run in parallel, while missing optional fields produce `null` or an explicit unavailable state.

## Migration decisions

The implementation will use the following decisions.

First, identity becomes a server-side shared primitive. EVM identities are normalized to lowercase chain plus contract; Solana mint casing is preserved; Bitcoin and native assets use `chain:native`. A CoinGecko ID may enrich an identity but cannot be its sole identity when a chain/contract or mint is known.

Second, provider definitions will be data-driven. Each provider will declare its id, capabilities, supported chains, priority, enabled/configured state, timeout, cache policy, and health metadata. Secrets remain server-only and are read from the existing environment layer; no new environment variables will be invented for adapters that are not implemented.

Third, the existing resilient HTTP transport will remain the only common external HTTP boundary. It already handles timeout, bounded response size, cooldown/circuit behavior, and provider labeling. Any direct provider request found outside that boundary will be treated as a migration candidate, not duplicated.

Fourth, normalized responses will carry provenance and cache metadata. Provider failures will be isolated per capability, and stale cache will be returned only with an explicit stale marker and original source metadata. A provider A value must not be labeled as provider B data.

Fifth, DEX market data and DEX execution remain separate. Existing swap/bridge providers and transaction signing paths will not be registered as market-data providers merely because they can quote or route transactions.

## Explicit non-goals for this implementation pass

This architecture pass will not add unimplemented provider credentials, CEX trading or withdrawal support, NFT data forced into fungible-token models, new live providers without a documented gap, database migrations, production SQL, deployment, secret exposure, or wallet key/signing changes. It will not redesign the Phase 1 UI. Additional DEX, CEX, security, NFT, and RPC adapters will be introduced only where the current repository already contains a compatible implementation or where a focused contract seam is required for later activation.

## Acceptance risks and controls

| Risk | Control |
|---|---|
| A second parallel provider stack is created | Extend `server/providers/*`; retain compatibility exports until parity is established. |
| UI behavior regresses while server contracts move | Keep `MarketToken`, `TokenDetail`, search, and chart response shapes stable initially; add source-level and provider contract tests. |
| Provider failures become page-wide errors | Orchestrator returns partial capability results and explicit unavailable values. |
| Cache provenance is lost | Use identity-aware centralized keys and an envelope containing creation, expiry, source, and source timestamp. |
| Secrets leak through logs or client bundles | Read environment values only server-side; provider definitions expose configured booleans, never credentials. |
| Chain-specific identity collisions return | Reuse one server identity resolver and test EVM casing, Solana mint casing, Bitcoin native, and same-symbol different-chain cases. |
| Too many providers are called per page | Chain profiles select only relevant capabilities and bounded fallback candidates; cache is checked first. |

## Implementation order

The next code phase will implement Phase A foundations first: the canonical server identity service, richer chain definitions/profiles, capability interfaces, provider definitions/registry, centralized cache-key/envelope helpers, and an orchestrator that can safely wrap existing market providers. Phase B migration will then route existing CoinGecko, DexPaprika, DexScreener, and Birdeye paths through those seams with parity tests. RPC, DEX, CEX, security, and NFT expansions remain subsequent bounded work and will not be silently fabricated as complete by registry entries alone.
