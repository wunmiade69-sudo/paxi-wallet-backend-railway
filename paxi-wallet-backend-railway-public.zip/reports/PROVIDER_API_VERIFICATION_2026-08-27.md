

## Quote-provider verification (Stage 3, 2026-08-27)

- Velora’s official Market API documentation: https://docs.velora.xyz/docs/market/overview. The documentation describes the classic flow as requesting a quote, building a transaction, then having the user sign and submit it on-chain. The transaction reference is https://docs.velora.xyz/docs/api-reference/market/transactions.
- Jupiter’s official developer documentation: https://dev.jup.ag/docs/swap and https://dev.jup.ag/docs/get-started. The current platform exposes raw transaction-control flows as well as managed execution; this audit retains client-controlled signing/broadcast and treats provider quote/build calls as server-boundary candidates only.
- THORChain official developer documentation: https://dev.thorchain.org/swap-guide/quickstart-guide.html and https://dev.thorchain.org/. The quote endpoint simulates swap logic; THORNode is the swap/quote API family and Midgard is the analytics/history family. Existing client BTC signing and broadcast must remain non-custodial; quote/status calls are the provider-boundary candidates.

These sources validate the architectural split, not live provider availability or terms for this repository. No live quote, signing, broadcast, or real-fund operation was performed.
