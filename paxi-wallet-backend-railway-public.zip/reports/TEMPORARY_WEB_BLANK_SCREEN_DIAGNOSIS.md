# Temporary Web Blank-Screen Diagnosis

The temporary server on port 4176 is listening and the public proxy responds successfully: `/healthz` returns HTTP 200 and `/` returns the production HTML. In the browser, the document title is `PAXI Wallet Beta v0.1`, the production JavaScript assets load, but `#root` remains empty and the viewport is blank.

The strongest code-level cause is unguarded browser-storage access during top-level render paths. `useAuth()` executes before `App` creates its `ErrorBoundary` and may write to `localStorage` during render. `I18nProvider` and `ThemeProvider` also read or write browser storage synchronously. A restricted or proxied browser context can throw a `SecurityError`, leaving the root unmounted without an in-app fallback. The next fix should centralize safe storage helpers and remove render-time storage writes, then rebuild and re-verify the public page.


After the safe-storage changes, a fresh build (`index-BF8CWCTF.js`) was served on port 4177. The public health endpoint and HTML both return HTTP 200, and the browser reports the new module script loaded, but `#root` is still empty with no captured `window` errors. This indicates a module/bootstrap failure or a pre-render issue that is not surfaced through the browser console; further diagnosis should inspect the generated module entry and runtime execution path, including imports and the main entrypoint.


The visible bootstrap fallback works: after rebuild, the public page now shows `PAXI — Wallet could not start` with a reload button. Therefore a client startup exception is definitely occurring before React mounts. The current fallback logs the message to the console, but the browser console view did not expose it; the next diagnostic change should persist the startup message on `window` and display it only when a `debug=1` query parameter is present.


The exact failure was `TypeError: Object.defineProperties called on non-object` in the split `bitcoin-vendors` chunk. The stack entered a CommonJS base64 helper factory in the general vendor chunk with an undefined export target, caused by the circular manual chunk mapping. Removing the manual chunk function from `vite.config.ts` produces a single larger client bundle and eliminates the runtime initialization failure. The rebuilt public page now renders the PAXI splash screen successfully.


The cleaned final temporary build removes the diagnostic monkey patch and temporary inspection scripts. TypeScript compilation and production build pass. The public URL now renders the PAXI splash screen, and the earlier onboarding click successfully opened the Create Wallet recovery-phrase screen. The no-manual-chunk build emits a larger main bundle and a warning above the 600 kB threshold; this is recorded as a follow-up performance item, while functionality is restored.
