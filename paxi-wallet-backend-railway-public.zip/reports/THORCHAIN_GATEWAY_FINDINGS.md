# THORChain Gateway Findings

The official THORChain developer quickstart documents the public quote path through the Liquify gateway:

- https://dev.thorchain.org/swap-guide/quickstart-guide.html
- https://gateway.liquify.com/chain/thorchain_api/thorchain/quote/swap

The same guide states that BTC quotes use `BTC.BTC`, amounts are in 1e8 units, quotes expire, and only available pools should be used. It also documents that Bitcoin transactions must send to the returned inbound address with the returned memo, and that the quote should be refreshed before broadcast.

The official Midgard route is documented through the Liquify gateway:

- https://gateway.liquify.com/chain/thorchain_midgard/v2/actions
- https://gateway.liquify.com/chain/thorchain_midgard/v2/doc

The previous Nine Realms hosts returned an upstream DNS/fetch failure from the temporary server. After switching the wallet to the Liquify endpoints and adding `gateway.liquify.com` to the strict HTTPS proxy allowlist, the temporary proxy successfully reached THORChain. The live read-only BTC.BTC -> BSC.BNB quote check then returned HTTP 500 with the upstream response: `failed to simulate swap: failed to simulate handler: trading is halted, can't process swap`.

This confirms that the remaining failure is an upstream THORChain trading halt, not a missing wallet address or a proxy routing error. The wallet must block or clearly label new Thorchain swaps while this upstream halt is active; existing BTC/Solana address availability is handled separately by seed-wallet derivation and explicit EVM-only/watch-only messaging.
