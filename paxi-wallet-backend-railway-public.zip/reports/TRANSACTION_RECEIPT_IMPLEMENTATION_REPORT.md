# Paxi Wallet — Live Transaction Receipt Implementation Report

**Author:** Manus AI  
**Date:** 13 August 2026  
**Scope:** EVM transaction status polling, receipt preview, and image sharing

## Executive result

The transaction receipt flow has been upgraded so a broadcast transaction still appears **Pending immediately**, but the receipt now polls the EVM network and automatically transitions to **Confirmed** or **Failed** when the RPC returns a receipt. The existing transaction-history resolver remains in place as the authoritative recovery layer for reopened screens, app restarts, and older pending transactions.

The receipt now generates and displays the branded PNG card inside the app. Native image sharing is attempted only when the browser explicitly supports file sharing. If the browser or Android WebView cannot share image files, the generated PNG is saved locally instead of silently degrading to a text-only share. Text sharing or clipboard copy is reserved for the final fallback when image generation itself is unavailable.

The final polish pass now describes the bounded timeout accurately: after five minutes, the UI says, “Still pending. We'll continue checking when you reopen your transaction history.” The portrait preview uses the receipt’s native `720/1180` aspect ratio rather than forcing a fixed height. The Bitcoin path was also audited: this repository contains a real UTXO-based sender in `bitcoin.ts`, so Bitcoin remains available in the send capability set; only the stale comment claiming it was unimplemented was corrected.

## Implemented changes

| Area | Implementation | Result |
|---|---|---|
| Live confirmation | Exposed the existing `resolvePendingStatus()` helper and added `useTransactionStatus()`. | Pending EVM receipts poll immediately, then at bounded 2s, 4s, 6s, 10s, 15s, and 30s intervals. |
| Polling safety | Added a five-minute maximum live polling window and cleanup on component unmount. | No indefinite RPC polling or timer leak. |
| Status semantics | Retained internal statuses `pending`, `confirmed`, and `failed`. | UI can display “Successful” while persistence remains semantically correct. |
| EVM-only resolver | Added a chain-type guard before constructing an EVM `JsonRpcProvider`. | Solana and Bitcoin records do not enter the EVM receipt path. |
| History recovery | Kept `getFullHistory()` and `resolvePendingStatus()` persistence behavior intact. | Live receipt polling complements, rather than replaces, history reconciliation. |
| Receipt preview | Generates a branded Canvas PNG whenever the receipt mounts or its status changes. | Users see the actual visual receipt card inside the app. |
| Native image sharing | Uses `navigator.canShare({ files })` only when both file sharing APIs are available. | Supported Android/browser environments receive the PNG through the native share sheet. |
| Unsupported image sharing | Saves the generated PNG locally when file sharing is unavailable. | Android WebViews no longer receive only a text receipt by default. |
| Last-resort fallback | Uses text share or clipboard copy only when image generation is unavailable. | Text is no longer the first fallback for a generated image receipt. |

## User flow after the fix

```text
User taps Send
        ↓
Transaction is signed and broadcast
        ↓
Local record is saved as pending
        ↓
Receipt opens immediately with a pending PNG preview
        ↓
Bounded RPC polling checks the transaction receipt
        ↓
status = 1  → confirmed → UI displays Successful
status = 0  → failed    → UI displays Failed
no receipt  → pending   → polling continues
five minutes → pending with history-recovery message
        ↓
updateTxRecord() persists confirmed/failed status and fee
```

Solana sends continue using `sendAndConfirmTransaction()`, so they return after confirmation and are still protected by the same UI abstraction. The shared resolver explicitly avoids treating Solana or Bitcoin records as EVM JSON-RPC receipts.

## Validation evidence

| Gate | Result | Evidence |
|---|---|---|
| TypeScript | **PASS** | `npm run check` completed without diagnostics. |
| Unit tests | **PASS: 22 tests across 7 files** | Existing wallet, security, chart, rewards, activity, and transaction-related regression suite passed. |
| Production build | **PASS** | Vite client and esbuild server bundle completed successfully. Existing circular-chunk, Bitcoin import, and Rollup annotation warnings remain non-fatal. |
| Existing history recovery | **Preserved** | `getFullHistory()` continues to resolve local pending records and persist status/fee updates. |
| Live receipt behavior | **Implemented** | `TransactionReceipt` now consumes `useTransactionStatus()` and renders the resolved local record. |
| Image fallback behavior | **Implemented** | Unsupported native image sharing saves the PNG; text is used only if Canvas generation fails. |

## Files changed

- `client/src/hooks/useTransactionStatus.ts` — bounded reusable live status polling hook.
- `client/src/lib/wallet/txIndexer.ts` — exported the existing resolver and added an EVM chain-type guard.
- `client/src/components/TransactionReceipt.tsx` — reactive status, preview image, image-first sharing, and save fallback.
- `client/src/lib/wallet/bitcoin.ts` — verified UTXO-based Bitcoin sender retained as a separate supported path.
- `reports/TRANSACTION_RECEIPT_IMPLEMENTATION_REPORT.md` — this report.

## Remaining non-blocking observations

The production build continues to emit existing non-fatal warnings for manual chunk circularity, a static/dynamic Bitcoin import overlap, and a Rollup pure-comment annotation. These warnings do not prevent the production bundle from being generated.

A live on-chain confirmation test requires broadcasting a real transaction and was not performed automatically because doing so would spend user funds. The implementation uses the existing production RPC and receipt-resolution path, and the typecheck, unit suite, and production build all pass after the change.

## References

1. [Latest attached transaction-flow review](../../upload/pasted_content.txt) — source requirements and identified defects.
2. `client/src/lib/wallet/txIndexer.ts` — existing history reconciliation and receipt-resolution implementation.
3. `client/src/lib/wallet/txHistory.ts` — local transaction record and persistence model.
4. `client/src/components/TransactionReceipt.tsx` — receipt rendering, PNG generation, preview, and sharing behavior.
5. `client/src/hooks/useTransactionStatus.ts` — bounded live polling implementation.
