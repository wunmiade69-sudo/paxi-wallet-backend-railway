# PAXI Wallet — Unified Token Intelligence, Liquidity, Charts, Logos & Notification UX

**Validation date:** 27 August 2026  
**Scope:** Local source and test workspace only. No deployment, production database operation, migration, SQL execution, credentials, signing, broadcasting, or real-funds operation was performed.

## Executive result

This phase adds a coherent, additive canonical-token presentation contract around the existing market and wallet architecture. Runtime identity remains **chain plus contract/mint**, with native assets distinct from token identifiers. Search results, custom-token persistence, held-asset presentation, token detail, market detail, charts, liquidity fallbacks, Discover surfaces, and notifications retain truthful availability and source context without replacing the existing wallet, listing, chart, Redis, campaign, eligibility, signing, or broadcast architecture.

A follow-up implementation slice also adds one shared, origin-aware notification bell to the Assets, Markets, and Discover headers. The existing Me-screen notification entry remains intact. Discover categories are now derived from categories with actual curated entries, and dApp logos are accepted only when explicitly supplied as safe HTTP(S) URLs. Missing logos continue to use an entry-specific initials fallback.

The implementation is **locally validated but not a production release sign-off**. Provider behavior, Railway configuration, and live Upstash or external API connectivity were not tested from an approved staging environment.

## Implemented pipeline

| Surface | Current canonical boundary | Truthfulness behavior |
|---|---|---|
| Assets/Home search | Existing local/PAXI/provider search plus `searchResultToCanonicalToken` | Dedupe uses chain and contract/mint identity; missing market fields remain null/unavailable; provider listings are not labeled as PAXI verification. |
| Markets | Existing server `MarketToken` market list/search/detail path | Field-level provenance is retained for actual CoinGecko, Birdeye, and DexPaprika values; provider source and PAXI trust remain separate. |
| Add Token/custom tokens | Existing lookup-then-persist path | EVM metadata is sourced from the contract; known Solana metadata is sourced from the existing public Jupiter token endpoint when available; fallback decimals are sourced only from the mint; unsafe logos are discarded. |
| Held assets | Existing streaming balance engine and `PortfolioAsset` adapter | Price provenance distinguishes canonical server, Binance, CoinGecko, DexScreener, and on-chain-pool fallbacks. Missing 24-hour change remains null rather than zero. |
| Token Detail / Asset Detail | Existing tRPC detail/stats/chart queries and existing detail layouts | Hardcoded stablecoin price assumptions were removed; unknown change/supply/liquidity states render as unavailable; DEX figures are labeled as pair-level where applicable. |
| Charts | Existing server chart fallbacks and `ProfessionalMarketChart` | No synthetic live candles or fabricated historical lines were added. Existing genuine-point and unavailable behavior is preserved. |
| Liquidity | Existing DexScreener path | The canonical snapshot returns null when no real pair exists. The legacy compatibility helper may still return numeric zero internally, but it is not used as a user-facing canonical liquidity value. |
| Discover | Existing curated catalog and local favorites/recents | Network filtering and search remain local and truthful; empty categories are not presented as available; dApp logos come only from explicit safe HTTP(S) catalog data or the initials fallback. |
| Notifications | Existing local notification store and app state machine | Records accept additive structured targets, `readAt`, and dedupe keys. Price alerts carry canonical identity when available and remain backward-compatible with legacy records. A shared bell derives unread count from persisted notifications and preserves the originating tab on Back. |

## Provider field matrix

| Provider/source | Implemented role | Fields that may be attributed | Key and client exposure |
|---|---|---|---|
| CoinGecko | Existing market list/detail/chart fallback | Name, symbol, image, price, 24-hour change, market cap, volume, supply and links where returned | Optional `COINGECKO_API_KEY`, server-only. |
| Birdeye | Existing provider search/detail/chart fallback | Actual normalized Solana market fields returned by the provider | Optional `BIRDEYE_API_KEY`, server-only; 429 is handled as unavailable/fallback. |
| DexPaprika | Existing provider search/detail/chart fallback | Actual normalized market fields returned by the provider | Optional `DEXPAPRIKA_API_KEY`, server-only. |
| DexScreener | Existing pair-level price/liquidity and DEX fallback | Real pair price, pair liquidity, pair volume, pair change and pair URL | Keyless public endpoint; no secret is placed in client code. |
| Binance | Existing client fallback for configured exchange symbols and server native-price fallback | Actual exchange price and 24-hour change | Public market endpoint; not a universal token resolver. |
| GoPlus | Existing EVM security lookup | Actual security checks when returned; unavailable/unknown otherwise | Existing keyless server path; absence of data is not treated as safe. |
| Jupiter | Existing client-side Solana metadata lookup only | Known token metadata when the public lookup returns it | No server Jupiter adapter or `JUPITER_API_KEY` implementation was added. It is not claimed as a unified server provider. |
| Uniswap / PancakeSwap | Not implemented as independent API adapters | None | No `UNISWAP_API_KEY` or `PANCAKESWAP_API_KEY` is consumed or requested. DexScreener `dexId` is not represented as an independently queried adapter. |
| CEX adapters beyond existing Binance fallback | Not implemented | None | No support claim is made. |

## Notification model

`NotificationRecord` remains backward-compatible and optionally carries `readAt`, `dedupeKey`, and a `NotificationTarget`. A target contains an entity type, optional chain, optional contract/mint, optional provider coin ID, and an explicit navigation type. The app only opens Token Detail when the target contains a provider coin ID or a chain plus contract/mint identity. Symbols are not used to reconstruct targets. Existing local-storage records without the new fields remain valid.

Price alerts retain their existing threshold, cooldown, and deduplication controls. New alerts use a canonical identity key when a market token has one; otherwise an existing provider coin ID is used. No background notification worker or server-side alert scheduler was added.

The reusable bell in `client/src/components/NotificationBell.tsx` reads unread state from the existing notification store and does not infer notifications from provider state. App navigation stores the originating `dashboard`, `markets`, `discover`, or `me` screen and returns there when the notification screen is closed.

## Environment variables actually consumed by source

| Variable family | Status |
|---|---|
| `COINGECKO_API_KEY`, `BIRDEYE_API_KEY`, `DEXPAPRIKA_API_KEY` | Read server-side by existing provider paths. |
| `LIFI_API_KEY` | Read by existing LI.FI server integration. |
| `BSC_RPC_URL` | Read by the existing shared RPC configuration. |
| `REDIS_URL`, `REDIS_REQUIRED`, `REDIS_TLS_REQUIRED` and existing database/auth/storage variables | Existing platform/runtime configuration; unchanged by this phase. |
| `JUPITER_API_KEY`, `UNISWAP_API_KEY`, `PANCAKESWAP_API_KEY`, `MORALIS_API_KEY`, `ALCHEMY_API_KEY`, `INFURA_API_KEY`, `GOPLUS_API_KEY`, `LLAMA_API_KEY`, `DEEPSEEK_API_KEY` | Not consumed by this source and not added to deployment instructions. |

No private provider key is exposed through client code or `VITE_` variables.

## Files changed in this phase

| Area | Files |
|---|---|
| Canonical models and search | `client/src/lib/phase3Models.ts`, `client/src/lib/assetSearch.ts`, `client/src/components/AssetSearchDrawer.tsx` |
| Custom-token metadata and persistence | `client/src/lib/wallet/chains.ts`, `client/src/lib/wallet/customTokens.ts`, `client/src/pages/AddTokenScreen.tsx` |
| Held balances and presentation | `client/src/lib/wallet/balances.ts`, `client/src/pages/Dashboard.tsx`, `client/src/pages/AssetDetailScreen.tsx`, `client/src/pages/MarketsScreen.tsx`, `client/src/pages/TokenDetailScreen.tsx` |
| Notifications and app navigation | `client/src/lib/phase3Local.ts`, `client/src/pages/NotificationsScreen.tsx`, `client/src/components/NotificationBell.tsx`, `client/src/App.tsx` |
| Discover trust, filters, and logos | `client/src/lib/wallet/discover.ts`, `client/src/pages/DiscoverScreen.tsx` |
| Server market, provider, price, and liquidity paths | `server/marketData.ts`, `server/marketProviders.ts`, `server/dexLiquidity.ts`, `server/priceEngine.ts` |
| Tests | `client/src/lib/assetSearch.test.ts`, `client/src/lib/wallet/customTokens.test.ts`, `client/src/lib/wallet/discover.test.ts`, `client/src/phase7Stability.test.ts`, `client/src/pages/AssetDetailScreen.test.ts`, `server/marketProviders.test.ts`, `server/phase3Local.test.ts`, `server/phase3Models.test.ts`, `server/dexLiquidity.test.ts` |

## Validation

| Command | Result |
|---|---|
| `npm run check` | **Passed** — TypeScript emitted no errors after the final Discover/logo and notification changes. |
| `npm test -- --run` | **Passed** — 69 test files, 259 tests. |
| `npm run build` | **Passed** — Vite client and esbuild server bundle completed. Existing non-fatal warnings remain for a large wallet chunk, dynamic/static Solana and Bitcoin imports, and a third-party pure-comment annotation. |
| `npm run lint` | **Not available** — package.json has no `lint` script; npm reported `Missing script: "lint"`. |
| `npm audit --omit=dev` | **Non-zero with inherited advisories** — 16 vulnerabilities: 7 low and 9 moderate; no high or critical findings were reported. Some suggested fixes require breaking changes; no forced audit fix was run. |
| Secret/hygiene scan | No credential literal or private-key material was added. Matches for words such as `mnemonic`, `privateKey`, and `seedPhrase` are existing wallet implementation identifiers and tests, not exposed secrets. Existing SQL/migration/seed files remain part of the source tree and were not modified or executed. |

## Explicit limitations and release blockers

The primary server market detail flow is still the existing `marketData.ts` orchestration. The separate `server/providers/aggregator.ts` median/confidence path is not silently represented as the primary detail resolver. This avoids claiming a runtime integration that was not completed.

Jupiter is not a server-side token-intelligence adapter. Uniswap and PancakeSwap are not independent API adapters. CEX coverage remains limited to existing Binance symbol fallback behavior. A provider listing or discovery result is not PAXI verification, and unavailable security data is not safe status.

Discover remains a curated dApp directory. It does not claim in-app dApp pairing or independently verify a listed dApp. Missing catalog logos intentionally render as initials rather than guessed favicons or arbitrary proxy images.

No approved isolated staging environment was available for live provider, Redis, Railway, OAuth, or external network verification. Therefore this phase must be treated as **local-validation complete / staging-required before production**. Production deployment, migrations, database writes, provider key configuration, and real wallet operations remain outside this phase.

## Packaging status

The deployment archive retains the existing two-file workflow: root `Dockerfile` plus `paxi-wallet-backend-railway-public.zip`. The regenerated ZIP contains exactly one top-level `paxi-wallet/` directory and excludes `node_modules`, `dist`, local caches, VCS metadata, and environment files. The Dockerfile remains the existing archive extractor and build launcher; it was not redesigned.

## References

[1]: https://docs.npmjs.com/cli/v10/commands/npm-audit "npm audit command documentation"
[2]: https://vite.dev/guide/build "Vite production build documentation"
[3]: https://vitest.dev/guide/ "Vitest guide"
