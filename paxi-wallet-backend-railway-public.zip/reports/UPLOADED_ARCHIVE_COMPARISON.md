# Uploaded Paxi Wallet Archive Comparison

**Compared file:** `paxi-wallet-updated.zip`  
**Target updated:** `/home/ubuntu/paxi-wallet-fixed/paxi-wallet`  
**Review date:** 12 August 2026

## Result

The uploaded archive contains a complete client-side bridge implementation using LI.FI, local transaction history, transaction indexing, wallet send/swap/bridge screens, and a server-side LI.FI proxy. The reviewed source already contained the uploaded transaction-history and wallet UI files, together with additional server-authoritative activity and transaction-verification services. The missing useful addition was the server-side LI.FI proxy path, which has now been merged and hardened.

## Comparison summary

| Area | Uploaded archive | Reviewed source before merge | Final action |
|---|---|---|---|
| LI.FI bridge execution | EVM and Solana signing, ERC-20 approval, route parsing, local pending transaction record | Same bridge execution plus backend-sourced `feeBps` validation and fee display | Preserved the reviewed fee authority and merged the uploaded proxy transport. |
| LI.FI API access | Client called `/api/lifi-proxy`; optional `LIFI_API_KEY` was attached server-side | Client called `https://li.quest/v1` directly | Added a server-only proxy and changed bridge quotes to use it. |
| Proxy security | Allowed `/quote` and `/status`, 15-second timeout, but no distributed limiter or upstream response-size cap | Existing block-scoped proxy hardening patterns were available | Added `distributedProxyRateLimit`, path allowlisting, bounded query values, 15-second timeout, 4 MiB response cap, content-type forwarding, and `Cache-Control: no-store`. |
| Transaction history | Local `txHistory.ts` and `txIndexer.ts` | Same files and behavior | No duplicate copy was needed. |
| Server transaction verification | No `server/wallet/transactionService.ts` or `transactionVerifier.ts` in the upload | Present in reviewed source | Kept the reviewed server-authoritative EVM verification and pending-to-confirmed lifecycle transition. |
| Activity ledger | No generic activity router/service in the upload | Present in reviewed source | Kept the reviewed activity ledger, idempotency, active-day tracking, and snapshot streaming. |
| Fee authority | Bridge used a client-side wallet-fee constant in its uploaded code and had stale bridge re-exports | Reviewed source had backend fee configuration and treasury validation | Kept the backend authority; did not copy the stale `WALLET_FEE_ADDRESS`/`WALLET_FEE_BPS` imports. |
| Server startup | Uploaded startup had a 50 MiB global body-parser limit and automatic port fallback | Reviewed startup had bounded parsers, production fail-fast port binding, security headers, readiness, metrics, CSRF, rate limiting, and worker controls | Kept the reviewed startup hardening and added only the proxy registration. |
| Dependency/runtime baseline | Express 4.21.2 and Drizzle 0.44.5 | Express 5.2.1 and Drizzle 0.45.2 | Kept the reviewed dependency baseline; the upload was older and was not used as the base. |

## Files merged or updated

The following files were added or updated in the reviewed source:

| File | Change |
|---|---|
| `server/_core/lifiProxy.ts` | Added hardened server-side LI.FI proxy. |
| `server/_core/index.ts` | Registered the LI.FI proxy alongside the other restricted proxy routes. |
| `server/_core/env.ts` | Added centralized server-only `lifiApiKey` configuration. |
| `client/src/lib/wallet/bridge.ts` | Switched quote requests from direct LI.FI access to the same-origin proxy while preserving backend-provided `feeBps`. |
| `.env.example` | Documented optional `LIFI_API_KEY` and explicitly marked it server-only. |

## Important intentional differences

The uploaded bridge imported `WALLET_FEE_ADDRESS` and `WALLET_FEE_BPS` from the swap module and re-exported them. Those references were not copied because they conflict with the reviewed architecture in which fee configuration and treasury authority are server-owned. The uploaded bridge also disabled LI.FI fees through a hardcoded `LIFI_FEE_ENABLED = false`; that behavior was not copied. The final bridge continues to use the backend-provided fee basis and sends the quote request through the secured proxy.

The uploaded startup code used a 50 MiB global JSON and URL-encoded body limit. That was not copied because it would weaken the reviewed upload-abuse controls. The final source retains the 1 MiB JSON and 256 KiB URL-encoded global limits, with route-specific parsers where required.

## Verification after merge

The merged source passed TypeScript validation, the Vitest suite, the production client/server build, and the dependency audit. A targeted production smoke confirmed that the server starts, `/healthz` returns `200`, a disallowed LI.FI path returns `400`, the allowed `/status` proxy route is registered, and no server-only LI.FI key marker appears in `dist/public`.

The dependency audit continues to report one documented upstream `bigint-buffer` advisory through the Solana dependency chain. This was present independently of the uploaded bridge merge and remains tracked as an upstream release risk.

## References

[1]: ../client/src/lib/wallet/bridge.ts "Final bridge implementation"
[2]: ../client/src/pages/BridgePanel.tsx "Final bridge UI and transaction lifecycle"
[3]: ../server/_core/lifiProxy.ts "Hardened server-side LI.FI proxy"
[4]: ../server/_core/index.ts "Production server startup and route registration"
[5]: ../server/_core/env.ts "Server environment configuration"
[6]: ../server/wallet/transactionService.ts "Server-authoritative transaction lifecycle"
[7]: ../server/wallet/transactionVerifier.ts "EVM transaction receipt verification"
[8]: ../server/activity/activityService.ts "Activity ledger and eligibility service"
[9]: ../server/fees/feeEngine.ts "Backend fee engine"
[10]: ../client/src/lib/wallet/txHistory.ts "Local transaction history"
[11]: ../client/src/lib/wallet/txIndexer.ts "On-chain transaction indexer"
