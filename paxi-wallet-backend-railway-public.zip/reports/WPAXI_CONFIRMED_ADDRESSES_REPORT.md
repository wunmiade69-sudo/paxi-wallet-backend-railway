# Paxi Wallet Production Validation and WPAXI Configuration Report

**Validation date:** 12 August 2026  
**Project:** Paxi Wallet  
**Scope:** Architecture recovery, production gate verification, Railway schema deployment, WPAXI referral-reward configuration, and HTTP smoke testing.

## Executive result

The recovered Paxi Wallet implementation now passes the local type-check, unit-test, production-build, dependency-security, live Railway deployment, database regression, and production HTTP smoke-test gates. The final Railway deployment uses the idempotent `pnpm db:push` pipeline; raw `pnpm db:drizzle:push` remains intentionally disabled.

The WPAXI reward pools are stored in Railway as four reserve pools, each with a 50,000,000 WPAXI allocation. They remain **inactive by design** because distributor addresses have not yet been supplied and verified on-chain. No reward pool or referral policy was activated without the required distributor and allowlist controls.

## Confirmed on-chain configuration

| Item | Confirmed value | Stored state |
|---|---|---|
| Qualifying BSC PAXI token | `0xeda04581461bc308e60052fe489e20c3f78d6e4e` | Stored as the qualifying token for the WPAXI referral policy |
| WPAXI pool 1 | `0x093b86bcbaf0a723e4bd4a4922a9f986a25c6b52` | Priority 1; 50,000,000 WPAXI; reserve; unverified; no distributor |
| WPAXI pool 2 | `0xed806ccd5958fe1926402a28748e5ffa2bad2239` | Priority 2; 50,000,000 WPAXI; reserve; unverified; no distributor |
| WPAXI pool 3 | `0x6229aa83a83c04347a663e77c3ed3d3cd1530fb8` | Priority 3; 50,000,000 WPAXI; reserve; unverified; no distributor |
| WPAXI pool 4 | `0x1df8d99d2118f76d88c4f46317b03cf4b1ef5592` | Priority 4; 50,000,000 WPAXI; reserve; unverified; no distributor |
| Referral qualification | `$20` minimum verified BSC PAXI trading volume | Server-owned exact fixed-scale USD arithmetic |
| Referral reward | `150 WPAXI` per qualified referral | Issued through the claimable reward-pool lifecycle |
| Token decimals | `18` on BSC for WPAXI and the configured BSC PAXI fee-token path | Centralized in `server/rewards/wpaxiConfig.ts` |

## Production and database evidence

The complete deployment pipeline completed against the supplied Railway MySQL URL. It ran the provider, scale/partition, identifier-collation, reference-constraint, activity/fee/snapshot, reward/eligibility/airdrop, WPAXI configuration, index, fee-seed, and deployment-ledger stages, followed by the live regression suite.

The regression output ends with `✨ ALL DATABASE TESTS PASSED SUCCESSFULLY`. The deployment ledger reports eight applied consolidated milestones, including `wpaxi-referral-pools-v1`, and one legacy Drizzle ledger entry retained as informational only. The full captured output is available in [`final-railway-db-push.log`](./final-railway-db-push.log).

## Validation matrix

| Gate | Result | Evidence |
|---|---:|---|
| TypeScript | PASS | `pnpm check` completed with no diagnostics |
| Unit tests | PASS | 4 test files; 13 tests passed |
| Production build | PASS | Vite client build and esbuild server bundle completed |
| Dependency audit | PASS with documented upstream exception | No fixable high/critical advisories; `bigint-buffer` remains an upstream high advisory with no patched release |
| Railway deployment | PASS | `pnpm db:push` completed through deployment and regression |
| Database regression | PASS | All expected tables, columns, indexes, foreign keys, and ledger controls passed |
| HTTP health | PASS | `GET /healthz` returned 200 |
| HTTP readiness | PASS | `GET /readyz` returned 200 with `database: true` |
| Public market endpoints | PASS | `GET /api/chains` and `GET /api/assets` returned 200 |
| CSRF/cross-site mutation guard | PASS | Cross-site POST returned 403 |
| Protected rewards endpoint | PASS | Unauthenticated `rewards.mine` returned 401 |
| LI.FI proxy allowlist | PASS | Disallowed path returned 400 |

The captured production smoke log showed the server remaining alive under a bounded foreground lifecycle test and then passed the HTTP suite with workers disabled and Redis optional.

## Bugs found and fixed during final review

### Deployment-script recovery

The package pipeline referenced deployment helpers that were absent after the sandbox reset. The missing provider-provenance, scale-partitioning, identifier-audit/collation, reference-constraint, optimization, fee-seed, and dependency-audit scripts were restored from the prior verified project copy. The standard pipeline was then run successfully rather than bypassed.

### Express 5 wildcard incompatibilities

Express 5 rejected legacy bare wildcard patterns. The storage proxy now uses `/manus-storage/{*key}`, and the Vite development and production catch-all handlers now use `/{*splat}`. This removed production startup failures caused by `path-to-regexp`.

### Bundled CLI process exit

`server/assetRegistry.ts` contained a direct-execution block with `process.exit(0)`. Because the module was bundled into the production server, its ESM entrypoint check also matched the bundled server entrypoint and terminated the HTTP process immediately after startup. The script-only block was removed from the imported module, and `scripts/seedAssetRegistry.ts` was added as the dedicated operational CLI. This is now exposed as `pnpm db:seed-assets`.

### Dependency security remediation

The WalletConnect dependency graph contained `elliptic@6.5.7`, which is affected by a critical advisory. The project now pins pnpm to `10.34.5` and records a root `pnpm-workspace.yaml` override to `elliptic: 6.6.1`. The audit now reports only the unfixable upstream `bigint-buffer` advisory through `@solana/spl-token`.

### Cookie helper typing

The session-cookie helper now explicitly uses Express’s request type, preserving the hardened policy: HTTPS requests use `SameSite=None; Secure`, while local HTTP uses `SameSite=Lax; Secure=false`.

## Activation checklist for WPAXI rewards

The pools must remain inactive until all of the following are completed through the admin-controlled lifecycle:

1. Supply the distributor address for each pool through `rewardPools.setDistributor`.
2. Verify each distributor’s on-chain WPAXI balance through `rewardPools.verify`.
3. Activate each verified pool through `rewardPools.activate`.
4. Configure and verify trusted BSC router and pair allowlists for qualifying PAXI trades.
5. Activate the server-owned referral policy only after the trusted allowlists are present.
6. Issue rewards only through the claimable-pool flow and finalize claims only after verifying the distributor-to-user BSC `Transfer` event.

The $20 threshold is evaluated with fixed-scale decimal arithmetic, so exact `$20.00` qualification and cumulative volume boundaries do not depend on JavaScript floating-point behavior.

## Remaining production risks and conditions

The dependency audit still records the upstream `bigint-buffer` high advisory because the advisory reports no patched release. Its path is `@solana/spl-token > @solana/buffer-layout-utils > bigint-buffer`; the application audit gate explicitly documents this as unfixable upstream rather than silently ignoring it.

Redis was intentionally disabled in the smoke environment. Production deployments serving millions of users must provide a TLS-capable Redis service and set the required Redis environment variables so distributed rate limiting, BullMQ workers, and cross-instance coordination are active. The application’s graceful degradation is appropriate for local operation but is not a substitute for Redis in a horizontally scaled production deployment.

The Solana treasury remains empty according to the inherited deployment state, and distributor addresses for all four WPAXI pools are still outstanding. These are operational activation blockers, not code-validation failures.

The production build still emits non-fatal warnings about circular manual chunks, a mixed static/dynamic Bitcoin import, and an upstream `ox` pure-comment annotation. The build completes successfully; these warnings should remain on the frontend performance backlog and be monitored with bundle-size budgets.

## Files and commands

- Deployment and regression evidence: [`final-railway-db-push.log`](./final-railway-db-push.log)
- Dependency audit JSON: [`dependency-audit.json`](./dependency-audit.json)
- Production build evidence: [`final-production-build.log`](./final-production-build.log)
- Central WPAXI configuration: `server/rewards/wpaxiConfig.ts`
- Exact reward arithmetic: `server/rewards/rewardMath.ts`
- Dedicated asset-registry CLI: `scripts/seedAssetRegistry.ts`
- Safe deployment command: `pnpm db:push`

> Final conclusion: the codebase passes the current automated production gates and the live Railway regression suite. WPAXI referral rewards are correctly configured but intentionally not activatable until distributor addresses, on-chain balance verification, trusted trading allowlists, and policy activation are completed.
