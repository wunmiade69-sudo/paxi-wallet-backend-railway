# WPAXI Referral and Reward-Pool Implementation Report

**Project:** `/home/ubuntu/paxi-wallet-fixed/paxi-wallet`  
**Review source:** `/home/ubuntu/upload/pasted_content.txt`  
**Date:** 12 August 2026  
**Author:** **Manus AI**

## Executive summary

The PAXI Wallet rewards architecture has been extended for the verified BSC PAXI referral campaign described in the pasted requirements. The implementation now separates referral attribution, on-chain trade verification, risk gating, cumulative qualifying volume, reward allocation, claimable state, and final on-chain payout verification.

The launch policy is seeded with a **$20 minimum verified PAXI BSC trading volume** and a **150 WPAXI reward**, but it is deliberately inactive until the real PAXI token address, trusted BSC router addresses, trusted PAXI pair addresses, four WPAXI pool addresses, and distributor addresses are configured and verified. No contract address was fabricated from search results.

## Implemented architecture

| Area | Implementation | Result |
|---|---|---|
| Permanent referral relationship | Existing `referrals` attribution remains one-time through a unique invitee constraint. | A referred user cannot switch sponsors later. Self-referral remains rejected. |
| Configurable referral policy | Added `rewardPolicies` with `minimumVolumeUsd`, `rewardAmount`, qualifying asset, network, minimum trade size, cooldown, and trusted contract configuration. | The launch defaults are `$20` and `150 WPAXI`, while the values are server/database controlled. |
| Verified trade volume | Added `referralTradingVolume` and `server/rewards/referralTradingVerifier.ts`. | Only successful BSC transactions from the referred wallet, routed through an allowlisted router, involving an allowlisted PAXI pair, and containing the PAXI plus stablecoin legs can qualify. |
| Trade classification | Buy/sell direction is derived from the PAXI transfer log relative to the referred wallet. | Transfers, deposits, withdrawals, bridges, and holding activity are not accepted as qualifying trades. |
| Risk foundation | Added minimum trade size, configurable cooldown, transaction/event uniqueness, router/pair allowlists, and risk status/flags. | The first release has a controlled anti-fake-volume foundation without pretending to solve advanced related-wallet or wash-trading analysis. |
| Cumulative qualification | Verified approved trade contributions are summed with fixed-scale decimal arithmetic. | A `$12` buy plus an `$8` sell can reach the `$20` threshold; no client-supplied volume is trusted. |
| Automatic activity integration | Confirmed BSC `buy`/`sell` activity now triggers non-blocking referral processing for pending referrals. | The activity ledger remains authoritative; referral processing failures do not undo transaction confirmation. |
| Reward pools | Added `rewardPools` with policy, token, distributor, total, allocated, remaining, priority, status, and verification metadata. | Pools can be reserved, on-chain verified, activated, exhausted, paused, or invalid. Only one active pool is used at a time, with future rotation supported by priority. |
| Claimable rewards | Extended `rewardLedger` with `claimable` and `claimed` states; added `rewardClaims`. | Qualification creates a claimable ledger entry rather than an immediate blockchain payout. |
| Claim finalization | Added `server/rewards/rewardClaimService.ts`. | A claim becomes `claimed` only after a BSC receipt proves the configured distributor sent at least the required WPAXI amount to the server-derived recipient wallet. |
| Admin controls | Added `rewardPools` admin router for policy configuration, pool registration, token verification, and activation. | Contract authority and pool activation remain out of the client. |

## Referral qualification flow

The final flow is:

```text
Referral code attached permanently
        ↓
Invitee performs BSC PAXI trade
        ↓
Confirmed activity event
        ↓
BSC receipt verification
        ↓
Trusted router + trusted PAXI pair check
        ↓
PAXI transfer direction + stablecoin USD leg
        ↓
Duplicate and risk checks
        ↓
Verified referralTradingVolume row
        ↓
Cumulative volume reaches configurable minimum
        ↓
One-time referral qualification
        ↓
150 WPAXI claimable reward from active pool
        ↓
User claims through a distributor workflow
        ↓
Receipt verification marks ledger and claim as claimed
```

Only `buy` and `sell` events are accepted. The verifier rejects a client statement such as “I traded $20” unless the server independently verifies the transaction. The trusted router and pair lists are mandatory before the policy can be activated.

## Reward-pool lifecycle

The four WPAXI contracts described in the pasted requirements are modeled as four prioritized pools rather than four different assets. Each pool has its own token address, distributor address, total allocation, remaining allocation, and verification record. The expected operating sequence is:

| Pool state | Meaning |
|---|---|
| `reserve` | Registered but not yet verified or active. |
| `active` | Verified and eligible to back new claims. Only one active pool is selected for the policy. |
| `exhausted` | Remaining allocation is below the next reward or has reached zero. |
| `paused` | Temporarily disabled by administration. |
| `invalid` | Failed verification or was retired. |

The allocation code uses the configured token decimals and fixed-scale arithmetic. Before verification, it checks the token’s on-chain `symbol`, `decimals`, and `totalSupply`, and rejects a pool allocation larger than the on-chain supply. Pool registration requires a distributor address, because final claim verification must prove the token transfer originated from the configured distributor.

At **150 WPAXI per qualified referral**, four theoretical 50,000,000 WPAXI pools represent 200,000,000 WPAXI and approximately 1,333,333 rewards before reserves, other reward sources, failed allocations, or operational limits. This is a planning calculation only; no pool is activated by this implementation without verified contract data.

## Contract audit result

The local project, uploaded archive, and available notes did not contain the four WPAXI BSC contract addresses. A public BscScan search for `WPAXI` returned no direct token-filter matches; the visible general search results were PancakeSwap pair/address records labeled with names such as `PAXI`, `PAXI 2`, `WTAXI`, and `$SPAXI`. Those records were not treated as WPAXI token contracts.

The following visible search-result addresses were therefore explicitly **not** configured as reward pools:

| Address | Visible search label | Decision |
|---|---|---|
| `0x7c46da0a8c7d8bb3a37496e3a3d7c920e697ebe3` | PancakeSwap V2: `$SPAXI` | Not treated as a WPAXI token contract. |
| `0x0f455027b6c83c66f77af1f7aea1e1ac22642a3e` | PancakeSwap V2: `WTAXI` | Not treated as a WPAXI token contract. |
| `0x03c5d34a6b94882c8144dc2e75e334a8a7c2469d` | PancakeSwap V2: `PAXI` | Not treated as a WPAXI token contract. |
| `0x2cc763e2341e41bdf5966ca6de2ebc4ad98607ef` | PancakeSwap V2: `PAXI 2` | Not treated as a WPAXI token contract. |

Before pool activation, provide authoritative contract addresses or verified token records for all four pools, together with the distributor address and the trusted PAXI router/pair configuration. The admin pool verification endpoint will then check the live token metadata and supply before activation.

## Database changes and deployment

The idempotent `scripts/applyRewardsSchema.ts` deployment now creates or evolves the following tables and fields:

- `rewardPolicies` for server-owned referral policy values and trusted-contract configuration.
- `referralTradingVolume` for one-time, verified buy/sell contributions and risk status.
- `rewardPools` for prioritized WPAXI pool rotation and on-chain verification metadata.
- `rewardClaims` for claimable and claimed payout records, including recipient wallet and distributor evidence.
- `referrals.qualifyingVolumeUsd` and `referrals.rewardLedgerId`.
- `rewardLedger.claimableAt`, `rewardLedger.claimedAt`, and the expanded status enum.

The migration is wired into `pnpm db:deploy` and `pnpm db:push`. The consolidated deployment ledger now includes `wpaxi-referral-pools-v1` in addition to the existing PAXI milestones. Raw Drizzle migration execution remains disabled.

## Verification evidence

| Check | Result |
|---|---|
| TypeScript | Passed with `pnpm check`. |
| Unit tests | 9/9 tests passed across 3 test files. |
| Production build | Passed. Server bundle built at approximately 325 kB; WalletConnect remains isolated in its own vendor chunk. |
| Dependency gate | Passed with no fixable high/critical production advisory. The upstream `bigint-buffer` advisory remains through the Solana dependency chain. |
| Railway deployment | Complete `pnpm db:push` passed against the user-provided Railway database. |
| Railway regression | All table, schema, index, foreign-key, partition, and consolidated-ledger checks passed. |
| Deployment ledger | 8 milestones present, including `wpaxi-referral-pools-v1`. |
| Production smoke | Health `200`, readiness `200`, cross-site mutation `403`, unauthenticated claims query `401`, invalid LI.FI proxy path `400`. |
| Client secret isolation | Server-only LI.FI test key was absent from `dist/public`. |

## Remaining release blockers

The four WPAXI token addresses and authoritative metadata are still missing. The policy is intentionally inactive and no reward pool is active. The trusted PAXI router/pair addresses and distributor addresses are also required before the policy can be enabled.

The current first-release risk engine provides transaction uniqueness, allowlisted contracts, minimum trade sizing, cooldown support, and explicit risk status. It does not yet detect related wallets, self-trading across controlled accounts, circular liquidity, or abnormal volume patterns. Those controls should be introduced before referral rewards have material economic value.

The claim service verifies a payout transaction after the user or payout operator submits its hash; it does not broadcast transactions. A production distributor contract or multisignature treasury workflow must be connected and tested before real WPAXI claims are enabled.

The production build retains the existing Bitcoin dynamic/static import warning and a generic vendor chunk above the preferred warning threshold. The dependency scan retains the unfixable upstream `bigint-buffer` advisory. These did not fail the current project gates but remain maintenance items.

## Required configuration before activation

```text
PAXI BSC token contract address
Trusted BSC PAXI router address or addresses
Trusted BSC PAXI pair address or addresses
WPAXI pool #1 token address + distributor address
WPAXI pool #2 token address + distributor address
WPAXI pool #3 token address + distributor address
WPAXI pool #4 token address + distributor address
```

The default policy remains `$20` minimum verified volume and `150` WPAXI reward. These are database-owned and configurable through the admin policy endpoint, but the policy cannot activate without the contract allowlists and verified pools.
