import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });

type QueryRow = Record<string, unknown>;

async function tableExists(table: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?",
    [table],
  );
  return rows.length > 0;
}

async function columnExists(table: string, column: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [table, column],
  );
  return rows.length > 0;
}

async function addColumn(table: string, column: string, sql: string): Promise<void> {
  if (await columnExists(table, column)) {
    console.log(`✅ Column ${column} already exists on ${table}`);
    return;
  }
  await connection.query(sql);
  console.log(`✅ Added column ${column} to ${table}`);
}

async function indexExists(table: string, index: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?",
    [table, index],
  );
  return rows.length > 0;
}

async function constraintExists(table: string, constraint: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?",
    [table, constraint],
  );
  return rows.length > 0;
}

async function ensureColumnCollation(table: string, column: string, definition: string, targetCollation: string): Promise<void> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT COLLATION_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [table, column],
  );
  const current = rows[0]?.COLLATION_NAME;
  if (current === targetCollation) return;
  await connection.query(`ALTER TABLE \`${table}\` MODIFY COLUMN \`${column}\` ${definition}`);
  console.log(`✅ Normalized ${table}.${column} collation to ${targetCollation}`);
}

async function createIndex(table: string, name: string, sql: string): Promise<void> {
  if (await indexExists(table, name)) {
    console.log(`✅ Index ${name} already exists on ${table}`);
    return;
  }
  await connection.query(sql);
  console.log(`✅ Created index ${name} on ${table}`);
}

async function addForeignKey(table: string, name: string, sql: string): Promise<void> {
  if (await constraintExists(table, name)) {
    console.log(`✅ Foreign key ${name} already exists`);
    return;
  }
  await connection.query(sql);
  console.log(`✅ Added foreign key ${name}`);
}

try {
  console.log("Applying wallet activity and fee schema...");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`activityEvents\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`userOpenId\` VARCHAR(64) NOT NULL,
      \`walletAddress\` VARCHAR(128) NOT NULL,
      \`chainId\` VARCHAR(32) NOT NULL,
      \`eventType\` ENUM('wallet_creation','token_creation','buy','sell','swap','bridge','send','receive','deposit','withdrawal') NOT NULL,
      \`transactionHash\` VARCHAR(128) NULL,
      \`assetId\` INT NULL,
      \`amount\` VARCHAR(128) NULL,
      \`amountUsd\` VARCHAR(32) NULL,
      \`feeUsd\` VARCHAR(32) NULL,
      \`networkFeeUsd\` VARCHAR(32) NULL,
      \`paxiFeeUsd\` VARCHAR(32) NULL,
      \`verificationSource\` ENUM('legacy','server_semantic','server_internal') NOT NULL DEFAULT 'legacy',
      \`amountUsdSource\` ENUM('legacy','onchain_stablecoin','server_internal','none') NOT NULL DEFAULT 'legacy',
      \`status\` ENUM('pending','confirmed','failed') NOT NULL DEFAULT 'pending',
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      KEY \`activityEvents_user_created_idx\` (\`userOpenId\`, \`createdAt\`),
      KEY \`activityEvents_user_type_created_idx\` (\`userOpenId\`, \`eventType\`, \`createdAt\`),
      KEY \`activityEvents_transaction_hash_idx\` (\`transactionHash\`),
      KEY \`activityEvents_chain_created_idx\` (\`chainId\`, \`createdAt\`),
      KEY \`activityEvents_user_id_idx\` (\`userOpenId\`, \`id\`),
      UNIQUE KEY \`activityEvents_user_wallet_tx_type_idx\` (\`userOpenId\`, \`walletAddress\`, \`chainId\`, \`transactionHash\`, \`eventType\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`feeConfig\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`operation\` ENUM('swap_evm','swap_btc','bridge','create_token','listing') NOT NULL,
      \`chainType\` VARCHAR(32) NOT NULL,
      \`percentageBps\` INT NOT NULL DEFAULT 0,
      \`fixedUsd\` VARCHAR(32) NOT NULL DEFAULT '0',
      \`isActive\` TINYINT(1) NOT NULL DEFAULT 1,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`feeConfig_operation_chain_idx\` (\`operation\`, \`chainType\`),
      KEY \`feeConfig_active_idx\` (\`isActive\`, \`operation\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`feeRecords\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`userOpenId\` VARCHAR(64) NOT NULL,
      \`activityEventId\` BIGINT UNSIGNED NULL,
      \`operation\` ENUM('swap_evm','swap_btc','bridge','create_token','listing') NOT NULL,
      \`chainType\` VARCHAR(32) NOT NULL,
      \`inputAmountUsd\` VARCHAR(32) NOT NULL,
      \`paxiFeeUsd\` VARCHAR(32) NOT NULL,
      \`networkFeeUsd\` VARCHAR(32) NOT NULL,
      \`totalFeeUsd\` VARCHAR(32) NOT NULL,
      \`transactionHash\` VARCHAR(128) NULL,
      \`status\` ENUM('pending','confirmed','failed') NOT NULL DEFAULT 'pending',
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`feeRecords_activity_event_idx\` (\`activityEventId\`),
      KEY \`feeRecords_user_created_idx\` (\`userOpenId\`, \`createdAt\`),
      KEY \`feeRecords_transaction_hash_idx\` (\`transactionHash\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaignSnapshotParticipants\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`snapshotId\` INT NOT NULL,
      \`userOpenId\` VARCHAR(64) NOT NULL,
      \`wallets\` JSON NOT NULL,
      \`chains\` JSON NOT NULL,
      \`activeDays\` INT NOT NULL DEFAULT 0,
      \`totalConfirmedEvents\` INT NOT NULL DEFAULT 0,
      \`totalVolumeUsd\` VARCHAR(32) NOT NULL DEFAULT '0',
      \`eventCounts\` JSON NOT NULL,
      \`volumeUsdByType\` JSON NOT NULL,
      \`requirements\` JSON NULL,
      \`externalScore\` INT NULL,
      \`eligibilityTier\` ENUM('pending','not_qualified','minimum','highest') NOT NULL DEFAULT 'pending',
      \`reviewedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`campaignSnapshotParticipants_snapshot_user_idx\` (\`snapshotId\`, \`userOpenId\`),
      KEY \`campaignSnapshotParticipants_eligibility_idx\` (\`snapshotId\`, \`eligibilityTier\`),
      KEY \`campaignSnapshotParticipants_user_idx\` (\`userOpenId\`, \`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);

  await addColumn("activityEvents", "verificationSource", "ALTER TABLE `activityEvents` ADD COLUMN `verificationSource` ENUM('legacy','server_semantic','server_internal') NOT NULL DEFAULT 'legacy' AFTER `paxiFeeUsd`");
  await addColumn("activityEvents", "amountUsdSource", "ALTER TABLE `activityEvents` ADD COLUMN `amountUsdSource` ENUM('legacy','onchain_stablecoin','server_internal','none') NOT NULL DEFAULT 'legacy' AFTER `verificationSource`");
  await ensureColumnCollation("activityEvents", "userOpenId", "VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL", "utf8mb4_0900_ai_ci");
  await ensureColumnCollation("activityEvents", "chainId", "VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL", "utf8mb4_0900_ai_ci");
  await ensureColumnCollation("feeRecords", "userOpenId", "VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL", "utf8mb4_0900_ai_ci");
  await ensureColumnCollation("campaignSnapshotParticipants", "userOpenId", "VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL", "utf8mb4_0900_ai_ci");
  await ensureColumnCollation("campaignSnapshots", "createdByOpenId", "VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL", "utf8mb4_0900_ai_ci");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaignSnapshots\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`campaignId\` INT NOT NULL,
      \`snapshotDate\` TIMESTAMP(3) NOT NULL,
      \`status\` ENUM('pending','frozen','calculating','complete','distributed') NOT NULL DEFAULT 'pending',
      \`totalParticipants\` INT NOT NULL DEFAULT 0,
      \`qualifiedCount\` INT NOT NULL DEFAULT 0,
      \`snapshotData\` JSON NULL,
      \`frozenAt\` TIMESTAMP(3) NULL,
      \`calculatedAt\` TIMESTAMP(3) NULL,
      \`distributedAt\` TIMESTAMP(3) NULL,
      \`createdByOpenId\` VARCHAR(64) NOT NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`campaignSnapshots_campaign_date_idx\` (\`campaignId\`, \`snapshotDate\`),
      KEY \`campaignSnapshots_status_created_idx\` (\`status\`, \`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);

  await createIndex("activityEvents", "activityEvents_user_created_idx", "CREATE INDEX `activityEvents_user_created_idx` ON `activityEvents` (`userOpenId`,`createdAt`)");
  await createIndex("activityEvents", "activityEvents_user_type_created_idx", "CREATE INDEX `activityEvents_user_type_created_idx` ON `activityEvents` (`userOpenId`,`eventType`,`createdAt`)");
  await createIndex("activityEvents", "activityEvents_transaction_hash_idx", "CREATE INDEX `activityEvents_transaction_hash_idx` ON `activityEvents` (`transactionHash`)");
  await createIndex("activityEvents", "activityEvents_chain_created_idx", "CREATE INDEX `activityEvents_chain_created_idx` ON `activityEvents` (`chainId`,`createdAt`)");
  await createIndex("activityEvents", "activityEvents_user_id_idx", "CREATE INDEX `activityEvents_user_id_idx` ON `activityEvents` (`userOpenId`,`id`)");
  await createIndex("activityEvents", "activityEvents_user_status_source_idx", "CREATE INDEX `activityEvents_user_status_source_idx` ON `activityEvents` (`userOpenId`,`status`,`verificationSource`,`createdAt`)");
  await createIndex("activityEvents", "activityEvents_user_wallet_tx_type_idx", "CREATE UNIQUE INDEX `activityEvents_user_wallet_tx_type_idx` ON `activityEvents` (`userOpenId`,`walletAddress`,`chainId`,`transactionHash`,`eventType`)");
  await createIndex("feeConfig", "feeConfig_operation_chain_idx", "CREATE UNIQUE INDEX `feeConfig_operation_chain_idx` ON `feeConfig` (`operation`,`chainType`)");
  await createIndex("feeConfig", "feeConfig_active_idx", "CREATE INDEX `feeConfig_active_idx` ON `feeConfig` (`isActive`,`operation`)");
  await createIndex("feeRecords", "feeRecords_activity_event_idx", "CREATE UNIQUE INDEX `feeRecords_activity_event_idx` ON `feeRecords` (`activityEventId`)");
  await createIndex("feeRecords", "feeRecords_user_created_idx", "CREATE INDEX `feeRecords_user_created_idx` ON `feeRecords` (`userOpenId`,`createdAt`)");
  await createIndex("feeRecords", "feeRecords_transaction_hash_idx", "CREATE INDEX `feeRecords_transaction_hash_idx` ON `feeRecords` (`transactionHash`)");
  await createIndex("campaignSnapshotParticipants", "campaignSnapshotParticipants_snapshot_user_idx", "CREATE UNIQUE INDEX `campaignSnapshotParticipants_snapshot_user_idx` ON `campaignSnapshotParticipants` (`snapshotId`,`userOpenId`)");
  await createIndex("campaignSnapshotParticipants", "campaignSnapshotParticipants_eligibility_idx", "CREATE INDEX `campaignSnapshotParticipants_eligibility_idx` ON `campaignSnapshotParticipants` (`snapshotId`,`eligibilityTier`)");
  await createIndex("campaignSnapshotParticipants", "campaignSnapshotParticipants_user_idx", "CREATE INDEX `campaignSnapshotParticipants_user_idx` ON `campaignSnapshotParticipants` (`userOpenId`,`createdAt`)");
  await createIndex("campaignSnapshots", "campaignSnapshots_campaign_date_idx", "CREATE UNIQUE INDEX `campaignSnapshots_campaign_date_idx` ON `campaignSnapshots` (`campaignId`,`snapshotDate`)");
  await createIndex("campaignSnapshots", "campaignSnapshots_status_created_idx", "CREATE INDEX `campaignSnapshots_status_created_idx` ON `campaignSnapshots` (`status`,`createdAt`)");

  await addForeignKey("activityEvents", "activityEvents_userOpenId_users_fk", "ALTER TABLE `activityEvents` ADD CONSTRAINT `activityEvents_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("activityEvents", "activityEvents_chainId_chains_fk", "ALTER TABLE `activityEvents` ADD CONSTRAINT `activityEvents_chainId_chains_fk` FOREIGN KEY (`chainId`) REFERENCES `chains` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("activityEvents", "activityEvents_assetId_assets_fk", "ALTER TABLE `activityEvents` ADD CONSTRAINT `activityEvents_assetId_assets_fk` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("feeRecords", "feeRecords_userOpenId_users_fk", "ALTER TABLE `feeRecords` ADD CONSTRAINT `feeRecords_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("feeRecords", "feeRecords_activityEventId_activityEvents_fk", "ALTER TABLE `feeRecords` ADD CONSTRAINT `feeRecords_activityEventId_activityEvents_fk` FOREIGN KEY (`activityEventId`) REFERENCES `activityEvents` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("campaignSnapshots", "campaignSnapshots_campaignId_campaigns_fk", "ALTER TABLE `campaignSnapshots` ADD CONSTRAINT `campaignSnapshots_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("campaignSnapshots", "campaignSnapshots_createdByOpenId_users_fk", "ALTER TABLE `campaignSnapshots` ADD CONSTRAINT `campaignSnapshots_createdByOpenId_users_fk` FOREIGN KEY (`createdByOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("campaignSnapshotParticipants", "campaignSnapshotParticipants_snapshotId_campaignSnapshots_fk", "ALTER TABLE `campaignSnapshotParticipants` ADD CONSTRAINT `campaignSnapshotParticipants_snapshotId_campaignSnapshots_fk` FOREIGN KEY (`snapshotId`) REFERENCES `campaignSnapshots` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("campaignSnapshotParticipants", "campaignSnapshotParticipants_userOpenId_users_fk", "ALTER TABLE `campaignSnapshotParticipants` ADD CONSTRAINT `campaignSnapshotParticipants_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");

  console.log("✅ Activity, fee, and campaign snapshot schema is ready.");
} catch (error) {
  console.error("❌ Activity schema deployment failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
