import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
const deploymentVersions = [
  { version: "providers-v1", checksum: "provider-provenance" },
  { version: "scale-partitioning-v1", checksum: "candles-marketSnapshots-partitions" },
  { version: "identifier-collation-v1", checksum: "assets-identifier-utf8mb4-bin" },
  { version: "reference-constraints-v1", checksum: "ownership-and-user-fks" },
  { version: "optimization-indexes-v1", checksum: "performance-indexes" },
  { version: "activity-fees-snapshots-v1", checksum: "wallet-activity-fee-engine-campaign-snapshots" },
  { version: "rewards-eligibility-airdrop-v1", checksum: "referrals-gift-codes-reward-ledger-eligibility-airdrops" },
  { version: "wpaxi-referral-pools-v1", checksum: "verified-bsc-volume-rotating-pools-claimable-rewards" },
  { version: "listing-campaign-escrow-v1", checksum: "listing-review-campaign-pool-required-usd" },
  { version: "listing-events-v1", checksum: "immutable-listing-review-and-resubmission-history" },
  { version: "campaign-assets-moderation-v1", checksum: "validated-private-assets-admin-approved-public-campaigns" },
  { version: "campaign-featured-eligibility-claims-v1", checksum: "featured-home-carousel-server-activity-eligibility-claimable-campaign-entries" },
];

try {
  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`paxiSchemaDeployments\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`version\` VARCHAR(96) NOT NULL,
      \`checksum\` VARCHAR(128) NOT NULL,
      \`appliedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`paxiSchemaDeployments_version_idx\` (\`version\`),
      KEY \`paxiSchemaDeployments_applied_idx\` (\`appliedAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);
  for (const item of deploymentVersions) {
    await connection.query(
      `INSERT INTO \`paxiSchemaDeployments\` (\`version\`, \`checksum\`) VALUES (?, ?) ON DUPLICATE KEY UPDATE \`checksum\` = VALUES(\`checksum\`)`,
      [item.version, item.checksum],
    );
  }
  console.log(`✅ Deployment ledger contains ${deploymentVersions.length} idempotent pipeline milestones.`);
} catch (error) {
  console.error("❌ Deployment ledger update failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
