import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");
const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const [rows] = await connection.query(
    "SELECT CHARACTER_SET_NAME, COLLATION_NAME, IS_NULLABLE, COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'identifier'",
  );
  const column = (rows as Array<{ CHARACTER_SET_NAME: string; COLLATION_NAME: string; IS_NULLABLE: string; COLUMN_TYPE: string }>)[0];
  if (!column) throw new Error("assets.identifier column not found");
  if (column.COLLATION_NAME === "utf8mb4_bin") {
    console.log("✅ assets.identifier already uses utf8mb4_bin");
  } else {
    await connection.query("ALTER TABLE `assets` MODIFY `identifier` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL");
    console.log(`✅ assets.identifier collation changed from ${column.COLLATION_NAME} to utf8mb4_bin`);
  }
} catch (error) {
  console.error("❌ Identifier collation deployment failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
