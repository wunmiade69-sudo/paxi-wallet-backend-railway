import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
type QueryRow = Record<string, unknown>;

async function constraintExists(table: string, constraint: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?",
    [table, constraint],
  );
  return rows.length > 0;
}

async function columnExists(table: string, column: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [table, column],
  );
  return rows.length > 0;
}

async function columnType(table: string, column: string): Promise<string> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [table, column],
  );
  return String(rows[0]?.COLUMN_TYPE ?? "");
}

async function indexExists(table: string, index: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?",
    [table, index],
  );
  return rows.length > 0;
}

async function addForeignKey(table: string, name: string, statement: string): Promise<void> {
  if (await constraintExists(table, name)) return;
  await connection.query(statement);
}

try {
  console.log("Applying PAXI listing and campaign schema...");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`tokenListings\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`contractAddress\` VARCHAR(64) NOT NULL,
      \`network\` VARCHAR(32) NOT NULL,
      \`symbol\` VARCHAR(32) NOT NULL,
      \`name\` VARCHAR(128) NOT NULL,
      \`logoKey\` VARCHAR(255) NULL,
      \`logoUrl\` VARCHAR(500) NULL,
      \`source\` ENUM('seed','created','community') NOT NULL,
      \`status\` ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
      \`socials\` JSON NULL,
      \`plan\` TEXT NULL,
      \`feeTxHash\` VARCHAR(128) NULL,
      \`feeAmountUsd\` VARCHAR(16) NULL,
      \`submittedByOpenId\` VARCHAR(64) NULL,
      \`reviewedByOpenId\` VARCHAR(64) NULL,
      \`rejectionReason\` TEXT NULL,
      \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updatedAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`tokenListings_contract_network_idx\` (\`contractAddress\`, \`network\`),
      KEY \`tokenListings_status_created_idx\` (\`status\`, \`createdAt\`),
      KEY \`tokenListings_submitted_by_updated_idx\` (\`submittedByOpenId\`, \`updatedAt\`),
      UNIQUE KEY \`tokenListings_fee_tx_hash_idx\` (\`feeTxHash\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaigns\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`listingId\` INT NOT NULL,
      \`title\` VARCHAR(128) NOT NULL,
      \`description\` TEXT NULL,
      \`bannerKey\` VARCHAR(255) NULL,
      \`iconKey\` VARCHAR(255) NULL,
      \`website\` VARCHAR(500) NULL,
      \`socials\` JSON NULL,
      \`taskType\` ENUM('swap_volume') NOT NULL DEFAULT 'swap_volume',
      \`minTokenAmount\` VARCHAR(64) NOT NULL,
      \`taskTokenSymbol\` VARCHAR(32) NOT NULL,
      \`taskTokenContractAddress\` VARCHAR(64) NULL,
      \`taskTokenNetwork\` VARCHAR(32) NOT NULL,
      \`rewardAmount\` VARCHAR(64) NOT NULL,
      \`rewardTokenSymbol\` VARCHAR(32) NOT NULL,
      \`rewardTokenContractAddress\` VARCHAR(64) NULL,
      \`rewardNetwork\` VARCHAR(32) NOT NULL,
      \`maxWinners\` INT NOT NULL,
      \`winnersCount\` INT NOT NULL DEFAULT 0,
      \`poolRequiredAmountUsd\` VARCHAR(16) NOT NULL,
      \`poolFundedTxHash\` VARCHAR(128) NULL,
      \`poolFundedAmountUsd\` VARCHAR(16) NULL,
      \`isFeatured\` TINYINT(1) NOT NULL DEFAULT 0,
      \`featuredAt\` TIMESTAMP NULL,
      \`claimsPaused\` TINYINT(1) NOT NULL DEFAULT 0,
      \`status\` ENUM('draft','pending_review','active','suspended','rejected','ended','cancelled') NOT NULL DEFAULT 'draft',
      \`startAt\` TIMESTAMP NULL,
      \`endAt\` TIMESTAMP NULL,
      \`createdByOpenId\` VARCHAR(64) NOT NULL,
      \`submittedAt\` TIMESTAMP NULL,
      \`reviewedAt\` TIMESTAMP NULL,
      \`reviewedByOpenId\` VARCHAR(64) NULL,
      \`rejectionReason\` TEXT NULL,
      \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updatedAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      KEY \`campaigns_status_timeline_idx\` (\`status\`, \`startAt\`, \`endAt\`),
      KEY \`campaigns_featured_timeline_idx\` (\`isFeatured\`, \`status\`, \`startAt\`, \`endAt\`),
      KEY \`campaigns_listing_updated_idx\` (\`listingId\`, \`updatedAt\`),
      KEY \`campaigns_created_by_idx\` (\`createdByOpenId\`, \`createdAt\`),
      UNIQUE KEY \`campaigns_pool_funded_tx_hash_idx\` (\`poolFundedTxHash\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  if (!(await columnExists("campaigns", "poolRequiredAmountUsd"))) {
    await connection.query("ALTER TABLE `campaigns` ADD COLUMN `poolRequiredAmountUsd` VARCHAR(16) NOT NULL DEFAULT '0' AFTER `winnersCount`");
  }
  if (!(await columnExists("campaigns", "bannerKey"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `bannerKey` VARCHAR(255) NULL");
  if (!(await columnExists("campaigns", "iconKey"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `iconKey` VARCHAR(255) NULL");
  if (!(await columnExists("campaigns", "website"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `website` VARCHAR(500) NULL");
  if (!(await columnExists("campaigns", "socials"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `socials` JSON NULL");
  if (!(await columnExists("campaigns", "submittedAt"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `submittedAt` TIMESTAMP NULL");
  if (!(await columnExists("campaigns", "reviewedAt"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `reviewedAt` TIMESTAMP NULL");
  if (!(await columnExists("campaigns", "reviewedByOpenId"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `reviewedByOpenId` VARCHAR(64) NULL");
  if (!(await columnExists("campaigns", "rejectionReason"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rejectionReason` TEXT NULL");
  if (!(await columnExists("campaigns", "isFeatured"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `isFeatured` TINYINT(1) NOT NULL DEFAULT 0");
  if (!(await columnExists("campaigns", "featuredAt"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `featuredAt` TIMESTAMP NULL");
  if (!(await columnExists("campaigns", "claimsPaused"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `claimsPaused` TINYINT(1) NOT NULL DEFAULT 0");
  if (!(await columnType("campaigns", "status")).includes("suspended")) {
    await connection.query("ALTER TABLE `campaigns` MODIFY COLUMN `status` ENUM('draft','pending_review','active','suspended','rejected','ended','cancelled') NOT NULL DEFAULT 'draft'");
  }
  if (!(await indexExists("campaigns", "campaigns_featured_timeline_idx"))) await connection.query("ALTER TABLE `campaigns` ADD KEY `campaigns_featured_timeline_idx` (`isFeatured`, `status`, `startAt`, `endAt`)");

  if (!(await columnExists("campaigns", "rewardEscrowRequiredAmount"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowRequiredAmount` VARCHAR(128) NULL AFTER `poolFundedAmountUsd`");
  if (!(await columnExists("campaigns", "rewardEscrowTokenDecimals"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowTokenDecimals` INT NULL AFTER `rewardEscrowRequiredAmount`");
  if (!(await columnExists("campaigns", "rewardEscrowAmountUnits"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowAmountUnits` VARCHAR(128) NULL AFTER `rewardEscrowTokenDecimals`");
  if (!(await columnExists("campaigns", "rewardEscrowRecipient"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowRecipient` VARCHAR(128) NULL AFTER `rewardEscrowAmountUnits`");
  if (!(await columnExists("campaigns", "rewardEscrowFundedTxHash"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowFundedTxHash` VARCHAR(128) NULL AFTER `rewardEscrowRecipient`");
  if (!(await columnExists("campaigns", "rewardEscrowFundedAt"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowFundedAt` TIMESTAMP NULL AFTER `rewardEscrowFundedTxHash`");
  if (!(await columnExists("campaigns", "rewardEscrowVerification"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowVerification` JSON NULL AFTER `rewardEscrowFundedAt`");
  if (!(await columnExists("campaigns", "rewardRequiredAmountUnits"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardRequiredAmountUnits` VARCHAR(128) NULL AFTER `rewardEscrowAmountUnits`");
  if (!(await columnExists("campaigns", "rewardEscrowedAmountUnits"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardEscrowedAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardRequiredAmountUnits`");
  if (!(await columnExists("campaigns", "rewardReservedAmountUnits"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardReservedAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardEscrowedAmountUnits`");
  if (!(await columnExists("campaigns", "rewardClaimedAmountUnits"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardClaimedAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardReservedAmountUnits`");
  if (!(await columnExists("campaigns", "rewardRemainingAmountUnits"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardRemainingAmountUnits` VARCHAR(128) NOT NULL DEFAULT '0' AFTER `rewardClaimedAmountUnits`");
  if (!(await columnExists("campaigns", "rewardAccountingUpdatedAt"))) await connection.query("ALTER TABLE `campaigns` ADD COLUMN `rewardAccountingUpdatedAt` TIMESTAMP NULL AFTER `rewardRemainingAmountUnits`");
  if (!(await indexExists("campaigns", "campaigns_reward_escrow_funded_tx_hash_idx"))) await connection.query("ALTER TABLE `campaigns` ADD UNIQUE KEY `campaigns_reward_escrow_funded_tx_hash_idx` (`rewardEscrowFundedTxHash`)");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaignEntries\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`campaignId\` INT NOT NULL,
      \`userOpenId\` VARCHAR(64) NOT NULL,
      \`progressAmount\` VARCHAR(64) NOT NULL DEFAULT '0',
      \`slotNumber\` INT NULL,
      \`qualifiedAt\` TIMESTAMP NULL,
      \`proofTxHash\` VARCHAR(128) NULL,
      \`payoutStatus\` ENUM('pending','claimable','paid') NOT NULL DEFAULT 'pending',
      \`claimRequestedAt\` TIMESTAMP NULL,
      \`payoutTxHash\` VARCHAR(128) NULL,
      \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updatedAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`campaignEntries_campaign_user_idx\` (\`campaignId\`, \`userOpenId\`),
      UNIQUE KEY \`campaignEntries_campaign_slot_idx\` (\`campaignId\`, \`slotNumber\`),
      KEY \`campaignEntries_user_created_idx\` (\`userOpenId\`, \`createdAt\`),
      UNIQUE KEY \`campaignEntries_proof_tx_hash_idx\` (\`proofTxHash\`),
      UNIQUE KEY \`campaignEntries_payout_tx_hash_idx\` (\`payoutTxHash\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
  if (!(await columnExists("campaignEntries", "claimRequestedAt"))) await connection.query("ALTER TABLE `campaignEntries` ADD COLUMN `claimRequestedAt` TIMESTAMP NULL");
  if (!(await columnExists("campaignEntries", "payoutWalletAddress"))) await connection.query("ALTER TABLE `campaignEntries` ADD COLUMN `payoutWalletAddress` VARCHAR(128) NULL AFTER `userOpenId`");
  if (!(await columnType("campaignEntries", "payoutStatus")).includes("claimable")) {
    await connection.query("ALTER TABLE `campaignEntries` MODIFY COLUMN `payoutStatus` ENUM('pending','claimable','paid') NOT NULL DEFAULT 'pending'");
  }

  await connection.query(`
    CREATE TABLE IF NOT EXISTS `campaignRewardEscrowVerifications` (
      `id` BIGINT NOT NULL AUTO_INCREMENT,
      `campaignId` INT NOT NULL,
      `transactionHash` VARCHAR(128) NOT NULL,
      `network` VARCHAR(32) NOT NULL,
      `tokenContractAddress` VARCHAR(128) NOT NULL,
      `senderAddress` VARCHAR(128) NOT NULL,
      `escrowRecipient` VARCHAR(128) NOT NULL,
      `tokenDecimals` INT NOT NULL,
      `amountUnits` VARCHAR(128) NOT NULL,
      `status` ENUM('verified','rejected') NOT NULL,
      `verificationData` JSON NULL,
      `createdAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      UNIQUE KEY `campaignRewardEscrow_transaction_hash_idx` (`transactionHash`),
      KEY `campaignRewardEscrow_campaign_status_idx` (`campaignId`, `status`, `createdAt`),
      CONSTRAINT `campaignRewardEscrowVerifications_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaignPayouts\` (
      \`id\` BIGINT NOT NULL AUTO_INCREMENT,
      \`campaignId\` INT NOT NULL,
      \`entryId\` INT NOT NULL,
      \`idempotencyKey\` VARCHAR(191) NOT NULL,
      \`network\` VARCHAR(32) NOT NULL,
      \`tokenContractAddress\` VARCHAR(128) NOT NULL,
      \`recipientAddress\` VARCHAR(128) NOT NULL,
      \`senderAddress\` VARCHAR(128) NULL,
      \`amountUnits\` VARCHAR(128) NOT NULL,
      \`nonce\` INT NULL,
      \`nonceKey\` VARCHAR(191) NULL,
      \`transactionHash\` VARCHAR(128) NULL,
      \`status\` ENUM('reserved','broadcast','confirmed','failed','recovery_required') NOT NULL DEFAULT 'reserved',
      \`lastError\` TEXT NULL,
      \`broadcastLeaseUntil\` TIMESTAMP NULL,
      \`confirmedBlockNumber\` INT NULL,
      \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`broadcastAt\` TIMESTAMP NULL,
      \`confirmedAt\` TIMESTAMP NULL,
      \`updatedAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`campaignPayouts_entry_idx\` (\`entryId\`),
      UNIQUE KEY \`campaignPayouts_idempotency_idx\` (\`idempotencyKey\`),
      UNIQUE KEY \`campaignPayouts_transaction_idx\` (\`transactionHash\`),
      UNIQUE KEY \`campaignPayouts_nonce_idx\` (\`nonceKey\`),
      KEY \`campaignPayouts_campaign_status_idx\` (\`campaignId\`, \`status\`, \`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
  if (!(await columnExists("campaignPayouts", "broadcastLeaseUntil"))) await connection.query("ALTER TABLE `campaignPayouts` ADD COLUMN `broadcastLeaseUntil` TIMESTAMP NULL AFTER `lastError`");
  if (!(await columnType("campaignPayouts", "status")).includes("recovery_required")) await connection.query("ALTER TABLE `campaignPayouts` MODIFY COLUMN `status` ENUM('reserved','broadcast','confirmed','failed','recovery_required') NOT NULL DEFAULT 'reserved'");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`listingEvents\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`listingId\` INT NOT NULL,
      \`eventType\` ENUM('submitted','resubmitted','auto_verified','verified','rejected') NOT NULL,
      \`actorOpenId\` VARCHAR(64) NULL,
      \`message\` TEXT NULL,
      \`feeTxHash\` VARCHAR(128) NULL,
      \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      KEY \`listingEvents_listing_created_idx\` (\`listingId\`, \`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`adminAuditEvents\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`actorOpenId\` VARCHAR(64) NOT NULL,
      \`action\` VARCHAR(80) NOT NULL,
      \`resourceType\` VARCHAR(48) NOT NULL,
      \`resourceId\` INT NULL,
      \`details\` JSON NULL,
      \`createdAt\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      KEY \`adminAuditEvents_actor_created_idx\` (\`actorOpenId\`, \`createdAt\`),
      KEY \`adminAuditEvents_resource_created_idx\` (\`resourceType\`, \`resourceId\`, \`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  await addForeignKey("campaigns", "campaigns_listingId_tokenListings_fk", "ALTER TABLE `campaigns` ADD CONSTRAINT `campaigns_listingId_tokenListings_fk` FOREIGN KEY (`listingId`) REFERENCES `tokenListings` (`id`)");
  await addForeignKey("campaignEntries", "campaignEntries_campaignId_campaigns_fk", "ALTER TABLE `campaignEntries` ADD CONSTRAINT `campaignEntries_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`)");
  await addForeignKey("campaignPayouts", "campaignPayouts_campaignId_campaigns_fk", "ALTER TABLE `campaignPayouts` ADD CONSTRAINT `campaignPayouts_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`)");
  await addForeignKey("campaignPayouts", "campaignPayouts_entryId_campaignEntries_fk", "ALTER TABLE `campaignPayouts` ADD CONSTRAINT `campaignPayouts_entryId_campaignEntries_fk` FOREIGN KEY (`entryId`) REFERENCES `campaignEntries` (`id`)");
  await addForeignKey("listingEvents", "listingEvents_listingId_tokenListings_fk", "ALTER TABLE `listingEvents` ADD CONSTRAINT `listingEvents_listingId_tokenListings_fk` FOREIGN KEY (`listingId`) REFERENCES `tokenListings` (`id`)");
  await addForeignKey("adminAuditEvents", "adminAuditEvents_actorOpenId_users_fk", "ALTER TABLE `adminAuditEvents` ADD CONSTRAINT `adminAuditEvents_actorOpenId_users_fk` FOREIGN KEY (`actorOpenId`) REFERENCES `users` (`openId`)");

  console.log("✅ Listing and campaign tables are ready.");
} catch (error) {
  console.error("❌ Listing/campaign schema update failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
