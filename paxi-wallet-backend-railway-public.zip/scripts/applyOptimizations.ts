import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  console.log("Applying schema optimizations...");

  const checkIndex = async (table: string, index: string) => {
    const [rows] = await connection.query(
      `SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`,
      [table, index]
    ) as [any[], any];
    return rows.length > 0;
  };

  const optimizations = [
    { table: "assets", index: "assets_status_updated_idx", sql: "CREATE INDEX `assets_status_updated_idx` ON `assets` (`status`,`updatedAt`)" },
    { table: "assets", index: "assets_verification_status_idx", sql: "CREATE INDEX `assets_verification_status_idx` ON `assets` (`verificationStatus`)" },
    { table: "markets", index: "markets_asset_status_updated_idx", sql: "CREATE INDEX `markets_asset_status_updated_idx` ON `markets` (`assetId`,`status`,`updatedAt`)" },
    { table: "tokenListings", index: "tokenListings_status_created_idx", sql: "CREATE INDEX `tokenListings_status_created_idx` ON `tokenListings` (`status`,`createdAt`)" },
    { table: "campaigns", index: "campaigns_status_timeline_idx", sql: "CREATE INDEX `campaigns_status_timeline_idx` ON `campaigns` (`status`,`startAt`,`endAt`)" },
    { table: "campaignEntries", index: "campaignEntries_user_created_idx", sql: "CREATE INDEX `campaignEntries_user_created_idx` ON `campaignEntries` (`userOpenId`,`createdAt`)" },
    { table: "tokenListings", index: "tokenListings_submitted_by_updated_idx", sql: "CREATE INDEX `tokenListings_submitted_by_updated_idx` ON `tokenListings` (`submittedByOpenId`,`updatedAt`)" },
    { table: "tokenListings", index: "tokenListings_fee_tx_hash_idx", sql: "CREATE UNIQUE INDEX `tokenListings_fee_tx_hash_idx` ON `tokenListings` (`feeTxHash`)" },
    { table: "campaigns", index: "campaigns_listing_updated_idx", sql: "CREATE INDEX `campaigns_listing_updated_idx` ON `campaigns` (`listingId`,`updatedAt`)" },
    { table: "campaigns", index: "campaigns_created_by_idx", sql: "CREATE INDEX `campaigns_created_by_idx` ON `campaigns` (`createdByOpenId`,`createdAt`)" },
    { table: "campaigns", index: "campaigns_pool_funded_tx_hash_idx", sql: "CREATE UNIQUE INDEX `campaigns_pool_funded_tx_hash_idx` ON `campaigns` (`poolFundedTxHash`)" },
    { table: "campaignEntries", index: "campaignEntries_proof_tx_hash_idx", sql: "CREATE UNIQUE INDEX `campaignEntries_proof_tx_hash_idx` ON `campaignEntries` (`proofTxHash`)" },
    { table: "campaignEntries", index: "campaignEntries_payout_tx_hash_idx", sql: "CREATE UNIQUE INDEX `campaignEntries_payout_tx_hash_idx` ON `campaignEntries` (`payoutTxHash`)" },
  ];

  for (const opt of optimizations) {
    if (await checkIndex(opt.table, opt.index)) {
      console.log(`✅ Index ${opt.index} already exists on ${opt.table}`);
    } else {
      console.log(`🚀 Creating index ${opt.index} on ${opt.table}...`);
      await connection.query(opt.sql);
    }
  }

  console.log("✨ All optimizations applied successfully.");
} catch (error) {
  console.error("❌ Optimization failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
