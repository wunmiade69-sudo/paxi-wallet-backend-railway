import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const [columns] = await connection.query(
    "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assetMarketData'",
  ) as [{ COLUMN_NAME: string }[], unknown];
  const existing = new Set(columns.map((column) => column.COLUMN_NAME));
  const additions: Array<[string, string]> = [
    ["confidence", "varchar(8) NULL"],
    ["providerSources", "varchar(255) NULL"],
    ["sourceUpdatedAt", "timestamp NULL"],
    ["isStale", "boolean NOT NULL DEFAULT false"],
  ];
  for (const [name, definition] of additions) {
    if (!existing.has(name)) await connection.query(`ALTER TABLE assetMarketData ADD COLUMN \`${name}\` ${definition}`);
  }
  console.log("Provider provenance columns applied");
} finally {
  connection.destroy();
}
