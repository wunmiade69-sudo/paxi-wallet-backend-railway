import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");
const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });

try {
  const constraints = [
    {
      table: "tokenListings",
      name: "tokenListings_submittedByOpenId_users_fk",
      sql: "ALTER TABLE `tokenListings` ADD CONSTRAINT `tokenListings_submittedByOpenId_users_fk` FOREIGN KEY (`submittedByOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT",
    },
    {
      table: "campaigns",
      name: "campaigns_createdByOpenId_users_fk",
      sql: "ALTER TABLE `campaigns` ADD CONSTRAINT `campaigns_createdByOpenId_users_fk` FOREIGN KEY (`createdByOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT",
    },
    {
      table: "campaignEntries",
      name: "campaignEntries_userOpenId_users_fk",
      sql: "ALTER TABLE `campaignEntries` ADD CONSTRAINT `campaignEntries_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT",
    },
  ];

  for (const constraint of constraints) {
    const [rows] = await connection.query(
      "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?",
      [constraint.table, constraint.name],
    );
    if ((rows as unknown[]).length > 0) {
      console.log(`✅ Constraint ${constraint.name} already exists`);
    } else {
      await connection.query(constraint.sql);
      console.log(`✅ Added constraint ${constraint.name}`);
    }
  }
} catch (error) {
  console.error("❌ Reference constraint deployment failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
