import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
type QueryRow = Record<string, unknown>;

async function indexExists(table: string, index: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?",
    [table, index],
  );
  return rows.length > 0;
}

async function constraintExists(table: string, constraint: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?",
    [table, constraint],
  );
  return rows.length > 0;
}

async function columnExists(table: string, column: string): Promise<boolean> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [table, column],
  );
  return rows.length > 0;
}

async function addColumn(table: string, column: string, definition: string): Promise<void> {
  if (await columnExists(table, column)) return;
  await connection.query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
}

async function columnType(table: string, column: string): Promise<string> {
  const [rows] = await connection.query<QueryRow[]>(
    "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [table, column],
  );
  return String(rows[0]?.COLUMN_TYPE ?? "");
}

async function createIndex(table: string, name: string, statement: string): Promise<void> {
  if (await indexExists(table, name)) return;
  await connection.query(statement);
}

async function addForeignKey(table: string, name: string, statement: string): Promise<void> {
  if (await constraintExists(table, name)) return;
  await connection.query(statement);
}

try {
  console.log("Applying PAXI rewards and eligibility schema...");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`referralProfiles\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`inviteCode\` VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`rewardWalletAddress\` VARCHAR(128) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`referralProfiles_user_idx\` (\`userOpenId\`),
      UNIQUE KEY \`referralProfiles_code_idx\` (\`inviteCode\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`referrals\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`inviterOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`inviteeOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`inviteCode\` VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`rewardWalletAddress\` VARCHAR(128) NULL,
      \`status\` ENUM('pending','qualified','rejected','cancelled') NOT NULL DEFAULT 'pending',
      \`qualifiedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`referrals_invitee_idx\` (\`inviteeOpenId\`),
      UNIQUE KEY \`referrals_inviter_invitee_idx\` (\`inviterOpenId\`,\`inviteeOpenId\`),
      KEY \`referrals_inviter_created_idx\` (\`inviterOpenId\`,\`createdAt\`),
      KEY \`referrals_invite_code_idx\` (\`inviteCode\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`rewardLedger\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`sourceType\` ENUM('referral','gift_code','airdrop','campaign','manual_adjustment') NOT NULL,
      \`sourceId\` VARCHAR(128) NOT NULL,
      \`assetSymbol\` VARCHAR(32) NOT NULL,
      \`assetNetwork\` VARCHAR(32) NOT NULL,
      \`assetContractAddress\` VARCHAR(128) NULL,
      \`amount\` VARCHAR(128) NOT NULL,
      \`status\` ENUM('pending','approved','distributed','reversed','failed') NOT NULL DEFAULT 'pending',
      \`idempotencyKey\` VARCHAR(191) NOT NULL,
      \`metadata\` JSON NULL,
      \`approvedAt\` TIMESTAMP(3) NULL,
      \`distributedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`rewardLedger_idempotency_idx\` (\`idempotencyKey\`),
      KEY \`rewardLedger_user_created_idx\` (\`userOpenId\`,\`createdAt\`),
      KEY \`rewardLedger_source_idx\` (\`sourceType\`,\`sourceId\`),
      KEY \`rewardLedger_status_created_idx\` (\`status\`,\`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`giftCodes\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`codeHash\` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`codeHint\` VARCHAR(16) NOT NULL,
      \`assetSymbol\` VARCHAR(32) NOT NULL,
      \`assetNetwork\` VARCHAR(32) NOT NULL,
      \`assetContractAddress\` VARCHAR(128) NULL,
      \`rewardAmount\` VARCHAR(128) NOT NULL,
      \`maxRedemptions\` INT NOT NULL,
      \`redemptionCount\` INT NOT NULL DEFAULT 0,
      \`expiresAt\` TIMESTAMP(3) NULL,
      \`status\` ENUM('active','paused','exhausted','expired','cancelled') NOT NULL DEFAULT 'active',
      \`createdByOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`giftCodes_code_hash_idx\` (\`codeHash\`),
      KEY \`giftCodes_status_expiry_idx\` (\`status\`,\`expiresAt\`),
      KEY \`giftCodes_creator_created_idx\` (\`createdByOpenId\`,\`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`giftCodeRedemptions\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`giftCodeId\` INT NOT NULL,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`rewardLedgerId\` BIGINT UNSIGNED NULL,
      \`status\` ENUM('pending','credited','rejected','reversed') NOT NULL DEFAULT 'pending',
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`giftCodeRedemptions_code_user_idx\` (\`giftCodeId\`,\`userOpenId\`),
      UNIQUE KEY \`giftCodeRedemptions_ledger_idx\` (\`rewardLedgerId\`),
      KEY \`giftCodeRedemptions_code_status_idx\` (\`giftCodeId\`,\`status\`),
      KEY \`giftCodeRedemptions_user_created_idx\` (\`userOpenId\`,\`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaignRequirements\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`campaignId\` INT NOT NULL,
      \`requirementKey\` VARCHAR(64) NOT NULL,
      \`label\` VARCHAR(160) NOT NULL,
      \`requirementType\` ENUM('active_days','event_count','volume_usd','chain_used','operation_used','external_score') NOT NULL,
      \`threshold\` VARCHAR(128) NOT NULL,
      \`points\` INT NOT NULL DEFAULT 1,
      \`sortOrder\` INT NOT NULL DEFAULT 0,
      \`isActive\` TINYINT(1) NOT NULL DEFAULT 1,
      \`config\` JSON NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`campaignRequirements_campaign_key_idx\` (\`campaignId\`,\`requirementKey\`),
      KEY \`campaignRequirements_campaign_order_idx\` (\`campaignId\`,\`sortOrder\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`eligibilityResults\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`snapshotId\` INT NOT NULL,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`totalRequirements\` INT NOT NULL DEFAULT 10,
      \`metRequirements\` INT NOT NULL DEFAULT 0,
      \`minimumThreshold\` INT NOT NULL DEFAULT 5,
      \`highestThreshold\` INT NOT NULL DEFAULT 10,
      \`payoutMultiplier\` VARCHAR(32) NOT NULL DEFAULT '0',
      \`requirementResults\` JSON NOT NULL,
      \`externalScore\` INT NULL,
      \`tier\` ENUM('not_qualified','minimum','highest') NOT NULL DEFAULT 'not_qualified',
      \`status\` ENUM('calculated','reviewed','approved','rejected') NOT NULL DEFAULT 'calculated',
      \`calculatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`reviewedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`eligibilityResults_snapshot_user_idx\` (\`snapshotId\`,\`userOpenId\`),
      KEY \`eligibilityResults_snapshot_tier_idx\` (\`snapshotId\`,\`tier\`),
      KEY \`eligibilityResults_user_created_idx\` (\`userOpenId\`,\`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`campaignTierMultipliers\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`campaignId\` INT NOT NULL,
      \`tier\` ENUM('minimum','highest') NOT NULL,
      \`multiplier\` VARCHAR(32) NOT NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`campaignTierMultipliers_campaign_tier_idx\` (\`campaignId\`,\`tier\`),
      KEY \`campaignTierMultipliers_campaign_idx\` (\`campaignId\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`airdropDistributions\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`campaignId\` INT NULL,
      \`snapshotId\` INT NULL,
      \`assetSymbol\` VARCHAR(32) NOT NULL,
      \`assetNetwork\` VARCHAR(32) NOT NULL,
      \`assetContractAddress\` VARCHAR(128) NULL,
      \`totalAmount\` VARCHAR(128) NOT NULL,
      \`allocatedAmount\` VARCHAR(128) NOT NULL DEFAULT '0',
      \`distributedAmount\` VARCHAR(128) NOT NULL DEFAULT '0',
      \`status\` ENUM('draft','allocated','review','approved','distributing','complete','cancelled') NOT NULL DEFAULT 'draft',
      \`createdByOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`approvedByOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
      \`distributionTxHash\` VARCHAR(128) NULL,
      \`approvedAt\` TIMESTAMP(3) NULL,
      \`distributedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`airdropDistributions_snapshot_idx\` (\`snapshotId\`),
      KEY \`airdropDistributions_status_created_idx\` (\`status\`,\`createdAt\`),
      KEY \`airdropDistributions_campaign_idx\` (\`campaignId\`,\`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`airdropAllocations\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`distributionId\` INT NOT NULL,
      \`eligibilityResultId\` BIGINT UNSIGNED NULL,
      \`rewardLedgerId\` BIGINT UNSIGNED NULL,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`amount\` VARCHAR(128) NOT NULL,
      \`tier\` ENUM('minimum','highest') NOT NULL,
      \`status\` ENUM('pending','approved','distributed','failed','cancelled') NOT NULL DEFAULT 'pending',
      \`distributionTxHash\` VARCHAR(128) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`airdropAllocations_distribution_user_idx\` (\`distributionId\`,\`userOpenId\`),
      UNIQUE KEY \`airdropAllocations_ledger_idx\` (\`rewardLedgerId\`),
      KEY \`airdropAllocations_status_idx\` (\`distributionId\`,\`status\`),
      KEY \`airdropAllocations_user_created_idx\` (\`userOpenId\`,\`createdAt\`),
      UNIQUE KEY \`airdropAllocations_tx_hash_idx\` (\`distributionTxHash\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`rewardPolicies\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`policyKey\` VARCHAR(64) NOT NULL,
      \`network\` VARCHAR(32) NOT NULL,
      \`qualifyingAssetSymbol\` VARCHAR(32) NOT NULL,
      \`qualifyingAssetAddress\` VARCHAR(128) NULL,
      \`minimumVolumeUsd\` VARCHAR(32) NOT NULL,
      \`rewardAssetSymbol\` VARCHAR(32) NOT NULL,
      \`rewardAssetNetwork\` VARCHAR(32) NOT NULL,
      \`rewardAmount\` VARCHAR(64) NOT NULL,
      \`minimumTradeUsd\` VARCHAR(32) NOT NULL DEFAULT '0',
      \`cooldownSeconds\` INT NOT NULL DEFAULT 0,
      \`isActive\` TINYINT(1) NOT NULL DEFAULT 0,
      \`config\` JSON NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`rewardPolicies_policy_key_idx\` (\`policyKey\`),
      KEY \`rewardPolicies_active_network_idx\` (\`isActive\`,\`network\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    INSERT INTO \`rewardPolicies\` (\`policyKey\`, \`network\`, \`qualifyingAssetSymbol\`, \`minimumVolumeUsd\`, \`rewardAssetSymbol\`, \`rewardAssetNetwork\`, \`rewardAmount\`, \`minimumTradeUsd\`, \`cooldownSeconds\`, \`isActive\`, \`config\`)
    VALUES ('bsc-paxi-trading-referral-v1', 'bsc', 'PAXI', '20', 'WPAXI', 'bsc', '150', '0', 0, 0, JSON_OBJECT('qualifyingEventTypes', JSON_ARRAY('buy','sell'), 'excludedEventTypes', JSON_ARRAY('send','receive','deposit','withdrawal','bridge'), 'activationRequiresVerifiedTokenAddress', true, 'activationRequiresVerifiedRewardPools', true, 'trustedRouterAddresses', JSON_ARRAY(), 'trustedPairAddresses', JSON_ARRAY()))
    ON DUPLICATE KEY UPDATE \`policyKey\` = VALUES(\`policyKey\`)
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`referralTradingVolume\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`referralId\` BIGINT UNSIGNED NOT NULL,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`transactionHash\` VARCHAR(128) NOT NULL,
      \`eventType\` ENUM('buy','sell') NOT NULL,
      \`network\` VARCHAR(32) NOT NULL,
      \`pairAddress\` VARCHAR(128) NULL,
      \`qualifyingAssetAddress\` VARCHAR(128) NULL,
      \`volumeUsd\` VARCHAR(32) NOT NULL,
      \`verified\` TINYINT(1) NOT NULL DEFAULT 0,
      \`riskStatus\` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      \`riskFlags\` JSON NULL,
      \`blockNumber\` BIGINT UNSIGNED NULL,
      \`verifiedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`referralTradingVolume_tx_event_idx\` (\`transactionHash\`,\`eventType\`),
      KEY \`referralTradingVolume_referral_created_idx\` (\`referralId\`,\`createdAt\`),
      KEY \`referralTradingVolume_user_created_idx\` (\`userOpenId\`,\`createdAt\`),
      KEY \`referralTradingVolume_verification_idx\` (\`verified\`,\`riskStatus\`,\`createdAt\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`rewardPools\` (
      \`id\` INT NOT NULL AUTO_INCREMENT,
      \`policyId\` INT NOT NULL,
      \`chainId\` VARCHAR(32) NOT NULL,
      \`tokenAddress\` VARCHAR(128) NOT NULL,
      \`distributorAddress\` VARCHAR(128) NULL,
      \`tokenSymbol\` VARCHAR(32) NOT NULL,
      \`tokenDecimals\` INT NOT NULL,
      \`totalAllocation\` VARCHAR(128) NOT NULL,
      \`allocatedAmount\` VARCHAR(128) NOT NULL DEFAULT '0',
      \`remainingAmount\` VARCHAR(128) NOT NULL,
      \`status\` ENUM('reserve','active','exhausted','paused','invalid') NOT NULL DEFAULT 'reserve',
      \`priority\` INT NOT NULL,
      \`verified\` TINYINT(1) NOT NULL DEFAULT 0,
      \`verificationData\` JSON NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`rewardPools_policy_priority_idx\` (\`policyId\`,\`priority\`),
      UNIQUE KEY \`rewardPools_chain_token_idx\` (\`chainId\`,\`tokenAddress\`),
      KEY \`rewardPools_status_priority_idx\` (\`policyId\`,\`status\`,\`priority\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`rewardClaims\` (
      \`id\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \`rewardLedgerId\` BIGINT UNSIGNED NOT NULL,
      \`userOpenId\` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`recipientWalletAddress\` VARCHAR(128) NOT NULL,
      \`poolId\` INT NULL,
      \`tokenAddress\` VARCHAR(128) NOT NULL,
      \`amount\` VARCHAR(128) NOT NULL,
      \`status\` ENUM('pending','claimable','claimed','failed','cancelled') NOT NULL DEFAULT 'pending',
      \`claimIdempotencyKey\` VARCHAR(191) NOT NULL,
      \`txHash\` VARCHAR(128) NULL,
      \`claimedAt\` TIMESTAMP(3) NULL,
      \`createdAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`rewardClaims_reward_idx\` (\`rewardLedgerId\`),
      UNIQUE KEY \`rewardClaims_idempotency_idx\` (\`claimIdempotencyKey\`),
      KEY \`rewardClaims_user_status_idx\` (\`userOpenId\`,\`status\`,\`createdAt\`),
      UNIQUE KEY \`rewardClaims_tx_hash_idx\` (\`txHash\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
  `);

  await addColumn("eligibilityResults", "payoutMultiplier", "VARCHAR(32) NOT NULL DEFAULT '0' AFTER `highestThreshold`");
  await addColumn("referralProfiles", "rewardWalletAddress", "VARCHAR(128) NULL AFTER `inviteCode`");
  await addColumn("referrals", "rewardWalletAddress", "VARCHAR(128) NULL AFTER `inviteCode`");
  await addColumn("referrals", "qualifyingVolumeUsd", "VARCHAR(32) NOT NULL DEFAULT '0' AFTER `status`");
  await addColumn("referrals", "rewardLedgerId", "BIGINT UNSIGNED NULL AFTER `qualifyingVolumeUsd`");
  await addColumn("rewardPools", "distributorAddress", "VARCHAR(128) NULL AFTER `tokenAddress`");
  await addColumn("rewardClaims", "recipientWalletAddress", "VARCHAR(128) NOT NULL DEFAULT '' AFTER `userOpenId`");
  const rewardLedgerType = await columnType("rewardLedger", "status");
  if (rewardLedgerType && !rewardLedgerType.includes("claimable")) {
    await connection.query("ALTER TABLE `rewardLedger` MODIFY COLUMN `status` ENUM('pending','claimable','claimed','approved','distributed','reversed','failed') NOT NULL DEFAULT 'pending'");
  }
  await addColumn("rewardLedger", "claimableAt", "TIMESTAMP(3) NULL AFTER `approvedAt`");
  await addColumn("rewardLedger", "claimedAt", "TIMESTAMP(3) NULL AFTER `claimableAt`");

  await createIndex("referrals", "referrals_inviter_created_idx", "CREATE INDEX `referrals_inviter_created_idx` ON `referrals` (`inviterOpenId`,`createdAt`)");
  await createIndex("campaignTierMultipliers", "campaignTierMultipliers_campaign_tier_idx", "CREATE UNIQUE INDEX `campaignTierMultipliers_campaign_tier_idx` ON `campaignTierMultipliers` (`campaignId`,`tier`)");
  await createIndex("campaignTierMultipliers", "campaignTierMultipliers_campaign_idx", "CREATE INDEX `campaignTierMultipliers_campaign_idx` ON `campaignTierMultipliers` (`campaignId`)");
  await createIndex("referrals", "referrals_reward_ledger_idx", "CREATE UNIQUE INDEX `referrals_reward_ledger_idx` ON `referrals` (`rewardLedgerId`)");
  await createIndex("rewardLedger", "rewardLedger_user_created_idx", "CREATE INDEX `rewardLedger_user_created_idx` ON `rewardLedger` (`userOpenId`,`createdAt`)");
  await createIndex("rewardLedger", "rewardLedger_source_idx", "CREATE INDEX `rewardLedger_source_idx` ON `rewardLedger` (`sourceType`,`sourceId`)");
  await createIndex("rewardLedger", "rewardLedger_status_created_idx", "CREATE INDEX `rewardLedger_status_created_idx` ON `rewardLedger` (`status`,`createdAt`)");
  await createIndex("rewardPolicies", "rewardPolicies_policy_key_idx", "CREATE UNIQUE INDEX `rewardPolicies_policy_key_idx` ON `rewardPolicies` (`policyKey`)");
  await createIndex("rewardPolicies", "rewardPolicies_active_network_idx", "CREATE INDEX `rewardPolicies_active_network_idx` ON `rewardPolicies` (`isActive`,`network`)");
  await createIndex("referralTradingVolume", "referralTradingVolume_tx_event_idx", "CREATE UNIQUE INDEX `referralTradingVolume_tx_event_idx` ON `referralTradingVolume` (`transactionHash`,`eventType`)");
  await createIndex("referralTradingVolume", "referralTradingVolume_referral_created_idx", "CREATE INDEX `referralTradingVolume_referral_created_idx` ON `referralTradingVolume` (`referralId`,`createdAt`)");
  await createIndex("referralTradingVolume", "referralTradingVolume_user_created_idx", "CREATE INDEX `referralTradingVolume_user_created_idx` ON `referralTradingVolume` (`userOpenId`,`createdAt`)");
  await createIndex("referralTradingVolume", "referralTradingVolume_verification_idx", "CREATE INDEX `referralTradingVolume_verification_idx` ON `referralTradingVolume` (`verified`,`riskStatus`,`createdAt`)");
  await createIndex("rewardPools", "rewardPools_policy_priority_idx", "CREATE UNIQUE INDEX `rewardPools_policy_priority_idx` ON `rewardPools` (`policyId`,`priority`)");
  await createIndex("rewardPools", "rewardPools_chain_token_idx", "CREATE UNIQUE INDEX `rewardPools_chain_token_idx` ON `rewardPools` (`chainId`,`tokenAddress`)");
  await createIndex("rewardPools", "rewardPools_status_priority_idx", "CREATE INDEX `rewardPools_status_priority_idx` ON `rewardPools` (`policyId`,`status`,`priority`)");
  await createIndex("rewardClaims", "rewardClaims_reward_idx", "CREATE UNIQUE INDEX `rewardClaims_reward_idx` ON `rewardClaims` (`rewardLedgerId`)");
  await createIndex("rewardClaims", "rewardClaims_idempotency_idx", "CREATE UNIQUE INDEX `rewardClaims_idempotency_idx` ON `rewardClaims` (`claimIdempotencyKey`)");
  await createIndex("rewardClaims", "rewardClaims_user_status_idx", "CREATE INDEX `rewardClaims_user_status_idx` ON `rewardClaims` (`userOpenId`,`status`,`createdAt`)");
  await createIndex("rewardClaims", "rewardClaims_tx_hash_idx", "CREATE UNIQUE INDEX `rewardClaims_tx_hash_idx` ON `rewardClaims` (`txHash`)");

  await addForeignKey("referralProfiles", "referralProfiles_userOpenId_users_fk", "ALTER TABLE `referralProfiles` ADD CONSTRAINT `referralProfiles_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("referrals", "referrals_inviterOpenId_users_fk", "ALTER TABLE `referrals` ADD CONSTRAINT `referrals_inviterOpenId_users_fk` FOREIGN KEY (`inviterOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("referrals", "referrals_inviteeOpenId_users_fk", "ALTER TABLE `referrals` ADD CONSTRAINT `referrals_inviteeOpenId_users_fk` FOREIGN KEY (`inviteeOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("referrals", "referrals_rewardLedgerId_rewardLedger_fk", "ALTER TABLE `referrals` ADD CONSTRAINT `referrals_rewardLedgerId_rewardLedger_fk` FOREIGN KEY (`rewardLedgerId`) REFERENCES `rewardLedger` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("rewardLedger", "rewardLedger_userOpenId_users_fk", "ALTER TABLE `rewardLedger` ADD CONSTRAINT `rewardLedger_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("giftCodes", "giftCodes_createdByOpenId_users_fk", "ALTER TABLE `giftCodes` ADD CONSTRAINT `giftCodes_createdByOpenId_users_fk` FOREIGN KEY (`createdByOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("giftCodeRedemptions", "giftCodeRedemptions_giftCodeId_giftCodes_fk", "ALTER TABLE `giftCodeRedemptions` ADD CONSTRAINT `giftCodeRedemptions_giftCodeId_giftCodes_fk` FOREIGN KEY (`giftCodeId`) REFERENCES `giftCodes` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("giftCodeRedemptions", "giftCodeRedemptions_userOpenId_users_fk", "ALTER TABLE `giftCodeRedemptions` ADD CONSTRAINT `giftCodeRedemptions_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("giftCodeRedemptions", "giftCodeRedemptions_rewardLedgerId_rewardLedger_fk", "ALTER TABLE `giftCodeRedemptions` ADD CONSTRAINT `giftCodeRedemptions_rewardLedgerId_rewardLedger_fk` FOREIGN KEY (`rewardLedgerId`) REFERENCES `rewardLedger` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("campaignRequirements", "campaignRequirements_campaignId_campaigns_fk", "ALTER TABLE `campaignRequirements` ADD CONSTRAINT `campaignRequirements_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`) ON UPDATE CASCADE ON DELETE CASCADE");
  await addForeignKey("eligibilityResults", "eligibilityResults_snapshotId_campaignSnapshots_fk", "ALTER TABLE `eligibilityResults` ADD CONSTRAINT `eligibilityResults_snapshotId_campaignSnapshots_fk` FOREIGN KEY (`snapshotId`) REFERENCES `campaignSnapshots` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("eligibilityResults", "eligibilityResults_userOpenId_users_fk", "ALTER TABLE `eligibilityResults` ADD CONSTRAINT `eligibilityResults_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("campaignTierMultipliers", "campaignTierMultipliers_campaignId_campaigns_fk", "ALTER TABLE `campaignTierMultipliers` ADD CONSTRAINT `campaignTierMultipliers_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`) ON UPDATE CASCADE ON DELETE CASCADE");
  await addForeignKey("airdropDistributions", "airdropDistributions_campaignId_campaigns_fk", "ALTER TABLE `airdropDistributions` ADD CONSTRAINT `airdropDistributions_campaignId_campaigns_fk` FOREIGN KEY (`campaignId`) REFERENCES `campaigns` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("airdropDistributions", "airdropDistributions_snapshotId_campaignSnapshots_fk", "ALTER TABLE `airdropDistributions` ADD CONSTRAINT `airdropDistributions_snapshotId_campaignSnapshots_fk` FOREIGN KEY (`snapshotId`) REFERENCES `campaignSnapshots` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("airdropDistributions", "airdropDistributions_createdByOpenId_users_fk", "ALTER TABLE `airdropDistributions` ADD CONSTRAINT `airdropDistributions_createdByOpenId_users_fk` FOREIGN KEY (`createdByOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("airdropDistributions", "airdropDistributions_approvedByOpenId_users_fk", "ALTER TABLE `airdropDistributions` ADD CONSTRAINT `airdropDistributions_approvedByOpenId_users_fk` FOREIGN KEY (`approvedByOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("airdropAllocations", "airdropAllocations_distributionId_airdropDistributions_fk", "ALTER TABLE `airdropAllocations` ADD CONSTRAINT `airdropAllocations_distributionId_airdropDistributions_fk` FOREIGN KEY (`distributionId`) REFERENCES `airdropDistributions` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("airdropAllocations", "airdropAllocations_eligibilityResultId_eligibilityResults_fk", "ALTER TABLE `airdropAllocations` ADD CONSTRAINT `airdropAllocations_eligibilityResultId_eligibilityResults_fk` FOREIGN KEY (`eligibilityResultId`) REFERENCES `eligibilityResults` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("airdropAllocations", "airdropAllocations_rewardLedgerId_rewardLedger_fk", "ALTER TABLE `airdropAllocations` ADD CONSTRAINT `airdropAllocations_rewardLedgerId_rewardLedger_fk` FOREIGN KEY (`rewardLedgerId`) REFERENCES `rewardLedger` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");
  await addForeignKey("airdropAllocations", "airdropAllocations_userOpenId_users_fk", "ALTER TABLE `airdropAllocations` ADD CONSTRAINT `airdropAllocations_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("rewardPools", "rewardPools_policyId_rewardPolicies_fk", "ALTER TABLE `rewardPools` ADD CONSTRAINT `rewardPools_policyId_rewardPolicies_fk` FOREIGN KEY (`policyId`) REFERENCES `rewardPolicies` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("referralTradingVolume", "referralTradingVolume_referralId_referrals_fk", "ALTER TABLE `referralTradingVolume` ADD CONSTRAINT `referralTradingVolume_referralId_referrals_fk` FOREIGN KEY (`referralId`) REFERENCES `referrals` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("referralTradingVolume", "referralTradingVolume_userOpenId_users_fk", "ALTER TABLE `referralTradingVolume` ADD CONSTRAINT `referralTradingVolume_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("rewardClaims", "rewardClaims_rewardLedgerId_rewardLedger_fk", "ALTER TABLE `rewardClaims` ADD CONSTRAINT `rewardClaims_rewardLedgerId_rewardLedger_fk` FOREIGN KEY (`rewardLedgerId`) REFERENCES `rewardLedger` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("rewardClaims", "rewardClaims_userOpenId_users_fk", "ALTER TABLE `rewardClaims` ADD CONSTRAINT `rewardClaims_userOpenId_users_fk` FOREIGN KEY (`userOpenId`) REFERENCES `users` (`openId`) ON UPDATE CASCADE ON DELETE RESTRICT");
  await addForeignKey("rewardClaims", "rewardClaims_poolId_rewardPools_fk", "ALTER TABLE `rewardClaims` ADD CONSTRAINT `rewardClaims_poolId_rewardPools_fk` FOREIGN KEY (`poolId`) REFERENCES `rewardPools` (`id`) ON UPDATE CASCADE ON DELETE SET NULL");

  console.log("Rewards, referrals, eligibility, and airdrop schema is ready.");
} catch (error) {
  console.error("Rewards schema deployment failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
