import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const [partitionRows] = await connection.query(
    "SELECT TABLE_NAME, PARTITION_NAME FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('marketSnapshots','candles') GROUP BY TABLE_NAME, PARTITION_NAME",
  ) as [{ TABLE_NAME: string; PARTITION_NAME: string | null }[], unknown];
  const partitioned = new Set(partitionRows.filter((row) => row.PARTITION_NAME).map((row) => row.TABLE_NAME));
  const [constraintRows] = await connection.query(
    "SELECT TABLE_NAME, CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME IN ('marketSnapshots','candles') AND CONSTRAINT_TYPE = 'FOREIGN KEY'",
  ) as [{ TABLE_NAME: string; CONSTRAINT_NAME: string }[], unknown];
  const constraints = new Set(constraintRows.map((row) => `${row.TABLE_NAME}:${row.CONSTRAINT_NAME}`));
  const alter = (table: string) => `ALTER TABLE \`${table}\` DROP PRIMARY KEY, ADD PRIMARY KEY (\`id\`, \`timestamp\`) PARTITION BY RANGE (UNIX_TIMESTAMP(\`timestamp\`)) (PARTITION p_before_2026 VALUES LESS THAN (1767225600), PARTITION p_2026 VALUES LESS THAN (1798761600), PARTITION p_2027 VALUES LESS THAN (1830297600), PARTITION p_future VALUES LESS THAN (MAXVALUE))`;

  for (const table of ["marketSnapshots", "candles"]) {
    if (partitioned.has(table)) continue;
    const foreignKey = `${table}:${table}_assetId_assets_id_fk`;
    if (constraints.has(foreignKey)) await connection.query(`ALTER TABLE \`${table}\` DROP FOREIGN KEY \`${table}_assetId_assets_id_fk\``);
    await connection.query(alter(table));
  }
  console.log("Scale partitioning applied");
} finally {
  connection.destroy();
}
