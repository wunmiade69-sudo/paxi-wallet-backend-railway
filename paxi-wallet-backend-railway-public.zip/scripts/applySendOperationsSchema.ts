import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  await connection.query(`
    CREATE TABLE IF NOT EXISTS \\`sendOperations\\` (
      \\`id\\` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      \\`operationId\\` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \\`userOpenId\\` VARCHAR(64) NOT NULL,
      \\`linkedWalletAddress\\` VARCHAR(128) NOT NULL,
      \\`quoteId\\` VARCHAR(64) NOT NULL,
      \\`quoteFingerprint\\` VARCHAR(128) NOT NULL,
      \\`network\\` VARCHAR(32) NOT NULL,
      \\`assetIdentity\\` VARCHAR(160) NOT NULL,
      \\`contractAddress\\` VARCHAR(128) NULL,
      \\`recipientAddress\\` VARCHAR(128) NOT NULL,
      \\`transferAmount\\` VARCHAR(128) NOT NULL,
      \\`transferAmountUnits\\` VARCHAR(128) NOT NULL,
      \\`transferAmountUsd\\` VARCHAR(32) NOT NULL,
      \\`paxiServiceFee\\` VARCHAR(128) NOT NULL,
      \\`paxiServiceFeeUnits\\` VARCHAR(128) NOT NULL,
      \\`paxiServiceFeeUsd\\` VARCHAR(32) NOT NULL,
      \\`networkFee\\` VARCHAR(128) NOT NULL,
      \\`networkFeeUsd\\` VARCHAR(32) NOT NULL,
      \\`totalWalletDebitUsd\\` VARCHAR(32) NOT NULL,
      \\`feeTransactionHash\\` VARCHAR(128) NULL,
      \\`sendTransactionHash\\` VARCHAR(128) NULL,
      \\`state\\` ENUM('QUOTED','FEE_BROADCAST','FEE_CONFIRMED','SEND_BROADCAST','CONFIRMED','FAILED','RECONCILIATION_REQUIRED') NOT NULL DEFAULT 'QUOTED',
      \\`failureCode\\` VARCHAR(64) NULL,
      \\`reconciliationCode\\` VARCHAR(64) NULL,
      \\`quoteExpiresAt\\` TIMESTAMP(3) NOT NULL,
      \\`confirmedAt\\` TIMESTAMP(3) NULL,
      \\`createdAt\\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \\`updatedAt\\` TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\\`id\\`),
      UNIQUE KEY \\`sendOperations_operation_unique\\` (\\`operationId\\`),
      UNIQUE KEY \\`sendOperations_fee_hash_unique\\` (\\`feeTransactionHash\\`),
      UNIQUE KEY \\`sendOperations_send_hash_unique\\` (\\`sendTransactionHash\\`),
      KEY \\`sendOperations_user_created_idx\\` (\\`userOpenId\\`,\\`createdAt\\`),
      KEY \\`sendOperations_quote_idx\\` (\\`quoteId\\`),
      KEY \\`sendOperations_state_updated_idx\\` (\\`state\\`,\\`updatedAt\\`),
      CONSTRAINT \\`sendOperations_user_fk\\` FOREIGN KEY (\\`userOpenId\\`) REFERENCES \\`users\\` (\\`openId\\`) ON UPDATE CASCADE ON DELETE RESTRICT,
      CONSTRAINT \\`sendOperations_quote_fk\\` FOREIGN KEY (\\`quoteId\\`) REFERENCES \\`sendFeeQuotes\\` (\\`id\\`) ON UPDATE CASCADE ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
  `);
  console.log("✅ sendOperations staging schema is ready");
} finally {
  await connection.end();
}
