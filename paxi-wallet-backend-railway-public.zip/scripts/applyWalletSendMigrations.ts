import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 10_000 });

async function tableExists(table: string): Promise<boolean> {
  const [rows] = await connection.query(
    "SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1",
    [table],
  );
  return (rows as unknown[]).length > 0;
}

async function columnExists(table: string, column: string): Promise<boolean> {
  const [rows] = await connection.query(
    "SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1",
    [table, column],
  );
  return (rows as unknown[]).length > 0;
}

async function indexExists(table: string, index: string): Promise<boolean> {
  const [rows] = await connection.query(
    "SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1",
    [table, index],
  );
  return (rows as unknown[]).length > 0;
}

async function addColumnIfMissing(table: string, column: string, definition: string): Promise<void> {
  if (!(await columnExists(table, column))) {
    await connection.query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
  }
}

async function addIndexIfMissing(table: string, index: string, definition: string): Promise<void> {
  if (!(await indexExists(table, index))) {
    await connection.query(`ALTER TABLE \`${table}\` ADD ${definition}`);
  }
}

try {
  if (!(await tableExists("users"))) throw new Error("users table is required before wallet/SEND migrations");
  if (!(await tableExists("activityEvents"))) throw new Error("activityEvents table is required before fee migrations");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`walletLinks\` (
      \`id\` varchar(36) NOT NULL,
      \`userOpenId\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`walletAddress\` varchar(128) NOT NULL,
      \`chainType\` varchar(16) NOT NULL,
      \`verifiedAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`createdAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`walletLinks_user_wallet_unique\` (\`userOpenId\`,\`walletAddress\`),
      KEY \`walletLinks_wallet_idx\` (\`walletAddress\`),
      CONSTRAINT \`walletLinks_user_fk\` FOREIGN KEY (\`userOpenId\`) REFERENCES \`users\` (\`openId\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin`);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`walletLinkChallenges\` (
      \`id\` varchar(36) NOT NULL,
      \`userOpenId\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`walletAddress\` varchar(128) NOT NULL,
      \`nonce\` varchar(64) NOT NULL,
      \`message\` text NOT NULL,
      \`expiresAt\` timestamp(3) NOT NULL,
      \`createdAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`walletLinkChallenges_nonce_unique\` (\`nonce\`),
      KEY \`walletLinkChallenges_lookup_idx\` (\`userOpenId\`,\`walletAddress\`,\`expiresAt\`),
      CONSTRAINT \`walletLinkChallenges_user_fk\` FOREIGN KEY (\`userOpenId\`) REFERENCES \`users\` (\`openId\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin`);

  const [feeConfigRows] = await connection.query<{ COLUMN_TYPE: string }[]>(
    "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'feeConfig' AND COLUMN_NAME = 'operation'",
  );
  if (feeConfigRows[0] && !feeConfigRows[0].COLUMN_TYPE.includes("'send'")) {
    await connection.query("ALTER TABLE `feeConfig` MODIFY COLUMN `operation` ENUM('send','swap_evm','swap_btc','bridge','create_token','listing') NOT NULL");
  }

  const [feeRecordRows] = await connection.query<{ COLUMN_TYPE: string }[]>(
    "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'feeRecords' AND COLUMN_NAME = 'operation'",
  );
  if (feeRecordRows[0] && !feeRecordRows[0].COLUMN_TYPE.includes("'send'")) {
    await connection.query("ALTER TABLE `feeRecords` MODIFY COLUMN `operation` ENUM('send','swap_evm','swap_btc','bridge','create_token','listing') NOT NULL");
  }
  await addColumnIfMissing("feeRecords", "operationId", "varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "walletAddress", "varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "asset", "varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "feeCurrency", "varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "feeAmount", "varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "assetDecimals", "int NULL");
  await addColumnIfMissing("feeRecords", "treasury", "varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "feeTransactionHash", "varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
  await addColumnIfMissing("feeRecords", "failureReason", "text NULL");
  await addIndexIfMissing("feeRecords", "feeRecords_user_operation_idx", "UNIQUE KEY `feeRecords_user_operation_idx` (`userOpenId`, `operationId`)");
  await addIndexIfMissing("feeRecords", "feeRecords_fee_transaction_hash_idx", "KEY `feeRecords_fee_transaction_hash_idx` (`feeTransactionHash`)");

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`feePaymentLedger\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT,
      \`transactionHash\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`userOpenId\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`product\` enum('send','listing','create_token','campaign') NOT NULL,
      \`operationKey\` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`network\` varchar(32) NOT NULL,
      \`payerWallet\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`treasury\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`asset\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`amount\` varchar(128) NOT NULL,
      \`status\` enum('claimed','released') NOT NULL DEFAULT 'claimed',
      \`createdAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`feePaymentLedger_transaction_hash_unique\` (\`transactionHash\`),
      UNIQUE KEY \`feePaymentLedger_product_operation_unique\` (\`product\`,\`operationKey\`),
      KEY \`feePaymentLedger_user_created_idx\` (\`userOpenId\`,\`createdAt\`),
      CONSTRAINT \`feePaymentLedger_user_fk\` FOREIGN KEY (\`userOpenId\`) REFERENCES \`users\` (\`openId\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin`);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`sendFeeQuotes\` (
      \`id\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`userOpenId\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`operationId\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`fingerprint\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`network\` varchar(32) NOT NULL,
      \`walletAddress\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`recipient\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`assetAddress\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`assetSymbol\` varchar(32) NOT NULL,
      \`assetDecimals\` int NOT NULL,
      \`amount\` varchar(128) NOT NULL,
      \`amountUsd\` varchar(32) NOT NULL,
      \`networkFeeNative\` varchar(128) NOT NULL,
      \`networkFeeUsd\` varchar(32) NOT NULL,
      \`paxiFeeAmountUnits\` varchar(128) NOT NULL,
      \`paxiFeeAmount\` varchar(128) NOT NULL,
      \`paxiFeeUsd\` varchar(32) NOT NULL,
      \`totalDebitUsd\` varchar(32) NOT NULL,
      \`feeCurrency\` varchar(32) NOT NULL,
      \`treasury\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`createdAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`expiresAt\` timestamp(3) NOT NULL,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`sendFeeQuotes_user_operation_idx\` (\`userOpenId\`,\`operationId\`),
      KEY \`sendFeeQuotes_fingerprint_idx\` (\`fingerprint\`),
      KEY \`sendFeeQuotes_user_created_idx\` (\`userOpenId\`,\`createdAt\`),
      CONSTRAINT \`sendFeeQuotes_user_fk\` FOREIGN KEY (\`userOpenId\`) REFERENCES \`users\` (\`openId\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin`);

  await connection.query(`
    CREATE TABLE IF NOT EXISTS \`sendOperations\` (
      \`id\` bigint unsigned NOT NULL AUTO_INCREMENT,
      \`operationId\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`userOpenId\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
      \`linkedWalletAddress\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`quoteId\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`quoteFingerprint\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`network\` varchar(32) NOT NULL,
      \`assetIdentity\` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`contractAddress\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`recipientAddress\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
      \`transferAmount\` varchar(128) NOT NULL,
      \`transferAmountUnits\` varchar(128) NOT NULL,
      \`transferAmountUsd\` varchar(32) NOT NULL,
      \`paxiServiceFee\` varchar(128) NOT NULL,
      \`paxiServiceFeeUnits\` varchar(128) NOT NULL,
      \`paxiServiceFeeUsd\` varchar(32) NOT NULL,
      \`networkFee\` varchar(128) NOT NULL,
      \`networkFeeUsd\` varchar(32) NOT NULL,
      \`totalWalletDebitUsd\` varchar(32) NOT NULL,
      \`feeTransactionHash\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`sendTransactionHash\` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`state\` enum('QUOTED','FEE_BROADCAST','FEE_CONFIRMED','SEND_BROADCAST','CONFIRMED','FAILED','RECONCILIATION_REQUIRED') NOT NULL DEFAULT 'QUOTED',
      \`failureCode\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`reconciliationCode\` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
      \`quoteExpiresAt\` timestamp(3) NOT NULL,
      \`confirmedAt\` timestamp(3) DEFAULT NULL,
      \`createdAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      \`updatedAt\` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`sendOperations_operation_unique\` (\`operationId\`),
      UNIQUE KEY \`sendOperations_fee_hash_unique\` (\`feeTransactionHash\`),
      UNIQUE KEY \`sendOperations_send_hash_unique\` (\`sendTransactionHash\`),
      KEY \`sendOperations_user_created_idx\` (\`userOpenId\`,\`createdAt\`),
      KEY \`sendOperations_quote_idx\` (\`quoteId\`),
      KEY \`sendOperations_state_updated_idx\` (\`state\`,\`updatedAt\`),
      CONSTRAINT \`sendOperations_user_fk\` FOREIGN KEY (\`userOpenId\`) REFERENCES \`users\` (\`openId\`) ON UPDATE CASCADE ON DELETE RESTRICT,
      CONSTRAINT \`sendOperations_quote_fk\` FOREIGN KEY (\`quoteId\`) REFERENCES \`sendFeeQuotes\` (\`id\`) ON UPDATE CASCADE ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin`);

  await connection.query(
    "INSERT INTO paxiSchemaDeployments (version, checksum) SELECT 'wallet-send-schema-v1', 'wallet-links-fees-quotes-ledger-send-operations' WHERE NOT EXISTS (SELECT 1 FROM paxiSchemaDeployments WHERE version = 'wallet-send-schema-v1')",
  );
  console.log("wallet/send migration complete");
} finally {
  await connection.end();
}
