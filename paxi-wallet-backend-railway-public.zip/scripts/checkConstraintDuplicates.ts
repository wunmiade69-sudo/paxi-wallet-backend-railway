import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");
const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const checks = [
    ["tokenListings.feeTxHash", "SELECT feeTxHash AS value, COUNT(*) AS count FROM tokenListings WHERE feeTxHash IS NOT NULL GROUP BY feeTxHash HAVING COUNT(*) > 1"],
    ["campaigns.poolFundedTxHash", "SELECT poolFundedTxHash AS value, COUNT(*) AS count FROM campaigns WHERE poolFundedTxHash IS NOT NULL GROUP BY poolFundedTxHash HAVING COUNT(*) > 1"],
    ["campaignEntries.proofTxHash", "SELECT proofTxHash AS value, COUNT(*) AS count FROM campaignEntries WHERE proofTxHash IS NOT NULL GROUP BY proofTxHash HAVING COUNT(*) > 1"],
    ["campaignEntries.payoutTxHash", "SELECT payoutTxHash AS value, COUNT(*) AS count FROM campaignEntries WHERE payoutTxHash IS NOT NULL GROUP BY payoutTxHash HAVING COUNT(*) > 1"],
  ] as const;
  let failures = 0;
  for (const [name, query] of checks) {
    const [rows] = await connection.query(query);
    const values = rows as Array<{ value: string; count: number }>;
    console.log(name, values.length === 0 ? "OK" : values);
    if (values.length > 0) failures++;
  }
  if (failures > 0) process.exitCode = 1;
} finally {
  connection.destroy();
}
