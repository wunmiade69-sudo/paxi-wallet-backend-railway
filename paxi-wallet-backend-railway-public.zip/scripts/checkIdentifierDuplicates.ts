import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");
const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const [rows] = await connection.query(`
    SELECT chainId, LOWER(identifier) AS normalizedIdentifier, COUNT(*) AS count,
           GROUP_CONCAT(identifier ORDER BY identifier SEPARATOR ',') AS identifiers
    FROM assets
    GROUP BY chainId, LOWER(identifier)
    HAVING COUNT(*) > 1
  `);
  console.log((rows as unknown[]).length === 0 ? "identifier collisions: OK" : rows);
  if ((rows as unknown[]).length > 0) process.exitCode = 1;
} finally {
  connection.destroy();
}
