import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const [tables] = await connection.query("SHOW TABLES LIKE '__drizzle_migrations'");
  console.log("migrationTablePresent", (tables as unknown[]).length > 0);
  if ((tables as unknown[]).length > 0) {
    const [rows] = await connection.query("SELECT hash, created_at FROM __drizzle_migrations ORDER BY created_at");
    console.table(rows);
  }
} finally {
  connection.destroy();
}
