import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");
const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });
try {
  const checks = [
    ["tokenListings.submittedByOpenId", "SELECT COUNT(*) AS count FROM tokenListings l LEFT JOIN users u ON u.openId = l.submittedByOpenId WHERE l.submittedByOpenId IS NOT NULL AND u.openId IS NULL"],
    ["campaigns.createdByOpenId", "SELECT COUNT(*) AS count FROM campaigns c LEFT JOIN users u ON u.openId = c.createdByOpenId WHERE u.openId IS NULL"],
    ["campaignEntries.userOpenId", "SELECT COUNT(*) AS count FROM campaignEntries e LEFT JOIN users u ON u.openId = e.userOpenId WHERE u.openId IS NULL"],
  ] as const;
  let failures = 0;
  for (const [name, query] of checks) {
    const [rows] = await connection.query(query);
    const count = Number((rows as Array<{ count: number }>)[0]?.count ?? 0);
    console.log(name, count === 0 ? "OK" : `ORPHANS=${count}`);
    if (count > 0) failures++;
  }
  if (failures > 0) process.exitCode = 1;
} finally {
  connection.destroy();
}
