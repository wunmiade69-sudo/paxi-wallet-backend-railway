import mysql from "mysql2/promise";
import { PAXI_BSC_ADDRESS, REFERRAL_MINIMUM_VOLUME_USD, WPAXI_POOL_ADDRESSES, WPAXI_POOL_ALLOCATION, WPAXI_REWARD_AMOUNT, WPAXI_TOKEN_DECIMALS } from "../server/rewards/wpaxiConfig";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");


const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });

type Row = { id: number; policyKey: string; qualifyingAssetAddress: string | null; minimumVolumeUsd: string; rewardAmount: string; isActive: number };

try {
  await connection.query(
    `INSERT INTO rewardPolicies (policyKey, network, qualifyingAssetSymbol, qualifyingAssetAddress, minimumVolumeUsd, rewardAssetSymbol, rewardAssetNetwork, rewardAmount, minimumTradeUsd, cooldownSeconds, isActive, config)
     VALUES (?, 'bsc', 'PAXI', ?, ?, 'WPAXI', 'bsc', ?, '0', 0, 0, JSON_OBJECT('qualifyingEventTypes', JSON_ARRAY('buy','sell'), 'excludedEventTypes', JSON_ARRAY('send','receive','deposit','withdrawal','bridge'), 'activationRequiresVerifiedTokenAddress', true, 'activationRequiresVerifiedRewardPools', true, 'trustedRouterAddresses', JSON_ARRAY(), 'trustedPairAddresses', JSON_ARRAY()))
     ON DUPLICATE KEY UPDATE qualifyingAssetAddress = VALUES(qualifyingAssetAddress), minimumVolumeUsd = VALUES(minimumVolumeUsd), rewardAmount = VALUES(rewardAmount), isActive = 0`,
    ["bsc-paxi-trading-referral-v1", PAXI_BSC_ADDRESS, REFERRAL_MINIMUM_VOLUME_USD, WPAXI_REWARD_AMOUNT],
  );
  const [policyRows] = await connection.query<Row[]>("SELECT id, policyKey, qualifyingAssetAddress, minimumVolumeUsd, rewardAmount, isActive FROM rewardPolicies WHERE policyKey = ? LIMIT 1", ["bsc-paxi-trading-referral-v1"]);
  const policy = policyRows[0];
  if (!policy) throw new Error("WPAXI referral policy was not persisted");

  const pools: Array<{ id: number; priority: number; tokenAddress: string; distributorAddress: string | null; totalAllocation: string; status: string; verified: number }> = [];
  for (const [index, tokenAddress] of WPAXI_POOL_ADDRESSES.entries()) {
    const priority = index + 1;
    const [existingRows] = await connection.query<Array<{ id: number; tokenAddress: string; distributorAddress: string | null; totalAllocation: string; status: string; verified: number }>>(
      "SELECT id, tokenAddress, distributorAddress, totalAllocation, status, verified FROM rewardPools WHERE policyId = ? AND priority = ? LIMIT 1",
      [policy.id, priority],
    );
    const existing = existingRows[0];
    if (existing) {
      if (existing.tokenAddress.toLowerCase() !== tokenAddress.toLowerCase() || existing.totalAllocation !== WPAXI_POOL_ALLOCATION) {
        throw new Error(`Existing WPAXI pool priority ${priority} does not match the confirmed address or allocation`);
      }
      pools.push({ id: existing.id, priority, tokenAddress: existing.tokenAddress, distributorAddress: existing.distributorAddress, totalAllocation: existing.totalAllocation, status: existing.status, verified: existing.verified });
      continue;
    }
    const [result] = await connection.query<{ insertId: number }>(
      `INSERT INTO rewardPools (policyId, chainId, tokenAddress, distributorAddress, tokenSymbol, tokenDecimals, totalAllocation, allocatedAmount, remainingAmount, status, priority, verified)
       VALUES (?, 'bsc', ?, NULL, 'WPAXI', ?, ?, '0', ?, 'reserve', ?, 0)`,
      [policy.id, tokenAddress, WPAXI_TOKEN_DECIMALS, WPAXI_POOL_ALLOCATION, WPAXI_POOL_ALLOCATION, priority],
    );
    pools.push({ id: Number(result.insertId), priority, tokenAddress, distributorAddress: null, totalAllocation: WPAXI_POOL_ALLOCATION, status: "reserve", verified: 0 });
  }

  console.log(JSON.stringify({
    policyId: policy.id,
    policyKey: policy.policyKey,
    qualifyingAssetAddress: policy.qualifyingAssetAddress,
    minimumVolumeUsd: policy.minimumVolumeUsd,
    rewardAmount: policy.rewardAmount,
    isActive: Boolean(policy.isActive),
    pools,
  }, null, 2));
} finally {
  connection.destroy();
}
