import { getDb } from "../server/db";
import { sql } from "drizzle-orm";

async function runTest() {
  console.log("🚀 Starting PAXI Wallet Database Regression Test...");
  const db = await getDb();
  if (!db) {
    console.error("❌ CRITICAL: Failed to connect to the database.");
    process.exit(1);
  }

  const results: any = {
    connection: "✅ Connected",
    tables: {},
    schema: {},
    partitioning: {},
    integrity: {},
    optimizations: {},
    constraints: {},
    primaryKeys: {},
    migrationLedger: {}
  };

  try {
    // 1. Check Tables
    const [tableRows] = await db.execute(sql`SHOW TABLES`);
    const tables = (tableRows as any[]).map(row => Object.values(row)[0]);
    const requiredTables = ["users", "assets", "assetMarketData", "candles", "liquidityPools", "markets", "marketSnapshots", "activityEvents", "feeConfig", "feeRecords", "tokenListings", "listingEvents", "campaigns", "campaignEntries", "campaignSnapshots", "campaignSnapshotParticipants", "referralProfiles", "referrals", "rewardLedger", "giftCodes", "giftCodeRedemptions", "campaignRequirements", "eligibilityResults", "campaignTierMultipliers", "airdropDistributions", "airdropAllocations", "paxiSchemaDeployments"];
    
    for (const table of requiredTables) {
      results.tables[table] = tables.includes(table) ? "✅ Present" : "❌ MISSING";
    }

    // 2. Check Provider Provenance Columns in assetMarketData
    const [columnRows] = await db.execute(sql`DESCRIBE assetMarketData`);
    const columns = (columnRows as any[]).map(row => row.Field);
    const newColumns = ["confidence", "providerSources", "sourceUpdatedAt", "isStale"];
    
    for (const col of newColumns) {
      results.schema[`assetMarketData.${col}`] = columns.includes(col) ? "✅ Present" : "❌ MISSING";
    }
    const [identifierMeta] = await db.execute(sql`SELECT COLLATION_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'assets' AND COLUMN_NAME = 'identifier'`);
    results.schema["assets.identifier.collation"] = (identifierMeta as any[])[0]?.COLLATION_NAME === "utf8mb4_bin" ? "✅ utf8mb4_bin" : `❌ ${(identifierMeta as any[])[0]?.COLLATION_NAME ?? "missing"}`;
    const activitySchemaChecks = [
      ["activityEvents", ["userOpenId", "walletAddress", "chainId", "eventType", "transactionHash", "amountUsd", "networkFeeUsd", "paxiFeeUsd", "verificationSource", "amountUsdSource", "status", "createdAt"]],
      ["feeConfig", ["operation", "chainType", "percentageBps", "fixedUsd", "isActive"]],
      ["feeRecords", ["activityEventId", "operation", "inputAmountUsd", "paxiFeeUsd", "networkFeeUsd", "totalFeeUsd", "status"]],
      ["tokenListings", ["contractAddress", "network", "status", "feeTxHash", "submittedByOpenId", "reviewedByOpenId"]],
      ["listingEvents", ["listingId", "eventType", "actorOpenId", "feeTxHash", "createdAt"]],
      ["campaigns", ["listingId", "bannerKey", "iconKey", "website", "socials", "poolRequiredAmountUsd", "poolFundedTxHash", "poolFundedAmountUsd", "isFeatured", "featuredAt", "claimsPaused", "status", "submittedAt", "reviewedAt", "reviewedByOpenId", "rejectionReason", "createdByOpenId"]],
      ["campaignEntries", ["campaignId", "userOpenId", "slotNumber", "proofTxHash", "payoutStatus", "claimRequestedAt"]],
      ["campaignSnapshots", ["campaignId", "snapshotDate", "status", "snapshotData", "frozenAt", "calculatedAt"]],
      ["campaignSnapshotParticipants", ["snapshotId", "userOpenId", "activeDays", "externalScore", "eligibilityTier", "requirements"]],
      ["referralProfiles", ["userOpenId", "inviteCode", "rewardWalletAddress", "createdAt"]],
      ["referrals", ["inviterOpenId", "inviteeOpenId", "inviteCode", "rewardWalletAddress", "status", "qualifyingVolumeUsd", "rewardLedgerId"]],
      ["rewardLedger", ["userOpenId", "sourceType", "sourceId", "amount", "status", "idempotencyKey", "claimableAt", "claimedAt"]],
      ["giftCodes", ["codeHash", "rewardAmount", "maxRedemptions", "redemptionCount", "status"]],
      ["giftCodeRedemptions", ["giftCodeId", "userOpenId", "rewardLedgerId", "status"]],
      ["campaignRequirements", ["campaignId", "requirementKey", "requirementType", "threshold", "isActive"]],
      ["eligibilityResults", ["snapshotId", "userOpenId", "totalRequirements", "metRequirements", "minimumThreshold", "highestThreshold", "payoutMultiplier", "tier"]],
      ["campaignTierMultipliers", ["campaignId", "tier", "multiplier", "createdAt"]],
      ["airdropDistributions", ["snapshotId", "totalAmount", "allocatedAmount", "distributedAmount", "status"]],
      ["airdropAllocations", ["distributionId", "eligibilityResultId", "rewardLedgerId", "userOpenId", "amount", "tier", "status"]],
      ["rewardPolicies", ["policyKey", "network", "qualifyingAssetSymbol", "minimumVolumeUsd", "rewardAssetSymbol", "rewardAmount", "isActive"]],
      ["referralTradingVolume", ["referralId", "userOpenId", "transactionHash", "eventType", "volumeUsd", "verified", "riskStatus"]],
      ["rewardPools", ["policyId", "chainId", "tokenAddress", "totalAllocation", "allocatedAmount", "remainingAmount", "status", "priority", "verified"]],
      ["rewardClaims", ["rewardLedgerId", "userOpenId", "recipientWalletAddress", "poolId", "tokenAddress", "amount", "status", "claimIdempotencyKey"]],
    ] as const;
    for (const [table, requiredColumns] of activitySchemaChecks) {
      const [rows] = await db.execute(sql`DESCRIBE ${sql.raw(table)}`);
      const present = new Set((rows as any[]).map((row) => row.Field));
      for (const column of requiredColumns) results.schema[`${table}.${column}`] = present.has(column) ? "✅ Present" : "❌ MISSING";
    }

    // 3. Check Partitioning
    const [partitionRows] = await db.execute(sql`
      SELECT TABLE_NAME, PARTITION_NAME, PARTITION_EXPRESSION, TABLE_ROWS
      FROM INFORMATION_SCHEMA.PARTITIONS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('candles', 'marketSnapshots')
    `);
    
    const partitions = partitionRows as any[];
    results.partitioning["candles"] = partitions.some(p => p.TABLE_NAME === 'candles' && p.PARTITION_NAME !== null) ? "✅ Partitioned" : "⚠️ Not Partitioned";
    results.partitioning["marketSnapshots"] = partitions.some(p => p.TABLE_NAME === 'marketSnapshots' && p.PARTITION_NAME !== null) ? "✅ Partitioned" : "⚠️ Not Partitioned";
    const [engineRows] = await db.execute(sql`SELECT TABLE_NAME, ENGINE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('candles','marketSnapshots')`);
    for (const row of engineRows as any[]) {
      results.partitioning[`${row.TABLE_NAME}.engine`] = row.ENGINE === "InnoDB" ? "✅ InnoDB" : `❌ ${row.ENGINE}`;
    }

    // 4. Verify partition-compatible composite primary keys.
    for (const table of ["candles", "marketSnapshots"]) {
      const [keyRows] = await db.execute(sql`
        SELECT COLUMN_NAME, SEQ_IN_INDEX
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ${table} AND INDEX_NAME = 'PRIMARY'
        ORDER BY SEQ_IN_INDEX
      `);
      const keyColumns = (keyRows as any[]).map((row) => row.COLUMN_NAME);
      results.primaryKeys[table] = keyColumns.join(",") === "id,timestamp" ? "✅ Composite (id,timestamp)" : `❌ ${keyColumns.join(",") || "missing"}`;
    }

    // 5. Data Integrity Counts
    const [userCount] = await db.execute(sql`SELECT COUNT(*) as count FROM users`);
    const [assetCount] = await db.execute(sql`SELECT COUNT(*) as count FROM assets`);
    const [marketCount] = await db.execute(sql`SELECT COUNT(*) as count FROM markets`);
    
    results.integrity["users"] = (userCount as any[])[0].count;
    results.integrity["assets"] = (assetCount as any[])[0].count;
    results.integrity["markets"] = (marketCount as any[])[0].count;
    const [activityCount] = await db.execute(sql`SELECT COUNT(*) as count FROM activityEvents`);
    const [feeConfigCount] = await db.execute(sql`SELECT COUNT(*) as count FROM feeConfig WHERE isActive = 1`);
    results.integrity["activityEvents"] = (activityCount as any[])[0].count;
    results.integrity["activeFeeConfig"] = (feeConfigCount as any[])[0].count;

    // 6. Check Optimizations (Indexes)
    const checkIndex = async (table: string, index: string) => {
      const [rows] = await db.execute(sql`SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ${table} AND INDEX_NAME = ${index}`);
      return (rows as any[]).length > 0;
    };

    const optimizationChecks = [
      { table: "assets", index: "assets_status_updated_idx" },
      { table: "assets", index: "assets_verification_status_idx" },
      { table: "markets", index: "markets_asset_status_updated_idx" },
      { table: "tokenListings", index: "tokenListings_status_created_idx" },
      { table: "campaigns", index: "campaigns_status_timeline_idx" },
      { table: "campaigns", index: "campaigns_featured_timeline_idx" },
      { table: "campaignEntries", index: "campaignEntries_user_created_idx" },
      { table: "tokenListings", index: "tokenListings_submitted_by_updated_idx" },
      { table: "tokenListings", index: "tokenListings_fee_tx_hash_idx" },
      { table: "listingEvents", index: "listingEvents_listing_created_idx" },
      { table: "campaigns", index: "campaigns_listing_updated_idx" },
      { table: "campaigns", index: "campaigns_created_by_idx" },
      { table: "campaigns", index: "campaigns_pool_funded_tx_hash_idx" },
      { table: "campaignEntries", index: "campaignEntries_proof_tx_hash_idx" },
      { table: "campaignEntries", index: "campaignEntries_payout_tx_hash_idx" },
      { table: "activityEvents", index: "activityEvents_user_created_idx" },
      { table: "activityEvents", index: "activityEvents_user_type_created_idx" },
      { table: "activityEvents", index: "activityEvents_transaction_hash_idx" },
      { table: "activityEvents", index: "activityEvents_chain_created_idx" },
      { table: "activityEvents", index: "activityEvents_user_id_idx" },
      { table: "activityEvents", index: "activityEvents_user_status_source_idx" },
      { table: "activityEvents", index: "activityEvents_user_wallet_tx_type_idx" },
      { table: "feeConfig", index: "feeConfig_operation_chain_idx" },
      { table: "feeRecords", index: "feeRecords_user_created_idx" },
      { table: "campaignSnapshots", index: "campaignSnapshots_campaign_date_idx" },
      { table: "campaignSnapshotParticipants", index: "campaignSnapshotParticipants_snapshot_user_idx" },
      { table: "campaignSnapshotParticipants", index: "campaignSnapshotParticipants_eligibility_idx" },
      { table: "referralProfiles", index: "referralProfiles_code_idx" },
      { table: "referrals", index: "referrals_invitee_idx" },
      { table: "rewardLedger", index: "rewardLedger_idempotency_idx" },
      { table: "rewardLedger", index: "rewardLedger_user_created_idx" },
      { table: "giftCodes", index: "giftCodes_code_hash_idx" },
      { table: "giftCodeRedemptions", index: "giftCodeRedemptions_code_user_idx" },
      { table: "campaignRequirements", index: "campaignRequirements_campaign_key_idx" },
      { table: "eligibilityResults", index: "eligibilityResults_snapshot_user_idx" },
      { table: "campaignTierMultipliers", index: "campaignTierMultipliers_campaign_tier_idx" },
      { table: "airdropDistributions", index: "airdropDistributions_snapshot_idx" },
      { table: "airdropAllocations", index: "airdropAllocations_distribution_user_idx" },
      { table: "rewardPolicies", index: "rewardPolicies_policy_key_idx" },
      { table: "rewardPolicies", index: "rewardPolicies_active_network_idx" },
      { table: "referralTradingVolume", index: "referralTradingVolume_tx_event_idx" },
      { table: "referralTradingVolume", index: "referralTradingVolume_referral_created_idx" },
      { table: "referralTradingVolume", index: "referralTradingVolume_verification_idx" },
      { table: "rewardPools", index: "rewardPools_policy_priority_idx" },
      { table: "rewardPools", index: "rewardPools_status_priority_idx" },
      { table: "rewardClaims", index: "rewardClaims_reward_idx" },
      { table: "rewardClaims", index: "rewardClaims_idempotency_idx" },
      { table: "rewardClaims", index: "rewardClaims_user_status_idx" },
    ];

    for (const opt of optimizationChecks) {
      results.optimizations[`${opt.table}.${opt.index}`] = (await checkIndex(opt.table, opt.index)) ? "✅ Optimized" : "❌ MISSING";
    }

    const expectedConstraints = [
      ["tokenListings", "tokenListings_submittedByOpenId_users_fk"],
      ["listingEvents", "listingEvents_listingId_tokenListings_fk"],
      ["campaigns", "campaigns_listingId_tokenListings_fk"],
      ["campaigns", "campaigns_createdByOpenId_users_fk"],
      ["campaignEntries", "campaignEntries_campaignId_campaigns_fk"],
      ["campaignEntries", "campaignEntries_userOpenId_users_fk"],
      ["activityEvents", "activityEvents_userOpenId_users_fk"],
      ["activityEvents", "activityEvents_chainId_chains_fk"],
      ["activityEvents", "activityEvents_assetId_assets_fk"],
      ["feeRecords", "feeRecords_userOpenId_users_fk"],
      ["feeRecords", "feeRecords_activityEventId_activityEvents_fk"],
      ["campaignSnapshots", "campaignSnapshots_campaignId_campaigns_fk"],
      ["campaignSnapshots", "campaignSnapshots_createdByOpenId_users_fk"],
      ["campaignSnapshotParticipants", "campaignSnapshotParticipants_snapshotId_campaignSnapshots_fk"],
      ["campaignSnapshotParticipants", "campaignSnapshotParticipants_userOpenId_users_fk"],
      ["referralProfiles", "referralProfiles_userOpenId_users_fk"],
      ["referrals", "referrals_inviterOpenId_users_fk"],
      ["referrals", "referrals_inviteeOpenId_users_fk"],
      ["rewardLedger", "rewardLedger_userOpenId_users_fk"],
      ["giftCodes", "giftCodes_createdByOpenId_users_fk"],
      ["giftCodeRedemptions", "giftCodeRedemptions_giftCodeId_giftCodes_fk"],
      ["giftCodeRedemptions", "giftCodeRedemptions_rewardLedgerId_rewardLedger_fk"],
      ["campaignRequirements", "campaignRequirements_campaignId_campaigns_fk"],
      ["eligibilityResults", "eligibilityResults_snapshotId_campaignSnapshots_fk"],
      ["eligibilityResults", "eligibilityResults_userOpenId_users_fk"],
      ["campaignTierMultipliers", "campaignTierMultipliers_campaignId_campaigns_fk"],
      ["airdropDistributions", "airdropDistributions_snapshotId_campaignSnapshots_fk"],
      ["airdropDistributions", "airdropDistributions_createdByOpenId_users_fk"],
      ["airdropAllocations", "airdropAllocations_distributionId_airdropDistributions_fk"],
      ["airdropAllocations", "airdropAllocations_eligibilityResultId_eligibilityResults_fk"],
      ["airdropAllocations", "airdropAllocations_rewardLedgerId_rewardLedger_fk"],
      ["airdropAllocations", "airdropAllocations_userOpenId_users_fk"],
      ["referrals", "referrals_rewardLedgerId_rewardLedger_fk"],
      ["rewardPools", "rewardPools_policyId_rewardPolicies_fk"],
      ["referralTradingVolume", "referralTradingVolume_referralId_referrals_fk"],
      ["referralTradingVolume", "referralTradingVolume_userOpenId_users_fk"],
      ["rewardClaims", "rewardClaims_rewardLedgerId_rewardLedger_fk"],
      ["rewardClaims", "rewardClaims_userOpenId_users_fk"],
      ["rewardClaims", "rewardClaims_poolId_rewardPools_fk"],
    ] as const;
    for (const [table, constraint] of expectedConstraints) {
      const [rows] = await db.execute(sql`SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ${table} AND CONSTRAINT_NAME = ${constraint}`);
      results.constraints[`${table}.${constraint}`] = (rows as any[]).length > 0 ? "✅ Present" : "❌ MISSING";
    }

    try {
      const [deploymentRows] = await db.execute(sql`SELECT version, checksum, appliedAt FROM paxiSchemaDeployments ORDER BY id`);
      results.migrationLedger = {
        appliedEntries: (deploymentRows as any[]).length,
        mode: (deploymentRows as any[]).length >= 6 ? "✅ Consolidated PAXI idempotent deployment ledger" : "❌ Incomplete PAXI deployment ledger",
        versions: (deploymentRows as any[]).map((row) => row.version),
      };
    } catch (error) {
      const code = typeof error === "object" && error !== null && "code" in error ? (error as { code?: unknown }).code : undefined;
      if (code === "ER_NO_SUCH_TABLE") {
        results.migrationLedger = { appliedEntries: 0, mode: "❌ Missing consolidated PAXI deployment ledger" };
      } else {
        throw error;
      }
    }

    try {
      const [migrationRows] = await db.execute(sql`SELECT hash, created_at FROM __drizzle_migrations ORDER BY created_at`);
      results.migrationLedger.legacyDrizzleEntries = (migrationRows as any[]).length;
      results.migrationLedger.legacyMode = "⚠️ Legacy Drizzle ledger is informational only; raw drizzle-kit migrate remains disabled";
    } catch (error) {
      const code = typeof error === "object" && error !== null && "code" in error ? (error as { code?: unknown }).code : undefined;
      if (code !== "ER_NO_SUCH_TABLE") throw error;
      results.migrationLedger.legacyDrizzleEntries = 0;
      results.migrationLedger.legacyMode = "⚠️ No legacy Drizzle ledger; use consolidated idempotent db:deploy";
    }

    console.log("\n--- REGRESSION TEST SUMMARY ---");
    console.table(results.tables);
    console.log("\n--- SCHEMA VERIFICATION ---");
    console.table(results.schema);
    console.log("\n--- INFRASTRUCTURE (PARTITIONING) ---");
    console.table(results.partitioning);
    console.log("\n--- DATA INTEGRITY ---");
    console.table(results.integrity);

    console.log("\n--- QUERY OPTIMIZATIONS (INDEXES) ---");
    console.table(results.optimizations);
    console.log("\n--- PARTITION PRIMARY KEYS ---");
    console.table(results.primaryKeys);
    console.log("\n--- USER REFERENCE CONSTRAINTS ---");
    console.table(results.constraints);
    console.log("\n--- MIGRATION LEDGER ---");
    console.table(results.migrationLedger);
    
    const allPassed = Object.values(results.tables).every(v => v === "✅ Present") &&
                     Object.values(results.schema).every(v => String(v).startsWith("✅")) &&
                     Object.values(results.primaryKeys).every(v => String(v).startsWith("✅")) &&
                     Object.values(results.constraints).every(v => String(v).startsWith("✅")) &&
                     Object.values(results.optimizations).every(v => v === "✅ Optimized") &&
                     String(results.migrationLedger.mode).startsWith("✅");

    if (allPassed) {
      console.log("\n✨ ALL DATABASE TESTS PASSED SUCCESSFULLY");
    } else {
      console.error("\n❌ SOME TESTS FAILED. CHECK SUMMARY ABOVE.");
      process.exit(1);
    }

  } catch (error) {
    console.error("❌ TEST EXECUTION ERROR:", error);
    process.exit(1);
  }

  process.exit(0);
}

runTest();
