import fs from "node:fs";
import { spawnSync } from "node:child_process";

const result = spawnSync("npm", ["audit", "--omit=dev", "--json"], { encoding: "utf8" });
const raw = `${result.stdout ?? ""}`;
const jsonStart = raw.indexOf("{");
if (jsonStart < 0) {
  console.error("Dependency audit did not return JSON.");
  if (result.stderr) console.error(result.stderr);
  process.exit(2);
}

const report = JSON.parse(raw.slice(jsonStart));
fs.mkdirSync("reports", { recursive: true });
fs.writeFileSync("reports/dependency-audit.json", JSON.stringify(report, null, 2));

function normalizeNpmFindings() {
  const vulnerabilities = report.vulnerabilities ?? {};
  return Object.values(vulnerabilities).map((vulnerability) => {
    const fixAvailable = vulnerability.fixAvailable;
    const via = Array.isArray(vulnerability.via) ? vulnerability.via : [];
    const advisoryUrls = via
      .filter((entry) => typeof entry === "object" && entry?.url)
      .map((entry) => entry.url);
    const isMajorFix = typeof fixAvailable === "object" && fixAvailable?.isSemVerMajor === true;
    const noFix = fixAvailable === false || fixAvailable == null;

    return {
      module: vulnerability.name,
      severity: vulnerability.severity,
      patched: isMajorFix
        ? `major upgrade required: ${fixAvailable.name}@${fixAvailable.version}`
        : noFix
          ? "no patched release"
          : fixAvailable === true
            ? "npm fix available"
            : String(fixAvailable),
      paths: [...new Set([...(vulnerability.nodes ?? []), ...advisoryUrls])],
      unfixable: noFix || isMajorFix,
    };
  });
}

function normalizePnpmFindings() {
  return Object.values(report.advisories ?? {}).map((advisory) => ({
    module: advisory.module_name,
    severity: advisory.severity,
    patched: advisory.patched_versions,
    paths: [...new Set((advisory.findings ?? []).flatMap((finding) => finding.paths ?? []))],
    unfixable: !advisory.patched_versions || String(advisory.patched_versions).includes("<0.0.0"),
  }));
}

const findings = report.vulnerabilities ? normalizeNpmFindings() : normalizePnpmFindings();
const highOrCritical = findings.filter((finding) => ["high", "critical"].includes(finding.severity));
const unfixable = highOrCritical.filter((finding) => finding.unfixable);
const fixable = highOrCritical.filter((finding) => !finding.unfixable);

console.log(`Dependency audit: ${findings.length} advisories; ${highOrCritical.length} high/critical.`);
for (const finding of unfixable) {
  console.warn(`UNFIXABLE UPSTREAM: ${finding.severity} ${finding.module} (${finding.patched})`);
  for (const path of finding.paths.slice(0, 3)) console.warn(`  ${path}`);
}
if (fixable.length > 0) {
  console.error(`FAIL: ${fixable.length} fixable high/critical advisories remain.`);
  for (const finding of fixable) console.error(`${finding.severity} ${finding.module} patched=${finding.patched}`);
  process.exit(1);
}
if (result.status !== 0 && unfixable.length === 0) process.exit(result.status ?? 1);
console.log("PASS: no fixable high/critical production dependency advisories remain.");
