import fs from "node:fs";
const file = "dist/public/assets/vendor-H9w4_Cwv.js";
const text = fs.readFileSync(file, "utf8");
const start = text.indexOf("function wr");
const end = text.indexOf("var Yg=xi.exports", start);
console.log(`start=${start} end=${end} length=${end - start}`);
console.log(text.slice(Math.max(start, end - 1800), end + 200));
