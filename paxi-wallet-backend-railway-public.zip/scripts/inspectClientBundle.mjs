import fs from "node:fs";
import path from "node:path";

const publicDir = path.resolve("dist/public/assets");
const files = fs.readdirSync(publicDir).filter((name) => /^index-[A-Za-z0-9_-]+\.js$/.test(name));
for (const name of files) {
  const text = fs.readFileSync(path.join(publicDir, name), "utf8");
  const needles = ["createRoot", "getElementById(\"root\")", "getElementById('root')", "render("];
  console.log(`FILE ${name} bytes=${Buffer.byteLength(text)}`);
  for (const needle of needles) {
    const index = text.indexOf(needle);
    console.log(`NEEDLE ${needle} index=${index}`);
    if (index >= 0) console.log(text.slice(Math.max(0, index - 500), index + 1000));
  }
}
