import fs from "node:fs";
import path from "node:path";

const files = [
  "dist/public/assets/vendor-H9w4_Cwv.js",
  "dist/public/assets/bitcoin-vendors-BA4yadC7.js",
];
const offsets = [177055, 205463, 6092, 7442, 7592, 8786, 10830, 11384, 68701];
for (const file of files) {
  const text = fs.readFileSync(path.resolve(file), "utf8");
  console.log(`FILE ${file} bytes=${text.length}`);
  for (const offset of offsets) {
    if (offset >= text.length) continue;
    console.log(`OFFSET ${offset}\n${text.slice(Math.max(0, offset - 700), offset + 1100)}\n---`);
  }
}
