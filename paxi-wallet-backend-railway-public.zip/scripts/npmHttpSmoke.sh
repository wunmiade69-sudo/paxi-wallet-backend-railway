#!/usr/bin/env bash
set -u

PORT="${PORT:-4175}"
BASE="http://127.0.0.1:${PORT}"
LOG="${SMOKE_LOG:-reports/npm-http-smoke.log}"
: > "$LOG"

NODE_ENV=production \
PORT="$PORT" \
ENABLE_WORKERS=false \
REDIS_REQUIRED=false \
JWT_SECRET="${JWT_SECRET:?JWT_SECRET is required}" \
VITE_APP_ID="${VITE_APP_ID:-paxi-npm-smoke}" \
OAUTH_SERVER_URL="${OAUTH_SERVER_URL:-https://oauth.example.invalid}" \
DATABASE_URL="${DATABASE_URL:?DATABASE_URL is required}" \
node dist/index.js > "$LOG" 2>&1 &
PID=$!
cleanup() { kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true; }
trap cleanup EXIT

for _ in $(seq 1 30); do
  if curl -fsS "$BASE/healthz" >/dev/null 2>&1; then break; fi
  sleep 1
done

health=$(curl -sS -o /tmp/paxi-health.json -w '%{http_code}' "$BASE/healthz")
ready=$(curl -sS -o /tmp/paxi-ready.json -w '%{http_code}' "$BASE/readyz")
chains=$(curl -sS -o /tmp/paxi-chains.json -w '%{http_code}' "$BASE/api/chains")
assets=$(curl -sS -o /tmp/paxi-assets.json -w '%{http_code}' "$BASE/api/assets")
csrf=$(curl -sS -o /tmp/paxi-csrf.json -w '%{http_code}' -X POST -H 'Origin: https://evil.example' -H 'Content-Type: application/json' "$BASE/api/trpc/rewards.mine")
rewards=$(curl -sS -o /tmp/paxi-rewards.json -w '%{http_code}' -H 'Origin: http://127.0.0.1:'"$PORT" "$BASE/api/trpc/rewards.mine?batch=1&input=%7B%7D")
lifi=$(curl -sS -o /tmp/paxi-lifi.json -w '%{http_code}' "$BASE/api/lifi-proxy?path=/admin")

printf 'health=%s\nready=%s\nchains=%s\nassets=%s\ncsrf=%s\nrewards=%s\nlifi_invalid=%s\n' "$health" "$ready" "$chains" "$assets" "$csrf" "$rewards" "$lifi" | tee -a "$LOG"

[ "$health" = "200" ] && [ "$ready" = "200" ] && [ "$chains" = "200" ] && [ "$assets" = "200" ] && [ "$csrf" = "403" ] && [ "$rewards" = "401" ] && [ "$lifi" = "400" ]
