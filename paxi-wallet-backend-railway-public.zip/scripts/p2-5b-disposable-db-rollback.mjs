import { randomUUID } from "node:crypto";
import { createPool } from "mysql2/promise";

const databaseUrl = process.env.P2_5B_TEST_DATABASE_URL ?? "";
if (process.env.P2_5B_ALLOW_DISPOSABLE_DB !== "true") {
  throw new Error("Refusing database access. Set P2_5B_ALLOW_DISPOSABLE_DB=true for an isolated disposable test database only.");
}
if (!databaseUrl) throw new Error("P2_5B_TEST_DATABASE_URL is required and must point to a disposable test database.");
const parsed = new URL(databaseUrl);
const host = parsed.hostname.toLowerCase();
if (["localhost", "127.0.0.1", "::1"].includes(host) === false && !host.endsWith(".test") && !host.endsWith(".local")) {
  throw new Error(`Refusing non-local/test database host: ${host}`);
}
const database = decodeURIComponent(parsed.pathname.replace(/^\//, ""));
if (!/^paxi_?test[_-]/i.test(database) && !/^test[_-]/i.test(database)) {
  throw new Error(`Refusing database name '${database}'. Use a disposable name beginning with paxi_test_ or test_.`);
}

const pool = createPool({
  host: parsed.hostname,
  port: Number(parsed.port) || 3306,
  user: decodeURIComponent(parsed.username),
  password: decodeURIComponent(parsed.password),
  database,
  connectionLimit: 1,
  multipleStatements: false,
  connectTimeout: 5000,
});
const suffix = randomUUID().replaceAll("-", "");
const operationTable = `p2_5b_ops_${suffix}`;
const activityTable = `p2_5b_activity_${suffix}`;
const feeTable = `p2_5b_fees_${suffix}`;
const q = (identifier) => `\`${identifier}\``;
const operationId = `op-${suffix}`;
const activityId = `activity-${suffix}`;
const feeId = `fee-${suffix}`;

try {
  const connection = await pool.getConnection();
  try {
    await connection.query(`CREATE TABLE ${q(operationTable)} (operation_id VARCHAR(80) PRIMARY KEY, state VARCHAR(32) NOT NULL) ENGINE=InnoDB`);
    await connection.query(`CREATE TABLE ${q(activityTable)} (activity_id VARCHAR(80) PRIMARY KEY, operation_id VARCHAR(80) NOT NULL) ENGINE=InnoDB`);
    await connection.query(`CREATE TABLE ${q(feeTable)} (fee_id VARCHAR(80) PRIMARY KEY, operation_id VARCHAR(80) NOT NULL) ENGINE=InnoDB`);
    console.log(JSON.stringify({ phase: "setup", engine: "MySQL/InnoDB", database, operationId, activityId, feeId, failurePoint: "after fee insert before COMMIT" }));

    await connection.beginTransaction();
    try {
      await connection.query(`INSERT INTO ${q(operationTable)} (operation_id, state) VALUES (?, 'SEND_PENDING')`, [operationId]);
      await connection.query(`INSERT INTO ${q(activityTable)} (activity_id, operation_id) VALUES (?, ?)`, [activityId, operationId]);
      await connection.query(`INSERT INTO ${q(feeTable)} (fee_id, operation_id) VALUES (?, ?)`, [feeId, operationId]);
      throw new Error("P2_5B_INTENTIONAL_FAILURE_AFTER_FEE_INSERT");
    } catch (error) {
      await connection.rollback();
      console.log(JSON.stringify({ phase: "rollback", error: error.message }));
    }

    const [afterRollback] = await connection.query(
      `SELECT (SELECT COUNT(*) FROM ${q(operationTable)} WHERE operation_id = ?) AS operations, (SELECT COUNT(*) FROM ${q(activityTable)} WHERE activity_id = ?) AS activities, (SELECT COUNT(*) FROM ${q(feeTable)} WHERE fee_id = ?) AS fees`,
      [operationId, activityId, feeId],
    );
    const rollbackState = afterRollback[0];
    if (rollbackState.operations !== 0 || rollbackState.activities !== 0 || rollbackState.fees !== 0) throw new Error(`Rollback left partial rows: ${JSON.stringify(rollbackState)}`);
    console.log(JSON.stringify({ phase: "post-rollback", state: rollbackState, usable: true }));

    await connection.beginTransaction();
    await connection.query(`INSERT INTO ${q(operationTable)} (operation_id, state) VALUES (?, 'COMPLETED')`, [operationId]);
    await connection.query(`INSERT INTO ${q(activityTable)} (activity_id, operation_id) VALUES (?, ?)`, [activityId, operationId]);
    await connection.query(`INSERT INTO ${q(feeTable)} (fee_id, operation_id) VALUES (?, ?)`, [feeId, operationId]);
    await connection.commit();
    const [afterCommit] = await connection.query(
      `SELECT (SELECT COUNT(*) FROM ${q(operationTable)} WHERE operation_id = ?) AS operations, (SELECT COUNT(*) FROM ${q(activityTable)} WHERE activity_id = ?) AS activities, (SELECT COUNT(*) FROM ${q(feeTable)} WHERE fee_id = ?) AS fees`,
      [operationId, activityId, feeId],
    );
    const commitState = afterCommit[0];
    if (commitState.operations !== 1 || commitState.activities !== 1 || commitState.fees !== 1) throw new Error(`Clean retry did not commit exactly once: ${JSON.stringify(commitState)}`);
    console.log(JSON.stringify({ phase: "post-clean-retry", state: commitState, duplicateFree: true }));
  } finally {
    await connection.query(`DROP TABLE IF EXISTS ${q(feeTable)}`);
    await connection.query(`DROP TABLE IF EXISTS ${q(activityTable)}`);
    await connection.query(`DROP TABLE IF EXISTS ${q(operationTable)}`);
    connection.release();
  }
} finally {
  await pool.end();
}
