import { fetchAggregatedMarket } from '../server/providers/aggregator';
import { marketProviders } from '../server/providers';

const chainId = process.argv[2] ?? 'bsc';
const tokenAddress = process.argv[3] ?? '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c';

const results = await Promise.all(
  marketProviders.map(async (provider) => {
    try {
      const markets = await provider.getMarketsForToken(chainId, tokenAddress);
      const ohlcv = provider.getOhlcv && markets[0]?.pairAddress
        ? await provider.getOhlcv(chainId, markets[0].pairAddress, '1h', 5)
        : [];
      return {
        provider: provider.name,
        ok: true,
        count: markets.length,
        timestampMs: markets[0]?.timestamp ?? null,
        ohlcvCount: ohlcv.length,
        firstOhlcvTimestampMs: ohlcv[0]?.timestamp ?? null,
      };
    } catch (error) {
      return { provider: provider.name, ok: false, count: 0, error: error instanceof Error ? error.message : String(error) };
    }
  }),
);

const aggregate = await fetchAggregatedMarket(chainId, tokenAddress);
console.log(JSON.stringify({ chainId, tokenAddress, providers: results, aggregate: aggregate ? {
  priceUsd: aggregate.priceUsd,
  confidence: aggregate.confidence,
  sources: aggregate.sources,
  primarySource: aggregate.primarySource,
  sourceUpdatedAt: aggregate.sourceUpdatedAt,
  sourceUpdatedAtIsMilliseconds: aggregate.sourceUpdatedAt == null || aggregate.sourceUpdatedAt > 10_000_000_000,
} : null }, null, 2));
