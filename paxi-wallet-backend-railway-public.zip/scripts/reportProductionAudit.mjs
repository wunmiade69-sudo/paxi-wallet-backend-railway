import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

const auditPath = '/tmp/paxi-production-audit.json';
try {
  execFileSync('npm', ['audit', '--omit=dev', '--json'], { stdio: ['ignore', fs.openSync(auditPath, 'w'), 'ignore'] });
} catch {
  // npm audit exits non-zero when vulnerabilities are present; the JSON is still the source of truth.
}

const report = JSON.parse(fs.readFileSync(auditPath, 'utf8'));
const vulnerabilities = Object.entries(report.vulnerabilities ?? {}).map(([name, entry]) => ({
  package: name,
  severity: entry.severity,
  direct: entry.isDirect,
  via: Array.isArray(entry.via)
    ? entry.via.map((item) => typeof item === 'string' ? item : `${item.source ?? 'advisory'} (${item.title ?? 'no title'})`)
    : [],
  range: entry.range ?? null,
  fix: entry.fixAvailable ?? false,
  nodes: entry.nodes ?? [],
}));

console.log(JSON.stringify({
  metadata: report.metadata?.vulnerabilities ?? null,
  vulnerabilities,
}, null, 2));
