#!/usr/bin/env bash
set -u

out="release-validation-final-freeze-2026-08-18"
rm -rf "$out"
mkdir -p "$out"
start=$(date -u +%Y-%m-%dT%H:%M:%SZ)

npm run check >"$out/check.log" 2>&1
check=$?
npm test -- --run >"$out/test.log" 2>&1
test=$?
npm run build >"$out/build.log" 2>&1
build=$?
npm run lint >"$out/lint.log" 2>&1
lint=$?
npm audit --omit=dev >"$out/audit.log" 2>&1
audit=$?

end=$(date -u +%Y-%m-%dT%H:%M:%SZ)
{
  printf 'started_at=%s\n' "$start"
  printf 'completed_at=%s\n' "$end"
  printf 'check_exit=%s\n' "$check"
  printf 'test_exit=%s\n' "$test"
  printf 'build_exit=%s\n' "$build"
  printf 'lint_exit=%s\n' "$lint"
  printf 'audit_exit=%s\n' "$audit"
  printf '\nTest summary:\n'
  grep -E 'Test Files|Tests ' "$out/test.log" | tail -8 || true
  printf '\nAudit summary:\n'
  grep -E 'Low|Moderate|High|Critical|vulnerabilit' "$out/audit.log" | tail -12 || true
} | tee "$out/summary.txt"

if [ "$check" -ne 0 ] || [ "$test" -ne 0 ] || [ "$build" -ne 0 ] || [ "$lint" -ne 0 ]; then
  exit 1
fi
exit 0
