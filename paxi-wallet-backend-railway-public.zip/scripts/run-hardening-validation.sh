#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
OUT="$ROOT/release-validation-hardening-2026-08-18"
mkdir -p "$OUT"
run_gate() {
  local name="$1"
  shift
  echo "[$STAMP] $name: $*" | tee "$OUT/$name.command.txt"
  (cd "$ROOT" && "$@") >"$OUT/$name.log" 2>&1
  local code=$?
  echo "$code" >"$OUT/$name.exit"
  echo "exit=$code"
}
run_gate check npm run check
run_gate test npm test -- --run
run_gate build npm run build
run_gate lint npm run lint
run_gate audit npm audit --omit=dev
{
  echo "timestamp=$STAMP"
  for name in check test build lint audit; do
    printf '%s_exit=%s\n' "$name" "$(cat "$OUT/$name.exit")"
  done
  echo "test_summary=$(grep -E 'Test Files|Tests ' "$OUT/test.log" | tail -n 2 | tr '\n' ';')"
  echo "audit_summary=$(grep -E 'found in| vulnerabilities|low|moderate|high|critical' "$OUT/audit.log" | tail -n 4 | tr '\n' ';')"
} >"$OUT/summary.txt"
