#!/usr/bin/env bash
set +e
set -o pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/release-validation-2026-08-18"
mkdir -p "$OUT"
cd "$ROOT"

run_step() {
  local name="$1"
  shift
  printf '\n===== %s =====\n' "$name" | tee "$OUT/${name}.log"
  "$@" 2>&1 | tee -a "$OUT/${name}.log"
  local code=${PIPESTATUS[0]}
  printf 'EXIT_CODE=%s\n' "$code" | tee -a "$OUT/${name}.log"
  printf '%s\t%s\n' "$name" "$code" >> "$OUT/exit-codes.tsv"
}

: > "$OUT/exit-codes.tsv"
run_step check npm run check
run_step test npm test -- --run
run_step build npm run build
run_step lint npm run lint
run_step audit npm audit --omit=dev

printf '\n===== file/test summaries =====\n' | tee "$OUT/summary.txt"
grep -hE '^ Test Files |^      Tests |^Test Files |^Tests |^  [0-9]+ vulnerabilities|^found [0-9]+ vulnerabilities|^EXIT_CODE=' "$OUT"/*.log | tee -a "$OUT/summary.txt"

date -u '+VALIDATED_AT_UTC=%Y-%m-%dT%H:%M:%SZ' | tee -a "$OUT/summary.txt"
