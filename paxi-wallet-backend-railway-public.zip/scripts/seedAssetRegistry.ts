import { backfillAssetsFromListings, PAXI_CHAINS, PAXI_DEXES, seedChains, seedDexes } from "../server/assetRegistry";

async function main(): Promise<void> {
  await seedChains();
  console.log(`Seeded ${PAXI_CHAINS.length} chains.`);
  await seedDexes();
  console.log(`Seeded ${PAXI_DEXES.length} dexes.`);
  if (process.argv.includes("--backfill")) {
    await backfillAssetsFromListings();
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
