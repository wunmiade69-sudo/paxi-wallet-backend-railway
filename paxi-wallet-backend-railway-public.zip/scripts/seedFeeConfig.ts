import mysql from "mysql2/promise";
import { DEFAULT_FEE_SCHEDULE } from "../server/fees/feeConfig";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });

try {
  for (const item of DEFAULT_FEE_SCHEDULE) {
    await connection.query(
      `INSERT INTO \`feeConfig\` (\`operation\`, \`chainType\`, \`percentageBps\`, \`fixedUsd\`, \`isActive\`)
       VALUES (?, ?, ?, ?, 1)
       ON DUPLICATE KEY UPDATE \`operation\` = VALUES(\`operation\`)`,
      [item.operation, item.chainType, item.percentageBps, item.fixedUsd],
    );
    console.log(`✅ Fee config present: ${item.operation}/${item.chainType}`);
  }
  console.log("✅ Default fee configuration seeded without overwriting existing values.");
} catch (error) {
  console.error("❌ Fee configuration seed failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
