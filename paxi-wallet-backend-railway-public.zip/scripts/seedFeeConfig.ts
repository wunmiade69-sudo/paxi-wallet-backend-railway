import mysql from "mysql2/promise";
import { DEFAULT_FEE_SCHEDULE } from "../server/fees/feeConfig";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const connection = await mysql.createConnection({ uri: databaseUrl, connectTimeout: 5_000 });

try {
  for (const item of DEFAULT_FEE_SCHEDULE) {
    await connection.query(
      `INSERT INTO \`feeConfig\` (\`operation\`, \`chainType\`, \`percentageBps\`, \`fixedUsd\`, \`isActive\`)
       VALUES (?, ?, ?, ?, 1)
       ON DUPLICATE KEY UPDATE
         \`percentageBps\` = VALUES(\`percentageBps\`),
         \`fixedUsd\` = VALUES(\`fixedUsd\`),
         \`isActive\` = VALUES(\`isActive\`)`,
      [item.operation, item.chainType, item.percentageBps, item.fixedUsd],
    );
    console.log(`✅ Fee config synced: ${item.operation}/${item.chainType} -> ${item.percentageBps}bps / $${item.fixedUsd}`);
  }
  console.log("✅ Default fee configuration seeded and synced to DEFAULT_FEE_SCHEDULE values.");
} catch (error) {
  console.error("❌ Fee configuration seed failed:", error instanceof Error ? error.message : "unknown error");
  process.exitCode = 1;
} finally {
  connection.destroy();
}
