import "dotenv/config";
import { and, eq } from "drizzle-orm";
import { getDb } from "../server/db";
import { syncAssetFromListing, seedChains } from "../server/assetRegistry";
import { tokenListings, type InsertTokenListing } from "../drizzle/schema";

const DEFAULT_NETWORK = "bsc";
const DEFAULT_CONTRACT = "0xeda04581461bc308e60052fe489e20c3f78d6e4e";
const DEFAULT_SYMBOL = "PAXI";
const DEFAULT_NAME = "PAXI";

function readArg(name: string): string | undefined {
  const prefix = `--${name}=`;
  const value = process.argv.find((argument) => argument.startsWith(prefix));
  return value ? value.slice(prefix.length).trim() : undefined;
}

function requiredValue(name: string, fallback?: string): string {
  const value = readArg(name) ?? process.env[name.toUpperCase().replace(/-/g, "_")] ?? fallback;
  if (!value) throw new Error(`Missing required value: --${name}=...`);
  return value;
}

async function main(): Promise<void> {
  const logoUrl = requiredValue("logo-url");
  const network = readArg("network") ?? DEFAULT_NETWORK;
  const contractAddress = readArg("contract") ?? DEFAULT_CONTRACT;
  const symbol = readArg("symbol") ?? DEFAULT_SYMBOL;
  const name = readArg("name") ?? DEFAULT_NAME;

  if (!/^https:\/\//i.test(logoUrl) && !logoUrl.startsWith("/manus-storage/")) {
    throw new Error("Logo URL must be HTTPS or a trusted /manus-storage/ path.");
  }
  if (!/^0x[a-fA-F0-9]{40}$/.test(contractAddress)) {
    throw new Error("PAXI contract must be a valid 20-byte EVM address.");
  }

  const db = await getDb();
  if (!db) throw new Error("No database connection - check DATABASE_URL is set.");
  await seedChains();

  const existing = await db
    .select()
    .from(tokenListings)
    .where(and(eq(tokenListings.contractAddress, contractAddress), eq(tokenListings.network, network)))
    .limit(1);

  let listing = existing[0];
  if (listing) {
    await db
      .update(tokenListings)
      .set({ logoUrl, symbol, name, status: "verified" })
      .where(eq(tokenListings.id, listing.id));
  } else {
    const values: InsertTokenListing = {
      contractAddress,
      network,
      symbol,
      name,
      logoUrl,
      source: "seed",
      status: "verified",
    };
    await db.insert(tokenListings).values(values);
  }

  const [updated] = await db
    .select()
    .from(tokenListings)
    .where(and(eq(tokenListings.contractAddress, contractAddress), eq(tokenListings.network, network)))
    .limit(1);
  if (!updated) throw new Error("Token listing could not be read after update.");

  await syncAssetFromListing(updated);
  console.log(JSON.stringify({
    ok: true,
    network,
    contractAddress,
    symbol,
    logoUrl,
    message: "Official logo stored in tokenListings and synchronized to assets; all users will receive this registry logo.",
  }, null, 2));
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
