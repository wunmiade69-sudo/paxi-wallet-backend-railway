INSERT INTO `feeConfig` (`operation`, `chainType`, `percentageBps`, `fixedUsd`, `isActive`)
VALUES ('send', 'evm', 40, '0', 1)
ON DUPLICATE KEY UPDATE
  `percentageBps` = VALUES(`percentageBps`),
  `fixedUsd` = VALUES(`fixedUsd`),
  `isActive` = VALUES(`isActive`);
