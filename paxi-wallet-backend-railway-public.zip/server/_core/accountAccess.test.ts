import { describe, expect, it } from "vitest";
import { assertPlatformAccessAllowed } from "./accountAccess";

describe("platform suspension guard", () => {
  it("allows active accounts", () => {
    expect(() => assertPlatformAccessAllowed({ suspendedAt: null })).not.toThrow();
    expect(() => assertPlatformAccessAllowed({})).not.toThrow();
  });

  it("denies suspended platform sessions with a forbidden error", () => {
    expect(() => assertPlatformAccessAllowed({ suspendedAt: new Date("2026-01-01T00:00:00.000Z") })).toThrowError("Account suspended");
  });
});
