import { ForbiddenError } from "@shared/_core/errors";

/**
 * Platform access suspension only. This guard must never mutate or freeze
 * self-custodied wallet keys, balances, or on-chain assets.
 */
export function assertPlatformAccessAllowed(user: { suspendedAt?: Date | null }): void {
  if (user.suspendedAt) {
    throw ForbiddenError("Account suspended");
  }
}
