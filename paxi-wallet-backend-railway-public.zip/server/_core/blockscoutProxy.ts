import express from "express";
import type { Express, Request, Response as ExpressResponse } from "express";
import { distributedProxyRateLimit } from "./distributedRateLimit";

const ALLOWED_HOSTS = new Set([
  "bsc.blockscout.com",
  "eth.blockscout.com",
  "blockstream.info",
  // gateway.liquify.com is the confirmed-working THORChain path (see
  // reports/THORCHAIN_GATEWAY_FINDINGS.md and server/thorchain.ts). The
  // old thornode.ninerealms.com / midgard.ninerealms.com entries were
  // removed: they were unreachable from this server and are no longer
  // called by any code, so keeping them allowlisted only invited drift.
  "gateway.liquify.com",
]);
const MAX_UPSTREAM_BYTES = 2 * 1024 * 1024;
const MAX_BROADCAST_BYTES = 256 * 1024;

function checkUrl(target: string): URL | null {
  try {
    const parsed = new URL(target);
    if (parsed.protocol !== "https:" || !ALLOWED_HOSTS.has(parsed.hostname)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function isAllowedBroadcastTarget(parsed: URL): boolean {
  return parsed.hostname === "blockstream.info" && parsed.pathname === "/api/tx";
}

async function readLimitedText(response: globalThis.Response, maxBytes: number): Promise<string> {
  const declaredLength = Number(response.headers.get("content-length") ?? 0);
  if (declaredLength > maxBytes) throw new Error("upstream response too large");
  if (!response.body) return "";

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new Error("upstream response too large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8");
}

export function registerBlockscoutProxyRoute(app: Express) {
  app.get("/api/blockscout-proxy", distributedProxyRateLimit, async (req: Request, res: ExpressResponse) => {
    const target = typeof req.query.url === "string" ? req.query.url : "";
    const parsed = checkUrl(target);
    if (!parsed) {
      res.status(400).json({ error: "Invalid or disallowed url" });
      return;
    }

    try {
      const upstream = await fetch(parsed.toString(), {
        headers: { Accept: "application/json,text/plain;q=0.9" },
        signal: AbortSignal.timeout(8000),
      });
      const body = await readLimitedText(upstream, MAX_UPSTREAM_BYTES);
      res
        .status(upstream.status)
        .type(upstream.headers.get("content-type") ?? "application/json")
        .send(body);
    } catch {
      res.status(502).json({ error: "Upstream fetch failed" });
    }
  });

  /** Esplora broadcast endpoint only; no arbitrary POST proxying is permitted. */
  app.post(
    "/api/blockscout-proxy",
    distributedProxyRateLimit,
    express.text({ type: "*/*", limit: `${MAX_BROADCAST_BYTES}b` }),
    async (req: Request, res: ExpressResponse) => {
      const target = typeof req.query.url === "string" ? req.query.url : "";
      const parsed = checkUrl(target);
      if (!parsed || !isAllowedBroadcastTarget(parsed)) {
        res.status(400).json({ error: "Invalid or disallowed broadcast url" });
        return;
      }
      if (typeof req.body !== "string" || req.body.length === 0) {
        res.status(400).json({ error: "Signed transaction body is required" });
        return;
      }

      try {
        const upstream = await fetch(parsed.toString(), {
          method: "POST",
          body: req.body,
          headers: { "Content-Type": "text/plain", Accept: "text/plain" },
          signal: AbortSignal.timeout(15000),
        });
        const body = await readLimitedText(upstream, MAX_BROADCAST_BYTES);
        res.status(upstream.status).type("text/plain").send(body);
      } catch {
        res.status(502).json({ error: "Upstream broadcast failed" });
      }
    },
  );
}
