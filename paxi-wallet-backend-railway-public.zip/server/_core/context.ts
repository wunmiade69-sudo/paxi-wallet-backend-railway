import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures, so we still resolve
    // to a null user here rather than throwing. But swallowing the error
    // completely made every "Please login (10001)" on a protected route
    // (send quotes, wallet-link, etc.) undiagnosable in production logs.
    // Log the real reason so an auth/session/cookie misconfiguration is
    // visible instead of only ever showing up as a generic login prompt.
    console.warn(
      "[Auth] authenticateRequest failed, continuing as unauthenticated:",
      error instanceof Error ? error.message : String(error),
    );
    user = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
