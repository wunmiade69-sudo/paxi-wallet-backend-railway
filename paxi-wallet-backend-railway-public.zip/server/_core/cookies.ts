import type { CookieOptions, Request as ExpressRequest } from "express";

/**
 * Session cookies are cross-site during OAuth, so production HTTPS uses
 * SameSite=None + Secure. Local HTTP development cannot legally set that
 * combination in modern browsers, so it uses SameSite=Lax + Secure=false.
 */
export function getSessionCookieOptions(
  req: ExpressRequest,
): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> {
  const secure = typeof req.secure === "boolean" ? req.secure : req.protocol === "https";
  return {
    httpOnly: true,
    path: "/",
    sameSite: secure ? "none" : "lax",
    secure,
  };
}
