import { describe, expect, it } from "vitest";
import { getSessionCookieOptions } from "./cookies";
import { isSameOriginMutation } from "./requestSecurity";
import { parseTrustProxyHops, validateTrustProxyHops } from "./env";

function requestLike(values: { method?: string; origin?: string; referer?: string; host?: string; protocol?: string; secure?: boolean }) {
  return {
    method: values.method ?? "POST",
    secure: values.secure,
    protocol: values.protocol ?? "https",
    get(name: string) {
      return {
        origin: values.origin,
        referer: values.referer,
        host: values.host ?? "wallet.example",
      }[name.toLowerCase()];
    },
  } as never;
}

describe("Railway deployment security configuration", () => {
  it("accepts only an explicit integer proxy-hop count in the supported range", () => {
    expect(parseTrustProxyHops("0")).toBe(0);
    expect(parseTrustProxyHops("2")).toBe(2);
    expect(parseTrustProxyHops("10")).toBe(10);
    expect(() => parseTrustProxyHops("1.5")).toThrow(/TRUST_PROXY_HOPS/);
    expect(() => parseTrustProxyHops("11")).toThrow(/TRUST_PROXY_HOPS/);
    expect(() => parseTrustProxyHops("trusted")).toThrow(/TRUST_PROXY_HOPS/);
  });

  it("requires Railway production to provide the topology-verified value instead of guessing", () => {
    expect(() => validateTrustProxyHops(true, undefined)).toThrow(/explicitly configured in production/);
    expect(() => validateTrustProxyHops(true, "2")).not.toThrow();
    expect(() => validateTrustProxyHops(false, undefined)).not.toThrow();
  });

  it("derives secure SameSite=None cookies from the Express trusted-proxy result", () => {
    expect(getSessionCookieOptions(requestLike({ protocol: "https", secure: true }))).toMatchObject({ secure: true, sameSite: "none", httpOnly: true, path: "/" });
    expect(getSessionCookieOptions(requestLike({ protocol: "http", secure: false }))).toMatchObject({ secure: false, sameSite: "lax" });
  });

  it("allows same-origin HTTPS mutations and blocks cross-origin or protocol-mismatched mutations", () => {
    expect(isSameOriginMutation(requestLike({ origin: "https://wallet.example", host: "wallet.example", protocol: "https" }))).toBe(true);
    expect(isSameOriginMutation(requestLike({ origin: "https://evil.example", host: "wallet.example", protocol: "https" }))).toBe(false);
    expect(isSameOriginMutation(requestLike({ origin: "http://wallet.example", host: "wallet.example", protocol: "https" }))).toBe(false);
    // Tests run in development mode; production denies a bearerless mutation
    // with no Origin/Referer rather than weakening same-origin protection.
    expect(isSameOriginMutation(requestLike({ host: "wallet.example", protocol: "https" }))).toBe(true);
    expect(isSameOriginMutation(requestLike({ method: "GET", host: "wallet.example", protocol: "https" }))).toBe(true);
  });
});
