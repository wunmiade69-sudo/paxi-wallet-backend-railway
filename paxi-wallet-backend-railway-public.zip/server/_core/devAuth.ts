import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { ENV } from "./env";
import { sdk } from "./sdk";

/**
 * DEV-ONLY login bypass. Real login goes through /api/oauth/callback and
 * Manus's OAuth server (see oauth.ts) - that requires infrastructure this
 * app doesn't have when run standalone (e.g. in Termux). This route does
 * the same last two steps (upsert user, sign a session cookie) but skips
 * the code/token exchange, so you can log in and test locally.
 *
 * Never registered when ENV.isProduction is true - see index.ts.
 *
 * Usage: visit /api/dev/login?name=YourName&admin=1 in the browser.
 */
export function registerDevLoginRoute(app: Express) {
  if (ENV.isProduction) return;

  app.get("/api/dev/login", async (req: Request, res: Response) => {
    const name = typeof req.query.name === "string" && req.query.name ? req.query.name : "Dev User";
    const wantsAdmin = req.query.admin === "1" || req.query.admin === "true";
    // Stable per name, so revisiting with the same ?name= logs back into the same test account.
    const openId = `dev_${name.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`;

    await db.upsertUser({
      openId,
      name,
      email: null,
      loginMethod: "dev",
      lastSignedIn: new Date(),
      ...(wantsAdmin ? { role: "admin" as const } : {}),
    });

    const sessionToken = await sdk.createSessionToken(openId, { name, expiresInMs: ONE_YEAR_MS });
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
    res.redirect(302, "/");
  });
}
