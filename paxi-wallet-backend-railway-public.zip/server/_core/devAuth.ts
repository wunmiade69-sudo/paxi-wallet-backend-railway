import type { Express, Request, Response } from "express";
import { ENV } from "./env";
import { issueSession } from "./session";

/**
 * DEV-ONLY login bypass. Real login goes through /api/oauth/callback and
 * Manus's OAuth server (see oauth.ts) - that requires infrastructure this
 * app doesn't have when run standalone (e.g. in Termux). This route does
 * the same last two steps (upsert user, sign a session cookie) but skips
 * the code/token exchange, so you can log in and test locally.
 *
 * Never registered when ENV.isProduction is true - see index.ts.
 *
 * Usage: visit /api/dev/login?name=YourName&admin=1 in the browser.
 */
export function registerDevLoginRoute(app: Express) {
  if (ENV.isProduction) return;

  app.get("/api/dev/login", async (req: Request, res: Response) => {
    const name = typeof req.query.name === "string" && req.query.name ? req.query.name : "Dev User";
    const wantsAdmin = req.query.admin === "1" || req.query.admin === "true";
    // Stable per name, so revisiting with the same ?name= logs back into the same test account.
    const openId = `dev_${name.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`;

    await issueSession(req, res, openId, name, {
      loginMethod: "dev",
      role: wantsAdmin ? "admin" : undefined,
    });
    res.redirect(302, "/");
  });
}
