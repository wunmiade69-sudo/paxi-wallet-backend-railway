import type { NextFunction, Request, Response } from "express";
import { redisSafe } from "../redis";
import { createLocalRateLimiter, publicApiRateLimit, type RateLimitOptions } from "./rateLimit";

const INCREMENT_SCRIPT = `
local count = redis.call('INCR', KEYS[1])
if count == 1 then
  redis.call('EXPIRE', KEYS[1], ARGV[1])
end
return count
`;

function clientKey(req: Request): string {
  return (req.ip ?? req.socket.remoteAddress ?? "unknown")
    .replace(/[^a-zA-Z0-9:._-]/g, "_");
}

function redisRateLimit(options: RateLimitOptions) {
  const localFallback = createLocalRateLimiter(options);

  return async function distributedRateLimit(req: Request, res: Response, next: NextFunction) {
    const key = `rate:v1:${options.keyPrefix}:${clientKey(req)}`;
    const windowSeconds = Math.ceil(options.windowMs / 1000);
    const count = await redisSafe(async (client) => {
      const result = await client.eval(INCREMENT_SCRIPT, 1, key, String(windowSeconds));
      return Number(result);
    });

    if (count == null || !Number.isFinite(count)) {
      localFallback(req, res, next);
      return;
    }

    res.setHeader("X-RateLimit-Limit", String(options.maxRequests));
    res.setHeader("X-RateLimit-Remaining", String(Math.max(0, options.maxRequests - count)));
    if (count > options.maxRequests) {
      res.setHeader("Retry-After", String(windowSeconds));
      res.status(429).json({ error: "Rate limit exceeded", retryAfterSeconds: windowSeconds });
      return;
    }
    next();
  };
}

export const distributedPublicApiRateLimit = redisRateLimit({
  windowMs: 60_000,
  maxRequests: 120,
  keyPrefix: "public-api",
});

export const distributedAuthRateLimit = redisRateLimit({
  windowMs: 5 * 60_000,
  maxRequests: 30,
  keyPrefix: "auth",
});

export const distributedProxyRateLimit = redisRateLimit({
  windowMs: 60_000,
  maxRequests: 120,
  keyPrefix: "proxy",
});

// Preserve the existing local export for callers that do not need Redis.
export { publicApiRateLimit };
