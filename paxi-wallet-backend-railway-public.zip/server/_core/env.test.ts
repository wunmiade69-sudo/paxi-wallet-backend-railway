import { afterEach, describe, expect, it, vi } from "vitest";

const originalTreasury = process.env.PAXI_TREASURY_ADDRESS;
const originalVault = process.env.PAXI_REWARD_VAULT_ADDRESS;
const originalEscrow = process.env.PAXI_REWARD_ESCROW_ADDRESS;

afterEach(() => {
  if (originalTreasury === undefined) delete process.env.PAXI_TREASURY_ADDRESS;
  else process.env.PAXI_TREASURY_ADDRESS = originalTreasury;
  if (originalVault === undefined) delete process.env.PAXI_REWARD_VAULT_ADDRESS;
  else process.env.PAXI_REWARD_VAULT_ADDRESS = originalVault;
  if (originalEscrow === undefined)
    delete process.env.PAXI_REWARD_ESCROW_ADDRESS;
  else process.env.PAXI_REWARD_ESCROW_ADDRESS = originalEscrow;
  vi.resetModules();
});

describe("server destination configuration", () => {
  it("does not embed a treasury or reward-vault fallback address", async () => {
    delete process.env.PAXI_TREASURY_ADDRESS;
    delete process.env.PAXI_REWARD_VAULT_ADDRESS;
    delete process.env.PAXI_REWARD_ESCROW_ADDRESS;
    vi.resetModules();

    const { ENV } = await import("./env");

    expect(ENV.paxiTreasuryAddress).toBe("");
    expect(ENV.paxiRewardVaultAddress).toBe("");
    expect(ENV.paxiRewardEscrowAddress).toBe("");
  });

  it("uses only explicitly configured destination values", async () => {
    process.env.PAXI_TREASURY_ADDRESS =
      "0x0000000000000000000000000000000000000001";
    process.env.PAXI_REWARD_VAULT_ADDRESS =
      "0x0000000000000000000000000000000000000002";
    delete process.env.PAXI_REWARD_ESCROW_ADDRESS;
    vi.resetModules();

    const { ENV } = await import("./env");

    expect(ENV.paxiTreasuryAddress).toBe(
      "0x0000000000000000000000000000000000000001"
    );
    expect(ENV.paxiRewardVaultAddress).toBe(
      "0x0000000000000000000000000000000000000002"
    );
    expect(ENV.paxiRewardEscrowAddress).toBe(
      "0x0000000000000000000000000000000000000002"
    );
  });
});
