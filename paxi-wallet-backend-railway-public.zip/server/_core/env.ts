export function parseTrustProxyHops(raw: string | undefined): number {
  if (raw == null || raw.trim() === "") return 0;
  if (!/^\d+$/.test(raw.trim())) throw new Error("TRUST_PROXY_HOPS must be an integer from 0 to 10");
  const parsed = Number(raw);
  if (!Number.isSafeInteger(parsed) || parsed < 0 || parsed > 10) {
    throw new Error("TRUST_PROXY_HOPS must be an integer from 0 to 10");
  }
  return parsed;
}

export function validateTrustProxyHops(isProduction: boolean, raw: string | undefined): void {
  if (isProduction && (raw == null || raw.trim() === "")) {
    throw new Error("TRUST_PROXY_HOPS must be explicitly configured in production after verifying the Railway proxy topology");
  }
  parseTrustProxyHops(raw);
}

const trustProxyHops = parseTrustProxyHops(process.env.TRUST_PROXY_HOPS);

export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  databaseReadUrl: process.env.DATABASE_READ_URL ?? process.env.DATABASE_REPLICA_URL ?? "",
  /** Optional - Redis is a cache/coordination layer, not a source of truth. Every Redis-backed feature must degrade gracefully (fall back to MySQL/in-process behavior) when this is unset. */
  redisUrl: process.env.REDIS_URL ?? "",
  redisRequired: process.env.REDIS_REQUIRED === "true",
  redisTlsRequired: process.env.REDIS_TLS_REQUIRED === "true",
  /** Background workers are opt-in; ordinary web/API operation must not start BullMQ by default. */
  workersEnabled: process.env.ENABLE_WORKERS === "true",
  /** Startup market prewarming remains enabled by default but can be disabled for isolated tests. */
  marketPrewarmEnabled: process.env.ENABLE_MARKET_PREWARM !== "false",
  metricsToken: process.env.METRICS_TOKEN ?? "",
  trustProxyHops,
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  /** Optional server-only LI.FI key; never prefix with VITE_ or expose it to the browser. */
  lifiApiKey: process.env.LIFI_API_KEY ?? "",
  /** Optional server-only Birdeye key for chain-specific token metadata and market fallbacks. */
  birdeyeApiKey: process.env.BIRDEYE_API_KEY ?? "",
  /** Optional server-only DexPaprika key for higher-limit DEX market fallbacks. */
  dexpaprikaApiKey: process.env.DEXPAPRIKA_API_KEY ?? "",
  /** Optional server-only Jupiter Developer Platform key for Solana token intelligence. */
  jupiterApiKey: process.env.JUPITER_API_KEY ?? "",
  /** Optional CoinGecko demo API key for higher-limit token metadata/price lookups. CoinGecko's contract-lookup endpoint works with zero key at a lower rate limit, so this only improves reliability - never gates a feature. */
  coingeckoApiKey: process.env.COINGECKO_API_KEY ?? "",
  /** Optional server-only BscScan key for BSC contract/token verification lookups. Free tier from bscscan.com/myapikey; safe to set as a plain env var, not a signing secret. */
  bscscanApiKey: process.env.BSCSCAN_API_KEY ?? "",
  /**
   * Optional OKX Web3/DEX API credentials. Unlike BscScan/Jupiter, OKX's DEX
   * endpoints require ALL FOUR of these for a signed request (HMAC-SHA256 of
   * timestamp+method+path+body using the secret) - a bare API key alone is
   * not sufficient. Public endpoints (e.g. the spot ticker) need none of
   * these. Get all four from the OKX Developer Portal (web3.okx.com).
   */
  okxApiKey: process.env.OKX_API_KEY ?? "",
  okxApiSecret: process.env.OKX_SECRET_KEY ?? "",
  okxApiPassphrase: process.env.OKX_API_PASSPHRASE ?? "",
  okxProjectId: process.env.OKX_PROJECT_ID ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  /** Real object storage for production (S3, or R2/any S3-compatible service via s3Endpoint). */
  s3Bucket: process.env.S3_BUCKET ?? "",
  s3Region: process.env.S3_REGION ?? "auto",
  s3AccessKeyId: process.env.S3_ACCESS_KEY_ID ?? "",
  s3SecretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "",
  /** Only needed for R2/non-AWS S3-compatible providers - leave unset for real AWS S3. */
  s3Endpoint: process.env.S3_ENDPOINT ?? "",
  /**
   * Same EVM address receives fees on every EVM chain (per chains.ts, one
   * address across EVM networks) and is the server-owned source for all
   * PAXI fee payment verification and payment destinations.
   * PAXI_TREASURY_ADDRESS must be explicitly configured in the server environment.
   * No hard-coded production destination is provided.
   */
  paxiTreasuryAddress: process.env.PAXI_TREASURY_ADDRESS ?? "",
  /** Optional non-EVM treasury addresses. These are validated for display/configuration only; settlement remains disabled until chain-specific verification exists. */
  paxiSolanaTreasuryAddress: process.env.PAXI_SOLANA_TREASURY_ADDRESS ?? "",
  paxiBitcoinTreasuryAddress: process.env.PAXI_BITCOIN_TREASURY_ADDRESS ?? "",
};

validateTrustProxyHops(ENV.isProduction, process.env.TRUST_PROXY_HOPS);
