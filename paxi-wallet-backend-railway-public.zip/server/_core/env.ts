const parsedTrustProxyHops = Number(process.env.TRUST_PROXY_HOPS ?? "0");
const trustProxyHops = Number.isFinite(parsedTrustProxyHops)
  ? Math.max(0, Math.min(Math.floor(parsedTrustProxyHops), 10))
  : 0;

export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  databaseReadUrl:
    process.env.DATABASE_READ_URL ?? process.env.DATABASE_REPLICA_URL ?? "",
  /** Optional - Redis is a cache/coordination layer, not a source of truth. Every Redis-backed feature must degrade gracefully (fall back to MySQL/in-process behavior) when this is unset. */
  redisUrl: process.env.REDIS_URL ?? "",
  redisRequired: process.env.REDIS_REQUIRED === "true",
  redisTlsRequired: process.env.REDIS_TLS_REQUIRED === "true",
  workersEnabled: process.env.ENABLE_WORKERS !== "false",
  metricsToken: process.env.METRICS_TOKEN ?? "",
  trustProxyHops,
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  /** Optional server-only LI.FI key; never expose this through Vite client variables. */
  lifiApiKey: process.env.LIFI_API_KEY ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  /** Real object storage for production (S3, or R2/any S3-compatible service via s3Endpoint). */
  s3Bucket: process.env.S3_BUCKET ?? "",
  s3Region: process.env.S3_REGION ?? "auto",
  s3AccessKeyId: process.env.S3_ACCESS_KEY_ID ?? "",
  s3SecretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "",
  /** Only needed for R2/non-AWS S3-compatible providers - leave unset for real AWS S3. */
  s3Endpoint: process.env.S3_ENDPOINT ?? "",
  /**
   * Same EVM address receives fees on every EVM chain (per chains.ts, one
   * address across EVM networks) and is the server-owned source for all
   * PAXI fee payment verification and payment destinations.
   * Treasury and reward-vault destinations are configuration-only. An unset
   * value must remain empty so fee verification and reward fulfillment fail
   * closed instead of sending value to an embedded address.
   */
  paxiTreasuryAddress: process.env.PAXI_TREASURY_ADDRESS ?? "",
  /** RewardVault deposit recipient. The old escrow variable remains an alias for deployments already using it. */
  paxiRewardVaultAddress:
    process.env.PAXI_REWARD_VAULT_ADDRESS ??
    process.env.PAXI_REWARD_ESCROW_ADDRESS ??
    process.env.PAXI_TREASURY_ADDRESS ??
    "",
  paxiRewardEscrowAddress:
    process.env.PAXI_REWARD_VAULT_ADDRESS ??
    process.env.PAXI_REWARD_ESCROW_ADDRESS ??
    process.env.PAXI_TREASURY_ADDRESS ??
    "",
  /** Optional server-owned distributor signer used only for automated campaign payouts. Never expose to Vite/client code. */
  paxiPayoutPrivateKey: process.env.PAXI_PAYOUT_PRIVATE_KEY ?? "",
  paxiRewardDistributorAddress:
    process.env.PAXI_REWARD_DISTRIBUTOR_ADDRESS ?? "",
  paxiPayoutRpcUrl:
    process.env.PAXI_PAYOUT_RPC_URL ?? "https://bsc-rpc.publicnode.com",
  /** Gift Code secrets and per-chain fulfillment configuration; server-only. */
  giftCodeHashSecret:
    process.env.GIFT_CODE_HASH_SECRET ?? process.env.JWT_SECRET ?? "",
  giftCodeMaxAttemptsPerHour: Number(
    process.env.GIFT_CODE_MAX_ATTEMPTS_PER_HOUR ?? 10
  ),
  ethereumPayoutPrivateKey:
    process.env.ETHEREUM_PAYOUT_PRIVATE_KEY ??
    process.env.PAXI_PAYOUT_PRIVATE_KEY ??
    "",
  ethereumPayoutRpcUrl: process.env.ETHEREUM_PAYOUT_RPC_URL ?? "",
  polygonPayoutPrivateKey:
    process.env.POLYGON_PAYOUT_PRIVATE_KEY ??
    process.env.PAXI_PAYOUT_PRIVATE_KEY ??
    "",
  polygonPayoutRpcUrl: process.env.POLYGON_PAYOUT_RPC_URL ?? "",
  arbitrumPayoutPrivateKey:
    process.env.ARBITRUM_PAYOUT_PRIVATE_KEY ??
    process.env.PAXI_PAYOUT_PRIVATE_KEY ??
    "",
  arbitrumPayoutRpcUrl: process.env.ARBITRUM_PAYOUT_RPC_URL ?? "",
  solanaPayoutPrivateKey: process.env.SOLANA_PAYOUT_PRIVATE_KEY ?? "",
  solanaPayoutRpcUrl:
    process.env.SOLANA_PAYOUT_RPC_URL ?? "https://api.mainnet-beta.solana.com",
  bitcoinPayoutPrivateKey: process.env.BITCOIN_PAYOUT_PRIVATE_KEY ?? "",
  bitcoinRpcUrl: process.env.BITCOIN_RPC_URL ?? "",
  /** Optional server-only market-data credentials. */
  birdeyeApiKey: process.env.BIRDEYE_API_KEY ?? "",
  birdeyeApiBaseUrl:
    process.env.BIRDEYE_API_BASE_URL ?? "https://public-api.birdeye.so",
  /** Optional self-hosted/contracted DexScanner endpoint; disabled when unset. */
  dexScannerApiBaseUrl: process.env.DEXSCANNER_API_BASE_URL ?? "",
  dexScannerApiKey: process.env.DEXSCANNER_API_KEY ?? "",
  /** Optional server-only Moralis security intelligence key. */
  moralisApiKey: process.env.MORALIS_API_KEY ?? "",
};
