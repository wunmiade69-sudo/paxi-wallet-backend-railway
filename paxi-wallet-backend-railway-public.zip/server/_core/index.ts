import "dotenv/config";
import express from "express";
import type { NextFunction, Request, Response } from "express";
import { sql } from "drizzle-orm";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerDevLoginRoute } from "./devAuth";
import { registerBlockscoutProxyRoute } from "./blockscoutProxy";
import { registerLifiProxyRoute } from "./lifiProxy";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { startMarketDataPrewarm } from "../marketData";
import { startWorkers } from "../workers";
import { registerPublicMarketApi } from "../publicMarketApi";
import { closeDbPools, getDb } from "../db";
import { stopWorkers } from "../workers";
import { ENV } from "./env";
import { metricsMiddleware, metricsText } from "./metrics";
import { distributedTrpcRateLimit } from "./distributedRateLimit";
import { getRedisHealth, redisSafe } from "../redis";
import { isSameOriginMutation } from "./requestSecurity";

function validateStartupConfig() {
  if (!ENV.isProduction) return;
  const required = [
    ["DATABASE_URL", ENV.databaseUrl],
    ["JWT_SECRET", ENV.cookieSecret],
    ["VITE_APP_ID", ENV.appId],
    ["OAUTH_SERVER_URL", ENV.oAuthServerUrl],
  ] as const;
  const missing = required.filter(([, value]) => !value).map(([name]) => name);
  if (missing.length > 0) {
    throw new Error(`Missing required production configuration: ${missing.join(", ")}`);
  }
  if (ENV.cookieSecret.length < 32) {
    throw new Error("JWT_SECRET must be at least 32 characters in production");
  }
  if (!ENV.redisUrl) {
    if (ENV.redisRequired) throw new Error("REDIS_URL is required when REDIS_REQUIRED=true");
    console.warn("[startup] REDIS_URL is not configured; distributed rate limits and BullMQ workers are disabled");
  }
  if (ENV.redisTlsRequired && ENV.redisUrl && !ENV.redisUrl.startsWith("rediss://")) {
    throw new Error("REDIS_TLS_REQUIRED=true requires a rediss:// REDIS_URL");
  }
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  validateStartupConfig();
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", ENV.trustProxyHops);
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
    res.setHeader("Cross-Origin-Resource-Policy", "same-site");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader("Content-Security-Policy", "base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self' https:");
    res.setHeader("X-DNS-Prefetch-Control", "off");
    if (ENV.isProduction && req.secure) {
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    next();
  });
  app.use(metricsMiddleware);
  const server = createServer(app);
  // Keep global parsers bounded; route-specific upload/proxy parsers apply tighter limits.
  app.use(express.json({ limit: "1mb", strict: true }));
  app.use(express.urlencoded({ limit: "256kb", extended: true, parameterLimit: 100 }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  registerDevLoginRoute(app);
  registerBlockscoutProxyRoute(app);
  registerLifiProxyRoute(app);
  registerPublicMarketApi(app);

  app.get("/healthz", async (_req, res) => {
    const redis = await getRedisHealth();
    // /healthz is a liveness endpoint: an optional Redis outage is reported
    // as degraded data, not as an application failure or credential leak.
    res.json({ ok: true, service: "paxi-wallet", redis: { status: redis } });
  });
  app.get("/metrics", (req, res) => {
    if (!ENV.metricsToken || req.header("authorization") !== `Bearer ${ENV.metricsToken}`) {
      res.status(404).end();
      return;
    }
    res.type("text/plain").send(metricsText());
  });
  app.get("/readyz", async (_req, res) => {
    const db = await getDb();
    if (!db) {
      res.status(503).json({ ok: false, database: false });
      return;
    }
    try {
      await db.execute(sql`SELECT 1`);
      const redisOk = ENV.redisRequired ? (await redisSafe((client) => client.ping())) === "PONG" : true;
      if (!redisOk) {
        res.status(503).json({ ok: false, database: true, redis: false });
        return;
      }
      res.json({ ok: true, database: true, ...(ENV.redisRequired ? { redis: true } : {}) });
    } catch {
      res.status(503).json({ ok: false, database: false, ...(ENV.redisRequired ? { redis: false } : {}) });
    }
  });

  // tRPC API
  app.use("/api/trpc", (req, res, next) => {
    if (!isSameOriginMutation(req)) {
      res.status(403).json({ error: "Cross-site request blocked" });
      return;
    }
    next();
  });
  app.use("/api/trpc", distributedTrpcRateLimit);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  app.use((error: unknown, _req: Request, res: Response, next: NextFunction) => {
    if (res.headersSent) {
      next(error);
      return;
    }
    const status = typeof error === "object" && error !== null && "status" in error && typeof (error as { status?: unknown }).status === "number"
      ? (error as { status: number }).status
      : 500;
    const isPayloadTooLarge = typeof error === "object" && error !== null && "type" in error && (error as { type?: unknown }).type === "entity.too.large";
    if (isPayloadTooLarge) {
      res.status(413).json({ error: "Request payload too large" });
      return;
    }
    console.error("[http] unhandled request error", status);
    res.status(status >= 400 && status < 600 ? status : 500).json({ error: "Internal server error" });
  });

  // Never silently move a production listener to another port; deployment health checks
  // must fail loudly if the configured port cannot be bound. Development retains auto-port
  // selection for local convenience.
  const preferredPort = Number.parseInt(process.env.PORT || "3000", 10);
  const port = ENV.isProduction ? preferredPort : await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  await new Promise<void>((resolve, reject) => {
    const onError = (error: NodeJS.ErrnoException) => {
      server.off("listening", onListening);
      reject(error);
    };
    const onListening = () => {
      server.off("error", onError);
      console.log(`Server running on http://localhost:${port}/`);
      resolve();
    };
    server.once("error", onError);
    server.once("listening", onListening);
    server.listen(port);
  });

  // Defer warm-up until the listener is accepting traffic. A prewarm outage must never
  // prevent health checks or public requests from being served. Isolated test runs can
  // disable provider prewarming without changing the production default.
  if (ENV.marketPrewarmEnabled) setTimeout(() => startMarketDataPrewarm(), 1000).unref();
  else console.warn("[startup] ENABLE_MARKET_PREWARM=false; market prewarming is disabled");

  // Phase 3B - Start background workers for market data refreshes,
  // metadata discovery, and historical candle generation.
  if (ENV.workersEnabled) startWorkers();
  else console.warn("[startup] ENABLE_WORKERS=false; background workers are disabled by configuration");

  let shuttingDown = false;
  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`[server] received ${signal}; shutting down`);
    await stopWorkers();
    await new Promise<void>((resolve) => server.close(() => resolve()));
    await closeDbPools();
    process.exit(0);
  };
  process.once("SIGTERM", () => void shutdown("SIGTERM"));
  process.once("SIGINT", () => void shutdown("SIGINT"));
}

  startServer().catch((error) => {
    console.error("[server] startup failed", error instanceof Error ? error.message : "unknown error");
    process.exitCode = 1;
  });
