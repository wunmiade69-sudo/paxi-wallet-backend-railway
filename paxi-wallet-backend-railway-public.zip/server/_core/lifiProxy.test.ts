import { describe, expect, it } from "vitest";
import {
  LIFI_INTEGRATOR,
  LIFI_CHAIN_IDS,
  buildLifiUpstreamQuery,
  lifiFeeDecimalFromBps,
  parseLifiFeeDecimal,
  validateLifiFeeBps,
} from "./lifiProxy";

const EVM_TOKEN = "0x0000000000000000000000000000000000000000";
const EVM_ADDRESS = "0x0000000000000000000000000000000000000001";
const SOLANA_TOKEN = "So11111111111111111111111111111111111111112";
const SOLANA_ADDRESS = "11111111111111111111111111111111";

function quoteInput(overrides: Record<string, string> = {}) {
  return {
    path: "/quote",
    fromChain: String(LIFI_CHAIN_IDS.ethereum),
    toChain: String(LIFI_CHAIN_IDS.bsc),
    fromToken: EVM_TOKEN,
    toToken: EVM_TOKEN,
    fromAddress: EVM_ADDRESS,
    toAddress: EVM_ADDRESS,
    fromAmount: "1000000000000000000",
    slippage: "0.01",
    integrator: LIFI_INTEGRATOR,
    fee: "0.008",
    ...overrides,
  };
}

describe("LI.FI proxy fee authority and validation", () => {
  it("converts basis points to LI.FI decimal percentage units", () => {
    expect(lifiFeeDecimalFromBps(80)).toBe("0.008");
    expect(parseLifiFeeDecimal("0.008")).toBe(80);
  });

  it("rejects non-integer, negative, and excessive configured rates", () => {
    expect(() => validateLifiFeeBps(80.5)).toThrow(
      "Invalid bridge fee configuration"
    );
    expect(() => validateLifiFeeBps(-1)).toThrow(
      "Invalid bridge fee configuration"
    );
    expect(() => validateLifiFeeBps(1001)).toThrow(
      "Invalid bridge fee configuration"
    );
  });

  it("writes the authoritative integrator and fee into a valid quote", () => {
    const query = buildLifiUpstreamQuery("/quote", quoteInput(), 80);
    expect(query.get("integrator")).toBe(LIFI_INTEGRATOR);
    expect(query.get("fee")).toBe("0.008");
    expect(query.get("fromChain")).toBe(String(LIFI_CHAIN_IDS.ethereum));
    expect(query.get("toChain")).toBe(String(LIFI_CHAIN_IDS.bsc));
  });

  it("rejects a client-supplied fee that differs from the server configuration", () => {
    expect(() =>
      buildLifiUpstreamQuery("/quote", quoteInput({ fee: "0.01" }), 80)
    ).toThrow("LI.FI fee configuration mismatch");
  });

  it("rejects an arbitrary upstream parameter or unsupported route chain", () => {
    expect(() =>
      buildLifiUpstreamQuery("/quote", quoteInput({ apiKey: "leak" }), 80)
    ).toThrow("Invalid or disallowed LI.FI query parameter");
    expect(() =>
      buildLifiUpstreamQuery("/quote", quoteInput({ fromChain: "137" }), 80)
    ).toThrow("Unsupported LI.FI fromChain");
  });

  it("validates Solana token and wallet addresses for the controlled route set", () => {
    const query = buildLifiUpstreamQuery(
      "/quote",
      {
        path: "/quote",
        fromChain: String(LIFI_CHAIN_IDS.solana),
        toChain: String(LIFI_CHAIN_IDS.ethereum),
        fromToken: SOLANA_TOKEN,
        toToken: EVM_TOKEN,
        fromAddress: SOLANA_ADDRESS,
        toAddress: EVM_ADDRESS,
        fromAmount: "1000000",
        slippage: "0.01",
        fee: "0.008",
      },
      80
    );
    expect(query.get("fromToken")).toBe(SOLANA_TOKEN);
    expect(query.get("fromAddress")).toBe(SOLANA_ADDRESS);
    expect(query.get("fee")).toBe("0.008");
  });

  it("keeps status requests read-only and does not accept fee overrides", () => {
    const query = buildLifiUpstreamQuery(
      "/status",
      { path: "/status", txHash: "0xabc123", bridge: "stargate" },
      80
    );
    expect(query.get("txHash")).toBe("0xabc123");
    expect(query.get("bridge")).toBe("stargate");
    expect(query.has("fee")).toBe(false);
  });
});
