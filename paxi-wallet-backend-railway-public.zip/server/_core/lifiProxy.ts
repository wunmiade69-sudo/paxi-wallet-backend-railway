import type { Express, Request, Response } from "express";
import { distributedProxyRateLimit } from "./distributedRateLimit";
import { ENV } from "./env";

const LIFI_BASE = "https://li.quest/v1";
const ALLOWED_PATHS = new Set(["/quote", "/status"]);
const MAX_UPSTREAM_BYTES = 4 * 1024 * 1024;

async function readLimitedText(response: globalThis.Response, maxBytes: number): Promise<string> {
  const declaredLength = Number(response.headers.get("content-length") ?? 0);
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) throw new Error("upstream response too large");
  if (!response.body) return "";

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new Error("upstream response too large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8");
}

/**
 * Keeps an optional LI.FI API key server-side. The client can request only
 * known read-only LI.FI resources; it cannot choose an arbitrary upstream URL
 * or proxy a write operation.
 */
export function registerLifiProxyRoute(app: Express) {
  app.get("/api/lifi-proxy", distributedProxyRateLimit, async (req: Request, res: Response) => {
    const path = typeof req.query.path === "string" ? req.query.path : "";
    if (!ALLOWED_PATHS.has(path)) {
      res.status(400).json({ error: "Invalid or disallowed LI.FI path" });
      return;
    }

    const query = new URLSearchParams();
    for (const [key, value] of Object.entries(req.query)) {
      if (key === "path" || typeof value !== "string" || value.length > 2048) continue;
      query.set(key, value);
    }

    try {
      const upstream = await fetch(`${LIFI_BASE}${path}?${query.toString()}`, {
        headers: {
          Accept: "application/json",
          ...(ENV.lifiApiKey ? { "x-lifi-api-key": ENV.lifiApiKey } : {}),
        },
        signal: AbortSignal.timeout(15_000),
      });
      const body = await readLimitedText(upstream, MAX_UPSTREAM_BYTES);
      res
        .status(upstream.status)
        .type(upstream.headers.get("content-type") ?? "application/json")
        .setHeader("Cache-Control", "no-store")
        .send(body);
    } catch {
      res.status(502).json({ error: "Upstream LI.FI request failed" });
    }
  });
}
