import type { Express, Request, Response } from "express";
import { getFeeConfig } from "../fees/feeEngine";
import { distributedProxyRateLimit } from "./distributedRateLimit";
import { ENV } from "./env";

const LIFI_BASE = "https://li.quest/v1";
const ALLOWED_PATHS = new Set(["/quote", "/status"]);
const MAX_UPSTREAM_BYTES = 4 * 1024 * 1024;
const MAX_QUERY_LENGTH = 8 * 1024;
const MAX_QUERY_VALUE_LENGTH = 512;
export const LIFI_INTEGRATOR = "paxiwallet";
export const MAX_LIFI_FEE_BPS = 1_000;
export const LIFI_CHAIN_IDS = {
  ethereum: 1,
  bsc: 56,
  solana: 1_151_111_081_099_710,
} as const;

const QUOTE_KEYS = new Set([
  "fromChain",
  "toChain",
  "fromToken",
  "toToken",
  "fromAddress",
  "toAddress",
  "fromAmount",
  "slippage",
  "integrator",
  "fee",
]);
const STATUS_KEYS = new Set([
  "txHash",
  "bridge",
  "bridgeCode",
  "fromChain",
  "toChain",
]);
const EVM_ADDRESS = /^0x[a-fA-F0-9]{40}$/;
const SOLANA_ADDRESS = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
const INTEGER = /^[0-9]+$/;
const DECIMAL = /^(?:0|[1-9][0-9]*)(?:\.[0-9]+)?$/;

export class LifiProxyInputError extends Error {}

async function readLimitedText(
  response: globalThis.Response,
  maxBytes: number
): Promise<string> {
  const declaredLength = Number(response.headers.get("content-length") ?? 0);
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes)
    throw new Error("upstream response too large");
  if (!response.body) return "";

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new Error("upstream response too large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks.map(chunk => Buffer.from(chunk))).toString(
    "utf8"
  );
}

function requireString(input: Record<string, unknown>, key: string): string {
  const value = input[key];
  if (
    typeof value !== "string" ||
    value.length === 0 ||
    value.length > MAX_QUERY_VALUE_LENGTH
  ) {
    throw new LifiProxyInputError(`Invalid LI.FI ${key}`);
  }
  return value;
}

function assertAllowedKeys(
  input: Record<string, unknown>,
  allowed: Set<string>
): void {
  for (const [key, value] of Object.entries(input)) {
    if (key === "path") continue;
    if (!allowed.has(key) || typeof value !== "string") {
      throw new LifiProxyInputError(
        "Invalid or disallowed LI.FI query parameter"
      );
    }
  }
}

function parseChainId(value: string, field: string): number {
  if (!INTEGER.test(value))
    throw new LifiProxyInputError(`Invalid LI.FI ${field}`);
  const chainId = Number(value);
  if (
    !Number.isSafeInteger(chainId) ||
    !Object.values(LIFI_CHAIN_IDS).includes(chainId as never)
  ) {
    throw new LifiProxyInputError(`Unsupported LI.FI ${field}`);
  }
  return chainId;
}

function isSolanaChain(chainId: number): boolean {
  return chainId === LIFI_CHAIN_IDS.solana;
}

function validateAddress(
  value: string,
  field: string,
  chainId: number
): string {
  const valid = isSolanaChain(chainId)
    ? SOLANA_ADDRESS.test(value)
    : EVM_ADDRESS.test(value);
  if (!valid) throw new LifiProxyInputError(`Invalid LI.FI ${field}`);
  return value;
}

function validateToken(value: string, field: string, chainId: number): string {
  return validateAddress(value, field, chainId);
}

function parsePositiveInteger(value: string, field: string): string {
  if (!INTEGER.test(value) || BigInt(value) <= 0n) {
    throw new LifiProxyInputError(`Invalid LI.FI ${field}`);
  }
  return value;
}

function parseSlippage(value: string): string {
  if (!DECIMAL.test(value))
    throw new LifiProxyInputError("Invalid LI.FI slippage");
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0.001 || parsed > 0.05) {
    throw new LifiProxyInputError("Invalid LI.FI slippage");
  }
  return value;
}

export function validateLifiFeeBps(value: unknown): number {
  if (
    typeof value !== "number" ||
    !Number.isInteger(value) ||
    value < 0 ||
    value > MAX_LIFI_FEE_BPS
  ) {
    throw new Error("Invalid bridge fee configuration");
  }
  return value;
}

export function lifiFeeDecimalFromBps(feeBps: number): string {
  const validated = validateLifiFeeBps(feeBps);
  return (validated / 10_000).toString();
}

export function parseLifiFeeDecimal(value: string): number {
  if (!DECIMAL.test(value)) throw new LifiProxyInputError("Invalid LI.FI fee");
  const [whole, fractional = ""] = value.split(".");
  if (fractional.length > 4)
    throw new LifiProxyInputError("Invalid LI.FI fee precision");
  const feeBps = Number(
    BigInt(whole) * 10_000n + BigInt(fractional.padEnd(4, "0") || "0")
  );
  return validateLifiFeeBps(feeBps);
}

/**
 * Builds a canonical upstream query. The client may display the server fee and
 * send it back, but the server rejects mismatches and always writes the
 * authoritative integrator and fee values into the upstream request.
 */
export function buildLifiUpstreamQuery(
  path: string,
  rawInput: Record<string, unknown>,
  authoritativeFeeBps: number
): URLSearchParams {
  if (!ALLOWED_PATHS.has(path))
    throw new LifiProxyInputError("Invalid or disallowed LI.FI path");
  const authoritative = validateLifiFeeBps(authoritativeFeeBps);
  const allowed = path === "/quote" ? QUOTE_KEYS : STATUS_KEYS;
  assertAllowedKeys(rawInput, allowed);
  const query = new URLSearchParams();

  if (path === "/status") {
    const txHash = requireString(rawInput, "txHash");
    if (!/^[A-Za-z0-9:_-]{1,256}$/.test(txHash)) {
      throw new LifiProxyInputError("Invalid LI.FI transaction hash");
    }
    query.set("txHash", txHash);
    for (const key of ["bridge", "bridgeCode", "fromChain", "toChain"]) {
      if (rawInput[key] !== undefined)
        query.set(key, requireString(rawInput, key));
    }
    return query;
  }

  const fromChain = parseChainId(
    requireString(rawInput, "fromChain"),
    "fromChain"
  );
  const toChain = parseChainId(requireString(rawInput, "toChain"), "toChain");
  for (const [key, value] of [
    ["fromChain", String(fromChain)],
    ["toChain", String(toChain)],
    [
      "fromToken",
      validateToken(
        requireString(rawInput, "fromToken"),
        "fromToken",
        fromChain
      ),
    ],
    [
      "toToken",
      validateToken(requireString(rawInput, "toToken"), "toToken", toChain),
    ],
    [
      "fromAddress",
      validateAddress(
        requireString(rawInput, "fromAddress"),
        "fromAddress",
        fromChain
      ),
    ],
    [
      "toAddress",
      validateAddress(
        requireString(rawInput, "toAddress"),
        "toAddress",
        toChain
      ),
    ],
    [
      "fromAmount",
      parsePositiveInteger(requireString(rawInput, "fromAmount"), "fromAmount"),
    ],
    ["slippage", parseSlippage(requireString(rawInput, "slippage"))],
  ] as const) {
    query.set(key, value);
  }

  if (
    rawInput.integrator !== undefined &&
    rawInput.integrator !== LIFI_INTEGRATOR
  ) {
    throw new LifiProxyInputError("Invalid LI.FI integrator");
  }
  if (
    rawInput.fee !== undefined &&
    parseLifiFeeDecimal(requireString(rawInput, "fee")) !== authoritative
  ) {
    throw new LifiProxyInputError("LI.FI fee configuration mismatch");
  }
  query.set("integrator", LIFI_INTEGRATOR);
  query.set("fee", lifiFeeDecimalFromBps(authoritative));
  return query;
}

/**
 * Keeps an optional LI.FI API key server-side. The client can request only
 * known read-only LI.FI resources; it cannot choose an arbitrary upstream URL,
 * alter the server-owned integrator fee, or proxy a write operation.
 */
export function registerLifiProxyRoute(app: Express) {
  app.get(
    "/api/lifi-proxy",
    distributedProxyRateLimit,
    async (req: Request, res: Response) => {
      if (req.originalUrl.length > MAX_QUERY_LENGTH) {
        res.status(413).json({ error: "LI.FI request is too large" });
        return;
      }
      const path = typeof req.query.path === "string" ? req.query.path : "";
      let authoritativeFeeBps: number;
      try {
        authoritativeFeeBps = validateLifiFeeBps(
          (await getFeeConfig("bridge", "any")).percentageBps
        );
      } catch {
        res.status(503).json({ error: "Bridge fee configuration unavailable" });
        return;
      }

      let query: URLSearchParams;
      try {
        query = buildLifiUpstreamQuery(
          path,
          req.query as Record<string, unknown>,
          authoritativeFeeBps
        );
      } catch (error) {
        const message =
          error instanceof LifiProxyInputError
            ? error.message
            : "Invalid LI.FI request";
        res.status(400).json({ error: message });
        return;
      }

      try {
        const upstream = await fetch(
          `${LIFI_BASE}${path}?${query.toString()}`,
          {
            headers: {
              Accept: "application/json",
              ...(ENV.lifiApiKey ? { "x-lifi-api-key": ENV.lifiApiKey } : {}),
            },
            signal: AbortSignal.timeout(15_000),
          }
        );
        const body = await readLimitedText(upstream, MAX_UPSTREAM_BYTES);
        res
          .status(upstream.status)
          .type(upstream.headers.get("content-type") ?? "application/json")
          .setHeader("Cache-Control", "no-store")
          .send(body);
      } catch {
        res.status(502).json({ error: "Upstream LI.FI request failed" });
      }
    }
  );
}
