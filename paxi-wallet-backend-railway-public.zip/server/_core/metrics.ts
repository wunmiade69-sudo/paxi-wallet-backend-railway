import type { NextFunction, Request, Response } from "express";

interface MetricValue {
  count: number;
  errorCount: number;
  totalDurationMs: number;
}

const metrics = new Map<string, MetricValue>();

function routeKey(req: Request): string {
  const prefix = req.path.startsWith("/api/assets") ? "/api/assets" : req.path.startsWith("/api/chains") ? "/api/chains" : req.path;
  return `${req.method.toLowerCase()}_${prefix.replace(/[^a-zA-Z0-9_]/g, "_") || "root"}`;
}

export function metricsMiddleware(req: Request, res: Response, next: NextFunction) {
  const start = process.hrtime.bigint();
  const key = routeKey(req);
  const originalEnd = res.end;
  res.end = function end(this: Response, ...args: Parameters<Response["end"]>) {
    const durationMs = Number(process.hrtime.bigint() - start) / 1_000_000;
    const current = metrics.get(key) ?? { count: 0, errorCount: 0, totalDurationMs: 0 };
    current.count += 1;
    if (res.statusCode >= 500) current.errorCount += 1;
    current.totalDurationMs += durationMs;
    metrics.set(key, current);
    return originalEnd.apply(this, args);
  } as Response["end"];
  next();
}

export function metricsText(): string {
  const lines = [
    "# HELP paxi_http_requests_total Total HTTP requests by method and route family",
    "# TYPE paxi_http_requests_total counter",
  ];
  for (const [route, value] of metrics) {
    lines.push(`paxi_http_requests_total{route=\"${route}\"} ${value.count}`);
    lines.push(`paxi_http_errors_total{route=\"${route}\"} ${value.errorCount}`);
    lines.push(`paxi_http_duration_ms_sum{route=\"${route}\"} ${value.totalDurationMs.toFixed(2)}`);
  }
  return `${lines.join("\n")}\n`;
}
