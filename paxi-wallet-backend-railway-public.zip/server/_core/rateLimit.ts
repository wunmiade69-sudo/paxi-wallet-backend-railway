import type { NextFunction, Request, Response } from "express";

interface Bucket {
  windowStartedAt: number;
  count: number;
}

export interface RateLimitOptions {
  windowMs: number;
  maxRequests: number;
  keyPrefix: string;
}

function clientKey(req: Request): string {
  // Express req.ip is trusted only according to app.set("trust proxy", ...).
  // Do not read x-forwarded-for directly: clients can forge it when no trusted proxy is configured.
  return (req.ip ?? req.socket.remoteAddress ?? "unknown")
    .replace(/[^a-zA-Z0-9:._-]/g, "_");
}

export function createLocalRateLimiter(options: RateLimitOptions) {
  const buckets = new Map<string, Bucket>();
  const cleanup = setInterval(() => {
    const cutoff = Date.now() - options.windowMs;
    for (const [key, bucket] of buckets) {
      if (bucket.windowStartedAt < cutoff) buckets.delete(key);
    }
  }, Math.min(options.windowMs, 60_000));
  cleanup.unref();

  return function localRateLimit(req: Request, res: Response, next: NextFunction) {
    const now = Date.now();
    const key = `${options.keyPrefix}:${clientKey(req)}`;
    const current = buckets.get(key);
    const bucket = !current || now - current.windowStartedAt >= options.windowMs
      ? { windowStartedAt: now, count: 0 }
      : current;

    bucket.count += 1;
    buckets.set(key, bucket);
    res.setHeader("X-RateLimit-Limit", String(options.maxRequests));
    res.setHeader("X-RateLimit-Remaining", String(Math.max(0, options.maxRequests - bucket.count)));

    if (bucket.count > options.maxRequests) {
      const retryAfter = Math.max(1, Math.ceil((options.windowMs - (now - bucket.windowStartedAt)) / 1000));
      res.setHeader("Retry-After", String(retryAfter));
      res.status(429).json({ error: "Rate limit exceeded", retryAfterSeconds: retryAfter });
      return;
    }

    next();
  };
}

export const publicApiRateLimit = createLocalRateLimiter({
  windowMs: 60_000,
  maxRequests: 120,
  keyPrefix: "public-api",
});

export const authRateLimit = createLocalRateLimiter({
  windowMs: 5 * 60_000,
  maxRequests: 30,
  keyPrefix: "auth",
});

export const proxyRateLimit = createLocalRateLimiter({
  windowMs: 60_000,
  maxRequests: 120,
  keyPrefix: "proxy",
});

export const healthRateLimit = createLocalRateLimiter({
  windowMs: 60_000,
  maxRequests: 120,
  keyPrefix: "health",
});
