import type { Request } from "express";
import { ENV } from "./env";

export function isSameOriginMutation(req: Request): boolean {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) return true;
  const source = req.get("origin") ?? (req.get("referer") ? (() => { try { return new URL(req.get("referer")!).origin; } catch { return ""; } })() : "");
  if (!source) return !ENV.isProduction || req.get("authorization")?.startsWith("Bearer ") === true;
  try {
    return new URL(source).host === req.get("host") && new URL(source).protocol === `${req.protocol}:`;
  } catch {
    return false;
  }
}
