import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";

/**
 * Upserts the user row and mints + sets the same session cookie the OAuth
 * callback and dev-login route issue. Shared so every login path (Manus
 * OAuth, dev bypass, wallet-signature login) produces an identical,
 * `authenticateRequest`-compatible session - no duplicated JWT/cookie logic
 * to drift out of sync.
 */
export async function issueSession(
  req: Request,
  res: Response,
  openId: string,
  name: string,
  options: { loginMethod?: string | null; role?: "user" | "admin"; email?: string | null } = {},
): Promise<void> {
  await db.upsertUser({
    openId,
    name: name || null,
    email: options.email ?? null,
    loginMethod: options.loginMethod ?? null,
    lastSignedIn: new Date(),
    ...(options.role ? { role: options.role } : {}),
  });

  const sessionToken = await sdk.createSessionToken(openId, { name, expiresInMs: ONE_YEAR_MS });
  const cookieOptions = getSessionCookieOptions(req);
  res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
}
