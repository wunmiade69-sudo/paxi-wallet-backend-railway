import type { Express } from "express";
import { existsSync } from "fs";
import { and, eq, gte, isNotNull, isNull, lte, or } from "drizzle-orm";
import { campaigns, tokenListings } from "../../drizzle/schema";
import { getReadDb } from "../db";
import { ENV } from "./env";
import { isForgeConfigured, isS3Configured, localStoragePath, storageGetSignedUrl } from "../storage";

const CAMPAIGN_ASSET_KEY = /^campaign-assets\/campaign\/(\d+)\/(banner|icon)\.(png|jpe?g|webp)$/i;

async function canServeStorageKey(key: string): Promise<boolean> {
  const match = CAMPAIGN_ASSET_KEY.exec(key);
  if (!match) return true;
  const campaignId = Number(match[1]);
  if (!Number.isSafeInteger(campaignId) || campaignId <= 0) return false;
  const db = await getReadDb();
  if (!db) return false;
  const now = new Date();
  const [row] = await db
    .select({ bannerKey: campaigns.bannerKey, iconKey: campaigns.iconKey })
    .from(campaigns)
    .innerJoin(tokenListings, eq(campaigns.listingId, tokenListings.id))
    .where(and(
      eq(campaigns.id, campaignId),
      eq(campaigns.status, "active"),
      isNotNull(campaigns.rewardEscrowFundedTxHash),
      eq(tokenListings.status, "verified"),
      or(isNull(campaigns.startAt), lte(campaigns.startAt, now)),
      or(isNull(campaigns.endAt), gte(campaigns.endAt, now)),
    ))
    .limit(1);
  return Boolean(row && (row.bannerKey === key || row.iconKey === key));
}

export function registerStorageProxy(app: Express) {
  app.get("/manus-storage/{*key}", async (req, res) => {
    const key = (req.params as Record<string, string>).key;
    if (!key) {
      res.status(400).send("Missing storage key");
      return;
    }

    try {
      if (!(await canServeStorageKey(key))) {
        res.status(404).send("Not found");
        return;
      }
    } catch (error) {
      console.error("[StorageProxy] visibility check failed:", error);
      res.status(404).send("Not found");
      return;
    }

    if (isForgeConfigured()) {
      try {
        const forgeUrl = new URL("v1/storage/presign/get", ENV.forgeApiUrl.replace(/\/+$/, "") + "/");
        forgeUrl.searchParams.set("path", key);
        const forgeResp = await fetch(forgeUrl, { headers: { Authorization: `Bearer ${ENV.forgeApiKey}` } });
        if (!forgeResp.ok) {
          const body = await forgeResp.text().catch(() => "");
          console.error(`[StorageProxy] forge error: ${forgeResp.status} ${body}`);
          res.status(502).send("Storage backend error");
          return;
        }
        const { url } = (await forgeResp.json()) as { url: string };
        if (!url) {
          res.status(502).send("Empty signed URL from backend");
          return;
        }
        res.set("Cache-Control", "no-store");
        res.redirect(307, url);
      } catch (err) {
        console.error("[StorageProxy] forge failed:", err);
        res.status(502).send("Storage proxy error");
      }
      return;
    }

    if (isS3Configured()) {
      try {
        const signedUrl = await storageGetSignedUrl(key);
        res.set("Cache-Control", "no-store");
        res.redirect(307, signedUrl);
      } catch (err) {
        console.error("[StorageProxy] S3 failed:", err);
        res.status(502).send("Storage proxy error");
      }
      return;
    }

    // Standalone/local mode (e.g. Termux) - storagePut wrote this file straight
    // to disk, so serve it back the same way.
    const filePath = localStoragePath(key);
    if (!existsSync(filePath)) {
      res.status(404).send("Not found");
      return;
    }
    res.set("Cache-Control", "no-store");
    res.sendFile(filePath);
  });
}
