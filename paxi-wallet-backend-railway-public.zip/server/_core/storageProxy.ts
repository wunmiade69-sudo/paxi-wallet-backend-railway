import type { Express } from "express";
import { existsSync } from "fs";
import { ENV } from "./env";
import { isForgeConfigured, isS3Configured, localStoragePath, storageGetSignedUrl } from "../storage";

export function registerStorageProxy(app: Express) {
  app.get("/manus-storage/{*key}", async (req, res) => {
    const key = (req.params as Record<string, string>).key;
    if (!key) {
      res.status(400).send("Missing storage key");
      return;
    }

    if (isForgeConfigured()) {
      try {
        const forgeUrl = new URL("v1/storage/presign/get", ENV.forgeApiUrl.replace(/\/+$/, "") + "/");
        forgeUrl.searchParams.set("path", key);
        const forgeResp = await fetch(forgeUrl, { headers: { Authorization: `Bearer ${ENV.forgeApiKey}` } });
        if (!forgeResp.ok) {
          const body = await forgeResp.text().catch(() => "");
          console.error(`[StorageProxy] forge error: ${forgeResp.status} ${body}`);
          res.status(502).send("Storage backend error");
          return;
        }
        const { url } = (await forgeResp.json()) as { url: string };
        if (!url) {
          res.status(502).send("Empty signed URL from backend");
          return;
        }
        res.set("Cache-Control", "no-store");
        res.redirect(307, url);
      } catch (err) {
        console.error("[StorageProxy] forge failed:", err);
        res.status(502).send("Storage proxy error");
      }
      return;
    }

    if (isS3Configured()) {
      try {
        const signedUrl = await storageGetSignedUrl(key);
        res.set("Cache-Control", "no-store");
        res.redirect(307, signedUrl);
      } catch (err) {
        console.error("[StorageProxy] S3 failed:", err);
        res.status(502).send("Storage proxy error");
      }
      return;
    }

    // Standalone/local mode (e.g. Termux) - storagePut wrote this file straight
    // to disk, so serve it back the same way.
    const filePath = localStoragePath(key);
    if (!existsSync(filePath)) {
      res.status(404).send("Not found");
      return;
    }
    res.set("Cache-Control", "no-store");
    res.sendFile(filePath);
  });
}
