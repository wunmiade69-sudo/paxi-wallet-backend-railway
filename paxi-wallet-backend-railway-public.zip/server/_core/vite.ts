import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import { nanoid } from "nanoid";
import path from "path";
import { createServer as createViteServer } from "vite";
import viteConfig from "../../vite.config";

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("/{*splat}", async (req, res, next) => {
    const url = req.originalUrl;
    const requestPath = url.split("?", 1)[0];

    try {
      const workspaceEntry = requestPath === "/admin.html"
        ? { html: "admin.html", script: "/src/admin-main.tsx" }
        : requestPath === "/project.html"
          ? { html: "project.html", script: "/src/project-main.tsx" }
          : { html: "index.html", script: "/src/main.tsx" };
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
        workspaceEntry.html
      );

      // Always reload the requested entry template from disk in case it changes.
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="${workspaceEntry.script}"`,
        `src="${workspaceEntry.script}?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath =
    process.env.NODE_ENV === "development"
      ? path.resolve(import.meta.dirname, "../..", "dist", "public")
      : path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }

  app.use(express.static(distPath));

  // fall through to index.html if the file doesn't exist
  app.use("/{*splat}", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
