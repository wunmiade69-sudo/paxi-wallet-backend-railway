import { adminAuditEvents } from "../drizzle/schema";
import { getDb } from "./db";

export async function recordAdminAuditEvent(input: {
  actorOpenId: string;
  action: string;
  resourceType: string;
  resourceId?: number | null;
  details?: Record<string, unknown>;
}): Promise<void> {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(adminAuditEvents).values({
      actorOpenId: input.actorOpenId,
      action: input.action,
      resourceType: input.resourceType,
      resourceId: input.resourceId ?? null,
      details: input.details,
    });
  } catch (error) {
    console.error("[admin-audit] failed to record event", {
      action: input.action,
      resourceType: input.resourceType,
      resourceId: input.resourceId,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}
