import { adminAuditEvents } from "../drizzle/schema";
import { getDb } from "./db";
import { getAdminRole, type AdminRole } from "./adminRbac";
import type { TrpcContext } from "./_core/context";

export type AdminAuditInput = {
  action: string;
  resourceType: string;
  resourceId?: number | null;
  result?: "success" | "failure" | "denied";
  reason?: string | null;
  details?: Record<string, unknown>;
  previousState?: Record<string, unknown>;
  newState?: Record<string, unknown>;
};

function safeRequestMetadata(ctx?: Pick<TrpcContext, "req">): Record<string, string | null> {
  const requestIdHeader = ctx?.req.headers["x-request-id"];
  const userAgentHeader = ctx?.req.headers["user-agent"];
  const forwardedForHeader = ctx?.req.headers["x-forwarded-for"];
  return {
    requestId: typeof requestIdHeader === "string" ? requestIdHeader.slice(0, 128) : null,
    userAgent: typeof userAgentHeader === "string" ? userAgentHeader.slice(0, 256) : null,
    ip: typeof forwardedForHeader === "string"
      ? forwardedForHeader.split(",")[0]?.trim().slice(0, 64) || null
      : ctx?.req.socket.remoteAddress?.slice(0, 64) ?? null,
  };
}

export async function recordAdminAudit(
  ctx: Pick<TrpcContext, "user" | "req">,
  input: AdminAuditInput,
): Promise<void> {
  const db = await getDb();
  if (!db || !ctx.user) return;
  const role: AdminRole | null = getAdminRole(ctx.user);
  await db.insert(adminAuditEvents).values({
    actorOpenId: ctx.user.openId,
    actorRole: role,
    action: input.action,
    resourceType: input.resourceType,
    resourceId: input.resourceId ?? null,
    details: input.details,
    result: input.result ?? "success",
    reason: input.reason ?? null,
    previousState: input.previousState,
    newState: input.newState,
    requestMetadata: safeRequestMetadata(ctx),
  });
}

export function auditFailureReason(error: unknown): string {
  return error instanceof Error ? error.message.slice(0, 500) : "Unknown administrative failure";
}
