import { describe, expect, it } from "vitest";
import { getAdminRole, hasAdminPermission, permissionsForAdminRole } from "./adminRbac";

describe("Phase 4 admin RBAC", () => {
  it("does not grant permissions to normal users even when an adminRole-looking value is supplied", () => {
    const user = { role: "user" as const, adminRole: "super_admin" };
    expect(getAdminRole(user)).toBeNull();
    expect(hasAdminPermission(user, "system.read")).toBe(false);
  });

  it("keeps legacy role=admin installations functional as a controlled super-admin compatibility path", () => {
    const user = { role: "admin" as const, adminRole: null };
    expect(getAdminRole(user)).toBe("super_admin");
    expect(hasAdminPermission(user, "audit.read")).toBe(true);
    expect(hasAdminPermission(user, "approvals.decide")).toBe(true);
  });

  it("enforces least privilege for an operations administrator", () => {
    const user = { role: "admin" as const, adminRole: "operations_admin" };
    expect(hasAdminPermission(user, "providers.read")).toBe(true);
    expect(hasAdminPermission(user, "campaigns.manage")).toBe(true);
    expect(hasAdminPermission(user, "users.manage")).toBe(false);
    expect(hasAdminPermission(user, "approvals.decide")).toBe(false);
  });

  it("returns explicit permissions for the audited role profile", () => {
    const permissions = permissionsForAdminRole("compliance_admin");
    expect(permissions).toContain("security.read");
    expect(permissions).toContain("approvals.decide");
    expect(permissions).not.toContain("system.manage");
  });

  it("keeps support administrators away from system control and approval execution", () => {
    const user = { role: "admin" as const, adminRole: "support_admin" };
    expect(hasAdminPermission(user, "users.manage")).toBe(true);
    expect(hasAdminPermission(user, "system.manage")).toBe(false);
    expect(hasAdminPermission(user, "approvals.decide")).toBe(false);
    expect(hasAdminPermission(user, "approvals.execute")).toBe(false);
  });

  it("keeps content administrators scoped to asset, campaign, and reward operations", () => {
    const user = { role: "admin" as const, adminRole: "content_admin" };
    expect(hasAdminPermission(user, "assets.manage")).toBe(true);
    expect(hasAdminPermission(user, "assets.verify")).toBe(true);
    expect(hasAdminPermission(user, "campaigns.manage")).toBe(true);
    expect(hasAdminPermission(user, "system.manage")).toBe(false);
    expect(hasAdminPermission(user, "approvals.decide")).toBe(false);
    expect(hasAdminPermission(user, "approvals.execute")).toBe(false);
  });

  it("keeps operations administrators unable to decide or execute approvals", () => {
    const user = { role: "admin" as const, adminRole: "operations_admin" };
    expect(hasAdminPermission(user, "approvals.request")).toBe(true);
    expect(hasAdminPermission(user, "approvals.decide")).toBe(false);
    expect(hasAdminPermission(user, "approvals.execute")).toBe(false);
    expect(hasAdminPermission(user, "users.manage")).toBe(false);
  });

  it("grants compliance decision authority without system control or execution", () => {
    const user = { role: "admin" as const, adminRole: "compliance_admin" };
    expect(hasAdminPermission(user, "approvals.decide")).toBe(true);
    expect(hasAdminPermission(user, "approvals.execute")).toBe(false);
    expect(hasAdminPermission(user, "system.manage")).toBe(false);
    expect(hasAdminPermission(user, "assets.manage")).toBe(false);
  });

  it("keeps approval execution exclusive to super administrators", () => {
    for (const adminRole of ["operations_admin", "support_admin", "compliance_admin", "content_admin"] as const) {
      expect(hasAdminPermission({ role: "admin", adminRole }, "approvals.execute")).toBe(false);
    }
    expect(hasAdminPermission({ role: "admin", adminRole: "super_admin" }, "approvals.execute")).toBe(true);
  });
});
