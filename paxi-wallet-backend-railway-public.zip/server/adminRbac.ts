import type { User } from "../drizzle/schema";

export const ADMIN_ROLES = [
  "super_admin",
  "operations_admin",
  "support_admin",
  "compliance_admin",
  "content_admin",
] as const;

export type AdminRole = (typeof ADMIN_ROLES)[number];

export const ADMIN_PERMISSIONS = [
  "users.read",
  "users.manage",
  "assets.read",
  "assets.manage",
  "assets.verify",
  "providers.read",
  "providers.manage",
  "transactions.read",
  "security.read",
  "campaigns.read",
  "campaigns.manage",
  "rewards.read",
  "rewards.manage",
  "notifications.manage",
  "system.read",
  "system.manage",
  "audit.read",
  "approvals.read",
  "approvals.request",
  "approvals.decide",
  "approvals.execute",
  "support.read",
  "support.manage",
] as const;

export type AdminPermission = (typeof ADMIN_PERMISSIONS)[number];

const ROLE_PERMISSIONS: Record<AdminRole, readonly AdminPermission[]> = {
  super_admin: ADMIN_PERMISSIONS,
  operations_admin: [
    "users.read",
    "assets.read",
    "providers.read",
    "transactions.read",
    "security.read",
    "campaigns.read",
    "campaigns.manage",
    "rewards.read",
    "rewards.manage",
    "notifications.manage",
    "system.read",
    "audit.read",
    "approvals.read",
    "approvals.request",
    "support.read",
  ],
  support_admin: [
    "users.read",
    "users.manage",
    "transactions.read",
    "notifications.manage",
    "system.read",
    "audit.read",
    "approvals.read",
    "approvals.request",
    "support.read",
    "support.manage",
  ],
  compliance_admin: [
    "users.read",
    "assets.read",
    "assets.verify",
    "providers.read",
    "transactions.read",
    "security.read",
    "campaigns.read",
    "rewards.read",
    "audit.read",
    "approvals.read",
    "approvals.request",
    "approvals.decide",
  ],
  content_admin: [
    "assets.read",
    "assets.manage",
    "assets.verify",
    "campaigns.read",
    "campaigns.manage",
    "rewards.read",
    "rewards.manage",
    "notifications.manage",
    "audit.read",
    "approvals.read",
    "approvals.request",
  ],
};

export function getAdminRole(user: Pick<User, "role"> & { adminRole?: string | null }): AdminRole | null {
  if (user.role !== "admin") return null;
  if (user.adminRole && (ADMIN_ROLES as readonly string[]).includes(user.adminRole)) {
    return user.adminRole as AdminRole;
  }
  // Existing installations only have role=admin. Keep those administrators
  // functional until the additive adminRole column is populated, but do not
  // grant admin permissions to normal users or client-supplied role claims.
  return "super_admin";
}

export function hasAdminPermission(
  user: Pick<User, "role"> & { adminRole?: string | null },
  permission: AdminPermission,
): boolean {
  const role = getAdminRole(user);
  return role ? ROLE_PERMISSIONS[role].includes(permission) : false;
}

export function permissionsForAdminRole(role: AdminRole): readonly AdminPermission[] {
  return ROLE_PERMISSIONS[role];
}

export function isAdminRole(value: string): value is AdminRole {
  return (ADMIN_ROLES as readonly string[]).includes(value);
}
