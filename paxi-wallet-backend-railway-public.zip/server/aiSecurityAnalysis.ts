import { fetchRawGoPlusToken } from "./contractSecurity";
import { getBscScanContractInfo } from "./providers/bscscan";
import { getEtherscanContractInfo } from "./providers/etherscan";
import { invokePaxiAI } from "./_core/llm";

/**
 * GoPlus's token_security response carries dozens of individual boolean/
 * numeric flags (proxy status, creator concentration, anti-whale, trading
 * cooldown, slippage-modifiable, self-destruct, external calls, blacklist,
 * whitelist, DEX liquidity per-pool, LP holder concentration, ...) that
 * getContractSecurity's point-deduction score deliberately reduces to a
 * handful it deducts from. Any of those flags can look individually benign
 * while the *combination* is a known rug/honeypot pattern a fixed formula
 * won't catch (e.g. a small, recently-added anti-whale limit + a
 * slippage-modifiable flag + a concentrated, unlocked LP position, on an
 * otherwise "verified" contract).
 *
 * This sends the full raw flag set - plus verified source code when
 * available - to an LLM and asks it to reason over the combination the way
 * a human security reviewer would. It is a second, probabilistic opinion,
 * not a replacement for the GoPlus-derived score: the result is always
 * labeled as AI-generated, with its own confidence figure, and never
 * silently merged into the deterministic score.
 */
export interface AiSecurityAnalysis {
  available: true;
  riskLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  summary: string;
  concerns: string[];
  reassurances: string[];
  confidencePercent: number;
  sourceCodeReviewed: boolean;
  model: string;
}

export interface AiSecurityUnavailable {
  available: false;
  reason: string;
}

const MAX_SOURCE_CHARS = 12_000; // keep prompt cost/latency bounded; enough for most single-file token contracts

const ANALYSIS_SCHEMA = {
  name: "contract_ai_security_analysis",
  schema: {
    type: "object",
    properties: {
      riskLevel: { type: "string", enum: ["LOW", "MEDIUM", "HIGH", "CRITICAL"] },
      summary: { type: "string", description: "One to two sentence plain-language summary of the overall assessment." },
      concerns: { type: "array", items: { type: "string" }, description: "Specific, concrete concerns found. Empty array if none." },
      reassurances: { type: "array", items: { type: "string" }, description: "Specific, concrete positive signals found. Empty array if none." },
      confidencePercent: { type: "integer", minimum: 0, maximum: 100, description: "Confidence in this assessment given the data actually available." },
    },
    required: ["riskLevel", "summary", "concerns", "reassurances", "confidencePercent"],
    additionalProperties: false,
  },
  strict: true,
} as const;

const SYSTEM_PROMPT = `You are a smart-contract security reviewer for a non-custodial crypto wallet. You are given raw, factual data about one ERC20/BEP20 token contract: automated scanner flags and, when available, verified Solidity source code. Your job is to reason over the COMBINATION of signals the way an experienced human reviewer would - individual flags can look benign in isolation but form a known scam/rug pattern together.

Rules:
- Base your assessment ONLY on the data provided. Never invent facts, holder numbers, or claims not present in the input.
- If source code is not provided, say so in your summary and lower your confidence accordingly - do not guess at code you cannot see.
- Be specific in "concerns" and "reassurances" - cite the actual flag or code pattern, not generic statements like "this could be risky."
- This is a probabilistic second opinion alongside a separate rule-based score, not a certification. Reflect appropriate uncertainty in confidencePercent.`;

function buildUserPrompt(params: {
  network: string;
  contractAddress: string;
  goPlusFlags: Record<string, unknown>;
  sourceCode: string | null;
  contractName: string | null;
}): string {
  const parts = [
    `Network: ${params.network}`,
    `Contract address: ${params.contractAddress}`,
    `Contract name (from verification): ${params.contractName ?? "unknown"}`,
    `\nAutomated scanner flags (GoPlus Security, raw JSON):\n${JSON.stringify(params.goPlusFlags, null, 2)}`,
  ];
  if (params.sourceCode) {
    const truncated = params.sourceCode.length > MAX_SOURCE_CHARS;
    parts.push(`\nVerified Solidity source${truncated ? " (truncated to first " + MAX_SOURCE_CHARS + " characters)" : ""}:\n${params.sourceCode.slice(0, MAX_SOURCE_CHARS)}`);
  } else {
    parts.push(`\nVerified source code: not available (contract is unverified or source lookup failed).`);
  }
  return parts.join("\n");
}

export async function analyzeContractWithAI(network: string, contractAddress: string): Promise<AiSecurityAnalysis | AiSecurityUnavailable> {
  const normalizedNetwork = network.trim().toLowerCase();
  if (normalizedNetwork !== "ethereum" && normalizedNetwork !== "bsc") {
    return { available: false, reason: "Deep AI analysis currently supports Ethereum and BSC contracts only." };
  }

  const [goPlusFlags, contractInfo] = await Promise.all([
    fetchRawGoPlusToken(normalizedNetwork, contractAddress).catch(() => null),
    normalizedNetwork === "bsc" ? getBscScanContractInfo(contractAddress) : getEtherscanContractInfo(contractAddress),
  ]);

  if (!goPlusFlags) {
    return { available: false, reason: "No scanner data available for this contract yet - it may be too new or unsupported." };
  }

  const prompt = buildUserPrompt({
    network: normalizedNetwork,
    contractAddress,
    goPlusFlags,
    sourceCode: contractInfo?.sourceCode ?? null,
    contractName: contractInfo?.contractName ?? null,
  });

  try {
    const result = await invokePaxiAI({
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt },
      ],
      responseFormat: { type: "json_schema", json_schema: ANALYSIS_SCHEMA },
      maxTokens: 1200,
    });

    const raw = result.choices[0]?.message?.content;
    const text = typeof raw === "string" ? raw : Array.isArray(raw) ? raw.map((p) => (p.type === "text" ? p.text : "")).join("") : "";
    const parsed = JSON.parse(text) as {
      riskLevel: AiSecurityAnalysis["riskLevel"];
      summary: string;
      concerns: string[];
      reassurances: string[];
      confidencePercent: number;
    };

    return {
      available: true,
      riskLevel: parsed.riskLevel,
      summary: parsed.summary,
      concerns: Array.isArray(parsed.concerns) ? parsed.concerns : [],
      reassurances: Array.isArray(parsed.reassurances) ? parsed.reassurances : [],
      confidencePercent: Math.max(0, Math.min(100, Math.round(parsed.confidencePercent))),
      sourceCodeReviewed: Boolean(contractInfo?.sourceCode),
      model: result.modelChainUsed,
    };
  } catch (error) {
    console.warn(`[aiSecurityAnalysis] LLM analysis failed for ${network}:${contractAddress}:`, error instanceof Error ? error.message : error);
    return { available: false, reason: "AI analysis is temporarily unavailable. Try again shortly." };
  }
}
