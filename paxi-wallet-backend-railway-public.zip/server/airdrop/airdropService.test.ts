import { describe, expect, it } from "vitest";
import { ethers } from "ethers";
import { verifyAirdropTransferSet } from "./airdropService";

const token = "0x0000000000000000000000000000000000000010";
const distributor = "0x0000000000000000000000000000000000000020";
const alice = "0x0000000000000000000000000000000000000030";
const bob = "0x0000000000000000000000000000000000000040";
const transferTopic = ethers.id("Transfer(address,address,uint256)");

function addressTopic(address: string): string {
  return ethers.zeroPadValue(address, 32);
}

function transfer(from: string, to: string, amount: bigint, address = token) {
  return { address, topics: [transferTopic, addressTopic(from), addressTopic(to)], data: ethers.toBeHex(amount, 32) };
}

describe("airdrop distribution Transfer verification", () => {
  it("accepts the exact server-known recipients and total", () => {
    const total = verifyAirdropTransferSet({
      tokenContractAddress: token,
      distributorAddress: distributor,
      tokenDecimals: 18,
      allocations: [{ recipientWalletAddress: alice, amount: "10" }, { recipientWalletAddress: bob, amount: "5" }],
      logs: [transfer(distributor, alice, 10n * 10n ** 18n), transfer(distributor, bob, 5n * 10n ** 18n)],
    });
    expect(total).toBe(15n * 10n ** 18n);
  });

  it("rejects transfers from an unrelated sender", () => {
    expect(() => verifyAirdropTransferSet({
      tokenContractAddress: token,
      distributorAddress: distributor,
      tokenDecimals: 18,
      allocations: [{ recipientWalletAddress: alice, amount: "10" }],
      logs: [transfer("0x0000000000000000000000000000000000000099", alice, 10n * 10n ** 18n)],
    })).toThrow(/recipients/);
  });

  it("rejects a different token contract", () => {
    expect(() => verifyAirdropTransferSet({
      tokenContractAddress: token,
      distributorAddress: distributor,
      tokenDecimals: 18,
      allocations: [{ recipientWalletAddress: alice, amount: "10" }],
      logs: [transfer(distributor, alice, 10n * 10n ** 18n, "0x0000000000000000000000000000000000000098")],
    })).toThrow(/recipients/);
  });

  it("rejects a wrong recipient or amount", () => {
    expect(() => verifyAirdropTransferSet({
      tokenContractAddress: token,
      distributorAddress: distributor,
      tokenDecimals: 18,
      allocations: [{ recipientWalletAddress: alice, amount: "10" }],
      logs: [transfer(distributor, bob, 10n * 10n ** 18n)],
    })).toThrow(/does not match/);
    expect(() => verifyAirdropTransferSet({
      tokenContractAddress: token,
      distributorAddress: distributor,
      tokenDecimals: 18,
      allocations: [{ recipientWalletAddress: alice, amount: "10" }],
      logs: [transfer(distributor, alice, 9n * 10n ** 18n)],
    })).toThrow(/does not match/);
  });

  it("rejects an extra recipient transfer and therefore cannot over-distribute", () => {
    expect(() => verifyAirdropTransferSet({
      tokenContractAddress: token,
      distributorAddress: distributor,
      tokenDecimals: 18,
      allocations: [{ recipientWalletAddress: alice, amount: "10" }],
      logs: [transfer(distributor, alice, 10n * 10n ** 18n), transfer(distributor, bob, 1n * 10n ** 18n)],
    })).toThrow(/recipients/);
  });
});

export {};
