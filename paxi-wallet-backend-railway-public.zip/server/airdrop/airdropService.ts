import { and, asc, eq, inArray, sql } from "drizzle-orm";
import {
  airdropAllocations,
  airdropDistributions,
  eligibilityResults,
  rewardLedger,
  type AirdropDistribution,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { creditReward } from "../rewards/rewardService";

const DECIMAL_PATTERN = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/;
const SCALE = 1_000_000_000_000_000_000n;

function assertAmount(value: string): void {
  if (!DECIMAL_PATTERN.test(value) || value === "0") throw new Error("Airdrop amount must be a positive decimal");
}

function parseUnits(value: string): bigint {
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * SCALE + BigInt(fraction.padEnd(18, "0").slice(0, 18) || "0");
}

function formatUnits(value: bigint): string {
  const whole = value / SCALE;
  const fraction = (value % SCALE).toString().padStart(18, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function assertId(value: number, field: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`Invalid ${field}`);
}

export async function createAirdropDistribution(params: {
  createdByOpenId: string;
  campaignId?: number;
  snapshotId?: number;
  assetSymbol: string;
  assetNetwork: string;
  assetContractAddress?: string | null;
  totalAmount: string;
}): Promise<AirdropDistribution> {
  if (!params.createdByOpenId || params.createdByOpenId.length > 64) throw new Error("Invalid creator identifier");
  if (params.campaignId !== undefined) assertId(params.campaignId, "campaign id");
  if (params.snapshotId !== undefined) assertId(params.snapshotId, "snapshot id");
  if (params.campaignId === undefined && params.snapshotId === undefined) throw new Error("Campaign or snapshot is required");
  assertAmount(params.totalAmount);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(airdropDistributions).values({
    createdByOpenId: params.createdByOpenId,
    campaignId: params.campaignId,
    snapshotId: params.snapshotId,
    assetSymbol: params.assetSymbol.trim().toUpperCase(),
    assetNetwork: params.assetNetwork.trim().toLowerCase(),
    assetContractAddress: params.assetContractAddress ?? null,
    totalAmount: params.totalAmount,
    allocatedAmount: "0",
    distributedAmount: "0",
    status: "draft",
  });
  const id = Number((result as unknown as { insertId?: number | string }).insertId);
  const [created] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, id)).limit(1);
  if (!created) throw new Error("Airdrop distribution was not created");
  return created;
}

export async function allocateAirdrop(distributionId: number): Promise<AirdropDistribution> {
  assertId(distributionId, "distribution id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [distribution] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
  if (!distribution) throw new Error("Airdrop distribution not found");
  if (!["draft", "allocated"].includes(distribution.status)) throw new Error("Airdrop is not available for allocation");
  if (!distribution.snapshotId) throw new Error("Airdrop allocation requires a campaign snapshot");

  const [claim] = await db.update(airdropDistributions).set({ status: "allocated" }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "draft"))).then(async (result) => [Number((result as { affectedRows?: number }).affectedRows ?? 0)] as const);
  if (claim !== 0 && claim !== 1) throw new Error("Airdrop claim failed");

  const results = await db.select().from(eligibilityResults)
    .where(and(eq(eligibilityResults.snapshotId, distribution.snapshotId), inArray(eligibilityResults.tier, ["minimum", "highest"])))
    .orderBy(asc(eligibilityResults.id));
  const cap = parseUnits(distribution.totalAmount);
  const existing = await db.select().from(airdropAllocations).where(eq(airdropAllocations.distributionId, distributionId));
  const existingUsers = new Set(existing.map((row) => row.userOpenId));
  let allocated = existing.reduce((sum, row) => sum + parseUnits(row.amount), 0n);
  const eligible = results
    .filter((result) => result.tier !== "not_qualified" && result.payoutMultiplier !== "0")
    .map((result) => ({ ...result, tier: result.tier as "minimum" | "highest" }));
  const weights = eligible.map((result) => parseUnits(result.payoutMultiplier));
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0n);
  if (totalWeight <= 0n) throw new Error("Eligible participants have no positive payout multiplier");
  const plannedAmounts = weights.map((weight) => (cap * weight) / totalWeight);
  const plannedTotal = plannedAmounts.reduce((sum, amount) => sum + amount, 0n);
  const firstFreshIndex = eligible.findIndex((result) => !existingUsers.has(result.userOpenId));
  const roundingRemainder = firstFreshIndex >= 0 && cap > plannedTotal ? cap - plannedTotal : 0n;

  for (let index = 0; index < eligible.length; index += 1) {
    const result = eligible[index];
    if (existingUsers.has(result.userOpenId)) continue;
    const remainingCap = cap > allocated ? cap - allocated : 0n;
    const amountUnits = plannedAmounts[index] + (index === firstFreshIndex ? roundingRemainder : 0n);
    const safeAmountUnits = amountUnits > remainingCap ? remainingCap : amountUnits;
    if (safeAmountUnits <= 0n) continue;
    const amount = formatUnits(safeAmountUnits);
    const ledger = await creditReward({
      userOpenId: result.userOpenId,
      sourceType: "airdrop",
      sourceId: String(distributionId),
      idempotencyKey: `airdrop:${distributionId}:user:${result.userOpenId}`,
      assetSymbol: distribution.assetSymbol,
      assetNetwork: distribution.assetNetwork,
      assetContractAddress: distribution.assetContractAddress,
      amount,
      metadata: { tier: result.tier, payoutMultiplier: result.payoutMultiplier, eligibilityResultId: result.id },
    });
    await db.insert(airdropAllocations).values({
      distributionId,
      eligibilityResultId: result.id,
      rewardLedgerId: ledger.id,
      userOpenId: result.userOpenId,
      amount,
      tier: result.tier,
      status: "pending",
    }).onDuplicateKeyUpdate({ set: { rewardLedgerId: ledger.id, amount, tier: result.tier } });
    allocated += safeAmountUnits;
  }

  await db.update(airdropDistributions).set({ allocatedAmount: formatUnits(allocated), status: "review" }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "allocated")));
  const [updated] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
  if (!updated) throw new Error("Airdrop distribution disappeared");
  return updated;
}

export async function approveAirdrop(distributionId: number, approvedByOpenId: string): Promise<AirdropDistribution> {
  assertId(distributionId, "distribution id");
  if (!approvedByOpenId || approvedByOpenId.length > 64) throw new Error("Invalid approver identifier");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.update(airdropDistributions).set({ status: "approved", approvedByOpenId, approvedAt: new Date() }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "review")));
  if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Only an airdrop in review can be approved");
  const [row] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
  if (!row) throw new Error("Airdrop distribution not found after approval");
  return row;
}

export async function markAirdropDistributed(distributionId: number, distributionTxHash: string): Promise<AirdropDistribution> {
  assertId(distributionId, "distribution id");
  if (!/^[A-Za-z0-9:_-]{8,128}$/.test(distributionTxHash)) throw new Error("Invalid distribution transaction hash");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.transaction(async (tx) => {
    const result = await tx.update(airdropDistributions).set({ status: "complete", distributionTxHash, distributedAt: new Date(), distributedAmount: sql`${airdropDistributions.allocatedAmount}` }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "approved")));
    if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Only an approved airdrop can be marked distributed");
    await tx.update(airdropAllocations).set({ status: "distributed", distributionTxHash }).where(and(eq(airdropAllocations.distributionId, distributionId), eq(airdropAllocations.status, "pending")));
    const rows = await tx.select({ ledgerId: airdropAllocations.rewardLedgerId }).from(airdropAllocations).where(eq(airdropAllocations.distributionId, distributionId));
    for (const row of rows) {
      if (row.ledgerId) await tx.update(rewardLedger).set({ status: "distributed", distributedAt: new Date() }).where(and(eq(rewardLedger.id, row.ledgerId), eq(rewardLedger.status, "approved")));
    }
    const [updated] = await tx.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
    if (!updated) throw new Error("Airdrop distribution not found after distribution");
    return updated;
  });
}
