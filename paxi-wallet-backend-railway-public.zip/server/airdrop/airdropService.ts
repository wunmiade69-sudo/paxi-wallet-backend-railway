import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { ethers } from "ethers";
import {
  airdropAllocations,
  airdropDistributions,
  campaignSnapshotParticipants,
  eligibilityResults,
  rewardLedger,
  type AirdropDistribution,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { ENV } from "../_core/env";
import { creditReward } from "../rewards/rewardService";

const DECIMAL_PATTERN = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/;
const SCALE = 1_000_000_000_000_000_000n;

function assertAmount(value: string): void {
  if (!DECIMAL_PATTERN.test(value) || value === "0") throw new Error("Airdrop amount must be a positive decimal");
}

function parseUnits(value: string): bigint {
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * SCALE + BigInt(fraction.padEnd(18, "0").slice(0, 18) || "0");
}

function formatUnits(value: bigint): string {
  const whole = value / SCALE;
  const fraction = (value % SCALE).toString().padStart(18, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function assertId(value: number, field: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`Invalid ${field}`);
}

function selectRecipientWallet(wallets: unknown): string {
  const candidates = Array.isArray(wallets) ? wallets.filter((value): value is string => typeof value === "string") : [];
  const address = candidates.find((value) => ethers.isAddress(value));
  if (!address) throw new Error("Airdrop allocation has no valid server-known EVM recipient wallet");
  return ethers.getAddress(address);
}

export async function createAirdropDistribution(params: {
  createdByOpenId: string;
  campaignId?: number;
  snapshotId?: number;
  assetSymbol: string;
  assetNetwork: string;
  assetContractAddress?: string | null;
  totalAmount: string;
}): Promise<AirdropDistribution> {
  if (!params.createdByOpenId || params.createdByOpenId.length > 64) throw new Error("Invalid creator identifier");
  if (params.campaignId !== undefined) assertId(params.campaignId, "campaign id");
  if (params.snapshotId !== undefined) assertId(params.snapshotId, "snapshot id");
  if (params.campaignId === undefined && params.snapshotId === undefined) throw new Error("Campaign or snapshot is required");
  assertAmount(params.totalAmount);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(airdropDistributions).values({
    createdByOpenId: params.createdByOpenId,
    campaignId: params.campaignId,
    snapshotId: params.snapshotId,
    assetSymbol: params.assetSymbol.trim().toUpperCase(),
    assetNetwork: params.assetNetwork.trim().toLowerCase(),
    assetContractAddress: params.assetContractAddress ?? null,
    totalAmount: params.totalAmount,
    allocatedAmount: "0",
    distributedAmount: "0",
    status: "draft",
  });
  const id = Number((result as unknown as { insertId?: number | string }).insertId);
  const [created] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, id)).limit(1);
  if (!created) throw new Error("Airdrop distribution was not created");
  return created;
}

export async function allocateAirdrop(distributionId: number): Promise<AirdropDistribution> {
  assertId(distributionId, "distribution id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [distribution] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
  if (!distribution) throw new Error("Airdrop distribution not found");
  if (!["draft", "allocated"].includes(distribution.status)) throw new Error("Airdrop is not available for allocation");
  if (!distribution.snapshotId) throw new Error("Airdrop allocation requires a campaign snapshot");

  const [claim] = await db.update(airdropDistributions).set({ status: "allocated" }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "draft"))).then(async (result) => [Number((result as { affectedRows?: number }).affectedRows ?? 0)] as const);
  if (claim !== 0 && claim !== 1) throw new Error("Airdrop claim failed");

  const resultRows = await db.select({ result: eligibilityResults, wallets: campaignSnapshotParticipants.wallets })
    .from(eligibilityResults)
    .innerJoin(campaignSnapshotParticipants, and(eq(campaignSnapshotParticipants.snapshotId, eligibilityResults.snapshotId), eq(campaignSnapshotParticipants.userOpenId, eligibilityResults.userOpenId)))
    .where(and(eq(eligibilityResults.snapshotId, distribution.snapshotId), inArray(eligibilityResults.tier, ["minimum", "highest"])))
    .orderBy(asc(eligibilityResults.id));
  const results = resultRows.map(({ result, wallets }) => ({ ...result, wallets }));
  const cap = parseUnits(distribution.totalAmount);
  const existing = await db.select().from(airdropAllocations).where(eq(airdropAllocations.distributionId, distributionId));
  const existingUsers = new Set(existing.map((row) => row.userOpenId));
  let allocated = existing.reduce((sum, row) => sum + parseUnits(row.amount), 0n);
  const eligible = results
    .filter((result) => result.tier !== "not_qualified" && result.payoutMultiplier !== "0")
    .map((result) => ({ ...result, tier: result.tier as "minimum" | "highest" }));
  const weights = eligible.map((result) => parseUnits(result.payoutMultiplier));
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0n);
  if (totalWeight <= 0n) throw new Error("Eligible participants have no positive payout multiplier");
  const plannedAmounts = weights.map((weight) => (cap * weight) / totalWeight);
  const plannedTotal = plannedAmounts.reduce((sum, amount) => sum + amount, 0n);
  const firstFreshIndex = eligible.findIndex((result) => !existingUsers.has(result.userOpenId));
  const roundingRemainder = firstFreshIndex >= 0 && cap > plannedTotal ? cap - plannedTotal : 0n;

  for (let index = 0; index < eligible.length; index += 1) {
    const result = eligible[index];
    if (existingUsers.has(result.userOpenId)) continue;
    const remainingCap = cap > allocated ? cap - allocated : 0n;
    const amountUnits = plannedAmounts[index] + (index === firstFreshIndex ? roundingRemainder : 0n);
    const safeAmountUnits = amountUnits > remainingCap ? remainingCap : amountUnits;
    if (safeAmountUnits <= 0n) continue;
    const amount = formatUnits(safeAmountUnits);
    const recipientWalletAddress = selectRecipientWallet(result.wallets);
    const ledger = await creditReward({
      userOpenId: result.userOpenId,
      sourceType: "airdrop",
      sourceId: String(distributionId),
      idempotencyKey: `airdrop:${distributionId}:user:${result.userOpenId}`,
      assetSymbol: distribution.assetSymbol,
      assetNetwork: distribution.assetNetwork,
      assetContractAddress: distribution.assetContractAddress,
      amount,
      metadata: { tier: result.tier, payoutMultiplier: result.payoutMultiplier, eligibilityResultId: result.id, recipientWalletAddress },
    });
    await db.insert(airdropAllocations).values({
      distributionId,
      eligibilityResultId: result.id,
      rewardLedgerId: ledger.id,
      userOpenId: result.userOpenId,
      recipientWalletAddress,
      amount,
      tier: result.tier,
      status: "pending",
    }).onDuplicateKeyUpdate({ set: { rewardLedgerId: ledger.id, amount, tier: result.tier } });
    allocated += safeAmountUnits;
  }

  await db.update(airdropDistributions).set({ allocatedAmount: formatUnits(allocated), status: "review" }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "allocated")));
  const [updated] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
  if (!updated) throw new Error("Airdrop distribution disappeared");
  return updated;
}

export async function approveAirdrop(distributionId: number, approvedByOpenId: string): Promise<AirdropDistribution> {
  assertId(distributionId, "distribution id");
  if (!approvedByOpenId || approvedByOpenId.length > 64) throw new Error("Invalid approver identifier");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.update(airdropDistributions).set({ status: "approved", approvedByOpenId, approvedAt: new Date() }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "review")));
  if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Only an airdrop in review can be approved");
  const [row] = await db.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
  if (!row) throw new Error("Airdrop distribution not found after approval");
  return row;
}

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;
const ERC20_DECIMALS_ABI = ["function decimals() view returns (uint8)"];

function topicAddress(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`).toLowerCase();
  } catch {
    return null;
  }
}

function airdropProvider(): ethers.JsonRpcProvider {
  const request = new ethers.FetchRequest(ENV.paxiPayoutRpcUrl);
  request.timeout = 10_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

function configuredAirdropDistributor(): string {
  const derived = ENV.paxiPayoutPrivateKey ? new ethers.Wallet(ENV.paxiPayoutPrivateKey).address : "";
  const configured = ENV.paxiRewardDistributorAddress || derived;
  if (!ethers.isAddress(configured)) throw new Error("Airdrop distributor is not configured on the server");
  if (ENV.paxiRewardDistributorAddress && derived && configured.toLowerCase() !== derived.toLowerCase()) {
    throw new Error("Airdrop distributor configuration does not match the payout signer");
  }
  return ethers.getAddress(configured);
}

export function verifyAirdropTransferSet(params: {
  tokenContractAddress: string;
  distributorAddress: string;
  allocations: Array<{ recipientWalletAddress: string | null; amount: string }>;
  tokenDecimals: number;
  logs: ReadonlyArray<{ address: string; topics: readonly string[]; data: string }>;
}): bigint {
  const tokenAddress = params.tokenContractAddress.toLowerCase();
  const distributor = params.distributorAddress.toLowerCase();
  const expected = new Map<string, bigint>();
  for (const allocation of params.allocations) {
    if (!allocation.recipientWalletAddress || !ethers.isAddress(allocation.recipientWalletAddress)) throw new Error("Airdrop allocation recipient is invalid");
    const recipient = ethers.getAddress(allocation.recipientWalletAddress).toLowerCase();
    const units = ethers.parseUnits(allocation.amount, params.tokenDecimals);
    expected.set(recipient, (expected.get(recipient) ?? 0n) + units);
  }
  const actual = new Map<string, bigint>();
  for (const log of params.logs) {
    if (log.address.toLowerCase() !== tokenAddress || log.topics[0] !== TRANSFER_TOPIC) continue;
    const from = topicAddress(log.topics[1]);
    const to = topicAddress(log.topics[2]);
    if (from !== distributor || !to) continue;
    let amount: bigint;
    try { amount = BigInt(log.data); } catch { throw new Error("Airdrop contains an invalid token Transfer event"); }
    actual.set(to, (actual.get(to) ?? 0n) + amount);
  }
  if (actual.size !== expected.size) throw new Error("Airdrop Transfer events do not match the allocated recipients");
  let total = 0n;
  for (const [recipient, expectedUnits] of expected) {
    if (actual.get(recipient) !== expectedUnits) throw new Error(`Airdrop amount for recipient ${recipient} does not match the allocation`);
    total += expectedUnits;
  }
  return total;
}

export async function verifyAirdropDistributionOnChain(params: {
  distribution: AirdropDistribution;
  allocations: Array<{ recipientWalletAddress: string | null; amount: string }>;
  distributionTxHash: string;
}): Promise<{ tokenDecimals: number; distributedAmount: string; blockNumber: number | null }> {
  const { distribution, allocations, distributionTxHash } = params;
  if (distribution.assetNetwork.trim().toLowerCase() !== "bsc") throw new Error("Airdrop verification currently supports BSC distributions only");
  if (!distribution.assetContractAddress || !ethers.isAddress(distribution.assetContractAddress)) throw new Error("Airdrop token contract is not configured");
  if (!TX_HASH_RE.test(distributionTxHash)) throw new Error("Invalid distribution transaction hash");
  if (allocations.length === 0 || allocations.some((allocation) => !allocation.recipientWalletAddress || !ethers.isAddress(allocation.recipientWalletAddress))) {
    throw new Error("Every airdrop allocation must have a server-known recipient wallet before distribution");
  }

  const provider = airdropProvider();
  const network = await provider.getNetwork();
  if (network.chainId !== 56n) throw new Error(`Airdrop transaction is on the wrong network: ${network.chainId.toString()}`);
  const receipt = await provider.getTransactionReceipt(distributionTxHash);
  if (!receipt) throw new Error("Airdrop transaction is not confirmed; distribution remains in progress");
  if (receipt.status !== 1) throw new Error("Airdrop transaction failed or reverted on-chain");

  const distributor = configuredAirdropDistributor().toLowerCase();
  if (receipt.from.toLowerCase() !== distributor) throw new Error("Airdrop transaction sender does not match the configured distributor");
  const tokenAddress = distribution.assetContractAddress.toLowerCase();
  const decimals = Number(await new ethers.Contract(tokenAddress, ERC20_DECIMALS_ABI, provider).decimals());
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) throw new Error("Airdrop token decimals are invalid");

  const total = verifyAirdropTransferSet({ tokenContractAddress: tokenAddress, distributorAddress: distributor, allocations, tokenDecimals: decimals, logs: receipt.logs });
  const allocatedUnits = ethers.parseUnits(distribution.allocatedAmount, decimals);
  if (total !== allocatedUnits) throw new Error("Airdrop verified transfer total does not match the allocated amount");
  return { tokenDecimals: decimals, distributedAmount: formatUnits(total), blockNumber: receipt.blockNumber };
}

export async function markAirdropDistributed(distributionId: number, distributionTxHash: string): Promise<AirdropDistribution> {
  assertId(distributionId, "distribution id");
  if (!TX_HASH_RE.test(distributionTxHash)) throw new Error("Invalid distribution transaction hash");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  let distribution: AirdropDistribution;
  await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT id FROM airdropDistributions WHERE id = ${distributionId} FOR UPDATE`);
    const [current] = await tx.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
    if (!current) throw new Error("Airdrop distribution not found");
    if (current.status === "complete") {
      if (current.distributionTxHash?.toLowerCase() === distributionTxHash.toLowerCase()) {
        distribution = current;
        return;
      }
      throw new Error("Airdrop is already complete with a different transaction");
    }
    if (!["approved", "distributing"].includes(current.status)) throw new Error("Only an approved or in-progress airdrop can be verified");
    const [used] = await tx.select({ id: airdropDistributions.id }).from(airdropDistributions).where(and(eq(airdropDistributions.distributionTxHash, distributionTxHash), sql`id <> ${distributionId}`)).limit(1);
    if (used) throw new Error("This distribution transaction has already been used");
    if (current.distributionTxHash && current.distributionTxHash.toLowerCase() !== distributionTxHash.toLowerCase()) throw new Error("A different distribution transaction is already in progress");
    if (current.status === "approved") {
      const result = await tx.update(airdropDistributions).set({ status: "distributing", distributionTxHash }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "approved")));
      if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Airdrop distribution changed concurrently; retry verification");
    }
    distribution = { ...current, status: "distributing", distributionTxHash };
  });

  const allocations = await db.select({ recipientWalletAddress: airdropAllocations.recipientWalletAddress, amount: airdropAllocations.amount }).from(airdropAllocations).where(eq(airdropAllocations.distributionId, distributionId));
  const verified = await verifyAirdropDistributionOnChain({ distribution: distribution!, allocations, distributionTxHash });
  return db.transaction(async (tx) => {
    await tx.execute(sql`SELECT id FROM airdropDistributions WHERE id = ${distributionId} FOR UPDATE`);
    const [current] = await tx.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
    if (!current) throw new Error("Airdrop distribution disappeared during verification");
    if (current.status === "complete") {
      if (current.distributionTxHash?.toLowerCase() === distributionTxHash.toLowerCase()) return current;
      throw new Error("Airdrop was completed concurrently with a different transaction");
    }
    const result = await tx.update(airdropDistributions).set({ status: "complete", distributedAt: new Date(), distributedAmount: verified.distributedAmount }).where(and(eq(airdropDistributions.id, distributionId), eq(airdropDistributions.status, "distributing"), eq(airdropDistributions.distributionTxHash, distributionTxHash)));
    if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Airdrop finalization changed concurrently; retry verification");
    await tx.update(airdropAllocations).set({ status: "distributed", distributionTxHash }).where(and(eq(airdropAllocations.distributionId, distributionId), eq(airdropAllocations.status, "pending")));
    const rows = await tx.select({ ledgerId: airdropAllocations.rewardLedgerId }).from(airdropAllocations).where(eq(airdropAllocations.distributionId, distributionId));
    for (const row of rows) {
      if (row.ledgerId) await tx.update(rewardLedger).set({ status: "distributed", distributedAt: new Date() }).where(and(eq(rewardLedger.id, row.ledgerId), inArray(rewardLedger.status, ["approved", "pending"])));
    }
    const [updated] = await tx.select().from(airdropDistributions).where(eq(airdropDistributions.id, distributionId)).limit(1);
    if (!updated) throw new Error("Airdrop distribution not found after finalization");
    return updated;
  });
}
