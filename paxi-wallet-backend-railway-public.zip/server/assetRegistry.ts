/**
 * Phase 1 of the universal asset registry (see drizzle/schema.ts for the
 * table docs). This file has two jobs:
 *
 *   1. `PAXI_CHAINS` / `seedChains()` - the chain rows every asset hangs off.
 *      Mirrors client/src/lib/wallet/chains.ts BASE_NETWORKS exactly, so
 *      `assets.chainId` always matches a network the wallet actually knows
 *      how to show. If you add a network on the client, add it here too.
 *
 *   2. `syncAssetFromListing()` - called from server/routers/listings.ts
 *      every time a tokenListings row is created/updated, so `assets` /
 *      `assetMetadata` never drift out of sync with the paid-listing flow.
 *      `tokenListings` stays the source of truth for the fee/review
 *      workflow; this just mirrors the result into the generalized table
 *      Phase 2 (markets) and Phase 3 (candles) will read from.
 *
 *      This is intentionally best-effort: if it throws, the caller logs a
 *      warning and moves on. A missed sync can always be repaired by
 *      re-running backfillAssetsFromListings.ts - it must never be able to
 *      fail a listing submission or token creation.
 */
import { and, eq } from "drizzle-orm";
import {
  assetMarketData,
  assetMetadata,
  assets,
  chains,
  dexes,
  tokenListings,
  type Asset,
  type InsertAsset,
  type InsertChain,
  type InsertDex,
  type TokenListing,
} from "../drizzle/schema";
import { getDb } from "./db";

/** Mirrors client/src/lib/wallet/chains.ts BASE_NETWORKS. Keep these two lists in sync. */
export const PAXI_CHAINS: InsertChain[] = [
  { id: "ethereum", name: "Ethereum", chainType: "evm", chainId: 1, nativeSymbol: "ETH" },
  { id: "bsc", name: "BNB Smart Chain", chainType: "evm", chainId: 56, nativeSymbol: "BNB" },
  { id: "bitcoin", name: "Bitcoin", chainType: "btc", nativeSymbol: "BTC" },
  { id: "solana", name: "Solana", chainType: "sol", nativeSymbol: "SOL" },
  { id: "polygon", name: "Polygon", chainType: "evm", chainId: 137, nativeSymbol: "POL" },
  { id: "arbitrum", name: "Arbitrum One", chainType: "evm", chainId: 42161, nativeSymbol: "ETH" },
];

/**
 * Chain-aware identifier normalization. EVM addresses are case-insensitive
 * (checksum casing is just a typo-check convention), so lowercasing is
 * safe and keeps "0xAbC..." and "0xabc..." as the same asset. Every other
 * address format PAXI supports is case-SENSITIVE - Solana's Base58,
 * Bitcoin's Base58Check/Bech32, TON's base64url all encode different
 * addresses for different casing. Lowercasing those would silently merge
 * or misroute distinct assets. `normalizeIdentifier`/`addressesEqual` are
 * the single place this decision is made - every write or comparison of
 * an `assets.identifier` value should go through one of these two rather
 * than calling `.toLowerCase()` directly.
 */
const EVM_CHAIN_IDS = new Set(PAXI_CHAINS.filter((c) => c.chainType === "evm").map((c) => c.id));

export function isEvmChain(chainId: string): boolean {
  return EVM_CHAIN_IDS.has(chainId);
}

export function normalizeIdentifier(chainId: string, identifier: string): string {
  return isEvmChain(chainId) ? identifier.toLowerCase() : identifier;
}

export function addressesEqual(chainId: string, a: string, b: string): boolean {
  return normalizeIdentifier(chainId, a) === normalizeIdentifier(chainId, b);
}

/** Safe to re-run - upserts every row in PAXI_CHAINS. Run once after migrating: `npx tsx scripts/seedAssetRegistry.ts`. */
export async function seedChains(): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("No database connection - check DATABASE_URL is set.");
  for (const chain of PAXI_CHAINS) {
    await db.insert(chains).values(chain).onDuplicateKeyUpdate({ set: chain });
  }
}

/**
 * Mirrors client/src/lib/wallet/dexAnalytics.ts's DEX_FACTORIES - the AMMs
 * PAXI Wallet can read on-chain reserves from directly. Add a row here
 * whenever a new factory is added to the client-side fallback, so
 * `liquidityPools` rows can record which DEX they came from.
 */
export const PAXI_DEXES: InsertDex[] = [
  {
    chainId: "bsc",
    name: "PancakeSwap",
    factoryAddress: "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73",
  },
];

/** Safe to re-run. Returns a name->id map so callers can attach liquidityPools rows to the right dex. */
export async function seedDexes(): Promise<Record<string, number>> {
  const db = await getDb();
  if (!db) throw new Error("No database connection - check DATABASE_URL is set.");
  const idByName: Record<string, number> = {};
  for (const dex of PAXI_DEXES) {
    await db.insert(dexes).values(dex).onDuplicateKeyUpdate({ set: dex });
    const [row] = await db
      .select({ id: dexes.id })
      .from(dexes)
      .where(and(eq(dexes.chainId, dex.chainId), eq(dexes.name, dex.name)))
      .limit(1);
    if (row) idByName[`${dex.chainId}:${dex.name}`] = row.id;
  }
  return idByName;
}

/**
 * Finds or creates the `assets` row for (chainId, identifier) - the
 * building block Phase 2 (dexLiquidity.ts, marketData.ts) uses to attach
 * pools/prices to an asset that may not have come through the
 * tokenListings flow at all (e.g. the quote side of a pool, or a token
 * CoinGecko knows about that nobody ever submitted a paid listing for).
 * Never overwrites an existing row's verification/status - only fills in
 * identity fields if the row doesn't exist yet.
 */
export async function getOrCreateAsset(input: {
  chainId: string;
  identifier: string;
  symbol: string;
  name: string;
  decimals?: number;
  logoUrl?: string | null;
}): Promise<Asset | null> {
  const db = await getDb();
  if (!db) return null;

  const identifier = normalizeIdentifier(input.chainId, input.identifier);
  const [existing] = await db
    .select()
    .from(assets)
    .where(and(eq(assets.chainId, input.chainId), eq(assets.identifier, identifier)))
    .limit(1);
  if (existing) return existing;

  const values: InsertAsset = {
    chainId: input.chainId,
    assetType: identifier === "native" ? "native" : "token",
    identifier,
    symbol: input.symbol,
    name: input.name,
    decimals: input.decimals ?? 18,
    logoUrl: input.logoUrl ?? null,
    status: "active",
    verificationStatus: "unverified", // discovered via market data, not the listing flow - no badge until reviewed
  };
  await db.insert(assets).values(values).onDuplicateKeyUpdate({ set: values });

  const [row] = await db
    .select()
    .from(assets)
    .where(and(eq(assets.chainId, input.chainId), eq(assets.identifier, identifier)))
    .limit(1);
  return row ?? null;
}

/**
 * Upserts the `assets` + `assetMetadata` rows that correspond to one
 * tokenListings row. Call this right after any insert/update of
 * `tokenListings` (see listings.ts). Never throws to the caller - logs and
 * returns instead, since a sync miss is non-fatal and repairable.
 */
export async function syncAssetFromListing(listing: TokenListing): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;

    const verificationStatus = listing.status === "verified" ? "verified" : listing.status === "rejected" ? "unverified" : "registered";

    const logoUrl = listing.logoUrl ?? (listing.logoKey ? `/manus-storage/${listing.logoKey}` : null);

    const identifier = normalizeIdentifier(listing.network, listing.contractAddress);

    const values: InsertAsset = {
      chainId: listing.network,
      assetType: "token",
      identifier,
      symbol: listing.symbol,
      name: listing.name,
      decimals: 18,
      logoUrl,
      status: "active",
      verificationStatus,
      sourceListingId: listing.id,
    };

    await db
      .insert(assets)
      .values(values)
      .onDuplicateKeyUpdate({ set: values });

    const [row] = await db
      .select({ id: assets.id })
      .from(assets)
      .where(eq(assets.sourceListingId, listing.id))
      .limit(1);
    if (!row) return;

    const socials = (listing.socials ?? {}) as Record<string, string>;
    const metaValues = {
      assetId: row.id,
      website: socials.website ?? null,
      twitter: socials.twitter ?? null,
      telegram: socials.telegram ?? null,
      discord: socials.discord ?? null,
    };
    await db.insert(assetMetadata).values(metaValues).onDuplicateKeyUpdate({ set: metaValues });
  } catch (err) {
    console.warn("[assetRegistry] syncAssetFromListing failed (non-fatal):", listing.network, listing.contractAddress, err);
  }
}

/** One-time backfill for every existing tokenListings row. Safe to re-run. `npx tsx scripts/seedAssetRegistry.ts --backfill` */
export async function backfillAssetsFromListings(): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("No database connection - check DATABASE_URL is set.");
  const existing = await db.select().from(tokenListings);
  console.log(`Backfilling ${existing.length} tokenListings row(s) into assets/assetMetadata...`);
  for (const listing of existing) {
    await syncAssetFromListing(listing);
  }
  console.log("Backfill done.");
}

/**
 * CoinGecko's platform slugs (returned as TokenDetail.platformId) mapped to
 * our own chain ids. Only chains PAXI Wallet actually supports are listed -
 * a CoinGecko platform we don't have a wallet network for is skipped.
 */
const COINGECKO_PLATFORM_TO_CHAIN: Record<string, string> = {
  ethereum: "ethereum",
  "binance-smart-chain": "bsc",
  "polygon-pos": "polygon",
  "arbitrum-one": "arbitrum",
  solana: "solana",
};

/**
 * Bridges a CoinGecko coin (with a known contract address) into the
 * universal asset registry + canonical price row. Called from
 * marketData.ts's getTokenDetail with data already fetched - no extra API
 * calls. Best-effort: swallows its own errors, never throws to the caller.
 */
export async function syncAssetFromCoinGeckoDetail(detail: {
  contractAddress: string | null;
  platformId: string | null;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number;
  priceChangePercent24h: number | null;
  priceChangePercent7d: number | null;
  volume24h: number;
  marketCap: number;
}): Promise<void> {
  if (!detail.contractAddress || !detail.platformId) return; // native coin (BTC/ETH/...) with no contract - Phase 1's "native" identifier case, skip for now
  const chainId = COINGECKO_PLATFORM_TO_CHAIN[detail.platformId];
  if (!chainId) return; // a chain PAXI Wallet doesn't support yet

  const db = await getDb();
  if (!db) return;

  const asset = await getOrCreateAsset({
    chainId,
    identifier: detail.contractAddress,
    symbol: detail.symbol,
    name: detail.name,
    logoUrl: detail.image || null,
  });
  if (!asset) return;

  const marketValues = {
    assetId: asset.id,
    priceUsd: String(detail.currentPrice),
    priceChange24h: detail.priceChangePercent24h != null ? String(detail.priceChangePercent24h) : null,
    priceChange7d: detail.priceChangePercent7d != null ? String(detail.priceChangePercent7d) : null,
    volume24hUsd: String(detail.volume24h),
    marketCapUsd: String(detail.marketCap),
    source: "coingecko",
  };
  await db.insert(assetMarketData).values(marketValues).onDuplicateKeyUpdate({ set: marketValues });
}


