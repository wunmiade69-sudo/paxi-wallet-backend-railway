import { decimalToUnits, inspectCampaignPayout, sendCampaignReward } from "../../campaigns/rewardEscrow";
import type { GiftCodeTransferAdapter, GiftCodeTransferRequest, GiftCodeTransferResult } from "./types";

export const bscAdapter: GiftCodeTransferAdapter = {
  network: "bsc",
  async transfer(request: GiftCodeTransferRequest): Promise<GiftCodeTransferResult> {
    const broadcast = await sendCampaignReward({
      network: "bsc",
      tokenContractAddress: request.tokenAddress,
      recipientAddress: request.recipientAddress,
      amountUnits: decimalToUnits(request.amount, request.decimals).toString(),
    });
    return { state: "broadcast", transactionHash: broadcast.transactionHash, senderAddress: broadcast.senderAddress };
  },
  async verify(request: GiftCodeTransferRequest & { transactionHash: string }): Promise<GiftCodeTransferResult> {
    const inspection = await inspectCampaignPayout({
      network: "bsc",
      transactionHash: request.transactionHash,
      tokenContractAddress: request.tokenAddress,
      recipientAddress: request.recipientAddress,
      amountUnits: decimalToUnits(request.amount, request.decimals).toString(),
    });
    if (inspection.state === "confirmed") return { state: "confirmed", transactionHash: request.transactionHash, senderAddress: inspection.senderAddress, blockNumber: inspection.blockNumber };
    if (inspection.state === "pending") return { state: "pending", transactionHash: request.transactionHash, reason: inspection.reason };
    return { state: "broadcast", transactionHash: request.transactionHash, reason: inspection.reason };
  },
};
