import { ethers } from "ethers";
import { ENV } from "../../_core/env";
import type { GiftCodeTransferAdapter, GiftCodeTransferRequest, GiftCodeTransferResult } from "./types";

const ERC20_ABI = ["function transfer(address to, uint256 amount) returns (bool)"];
const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");

function provider(): ethers.JsonRpcProvider {
  const request = new ethers.FetchRequest(ENV.ethereumPayoutRpcUrl || "https://ethereum-rpc.publicnode.com");
  request.timeout = 8_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

function addressFromTopic(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try { return ethers.getAddress(`0x${topic.slice(26)}`); } catch { return null; }
}

function amountUnits(request: GiftCodeTransferRequest): bigint { return ethers.parseUnits(request.amount, request.decimals); }

export const ethereumAdapter: GiftCodeTransferAdapter = {
  network: "ethereum",
  async transfer(request) {
    if (!ENV.ethereumPayoutPrivateKey) throw new Error("Ethereum Gift Code payout signer is not configured");
    if (!ethers.isAddress(request.tokenAddress) || !ethers.isAddress(request.recipientAddress)) throw new Error("Invalid Ethereum token or recipient");
    const signer = new ethers.Wallet(ENV.ethereumPayoutPrivateKey, provider());
    const token = new ethers.Contract(request.tokenAddress, ERC20_ABI, signer);
    const transaction = await token.transfer(request.recipientAddress, amountUnits(request));
    return { state: "broadcast", transactionHash: transaction.hash, senderAddress: signer.address };
  },
  async verify(request) {
    if (!ethers.isHexString(request.transactionHash, 32)) return { state: "broadcast", transactionHash: request.transactionHash, reason: "Invalid Ethereum transaction hash" };
    const receipt = await provider().getTransactionReceipt(request.transactionHash);
    if (!receipt) return { state: "pending", transactionHash: request.transactionHash, reason: "Ethereum transaction is not confirmed yet" };
    if (receipt.status !== 1) return { state: "broadcast", transactionHash: request.transactionHash, reason: "Ethereum transaction reverted" };
    const expectedToken = ethers.getAddress(request.tokenAddress);
    const expectedRecipient = ethers.getAddress(request.recipientAddress);
    const expectedAmount = amountUnits(request);
    for (const log of receipt.logs) {
      if (log.address.toLowerCase() !== expectedToken.toLowerCase() || log.topics[0] !== TRANSFER_TOPIC) continue;
      const from = addressFromTopic(log.topics[1]);
      const to = addressFromTopic(log.topics[2]);
      if (to?.toLowerCase() !== expectedRecipient.toLowerCase()) continue;
      try {
        if (BigInt(log.data) === expectedAmount) return { state: "confirmed", transactionHash: request.transactionHash, senderAddress: from ?? undefined, blockNumber: receipt.blockNumber };
      } catch { /* ignore malformed logs */ }
    }
    return { state: "broadcast", transactionHash: request.transactionHash, reason: "Receipt did not contain the exact ERC-20 transfer" };
  },
};
