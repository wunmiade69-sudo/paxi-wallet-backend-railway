import { Connection, Keypair, PublicKey, Transaction } from "@solana/web3.js";
import { createTransferInstruction, getAccount, getOrCreateAssociatedTokenAccount } from "@solana/spl-token";
import { ENV } from "../../_core/env";
import type { GiftCodeTransferAdapter, GiftCodeTransferRequest, GiftCodeTransferResult } from "./types";

function connection(): Connection { return new Connection(ENV.solanaPayoutRpcUrl, "confirmed"); }

function signer(): Keypair {
  if (!ENV.solanaPayoutPrivateKey) throw new Error("Solana Gift Code payout signer is not configured");
  let bytes: number[];
  try { bytes = JSON.parse(ENV.solanaPayoutPrivateKey) as number[]; } catch { throw new Error("SOLANA_PAYOUT_PRIVATE_KEY must be a JSON secret-key array"); }
  if (!Array.isArray(bytes) || (bytes.length !== 64 && bytes.length !== 32) || bytes.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255)) throw new Error("Invalid Solana payout secret key");
  return bytes.length === 64 ? Keypair.fromSecretKey(Uint8Array.from(bytes)) : Keypair.fromSeed(Uint8Array.from(bytes));
}

function units(request: GiftCodeTransferRequest): bigint {
  const [whole, fraction = ""] = request.amount.split(".");
  return BigInt(`${whole}${fraction.padEnd(request.decimals, "0")}`);
}

export const solanaAdapter: GiftCodeTransferAdapter = {
  network: "solana",
  async transfer(request) {
    const payer = signer();
    const conn = connection();
    const mint = new PublicKey(request.tokenAddress);
    const recipient = new PublicKey(request.recipientAddress);
    const source = await getOrCreateAssociatedTokenAccount(conn, payer, mint, payer.publicKey);
    const destination = await getOrCreateAssociatedTokenAccount(conn, payer, mint, recipient);
    const transaction = new Transaction().add(createTransferInstruction(source.address, destination.address, payer.publicKey, units(request)));
    const signature = await conn.sendTransaction(transaction, [payer]);
    await conn.confirmTransaction(signature, "confirmed");
    return { state: "confirmed", transactionHash: signature, senderAddress: payer.publicKey.toBase58() };
  },
  async verify(request) {
    const conn = connection();
    const tx = await conn.getParsedTransaction(request.transactionHash, { commitment: "confirmed", maxSupportedTransactionVersion: 0 });
    if (!tx) return { state: "pending", transactionHash: request.transactionHash, reason: "Solana transaction is not confirmed yet" };
    if (tx.meta?.err) return { state: "broadcast", transactionHash: request.transactionHash, reason: "Solana transaction failed" };
    const mint = new PublicKey(request.tokenAddress).toBase58();
    const recipient = new PublicKey(request.recipientAddress).toBase58();
    const expected = units(request);
    const pre = new Map((tx.meta?.preTokenBalances ?? []).filter((entry) => entry.mint === mint && entry.owner === recipient).map((entry) => [entry.accountIndex, BigInt(entry.uiTokenAmount.amount)]));
    const post = (tx.meta?.postTokenBalances ?? []).filter((entry) => entry.mint === mint && entry.owner === recipient);
    for (const entry of post) {
      const delta = BigInt(entry.uiTokenAmount.amount) - (pre.get(entry.accountIndex) ?? 0n);
      if (delta === expected) return { state: "confirmed", transactionHash: request.transactionHash, senderAddress: tx.transaction.message.accountKeys.find((key) => key.signer)?.pubkey.toBase58() };
    }
    return { state: "broadcast", transactionHash: request.transactionHash, reason: "Solana transaction did not credit the exact SPL-token amount" };
  },
};
