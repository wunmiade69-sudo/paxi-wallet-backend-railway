import type { GiftCodeTransferAdapter, GiftCodeTransferRequest, GiftCodeTransferResult } from "./types";

export const tonAdapter: GiftCodeTransferAdapter = {
  network: "ton",
  async transfer(_request: GiftCodeTransferRequest): Promise<GiftCodeTransferResult> {
    throw new Error("TON Gift Code fulfillment is reserved for a future audited adapter");
  },
  async verify(request: GiftCodeTransferRequest & { transactionHash: string }): Promise<GiftCodeTransferResult> {
    return { state: "broadcast", transactionHash: request.transactionHash, reason: "TON Gift Code verification is not implemented yet" };
  },
};
