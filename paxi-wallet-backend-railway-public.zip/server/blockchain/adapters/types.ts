export type TransferState = "confirmed" | "broadcast" | "pending";

export interface GiftCodeTransferRequest {
  network: string;
  tokenAddress: string;
  recipientAddress: string;
  amount: string;
  decimals: number;
}

export interface GiftCodeTransferResult {
  state: TransferState;
  transactionHash: string;
  senderAddress?: string;
  blockNumber?: number;
  reason?: string;
}

export interface GiftCodeTransferAdapter {
  readonly network: string;
  transfer(request: GiftCodeTransferRequest): Promise<GiftCodeTransferResult>;
  verify(request: GiftCodeTransferRequest & { transactionHash: string }): Promise<GiftCodeTransferResult>;
}
