import type { AssetIdentity } from "../identity/assetIdentity";
import { getAssetIdentityKey } from "../identity/assetIdentity";

export type CacheNamespace = "metadata" | "logo" | "price" | "liquidity" | "chart" | "security" | "pairs" | "search";

export interface CacheEnvelope<T> {
  data: T;
  createdAt: number;
  expiresAt: number;
  source: string;
  sourceTimestamp: number | null;
  stale: boolean;
}

export function assetCacheKey(namespace: Exclude<CacheNamespace, "search">, identity: AssetIdentity, suffix?: string): string {
  const key = `asset:${namespace}:${getAssetIdentityKey(identity)}`;
  return suffix ? `${key}:${suffix}` : key;
}

export function searchCacheKey(query: string, chain: string | null): string {
  return `asset:search:${chain ?? "all"}:${query.trim().toLowerCase()}`;
}

export function createCacheEnvelope<T>(data: T, source: string, ttlMs: number, sourceTimestamp: number | null = null, now = Date.now()): CacheEnvelope<T> {
  return {
    data,
    createdAt: now,
    expiresAt: now + Math.max(0, ttlMs),
    source,
    sourceTimestamp,
    stale: false,
  };
}

export function markCacheEnvelopeStale<T>(envelope: CacheEnvelope<T>, now = Date.now()): CacheEnvelope<T> {
  return { ...envelope, stale: envelope.expiresAt <= now };
}
