import { describe, expect, it } from "vitest";
import { CAMPAIGN_ICON_MAX_BYTES, decodeCampaignImage } from "./campaignAssets";

describe("campaign asset validation", () => {
  it("accepts a genuine PNG data URL and records the content type", () => {
    const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]).toString("base64");
    expect(decodeCampaignImage(`data:image/png;base64,${png}`, CAMPAIGN_ICON_MAX_BYTES, "Campaign icon").contentType).toBe("image/png");
  });

  it("rejects a mismatched declared image type and an oversized asset", () => {
    const jpgBytes = Buffer.from([0xff, 0xd8, 0xff, 0x00]).toString("base64");
    expect(() => decodeCampaignImage(`data:image/png;base64,${jpgBytes}`, CAMPAIGN_ICON_MAX_BYTES, "Campaign icon")).toThrow("does not match");
    const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]).toString("base64");
    expect(() => decodeCampaignImage(`data:image/png;base64,${png}`, 1, "Campaign icon")).toThrow("smaller than");
  });
});
