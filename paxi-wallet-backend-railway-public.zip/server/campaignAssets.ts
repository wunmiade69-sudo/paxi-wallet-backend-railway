import { TRPCError } from "@trpc/server";

export const CAMPAIGN_BANNER_MAX_BYTES = 5 * 1024 * 1024;
export const CAMPAIGN_ICON_MAX_BYTES = 1 * 1024 * 1024;

const IMAGE_PATTERN = /^data:image\/(png|jpeg|jpg|webp);base64,/;

export type CampaignAsset = { buffer: Buffer; contentType: "image/png" | "image/jpeg" | "image/webp"; extension: "png" | "jpg" | "webp" };

export function decodeCampaignImage(dataUrl: string, maxBytes: number, label: string): CampaignAsset {
  const match = dataUrl.match(IMAGE_PATTERN);
  if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: `${label} must be a PNG, JPEG, or WebP image.` });
  const [, declaredType] = match;
  const base64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
  const buffer = Buffer.from(base64, "base64");
  if (buffer.byteLength === 0 || buffer.byteLength > maxBytes) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `${label} must be smaller than ${Math.floor(maxBytes / 1024 / 1024)}MB.` });
  }

  const isPng = declaredType === "png" && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  const isJpeg = (declaredType === "jpeg" || declaredType === "jpg") && buffer.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]));
  const isWebp = declaredType === "webp" && buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP";
  if (!isPng && !isJpeg && !isWebp) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `${label} content does not match its declared image type.` });
  }

  return isPng
    ? { buffer, contentType: "image/png", extension: "png" }
    : isWebp
      ? { buffer, contentType: "image/webp", extension: "webp" }
      : { buffer, contentType: "image/jpeg", extension: "jpg" };
}
