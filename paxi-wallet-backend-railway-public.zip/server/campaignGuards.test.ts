import { describe, expect, it } from "vitest";
import { campaignTokensMatchApprovedListing } from "./campaignGuards";

const listing = { network: "bsc", contractAddress: "0xeda04581461bc308e60052fe489e20c3f78d6e4e", symbol: "PAXI" };
const campaign = {
  taskTokenNetwork: "bsc",
  taskTokenContractAddress: "0xeda04581461bc308e60052fe489e20c3f78d6e4e",
  taskTokenSymbol: "PAXI",
  rewardNetwork: "bsc",
  rewardTokenContractAddress: "0xeda04581461bc308e60052fe489e20c3f78d6e4e",
  rewardTokenSymbol: "PAXI",
};

describe("approved-listing campaign guard", () => {
  it("accepts a campaign that uses the exact reviewed token identity", () => {
    expect(campaignTokensMatchApprovedListing(campaign, listing)).toBe(true);
  });

  it("rejects a campaign that substitutes an unreviewed task or reward contract", () => {
    expect(campaignTokensMatchApprovedListing({ ...campaign, taskTokenContractAddress: "0x1111111111111111111111111111111111111111" }, listing)).toBe(false);
    expect(campaignTokensMatchApprovedListing({ ...campaign, rewardTokenContractAddress: "0x2222222222222222222222222222222222222222" }, listing)).toBe(false);
  });
});
