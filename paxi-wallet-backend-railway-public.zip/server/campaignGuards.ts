import { addressesEqual } from "./assetRegistry";

export interface ApprovedListingIdentity {
  network: string;
  contractAddress: string;
  symbol: string;
}

export interface CampaignTokenIdentity {
  taskTokenNetwork: string;
  taskTokenContractAddress: string;
  taskTokenSymbol: string;
  rewardNetwork: string;
  rewardTokenContractAddress?: string;
  rewardTokenSymbol: string;
}

/** Campaign task and reward identity must be the exact contract that passed listing review. */
export function campaignTokensMatchApprovedListing(
  campaign: CampaignTokenIdentity,
  listing: ApprovedListingIdentity,
): boolean {
  const sameIdentity = (network: string, contractAddress: string | undefined, symbol: string) =>
    network === listing.network
    && Boolean(contractAddress)
    && addressesEqual(network, contractAddress!, listing.contractAddress)
    && symbol.trim().toLowerCase() === listing.symbol.trim().toLowerCase();

  return sameIdentity(campaign.taskTokenNetwork, campaign.taskTokenContractAddress, campaign.taskTokenSymbol)
    && sameIdentity(campaign.rewardNetwork, campaign.rewardTokenContractAddress, campaign.rewardTokenSymbol);
}
