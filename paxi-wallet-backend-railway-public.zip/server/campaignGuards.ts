export interface ApprovedListingIdentity {
  network: string;
  contractAddress: string;
  symbol: string;
}

export interface CampaignTokenIdentity {
  taskTokenNetwork: string;
  taskTokenContractAddress: string;
  taskTokenSymbol: string;
  rewardNetwork: string;
  rewardTokenContractAddress?: string;
  rewardTokenSymbol: string;
}

/** Campaign task and reward identity must be the exact contract that passed listing review. */
export function campaignTokensMatchApprovedListing(
  campaign: CampaignTokenIdentity,
  listing: ApprovedListingIdentity,
): boolean {
  return (
    campaign.taskTokenNetwork === listing.network &&
    campaign.taskTokenContractAddress === listing.contractAddress &&
    campaign.taskTokenSymbol === listing.symbol &&
    campaign.rewardNetwork === listing.network &&
    campaign.rewardTokenContractAddress === listing.contractAddress &&
    campaign.rewardTokenSymbol === listing.symbol
  );
}
