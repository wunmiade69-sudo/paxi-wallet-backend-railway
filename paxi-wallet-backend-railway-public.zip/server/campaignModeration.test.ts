import { describe, expect, it } from "vitest";
import { campaignCanEnterReview, campaignCanPublish } from "./campaignModeration";

const readyDraft = { status: "draft", bannerKey: "campaign/banner.webp", iconKey: "campaign/icon.webp", poolFundedTxHash: "0xabc" };

describe("campaign moderation gates", () => {
  it("requires private validated assets and verified escrow before a draft enters review", () => {
    expect(campaignCanEnterReview(readyDraft)).toBe(true);
    expect(campaignCanEnterReview({ ...readyDraft, bannerKey: null })).toBe(false);
    expect(campaignCanEnterReview({ ...readyDraft, poolFundedTxHash: null })).toBe(false);
  });

  it("permits publication only from a fully funded pending-review campaign", () => {
    expect(campaignCanPublish({ ...readyDraft, status: "pending_review" })).toBe(true);
    expect(campaignCanPublish({ ...readyDraft, status: "active" })).toBe(false);
    expect(campaignCanPublish({ ...readyDraft, status: "pending_review", iconKey: null })).toBe(false);
  });
});
