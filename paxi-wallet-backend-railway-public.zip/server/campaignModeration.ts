export function campaignCanEnterReview(campaign: { status: string; bannerKey: string | null; iconKey: string | null; poolFundedTxHash: string | null }): boolean {
  return campaign.status === "draft" && Boolean(campaign.bannerKey && campaign.iconKey && campaign.poolFundedTxHash);
}

export function campaignCanPublish(campaign: { status: string; bannerKey: string | null; iconKey: string | null; poolFundedTxHash: string | null }): boolean {
  return campaign.status === "pending_review" && Boolean(campaign.bannerKey && campaign.iconKey && campaign.poolFundedTxHash);
}
