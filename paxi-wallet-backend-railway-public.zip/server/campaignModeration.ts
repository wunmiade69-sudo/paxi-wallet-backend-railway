export function campaignCanEnterReview(campaign: {
  status: string;
  bannerKey: string | null;
  iconKey: string | null;
  rewardEscrowFundedTxHash: string | null;
}): boolean {
  return campaign.status === "draft"
    && Boolean(campaign.bannerKey)
    && Boolean(campaign.iconKey)
    && Boolean(campaign.rewardEscrowFundedTxHash);
}

export function campaignCanPublish(campaign: {
  status: string;
  bannerKey: string | null;
  iconKey: string | null;
  rewardEscrowFundedTxHash: string | null;
}): boolean {
  return campaign.status === "pending_review"
    && Boolean(campaign.bannerKey)
    && Boolean(campaign.iconKey)
    && Boolean(campaign.rewardEscrowFundedTxHash);
}
