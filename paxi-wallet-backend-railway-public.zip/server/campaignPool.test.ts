import { describe, expect, it } from "vitest";
import { calculateCampaignPoolUsd } from "./campaignPool";

describe("campaign pool calculation", () => {
  it("calculates the required escrow amount with fixed-point USD precision", () => {
    expect(calculateCampaignPoolUsd("1.50", 100)).toBe("150");
    expect(calculateCampaignPoolUsd("0.333333", 3)).toBe("0.999999");
  });

  it("rejects zero, malformed, and out-of-range campaign pool inputs", () => {
    expect(() => calculateCampaignPoolUsd("0", 1)).toThrow("greater than zero");
    expect(() => calculateCampaignPoolUsd("1.1234567", 1)).toThrow("at most 6");
    expect(() => calculateCampaignPoolUsd("1", 100_001)).toThrow("100,000");
  });
});
