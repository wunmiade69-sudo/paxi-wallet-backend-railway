const USD_AMOUNT_PATTERN = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/;
const USD_SCALE = 1_000_000n;

function parseUsd(value: string): bigint {
  if (!USD_AMOUNT_PATTERN.test(value)) throw new Error("Reward value must be a USD amount with at most 6 fractional digits.");
  const [whole, fractional = ""] = value.split(".");
  const scaled = BigInt(whole) * USD_SCALE + BigInt(fractional.padEnd(6, "0") || "0");
  if (scaled <= 0n) throw new Error("Reward value must be greater than zero.");
  return scaled;
}

function formatUsd(value: bigint): string {
  const whole = value / USD_SCALE;
  const fractional = (value % USD_SCALE).toString().padStart(6, "0").replace(/0+$/, "");
  return fractional ? `${whole}.${fractional}` : whole.toString();
}

/** Computes the campaign escrow requirement without trusting client-side arithmetic. */
export function calculateCampaignPoolUsd(rewardValueUsd: string, maxWinners: number): string {
  if (!Number.isSafeInteger(maxWinners) || maxWinners < 1 || maxWinners > 100_000) {
    throw new Error("Maximum winners must be between 1 and 100,000.");
  }
  return formatUsd(parseUsd(rewardValueUsd) * BigInt(maxWinners));
}
