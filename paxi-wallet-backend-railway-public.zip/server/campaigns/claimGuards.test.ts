import { describe, expect, it } from "vitest";
import { campaignClaimBlockReason } from "./claimGuards";

const valid = { status: "active", claimsPaused: false, rewardEscrowFundedTxHash: "0xescrow", listingVerified: true, startAt: null, endAt: null };

describe("campaign claim guards", () => {
  it("allows requests only for active approved campaigns with verified escrow", () => {
    expect(campaignClaimBlockReason(valid)).toBeNull();
    expect(campaignClaimBlockReason({ ...valid, claimsPaused: true })).toContain("paused");
    expect(campaignClaimBlockReason({ ...valid, rewardEscrowFundedTxHash: null })).toContain("escrow");
    expect(campaignClaimBlockReason({ ...valid, listingVerified: false })).toContain("listing");
  });
});
