import { describe, expect, it } from "vitest";
import { campaignClaimBlockReason } from "./claimGuards";

const valid = { status: "active", claimsPaused: false, poolFundedTxHash: "0xpool", listingVerified: true, startAt: null, endAt: null };

describe("campaign claim guards", () => {
  it("allows requests only for active approved campaigns with verified escrow", () => {
    expect(campaignClaimBlockReason(valid)).toBeNull();
    expect(campaignClaimBlockReason({ ...valid, claimsPaused: true })).toContain("paused");
    expect(campaignClaimBlockReason({ ...valid, poolFundedTxHash: null })).toContain("pool");
    expect(campaignClaimBlockReason({ ...valid, listingVerified: false })).toContain("listing");
  });
});
