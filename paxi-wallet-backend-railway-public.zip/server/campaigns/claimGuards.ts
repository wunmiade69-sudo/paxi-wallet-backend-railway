export type CampaignClaimGuardInput = {
  status: string;
  claimsPaused: boolean;
  rewardEscrowFundedTxHash: string | null;
  listingVerified: boolean;
  startAt: Date | null;
  endAt: Date | null;
};

/** Returns a user-safe refusal reason or null when a campaign claim may be requested. */
export function campaignClaimBlockReason(campaign: CampaignClaimGuardInput, now = new Date()): string | null {
  if (campaign.status !== "active") return "This campaign is not active.";
  if (!campaign.listingVerified) return "This campaign's listing is no longer approved.";
  if (campaign.claimsPaused) return "Reward claims are temporarily paused for this campaign.";
  if (!campaign.rewardEscrowFundedTxHash) return "This campaign reward-token escrow has not been verified.";
  if (campaign.startAt && now < campaign.startAt) return "This campaign has not started yet.";
  if (campaign.endAt && now > campaign.endAt) return "This campaign has ended.";
  return null;
}
