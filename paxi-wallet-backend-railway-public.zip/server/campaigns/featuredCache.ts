import { redisSafe } from "../redis";

const FEATURED_CACHE_KEY = "campaigns:featured:v1";
const FEATURED_CACHE_TTL_SECONDS = 60;

/** Redis is a disposable performance layer; callers always query MySQL on a miss. */
export async function getCachedFeaturedCampaigns<T>(): Promise<T | null> {
  const raw = await redisSafe((client) => client.get(FEATURED_CACHE_KEY));
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export async function setCachedFeaturedCampaigns(value: unknown): Promise<void> {
  await redisSafe((client) => client.set(FEATURED_CACHE_KEY, JSON.stringify(value), "EX", FEATURED_CACHE_TTL_SECONDS));
}

export async function clearCachedFeaturedCampaigns(): Promise<void> {
  await redisSafe((client) => client.del(FEATURED_CACHE_KEY));
}
