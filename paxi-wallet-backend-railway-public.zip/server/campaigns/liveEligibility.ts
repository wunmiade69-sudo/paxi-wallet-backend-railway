import { and, asc, eq } from "drizzle-orm";
import { campaignRequirements, campaigns, tokenListings } from "../../drizzle/schema";
import { getActivityStats } from "../activity/activityService";
import { getDb } from "../db";
import { ensureDefaultRequirements, evaluateActivityRequirement } from "../eligibility/requirementService";

export type LiveCampaignEligibility = {
  campaignId: number;
  evaluatedAt: number;
  totalRequirements: number;
  metRequirements: number;
  minimumRequired: number;
  eligible: boolean;
  requirements: Array<{ key: string; label: string; met: boolean; threshold: string }>;
};

/**
 * Evaluates active campaign requirements from confirmed, server-trusted PAXI
 * activity in the campaign's own time window. The client never supplies
 * completion flags or amounts to this calculation.
 */
export async function evaluateLiveCampaignEligibility(campaignId: number, userOpenId: string): Promise<LiveCampaignEligibility> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, campaignId)).limit(1);
  if (!campaign || campaign.status !== "active") throw new Error("Campaign is not active");
  const [listing] = await db.select({ status: tokenListings.status }).from(tokenListings).where(eq(tokenListings.id, campaign.listingId)).limit(1);
  if (listing?.status !== "verified") throw new Error("Campaign listing is not approved");

  const now = new Date();
  if (campaign.startAt && now < campaign.startAt) throw new Error("Campaign has not started");
  if (campaign.endAt && now > campaign.endAt) throw new Error("Campaign has ended");

  let requirements = await db.select().from(campaignRequirements).where(and(eq(campaignRequirements.campaignId, campaignId), eq(campaignRequirements.isActive, true))).orderBy(asc(campaignRequirements.sortOrder));
  // Backfill approved legacy campaigns once. New campaigns seed these rows at creation.
  if (requirements.length === 0) requirements = await ensureDefaultRequirements(campaignId);
  const activeRequirements = requirements.filter((requirement) => requirement.isActive);
  if (activeRequirements.length !== 10) throw new Error("Campaign requires exactly ten active requirements");

  const windowEnd = campaign.endAt && campaign.endAt < now ? campaign.endAt : now;
  const stats = await getActivityStats(userOpenId, { since: campaign.startAt ?? undefined, until: windowEnd });
  const rows = activeRequirements.map((requirement) => ({ key: requirement.requirementKey, label: requirement.label, met: evaluateActivityRequirement(requirement, stats), threshold: requirement.threshold }));
  const metRequirements = rows.filter((row) => row.met).length;
  const minimumRequired = 5;
  return { campaignId, evaluatedAt: Date.now(), totalRequirements: rows.length, metRequirements, minimumRequired, eligible: metRequirements >= minimumRequired, requirements: rows };
}
