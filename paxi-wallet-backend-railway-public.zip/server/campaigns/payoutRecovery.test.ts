import { describe, expect, it } from "vitest";
import { classifyCampaignPayoutRequest, decideCampaignPayoutRecovery } from "./rewardEscrow";

describe("campaign payout recovery state machine", () => {
  it("retains the reservation after a broadcast timeout", () => {
    expect(decideCampaignPayoutRecovery({ state: "rpc_unavailable", reason: "timeout" })).toBe("retain");
    expect(classifyCampaignPayoutRequest({ status: "recovery_required", transactionHash: "0x" + "1".repeat(64) })).toBe("recover_existing");
  });

  it("retains a broadcast transaction while its receipt is pending", () => {
    expect(decideCampaignPayoutRecovery({ state: "pending", reason: "not mined" })).toBe("retain");
  });

  it("confirms only after the existing transaction has an exact successful transfer", () => {
    expect(decideCampaignPayoutRecovery({ state: "confirmed", senderAddress: "0x0000000000000000000000000000000000000001", blockNumber: 10 })).toBe("confirm");
  });

  it("allows a replacement only after an explicit reverted receipt", () => {
    expect(decideCampaignPayoutRecovery({ state: "reverted", reason: "receipt status 0" })).toBe("replace");
    expect(decideCampaignPayoutRecovery({ state: "invalid", reason: "wrong transfer" })).toBe("retain");
  });

  it("does not create a second payout for a duplicate request with an existing hash", () => {
    expect(classifyCampaignPayoutRequest({ status: "broadcast", transactionHash: "0x" + "2".repeat(64) })).toBe("recover_existing");
    expect(classifyCampaignPayoutRequest({ status: "confirmed", transactionHash: "0x" + "2".repeat(64) })).toBe("already_complete");
  });

  it("serializes concurrent requests while a broadcast lease is active", () => {
    const now = new Date("2026-08-17T12:00:00.000Z");
    const leaseUntil = new Date("2026-08-17T12:00:30.000Z");
    expect(classifyCampaignPayoutRequest({ status: "reserved", transactionHash: null, now, leaseUntil })).toBe("already_in_flight");
    expect(classifyCampaignPayoutRequest({ status: "reserved", transactionHash: null, now: new Date("2026-08-17T12:01:00.000Z"), leaseUntil })).toBe("start");
  });
});

export {};

function noop(): void {}
void noop;
