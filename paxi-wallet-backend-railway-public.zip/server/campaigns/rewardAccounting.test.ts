import { describe, expect, it } from "vitest";
import { assertRewardAccounting, confirmReward, releaseReward, reserveReward } from "./rewardAccounting";

const base = { rewardRequired: 100n, rewardEscrowed: 100n, rewardReserved: 0n, rewardClaimed: 0n, rewardRemaining: 100n };

describe("reward accounting", () => {
  it("reserves and confirms an exact winner amount", () => {
    const reserved = reserveReward(base, 25n);
    expect(reserved.rewardReserved).toBe(25n);
    expect(reserved.rewardRemaining).toBe(75n);
    const confirmed = confirmReward(reserved, 25n);
    expect(confirmed.rewardReserved).toBe(0n);
    expect(confirmed.rewardClaimed).toBe(25n);
    expect(confirmed.rewardRemaining).toBe(75n);
    expect(() => assertRewardAccounting(confirmed)).not.toThrow();
  });

  it("releases a failed payout back to remaining balance", () => {
    const reserved = reserveReward(base, 25n);
    const released = releaseReward(reserved, 25n);
    expect(released).toEqual(base);
  });

  it("rejects a claim that would over-commit escrow", () => {
    expect(() => reserveReward(base, 101n)).toThrow(/Insufficient unreserved/);
    expect(() => assertRewardAccounting({ ...base, rewardClaimed: 101n, rewardRemaining: 0n })).toThrow(/exceed escrowed/);
  });

  it("requires all accounting buckets to reconcile", () => {
    expect(() => assertRewardAccounting({ ...base, rewardRemaining: 99n })).toThrow(/reconcile/);
  });
});
