export interface RewardAccountingState {
  rewardRequired: bigint;
  rewardEscrowed: bigint;
  rewardReserved: bigint;
  rewardClaimed: bigint;
  rewardRemaining: bigint;
}

export function assertRewardAccounting(state: RewardAccountingState): void {
  if ([state.rewardRequired, state.rewardEscrowed, state.rewardReserved, state.rewardClaimed, state.rewardRemaining].some((value) => value < 0n)) {
    throw new Error("Reward accounting cannot contain negative balances.");
  }
  if (state.rewardRequired > state.rewardEscrowed) throw new Error("Reward escrow is below the required reward amount.");
  if (state.rewardClaimed > state.rewardEscrowed) throw new Error("Claimed rewards exceed escrowed rewards.");
  if (state.rewardReserved + state.rewardClaimed > state.rewardEscrowed) throw new Error("Reserved and claimed rewards exceed escrowed rewards.");
  if (state.rewardClaimed + state.rewardRemaining > state.rewardEscrowed) throw new Error("Claimed and remaining rewards exceed escrowed rewards.");
  if (state.rewardRemaining + state.rewardReserved + state.rewardClaimed !== state.rewardEscrowed) throw new Error("Reward accounting buckets do not reconcile to escrowed rewards.");
}

export function reserveReward(state: RewardAccountingState, amount: bigint): RewardAccountingState {
  if (amount <= 0n || state.rewardRemaining < amount) throw new Error("Insufficient unreserved reward balance.");
  const next = { ...state, rewardReserved: state.rewardReserved + amount, rewardRemaining: state.rewardRemaining - amount };
  assertRewardAccounting(next);
  return next;
}

export function confirmReward(state: RewardAccountingState, amount: bigint): RewardAccountingState {
  if (amount <= 0n || state.rewardReserved < amount) throw new Error("Cannot confirm more reward than is reserved.");
  const next = { ...state, rewardReserved: state.rewardReserved - amount, rewardClaimed: state.rewardClaimed + amount };
  assertRewardAccounting(next);
  return next;
}

export function releaseReward(state: RewardAccountingState, amount: bigint): RewardAccountingState {
  if (amount <= 0n || state.rewardReserved < amount) throw new Error("Cannot release more reward than is reserved.");
  const next = { ...state, rewardReserved: state.rewardReserved - amount, rewardRemaining: state.rewardRemaining + amount };
  assertRewardAccounting(next);
  return next;
}
