import { ethers } from "ethers";
import { ENV } from "../_core/env";
import { getCircuitBreaker } from "../resilience/circuitBreaker";

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const ERC20_ABI = [
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function transfer(address to, uint256 amount) returns (bool)",
];
const DECIMAL_RE = /^(?:0|[1-9]\d{0,38})(?:\.\d{1,36})?$/;
const NETWORKS: Record<string, string> = {
  ethereum: "https://ethereum-rpc.publicnode.com",
  bsc: "https://bsc-rpc.publicnode.com",
};

export interface RewardEscrowVerification {
  ok: true;
  senderAddress: string;
  escrowRecipient: string;
  tokenDecimals: number;
  tokenSymbol: string;
  amountUnits: string;
  amountHuman: string;
  blockNumber: number;
  transactionHash: string;
}

export interface RewardEscrowFailure {
  ok: false;
  reason: string;
}

export type RewardEscrowResult = RewardEscrowVerification | RewardEscrowFailure;

export function multiplyDecimalByInteger(value: string, multiplier: number): string {
  if (!DECIMAL_RE.test(value) || !Number.isSafeInteger(multiplier) || multiplier <= 0) {
    throw new Error("Invalid reward amount or winner count.");
  }
  const [whole, fraction = ""] = value.split(".");
  const scale = 10n ** BigInt(fraction.length);
  const scaled = BigInt(`${whole}${fraction}`) * BigInt(multiplier);
  const wholePart = scaled / scale;
  const fractionPart = (scaled % scale).toString().padStart(fraction.length, "0").replace(/0+$/, "");
  return fractionPart ? `${wholePart}.${fractionPart}` : wholePart.toString();
}

export function decimalToUnits(value: string, decimals: number): bigint {
  if (!DECIMAL_RE.test(value) || !Number.isInteger(decimals) || decimals < 0 || decimals > 36) {
    throw new Error("Invalid token amount or decimals.");
  }
  return ethers.parseUnits(value, decimals);
}

function addressFromTopic(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`);
  } catch {
    return null;
  }
}

function providerFor(network: string): ethers.JsonRpcProvider | null {
  const rpcUrl = NETWORKS[network];
  if (!rpcUrl) return null;
  const request = new ethers.FetchRequest(rpcUrl);
  request.timeout = 8_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

function payoutProvider(): ethers.JsonRpcProvider {
  const request = new ethers.FetchRequest(ENV.paxiPayoutRpcUrl);
  request.timeout = 8_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

function isTxHash(value: string): boolean {
  return ethers.isHexString(value, 32);
}

export function getConfiguredPayoutSignerAddress(): string {
  if (!ENV.paxiPayoutPrivateKey) throw new Error("PAXI payout distributor signer is not configured on the server.");
  const derivedAddress = new ethers.Wallet(ENV.paxiPayoutPrivateKey).address;
  if (ENV.paxiRewardDistributorAddress && derivedAddress.toLowerCase() !== ENV.paxiRewardDistributorAddress.toLowerCase()) {
    throw new Error("PAXI_REWARD_DISTRIBUTOR_ADDRESS does not match PAXI_PAYOUT_PRIVATE_KEY.");
  }
  return derivedAddress;
}

/**
 * The current payout path is a direct ERC-20 transfer from the configured
 * distributor signer. Until a RewardVault contract with an on-chain
 * distributor authorization is integrated, funding and payout must use the
 * same address; otherwise the project could deposit into one wallet while
 * PAXI attempts to pay from an unrelated wallet.
 */
export function assertRewardVaultPayoutCompatibility(): { vaultAddress: string; distributorAddress: string } {
  if (!ethers.isAddress(ENV.paxiRewardVaultAddress)) {
    throw new Error("PAXI_REWARD_VAULT_ADDRESS is not a valid EVM address.");
  }
  const distributorAddress = getConfiguredPayoutSignerAddress();
  const vaultAddress = ethers.getAddress(ENV.paxiRewardVaultAddress);
  if (vaultAddress.toLowerCase() !== distributorAddress.toLowerCase()) {
    throw new Error("The configured reward vault differs from the direct-transfer payout distributor. Configure the same address or deploy an authorized RewardVault distributor contract before enabling payouts.");
  }
  return { vaultAddress, distributorAddress };
}

export async function getNextPayoutNonce(): Promise<{ senderAddress: string; nonce: number }> {
  const senderAddress = getConfiguredPayoutSignerAddress();
  const nonce = await payoutProvider().getTransactionCount(senderAddress, "pending");
  return { senderAddress, nonce };
}

/**
 * Verifies one exact ERC-20 reward-token deposit to the server-controlled
 * escrow address. The caller binds the returned sender to the authenticated
 * owner wallet before accepting the deposit.
 */
export async function verifyRewardTokenDeposit(params: {
  network: string;
  transactionHash: string;
  tokenContractAddress: string;
  escrowRecipient?: string;
  requiredHumanAmount: string;
}): Promise<RewardEscrowResult> {
  const provider = providerFor(params.network);
  let escrowRecipient: string;
  try {
    const compatibility = assertRewardVaultPayoutCompatibility();
    escrowRecipient = params.escrowRecipient ?? compatibility.vaultAddress;
    if (escrowRecipient.toLowerCase() !== compatibility.vaultAddress.toLowerCase()) {
      return { ok: false, reason: "The supplied escrow recipient is not the configured reward vault." };
    }
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : "Reward vault and payout distributor are not safely configured." };
  }
  if (!provider) return { ok: false, reason: `Reward escrow is not supported on "${params.network}" yet.` };
  if (!isTxHash(params.transactionHash) || !ethers.isAddress(params.tokenContractAddress) || !ethers.isAddress(escrowRecipient)) {
    return { ok: false, reason: "Invalid reward deposit transaction, token, or escrow address." };
  }

  let receipt: ethers.TransactionReceipt | null;
  try {
    const breaker = getCircuitBreaker(`reward-escrow-rpc-${params.network}`, { failureThreshold: 3, resetTimeoutMs: 30_000 });
    receipt = await breaker.execute(() => provider.getTransactionReceipt(params.transactionHash));
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify the reward deposit." };
  }
  if (!receipt) return { ok: false, reason: "Reward deposit transaction not found or not confirmed yet." };
  if (receipt.status !== 1) return { ok: false, reason: "The reward deposit transaction failed on-chain." };
  if (!receipt.from) return { ok: false, reason: "The reward deposit has no transaction sender." };

  const token = new ethers.Contract(params.tokenContractAddress, ERC20_ABI, provider);
  let tokenDecimals: number;
  let tokenSymbol: string;
  try {
    const breaker = getCircuitBreaker(`reward-escrow-rpc-${params.network}`, { failureThreshold: 3, resetTimeoutMs: 30_000 });
    [tokenDecimals, tokenSymbol] = await Promise.all([
      breaker.execute(() => token.decimals()).then(Number),
      breaker.execute(() => token.symbol()).then(String),
    ]);
    if (!Number.isInteger(tokenDecimals) || tokenDecimals < 0 || tokenDecimals > 36 || !tokenSymbol.trim()) throw new Error("invalid token metadata");
  } catch {
    return { ok: false, reason: "Couldn't read the approved reward token metadata." };
  }

  let requiredUnits: bigint;
  try {
    requiredUnits = decimalToUnits(params.requiredHumanAmount, tokenDecimals);
  } catch {
    return { ok: false, reason: "The campaign reward amount cannot be represented by the token decimals." };
  }
  if (requiredUnits <= 0n) return { ok: false, reason: "The required reward escrow amount must be positive." };

  const expectedToken = ethers.getAddress(params.tokenContractAddress);
  const expectedRecipient = ethers.getAddress(escrowRecipient);
  const expectedSender = ethers.getAddress(receipt.from);
  for (const log of receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC || log.address.toLowerCase() !== expectedToken.toLowerCase()) continue;
    const from = addressFromTopic(log.topics[1]);
    const to = addressFromTopic(log.topics[2]);
    if (!from || !to || from.toLowerCase() !== expectedSender.toLowerCase() || to.toLowerCase() !== expectedRecipient.toLowerCase()) continue;
    let amount: bigint;
    try { amount = BigInt(log.data); } catch { continue; }
    if (amount !== requiredUnits) continue;
    return {
      ok: true,
      senderAddress: expectedSender,
      escrowRecipient: expectedRecipient,
      tokenDecimals,
      tokenSymbol,
      amountUnits: amount.toString(),
      amountHuman: ethers.formatUnits(amount, tokenDecimals),
      blockNumber: receipt.blockNumber,
      transactionHash: params.transactionHash,
    };
  }

  return { ok: false, reason: `No exact ${params.requiredHumanAmount} ${tokenSymbol} transfer from the transaction sender to the PAXI reward escrow was found.` };
}

export type CampaignPayoutInspection =
  | { state: "pending"; reason: string }
  | { state: "rpc_unavailable"; reason: string }
  | { state: "reverted"; reason: string }
  | { state: "confirmed"; senderAddress: string; blockNumber: number }
  | { state: "invalid"; reason: string };

/**
 * Inspect an already-broadcast transaction without treating an RPC timeout as
 * proof that the transaction does not exist. This is the recovery boundary for
 * campaign payouts: only an explicit reverted receipt permits a replacement.
 */
export async function inspectCampaignPayout(params: {
  network: string;
  transactionHash: string;
  tokenContractAddress: string;
  recipientAddress: string;
  amountUnits: string;
  expectedSenderAddress?: string;
}): Promise<CampaignPayoutInspection> {
  const provider = providerFor(params.network);
  if (!provider || !isTxHash(params.transactionHash) || !ethers.isAddress(params.tokenContractAddress) || !ethers.isAddress(params.recipientAddress)) {
    return { state: "invalid", reason: "Invalid campaign payout verification input." };
  }
  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await provider.getTransactionReceipt(params.transactionHash);
  } catch {
    return { state: "rpc_unavailable", reason: "Couldn't reach the network to verify the campaign payout; the reservation is being retained." };
  }
  if (!receipt) return { state: "pending", reason: "The payout transaction has not received a confirmed receipt yet; the reservation is being retained." };
  if (receipt.status !== 1) return { state: "reverted", reason: "The payout transaction has an explicit reverted/failed receipt." };
  if (!receipt.from) return { state: "invalid", reason: "The successful payout transaction has no transaction sender." };
  if (params.expectedSenderAddress && receipt.from.toLowerCase() !== params.expectedSenderAddress.toLowerCase()) {
    return { state: "invalid", reason: "The payout was not sent by the configured PAXI payout wallet." };
  }
  const expectedToken = params.tokenContractAddress.toLowerCase();
  const expectedRecipient = params.recipientAddress.toLowerCase();
  let expectedAmount: bigint;
  try { expectedAmount = BigInt(params.amountUnits); } catch { return { state: "invalid", reason: "Invalid campaign payout amount." }; }
  for (const log of receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC || log.address.toLowerCase() !== expectedToken) continue;
    const from = addressFromTopic(log.topics[1]);
    const to = addressFromTopic(log.topics[2]);
    if (from?.toLowerCase() !== receipt.from.toLowerCase() || to?.toLowerCase() !== expectedRecipient) continue;
    try {
      if (BigInt(log.data) === expectedAmount) return { state: "confirmed", senderAddress: receipt.from, blockNumber: receipt.blockNumber };
    } catch {
      continue;
    }
  }
  return { state: "invalid", reason: "The successful payout transaction does not contain the exact reward-token transfer to the winner; no replacement is allowed automatically." };
}

export type CampaignPayoutRecoveryAction = "retain" | "confirm" | "replace";

export function decideCampaignPayoutRecovery(state: CampaignPayoutInspection): CampaignPayoutRecoveryAction {
  if (state.state === "confirmed") return "confirm";
  if (state.state === "reverted") return "replace";
  return "retain";
}

export type CampaignPayoutRequestAction = "start" | "recover_existing" | "already_in_flight" | "already_complete";

export function classifyCampaignPayoutRequest(params: { status: string; transactionHash: string | null; leaseUntil?: Date | null; now?: Date }): CampaignPayoutRequestAction {
  if (params.status === "confirmed" || params.status === "paid") return "already_complete";
  if (params.transactionHash) return "recover_existing";
  if (params.leaseUntil && (params.now ?? new Date()).getTime() < params.leaseUntil.getTime()) return "already_in_flight";
  return "start";
}

export async function verifyCampaignPayout(params: {
  network: string;
  transactionHash: string;
  tokenContractAddress: string;
  recipientAddress: string;
  amountUnits: string;
  expectedSenderAddress?: string;
}): Promise<{ ok: true; senderAddress: string; blockNumber: number } | { ok: false; reason: string }> {
  const inspection = await inspectCampaignPayout(params);
  if (inspection.state === "confirmed") return { ok: true, senderAddress: inspection.senderAddress, blockNumber: inspection.blockNumber };
  return { ok: false, reason: inspection.reason };
}

export interface BroadcastCampaignReward {
  transactionHash: string;
  senderAddress: string;
  nonce: number;
  waitForConfirmation: () => Promise<ethers.TransactionReceipt>;
}

/** Broadcast exactly once with a reserved nonce. Confirmation is deliberately
 * separate so the database can persist the tx hash immediately after broadcast. */
export async function sendCampaignReward(params: {
  network: string;
  tokenContractAddress: string;
  recipientAddress: string;
  amountUnits: string;
  nonce?: number;
}): Promise<BroadcastCampaignReward> {
  if (params.network !== "bsc") throw new Error("Automated campaign payouts are currently enabled only on BSC.");
  const { distributorAddress: configuredSender } = assertRewardVaultPayoutCompatibility();
  if (!ethers.isAddress(params.tokenContractAddress) || !ethers.isAddress(params.recipientAddress)) throw new Error("Invalid payout token or recipient address.");
  const provider = payoutProvider();
  const signer = new ethers.Wallet(ENV.paxiPayoutPrivateKey, provider);
  if (signer.address.toLowerCase() !== configuredSender.toLowerCase()) throw new Error("Payout signer configuration changed while preparing the transaction.");
  const token = new ethers.Contract(params.tokenContractAddress, ERC20_ABI, signer);
  const nonce = params.nonce ?? await provider.getTransactionCount(signer.address, "pending");
  const transaction = await token.transfer(params.recipientAddress, BigInt(params.amountUnits), { nonce });
  return {
    transactionHash: transaction.hash,
    senderAddress: signer.address,
    nonce,
    waitForConfirmation: async () => {
      const receipt = await transaction.wait(1);
      if (!receipt || receipt.status !== 1) throw new Error("The campaign payout transaction did not confirm successfully.");
      return receipt;
    },
  };
}
