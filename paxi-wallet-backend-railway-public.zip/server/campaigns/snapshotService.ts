import { and, asc, eq, gt, inArray, lte, or, sql } from "drizzle-orm";
import {
  activityEvents,
  campaignSnapshotParticipants,
  campaignSnapshots,
  type CampaignSnapshot,
  type CampaignSnapshotParticipant,
} from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import { TRUSTED_ACTIVITY_SOURCES } from "../activity/activityService";
import type { ActivityEventType } from "../activity/activityService";

export type SnapshotStatus = "pending" | "frozen" | "calculating" | "complete" | "distributed";
export type EligibilityTier = "pending" | "not_qualified" | "minimum" | "highest";

export interface ExternalEligibilityResult {
  userOpenId: string;
  score: number;
  requirements?: Record<string, boolean>;
}

export interface SnapshotExportPage {
  snapshot: CampaignSnapshot;
  participants: Array<CampaignSnapshotParticipant & { createdAtMs: number; reviewedAtMs: number | null }>;
  nextCursor: string | null;
}

interface FrozenAggregate {
  wallets: Set<string>;
  chains: Set<string>;
  activeDays: Set<string>;
  totalConfirmedEvents: number;
  totalVolumeUsdMicros: bigint;
  eventCounts: Record<string, number>;
  volumeUsdByTypeMicros: Record<string, bigint>;
}

const BATCH_SIZE = 2_000;
const MAX_RESULTS_PER_CALCULATION = 5_000;
const USD_SCALE = 1_000_000n;
const EVENT_TYPES: ActivityEventType[] = [
  "wallet_creation",
  "token_creation",
  "buy",
  "sell",
  "swap",
  "bridge",
  "send",
  "receive",
  "deposit",
  "withdrawal",
];

function emptyCounts(): Record<string, number> {
  return Object.fromEntries(EVENT_TYPES.map((type) => [type, 0]));
}

function emptyVolumes(): Record<string, bigint> {
  return Object.fromEntries(EVENT_TYPES.map((type) => [type, 0n]));
}

function parseUsd(value: string | null): bigint {
  if (!value) return 0n;
  const [whole, fraction = ""] = value.split(".");
  if (!/^\d+$/.test(whole) || !/^\d{0,18}$/.test(fraction)) return 0n;
  return BigInt(whole) * USD_SCALE + BigInt(fraction.padEnd(6, "0").slice(0, 6) || "0");
}

function formatUsd(value: bigint): string {
  const whole = value / USD_SCALE;
  const fraction = (value % USD_SCALE).toString().padStart(6, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function scoreTier(score: number): Exclude<EligibilityTier, "pending"> {
  if (!Number.isInteger(score) || score < 0 || score > 10) throw new Error("Eligibility score must be an integer from 0 to 10");
  if (score <= 4) return "not_qualified";
  if (score <= 9) return "minimum";
  return "highest";
}

function parseCursor(cursor: string | undefined): number | undefined {
  if (!cursor) return undefined;
  if (!/^\d{1,16}$/.test(cursor)) throw new Error("Invalid snapshot cursor");
  const value = Number(cursor);
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error("Invalid snapshot cursor");
  return value;
}

async function getSnapshot(snapshotId: number): Promise<CampaignSnapshot> {
  // Snapshot state transitions are admin-controlled writes; read them from the
  // primary so replica lag cannot cause a stale status decision or overwrite.
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [snapshot] = await db.select().from(campaignSnapshots).where(eq(campaignSnapshots.id, snapshotId)).limit(1);
  if (!snapshot) throw new Error("Campaign snapshot not found");
  return snapshot;
}

export async function createCampaignSnapshot(
  campaignId: number,
  snapshotDate: Date,
  createdByOpenId: string,
): Promise<CampaignSnapshot> {
  if (!Number.isSafeInteger(campaignId) || campaignId <= 0) throw new Error("Invalid campaign id");
  if (!createdByOpenId || createdByOpenId.length > 64) throw new Error("Invalid creator identifier");
  if (!(snapshotDate instanceof Date) || Number.isNaN(snapshotDate.getTime())) throw new Error("Invalid snapshot date");
  if (snapshotDate.getTime() > Date.now()) throw new Error("Snapshot date cannot be in the future");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(campaignSnapshots)
    .where(and(eq(campaignSnapshots.campaignId, campaignId), eq(campaignSnapshots.snapshotDate, snapshotDate)))
    .limit(1);
  if (existing[0]) return existing[0];

  const result = await db.insert(campaignSnapshots).values({
    campaignId,
    snapshotDate,
    createdByOpenId,
    status: "pending",
    totalParticipants: 0,
    qualifiedCount: 0,
    snapshotData: { version: "paxi-snapshot-v1", state: "pending" },
  });
  const id = Number((result as unknown as { insertId?: number | string }).insertId);
  if (!Number.isSafeInteger(id) || id <= 0) throw new Error("Snapshot insert did not return an id");
  return getSnapshot(id);
}

export async function freezeCampaignSnapshot(snapshotId: number): Promise<CampaignSnapshot> {
  const snapshot = await getSnapshot(snapshotId);
  if (snapshot.status === "frozen" || snapshot.status === "calculating" || snapshot.status === "complete" || snapshot.status === "distributed") return snapshot;
  if (snapshot.status !== "pending") throw new Error("Snapshot cannot be frozen from its current state");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const claim = await db
    .update(campaignSnapshots)
    .set({ status: "calculating" })
    .where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "pending")));
  if (Number((claim as { affectedRows?: number }).affectedRows ?? 0) !== 1) return getSnapshot(snapshotId);

  try {
    await db.delete(campaignSnapshotParticipants).where(eq(campaignSnapshotParticipants.snapshotId, snapshotId));
    let lastUserOpenId = "";
    let lastActivityId = 0;
    let currentUserOpenId: string | null = null;
    let currentAggregate: FrozenAggregate | null = null;
    let totalParticipants = 0;
    let participantBatch: Array<{
      snapshotId: number;
      userOpenId: string;
      wallets: string[];
      chains: string[];
      activeDays: number;
      totalConfirmedEvents: number;
      totalVolumeUsd: string;
      eventCounts: Record<string, number>;
      volumeUsdByType: Record<string, string>;
      eligibilityTier: "pending";
    }> = [];

    const flushCurrentUser = async () => {
      if (!currentUserOpenId || !currentAggregate) return;
      participantBatch.push({
        snapshotId,
        userOpenId: currentUserOpenId,
        wallets: [...currentAggregate.wallets],
        chains: [...currentAggregate.chains],
        activeDays: currentAggregate.activeDays.size,
        totalConfirmedEvents: currentAggregate.totalConfirmedEvents,
        totalVolumeUsd: formatUsd(currentAggregate.totalVolumeUsdMicros),
        eventCounts: currentAggregate.eventCounts,
        volumeUsdByType: Object.fromEntries(Object.entries(currentAggregate.volumeUsdByTypeMicros).map(([type, value]) => [type, formatUsd(value)])),
        eligibilityTier: "pending",
      });
      totalParticipants += 1;
      if (participantBatch.length >= 500) {
        await db.insert(campaignSnapshotParticipants).values(participantBatch);
        participantBatch = [];
      }
      currentUserOpenId = null;
      currentAggregate = null;
    };

    while (true) {
      const conditions = [eq(activityEvents.status, "confirmed"), inArray(activityEvents.verificationSource, [...TRUSTED_ACTIVITY_SOURCES]), lte(activityEvents.createdAt, snapshot.snapshotDate)];
      if (lastUserOpenId) {
        conditions.push(or(gt(activityEvents.userOpenId, lastUserOpenId), and(eq(activityEvents.userOpenId, lastUserOpenId), gt(activityEvents.id, lastActivityId)))!);
      }
      const rows = await db
        .select()
        .from(activityEvents)
        .where(and(...conditions))
        .orderBy(asc(activityEvents.userOpenId), asc(activityEvents.id))
        .limit(BATCH_SIZE);
      if (rows.length === 0) break;

      for (const row of rows) {
        if (currentUserOpenId !== row.userOpenId) {
          await flushCurrentUser();
          currentUserOpenId = row.userOpenId;
          currentAggregate = {
            wallets: new Set<string>(),
            chains: new Set<string>(),
            activeDays: new Set<string>(),
            totalConfirmedEvents: 0,
            totalVolumeUsdMicros: 0n,
            eventCounts: emptyCounts(),
            volumeUsdByTypeMicros: emptyVolumes(),
          };
        }
        currentAggregate!.wallets.add(row.walletAddress);
        currentAggregate!.chains.add(row.chainId);
        currentAggregate!.activeDays.add(row.createdAt.toISOString().slice(0, 10));
        currentAggregate!.totalConfirmedEvents += 1;
        currentAggregate!.totalVolumeUsdMicros += parseUsd(row.amountUsd);
        currentAggregate!.eventCounts[row.eventType] = (currentAggregate!.eventCounts[row.eventType] ?? 0) + 1;
        currentAggregate!.volumeUsdByTypeMicros[row.eventType] = (currentAggregate!.volumeUsdByTypeMicros[row.eventType] ?? 0n) + parseUsd(row.amountUsd);
        lastUserOpenId = row.userOpenId;
        lastActivityId = Number(row.id);
      }
      if (rows.length < BATCH_SIZE) break;
    }
    await flushCurrentUser();
    if (participantBatch.length > 0) await db.insert(campaignSnapshotParticipants).values(participantBatch);

    await db
      .update(campaignSnapshots)
      .set({
        status: "frozen",
        frozenAt: new Date(),
        totalParticipants,
        qualifiedCount: 0,
        snapshotData: {
          version: "paxi-snapshot-v1",
          snapshotDateMs: snapshot.snapshotDate.getTime(),
          participantStorage: "campaignSnapshotParticipants",
          externalEligibility: "required",
        },
      })
      .where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "calculating")));
    return getSnapshot(snapshotId);
  } catch (error) {
    await db
      .update(campaignSnapshots)
      .set({ status: "pending", frozenAt: null, totalParticipants: 0, qualifiedCount: 0 })
      .where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "calculating")));
    throw error;
  }
}

export async function applyExternalEligibility(
  snapshotId: number,
  results: ExternalEligibilityResult[],
  finalize: boolean,
): Promise<CampaignSnapshot> {
  if (results.length > MAX_RESULTS_PER_CALCULATION) throw new Error(`At most ${MAX_RESULTS_PER_CALCULATION} eligibility results may be applied per request`);
  const snapshot = await getSnapshot(snapshotId);
  if (!["frozen", "calculating"].includes(snapshot.status)) throw new Error("Snapshot must be frozen before eligibility is applied");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (results.length > 0 || finalize) {
    const claim = await db
      .update(campaignSnapshots)
      .set({ status: "calculating" })
      .where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "frozen")));
    if (Number((claim as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
      const current = await getSnapshot(snapshotId);
      if (current.status !== "calculating") throw new Error("Snapshot is no longer accepting eligibility results");
    }
  }

  for (const result of results) {
    if (!result.userOpenId || result.userOpenId.length > 64) throw new Error("Invalid eligibility user identifier");
    const tier = scoreTier(result.score);
    const [participant] = await db
      .select({ id: campaignSnapshotParticipants.id })
      .from(campaignSnapshotParticipants)
      .where(and(eq(campaignSnapshotParticipants.snapshotId, snapshotId), eq(campaignSnapshotParticipants.userOpenId, result.userOpenId)))
      .limit(1);
    if (!participant) throw new Error(`Eligibility result does not belong to snapshot ${snapshotId}`);
    await db
      .update(campaignSnapshotParticipants)
      .set({ externalScore: result.score, requirements: result.requirements ?? null, eligibilityTier: tier, reviewedAt: new Date() })
      .where(eq(campaignSnapshotParticipants.id, participant.id));
  }

  if (finalize) {
    const [pending] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(campaignSnapshotParticipants)
      .where(and(eq(campaignSnapshotParticipants.snapshotId, snapshotId), eq(campaignSnapshotParticipants.eligibilityTier, "pending")));
    if (Number(pending?.count ?? 0) > 0) throw new Error("Cannot finalize a snapshot while participants lack eligibility scores");
    const [qualified] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(campaignSnapshotParticipants)
      .where(and(eq(campaignSnapshotParticipants.snapshotId, snapshotId), inArray(campaignSnapshotParticipants.eligibilityTier, ["minimum", "highest"])));
    await db
      .update(campaignSnapshots)
      .set({ status: "complete", qualifiedCount: Number(qualified?.count ?? 0), calculatedAt: new Date() })
      .where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "calculating")));
  }
  return getSnapshot(snapshotId);
}

export async function exportCampaignSnapshot(snapshotId: number, options: { limit?: number; cursor?: string; eligibleOnly?: boolean } = {}): Promise<SnapshotExportPage> {
  const snapshot = await getSnapshot(snapshotId);
  const limit = Math.min(Math.max(Math.trunc(options.limit ?? 100), 1), 1_000);
  const cursor = parseCursor(options.cursor);
  const db = await getReadDb();
  if (!db) throw new Error("Database not available");
  const conditions = [eq(campaignSnapshotParticipants.snapshotId, snapshotId)];
  if (cursor) conditions.push(gt(campaignSnapshotParticipants.id, cursor));
  if (options.eligibleOnly) conditions.push(inArray(campaignSnapshotParticipants.eligibilityTier, ["minimum", "highest"]));
  const rows = await db
    .select()
    .from(campaignSnapshotParticipants)
    .where(and(...conditions))
    .orderBy(asc(campaignSnapshotParticipants.id))
    .limit(limit + 1);
  const hasMore = rows.length > limit;
  const pageRows = hasMore ? rows.slice(0, limit) : rows;
  return {
    snapshot,
    participants: pageRows.map((row) => ({ ...row, createdAtMs: row.createdAt.getTime(), reviewedAtMs: row.reviewedAt?.getTime() ?? null })),
    nextCursor: hasMore ? String(pageRows[pageRows.length - 1]?.id ?? "") : null,
  };
}

export async function getCampaignSnapshotEligibilityPayload(snapshotId: number): Promise<{ snapshotId: number; snapshotDateMs: number; participants: Array<{ userOpenId: string; wallets: string[]; chains: string[]; activeDays: number; totalConfirmedEvents: number; totalVolumeUsd: string; eventCounts: Record<string, number>; volumeUsdByType: Record<string, string> }> }> {
  const participants: Array<{ userOpenId: string; wallets: string[]; chains: string[]; activeDays: number; totalConfirmedEvents: number; totalVolumeUsd: string; eventCounts: Record<string, number>; volumeUsdByType: Record<string, string> }> = [];
  let cursor: string | undefined;
  let snapshotDateMs = 0;
  do {
    const page = await exportCampaignSnapshot(snapshotId, { limit: 1_000, cursor });
    snapshotDateMs = page.snapshot.snapshotDate.getTime();
    participants.push(...page.participants.map((row) => ({
      userOpenId: row.userOpenId,
      wallets: row.wallets,
      chains: row.chains,
      activeDays: row.activeDays,
      totalConfirmedEvents: row.totalConfirmedEvents,
      totalVolumeUsd: row.totalVolumeUsd,
      eventCounts: row.eventCounts,
      volumeUsdByType: row.volumeUsdByType,
    })));
    cursor = page.nextCursor ?? undefined;
  } while (cursor);
  return { snapshotId, snapshotDateMs, participants };
}
