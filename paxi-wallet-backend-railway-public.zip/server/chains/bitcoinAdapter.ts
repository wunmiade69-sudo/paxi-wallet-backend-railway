import * as bitcoin from "bitcoinjs-lib";
import type { ChainAdapter } from "./types";
import { withRpcHttp, getPrimaryRpcUrl } from "./rpc";

export class BitcoinAdapter implements ChainAdapter {
  readonly network = "bitcoin";
  readonly family = "bitcoin" as const;
  readonly nativeSymbol = "BTC";
  get rpcUrl(): string {
    return getPrimaryRpcUrl("bitcoin");
  }

  normalizeIdentifier(identifier: string): string {
    return identifier.trim();
  }

  validateIdentifier(identifier: string): boolean {
    try {
      bitcoin.address.toOutputScript(identifier, bitcoin.networks.bitcoin);
      return true;
    } catch {
      return false;
    }
  }

  async getNativeBalance(address: string): Promise<string> {
    const normalized = this.normalizeIdentifier(address);
    if (!this.validateIdentifier(normalized)) throw new Error("Invalid Bitcoin address");
    const data = await withRpcHttp("bitcoin", async (endpoint) => {
      const response = await fetch(`${endpoint}/address/${encodeURIComponent(normalized)}`, {
        signal: AbortSignal.timeout(8_000),
      });
      if (!response.ok) throw new Error("Bitcoin balance request failed");
      return (await response.json()) as {
        chain_stats?: { funded_txo_sum?: number; spent_txo_sum?: number };
        mempool_stats?: { funded_txo_sum?: number; spent_txo_sum?: number };
      };
    });

    const confirmed = (data.chain_stats?.funded_txo_sum ?? 0) - (data.chain_stats?.spent_txo_sum ?? 0);
    const pending = (data.mempool_stats?.funded_txo_sum ?? 0) - (data.mempool_stats?.spent_txo_sum ?? 0);
    return ((confirmed + pending) / 100_000_000).toString();
  }

  getExplorerUrl(kind: "tx" | "address", value: string): string {
    return `https://blockstream.info/${kind === "tx" ? "tx" : "address"}/${encodeURIComponent(value)}`;
  }
}
