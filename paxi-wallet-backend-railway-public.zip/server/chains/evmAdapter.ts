import { formatEther, getAddress, JsonRpcProvider } from "ethers";
import type { ChainAdapter } from "./types";
import { withEvmRpc, getPrimaryRpcUrl } from "./rpc";

export interface EvmNetworkDefinition {
  network: string;
  chainId: number;
  nativeSymbol: string;
  rpcUrl: string;
  explorer: string;
}

export class EvmAdapter implements ChainAdapter {
  readonly family = "evm" as const;

  constructor(private readonly definition: EvmNetworkDefinition) {}

  get network(): string {
    return this.definition.network;
  }

  get nativeSymbol(): string {
    return this.definition.nativeSymbol;
  }

  get rpcUrl(): string {
    return getPrimaryRpcUrl(this.network as Parameters<typeof getPrimaryRpcUrl>[0]);
  }

  normalizeIdentifier(identifier: string): string {
    const value = String(identifier).trim();
    try {
      return getAddress(value);
    } catch {
      return value.toLowerCase();
    }
  }

  validateIdentifier(identifier: string): boolean {
    try {
      getAddress(identifier);
      return true;
    } catch {
      return false;
    }
  }

  async getNativeBalance(address: string): Promise<string> {
    const normalized = this.normalizeIdentifier(address);
    if (!this.validateIdentifier(normalized)) throw new Error(`Invalid ${this.network} address`);
    const balance = await withEvmRpc(this.network as Parameters<typeof withEvmRpc>[0], (provider) => provider.getBalance(normalized));
    return formatEther(balance);
  }

  getExplorerUrl(kind: "tx" | "address", value: string): string {
    return `${this.definition.explorer}/${kind === "tx" ? "tx" : "address"}/${encodeURIComponent(value)}`;
  }
}
