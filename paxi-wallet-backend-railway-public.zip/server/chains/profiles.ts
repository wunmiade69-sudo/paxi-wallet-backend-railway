import type { ProviderCapability } from "../providers/contracts";
import type { SupportedNetwork } from "./types";

export type ChainType = "EVM" | "SOLANA" | "BITCOIN" | "MOVE" | "OTHER";

export interface ChainCapabilities {
  readonly supportsNative: boolean;
  readonly supportsFungibleTokens: boolean;
  readonly supportsNfts: boolean;
  readonly supportsTransactions: boolean;
  readonly providerCapabilities: readonly ProviderCapability[];
}

export interface ChainProviderProfile {
  readonly market: readonly string[];
  readonly metadata: readonly string[];
  readonly logo: readonly string[];
  readonly chart: readonly string[];
  readonly liquidity: readonly string[];
  readonly security: readonly string[];
  readonly dex: readonly string[];
}

export interface ChainDefinition {
  readonly chainKey: SupportedNetwork;
  readonly chainId: string | number;
  readonly chainType: ChainType;
  readonly displayName: string;
  readonly nativeAsset: { readonly symbol: string; readonly identifier: "native" };
  readonly addressFormat: "evm" | "solana" | "bitcoin";
  readonly explorer: string;
  readonly capabilities: ChainCapabilities;
  readonly providerProfile: ChainProviderProfile;
  readonly rpcEnvKeys: readonly string[];
}

const commonMarketCapabilities: readonly ProviderCapability[] = [
  "PRICE",
  "TOKEN_METADATA",
  "LOGO",
  "SEARCH",
  "OHLCV",
  "LIQUIDITY",
];

const definitions: Record<SupportedNetwork, ChainDefinition> = {
  ethereum: {
    chainKey: "ethereum",
    chainId: 1,
    chainType: "EVM",
    displayName: "Ethereum",
    nativeAsset: { symbol: "ETH", identifier: "native" },
    addressFormat: "evm",
    explorer: "https://etherscan.io",
    capabilities: { supportsNative: true, supportsFungibleTokens: true, supportsNfts: true, supportsTransactions: true, providerCapabilities: commonMarketCapabilities },
    providerProfile: {
      market: ["coingecko", "dexscreener", "dexpaprika"],
      metadata: ["coingecko", "dexpaprika"],
      logo: ["coingecko", "dexscreener", "dexpaprika"],
      chart: ["coingecko", "dexscreener"],
      liquidity: ["dexscreener", "dexpaprika"],
      security: ["goplus"],
      dex: [],
    },
    rpcEnvKeys: ["ETH_RPC_URL", "ETH_RPC_FALLBACK_URL", "ETH_RPC_FALLBACK_URL_2"],
  },
  bsc: {
    chainKey: "bsc",
    chainId: 56,
    chainType: "EVM",
    displayName: "BNB Chain",
    nativeAsset: { symbol: "BNB", identifier: "native" },
    addressFormat: "evm",
    explorer: "https://bscscan.com",
    capabilities: { supportsNative: true, supportsFungibleTokens: true, supportsNfts: true, supportsTransactions: true, providerCapabilities: commonMarketCapabilities },
    providerProfile: {
      market: ["coingecko", "dexscreener", "dexpaprika"],
      metadata: ["coingecko", "dexpaprika"],
      logo: ["coingecko", "dexscreener", "dexpaprika"],
      chart: ["coingecko", "dexscreener"],
      liquidity: ["dexscreener", "dexpaprika"],
      security: ["goplus"],
      dex: [],
    },
    rpcEnvKeys: ["BSC_RPC_URL", "BSC_RPC_FALLBACK_URL", "BSC_RPC_FALLBACK_URL_2"],
  },
  polygon: {
    chainKey: "polygon",
    chainId: 137,
    chainType: "EVM",
    displayName: "Polygon",
    nativeAsset: { symbol: "POL", identifier: "native" },
    addressFormat: "evm",
    explorer: "https://polygonscan.com",
    capabilities: { supportsNative: true, supportsFungibleTokens: true, supportsNfts: true, supportsTransactions: true, providerCapabilities: commonMarketCapabilities },
    providerProfile: {
      market: ["coingecko", "dexscreener", "dexpaprika"],
      metadata: ["coingecko", "dexpaprika"],
      logo: ["coingecko", "dexscreener", "dexpaprika"],
      chart: ["coingecko", "dexscreener"],
      liquidity: ["dexscreener", "dexpaprika"],
      security: ["goplus"],
      dex: [],
    },
    rpcEnvKeys: ["POLYGON_RPC_URL", "POLYGON_RPC_FALLBACK_URL", "POLYGON_RPC_FALLBACK_URL_2"],
  },
  arbitrum: {
    chainKey: "arbitrum",
    chainId: 42161,
    chainType: "EVM",
    displayName: "Arbitrum",
    nativeAsset: { symbol: "ETH", identifier: "native" },
    addressFormat: "evm",
    explorer: "https://arbiscan.io",
    capabilities: { supportsNative: true, supportsFungibleTokens: true, supportsNfts: false, supportsTransactions: true, providerCapabilities: commonMarketCapabilities },
    providerProfile: {
      market: ["coingecko", "dexscreener", "dexpaprika"],
      metadata: ["coingecko", "dexpaprika"],
      logo: ["coingecko", "dexscreener", "dexpaprika"],
      chart: ["coingecko", "dexscreener"],
      liquidity: ["dexscreener", "dexpaprika"],
      security: ["goplus"],
      dex: [],
    },
    rpcEnvKeys: ["ARBITRUM_RPC_URL", "ARBITRUM_RPC_FALLBACK_URL", "ARBITRUM_RPC_FALLBACK_URL_2"],
  },
  solana: {
    chainKey: "solana",
    chainId: "solana-mainnet",
    chainType: "SOLANA",
    displayName: "Solana",
    nativeAsset: { symbol: "SOL", identifier: "native" },
    addressFormat: "solana",
    explorer: "https://explorer.solana.com",
    capabilities: { supportsNative: true, supportsFungibleTokens: true, supportsNfts: true, supportsTransactions: true, providerCapabilities: commonMarketCapabilities },
    providerProfile: {
      market: ["birdeye", "dexscreener", "coingecko"],
      metadata: ["birdeye", "coingecko"],
      logo: ["birdeye", "dexscreener", "coingecko"],
      chart: ["birdeye", "coingecko"],
      liquidity: ["birdeye", "dexscreener"],
      security: ["goplus"],
      dex: [],
    },
    rpcEnvKeys: ["SOLANA_RPC_URL", "SOLANA_RPC_FALLBACK_URL", "SOLANA_RPC_FALLBACK_URL_2"],
  },
  bitcoin: {
    chainKey: "bitcoin",
    chainId: "bitcoin-mainnet",
    chainType: "BITCOIN",
    displayName: "Bitcoin",
    nativeAsset: { symbol: "BTC", identifier: "native" },
    addressFormat: "bitcoin",
    explorer: "https://blockstream.info",
    capabilities: { supportsNative: true, supportsFungibleTokens: false, supportsNfts: false, supportsTransactions: true, providerCapabilities: ["PRICE", "TOKEN_METADATA", "LOGO", "SEARCH", "OHLCV", "BALANCE", "TRANSACTION_HISTORY"] },
    providerProfile: {
      market: ["coingecko"],
      metadata: ["coingecko"],
      logo: ["coingecko"],
      chart: ["coingecko"],
      liquidity: [],
      security: [],
      dex: [],
    },
    rpcEnvKeys: ["BTC_RPC_URL", "BTC_FALLBACK_URL", "BTC_FALLBACK_URL_2"],
  },
};

export function getChainDefinition(chain: SupportedNetwork): ChainDefinition {
  return definitions[chain];
}

export function listChainDefinitions(): ChainDefinition[] {
  return Object.values(definitions);
}
