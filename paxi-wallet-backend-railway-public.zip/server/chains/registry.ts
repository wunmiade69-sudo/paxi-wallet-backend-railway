import { BitcoinAdapter } from "./bitcoinAdapter";
import { EvmAdapter } from "./evmAdapter";
import { SolanaAdapter } from "./solanaAdapter";
import { UnsupportedNetworkError, type ChainAdapter, type SupportedNetwork } from "./types";
import { getChainDefinition, listChainDefinitions, type ChainDefinition } from "./profiles";
import { getPrimaryRpcUrl } from "./rpc";

const adapters: Record<string, ChainAdapter> = {
  ethereum: new EvmAdapter({
    network: "ethereum",
    chainId: 1,
    nativeSymbol: "ETH",
    rpcUrl: getPrimaryRpcUrl("ethereum"),
    explorer: "https://etherscan.io",
  }),
  bsc: new EvmAdapter({
    network: "bsc",
    chainId: 56,
    nativeSymbol: "BNB",
    rpcUrl: getPrimaryRpcUrl("bsc"),
    explorer: "https://bscscan.com",
  }),
  polygon: new EvmAdapter({
    network: "polygon",
    chainId: 137,
    nativeSymbol: "POL",
    rpcUrl: getPrimaryRpcUrl("polygon"),
    explorer: "https://polygonscan.com",
  }),
  arbitrum: new EvmAdapter({
    network: "arbitrum",
    chainId: 42161,
    nativeSymbol: "ETH",
    rpcUrl: getPrimaryRpcUrl("arbitrum"),
    explorer: "https://arbiscan.io",
  }),
  solana: new SolanaAdapter(),
  bitcoin: new BitcoinAdapter(),
};

export function getChainAdapter(network: string): ChainAdapter {
  const adapter = adapters[network];
  if (!adapter) throw new UnsupportedNetworkError(network);
  return adapter;
}

export function getRegisteredChainDefinition(network: string): ChainDefinition {
  if (!isSupportedNetworkKey(network)) throw new UnsupportedNetworkError(network);
  return getChainDefinition(network);
}

export function listRegisteredChainDefinitions(): ChainDefinition[] {
  return listChainDefinitions();
}

function isSupportedNetworkKey(value: string): value is SupportedNetwork {
  return Object.prototype.hasOwnProperty.call(adapters, value);
}

export function listChainAdapters() {
  return Object.values(adapters).map((adapter) => ({
    network: adapter.network,
    family: adapter.family,
    nativeSymbol: adapter.nativeSymbol,
    rpcUrl: adapter.rpcUrl ?? null,
  }));
}
