import { describe, expect, it, vi, afterEach } from 'vitest';
import { getConfirmationDepth, getReceiptConfirmations } from './rpc';

describe('RPC confirmation policy', () => {
  afterEach(() => vi.unstubAllEnvs());

  it('uses conservative chain-specific defaults', () => {
    expect(getConfirmationDepth('ethereum')).toBe(2);
    expect(getConfirmationDepth('bsc')).toBe(3);
  });

  it('allows a bounded environment override', () => {
    vi.stubEnv('ETHEREUM_CONFIRMATIONS', '6');
    expect(getConfirmationDepth('ethereum')).toBe(6);
  });

  it('rejects invalid confirmation overrides', () => {
    vi.stubEnv('BSC_CONFIRMATIONS', '0');
    expect(getConfirmationDepth('bsc')).toBe(3);
    vi.stubEnv('BSC_CONFIRMATIONS', '999');
    expect(getConfirmationDepth('bsc')).toBe(3);
  });

  it('counts the mined block as the first confirmation', () => {
    expect(getReceiptConfirmations(100, 100)).toBe(1);
    expect(getReceiptConfirmations(102, 100)).toBe(3);
  });
});
