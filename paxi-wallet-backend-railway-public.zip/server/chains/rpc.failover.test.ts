import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { classifyRpcError, getRpcUrls, withRpcHttp } from "./rpc";

const ENV_KEYS = ["ETH_RPC_URL", "ETH_RPC_FALLBACK_URL", "ETH_RPC_FALLBACK_URL_2"] as const;
const originalEnv: Record<string, string | undefined> = {};

beforeEach(() => {
  for (const key of ENV_KEYS) originalEnv[key] = process.env[key];
});

afterEach(() => {
  for (const key of ENV_KEYS) {
    if (originalEnv[key] === undefined) delete process.env[key];
    else process.env[key] = originalEnv[key];
  }
});

describe("RPC failover (server/chains/rpc.ts)", () => {
  it("exposes every configured endpoint plus the built-in default, deduplicated", () => {
    process.env.ETH_RPC_URL = "https://primary.example.com";
    process.env.ETH_RPC_FALLBACK_URL = "https://fallback-1.example.com";
    process.env.ETH_RPC_FALLBACK_URL_2 = "https://fallback-1.example.com"; // deliberate duplicate
    const urls = getRpcUrls("ethereum");
    expect(urls).toEqual([
      "https://primary.example.com/",
      "https://fallback-1.example.com/",
      "https://ethereum-rpc.publicnode.com/",
    ]);
  });

  it("falls over to the next endpoint when the primary throws, without surfacing a false success on the failed one", async () => {
    process.env.ETH_RPC_URL = "https://primary.example.com";
    process.env.ETH_RPC_FALLBACK_URL = "https://fallback-1.example.com";
    const attempted: string[] = [];
    const result = await withRpcHttp("ethereum", async (endpoint) => {
      attempted.push(endpoint);
      if (endpoint.includes("primary")) throw new Error("ECONNREFUSED");
      return "ok-from-fallback";
    });
    expect(result).toBe("ok-from-fallback");
    expect(attempted[0]).toContain("primary");
    expect(attempted[1]).toContain("fallback-1");
  });

  it("classifies a timeout distinctly from a hard unavailability, since callers must treat them differently", () => {
    expect(classifyRpcError(new Error("ETIMEDOUT: request timed out"), "ethereum").code).toBe("RPC_TIMEOUT");
    expect(classifyRpcError(new Error("connect ECONNREFUSED"), "ethereum").code).toBe("RPC_UNAVAILABLE");
    expect(classifyRpcError(new Error("429 Too Many Requests"), "ethereum").code).toBe("RPC_RATE_LIMITED");
  });

  it("surfaces a classified error (not a false 'not broadcast' signal) when every configured endpoint fails", async () => {
    process.env.ETH_RPC_URL = "https://primary.example.com";
    process.env.ETH_RPC_FALLBACK_URL = "https://fallback-1.example.com";
    let attempts = 0;
    await expect(
      withRpcHttp("ethereum", async () => {
        attempts += 1;
        throw new Error("ETIMEDOUT");
      }),
    ).rejects.toMatchObject({ code: "RPC_TIMEOUT" });
    // Every configured endpoint (including the built-in default) must actually
    // have been tried - a caller must not give up after only the primary,
    // since that is exactly the situation that must resolve to
    // RECONCILIATION_REQUIRED rather than a premature "safe to rebroadcast".
    expect(attempts).toBe(3);
  });
});
