import { afterEach, describe, expect, it, vi } from "vitest";
import { classifyRpcError, getRpcUrls, RpcProviderError, withRpcHttp } from "./rpc";

afterEach(() => {
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
});

describe("server RPC endpoint policy", () => {
  it("orders valid configured endpoints before the public fallback and rejects embedded credentials", () => {
    vi.stubEnv("BSC_RPC_URL", "https://primary.example/rpc");

    const urls = getRpcUrls("bsc");

    expect(urls[0]).toBe("https://primary.example/rpc");
    expect(urls).toContain("https://bsc-rpc.publicnode.com/");

    vi.stubEnv("BSC_RPC_URL", "https://user:secret@unsafe.example/rpc");
    expect(getRpcUrls("bsc")).not.toContain(expect.stringContaining("unsafe.example"));
    expect(getRpcUrls("ethereum")).toEqual(["https://ethereum-rpc.publicnode.com/"]);
  });

  it("classifies provider failures without turning them into transaction failures", () => {
    expect(classifyRpcError(new Error("request timed out"), "bsc").code).toBe("RPC_TIMEOUT");
    expect(classifyRpcError(new Error("HTTP 429 rate limit"), "bsc").code).toBe("RPC_RATE_LIMITED");
    expect(classifyRpcError(new Error("invalid JSON response"), "bsc").code).toBe("RPC_INVALID_RESPONSE");
    const unavailable = classifyRpcError(new Error("connection refused"), "bsc");
    expect(unavailable).toBeInstanceOf(RpcProviderError);
    expect(unavailable.code).toBe("RPC_UNAVAILABLE");
  });

  it("fails over to the next endpoint after a request failure", async () => {
    vi.stubEnv("BSC_RPC_URL", "https://primary-failover.example/rpc");
    const attempts: string[] = [];

    const result = await withRpcHttp("bsc", async (endpoint) => {
      attempts.push(endpoint);
      if (endpoint.includes("primary-failover")) throw new Error("primary unavailable");
      return { endpoint };
    });

    expect(result.endpoint).toBe("https://bsc-rpc.publicnode.com/");
    expect(attempts.slice(0, 2).map((url) => new URL(url).hostname)).toEqual([
      "primary-failover.example",
      "bsc-rpc.publicnode.com",
    ]);
  });
});

void vi;
