import { ethers } from "ethers";
import { getCircuitBreaker } from "../resilience/circuitBreaker";
import { listChainDefinitions } from "./profiles";
import { getDefaultConfirmationDepth } from "../../shared/confirmationPolicy";

export type RpcNetwork = "ethereum" | "bsc" | "polygon" | "arbitrum" | "solana" | "bitcoin";
export type RpcErrorCode =
  | "RPC_TIMEOUT"
  | "RPC_UNAVAILABLE"
  | "RPC_RATE_LIMITED"
  | "RPC_INVALID_RESPONSE"
  | "RPC_CHAIN_MISMATCH"
  | "RPC_TRANSACTION_NOT_FOUND";

export class RpcProviderError extends Error {
  readonly code: RpcErrorCode;
  readonly network: RpcNetwork;
  readonly endpoint?: string;
  constructor(code: RpcErrorCode, network: RpcNetwork, message: string, endpoint?: string) {
    super(message);
    this.name = "RpcProviderError";
    this.code = code;
    this.network = network;
    this.endpoint = endpoint;
  }
}

const DEFAULT_RPC_URLS: Record<RpcNetwork, string> = {
  ethereum: "https://ethereum-rpc.publicnode.com",
  bsc: "https://bsc-rpc.publicnode.com",
  polygon: "https://polygon-bor-rpc.publicnode.com",
  arbitrum: "https://arbitrum-one-rpc.publicnode.com",
  solana: "https://api.mainnet-beta.solana.com",
  bitcoin: "https://blockstream.info/api",
};

const RPC_ENV_KEYS: Record<RpcNetwork, readonly string[]> = Object.fromEntries(
  listChainDefinitions().map((definition) => [definition.chainKey, definition.rpcEnvKeys]),
) as Record<RpcNetwork, readonly string[]>;

function validRpcUrl(value: string | undefined): string | null {
  if (!value?.trim()) return null;
  try {
    const parsed = new URL(value.trim());
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    if (!parsed.hostname || parsed.username || parsed.password) return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

export function getRpcUrls(network: RpcNetwork): string[] {
  const configured = (RPC_ENV_KEYS[network] ?? [])
    .map((key) => validRpcUrl(process.env[key]))
    .filter((value): value is string => Boolean(value));
  const fallback = validRpcUrl(DEFAULT_RPC_URLS[network]);
  return [...new Set([...configured, ...(fallback ? [fallback] : [])])];
}

export function createEvmRpcProvider(
  network: Exclude<RpcNetwork, "solana" | "bitcoin">,
  rpcUrl?: string,
): ethers.JsonRpcProvider {
  const endpoint = rpcUrl ?? getRpcUrls(network)[0];
  if (!endpoint) throw new RpcProviderError("RPC_UNAVAILABLE", network, `No RPC endpoint configured for ${network}`);
  const request = new ethers.FetchRequest(endpoint);
  request.timeout = Number(process.env.RPC_TIMEOUT_MS ?? 8_000);
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

export function classifyRpcError(error: unknown, network: RpcNetwork, endpoint?: string): RpcProviderError {
  if (error instanceof RpcProviderError) return error;
  const message = error instanceof Error ? error.message : String(error);
  const lower = message.toLowerCase();
  const code: RpcErrorCode = /timeout|timed out|etimedout|abort/.test(lower)
    ? "RPC_TIMEOUT"
    : /429|rate.?limit|too many requests/.test(lower)
      ? "RPC_RATE_LIMITED"
      : /invalid.*(json|response)|bad response|malformed/.test(lower)
        ? "RPC_INVALID_RESPONSE"
        : "RPC_UNAVAILABLE";
  return new RpcProviderError(code, network, message, endpoint);
}

async function failover<T>(network: RpcNetwork, operation: (endpoint: string) => Promise<T>): Promise<T> {
  const endpoints = getRpcUrls(network);
  let lastError: RpcProviderError | undefined;
  for (const [index, endpoint] of endpoints.entries()) {
    const breaker = getCircuitBreaker(`rpc-${network}-${index}`, { failureThreshold: 3, resetTimeoutMs: 15_000 });
    try {
      return await breaker.execute(() => operation(endpoint));
    } catch (error) {
      lastError = classifyRpcError(error, network, endpoint);
      if (index < endpoints.length - 1) await new Promise((resolve) => setTimeout(resolve, Math.min(150 * (index + 1), 450)));
    }
  }
  throw lastError ?? new RpcProviderError("RPC_UNAVAILABLE", network, `RPC unavailable for ${network}`);
}

export async function withEvmRpc<T>(
  network: Exclude<RpcNetwork, "solana" | "bitcoin">,
  operation: (provider: ethers.JsonRpcProvider) => Promise<T>,
): Promise<T> {
  return failover(network, async (endpoint) => operation(createEvmRpcProvider(network, endpoint)));
}

export async function withRpcHttp<T>(network: RpcNetwork, operation: (endpoint: string) => Promise<T>): Promise<T> {
  return failover(network, operation);
}

export function getPrimaryRpcUrl(network: RpcNetwork): string {
  const endpoint = getRpcUrls(network)[0];
  if (!endpoint) throw new RpcProviderError("RPC_UNAVAILABLE", network, `No RPC endpoint configured for ${network}`);
  return endpoint;
}

export function getConfirmationDepth(network: RpcNetwork): number {
  const key = `${network.toUpperCase()}_CONFIRMATIONS`;
  const configured = Number.parseInt(process.env[key] ?? "", 10);
  if (Number.isInteger(configured) && configured >= 1 && configured <= 100) return configured;
  return getDefaultConfirmationDepth(network);
}

export function getReceiptConfirmations(latestBlock: number, receiptBlock: number): number {
  return Math.max(0, latestBlock - receiptBlock + 1);
}
