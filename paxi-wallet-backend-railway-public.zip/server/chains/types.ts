export type ChainFamily = "evm" | "solana" | "bitcoin";

export interface ChainAdapter {
  readonly network: string;
  readonly family: ChainFamily;
  readonly nativeSymbol: string;
  readonly rpcUrl?: string;

  normalizeIdentifier(identifier: string): string;
  validateIdentifier(identifier: string): boolean;
  getNativeBalance(address: string): Promise<string>;
  getExplorerUrl(kind: "tx" | "address", value: string): string | null;
}

export type SupportedNetwork =
  | "ethereum"
  | "bsc"
  | "polygon"
  | "arbitrum"
  | "solana"
  | "bitcoin";

export class UnsupportedNetworkError extends Error {
  constructor(network: string) {
    super(`Unsupported network: ${network}`);
    this.name = "UnsupportedNetworkError";
  }
}

export class InvalidChainIdentifierError extends Error {
  constructor(network: string, identifier: string) {
    super(`Invalid ${network} identifier: ${identifier}`);
    this.name = "InvalidChainIdentifierError";
  }
}

export function requireValidIdentifier(adapter: ChainAdapter, identifier: string): string {
  const normalized = adapter.normalizeIdentifier(identifier.trim());
  if (!normalized || !adapter.validateIdentifier(normalized)) {
    throw new InvalidChainIdentifierError(adapter.network, identifier);
  }
  return normalized;
}

export function isSupportedNetwork(value: string): value is SupportedNetwork {
  return ["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"].includes(value);
}
