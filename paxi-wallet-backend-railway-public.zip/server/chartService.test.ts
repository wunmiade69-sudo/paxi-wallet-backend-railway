import { describe, expect, it } from "vitest";
import { getProviderCandleLimit, mergeChartCandles, type ChartCandle } from "./chartService";

function candle(timestamp: number, close: number, source: string, fallback: boolean): ChartCandle {
  return { timestamp, open: close, high: close, low: close, close, volume: null, source, fallback };
}

describe("chart candle merge", () => {
  it("keeps the provider margin above the requested limit until merge time", () => {
    expect(getProviderCandleLimit(365)).toBe(457);
    expect(getProviderCandleLimit(1)).toBe(2);
  });
  it("fills a short internal series from provider history and keeps internal duplicates", () => {
    const merged = mergeChartCandles(
      [candle(1_000, 1, "provider", true), candle(2_000, 2, "provider", true), candle(3_000, 3, "provider", true)],
      [candle(2_000, 20, "internal", false)],
      3,
    );
    expect(merged.map((row) => row.timestamp)).toEqual([1_000, 2_000, 3_000]);
    expect(merged.find((row) => row.timestamp === 2_000)?.close).toBe(20);
  });

  it("returns the newest requested candles after deduplication", () => {
    const merged = mergeChartCandles(
      [candle(1_000, 1, "provider", true), candle(2_000, 2, "provider", true)],
      [candle(3_000, 3, "internal", false), candle(4_000, 4, "internal", false)],
      2,
    );
    expect(merged.map((row) => row.timestamp)).toEqual([3_000, 4_000]);
  });
});


describe("chart timestamp sanitation", () => {
  it.each(["bitcoin", "solana", "bsc"])("normalizes %s candle timestamps to ordered milliseconds", async (chain) => {
    const { sanitizeChartCandles } = await import("./chartService");
    const rows = sanitizeChartCandles([
      { timestamp: 1_700_000_100, open: 2, high: 3, low: 1, close: 2.5, source: chain },
      { timestamp: 1_700_000_000_000, open: 1, high: 2, low: 0.5, close: 1.5, source: chain },
    ], 10);
    expect(rows).toHaveLength(2);
    expect(rows[0].timestamp).toBe(1_700_000_000_000);
    expect(rows[1].timestamp).toBe(1_700_000_100_000);
    expect(new Date(rows[0].timestamp).getUTCFullYear()).toBe(2023);
  });

  it("drops malformed cached timestamps instead of replacing them with now", async () => {
    const { sanitizeChartCandles } = await import("./chartService");
    const rows = sanitizeChartCandles([
      { timestamp: "not-a-date", open: 1, high: 1, low: 1, close: 1, source: "cache" },
      { timestamp: 1_700_000_000, open: 1, high: 1, low: 1, close: 1, source: "cache" },
    ], 10);
    expect(rows).toHaveLength(1);
    expect(rows[0].timestamp).toBe(1_700_000_000_000);
  });
});
