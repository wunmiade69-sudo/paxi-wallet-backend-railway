import { describe, expect, it } from "vitest";
import { getProviderCandleLimit, mergeChartCandles, type ChartCandle } from "./chartService";

function candle(timestamp: number, close: number, source: string, fallback: boolean): ChartCandle {
  return { timestamp, open: close, high: close, low: close, close, volume: null, source, fallback };
}

describe("chart candle merge", () => {
  it("keeps the provider margin above the requested limit until merge time", () => {
    expect(getProviderCandleLimit(365)).toBe(457);
    expect(getProviderCandleLimit(1)).toBe(2);
  });
  it("fills a short internal series from provider history and keeps internal duplicates", () => {
    const merged = mergeChartCandles(
      [candle(1_000, 1, "provider", true), candle(2_000, 2, "provider", true), candle(3_000, 3, "provider", true)],
      [candle(2_000, 20, "internal", false)],
      3,
    );
    expect(merged.map((row) => row.timestamp)).toEqual([1_000, 2_000, 3_000]);
    expect(merged.find((row) => row.timestamp === 2_000)?.close).toBe(20);
  });

  it("returns the newest requested candles after deduplication", () => {
    const merged = mergeChartCandles(
      [candle(1_000, 1, "provider", true), candle(2_000, 2, "provider", true)],
      [candle(3_000, 3, "internal", false), candle(4_000, 4, "internal", false)],
      2,
    );
    expect(merged.map((row) => row.timestamp)).toEqual([3_000, 4_000]);
  });
});
