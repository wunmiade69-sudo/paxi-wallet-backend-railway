import { and, desc, eq, sql } from "drizzle-orm";
import { candles } from "../drizzle/schema";
import { normalizeIdentifier } from "./assetRegistry";
import { timestampMs, type ProviderOhlcv } from "./providers/types";
import { getCachedChartData, setCachedChartData } from "./redis";
import { orchestratedChart } from "./providers";
import { normalizeMarketChain } from "./marketProviders";

export const CHART_TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"] as const;
export type ChartTimeframe = (typeof CHART_TIMEFRAMES)[number];

export interface ChartCandle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number | null;
  source: string;
  fallback: boolean;
}

export interface ChartResult {
  candles: ChartCandle[];
  source: string;
  fallback: boolean;
  requestedLimit: number;
  returned: number;
  generatedAt: number;
}

type ChartDb = NonNullable<Awaited<ReturnType<typeof import("./db").getReadDb>>>;

function finiteNumber(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeProviderCandle(row: ProviderOhlcv, fallback: boolean): ChartCandle | null {
  const open = finiteNumber(row.open);
  const high = finiteNumber(row.high);
  const low = finiteNumber(row.low);
  const close = finiteNumber(row.close);
  if (open === null || high === null || low === null || close === null) return null;

  return {
    timestamp: timestampMs(row.timestamp),
    open,
    high,
    low,
    close,
    volume: finiteNumber(row.volume),
    source: row.source,
    fallback,
  };
}

function normalizeInternalCandle(row: typeof candles.$inferSelect): ChartCandle | null {
  const open = finiteNumber(row.open);
  const high = finiteNumber(row.high);
  const low = finiteNumber(row.low);
  const close = finiteNumber(row.close);
  if (open === null || high === null || low === null || close === null) return null;

  return {
    timestamp: timestampMs(row.timestamp),
    open,
    high,
    low,
    close,
    volume: finiteNumber(row.volume),
    source: "internal",
    fallback: false,
  };
}

export function getProviderCandleLimit(limit: number): number {
  return Math.ceil(Math.max(1, limit) * 1.25);
}

function dedupeAndLimit(rows: ChartCandle[], limit: number): ChartCandle[] {
  const byTimestamp = new Map<number, ChartCandle>();
  for (const row of rows) {
    if (!Number.isFinite(row.timestamp) || row.timestamp <= 0) continue;
    byTimestamp.set(row.timestamp, row);
  }
  return [...byTimestamp.values()]
    .sort((left, right) => left.timestamp - right.timestamp)
    .slice(-limit);
}

export function mergeChartCandles(providerCandles: ChartCandle[], internalCandles: ChartCandle[], limit: number): ChartCandle[] {
  return dedupeAndLimit([...providerCandles, ...internalCandles], limit);
}

async function loadProviderCandles(
  chainId: string,
  tokenAddress: string,
  timeframe: ChartTimeframe,
  limit: number,
): Promise<{ candles: ChartCandle[]; source: string } | null> {
  const providerLimit = getProviderCandleLimit(limit);
  const normalizedChain = normalizeMarketChain(chainId);
  if (!normalizedChain) return null;
  const orchestratedTimeframe = timeframe === "1m" || timeframe === "5m" || timeframe === "15m" || timeframe === "30m" || timeframe === "1h" ? "1D" : timeframe === "4h" ? "1W" : "1M";
  const orchestrated = await orchestratedChart(
    { chain: normalizedChain, contractAddress: tokenAddress === "native" ? "native" : tokenAddress },
    orchestratedTimeframe,
    providerLimit,
  );
  if (!orchestrated.value?.points.length) return null;
  const candles = dedupeAndLimit(
    orchestrated.value.points
      .map((point): ChartCandle | null => {
        const close = finiteNumber(point.close);
        if (close === null) return null;
        return {
          timestamp: point.timestamp,
          open: finiteNumber(point.open) ?? close,
          high: finiteNumber(point.high) ?? close,
          low: finiteNumber(point.low) ?? close,
          close,
          volume: finiteNumber(point.volume),
          source: orchestrated.value?.source ?? "provider",
          fallback: true,
        };
      })
      .filter((row): row is ChartCandle => row !== null),
    limit,
  );
  return candles.length > 0 ? { candles, source: orchestrated.value.source } : null;
}

export async function getChartData(options: {
  db: ChartDb;
  assetId: number;
  chainId: string;
  tokenAddress: string;
  timeframe: ChartTimeframe;
  limit: number;
}): Promise<ChartResult> {
  const { db, assetId, chainId, tokenAddress, timeframe, limit } = options;
  const normalizedAddress = normalizeIdentifier(chainId, tokenAddress);
  const cacheKey = `${chainId.toLowerCase()}:${normalizedAddress}:${timeframe}:${limit}`;
  const cached = await getCachedChartData(cacheKey);
  if (cached) {
    return { ...cached, candles: cached.candles as ChartCandle[] };
  }

  const internalRows = await db
    .select()
    .from(candles)
    .where(and(eq(candles.assetId, assetId), eq(candles.timeframe, timeframe)))
    .orderBy(desc(candles.timestamp))
    .limit(limit);
  const internalCandles = dedupeAndLimit(
    internalRows.map(normalizeInternalCandle).filter((row): row is ChartCandle => row !== null),
    limit,
  );

  let result: ChartResult;
  if (internalCandles.length >= limit) {
    result = {
      candles: internalCandles,
      source: "internal",
      fallback: false,
      requestedLimit: limit,
      returned: internalCandles.length,
      generatedAt: Date.now(),
    };
  } else {
    const providerResult = await loadProviderCandles(chainId, normalizedAddress, timeframe, limit);
    const merged = providerResult
      ? mergeChartCandles(providerResult.candles, internalCandles, limit)
      : internalCandles;
    const sources = [...new Set(merged.map((row) => row.source))];
    result = {
      candles: merged,
      source: sources.length > 0 ? sources.join("+") : "none",
      fallback: merged.some((row) => row.fallback),
      requestedLimit: limit,
      returned: merged.length,
      generatedAt: Date.now(),
    };
  }

  await setCachedChartData(cacheKey, timeframe, result);
  return result;
}
