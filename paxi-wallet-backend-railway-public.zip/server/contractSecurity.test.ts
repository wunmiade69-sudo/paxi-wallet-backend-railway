import { describe, expect, it, vi } from "vitest";
import { getContractSecurity } from "./contractSecurity";

describe("contract security safety states", () => {
  it("returns unknown for unsupported chains instead of a safe result", async () => {
    const result = await getContractSecurity("solana", "MintAddress");

    expect(result.status).toBe("unknown");
    expect(result.riskLevel).toBe("UNKNOWN");
    expect(result.score).toBeNull();
  });

  it("returns unknown for malformed EVM identifiers without calling the provider", async () => {
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    const result = await getContractSecurity("ethereum", "not-an-address");

    expect(result.status).toBe("unknown");
    expect(result.score).toBeNull();
    expect(fetchSpy).not.toHaveBeenCalled();
    fetchSpy.mockRestore();
  });

  it("normalizes a valid GoPlus response through the shared provider path", async () => {
    const address = "0x1111111111111111111111111111111111111111";
    const fetchSpy = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({
      result: {
        [address]: {
          is_open_source: "1",
          is_honeypot: "0",
          owner_address: "0x0000000000000000000000000000000000000000",
          lp_holders: [{ percent: "100", is_locked: 1 }],
          buy_tax: "0",
          sell_tax: "0",
          is_mintable: "0",
          can_take_back_ownership: "0",
          owner_change_balance: "0",
          transfer_pausable: "0",
          holder_count: "12",
        },
      },
    }), { status: 200, headers: { "content-type": "application/json" } }));

    const result = await getContractSecurity("ethereum", address);

    expect(result).toMatchObject({ status: "safe", riskLevel: "LOW", score: 100, holderCount: 12 });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    fetchSpy.mockRestore();
  });

  it("degrades rate-limited and malformed GoPlus responses to unknown", async () => {
    const address = "0x2222222222222222222222222222222222222222";
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    fetchSpy.mockResolvedValueOnce(new Response("rate limited", { status: 429 }));
    await expect(getContractSecurity("ethereum", address)).resolves.toMatchObject({ status: "unknown", score: null });
    fetchSpy.mockResolvedValueOnce(new Response("not json", { status: 200 }));
    await expect(getContractSecurity("ethereum", address)).resolves.toMatchObject({ status: "unknown", score: null });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    fetchSpy.mockRestore();
  });
});
