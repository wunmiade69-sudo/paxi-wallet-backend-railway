/**
 * Real contract/token security data via GoPlus Security's free Token
 * Security API (api.gopluslabs.io) - the standard, widely-used source for
 * exactly this (honeypot detection, ownership, liquidity lock, tax rates).
 * No API key needed for this tier.
 *
 * IMPORTANT: the score/risk level below is a transparent heuristic built
 * from GoPlus's real flags - never a fabricated or hardcoded number. If
 * GoPlus has no data for a token (e.g. brand new, or an unsupported
 * chain), this returns "unknown" rather than guessing a good score - an
 * absence of red flags is not the same as a confirmed-safe token.
 */

// GoPlus's chain_id happens to match EIP-155 chain IDs for these two.
import { fetchJson } from "./providers/http";

const GOPLUS_CHAIN_ID: Record<string, string> = {
  ethereum: "1",
  bsc: "56",
};

export type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "UNKNOWN";
export type SecurityStatus = "safe" | "unknown" | "high-risk";

export interface ContractSecurityReport {
  status: SecurityStatus;
  riskLevel: RiskLevel;
  score: number | null; // 0-100, null if GoPlus has no data at all
  checks: {
    verifiedContract: boolean | null;
    liquidityLocked: boolean | null;
    noHoneypot: boolean | null;
    ownershipRenounced: boolean | null;
    lowRugRisk: boolean | null;
  };
  buyTaxPercent: number | null;
  sellTaxPercent: number | null;
  holderCount: number | null;
}

export const UNSUPPORTED_REPORT: ContractSecurityReport = {
  status: "unknown",
  riskLevel: "UNKNOWN",
  score: null,
  checks: {
    verifiedContract: null,
    liquidityLocked: null,
    noHoneypot: null,
    ownershipRenounced: null,
    lowRugRisk: null,
  },
  buyTaxPercent: null,
  sellTaxPercent: null,
  holderCount: null,
};

export async function getContractSecurity(network: string, contractAddress: string): Promise<ContractSecurityReport> {
  const chainId = GOPLUS_CHAIN_ID[network];
  if (!chainId) return UNSUPPORTED_REPORT;

  try {
    const normalizedAddress = contractAddress.trim().toLowerCase();
    if (!/^0x[0-9a-f]{40}$/.test(normalizedAddress)) return UNSUPPORTED_REPORT;
    const url = new URL(`https://api.gopluslabs.io/api/v1/token_security/${chainId}`);
    url.searchParams.set("contract_addresses", normalizedAddress);
    const data = await fetchJson<{ result?: Record<string, Record<string, unknown>> }>(url.toString(), "goplus");
    const token = data.result?.[normalizedAddress];
    if (!token) return UNSUPPORTED_REPORT;

    const isTrue = (v: unknown) => v === "1";

    const verifiedContract = isTrue(token.is_open_source);
    const honeypot = isTrue(token.is_honeypot);
    const noHoneypot = !honeypot;

    // Renounced = no real owner left (burned/zero address).
    const ownerAddress = typeof token.owner_address === "string" ? token.owner_address.toLowerCase() : "";
    const burnAddresses = ["", "0x0000000000000000000000000000000000000000", "0x000000000000000000000000000000000000dead"];
    const ownershipRenounced = burnAddresses.includes(ownerAddress);

    // Liquidity locked if the majority of LP tokens are locked or burned.
    const lpHolders = Array.isArray(token.lp_holders) ? token.lp_holders as Array<Record<string, unknown>> : [];
    const totalLpPercent = lpHolders.reduce((sum, h) => sum + Number(h.percent ?? 0), 0);
    const lockedLpPercent = lpHolders
      .filter((h) => h.is_locked === 1 || h.tag === "locked" || h.tag === "burn")
      .reduce((sum, h) => sum + Number(h.percent ?? 0), 0);
    const liquidityLocked = totalLpPercent > 0 ? lockedLpPercent / totalLpPercent > 0.5 : null;

    const buyTaxPercent = token.buy_tax != null ? Number(token.buy_tax) * 100 : null;
    const sellTaxPercent = token.sell_tax != null ? Number(token.sell_tax) * 100 : null;
    const highTax = (buyTaxPercent ?? 0) > 10 || (sellTaxPercent ?? 0) > 10;

    const mintable = isTrue(token.is_mintable);
    const canTakeBackOwnership = isTrue(token.can_take_back_ownership);
    const ownerCanChangeBalance = isTrue(token.owner_change_balance);
    const transferPausable = isTrue(token.transfer_pausable);

    const lowRugRisk = !mintable && !canTakeBackOwnership && !ownerCanChangeBalance && !transferPausable && !highTax;

    // Transparent point-based score - every deduction here is a real,
    // specific flag from GoPlus, documented so it's auditable and adjustable.
    let score = 100;
    if (honeypot) score -= 50;
    if (!verifiedContract) score -= 15;
    if (!ownershipRenounced) score -= 10;
    if (liquidityLocked === false) score -= 15;
    if (liquidityLocked === null) score -= 5; // no LP data at all is itself a caution flag
    if (highTax) score -= 10;
    if (mintable) score -= 5;
    if (canTakeBackOwnership) score -= 5;
    if (ownerCanChangeBalance) score -= 8;
    if (transferPausable) score -= 5;
    score = Math.max(0, Math.min(100, score));

    const riskLevel: RiskLevel = honeypot || score < 40 ? "HIGH" : score < 75 ? "MEDIUM" : "LOW";
    const status: SecurityStatus = honeypot || score < 40 ? "high-risk" : score < 75 || !verifiedContract ? "unknown" : "safe";

    return {
      status,
      riskLevel,
      score,
      checks: { verifiedContract, liquidityLocked, noHoneypot, ownershipRenounced, lowRugRisk },
      buyTaxPercent,
      sellTaxPercent,
      holderCount: token.holder_count != null ? Number(token.holder_count) : null,
    };
  } catch {
    return UNSUPPORTED_REPORT;
  }
}
