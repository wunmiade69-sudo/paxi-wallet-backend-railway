import { beforeEach, describe, expect, it, vi } from "vitest";

describe("server fiat-rate adapter", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.restoreAllMocks();
  });

  it("normalizes valid rates and always includes the USD baseline", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ rates: { EUR: 0.92, GBP: 0.79, JPY: 145, INR: 0 } }),
    });
    vi.stubGlobal("fetch", fetchMock);
    const currency = await import("./currency");

    await expect(currency.getUsdFiatRates()).resolves.toEqual({ USD: 1, EUR: 0.92, GBP: 0.79, JPY: 145 });
    expect(fetchMock.mock.calls[0]?.[0]).toContain("from=USD");
  });

  it("returns null when no non-USD rate is valid", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ rates: { EUR: -1, GBP: Number.NaN, JPY: "145" } }),
    }));
    const currency = await import("./currency");

    await expect(currency.getUsdFiatRates()).resolves.toBeNull();
  });

  it("returns null for provider errors and malformed JSON responses", async () => {
    for (const response of [
      { ok: false, status: 500 },
      { ok: true, json: async () => ({ malformed: true }) },
    ]) {
      vi.resetModules();
      vi.stubGlobal("fetch", vi.fn().mockResolvedValue(response));
      const currency = await import("./currency");
      await expect(currency.getUsdFiatRates()).resolves.toBeNull();
    }
  });
});

