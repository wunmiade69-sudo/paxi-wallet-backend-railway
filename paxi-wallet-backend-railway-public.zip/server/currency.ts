import { fetchJson } from "./providers/http";

export const SUPPORTED_FIAT_CURRENCIES = ["USD", "EUR", "GBP", "JPY", "INR"] as const;
export type SupportedFiatCurrency = (typeof SUPPORTED_FIAT_CURRENCIES)[number];

interface FrankfurterResponse {
  rates?: Record<string, number>;
}

/**
 * Fetches USD fiat rates from the public Frankfurter service through the
 * shared server resilience boundary. The browser receives only normalized
 * rates; provider errors are represented as null and never as guessed values.
 */
export async function getUsdFiatRates(): Promise<Partial<Record<SupportedFiatCurrency, number>> | null> {
  try {
    const body = await fetchJson<FrankfurterResponse>(
      "https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,INR",
      "frankfurter",
    );
    const rates: Partial<Record<SupportedFiatCurrency, number>> = { USD: 1 };
    for (const currency of SUPPORTED_FIAT_CURRENCIES) {
      if (currency === "USD") continue;
      const value = body?.rates?.[currency];
      if (typeof value === "number" && Number.isFinite(value) && value > 0) {
        rates[currency] = value;
      }
    }
    return Object.keys(rates).length > 1 ? rates : null;
  } catch {
    return null;
  }
}
