import { describe, expect, it } from "vitest";
import { shouldUseDatabaseTls } from "./db";

describe("database transport security", () => {
  it("requires verified TLS for TiDB Cloud endpoints", () => {
    expect(shouldUseDatabaseTls("mysql://user:pass@gateway01.eu-central-1.prod.aws.tidbcloud.com:4000/app")).toBe(true);
  });

  it("does not change Railway MySQL transport unless TLS is explicitly configured", () => {
    expect(shouldUseDatabaseTls("mysql://user:pass@altaria.proxy.rlwy.net:16523/railway")).toBe(false);
  });
});
