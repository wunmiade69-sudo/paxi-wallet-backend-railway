import { createPool } from "mysql2/promise";
import { drizzle } from "drizzle-orm/mysql2";
import { eq } from "drizzle-orm";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

type Db = ReturnType<typeof drizzle>;
let _db: Db | null = null;
let _readDb: Db | null = null;
let _writePool: ReturnType<typeof createPool> | null = null;
let _readPool: ReturnType<typeof createPool> | null = null;

export function shouldUseDatabaseTls(url: string): boolean {
  if (process.env.DATABASE_SSL === "true") return true;

  try {
    const hostname = new URL(url).hostname.toLowerCase();
    // TiDB Cloud Serverless rejects plaintext MySQL connections. Its public
    // endpoints use publicly trusted certificates, so standard verification
    // provides encrypted transport without requiring a bundled CA file.
    return hostname === "tidbcloud.com" || hostname.endsWith(".tidbcloud.com");
  } catch {
    return false;
  }
}

function createDb(url: string, role: "write" | "read"): Db | null {
  if (!url) return null;
  try {
    const parsed = new URL(url);
    const poolSize = Math.max(2, Math.min(Number(process.env.DB_POOL_SIZE ?? 20) || 20, 100));
    const pool = createPool({
      host: parsed.hostname,
      port: Number(parsed.port) || 3306,
      user: decodeURIComponent(parsed.username),
      password: decodeURIComponent(parsed.password),
      database: decodeURIComponent(parsed.pathname.replace(/^\//, "")),
      waitForConnections: true,
      connectionLimit: poolSize,
      maxIdle: Math.min(poolSize, 10),
      idleTimeout: 60_000,
      queueLimit: poolSize * 4,
      connectTimeout: 5_000,
      enableKeepAlive: true,
      keepAliveInitialDelay: 0,
      ssl: shouldUseDatabaseTls(url) ? { rejectUnauthorized: true } : undefined,
    });
    if (role === "write") _writePool = pool;
    else _readPool = pool;
    // mysql2 exposes duplicated Pool declarations through its promise and callback type paths;
    // the runtime client is compatible, so keep the cast at this integration boundary only.
    return drizzle({ client: pool }) as unknown as Db;
  } catch (error) {
    console.warn(`[Database:${role}] Failed to initialize database pool:`, error instanceof Error ? error.message : "unknown error");
    return null;
  }
}

/** Primary/write connection. Lazily created so local tooling works without a DB. */
export async function getDb(): Promise<Db | null> {
  if (!_db) _db = createDb(ENV.databaseUrl, "write");
  return _db;
}

/** Read connection. Uses DATABASE_READ_URL/DATABASE_REPLICA_URL when configured, otherwise primary. */
export async function getReadDb(): Promise<Db | null> {
  if (ENV.databaseReadUrl) {
    if (!_readDb) _readDb = createDb(ENV.databaseReadUrl, "read");
    if (_readDb) return _readDb;
  }
  return getDb();
}

export async function closeDbPools(): Promise<void> {
  const pools = [_writePool, _readPool].filter((pool, index, all) => pool && all.indexOf(pool) === index) as Array<ReturnType<typeof createPool>>;
  await Promise.allSettled(pools.map((pool) => pool.end()));
  _writePool = null;
  _readPool = null;
  _db = null;
  _readDb = null;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = values[field];
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
    values.adminRole = "super_admin";
    updateSet.adminRole = "super_admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getReadDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}
