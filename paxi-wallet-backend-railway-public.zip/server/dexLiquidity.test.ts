import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  getTokenMarketSnapshot,
  resolveTokenPriceUsd,
  type DexScreenerPairRaw,
} from './dexLiquidity';

const pair: DexScreenerPairRaw = {
  chainId: 'ethereum',
  dexId: 'uniswap',
  pairAddress: '0x00000000000000000000000000000000000000aa',
  priceUsd: '2',
  priceNative: '2',
  liquidity: { usd: 2500 },
  baseToken: {
    address: '0x0000000000000000000000000000000000000001',
    name: 'Base',
    symbol: 'BASE',
  },
  quoteToken: {
    address: '0x0000000000000000000000000000000000000002',
    name: 'Quote',
    symbol: 'QUOTE',
  },
};

describe('canonical DEX liquidity boundary', () => {
  afterEach(() => vi.unstubAllGlobals());

  it('returns null when the provider has no matching pair instead of a fake zero snapshot', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ pairs: [] }), { status: 200 }),
    ));

    await expect(getTokenMarketSnapshot('ethereum', pair.baseToken.address)).resolves.toBeNull();
  });

  it('resolves the looked-up quote token from real pair fields', () => {
    expect(resolveTokenPriceUsd('ethereum', pair, pair.baseToken.address)).toBe(2);
    expect(resolveTokenPriceUsd('ethereum', pair, pair.quoteToken.address)).toBe(1);
    expect(resolveTokenPriceUsd('ethereum', pair, '0x0000000000000000000000000000000000000003')).toBeNull();
  });
});

export {};

