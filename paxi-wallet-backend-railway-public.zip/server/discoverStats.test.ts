import { beforeEach, describe, expect, it, vi } from "vitest";

const fetchJson = vi.fn();
vi.mock("./providers/http", () => ({ fetchJson }));

describe("getDiscoverProtocolStats", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.resetModules();
  });

  it("maps only the curated dApps that have a real DefiLlama TVL slug, using the real tvl/change fields", async () => {
    fetchJson.mockResolvedValue([
      { slug: "uniswap", name: "Uniswap", tvl: 4_200_000_000, change_1d: 0.5, change_7d: 6.1 },
      { slug: "pancakeswap", name: "PancakeSwap", tvl: 1_100_000_000, change_1d: -0.2, change_7d: -3.4 },
      { slug: "curve-dex", name: "Curve DEX", tvl: 2_098_000_000, change_1d: 0.1, change_7d: 1.9 },
      { slug: "aave", name: "AAVE", tvl: 15_000_000_000, change_1d: 0.3, change_7d: 4.4 },
      { slug: "some-other-protocol", name: "Unrelated", tvl: 999, change_1d: 0, change_7d: 0 },
    ]);
    const { getDiscoverProtocolStats } = await import("./discoverStats");
    const stats = await getDiscoverProtocolStats();

    expect(Object.keys(stats).sort()).toEqual(["aave", "curve", "pancakeswap", "uniswap"]);
    expect(stats.uniswap).toEqual({ tvlUsd: 4_200_000_000, change1dPct: 0.5, change7dPct: 6.1 });
    // 1inch, jumper, opensea, blur are intentionally never present — no misleading fabricated TVL for them.
    expect(stats["1inch"]).toBeUndefined();
    expect(stats.jumper).toBeUndefined();
  });

  it("omits a protocol entirely rather than reporting a fabricated TVL when its slug is missing or its tvl field is invalid", async () => {
    fetchJson.mockResolvedValue([
      { slug: "uniswap", name: "Uniswap", tvl: "not-a-number", change_1d: 0.5, change_7d: 6.1 },
      // pancakeswap, curve-dex, aave slugs absent entirely from this payload
    ]);
    const { getDiscoverProtocolStats } = await import("./discoverStats");
    const stats = await getDiscoverProtocolStats();
    expect(stats).toEqual({});
  });

  it("serves the last-known cache instead of failing when a later refresh throws", async () => {
    fetchJson.mockResolvedValueOnce([{ slug: "uniswap", name: "Uniswap", tvl: 4_000_000_000, change_1d: 0, change_7d: 0 }]);
    const { getDiscoverProtocolStats } = await import("./discoverStats");
    const first = await getDiscoverProtocolStats();
    expect(first.uniswap.tvlUsd).toBe(4_000_000_000);

    // Force the module to treat the cache as expired, then fail the refetch.
    vi.useFakeTimers();
    vi.advanceTimersByTime(16 * 60_000);
    fetchJson.mockRejectedValueOnce(new Error("upstream down"));
    const second = await getDiscoverProtocolStats();
    expect(second.uniswap.tvlUsd).toBe(4_000_000_000);
    vi.useRealTimers();
  });

  it("returns an empty object, not a throw, when DefiLlama has never been reachable", async () => {
    fetchJson.mockRejectedValue(new Error("network error"));
    const { getDiscoverProtocolStats } = await import("./discoverStats");
    await expect(getDiscoverProtocolStats()).resolves.toEqual({});
  });
});
