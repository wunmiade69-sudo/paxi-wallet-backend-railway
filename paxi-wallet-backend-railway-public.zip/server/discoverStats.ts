/**
 * Real, live protocol stats for the Discover tab's featured dApps — sourced
 * from DefiLlama's free public API (https://api.llama.fi/protocols, no key
 * required). This intentionally does NOT cover every curated dApp: 1inch
 * (an aggregator) and Jumper (a bridge router) don't have a "TVL locked in
 * this protocol's own contracts" figure the way a DEX or lending market
 * does, and OpenSea/Blur are NFT marketplaces DefiLlama doesn't track by
 * TVL at all. Rather than inventing a number for those, they're simply
 * left out of the map below and the client omits the stat entirely.
 */
import { fetchJson } from "./providers/http";

export interface ProtocolStat {
  tvlUsd: number;
  change1dPct: number | null;
  change7dPct: number | null;
}

interface DefiLlamaProtocol {
  slug?: string;
  name?: string;
  tvl?: number;
  change_1d?: number | null;
  change_7d?: number | null;
}

/** curated dApp id -> the DefiLlama protocol slug that represents it. */
const DAPP_TO_DEFILLAMA_SLUG: Record<string, string> = {
  uniswap: "uniswap",
  pancakeswap: "pancakeswap",
  curve: "curve-dex",
  aave: "aave",
};

const DEFILLAMA_PROTOCOLS_URL = "https://api.llama.fi/protocols";
const CACHE_TTL_MS = 15 * 60_000; // TVL moves slowly; no need to refetch on every request

let cache: { data: Record<string, ProtocolStat>; expiresAt: number } | null = null;
let inFlight: Promise<Record<string, ProtocolStat>> | null = null;

async function fetchAndMap(): Promise<Record<string, ProtocolStat>> {
  const protocols = await fetchJson<DefiLlamaProtocol[]>(DEFILLAMA_PROTOCOLS_URL, "defillama");
  if (!Array.isArray(protocols)) throw new Error("Unexpected DefiLlama /protocols response shape");

  const bySlug = new Map<string, DefiLlamaProtocol>();
  for (const p of protocols) {
    if (p && typeof p.slug === "string") bySlug.set(p.slug, p);
  }

  const result: Record<string, ProtocolStat> = {};
  for (const [dappId, slug] of Object.entries(DAPP_TO_DEFILLAMA_SLUG)) {
    const p = bySlug.get(slug);
    if (!p || typeof p.tvl !== "number" || !Number.isFinite(p.tvl)) continue;
    result[dappId] = {
      tvlUsd: p.tvl,
      change1dPct: typeof p.change_1d === "number" && Number.isFinite(p.change_1d) ? p.change_1d : null,
      change7dPct: typeof p.change_7d === "number" && Number.isFinite(p.change_7d) ? p.change_7d : null,
    };
  }
  return result;
}

/**
 * Returns { dappId: ProtocolStat } for whichever curated dApps have real,
 * currently-available TVL data. Serves a 15-minute in-memory cache; on a
 * fetch failure, serves the last-known cache (even if stale) rather than
 * failing the whole Discover screen, and falls back to an empty object only
 * when nothing has ever been fetched successfully — the client already
 * treats a missing entry as "no stat to show," so this never fabricates data.
 */
export async function getDiscoverProtocolStats(): Promise<Record<string, ProtocolStat>> {
  if (cache && cache.expiresAt > Date.now()) return cache.data;

  if (!inFlight) {
    inFlight = fetchAndMap()
      .then((data) => {
        cache = { data, expiresAt: Date.now() + CACHE_TTL_MS };
        return data;
      })
      .catch((err) => {
        console.warn("[discoverStats] DefiLlama fetch failed, serving cache if any:", err);
        return cache?.data ?? {};
      })
      .finally(() => {
        inFlight = null;
      });
  }
  return inFlight;
}
