import { describe, expect, it } from "vitest";
import { evaluateActivityRequirement } from "./requirementService";

const metrics = {
  activeDays: 3,
  totalEvents: 4,
  eventCounts: { wallet_creation: 1, token_creation: 0, buy: 0, sell: 0, swap: 2, bridge: 0, send: 1, receive: 0, deposit: 0, withdrawal: 0 },
  totalVolumeUsd: "125.50",
  chains: ["bsc"],
};

describe("server-authoritative campaign requirement evaluation", () => {
  it("evaluates activity requirements from trusted aggregate metrics rather than client flags", () => {
    expect(evaluateActivityRequirement({ requirementType: "operation_used", requirementKey: "swap", threshold: "1", config: { eventType: "swap" } } as never, metrics)).toBe(true);
    expect(evaluateActivityRequirement({ requirementType: "active_days", requirementKey: "days", threshold: "5" } as never, metrics)).toBe(false);
    expect(evaluateActivityRequirement({ requirementType: "volume_usd", requirementKey: "volume", threshold: "100" } as never, metrics)).toBe(true);
    expect(evaluateActivityRequirement({ requirementType: "chain_used", requirementKey: "chain", threshold: "1", config: { chainId: "ethereum" } } as never, metrics)).toBe(false);
  });
});
