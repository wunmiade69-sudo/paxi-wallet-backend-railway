import { and, asc, eq, gt, inArray, sql } from "drizzle-orm";
import {
  campaignRequirements,
  campaignSnapshotParticipants,
  campaignSnapshots,
  campaignTierMultipliers,
  eligibilityResults,
  type CampaignRequirement,
  type CampaignSnapshot,
} from "../../drizzle/schema";
import { getDb } from "../db";
import type { ActivityStats } from "../activity/activityService";

const MULTIPLIER_PATTERN = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,18})?$/;
const DEFAULT_TIER_MULTIPLIERS = { minimum: "1", highest: "2" } as const;

const DEFAULT_REQUIREMENTS: ReadonlyArray<{
  requirementKey: string;
  label: string;
  requirementType: "active_days" | "event_count" | "volume_usd" | "operation_used";
  threshold: string;
  config?: Record<string, unknown>;
}> = [
  { requirementKey: "wallet_created", label: "Created a wallet", requirementType: "operation_used", threshold: "1", config: { eventType: "wallet_creation" } },
  { requirementKey: "send_used", label: "Completed a send", requirementType: "operation_used", threshold: "1", config: { eventType: "send" } },
  { requirementKey: "receive_used", label: "Received an asset", requirementType: "operation_used", threshold: "1", config: { eventType: "receive" } },
  { requirementKey: "swap_used", label: "Completed a swap", requirementType: "operation_used", threshold: "1", config: { eventType: "swap" } },
  { requirementKey: "bridge_used", label: "Completed a bridge", requirementType: "operation_used", threshold: "1", config: { eventType: "bridge" } },
  { requirementKey: "buy_used", label: "Completed a buy", requirementType: "operation_used", threshold: "1", config: { eventType: "buy" } },
  { requirementKey: "sell_used", label: "Completed a sell", requirementType: "operation_used", threshold: "1", config: { eventType: "sell" } },
  { requirementKey: "active_days_2", label: "Used PAXI Wallet on at least two days", requirementType: "active_days", threshold: "2" },
  { requirementKey: "active_days_5", label: "Used PAXI Wallet on at least five days", requirementType: "active_days", threshold: "5" },
  { requirementKey: "confirmed_events_5", label: "Completed at least five confirmed activities", requirementType: "event_count", threshold: "5" },
];

function assertId(value: number, field: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`Invalid ${field}`);
}

function assertMultiplier(value: string): void {
  if (!MULTIPLIER_PATTERN.test(value) || value === "0") throw new Error("Tier multiplier must be a positive decimal");
}

export async function ensureDefaultTierMultipliers(campaignId: number) {
  assertId(campaignId, "campaign id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(campaignTierMultipliers).where(eq(campaignTierMultipliers.campaignId, campaignId));
  const existingTiers = new Set(existing.map((row) => row.tier));
  for (const tier of ["minimum", "highest"] as const) {
    if (existingTiers.has(tier)) continue;
    await db.insert(campaignTierMultipliers).values({ campaignId, tier, multiplier: DEFAULT_TIER_MULTIPLIERS[tier] });
  }
  return db.select().from(campaignTierMultipliers).where(eq(campaignTierMultipliers.campaignId, campaignId));
}

export async function setTierMultiplier(campaignId: number, tier: "minimum" | "highest", multiplier: string) {
  assertId(campaignId, "campaign id");
  assertMultiplier(multiplier);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(campaignTierMultipliers).values({ campaignId, tier, multiplier }).onDuplicateKeyUpdate({ set: { multiplier } });
  const [row] = await db.select().from(campaignTierMultipliers).where(and(eq(campaignTierMultipliers.campaignId, campaignId), eq(campaignTierMultipliers.tier, tier))).limit(1);
  if (!row) throw new Error("Tier multiplier was not persisted");
  return row;
}

export async function listTierMultipliers(campaignId: number) {
  assertId(campaignId, "campaign id");
  return ensureDefaultTierMultipliers(campaignId);
}

function parseThreshold(value: string): number {
  if (!/^\d+(?:\.\d{1,18})?$/.test(value)) throw new Error("Invalid requirement threshold");
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) throw new Error("Invalid requirement threshold");
  return parsed;
}

function decimalAtLeast(value: string, threshold: string): boolean {
  try {
    const toMicros = (input: string) => {
      const [whole, fraction = ""] = input.split(".");
      return BigInt(whole) * 1_000_000n + BigInt(fraction.padEnd(6, "0").slice(0, 6) || "0");
    };
    return toMicros(value || "0") >= toMicros(threshold);
  } catch {
    return false;
  }
}

export async function ensureDefaultRequirements(campaignId: number): Promise<CampaignRequirement[]> {
  assertId(campaignId, "campaign id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(campaignRequirements).where(eq(campaignRequirements.campaignId, campaignId)).orderBy(asc(campaignRequirements.sortOrder));
  if (existing.length > 0) return existing;
  await db.insert(campaignRequirements).values(DEFAULT_REQUIREMENTS.map((requirement, index) => ({
    campaignId,
    ...requirement,
    points: 1,
    sortOrder: index,
    isActive: true,
  })));
  return db.select().from(campaignRequirements).where(eq(campaignRequirements.campaignId, campaignId)).orderBy(asc(campaignRequirements.sortOrder));
}

type RequirementMetrics = Pick<ActivityStats, "activeDays" | "eventCounts" | "totalEvents" | "totalVolumeUsd" | "chains"> & { externalScore?: number | null };

/** Evaluates an active requirement from server-generated activity metrics only. */
export function evaluateActivityRequirement(
  requirement: CampaignRequirement,
  participant: RequirementMetrics,
): boolean {
  const threshold = parseThreshold(requirement.threshold);
  switch (requirement.requirementType) {
    case "active_days":
      return participant.activeDays >= threshold;
    case "event_count": {
      const eventType = typeof requirement.config?.eventType === "string" ? requirement.config.eventType : null;
      const eventCounts = participant.eventCounts as Record<string, number>;
      return eventType ? Number(eventCounts[eventType] ?? 0) >= threshold : participant.totalEvents >= threshold;
    }
    case "volume_usd":
      return decimalAtLeast(participant.totalVolumeUsd, requirement.threshold);
    case "operation_used": {
      const eventType = typeof requirement.config?.eventType === "string" ? requirement.config.eventType : requirement.requirementKey;
      return Number((participant.eventCounts as Record<string, number>)[eventType] ?? 0) >= threshold;
    }
    case "chain_used": {
      const chain = typeof requirement.config?.chainId === "string" ? requirement.config.chainId : requirement.threshold;
      return participant.chains.includes(chain);
    }
    case "external_score":
      return (participant.externalScore ?? 0) >= threshold;
    default:
      return false;
  }
}

function tierFor(met: number, total: number, minimumThreshold: number, highestThreshold: number): "not_qualified" | "minimum" | "highest" {
  if (met >= highestThreshold && total >= highestThreshold) return "highest";
  if (met >= minimumThreshold && total >= minimumThreshold) return "minimum";
  return "not_qualified";
}

async function getSnapshot(db: Awaited<ReturnType<typeof getDb>>, snapshotId: number): Promise<CampaignSnapshot> {
  if (!db) throw new Error("Database not available");
  const [snapshot] = await db.select().from(campaignSnapshots).where(eq(campaignSnapshots.id, snapshotId)).limit(1);
  if (!snapshot) throw new Error("Campaign snapshot not found");
  return snapshot;
}

export async function evaluateSnapshotRequirements(snapshotId: number): Promise<CampaignSnapshot> {
  assertId(snapshotId, "snapshot id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const snapshot = await getSnapshot(db, snapshotId);
  if (!["frozen", "calculating", "complete"].includes(snapshot.status)) throw new Error("Snapshot must be frozen before requirements are evaluated");
  if (snapshot.status === "complete") return snapshot;

  const claim = await db.update(campaignSnapshots).set({ status: "calculating" }).where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "frozen")));
  if (Number((claim as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
    const current = await getSnapshot(db, snapshotId);
    if (current.status !== "calculating") throw new Error("Snapshot is no longer available for requirement evaluation");
  }

  const requirements = await ensureDefaultRequirements(snapshot.campaignId);
  const activeRequirements = requirements.filter((item) => item.isActive);
  if (activeRequirements.length !== 10) throw new Error("A campaign must have exactly ten active requirements before evaluation");
  const minimumThreshold = 5;
  const highestThreshold = 10;
  const tierMultipliers = await ensureDefaultTierMultipliers(snapshot.campaignId);
  const multiplierByTier = new Map(tierMultipliers.map((row) => [row.tier, row.multiplier]));
  let cursor = 0;
  let qualifiedCount = 0;

  try {
    while (true) {
      const participants = await db.select().from(campaignSnapshotParticipants)
        .where(and(eq(campaignSnapshotParticipants.snapshotId, snapshotId), gt(campaignSnapshotParticipants.id, cursor)))
        .orderBy(asc(campaignSnapshotParticipants.id))
        .limit(500);
      if (participants.length === 0) break;
      for (const participant of participants) {
        const metrics: RequirementMetrics = {
          activeDays: participant.activeDays,
          eventCounts: participant.eventCounts as ActivityStats["eventCounts"],
          totalEvents: participant.totalConfirmedEvents,
          totalVolumeUsd: participant.totalVolumeUsd,
          chains: participant.chains,
          externalScore: participant.externalScore,
        };
        const results = Object.fromEntries(activeRequirements.map((requirement) => [requirement.requirementKey, evaluateActivityRequirement(requirement, metrics)]));
        const metRequirements = Object.values(results).filter(Boolean).length;
        const tier = tierFor(metRequirements, activeRequirements.length, minimumThreshold, highestThreshold);
        const payoutMultiplier = tier === "not_qualified" ? "0" : multiplierByTier.get(tier) ?? DEFAULT_TIER_MULTIPLIERS[tier];
        assertMultiplier(payoutMultiplier === "0" ? "1" : payoutMultiplier);
        if (tier !== "not_qualified") qualifiedCount += 1;
        await db.insert(eligibilityResults).values({
          snapshotId,
          userOpenId: participant.userOpenId,
          totalRequirements: activeRequirements.length,
          metRequirements,
          minimumThreshold,
          highestThreshold,
          payoutMultiplier,
          requirementResults: results,
          externalScore: participant.externalScore,
          tier,
          status: "calculated",
          calculatedAt: new Date(),
        }).onDuplicateKeyUpdate({ set: {
          totalRequirements: activeRequirements.length,
          metRequirements,
          minimumThreshold,
          highestThreshold,
          payoutMultiplier,
          requirementResults: results,
          externalScore: participant.externalScore,
          tier,
          status: "calculated",
          calculatedAt: new Date(),
        }});
        await db.update(campaignSnapshotParticipants).set({ requirements: results, eligibilityTier: tier }).where(and(eq(campaignSnapshotParticipants.id, participant.id), eq(campaignSnapshotParticipants.snapshotId, snapshotId)));
        cursor = Number(participant.id);
      }
      if (participants.length < 500) break;
    }
    await db.update(campaignSnapshots).set({ status: "complete", qualifiedCount, calculatedAt: new Date() }).where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "calculating")));
    return getSnapshot(db, snapshotId);
  } catch (error) {
    await db.update(campaignSnapshots).set({ status: "frozen" }).where(and(eq(campaignSnapshots.id, snapshotId), eq(campaignSnapshots.status, "calculating")));
    throw error;
  }
}

export async function listEligibilityResults(snapshotId: number, tier?: "not_qualified" | "minimum" | "highest") {
  assertId(snapshotId, "snapshot id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const conditions = [eq(eligibilityResults.snapshotId, snapshotId)];
  if (tier) conditions.push(eq(eligibilityResults.tier, tier));
  return db.select().from(eligibilityResults).where(and(...conditions)).orderBy(asc(eligibilityResults.id)).limit(10_000);
}
