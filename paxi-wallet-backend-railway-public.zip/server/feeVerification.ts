import { ethers } from "ethers";
import { ENV } from "./_core/env";
import { getConfirmationDepth, getReceiptConfirmations, withEvmRpc, type RpcNetwork } from "./chains/rpc";
import { CANONICAL_CHAINS } from "../shared/canonicalRegistry";
import { getSendFeeAssetPolicy } from "../shared/sendFeeAssetPolicy";

/**
 * Public RPC per EVM network we accept fees/tasks on, plus that network's
 * USDT/USDC contract addresses (fees must be paid in one of these - see note
 * below about why native-currency fees aren't supported yet).
 * Mirrors the `id`s in client/src/lib/wallet/chains.ts - keep in sync if you
 * add a network there.
 */
const FEE_NETWORKS: Record<string, { rpcUrl: string; stablecoins: Record<string, { address: string; decimals: number }> }> = {
  ethereum: { rpcUrl: "https://ethereum-rpc.publicnode.com", stablecoins: { USDT: CANONICAL_CHAINS.ethereum.stablecoins.USDT!, USDC: CANONICAL_CHAINS.ethereum.stablecoins.USDC! } },
  bsc: { rpcUrl: "https://bsc-rpc.publicnode.com", stablecoins: { USDT: CANONICAL_CHAINS.bsc.stablecoins.USDT!, USDC: CANONICAL_CHAINS.bsc.stablecoins.USDC! } },
};

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const ERC20_DECIMALS_ABI = ["function decimals() view returns (uint8)"];
const TOKEN_FACTORY_ADDRESSES: Record<string, string> = {
  bsc: process.env.PAXI_BSC_FACTORY_ADDRESS ?? "0xc913e259eeef3d4623900b05e8a8ab6a496b9ef2",
};
const USD_PATTERN = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/;
const TOKEN_CREATED_TOPIC = ethers.id("TokenCreated(address,address,string,string,uint256,uint256)");
const TOKEN_CREATED_INTERFACE = new ethers.Interface([
  "event TokenCreated(address indexed tokenAddress,address indexed creator,string name,string symbol,uint256 supply,uint256 feePaid)",
]);

export type FeeVerificationResult = { ok: true; networkFeeNative?: string; feeCurrency?: string } | { ok: false; reason: string };

function getProvider(network: string): { cfg: (typeof FEE_NETWORKS)[string]; rpcNetwork: Exclude<RpcNetwork, "solana" | "bitcoin"> } | null {
  const cfg = FEE_NETWORKS[network];
  if (!cfg || (network !== "ethereum" && network !== "bsc")) return null;
  return { cfg, rpcNetwork: network };
}

function addressFromTopic(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`).toLowerCase();
  } catch {
    return null;
  }
}

function isTransactionHash(value: string): boolean {
  return ethers.isHexString(value, 32);
}

function transferAmount(data: string): bigint | null {
  try {
    return BigInt(data);
  } catch {
    return null;
  }
}

function usdToUnits(minUsd: string, decimals: number): bigint {
  if (!USD_PATTERN.test(minUsd)) throw new Error("Invalid USD amount");
  const [whole, fraction = ""] = minUsd.split(".");
  if (fraction.length > decimals) throw new Error("USD amount has too many fractional digits");
  const scale = 10n ** BigInt(decimals);
  const fractionalUnits = BigInt(fraction.padEnd(decimals, "0") || "0");
  return BigInt(whole) * scale + fractionalUnits;
}

async function getReceipt(network: Exclude<RpcNetwork, "solana" | "bitcoin">, txHash: string): Promise<ethers.TransactionReceipt | null> {
  return withEvmRpc(network, (provider) => provider.getTransactionReceipt(txHash));
}

/**
 * Confirms `txHash` is a real, already-mined USDT or USDC transfer of at
 * least `minUsd` to the Paxi treasury address, on the given network.
 * Used for listing fees, creation fees, and campaign pool funding.
 * Never trust a client-supplied tx hash for anything financial without this.
 */
export async function verifyFeePayment(network: string, txHash: string, minUsd: string): Promise<FeeVerificationResult> {
  const net = getProvider(network);
  if (!net) return { ok: false, reason: `Fee payments aren't supported on "${network}" yet.` };
  if (!isTransactionHash(txHash)) return { ok: false, reason: "Invalid transaction hash." };
  const [wholeUsd] = minUsd.split(".");
  if (!USD_PATTERN.test(minUsd) || BigInt(wholeUsd || "0") <= 0n || BigInt(wholeUsd || "0") > 100_000_000n) {
    return { ok: false, reason: "Invalid fee amount." };
  }
  if (!ENV.paxiTreasuryAddress || !ethers.isAddress(ENV.paxiTreasuryAddress)) return { ok: false, reason: "Treasury address not configured on the server." };

  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await getReceipt(net.rpcNetwork, txHash);
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify that transaction." };
  }
  if (!receipt) return { ok: false, reason: "Transaction not found (or not confirmed yet)." };
  if (receipt.status !== 1) return { ok: false, reason: "That transaction failed on-chain." };
  try {
    const confirmations = await withEvmRpc(net.rpcNetwork, async (provider) => {
      const latestBlock = await provider.getBlockNumber();
      return getReceiptConfirmations(latestBlock, receipt!.blockNumber);
    });
    const required = getConfirmationDepth(net.rpcNetwork);
    if (confirmations < required) {
      return { ok: false, reason: `Fee transaction needs ${required} confirmations; currently has ${confirmations}.` };
    }
  } catch {
    return { ok: false, reason: "Couldn't determine transaction confirmation depth." };
  }

  const stablecoins = Object.values(net.cfg.stablecoins);
  const treasury = ENV.paxiTreasuryAddress.toLowerCase();

  for (const log of receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC) continue;
    const stablecoin = stablecoins.find((candidate) => candidate.address.toLowerCase() === log.address.toLowerCase());
    if (!stablecoin) continue;
    if (addressFromTopic(log.topics[2]) !== treasury) continue;
    const amount = transferAmount(log.data);
    if (amount != null && amount >= usdToUnits(minUsd, stablecoin.decimals)) return { ok: true };
  }

  return { ok: false, reason: `No USDT/USDC transfer of at least $${minUsd} to the Paxi address was found in that transaction.` };
}

/**
 * Confirms `txHash` is a real, mined, successful transaction sent BY
 * `walletAddress` that transferred at least `minHumanAmount` units of
 * `tokenContractAddress` (human units, e.g. "50", not raw base units -
 * decimals are looked up on-chain). Used for campaign task proof
 * ("trade at least X of this token").
 *
 * LIMITATION: this only proves *a* transfer of that size happened in a tx
 * the wallet signed - it can't fully distinguish "swapped through Paxi" from
 * "sent tokens to a friend". Good enough as an anti-fake-entry check for a
 * launch; if campaigns get valuable enough to attract abuse, tighten this to
 * also require the tx `to` address matches Paxi's known swap router/aggregator
 * contract for that network.
 */
/**
 * Verifies the deployment half of Create Token: a confirmed transaction from
 * the authenticated wallet to Paxi's configured factory that emitted a
 * TokenCreated event for the claimed token address.
 */
export async function verifyTokenDeployment(
  network: string,
  txHash: string,
  walletAddress: string,
  tokenAddress: string,
): Promise<FeeVerificationResult> {
  const net = getProvider(network);
  const factoryAddress = TOKEN_FACTORY_ADDRESSES[network];
  if (!net || !factoryAddress) return { ok: false, reason: `Token creation isn't supported on "${network}".` };
  if (!isTransactionHash(txHash) || !ethers.isAddress(walletAddress) || !ethers.isAddress(tokenAddress)) {
    return { ok: false, reason: "Invalid deployment transaction or wallet address." };
  }

  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await getReceipt(net.rpcNetwork, txHash);
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify the deployment transaction." };
  }
  if (!receipt) return { ok: false, reason: "Deployment transaction not found (or not confirmed yet)." };
  if (receipt.status !== 1) return { ok: false, reason: "The token deployment transaction failed on-chain." };
  if (!receipt.from || receipt.from.toLowerCase() !== walletAddress.toLowerCase()) {
    return { ok: false, reason: "The deployment transaction wasn't sent from the wallet on your account." };
  }
  if (!receipt.to || receipt.to.toLowerCase() !== factoryAddress.toLowerCase()) {
    return { ok: false, reason: "The deployment transaction did not call Paxi's configured token factory." };
  }

  const expectedToken = tokenAddress.toLowerCase();
  const expectedCreator = walletAddress.toLowerCase();
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() !== factoryAddress.toLowerCase() || log.topics[0] !== TOKEN_CREATED_TOPIC) continue;
    const emittedToken = addressFromTopic(log.topics[1]);
    const emittedCreator = addressFromTopic(log.topics[2]);
    if (emittedToken !== expectedToken || emittedCreator !== expectedCreator) continue;
    try {
      const parsed = TOKEN_CREATED_INTERFACE.parseLog({ topics: log.topics, data: log.data });
      const feePaid = parsed?.args[5] as bigint | undefined;
      if (feePaid !== 0n) return { ok: false, reason: "The factory still charges an on-chain fee; disable it before using the backend fee flow." };
    } catch {
      return { ok: false, reason: "The matching TokenCreated event could not be decoded." };
    }
    return { ok: true };
  }
  return { ok: false, reason: "The deployment transaction did not emit a matching TokenCreated event." };
}

export async function verifyTokenTransferProof(
  network: string,
  txHash: string,
  tokenContractAddress: string,
  walletAddress: string,
  minHumanAmount: string,
): Promise<FeeVerificationResult> {
  const net = getProvider(network);
  if (!net) return { ok: false, reason: `"${network}" isn't supported for task verification yet.` };
  if (!isTransactionHash(txHash) || !ethers.isAddress(tokenContractAddress) || !ethers.isAddress(walletAddress)) {
    return { ok: false, reason: "Invalid transaction, token, or wallet address." };
  }
  if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(minHumanAmount) || Number(minHumanAmount) <= 0) {
    return { ok: false, reason: "Invalid required token amount." };
  }

  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await getReceipt(net.rpcNetwork, txHash);
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify that transaction." };
  }
  if (!receipt) return { ok: false, reason: "Transaction not found (or not confirmed yet)." };
  if (receipt.status !== 1) return { ok: false, reason: "That transaction failed on-chain." };
  if (receipt.from.toLowerCase() !== walletAddress.toLowerCase()) {
    return { ok: false, reason: "That transaction wasn't sent from the wallet address on your account." };
  }

  let decimals = 18;
  try {
    decimals = Number(await withEvmRpc(net.rpcNetwork, (provider) => new ethers.Contract(tokenContractAddress, ERC20_DECIMALS_ABI, provider).decimals()));
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) throw new Error("invalid decimals");
  } catch {
    return { ok: false, reason: "Couldn't read the task token's contract - check the address." };
  }

  let minUnits: bigint;
  try {
    minUnits = ethers.parseUnits(minHumanAmount, decimals);
  } catch {
    return { ok: false, reason: "Invalid required token amount." };
  }
  const wallet = walletAddress.toLowerCase();
  const tokenAddr = tokenContractAddress.toLowerCase();

  for (const log of receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC) continue;
    if (log.address.toLowerCase() !== tokenAddr) continue;
    const from = addressFromTopic(log.topics[1]);
    const to = addressFromTopic(log.topics[2]);
    if (from == null || to == null || (from !== wallet && to !== wallet)) continue;
    const amount = transferAmount(log.data);
    if (amount != null && amount >= minUnits) return { ok: true };
  }

  return { ok: false, reason: `That transaction doesn't show a transfer of at least ${minHumanAmount} of this token.` };
}


export interface VerifyEvmAssetTransferParams {
  network: string;
  txHash: string;
  payerAddress: string;
  treasuryAddress: string;
  assetAddress: string | null;
  assetSymbol: string;
  amountUnits: string;
  assetDecimals: number;
}

/**
 * Verifies a same-asset PAXI fee transfer. This is deliberately separate from
 * verifyFeePayment: SEND fees are charged in the asset being sent, while
 * listing/creation fees remain stablecoin payments. The server accepts only
 * confirmed Ethereum/BSC receipts and proves the payer, treasury, contract,
 * amount, and on-chain decimals from receipt/provider data.
 */
export async function verifyEvmAssetTransfer(
  params: VerifyEvmAssetTransferParams,
): Promise<FeeVerificationResult> {
  const net = getProvider(params.network);
  if (!net) return { ok: false, reason: `EVM fee settlement isn't supported on "${params.network}" yet.` };
  if (!isTransactionHash(params.txHash)) return { ok: false, reason: "Invalid fee transaction hash." };
  if (!ethers.isAddress(params.payerAddress) || !ethers.isAddress(params.treasuryAddress)) {
    return { ok: false, reason: "Invalid fee payer or treasury address." };
  }
  if (!/^[0-9]+$/.test(params.amountUnits) || params.amountUnits === "0") {
    return { ok: false, reason: "Invalid fee amount." };
  }
  if (!Number.isInteger(params.assetDecimals) || params.assetDecimals < 0 || params.assetDecimals > 36) {
    return { ok: false, reason: "Invalid asset decimals." };
  }
  if (params.assetAddress != null && !ethers.isAddress(params.assetAddress)) {
    return { ok: false, reason: "Invalid fee asset contract." };
  }
  try {
    getSendFeeAssetPolicy(params.network, params.assetAddress, params.assetSymbol, params.assetDecimals);
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : "This asset is not eligible for PAXI SEND fee settlement." };
  }

  const payer = ethers.getAddress(params.payerAddress).toLowerCase();
  const treasury = ethers.getAddress(params.treasuryAddress).toLowerCase();
  const minimum = BigInt(params.amountUnits);

  try {
    return await withEvmRpc(net.rpcNetwork, async (provider) => {
      const receipt = await provider.getTransactionReceipt(params.txHash);
      if (!receipt) return { ok: false, reason: "Fee transaction not found or not confirmed." };
      if (receipt.status !== 1) return { ok: false, reason: "The fee transaction failed on-chain." };
      const transaction = await provider.getTransaction(params.txHash);
      if (!transaction || transaction.from?.toLowerCase() !== payer) {
        return { ok: false, reason: "The fee transaction was not sent by this wallet." };
      }

      if (params.assetAddress == null) {
        if (transaction.to?.toLowerCase() !== treasury || transaction.value < minimum) {
          return { ok: false, reason: "The confirmed native fee transfer did not reach the configured treasury for the required amount." };
        }
        const gasPrice = receipt.gasPrice ?? 0n;
        return { ok: true, networkFeeNative: ethers.formatUnits(receipt.gasUsed * gasPrice, 18) };
      }

      const assetAddress = ethers.getAddress(params.assetAddress).toLowerCase();
      try {
        const token = new ethers.Contract(assetAddress, ERC20_DECIMALS_ABI, provider);
        const onChainDecimals = Number(await token.decimals());
        if (!Number.isInteger(onChainDecimals) || onChainDecimals !== params.assetDecimals) {
          return { ok: false, reason: "The fee asset decimals do not match the configured asset." };
        }
      } catch {
        return { ok: false, reason: "The fee asset contract or decimals could not be validated on-chain." };
      }

      for (const log of receipt.logs) {
        if (log.address.toLowerCase() !== assetAddress || log.topics[0] !== TRANSFER_TOPIC) continue;
        const from = addressFromTopic(log.topics[1]);
        const to = addressFromTopic(log.topics[2]);
        const amount = transferAmount(log.data);
        if (from === payer && to === treasury && amount != null && amount >= minimum) {
          const gasPrice = receipt.gasPrice ?? 0n;
          return { ok: true, networkFeeNative: ethers.formatUnits(receipt.gasUsed * gasPrice, 18) };
        }
      }
      return { ok: false, reason: "No confirmed same-asset transfer of the required fee to the configured treasury was found." };
    });
  } catch {
    return { ok: false, reason: "Could not reach the network to verify the fee transaction." };
  }
}
