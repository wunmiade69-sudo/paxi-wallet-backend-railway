import { describe, expect, it } from "vitest";
import { buildNormalizedFeeBreakdown } from "./feeBreakdown";

describe("normalized fee breakdown", () => {
  it("keeps fee components separate and sums them with exact decimal arithmetic", () => {
    expect(buildNormalizedFeeBreakdown({
      feeCurrency: "usd",
      networkFee: "0.10",
      paxiServiceFee: "0.30",
      routeFee: "0.025001",
      bridgeFee: "0.004999",
      relayerFee: null,
      estimatedReceived: "99.57",
    })).toEqual({
      feeCurrency: "USD",
      networkFee: "0.1",
      paxiServiceFee: "0.3",
      routeFee: "0.025001",
      bridgeFee: "0.004999",
      totalFee: "0.43",
      estimatedReceived: "99.57",
    });
  });

  it("rejects negative, over-precise, and malformed components", () => {
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "USD", paxiServiceFee: "-0.1" })).toThrow();
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "USD", paxiServiceFee: "0.1234567" })).toThrow();
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "USD", paxiServiceFee: "not-a-number" })).toThrow();
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "", paxiServiceFee: "0" })).toThrow();
  });

  it("does not mislabel USD engine amounts as a chain-native currency", () => {
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "SOL", paxiServiceFee: "0.3" })).toThrow(/must be USD/);
    expect(() => buildNormalizedFeeBreakdown({ feeCurrency: "BTC", paxiServiceFee: "0.0001" })).toThrow(/must be USD/);
  });
});
