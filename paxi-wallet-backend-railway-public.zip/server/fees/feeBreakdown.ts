const DECIMAL_SCALE = 1_000_000n;
const NON_NEGATIVE_DECIMAL = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/;
const CURRENCY_PATTERN = /^[A-Za-z][A-Za-z0-9._-]{1,15}$/;
const FEE_ENGINE_CURRENCY = "USD";

export interface NormalizedFeeBreakdownInput {
  feeCurrency: string;
  networkFee?: string | null;
  paxiServiceFee: string;
  routeFee?: string | null;
  bridgeFee?: string | null;
  relayerFee?: string | null;
  estimatedReceived?: string | null;
}

/**
 * A normalized, additive fee contract for quote previews. Amounts are decimal
 * strings and are calculated with integer micro-units; no settlement is
 * performed by this module.
 */
export interface NormalizedFeeBreakdown {
  feeCurrency: string;
  networkFee?: string;
  paxiServiceFee: string;
  routeFee?: string;
  bridgeFee?: string;
  relayerFee?: string;
  totalFee: string;
  estimatedReceived?: string;
}

function parseAmount(value: string, field: string): bigint {
  if (!NON_NEGATIVE_DECIMAL.test(value)) {
    throw new Error(`${field} must be a non-negative amount with at most 6 fractional digits`);
  }
  const [whole, fractional = ""] = value.split(".");
  return BigInt(whole) * DECIMAL_SCALE + BigInt(fractional.padEnd(6, "0") || "0");
}

function formatAmount(value: bigint): string {
  if (value < 0n) throw new Error("Fee amount cannot be negative");
  const whole = value / DECIMAL_SCALE;
  const fractional = (value % DECIMAL_SCALE).toString().padStart(6, "0").replace(/0+$/, "");
  return fractional ? `${whole.toString()}.${fractional}` : whole.toString();
}

function normalizeCurrency(value: string): string {
  const normalized = value.trim().toUpperCase();
  if (!CURRENCY_PATTERN.test(normalized)) throw new Error("Invalid fee currency");
  if (normalized !== FEE_ENGINE_CURRENCY) {
    throw new Error("Fee preview currency must be USD until chain-native conversion is implemented");
  }
  return normalized;
}

function optionalAmount(value: string | null | undefined, field: string): string | undefined {
  if (value == null) return undefined;
  return formatAmount(parseAmount(value, field));
}

export function buildNormalizedFeeBreakdown(input: NormalizedFeeBreakdownInput): NormalizedFeeBreakdown {
  const feeCurrency = normalizeCurrency(input.feeCurrency);
  const networkFee = optionalAmount(input.networkFee, "networkFee");
  const paxiServiceFee = formatAmount(parseAmount(input.paxiServiceFee, "paxiServiceFee"));
  const routeFee = optionalAmount(input.routeFee, "routeFee");
  const bridgeFee = optionalAmount(input.bridgeFee, "bridgeFee");
  const relayerFee = optionalAmount(input.relayerFee, "relayerFee");
  const estimatedReceived = optionalAmount(input.estimatedReceived, "estimatedReceived");

  const totalFee = formatAmount(
    [networkFee, paxiServiceFee, routeFee, bridgeFee, relayerFee]
      .filter((value): value is string => value !== undefined)
      .map((value) => parseAmount(value, "fee component"))
      .reduce((sum, value) => sum + value, 0n),
  );

  return {
    feeCurrency,
    ...(networkFee !== undefined ? { networkFee } : {}),
    paxiServiceFee,
    ...(routeFee !== undefined ? { routeFee } : {}),
    ...(bridgeFee !== undefined ? { bridgeFee } : {}),
    ...(relayerFee !== undefined ? { relayerFee } : {}),
    totalFee,
    ...(estimatedReceived !== undefined ? { estimatedReceived } : {}),
  };
}
