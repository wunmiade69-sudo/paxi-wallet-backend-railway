import { describe, expect, it } from "vitest";
import { createSendOperation, getSendOperation, transitionSendOperation } from "./sendOperations";

type Row = Record<string, any>;

class InMemoryOperationDb {
  rows: Row[] = [];
  insert() {
    return { values: async (value: Row) => {
      if (this.rows.some((row) => row.operationId === value.operationId)) throw new Error("duplicate operation");
      this.rows.push({ id: this.rows.length + 1, ...value });
    } };
  }
  select() {
    return { from: () => ({ where: () => ({ limit: async () => this.rows.slice(0, 1) }) }) };
  }
  update() {
    return { set: (patch: Row) => ({ where: async () => { Object.assign(this.rows[0], patch); } }) };
  }
}

const operation = (operationId: string) => ({
  operationId, userOpenId: "user-1", linkedWalletAddress: "0x1", quoteId: "quote-1", quoteFingerprint: "immutable-fingerprint",
  network: "ethereum", assetIdentity: "ethereum:native", contractAddress: null, recipientAddress: "0x2",
  transferAmount: "2", transferAmountUnits: "2000000000000000000", transferAmountUsd: "4000", paxiServiceFee: "0.01",
  paxiServiceFeeUnits: "10000000000000000", paxiServiceFeeUsd: "20", networkFee: "0.001", networkFeeUsd: "2",
  totalWalletDebitUsd: "4022", feeTransactionHash: null, sendTransactionHash: null, state: "QUOTED" as const,
  failureCode: null, reconciliationCode: null, quoteExpiresAt: new Date(Date.now() + 60_000), confirmedAt: null,
});

function createHash(seed: string): string { return `0x${seed.repeat(64).slice(0, 64)}`; }

class MockHistory {
  private rows = new Map<string, { hash: string; status: "pending" | "confirmed" | "failed" }>();
  ensure(hash: string) {
    const existing = this.rows.get(hash);
    if (existing) return existing;
    const row = { hash, status: "pending" as const };
    this.rows.set(hash, row);
    return row;
  }
  confirm(hash: string) { const row = this.rows.get(hash); if (!row) throw new Error("missing pending history"); row.status = "confirmed"; }
  count() { return this.rows.size; }
}

describe("P2.5B mocked SEND lifecycle", () => {
  it("persists fee and SEND hashes, finalizes exactly once, and never rebroadcasts known hashes", async () => {
    const db = new InMemoryOperationDb();
    const history = new MockHistory();
    const broadcasts = { fee: 0, send: 0 };
    const feeHash = createHash("a");
    const sendHash = createHash("b");

    const quoted = await createSendOperation(operation("op-complete"), db);
    const immutableQuote = quoted.quoteFingerprint;
    broadcasts.fee += 1;
    await transitionSendOperation("user-1", quoted.operationId, "FEE_BROADCAST", { feeTransactionHash: feeHash }, db);
    history.ensure(feeHash);
    await transitionSendOperation("user-1", quoted.operationId, "FEE_CONFIRMED", {}, db);
    broadcasts.send += 1;
    await transitionSendOperation("user-1", quoted.operationId, "SEND_BROADCAST", { sendTransactionHash: sendHash }, db);
    history.ensure(sendHash);
    history.ensure(sendHash);
    await transitionSendOperation("user-1", quoted.operationId, "CONFIRMED", { confirmedAt: new Date() }, db);
    history.confirm(sendHash);

    const final = await getSendOperation("user-1", quoted.operationId, db);
    expect(final?.state).toBe("CONFIRMED");
    expect(final?.feeTransactionHash).toBe(feeHash);
    expect(final?.sendTransactionHash).toBe(sendHash);
    expect(final?.quoteFingerprint).toBe(immutableQuote);
    expect(history.count()).toBe(2);
    expect(broadcasts).toEqual({ fee: 1, send: 1 });

    // Reconciliation/callback replay only reads the known hash and updates the
    // existing logical record; it never increments either broadcast counter.
    history.ensure(feeHash);
    history.ensure(sendHash);
    expect(history.count()).toBe(2);
    expect(broadcasts).toEqual({ fee: 1, send: 1 });
  });

  it("leaves a fee-confirmation timeout recoverable and does not start SEND", async () => {
    const db = new InMemoryOperationDb();
    const quoted = await createSendOperation(operation("op-fee-timeout"), db);
    await transitionSendOperation("user-1", quoted.operationId, "FEE_BROADCAST", { feeTransactionHash: createHash("c") }, db);
    const current = await getSendOperation("user-1", quoted.operationId, db);
    expect(current?.state).toBe("FEE_BROADCAST");
    expect(current?.feeTransactionHash).toBeTruthy();
    expect(current?.sendTransactionHash).toBeNull();
  });

  it("rejects a second operation with the same identity", async () => {
    const db = new InMemoryOperationDb();
    await createSendOperation(operation("op-idempotent"), db);
    await expect(createSendOperation(operation("op-idempotent"), db)).rejects.toThrow("duplicate operation");
    expect(db.rows).toHaveLength(1);
  });
});
