import { and, eq } from "drizzle-orm";
import { feePaymentLedger, type FeePaymentLedger } from "../../drizzle/schema";
import { getDb } from "../db";

type DbExecutor = any;

const TX_HASH = /^0x[0-9a-fA-F]{64}$/;

export type FeeLedgerProduct = "send" | "listing" | "create_token" | "campaign";

export interface ClaimFeePaymentInput {
  transactionHash: string;
  userOpenId: string;
  product: FeeLedgerProduct;
  operationKey: string;
  network: string;
  payerWallet?: string | null;
  treasury: string;
  asset?: string | null;
  amount: string;
}

/**
 * Atomically claims a verified on-chain fee payment for one product operation.
 * The unique transaction-hash constraint is the cross-product replay barrier.
 */
export async function claimFeePayment(input: ClaimFeePaymentInput, executor?: DbExecutor): Promise<FeePaymentLedger> {
  if (!TX_HASH.test(input.transactionHash)) throw new Error("Invalid fee transaction hash");
  if (!input.userOpenId || input.userOpenId.length > 64) throw new Error("Invalid user identifier");
  if (!input.operationKey || input.operationKey.length > 191) throw new Error("Invalid fee operation key");
  if (!input.network || input.network.length > 32) throw new Error("Invalid fee network");
  if (!input.treasury || input.treasury.length > 128) throw new Error("Invalid fee treasury");
  if (!input.amount || input.amount.length > 128) throw new Error("Invalid fee amount");

  const db = executor ?? await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(feePaymentLedger)
    .where(eq(feePaymentLedger.transactionHash, input.transactionHash))
    .limit(1);
  if (existing[0]) {
    const row = existing[0];
    if (row.product === input.product && row.operationKey === input.operationKey && row.userOpenId === input.userOpenId) return row;
    throw new Error("That fee transaction has already been used for another operation");
  }

  try {
    await db.insert(feePaymentLedger).values({
      transactionHash: input.transactionHash,
      userOpenId: input.userOpenId,
      product: input.product,
      operationKey: input.operationKey,
      network: input.network.toLowerCase(),
      payerWallet: input.payerWallet ?? null,
      treasury: input.treasury,
      asset: input.asset ?? null,
      amount: input.amount,
      status: "claimed",
    });
  } catch (error) {
    const concurrent = await db
      .select()
      .from(feePaymentLedger)
      .where(eq(feePaymentLedger.transactionHash, input.transactionHash))
      .limit(1);
    if (concurrent[0]) {
      const row = concurrent[0];
      if (row.product === input.product && row.operationKey === input.operationKey && row.userOpenId === input.userOpenId) return row;
      throw new Error("That fee transaction has already been used for another operation");
    }
    throw error;
  }

  const [claimed] = await db.select().from(feePaymentLedger).where(and(
    eq(feePaymentLedger.transactionHash, input.transactionHash),
    eq(feePaymentLedger.product, input.product),
    eq(feePaymentLedger.operationKey, input.operationKey),
  )).limit(1);
  if (!claimed) throw new Error("Fee payment could not be reloaded after claim");
  return claimed;
}
