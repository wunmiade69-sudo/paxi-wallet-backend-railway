import { describe, expect, it } from "vitest";
import { assertSafeSendFee, calculateSendFeeAmountUnits, calculateTotalWalletDebitUsd, parseSendUnits, quoteSendFee, recordConfirmedSend } from "./sendFee";
import { validateSendBalances } from "@shared/sendFeeGuards";
import { getSendFeeAssetPolicy } from "@shared/sendFeeAssetPolicy";

describe("SEND fee architecture", () => {
  it("calculates exact same-asset fee units from the server fee amount", () => {
    expect(calculateSendFeeAmountUnits("0.30", 2_000, 18)).toBe("150000000000000");
    expect(parseSendUnits("0.5", 18)).toBe(500000000000000000n);
  });

  it("handles realistic 18-decimal SENDs without Number overflow", () => {
    expect(calculateSendFeeAmountUnits("10", 2_000, 18)).toBe("5000000000000000");
    expect(calculateSendFeeAmountUnits("10", 600, 18)).toBe("16666666666666667");
  });

  it("supports 2 ETH and 10 BNB fee-unit cases that exceed MAX_SAFE_INTEGER", () => {
    expect(calculateSendFeeAmountUnits("20", 2_000, 18)).toBe("10000000000000000");
    expect(calculateSendFeeAmountUnits("30", 600, 18)).toBe("50000000000000000");
  });

  it("rounds the fee up to the smallest representable token unit", () => {
    expect(calculateSendFeeAmountUnits("0.01", 3, 0)).toBe("1");
    expect(calculateSendFeeAmountUnits("0.01", 3, 2)).toBe("1");
  });

  it("supports a zero-fee configuration without manufacturing a fee transfer", () => {
    expect(calculateSendFeeAmountUnits("0", 2_000, 18)).toBe("0");
    expect(assertSafeSendFee("0", 0)).toBeUndefined();
  });

  it("rejects fee configurations and calculated fees above the safety maximum", () => {
    expect(() => assertSafeSendFee("0.1", 1_001)).toThrow(/safety maximum/);
    expect(() => assertSafeSendFee("10000.000001", 50)).toThrow(/safety maximum/);
  });


  it("calculates the complete wallet debit identity exactly in USD micros", () => {
    expect(calculateTotalWalletDebitUsd("1000", "5", "2.50")).toBe("1007.5");
    expect(calculateTotalWalletDebitUsd("0.000001", "0.000002", "0.000003")).toBe("0.000006");
  });
  it("requires the transfer plus service fee and native gas reserve, using exact bigint base units", () => {
    // assetBalance=1.00, amount=0.98, serviceFee=0.03 (2-decimal units) -> 100n < 101n, insufficient.
    expect(() => validateSendBalances({
      assetBalanceUnits: 100n,
      amountUnits: 98n,
      serviceFeeUnits: 3n,
      nativeBalanceUnits: 10n,
      networkFeeNativeUnits: 1n,
      isNativeAsset: false,
    })).toThrow(/Insufficient asset balance/);
    // nativeBalance=0.001 < networkFeeNative=0.01 (2-decimal units: 1n < 10n).
    expect(() => validateSendBalances({
      assetBalanceUnits: 100n,
      amountUnits: 50n,
      serviceFeeUnits: 1n,
      nativeBalanceUnits: 1n,
      networkFeeNativeUnits: 10n,
      isNativeAsset: false,
    })).toThrow(/Insufficient native balance/);
    expect(() => validateSendBalances({
      assetBalanceUnits: 100n,
      amountUnits: 50n,
      serviceFeeUnits: 1n,
      nativeBalanceUnits: 10n,
      networkFeeNativeUnits: 1n,
      isNativeAsset: true,
    })).not.toThrow();
    // Exactness at the boundary: balance == required must pass (no epsilon
    // fudge in either direction now that this is integer bigint math).
    // isNativeAsset: true, so required = amountUnits + serviceFeeUnits +
    // networkFeeNativeUnits = 50n + 1n + 10n = 61n.
    expect(() => validateSendBalances({
      assetBalanceUnits: 61n,
      amountUnits: 50n,
      serviceFeeUnits: 1n,
      nativeBalanceUnits: 10n,
      networkFeeNativeUnits: 10n,
      isNativeAsset: true,
    })).not.toThrow();
    // One unit short of the boundary must still throw.
    expect(() => validateSendBalances({
      assetBalanceUnits: 60n,
      amountUnits: 50n,
      serviceFeeUnits: 1n,
      nativeBalanceUnits: 10n,
      networkFeeNativeUnits: 10n,
      isNativeAsset: true,
    })).toThrow(/Insufficient asset balance/);
    // Rejects a float/negative slipping in as a non-bigint.
    expect(() => validateSendBalances({
      // @ts-expect-error - intentionally wrong type to prove the guard rejects it
      assetBalanceUnits: 100,
      amountUnits: 50n,
      serviceFeeUnits: 1n,
      nativeBalanceUnits: 10n,
      networkFeeNativeUnits: 1n,
      isNativeAsset: false,
    })).toThrow(/exact non-negative integers/);
  });

  it("returns an honest unavailable result before any non-EVM settlement work", async () => {
    await expect(quoteSendFee({
      network: "polygon",
      walletAddress: "0x0000000000000000000000000000000000000001",
      recipient: "0x0000000000000000000000000000000000000002",
      assetAddress: null,
      assetSymbol: "POL",
      assetDecimals: 18,
      amount: "1",
      networkFeeNative: "0.001",
    })).rejects.toThrow(/unavailable/);
  });

  it("requires a canonical operation ID for durable SEND records", async () => {
    await expect(recordConfirmedSend("user-1", {
      operationId: "bad id with spaces",
      network: "ethereum",
      walletAddress: "0x0000000000000000000000000000000000000001",
      recipient: "0x0000000000000000000000000000000000000002",
      assetAddress: null,
      assetSymbol: "ETH",
      assetDecimals: 18,
      amount: "1",
      networkFeeNative: "0.001",
      transactionHash: `0x${"1".repeat(64)}`,
    })).rejects.toThrow(/operation identifier/);
  });
});


describe("P2.2 SEND fee asset safety", () => {
  it("allows native EVM assets", () => {
    expect(getSendFeeAssetPolicy("ethereum", null, "ETH", 18).kind).toBe("native");
    expect(getSendFeeAssetPolicy("bsc", null, "BNB", 18).kind).toBe("native");
  });

  it("allows only canonical USDT/USDC fee assets", () => {
    expect(getSendFeeAssetPolicy("ethereum", "0xdac17f958d2ee523a2206206994597c13d831ec7", "USDT", 6).kind).toBe("erc20");
    expect(getSendFeeAssetPolicy("bsc", "0x55d398326f99059ff775485246999027b3197955", "USDT", 18).kind).toBe("erc20");
  });

  it("rejects arbitrary ERC-20s because transfer-tax/rebase behavior is not verified", () => {
    expect(() => getSendFeeAssetPolicy("ethereum", "0x0000000000000000000000000000000000000001", "PAXI", 18)).toThrow(/not eligible for fee settlement/i);
  });

  it("rejects a non-canonical stablecoin contract", () => {
    expect(() => getSendFeeAssetPolicy("ethereum", "0x0000000000000000000000000000000000000001", "USDT", 6)).toThrow(/canonical USDT\/USDC contract/i);
  });
});
