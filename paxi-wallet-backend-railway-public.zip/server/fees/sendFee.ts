import { and, eq } from "drizzle-orm";
import { ethers } from "ethers";
import { feeRecords, sendFeeQuotes } from "../../drizzle/schema";
import { getDb } from "../db";
import { getNativeAssetPrice, getAssetPrice } from "../priceEngine";
import { recordActivity } from "../activity/activityService";
import { getChainAdapter } from "../chains/registry";
import { requireValidIdentifier } from "../chains/types";
import { classifyEvmVerificationError, verifyConfirmedEvmTransaction } from "../wallet/transactionVerifier";
import { verifyEvmAssetTransfer } from "../feeVerification";
import { calculateFee, getFeeConfig, recordFee, type FeeCalculation } from "./feeEngine";
import { getTreasuryConfiguration } from "./treasury";
import { validateSendBalances } from "@shared/sendFeeGuards";
import { randomUUID, createHash } from "node:crypto";
import { claimFeePayment } from "./paymentLedger";
import { requireLinkedWallet } from "./walletLink";
import { getSendFeeAssetPolicy } from "@shared/sendFeeAssetPolicy";
import { isSendFeeSettlementSupported } from "@shared/sendFeeSupport";
import { createSendOperation, getSendOperation, transitionSendOperation } from "./sendOperations";

const HUMAN_AMOUNT = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,36})?$/;
const OPERATION_ID = /^[A-Za-z0-9._:-]{1,128}$/;
const MAX_SEND_FEE_BPS = 1_000;
const MAX_SEND_FEE_USD = "10000";
const ERC20_DECIMALS_ABI = ["function decimals() view returns (uint8)"];

export interface SendFeeQuoteInput {
  network: string;
  walletAddress: string;
  recipient: string;
  assetAddress: string | null;
  assetSymbol: string;
  assetDecimals: number;
  amount: string;
  networkFeeNative: string;
}

export interface SendFeeQuote {
  supported: boolean;
  reason?: string;
  operation: "send";
  network: "ethereum" | "bsc";
  walletAddress: string;
  recipient: string;
  assetAddress: string | null;
  assetSymbol: string;
  assetDecimals: number;
  amount: string;
  amountUsd: string;
  networkFeeNative: string;
  networkFeeUsd: string;
  paxiFeeAmountUnits: string;
  paxiFeeAmount: string;
  paxiFeeUsd: string;
  totalDebitUsd: string;
  totalWalletDebitUsd: string;
  recipientReceives: string;
  feeCurrency: string;
  treasury: string | null;
  calculation: FeeCalculation;
  quoteId: string;
  operationId: string;
  expiresAt: string;
}

export interface RecordSendInput extends SendFeeQuoteInput {
  operationId: string;
  quoteId: string;
  feeTransactionHash?: string | null;
  transactionHash: string;
}

export interface RecordSendResult {
  success: true;
  idempotent: boolean;
  operationId: string;
  feeRecordId: number;
  activityEventId: number;
  transactionHash: string;
  feeTransactionHash: string | null;
}

function assertHumanAmount(value: string, field: string): void {
  if (!HUMAN_AMOUNT.test(value) || value === "0") throw new Error(`Invalid ${field}`);
}

function assertDecimals(value: number): void {
  if (!Number.isInteger(value) || value < 0 || value > 36) throw new Error("Invalid asset decimals");
}

export function parseSendUnits(value: string, decimals: number): bigint {
  if (!HUMAN_AMOUNT.test(value)) throw new Error("Invalid decimal amount");
  const [whole, fraction = ""] = value.split(".");
  if (fraction.length > decimals) throw new Error("Amount has more fractional digits than the asset supports");
  return BigInt(whole) * 10n ** BigInt(decimals) + BigInt((fraction || "").padEnd(decimals, "0") || "0");
}

function formatUnits(value: bigint, decimals: number): string {
  const scale = 10n ** BigInt(decimals);
  const whole = value / scale;
  const fraction = (value % scale).toString().padStart(decimals, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function addNativeAmounts(...values: string[]): string {
  return formatUnits(values.reduce((sum, value) => sum + parseSendUnits(value || "0", 18), 0n), 18);
}

const USD_SCALE = 1_000_000n;

function parseUsdMicros(value: string, field: string): bigint {
  if (!/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/.test(value)) {
    throw new Error(`${field} must be a non-negative USD amount with at most 6 fractional digits`);
  }
  const [whole, fractional = ""] = value.split(".");
  return BigInt(whole) * USD_SCALE + BigInt(fractional.padEnd(6, "0") || "0");
}

function priceToUsdMicros(priceUsd: number): bigint {
  if (!Number.isFinite(priceUsd) || priceUsd < 0) throw new Error("Price data is unavailable");
  // Provider prices are already approximate decimal data. Normalize them once
  // into the application's six-decimal USD representation, then keep all
  // token/base-unit arithmetic in BigInt. Never convert token units to Number.
  return parseUsdMicros(priceUsd.toFixed(6), "priceUsd");
}

function formatUsdMicros(value: bigint): string {
  if (value < 0n) throw new Error("USD amount cannot be negative");
  const whole = value / USD_SCALE;
  const fractional = (value % USD_SCALE).toString().padStart(6, "0").replace(/0+$/, "");
  return fractional ? `${whole}.${fractional}` : whole.toString();
}

function amountUsd(amount: string, decimals: number, priceUsd: number): string {
  assertDecimals(decimals);
  const units = parseSendUnits(amount, decimals);
  const priceMicros = priceToUsdMicros(priceUsd);
  const scale = 10n ** BigInt(decimals);
  // USD micros = floor(token base units * USD micros / token base-unit scale).
  // The display value is never derived from a floating-point token amount.
  return formatUsdMicros((units * priceMicros) / scale);
}

/** Exact USD total shown to the user before signing.
 * totalWalletDebit = transfer amount + PAXI service fee + network fee.
 */
export function calculateTotalWalletDebitUsd(transferAmountUsd: string, paxiServiceFeeUsd: string, networkFeeUsd: string): string {
  return formatUsdMicros(
    parseUsdMicros(transferAmountUsd, "transferAmountUsd") +
    parseUsdMicros(paxiServiceFeeUsd, "paxiServiceFeeUsd") +
    parseUsdMicros(networkFeeUsd, "networkFeeUsd"),
  );
}

export function calculateSendFeeAmountUnits(feeUsd: string, priceUsd: number, decimals: number): string {
  assertDecimals(decimals);
  const feeMicros = parseUsdMicros(feeUsd, "feeUsd");
  if (feeMicros === 0n) return "0";
  const priceMicros = priceToUsdMicros(priceUsd);
  if (priceMicros <= 0n) throw new Error("PAXI fee cannot be represented safely in this asset");
  const tokenScale = 10n ** BigInt(decimals);
  // ceil(feeUsdMicros * 10^decimals / priceUsdMicros).
  const units = (feeMicros * tokenScale + priceMicros - 1n) / priceMicros;
  if (units <= 0n) throw new Error("PAXI fee cannot be represented safely in this asset");
  return units.toString();
}

export function assertSafeSendFee(paxiFeeUsd: string, percentageBps: number): void {
  const feeMicros = parseUsdMicros(paxiFeeUsd, "paxiFeeUsd");
  const maxFeeMicros = parseUsdMicros(MAX_SEND_FEE_USD, "MAX_SEND_FEE_USD");
  if (feeMicros > maxFeeMicros) {
    throw new Error("Calculated SEND fee exceeds the safety maximum");
  }
  if (!Number.isInteger(percentageBps) || percentageBps < 0 || percentageBps > MAX_SEND_FEE_BPS) {
    throw new Error("Configured SEND fee exceeds the safety maximum");
  }
}

function normalizeEvmNetwork(network: string): "ethereum" | "bsc" {
  if (!isSendFeeSettlementSupported(network)) throw new Error("PAXI SEND fee settlement is unavailable on this network.");
  return network;
}

async function validateAsset(input: SendFeeQuoteInput, network: "ethereum" | "bsc"): Promise<string | null> {
  assertDecimals(input.assetDecimals);
  if (input.assetAddress == null) {
    if (input.assetDecimals !== 18) throw new Error("Native EVM assets must use 18 decimals");
    return null;
  }
  if (!ethers.isAddress(input.assetAddress)) throw new Error("Invalid asset contract");
  const normalized = ethers.getAddress(input.assetAddress);
  getSendFeeAssetPolicy(network, normalized, input.assetSymbol, input.assetDecimals);
  const adapter = getChainAdapter(network);
  if (adapter.family !== "evm" || !adapter.rpcUrl) throw new Error("EVM asset validation is unavailable");
  const onChainDecimals = await import("../chains/rpc").then(({ withEvmRpc }) =>
    withEvmRpc(network, async (provider) => {
      const code = await provider.getCode(normalized);
      if (code === "0x") throw new Error("The asset contract is not deployed on this network");
      const token = new ethers.Contract(normalized, ERC20_DECIMALS_ABI, provider);
      return Number(await token.decimals());
    }),
  );
  if (!Number.isInteger(onChainDecimals) || onChainDecimals !== input.assetDecimals) throw new Error("Asset decimals do not match the deployed token");
  return normalized;
}

async function resolvePrice(input: SendFeeQuoteInput, network: "ethereum" | "bsc"): Promise<{ asset: number; native: number }> {
  const assetPrice = input.assetAddress == null
    ? await getNativeAssetPrice(network)
    : await getAssetPrice({
        network,
        contractAddress: input.assetAddress,
        symbol: input.assetSymbol,
        decimals: input.assetDecimals,
      });
  const nativePrice = await getNativeAssetPrice(network);
  if (!assetPrice?.priceUsd || !nativePrice?.priceUsd) throw new Error("Live asset pricing is unavailable; try again shortly.");
  return { asset: assetPrice.priceUsd, native: nativePrice.priceUsd };
}

async function calculateSendFeeQuote(input: SendFeeQuoteInput): Promise<Omit<SendFeeQuote, "quoteId" | "operationId" | "expiresAt">> {
  const network = normalizeEvmNetwork(input.network);
  assertHumanAmount(input.amount, "amount");
  assertHumanAmount(input.networkFeeNative === "0" ? "0.000000000000000001" : input.networkFeeNative, "network fee");
  if (!ethers.isAddress(input.walletAddress) || !ethers.isAddress(input.recipient)) throw new Error("Invalid EVM wallet or recipient address");
  const walletAddress = requireValidIdentifier(getChainAdapter(network), input.walletAddress);
  const recipient = requireValidIdentifier(getChainAdapter(network), input.recipient);
  const assetAddress = await validateAsset(input, network);
  const treasury = getTreasuryConfiguration(network);
  const prices = await resolvePrice({ ...input, assetAddress }, network);
  const inputAmountUsd = amountUsd(input.amount, input.assetDecimals, prices.asset);
  const networkUsd = amountUsd(input.networkFeeNative, 18, prices.native);
  const config = await getFeeConfig("send", "evm");
  assertSafeSendFee("0", config.percentageBps);
  const calculation = await calculateFee("send", "evm", inputAmountUsd, networkUsd);
  assertSafeSendFee(calculation.paxiFeeUsd, config.percentageBps);
  // Only require a fee-safe asset when a non-zero PAXI service fee will be
  // settled. Zero-fee mode must not prevent ordinary ERC-20 sends.
  if (calculation.paxiFeeUsd !== "0") {
    getSendFeeAssetPolicy(network, assetAddress, input.assetSymbol, input.assetDecimals);
  }
  const amountUnits = parseSendUnits(input.amount, input.assetDecimals);
  const feeUnits = calculateSendFeeAmountUnits(calculation.paxiFeeUsd, prices.asset, input.assetDecimals);
  const feeAmount = formatUnits(BigInt(feeUnits), input.assetDecimals);
  const supported = calculation.paxiFeeUsd === "0" || treasury.settlementEnabled;
  return {
    supported,
    ...(supported ? {} : { reason: treasury.reason ?? "PAXI SEND fee settlement is unavailable on this network." }),
    operation: "send",
    network,
    walletAddress,
    recipient,
    assetAddress,
    assetSymbol: input.assetSymbol.trim().slice(0, 32),
    assetDecimals: input.assetDecimals,
    amount: formatUnits(amountUnits, input.assetDecimals),
    amountUsd: inputAmountUsd,
    networkFeeNative: input.networkFeeNative,
    networkFeeUsd: networkUsd,
    paxiFeeAmountUnits: feeUnits,
    paxiFeeAmount: feeAmount,
    paxiFeeUsd: calculation.paxiFeeUsd,
    // Keep the legacy field as an alias for compatibility, but its value is now
    // the true wallet debit rather than fee-only USD.
    totalDebitUsd: calculateTotalWalletDebitUsd(inputAmountUsd, calculation.paxiFeeUsd, networkUsd),
    totalWalletDebitUsd: calculateTotalWalletDebitUsd(inputAmountUsd, calculation.paxiFeeUsd, networkUsd),
    recipientReceives: formatUnits(amountUnits, input.assetDecimals),
    feeCurrency: input.assetSymbol.trim().toUpperCase(),
    treasury: treasury.address,
    calculation,
  };
}

function quoteFingerprint(input: SendFeeQuoteInput, quote: Omit<SendFeeQuote, "quoteId" | "operationId" | "expiresAt">): string {
  const canonical = JSON.stringify({
    network: quote.network,
    walletAddress: quote.walletAddress.toLowerCase(),
    recipient: quote.recipient.toLowerCase(),
    assetAddress: quote.assetAddress?.toLowerCase() ?? null,
    assetSymbol: quote.assetSymbol.toUpperCase(),
    assetDecimals: quote.assetDecimals,
    amount: quote.amount,
    amountUsd: quote.amountUsd,
    networkFeeNative: quote.networkFeeNative,
    networkFeeUsd: quote.networkFeeUsd,
    paxiFeeAmountUnits: quote.paxiFeeAmountUnits,
    paxiFeeAmount: quote.paxiFeeAmount,
    paxiFeeUsd: quote.paxiFeeUsd,
    feeCurrency: quote.feeCurrency,
    treasury: quote.treasury,
  });
  return createHash("sha256").update(canonical).digest("hex");
}

const SEND_QUOTE_TTL_MS = 5 * 60 * 1000;

/** Compatibility preview helper used by legacy callers; it rejects unsupported settlement before any provider work. */
export async function quoteSendFee(input: SendFeeQuoteInput): Promise<SendFeeQuote> {
  normalizeEvmNetwork(input.network);
  return calculateSendFeeQuote(input).then((calculated) => ({
    ...calculated,
    quoteId: "preview",
    operationId: "preview",
    expiresAt: new Date(Date.now() + SEND_QUOTE_TTL_MS).toISOString(),
  }));
}

export async function issueSendFeeQuote(userOpenId: string, input: SendFeeQuoteInput): Promise<SendFeeQuote> {
  if (!userOpenId || userOpenId.length > 64) throw new Error("Invalid user identifier");
  const linkedWallet = await requireLinkedWallet(userOpenId, input.walletAddress);
  const calculated = await calculateSendFeeQuote({ ...input, walletAddress: linkedWallet });
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const quoteId = randomUUID();
  const operationId = randomUUID();
  const expiresAt = new Date(Date.now() + SEND_QUOTE_TTL_MS);
  const fingerprint = quoteFingerprint(input, calculated);
  await db.insert(sendFeeQuotes).values({
    id: quoteId,
    userOpenId,
    operationId,
    fingerprint,
    network: calculated.network,
    walletAddress: calculated.walletAddress,
    recipient: calculated.recipient,
    assetAddress: calculated.assetAddress,
    assetSymbol: calculated.assetSymbol,
    assetDecimals: calculated.assetDecimals,
    amount: calculated.amount,
    amountUsd: calculated.amountUsd,
    networkFeeNative: calculated.networkFeeNative,
    networkFeeUsd: calculated.networkFeeUsd,
    paxiFeeAmountUnits: calculated.paxiFeeAmountUnits,
    paxiFeeAmount: calculated.paxiFeeAmount,
    paxiFeeUsd: calculated.paxiFeeUsd,
    totalDebitUsd: calculated.totalDebitUsd,
    feeCurrency: calculated.feeCurrency,
    treasury: calculated.treasury,
    expiresAt,
  });
  await createSendOperation({
    operationId,
    userOpenId,
    linkedWalletAddress: calculated.walletAddress,
    quoteId,
    quoteFingerprint: fingerprint,
    network: calculated.network,
    assetIdentity: `${calculated.network}:${calculated.assetAddress ?? "native"}`,
    contractAddress: calculated.assetAddress,
    recipientAddress: calculated.recipient,
    transferAmount: calculated.amount,
    transferAmountUnits: parseSendUnits(calculated.amount, calculated.assetDecimals).toString(),
    transferAmountUsd: calculated.amountUsd,
    paxiServiceFee: calculated.paxiFeeAmount,
    paxiServiceFeeUnits: calculated.paxiFeeAmountUnits,
    paxiServiceFeeUsd: calculated.paxiFeeUsd,
    networkFee: calculated.networkFeeNative,
    networkFeeUsd: calculated.networkFeeUsd,
    totalWalletDebitUsd: calculated.totalWalletDebitUsd,
    quoteExpiresAt: expiresAt,
  }, db);
  return { ...calculated, quoteId, operationId, expiresAt: expiresAt.toISOString() };
}

async function loadAndValidateSendQuote(userOpenId: string, input: RecordSendInput): Promise<SendFeeQuote> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await requireLinkedWallet(userOpenId, input.walletAddress);
  const [row] = await db.select().from(sendFeeQuotes).where(and(eq(sendFeeQuotes.id, input.quoteId), eq(sendFeeQuotes.userOpenId, userOpenId))).limit(1);
  if (!row) throw new Error("SEND quote not found");
  if (row.expiresAt.getTime() <= Date.now()) throw new Error("SEND quote has expired. Please review the transaction again.");
  if (row.operationId !== input.operationId) throw new Error("SEND operation does not match the issued quote");

  // Validate the client's supplied inputs against the immutable database snapshot.
  // Deliberately do NOT resolve prices or fee configuration here: those values are
  // frozen in the quote and must remain stable after the user broadcasts.
  const candidateSnapshot = {
    network: input.network,
    walletAddress: input.walletAddress.toLowerCase(),
    recipient: input.recipient.toLowerCase(),
    assetAddress: input.assetAddress?.toLowerCase() ?? null,
    assetSymbol: input.assetSymbol.trim().toUpperCase(),
    assetDecimals: input.assetDecimals,
    amount: input.amount,
    amountUsd: row.amountUsd,
    networkFeeNative: input.networkFeeNative,
    networkFeeUsd: row.networkFeeUsd,
    paxiFeeAmountUnits: row.paxiFeeAmountUnits,
    paxiFeeAmount: row.paxiFeeAmount,
    paxiFeeUsd: row.paxiFeeUsd,
    feeCurrency: row.feeCurrency,
    treasury: row.treasury,
  };
  const expectedSnapshot = {
    network: row.network,
    walletAddress: row.walletAddress.toLowerCase(),
    recipient: row.recipient.toLowerCase(),
    assetAddress: row.assetAddress?.toLowerCase() ?? null,
    assetSymbol: row.assetSymbol.toUpperCase(),
    assetDecimals: row.assetDecimals,
    amount: row.amount,
    amountUsd: row.amountUsd,
    networkFeeNative: row.networkFeeNative,
    networkFeeUsd: row.networkFeeUsd,
    paxiFeeAmountUnits: row.paxiFeeAmountUnits,
    paxiFeeAmount: row.paxiFeeAmount,
    paxiFeeUsd: row.paxiFeeUsd,
    feeCurrency: row.feeCurrency,
    treasury: row.treasury,
  };
  const digest = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
  if (digest(candidateSnapshot) !== digest(expectedSnapshot) || digest(expectedSnapshot) !== row.fingerprint) {
    throw new Error("SEND details no longer match the issued quote. Please review the transaction again.");
  }

  const calculation: FeeCalculation = {
    operation: "send",
    chainType: "evm",
    inputAmountUsd: row.amountUsd,
    paxiFeeUsd: row.paxiFeeUsd,
    networkFeeEstimateUsd: row.networkFeeUsd,
    totalFeeUsd: formatUsdMicros(parseUsdMicros(row.paxiFeeUsd, "paxiFeeUsd") + parseUsdMicros(row.networkFeeUsd, "networkFeeUsd")),
    breakdown: {
      percentageBps: 0,
      percentageFeeUsd: row.paxiFeeUsd,
      fixedFeeUsd: "0",
      networkFeeUsd: row.networkFeeUsd,
    },
  };
  return {
    supported: row.paxiFeeUsd === "0" || Boolean(row.treasury),
    ...(row.paxiFeeUsd === "0" || row.treasury ? {} : { reason: "PAXI SEND fee settlement is unavailable on this network." }),
    operation: "send",
    network: row.network as "ethereum" | "bsc",
    walletAddress: row.walletAddress,
    recipient: row.recipient,
    assetAddress: row.assetAddress,
    assetSymbol: row.assetSymbol,
    assetDecimals: row.assetDecimals,
    amount: row.amount,
    amountUsd: row.amountUsd,
    networkFeeNative: row.networkFeeNative,
    networkFeeUsd: row.networkFeeUsd,
    paxiFeeAmountUnits: row.paxiFeeAmountUnits,
    paxiFeeAmount: row.paxiFeeAmount,
    paxiFeeUsd: row.paxiFeeUsd,
    totalDebitUsd: row.totalDebitUsd,
    totalWalletDebitUsd: formatUsdMicros(parseUsdMicros(row.amountUsd, "amountUsd") + parseUsdMicros(row.paxiFeeUsd, "paxiFeeUsd") + parseUsdMicros(row.networkFeeUsd, "networkFeeUsd")),
    recipientReceives: row.amount,
    feeCurrency: row.feeCurrency,
    treasury: row.treasury,
    calculation,
    quoteId: row.id,
    operationId: row.operationId,
    expiresAt: row.expiresAt.toISOString(),
  };
}

function assertOperationId(value: string): void {
  if (!OPERATION_ID.test(value)) throw new Error("Invalid operation identifier");
}

export async function recordConfirmedSend(userOpenId: string, input: RecordSendInput): Promise<RecordSendResult> {
  assertOperationId(input.operationId);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [existing] = await db
    .select()
    .from(feeRecords)
    .where(and(eq(feeRecords.userOpenId, userOpenId), eq(feeRecords.operationId, input.operationId)))
    .limit(1);
  if (existing) {
    if (existing.transactionHash && existing.transactionHash !== input.transactionHash) throw new Error("OPERATION_CONFLICT: operation ID was already used for a different SEND transaction");
    if ((existing.feeTransactionHash ?? null) !== (input.feeTransactionHash ?? null)) throw new Error("OPERATION_CONFLICT: operation ID was already used for a different fee transaction");
    if (!existing.activityEventId) throw new Error("Existing SEND fee record has no activity record");
    return {
      success: true,
      idempotent: true,
      operationId: input.operationId,
      feeRecordId: Number(existing.id),
      activityEventId: Number(existing.activityEventId),
      transactionHash: existing.transactionHash ?? input.transactionHash,
      feeTransactionHash: existing.feeTransactionHash ?? null,
    };
  }

  const quote = await loadAndValidateSendQuote(userOpenId, input);
  if (!quote.supported) throw new Error(quote.reason ?? "PAXI SEND fee settlement is unavailable");
  if (quote.paxiFeeUsd !== "0" && !input.feeTransactionHash) throw new Error("A confirmed PAXI fee transaction is required before the SEND can be recorded");


  const verifiedFee = quote.paxiFeeUsd === "0"
    ? { ok: true as const, networkFeeNative: "0" }
    : await verifyEvmAssetTransfer({
        network: quote.network,
        txHash: input.feeTransactionHash!,
        payerAddress: quote.walletAddress,
        treasuryAddress: quote.treasury!,
        assetAddress: quote.assetAddress,
        assetSymbol: quote.assetSymbol,
        amountUnits: quote.paxiFeeAmountUnits,
        assetDecimals: quote.assetDecimals,
      });
  if (!verifiedFee.ok) throw new Error(verifiedFee.reason);

  const verifiedSend = await verifyConfirmedEvmTransaction(
    quote.network,
    quote.walletAddress,
    input.transactionHash,
    { expectedRecipient: quote.recipient, expectedAssetAddress: quote.assetAddress, expectedAmountUnits: parseSendUnits(quote.amount, quote.assetDecimals).toString() },
  );
  if (verifiedSend.eventType !== "send") throw new Error("The confirmed transaction is not a direct SEND");
  if (!verifiedSend.amount || parseSendUnits(verifiedSend.amount, quote.assetDecimals) !== parseSendUnits(quote.amount, quote.assetDecimals)) {
    throw new Error("The confirmed SEND amount does not match the reviewed amount");
  }

  const actualNetworkFeeNative = addNativeAmounts(verifiedSend.networkFeeNative, verifiedFee.networkFeeNative ?? "0");
  // The immutable quote governs the PAXI service fee. Do not reprice after the
  // user's fee/SEND transactions have been broadcast. The quoted network fee
  // remains the authoritative review snapshot for this operation.
  const { activity, fee } = await db.transaction(async (tx) => {
    if (input.feeTransactionHash) {
      await claimFeePayment({
        transactionHash: input.feeTransactionHash,
        userOpenId,
        product: "send",
        operationKey: input.operationId,
        network: quote.network,
        payerWallet: quote.walletAddress,
        treasury: quote.treasury!,
        asset: quote.feeCurrency,
        amount: quote.paxiFeeAmountUnits,
      }, tx);
    }

    const activity = await recordActivity({
    userOpenId,
    walletAddress: quote.walletAddress,
    chainId: quote.network,
    eventType: "send",
    transactionHash: verifiedSend.transactionHash,
    assetId: null,
    amount: verifiedSend.amount,
    amountUsd: quote.amountUsd,
    feeUsd: quote.calculation.totalFeeUsd,
    networkFeeUsd: quote.networkFeeUsd,
    paxiFeeUsd: quote.paxiFeeUsd,
    verificationSource: "server_semantic",
    amountUsdSource: "server_internal",
    status: "confirmed",
    createdAt: verifiedSend.blockTimestampMs == null ? new Date() : new Date(verifiedSend.blockTimestampMs),
    }, tx);
    const fee = await recordFee({
    userOpenId,
    operation: "send",
    operationId: input.operationId,
    walletAddress: quote.walletAddress,
    chainType: quote.network,
    asset: `${quote.network}:${quote.assetAddress ?? "native"}`,
    feeCurrency: quote.feeCurrency,
    feeAmount: quote.paxiFeeAmountUnits,
    assetDecimals: quote.assetDecimals,
    treasury: quote.treasury,
    inputAmountUsd: quote.amountUsd,
    networkFeeEstimateUsd: quote.networkFeeUsd,
    activityEventId: Number(activity.id),
    transactionHash: verifiedSend.transactionHash,
    feeTransactionHash: input.feeTransactionHash ?? null,
    status: "confirmed",
    }, tx);
    if (quote.paxiFeeUsd !== "0") {
      await transitionSendOperation(userOpenId, input.operationId, "FEE_BROADCAST", { feeTransactionHash: input.feeTransactionHash!, reconciliationCode: "CONFIRMED" }, tx);
      await transitionSendOperation(userOpenId, input.operationId, "FEE_CONFIRMED", { reconciliationCode: "CONFIRMED" }, tx);
    }
    await transitionSendOperation(userOpenId, input.operationId, "SEND_BROADCAST", {
      sendTransactionHash: verifiedSend.transactionHash,
      reconciliationCode: "CONFIRMED",
    }, tx);
    await transitionSendOperation(userOpenId, input.operationId, "CONFIRMED", {
      sendTransactionHash: verifiedSend.transactionHash,
      confirmedAt: new Date(),
      reconciliationCode: "CONFIRMED",
    }, tx);
    return { activity, fee };
  });
  return {
    success: true,
    idempotent: false,
    operationId: input.operationId,
    feeRecordId: Number(fee.id),
    activityEventId: Number(activity.id),
    transactionHash: verifiedSend.transactionHash,
    feeTransactionHash: input.feeTransactionHash ?? null,
  };
}


export type ReconcileSendInput = Omit<RecordSendInput, "feeTransactionHash" | "transactionHash"> & {
  feeTransactionHash?: string | null;
  transactionHash?: string | null;
};

export type SendReconciliationCode =
  | "PENDING" | "CONFIRMING" | "CONFIRMED" | "FAILED" | "REJECTED"
  | "WRONG_PAYER" | "WRONG_TREASURY" | "WRONG_ASSET" | "WRONG_AMOUNT" | "WRONG_CHAIN" | "WRONG_RECIPIENT"
  | "FEE_PAYMENT_REUSED" | "OPERATION_CONFLICT" | "QUOTE_INVALID" | "QUOTE_EXPIRED"
  | "RPC_UNAVAILABLE" | "RPC_TIMEOUT" | "TRANSACTION_NOT_FOUND" | "RECONCILIATION_REQUIRED";

export interface SendReconciliationResult {
  code: SendReconciliationCode;
  state: "PENDING" | "CONFIRMING" | "CONFIRMED" | "FAILED" | "REJECTED";
  fee: Awaited<ReturnType<typeof import("../wallet/transactionVerifier").reconcileEvmTransaction>> | null;
  send: Awaited<ReturnType<typeof import("../wallet/transactionVerifier").reconcileEvmTransaction>> | null;
  detail?: string;
}

function errorCode(error: unknown): SendReconciliationCode {
  const message = error instanceof Error ? error.message.toLowerCase() : String(error).toLowerCase();
  if (message.includes("expired")) return "QUOTE_EXPIRED";
  if (message.includes("does not match") || message.includes("conflict") || message.includes("already used")) return "OPERATION_CONFLICT";
  return "QUOTE_INVALID";
}

function mapEvmCode(code: ReturnType<typeof classifyEvmVerificationError>): SendReconciliationCode {
  return code;
}

async function persistReconciliationState(userOpenId: string, operationId: string, state: "FEE_BROADCAST" | "FEE_CONFIRMED" | "SEND_BROADCAST" | "CONFIRMED" | "FAILED" | "RECONCILIATION_REQUIRED", patch: Record<string, unknown> = {}): Promise<void> {
  const operation = await getSendOperation(userOpenId, operationId);
  if (!operation || operation.state === state) return;
  await transitionSendOperation(userOpenId, operationId, state, patch);
}

export async function reconcileSend(userOpenId: string, input: ReconcileSendInput): Promise<SendReconciliationResult> {
  const { reconcileEvmTransaction } = await import("../wallet/transactionVerifier");
  if (!input.feeTransactionHash && !input.transactionHash) return { code: "PENDING", state: "PENDING", fee: null, send: null };
  let quote: SendFeeQuote;
  try {
    quote = await loadAndValidateSendQuote(userOpenId, { ...input, transactionHash: input.transactionHash ?? "0x" + "0".repeat(64) });
  } catch (error) {
    return { code: errorCode(error), state: "REJECTED", fee: null, send: null, detail: error instanceof Error ? error.message : String(error) };
  }
  const fee = input.feeTransactionHash ? await reconcileEvmTransaction(quote.network, quote.walletAddress, input.feeTransactionHash, {
    expectedRecipient: quote.treasury ?? undefined, expectedAssetAddress: quote.assetAddress, expectedAmountUnits: quote.paxiFeeAmountUnits,
  }) : null;
  if (fee && fee.status === "failed") {
    await persistReconciliationState(userOpenId, input.operationId, "FAILED", { failureCode: "FEE_FAILED", reconciliationCode: "FAILED" });
    const classified = mapEvmCode(classifyEvmVerificationError(new Error(fee.reason)));
    const code = classified === "WRONG_RECIPIENT" ? "WRONG_TREASURY" : classified;
    return { code, state: "FAILED", fee, send: null, detail: fee.reason };
  }
  if (fee && fee.status === "unknown") {
    await persistReconciliationState(userOpenId, input.operationId, "RECONCILIATION_REQUIRED", { reconciliationCode: fee.code === "RPC_TIMEOUT" ? "RPC_TIMEOUT" : "RPC_UNAVAILABLE" });
    return { code: fee.code === "RPC_TIMEOUT" ? "RPC_TIMEOUT" : "RPC_UNAVAILABLE", state: "REJECTED", fee, send: null, detail: fee.reason };
  }
  if (fee?.status === "pending") await persistReconciliationState(userOpenId, input.operationId, "FEE_BROADCAST", { feeTransactionHash: input.feeTransactionHash, reconciliationCode: "PENDING" });
  if (fee?.status === "confirming") await persistReconciliationState(userOpenId, input.operationId, "FEE_BROADCAST", { feeTransactionHash: input.feeTransactionHash, reconciliationCode: "CONFIRMING" });
  if (quote.paxiFeeUsd !== "0" && (!fee || fee.status !== "confirmed")) return { code: fee?.status === "pending" ? "PENDING" : "CONFIRMING", state: fee?.status === "pending" ? "PENDING" : "CONFIRMING", fee, send: null };
  if (fee?.status === "confirmed") await persistReconciliationState(userOpenId, input.operationId, "FEE_CONFIRMED", { feeTransactionHash: input.feeTransactionHash, reconciliationCode: "CONFIRMED" });
  const send = input.transactionHash ? await reconcileEvmTransaction(quote.network, quote.walletAddress, input.transactionHash, {
    expectedRecipient: quote.recipient, expectedAssetAddress: quote.assetAddress, expectedAmountUnits: parseSendUnits(quote.amount, quote.assetDecimals).toString(),
  }) : null;
  if (!send) return { code: "PENDING", state: "PENDING", fee, send: null };
  if (send.status === "pending") { await persistReconciliationState(userOpenId, input.operationId, "SEND_BROADCAST", { sendTransactionHash: input.transactionHash, reconciliationCode: "PENDING" }); return { code: "PENDING", state: "PENDING", fee, send }; }
  if (send.status === "confirming") { await persistReconciliationState(userOpenId, input.operationId, "SEND_BROADCAST", { sendTransactionHash: input.transactionHash, reconciliationCode: "CONFIRMING" }); return { code: "CONFIRMING", state: "CONFIRMING", fee, send }; }
  if (send.status === "unknown") { await persistReconciliationState(userOpenId, input.operationId, "RECONCILIATION_REQUIRED", { reconciliationCode: send.code === "RPC_TIMEOUT" ? "RPC_TIMEOUT" : "RPC_UNAVAILABLE" }); return { code: send.code === "RPC_TIMEOUT" ? "RPC_TIMEOUT" : "RPC_UNAVAILABLE", state: "REJECTED", fee, send, detail: send.reason }; }
  if (send.status === "failed") { await persistReconciliationState(userOpenId, input.operationId, "FAILED", { failureCode: mapEvmCode(classifyEvmVerificationError(new Error(send.reason))), reconciliationCode: "FAILED" }); return { code: mapEvmCode(classifyEvmVerificationError(new Error(send.reason))), state: "FAILED", fee, send, detail: send.reason }; }
  await persistReconciliationState(userOpenId, input.operationId, "CONFIRMED", { sendTransactionHash: input.transactionHash, confirmedAt: new Date(), reconciliationCode: "CONFIRMED" });
  return { code: "CONFIRMED", state: "CONFIRMED", fee, send };
}
