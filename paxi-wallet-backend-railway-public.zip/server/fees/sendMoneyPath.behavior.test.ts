import { describe, expect, it } from "vitest";
import { claimFeePayment } from "./paymentLedger";
import { assertSafeSendFee, calculateSendFeeAmountUnits, calculateTotalWalletDebitUsd, parseSendUnits, quoteSendFee } from "./sendFee";
import { createSendOperation, getSendOperation, transitionSendOperation } from "./sendOperations";
import { saveSendRecovery, loadSendRecovery, clearSendRecovery } from "../../client/src/lib/wallet/sendRecovery";

type Row = Record<string, any>;

class FakeLedgerDb {
  rows: Row[] = [];
  select() { return { from: () => ({ where: () => ({ limit: async () => this.rows.slice(0, 1) }) }) }; }
  insert() { return { values: async (value: Row) => { await new Promise((resolve) => setTimeout(resolve, 2)); if (this.rows.some((row) => row.transactionHash === value.transactionHash)) throw new Error("duplicate key"); this.rows.push({ id: this.rows.length + 1, ...value }); } }; }
}

class FakeOperationDb {
  rows: Row[] = [];
  select() { return { from: () => ({ where: () => ({ limit: async () => this.rows.slice(0, 1) }) }) }; }
  insert() { return { values: async (value: Row) => { if (this.rows.some((row) => row.operationId === value.operationId)) throw new Error("duplicate operation"); this.rows.push({ id: this.rows.length + 1, ...value }); } }; }
  update() { return { set: (patch: Row) => ({ where: async () => { Object.assign(this.rows[0], patch); } }) }; }
}

const payment = (product: "send" | "listing" | "create_token" | "campaign", operationKey: string) => ({
  transactionHash: `0x${"a".repeat(64)}`, userOpenId: `user-${operationKey}`, product, operationKey,
  network: "ethereum", payerWallet: "0x0000000000000000000000000000000000000001",
  treasury: "0x0000000000000000000000000000000000000002", asset: "ethereum:native", amount: "1",
});

describe("P2.5B real money-path behavior with mocked dependencies", () => {
  it("allows exactly one winner for concurrent fee-hash claims", async () => {
    const db = new FakeLedgerDb();
    const results = await Promise.allSettled([claimFeePayment(payment("send", "op-a"), db), claimFeePayment(payment("send", "op-b"), db)]);
    expect(results.filter((result) => result.status === "fulfilled")).toHaveLength(1);
    expect(results.filter((result) => result.status === "rejected")).toHaveLength(1);
    expect(db.rows).toHaveLength(1);
  });

  it("rejects the same fee hash across products", async () => {
    const db = new FakeLedgerDb();
    await claimFeePayment(payment("send", "op-send"), db);
    await expect(claimFeePayment(payment("listing", "op-listing"), db)).rejects.toThrow(/already been used/);
    await expect(claimFeePayment(payment("create_token", "op-token"), db)).rejects.toThrow(/already been used/);
    await expect(claimFeePayment(payment("campaign", "op-campaign"), db)).rejects.toThrow(/already been used/);
  });

  it("returns the same logical result for an idempotent ledger retry", async () => {
    const db = new FakeLedgerDb();
    const first = await claimFeePayment(payment("send", "op-same"), db);
    const second = await claimFeePayment(payment("send", "op-same"), db);
    expect(second.id).toBe(first.id);
    expect(db.rows).toHaveLength(1);
  });

  it("persists and transitions a durable operation only through valid states", async () => {
    const db = new FakeOperationDb();
    await createSendOperation({ operationId: "op-1", userOpenId: "user-1", linkedWalletAddress: "0x1", quoteId: "quote-1", quoteFingerprint: "fp", network: "ethereum", assetIdentity: "ethereum:native", contractAddress: null, recipientAddress: "0x2", transferAmount: "2", transferAmountUnits: "2000000000000000000", transferAmountUsd: "4000", paxiServiceFee: "0.01", paxiServiceFeeUnits: "10000000000000000", paxiServiceFeeUsd: "20", networkFee: "0.001", networkFeeUsd: "2", totalWalletDebitUsd: "4022", feeTransactionHash: null, sendTransactionHash: null, state: "QUOTED", failureCode: null, reconciliationCode: null, quoteExpiresAt: new Date(Date.now() + 60_000), confirmedAt: null }, db);
    await transitionSendOperation("user-1", "op-1", "FEE_BROADCAST", { feeTransactionHash: `0x${"b".repeat(64)}` }, db);
    await transitionSendOperation("user-1", "op-1", "RECONCILIATION_REQUIRED", { reconciliationCode: "RPC_TIMEOUT" }, db);
    const restored = await getSendOperation("user-1", "op-1", db);
    expect(restored?.state).toBe("RECONCILIATION_REQUIRED");
    await expect(transitionSendOperation("user-1", "op-1", "QUOTED", {}, db)).rejects.toThrow(/Invalid durable SEND operation transition/);
  });

  it("recovers a known broadcast from client reload storage without creating a new operation", () => {
    const storage = new Map<string, string>();
    const original = globalThis.localStorage;
    Object.defineProperty(globalThis, "localStorage", { configurable: true, value: { setItem: (key: string, value: string) => storage.set(key, value), getItem: (key: string) => storage.get(key) ?? null, removeItem: (key: string) => storage.delete(key) } });
    try {
      clearSendRecovery();
      saveSendRecovery({ operationId: "op-reload", quoteId: "quote-reload", network: "ethereum", walletAddress: "0xA", recipient: "0xB", assetAddress: null, assetSymbol: "ETH", amount: "2", feeTransactionHash: `0x${"c".repeat(64)}`, transactionHash: null });
      const recovered = loadSendRecovery({ network: "ethereum", walletAddress: "0xa", recipient: "0xb", assetSymbol: "ETH", amount: "2" });
      expect(recovered?.operationId).toBe("op-reload");
      expect(recovered?.feeTransactionHash).toMatch(/^0x/);
    } finally {
      clearSendRecovery();
      Object.defineProperty(globalThis, "localStorage", { configurable: true, value: original });
    }
  });

  it("keeps 18-decimal ETH and BNB base-unit arithmetic outside Number safe range", () => {
    expect(parseSendUnits("2", 18)).toBe(2000000000000000000n);
    expect(parseSendUnits("10", 18)).toBe(10000000000000000000n);
    expect(calculateSendFeeAmountUnits("10", 2000, 18)).toBe("5000000000000000");
  });

  it("calculates six-decimal USDT fee units and preserves dust rounding", () => {
    expect(parseSendUnits("1000000", 6)).toBe(1000000000000n);
    expect(calculateSendFeeAmountUnits("1", 1, 6)).toBe("1000000");
    expect(() => parseSendUnits("0.0000001", 6)).toThrow(/fractional digits/);
  });

  it("enforces the service-fee cap and exact total debit identity", () => {
    expect(() => assertSafeSendFee("10000.000001", 50)).toThrow(/safety maximum/);
    expect(() => assertSafeSendFee("10", 1001)).toThrow(/safety maximum/);
    expect(calculateTotalWalletDebitUsd("4000", "20", "2")).toBe("4022");
    expect(calculateTotalWalletDebitUsd("0.000001", "0", "0.000001")).toBe("0.000002");
  });

  it("fails closed for unsupported SEND fee settlement networks", async () => {
    await expect(quoteSendFee({ network: "polygon", walletAddress: "0x1", recipient: "0x2", assetAddress: null, assetSymbol: "MATIC", assetDecimals: 18, amount: "1", networkFeeNative: "0.01" })).rejects.toThrow(/unavailable/);
    await expect(quoteSendFee({ network: "arbitrum", walletAddress: "0x1", recipient: "0x2", assetAddress: null, assetSymbol: "ETH", assetDecimals: 18, amount: "1", networkFeeNative: "0.01" })).rejects.toThrow(/unavailable/);
    await expect(quoteSendFee({ network: "solana", walletAddress: "x", recipient: "y", assetAddress: null, assetSymbol: "SOL", assetDecimals: 9, amount: "1", networkFeeNative: "0.01" })).rejects.toThrow(/unavailable/);
  });
});
