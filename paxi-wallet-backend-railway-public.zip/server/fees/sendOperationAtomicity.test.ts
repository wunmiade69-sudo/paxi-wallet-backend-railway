import { describe, expect, it } from "vitest";
import { createSendOperation, getSendOperation, transitionSendOperation } from "./sendOperations";

type Row = Record<string, any>;

/**
 * A fake executor that mimics the rollback contract Drizzle's
 * db.transaction() provides on top of a real relational database: if the
 * callback throws, none of the writes made through `tx` during that
 * callback become visible outside it. This is a contract-level test - it
 * cannot exercise MySQL's actual WAL/rollback machinery (no database is
 * reachable in this sandbox), but it does prove that sendFee.ts's use of
 * `db.transaction(async (tx) => { ...activity...fee...operation transitions })`
 * has no code path that leaks a write outside the transaction boundary
 * (e.g. no accidental use of the outer `db` instead of `tx` inside the
 * callback, which would silently defeat atomicity even with a real DB).
 */
class RollbackAwareDb {
  committedRows: Row[] = [];

  select(rows: Row[]) {
    return { from: () => ({ where: () => ({ limit: async () => rows.slice(0, 1) }) }) };
  }

  async transaction<T>(callback: (tx: FakeTx) => Promise<T>): Promise<T> {
    // Deep-clone every row, not just the array. `[...this.committedRows]`
    // alone copies the array but each element is still the SAME object
    // reference as the one in `this.committedRows` - so `FakeTx.update()`'s
    // `Object.assign(this.rows[0], patch)` would mutate the committed row
    // in place, and that mutation would be visible from outside the
    // transaction even if the callback later throws and `staged` itself is
    // discarded. Cloning each row here is what actually gives this fake
    // transaction isolated state, matching a real DB transaction where
    // uncommitted writes are invisible outside it until COMMIT.
    const staged: Row[] = this.committedRows.map((row) => ({ ...row }));
    const tx = new FakeTx(staged);
    try {
      const result = await callback(tx);
      this.committedRows = staged; // commit: only reached if callback did not throw
      return result;
    } catch (error) {
      // rollback: `staged` (and everything tx wrote into it) is discarded;
      // this.committedRows still holds its original, untouched row objects.
      throw error;
    }
  }
}

class FakeTx {
  constructor(private rows: Row[]) {}
  select() {
    return { from: () => ({ where: () => ({ limit: async () => this.rows.slice(0, 1) }) }) };
  }
  insert() {
    return {
      values: async (value: Row) => {
        if (this.rows.some((row) => row.operationId === value.operationId)) throw new Error("duplicate operation");
        this.rows.push({ id: this.rows.length + 1, ...value });
      },
    };
  }
  update() {
    return { set: (patch: Row) => ({ where: async () => { Object.assign(this.rows[0], patch); } }) };
  }
}

const baseOperation = (operationId: string) => ({
  operationId,
  userOpenId: "user-1",
  linkedWalletAddress: "0x1",
  quoteId: "quote-1",
  quoteFingerprint: "fp",
  network: "ethereum",
  assetIdentity: "ethereum:native",
  contractAddress: null,
  recipientAddress: "0x2",
  transferAmount: "2",
  transferAmountUnits: "2000000000000000000",
  transferAmountUsd: "4000",
  paxiServiceFee: "0.01",
  paxiServiceFeeUnits: "10000000000000000",
  paxiServiceFeeUsd: "20",
  networkFee: "0.001",
  networkFeeUsd: "2",
  totalWalletDebitUsd: "4022",
  feeTransactionHash: null,
  sendTransactionHash: null,
  state: "QUOTED" as const,
  failureCode: null,
  reconciliationCode: null,
  quoteExpiresAt: new Date(Date.now() + 60_000),
  confirmedAt: null,
});

describe("SEND operation database atomicity contract", () => {
  it("does not leave a partially-transitioned operation visible if the transaction callback throws after some writes", async () => {
    const db = new RollbackAwareDb();
    // Seed a QUOTED operation as if issueSendFeeQuote had already run outside this transaction.
    await db.transaction(async (tx) => {
      await createSendOperation(baseOperation("op-partial"), tx);
    });
    expect(db.committedRows).toHaveLength(1);
    expect(db.committedRows[0].state).toBe("QUOTED");

    // Simulate the confirm-path transaction from sendFee.ts: several transitions,
    // then something downstream (e.g. recordFee) throws before the transaction completes.
    await expect(
      db.transaction(async (tx) => {
        await transitionSendOperation("user-1", "op-partial", "FEE_BROADCAST", { feeTransactionHash: `0x${"a".repeat(64)}` }, tx);
        await transitionSendOperation("user-1", "op-partial", "FEE_CONFIRMED", {}, tx);
        throw new Error("simulated downstream failure (e.g. fee ledger write failed)");
      }),
    ).rejects.toThrow(/simulated downstream failure/);

    // The operation outside the transaction must still show QUOTED - not
    // FEE_CONFIRMED - because the whole callback rolled back together.
    const afterRollback = await getSendOperation("user-1", "op-partial", { select: db.select.bind(db, db.committedRows) });
    expect(afterRollback?.state).toBe("QUOTED");
  });

  it("commits every write together when the transaction callback succeeds", async () => {
    const db = new RollbackAwareDb();
    await db.transaction(async (tx) => {
      await createSendOperation(baseOperation("op-success"), tx);
    });
    await db.transaction(async (tx) => {
      await transitionSendOperation("user-1", "op-success", "FEE_BROADCAST", { feeTransactionHash: `0x${"b".repeat(64)}` }, tx);
      await transitionSendOperation("user-1", "op-success", "FEE_CONFIRMED", {}, tx);
      await transitionSendOperation("user-1", "op-success", "SEND_BROADCAST", { sendTransactionHash: `0x${"c".repeat(64)}` }, tx);
      await transitionSendOperation("user-1", "op-success", "CONFIRMED", { confirmedAt: new Date() }, tx);
    });
    const committed = await getSendOperation("user-1", "op-success", { select: db.select.bind(db, db.committedRows) });
    expect(committed?.state).toBe("CONFIRMED");
  });

  it("rejects creating a second operation under a reused operationId rather than silently duplicating it (retry safety)", async () => {
    const db = new RollbackAwareDb();
    await db.transaction(async (tx) => {
      await createSendOperation(baseOperation("op-retry"), tx);
    });
    await expect(
      db.transaction(async (tx) => {
        await createSendOperation(baseOperation("op-retry"), tx);
      }),
    ).rejects.toThrow(/duplicate operation/);
    expect(db.committedRows).toHaveLength(1);
  });
});
