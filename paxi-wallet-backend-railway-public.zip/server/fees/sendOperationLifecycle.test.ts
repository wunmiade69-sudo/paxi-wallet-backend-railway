import { describe, expect, it } from "vitest";
import { assertSendOperationTransition, canTransitionSendOperation } from "../../shared/sendOperationLifecycle";

describe("durable SEND operation lifecycle", () => {
  it.each([
    ["QUOTED", "FEE_BROADCAST"], ["FEE_BROADCAST", "FEE_CONFIRMED"], ["FEE_CONFIRMED", "SEND_BROADCAST"],
    ["SEND_BROADCAST", "CONFIRMED"], ["FEE_BROADCAST", "FAILED"], ["FEE_CONFIRMED", "FAILED"],
    ["SEND_BROADCAST", "RECONCILIATION_REQUIRED"], ["RECONCILIATION_REQUIRED", "CONFIRMED"],
  ] as const)("allows %s -> %s", (from, to) => expect(canTransitionSendOperation(from, to)).toBe(true));

  it.each([
    ["CONFIRMED", "SEND_BROADCAST"], ["FEE_CONFIRMED", "FEE_BROADCAST"],
    ["FAILED", "CONFIRMED"],
  ] as const)("rejects invalid transition %s -> %s", (from, to) => {
    expect(() => assertSendOperationTransition(from, to)).toThrow(/Invalid durable SEND operation transition/);
  });

  it("permits idempotent same-state observation", () => {
    expect(canTransitionSendOperation("RECONCILIATION_REQUIRED", "RECONCILIATION_REQUIRED")).toBe(true);
  });
});
