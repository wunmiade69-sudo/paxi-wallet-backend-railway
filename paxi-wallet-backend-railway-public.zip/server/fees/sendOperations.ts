import { and, eq } from "drizzle-orm";
import { sendOperations, type InsertSendOperation, type SendOperation } from "../../drizzle/schema";
import { getDb } from "../db";
import { assertSendOperationTransition, type SendOperationState } from "@shared/sendOperationLifecycle";

type DbExecutor = any;

export async function createSendOperation(input: InsertSendOperation, executor?: DbExecutor): Promise<SendOperation> {
  const db = executor ?? await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(sendOperations).values(input);
  const [row] = await db.select().from(sendOperations).where(eq(sendOperations.operationId, input.operationId)).limit(1);
  if (!row) throw new Error("SEND operation was not persisted");
  return row;
}

export async function getSendOperation(userOpenId: string, operationId: string, executor?: DbExecutor): Promise<SendOperation | undefined> {
  const db = executor ?? await getDb();
  if (!db) throw new Error("Database not available");
  const [row] = await db.select().from(sendOperations).where(and(eq(sendOperations.operationId, operationId), eq(sendOperations.userOpenId, userOpenId))).limit(1);
  return row;
}

export async function transitionSendOperation(userOpenId: string, operationId: string, to: SendOperationState, patch: Partial<InsertSendOperation> = {}, executor?: DbExecutor): Promise<SendOperation> {
  const db = executor ?? await getDb();
  if (!db) throw new Error("Database not available");
  const current = await getSendOperation(userOpenId, operationId, db);
  if (!current) throw new Error("SEND operation not found");
  assertSendOperationTransition(current.state, to);
  await db.update(sendOperations).set({ ...patch, state: to, updatedAt: new Date() }).where(and(eq(sendOperations.operationId, operationId), eq(sendOperations.userOpenId, userOpenId)));
  const updated = await getSendOperation(userOpenId, operationId, db);
  if (!updated) throw new Error("SEND operation disappeared after transition");
  return updated;
}
