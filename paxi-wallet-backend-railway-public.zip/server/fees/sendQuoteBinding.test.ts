import { describe, expect, it } from "vitest";

describe("SEND quote binding contract", () => {
  it("requires a server-issued quote id and operation id", () => {
    expect("quoteId" in { quoteId: "q", operationId: "op" }).toBe(true);
  });

  it("documents the five-minute quote lifetime", () => {
    const ttl = 5 * 60 * 1000;
    expect(ttl).toBe(300_000);
  });

  it("treats a quote snapshot as immutable when price/config changes", () => {
    const snapshot = { amountUsd: "4000", paxiFeeUsd: "20", networkFeeUsd: "2" };
    const later = { amountUsd: "4200", paxiFeeUsd: "21", networkFeeUsd: "2" };
    expect(snapshot).not.toEqual(later);
    expect(snapshot.paxiFeeUsd).toBe("20");
  });
});
