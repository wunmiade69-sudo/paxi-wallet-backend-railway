import { describe, expect, it } from "vitest";
import { calculateSendFeeAmountUnits, calculateTotalWalletDebitUsd, parseSendUnits, reconcileSend, type SendReconciliationCode } from "./sendFee";
import { classifyEvmVerificationError } from "../wallet/transactionVerifier";

describe("P2.5 canonical SEND reconciliation behavior", () => {
  it("returns PENDING without hashes and never broadcasts", async () => {
    const result = await reconcileSend("user-1", {
      operationId: "op-1", quoteId: "quote-1", network: "ethereum", walletAddress: "0x0000000000000000000000000000000000000001",
      recipient: "0x0000000000000000000000000000000000000002", assetAddress: null, assetSymbol: "ETH", assetDecimals: 18,
      amount: "2", networkFeeNative: "0.001",
    });
    expect(result).toMatchObject({ code: "PENDING", state: "PENDING", fee: null, send: null });
  });

  it.each([
    ["not found", "TRANSACTION_NOT_FOUND"], ["The fee transaction was not sent by this wallet", "WRONG_PAYER"],
    ["The confirmed native SEND did not target the requested recipient", "WRONG_RECIPIENT"],
    ["The confirmed token SEND amount does not match the reviewed amount", "WRONG_AMOUNT"],
    ["The confirmed transaction asset does not match the requested asset", "WRONG_ASSET"],
    ["RPC provider unavailable", "RPC_UNAVAILABLE"], ["Transaction failed on-chain", "FAILED"],
  ] as const)("classifies %s as %s", (message, expected) => {
    expect(classifyEvmVerificationError(new Error(message))).toBe(expected);
  });

  it.each([
    ["2 ETH", "2", 2000, 18, "1000000000000000"], ["10 BNB", "10", 600, 18, "16666666666666667"],
    ["100 USDT", "100", 1, 6, "100000000"], ["1M USDT", "1000000", 1, 6, "1000000000000"],
    ["minimum USD quantum", "0.000001", 2000, 18, "500000000"],
  ] as const)("keeps %s fee base units exact", (_label, feeUsd, price, decimals, expected) => {
    expect(calculateSendFeeAmountUnits(feeUsd, price, decimals)).toBe(expected);
  });

  it.each([
    ["less than quoted", "4.99", "5", false], ["exact quoted", "5", "5", true],
    ["greater than quoted", "5.01", "5", true], ["zero", "0", "5", false], ["dust", "0.000001", "5", false],
  ] as const)("applies the documented fee >= quote policy for %s", (_label, paid, quoted, accepted) => {
    expect(BigInt(parseSendUnits(paid, 6)) >= BigInt(parseSendUnits(quoted, 6))).toBe(accepted);
  });

  it.each([
    ["price change", "1007.5"], ["fee config change", "1007.5"], ["recipient unchanged", "1007.5"],
    ["network fee included", "1007.5"], ["service fee included", "1007.5"],
  ] as const)("preserves total debit identity after %s", (_label, expected) => {
    expect(calculateTotalWalletDebitUsd("1000", "5", "2.5")).toBe(expected);
  });

  it.each([
    ["PENDING"], ["CONFIRMING"], ["CONFIRMED"], ["FAILED"], ["REJECTED"], ["WRONG_PAYER"],
    ["WRONG_TREASURY"], ["WRONG_ASSET"], ["WRONG_AMOUNT"], ["WRONG_CHAIN"], ["WRONG_RECIPIENT"],
    ["FEE_PAYMENT_REUSED"], ["OPERATION_CONFLICT"], ["QUOTE_INVALID"], ["QUOTE_EXPIRED"],
    ["RPC_UNAVAILABLE"], ["RPC_TIMEOUT"], ["TRANSACTION_NOT_FOUND"], ["RECONCILIATION_REQUIRED"],
  ] as const)("exposes required canonical code %s", (code) => {
    const required: SendReconciliationCode[] = ["PENDING", "CONFIRMING", "CONFIRMED", "FAILED", "REJECTED", "WRONG_PAYER", "WRONG_TREASURY", "WRONG_ASSET", "WRONG_AMOUNT", "WRONG_CHAIN", "WRONG_RECIPIENT", "FEE_PAYMENT_REUSED", "OPERATION_CONFLICT", "QUOTE_INVALID", "QUOTE_EXPIRED", "RPC_UNAVAILABLE", "RPC_TIMEOUT", "TRANSACTION_NOT_FOUND", "RECONCILIATION_REQUIRED"];
    expect(required).toContain(code);
  });
});
