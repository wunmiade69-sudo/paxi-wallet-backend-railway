import { getAddress } from "ethers";
import { PublicKey } from "@solana/web3.js";
import * as bitcoin from "bitcoinjs-lib";
import { ENV } from "../_core/env";

export type TreasuryNetwork = "ethereum" | "bsc" | "polygon" | "arbitrum" | "solana" | "bitcoin";
export type TreasuryFamily = "evm" | "solana" | "bitcoin";

export interface TreasuryConfiguration {
  network: TreasuryNetwork;
  family: TreasuryFamily;
  address: string | null;
  configured: boolean;
  validated: boolean;
  feeConstructionImplemented: boolean;
  feeBroadcastImplemented: boolean;
  feeConfirmationImplemented: boolean;
  settlementEnabled: boolean;
  reason?: string;
}

function isEvmNetwork(network: TreasuryNetwork): boolean {
  return ["ethereum", "bsc", "polygon", "arbitrum"].includes(network);
}

export function validateTreasuryAddress(network: TreasuryNetwork, address: string): string {
  const value = address.trim();
  if (!value) throw new Error(`${network} treasury address is required`);

  if (isEvmNetwork(network)) {
    try {
      return getAddress(value);
    } catch {
      throw new Error(`Invalid ${network} EVM treasury address`);
    }
  }

  if (network === "solana") {
    try {
      return new PublicKey(value).toBase58();
    } catch {
      throw new Error("Invalid Solana treasury address");
    }
  }

  try {
    bitcoin.address.toOutputScript(value, bitcoin.networks.bitcoin);
    return value;
  } catch {
    throw new Error("Invalid Bitcoin treasury address");
  }
}

function unavailable(
  network: TreasuryNetwork,
  family: TreasuryFamily,
  reason: string,
  configured = false,
): TreasuryConfiguration {
  return {
    network,
    family,
    address: null,
    configured,
    validated: false,
    feeConstructionImplemented: false,
    feeBroadcastImplemented: false,
    feeConfirmationImplemented: false,
    settlementEnabled: false,
    reason,
  };
}

function evmConfiguration(network: TreasuryNetwork): TreasuryConfiguration {
  if (!ENV.paxiTreasuryAddress) {
    return unavailable(
      network,
      "evm",
      "No EVM treasury is configured; add PAXI_TREASURY_ADDRESS on the server.",
    );
  }

  try {
    const address = validateTreasuryAddress(network, ENV.paxiTreasuryAddress);
    const settlementEnabled = network === "ethereum" || network === "bsc";
    return {
      network,
      family: "evm",
      address,
      configured: true,
      validated: true,
      feeConstructionImplemented: settlementEnabled,
      feeBroadcastImplemented: settlementEnabled,
      feeConfirmationImplemented: settlementEnabled,
      settlementEnabled,
      ...(settlementEnabled
        ? {}
        : { reason: "Treasury validation is available, but PAXI fee settlement is unavailable on this network." }),
    };
  } catch {
    return unavailable(network, "evm", "The configured EVM treasury address is invalid.", true);
  }
}

export function getTreasuryConfiguration(network: TreasuryNetwork): TreasuryConfiguration {
  if (isEvmNetwork(network)) return evmConfiguration(network);

  if (network === "solana") {
    if (!ENV.paxiSolanaTreasuryAddress) {
      return unavailable(network, "solana", "No Solana treasury is configured; PAXI fee settlement is unavailable.");
    }
    try {
      return {
        network,
        family: "solana",
        address: validateTreasuryAddress(network, ENV.paxiSolanaTreasuryAddress),
        configured: true,
        validated: true,
        feeConstructionImplemented: false,
        feeBroadcastImplemented: false,
        feeConfirmationImplemented: false,
        settlementEnabled: false,
        reason: "Solana treasury is validated, but PAXI fee settlement is unavailable.",
      };
    } catch {
      return unavailable(network, "solana", "The configured Solana treasury address is invalid.", true);
    }
  }

  if (!ENV.paxiBitcoinTreasuryAddress) {
    return unavailable(network, "bitcoin", "No Bitcoin treasury is configured; PAXI fee settlement is unavailable.");
  }
  try {
    return {
      network,
      family: "bitcoin",
      address: validateTreasuryAddress(network, ENV.paxiBitcoinTreasuryAddress),
      configured: true,
      validated: true,
      feeConstructionImplemented: false,
      feeBroadcastImplemented: false,
      feeConfirmationImplemented: false,
      settlementEnabled: false,
      reason: "Bitcoin treasury is validated, but PAXI fee settlement is unavailable.",
    };
  } catch {
    return unavailable(network, "bitcoin", "The configured Bitcoin treasury address is invalid.", true);
  }
}

export function listTreasuryConfigurations(): TreasuryConfiguration[] {
  return (["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"] as TreasuryNetwork[]).map(getTreasuryConfiguration);
}
