import { and, eq, gt } from "drizzle-orm";
import { ethers } from "ethers";
import { randomUUID } from "node:crypto";
import { walletLinks, walletLinkChallenges } from "../../drizzle/schema";
import { getDb } from "../db";
import * as db from "../db";

const CHALLENGE_TTL_MS = 10 * 60 * 1000;
const MAX_LINKS_PER_USER = 10;

function normalize(address: string): string {
  return ethers.getAddress(address);
}

/**
 * Deterministic account id for a wallet that isn't attached to a Manus
 * login. This wallet is non-custodial and every send is already gated by an
 * ECDSA signature over a fresh server nonce (see `verifyWalletLink` below) -
 * that signature IS proof of identity, so a wallet address maps 1:1 to its
 * own PAXI account instead of requiring a separate OAuth login on top of it.
 */
export function walletOpenId(address: string): string {
  return `wallet:${normalize(address)}`;
}

/** Ensures a `users` row exists for a wallet-native identity, so FK-constrained
 * tables (walletLinks, walletLinkChallenges, sendFeeQuotes, ...) can reference it. */
async function ensureWalletUser(openId: string, _address: string): Promise<void> {
  await db.upsertUser({ openId, name: null, email: null, loginMethod: "wallet", lastSignedIn: new Date() });
}

function buildMessage(nonce: string, address: string, expiresAt: Date): string {
  return [
    "PAXI Wallet ownership verification",
    "",
    "Sign this message to link your wallet to your authenticated PAXI account.",
    "No blockchain transaction will be sent and no network fee is charged.",
    "",
    `Wallet: ${address}`,
    `Nonce: ${nonce}`,
    `Expires: ${expiresAt.toISOString()}`,
  ].join("\n");
}

/**
 * `userOpenId` is the caller's existing Manus session, if any. When absent
 * (the common case for this non-custodial wallet), the wallet address's own
 * deterministic identity is used instead so the flow works with no separate
 * login step.
 */
export async function createWalletLinkChallenge(userOpenId: string | null, walletAddress: string) {
  const address = normalize(walletAddress);
  const resolvedOpenId = userOpenId || walletOpenId(address);
  if (!userOpenId) await ensureWalletUser(resolvedOpenId, address);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const expiresAt = new Date(Date.now() + CHALLENGE_TTL_MS);
  const nonce = randomUUID();
  const message = buildMessage(nonce, address, expiresAt);
  await db.insert(walletLinkChallenges).values({
    id: randomUUID(), userOpenId: resolvedOpenId, walletAddress: address, nonce, message, expiresAt,
  });
  return { message, expiresAt: expiresAt.toISOString() };
}

export async function verifyWalletLink(userOpenId: string | null, walletAddress: string, message: string, signature: string) {
  const address = normalize(walletAddress);
  const resolvedOpenId = userOpenId || walletOpenId(address);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [challenge] = await db.select().from(walletLinkChallenges)
    .where(and(eq(walletLinkChallenges.userOpenId, resolvedOpenId), eq(walletLinkChallenges.walletAddress, address), eq(walletLinkChallenges.message, message), gt(walletLinkChallenges.expiresAt, new Date())))
    .limit(1);
  if (!challenge) throw new Error("Wallet-link request is invalid or expired. Please try again.");
  let recovered: string;
  try { recovered = ethers.getAddress(ethers.verifyMessage(message, signature)); }
  catch { throw new Error("Wallet signature could not be verified."); }
  if (recovered !== address) throw new Error("Wallet signature does not prove ownership of this address.");
  const [existing] = await db.select().from(walletLinks).where(and(eq(walletLinks.userOpenId, resolvedOpenId), eq(walletLinks.walletAddress, address))).limit(1);
  if (!existing) {
    const links = await db.select().from(walletLinks).where(eq(walletLinks.userOpenId, resolvedOpenId));
    if (links.length >= MAX_LINKS_PER_USER) throw new Error("Maximum number of linked wallets reached.");
    await db.insert(walletLinks).values({ id: randomUUID(), userOpenId: resolvedOpenId, walletAddress: address, chainType: "evm", verifiedAt: new Date() });
  }
  await db.delete(walletLinkChallenges).where(eq(walletLinkChallenges.id, challenge.id));
  return { linked: true, walletAddress: address, openId: resolvedOpenId, isNewSession: !userOpenId };
}

export async function requireLinkedWallet(userOpenId: string, walletAddress: string): Promise<string> {
  const address = normalize(walletAddress);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [row] = await db.select().from(walletLinks).where(and(eq(walletLinks.userOpenId, userOpenId), eq(walletLinks.walletAddress, address))).limit(1);
  if (!row) throw new Error("This wallet is not linked to your PAXI account. Please verify wallet ownership first.");
  return row.walletAddress;
}
