import { and, eq, gt } from "drizzle-orm";
import { ethers } from "ethers";
import { randomUUID } from "node:crypto";
import { walletLinks, walletLinkChallenges } from "../../drizzle/schema";
import { getDb } from "../db";

const CHALLENGE_TTL_MS = 10 * 60 * 1000;
const MAX_LINKS_PER_USER = 10;

function normalize(address: string): string {
  return ethers.getAddress(address);
}

function buildMessage(nonce: string, address: string, expiresAt: Date): string {
  return [
    "PAXI Wallet ownership verification",
    "",
    "Sign this message to link your wallet to your authenticated PAXI account.",
    "No blockchain transaction will be sent and no network fee is charged.",
    "",
    `Wallet: ${address}`,
    `Nonce: ${nonce}`,
    `Expires: ${expiresAt.toISOString()}`,
  ].join("\n");
}

export async function createWalletLinkChallenge(userOpenId: string, walletAddress: string) {
  if (!userOpenId) throw new Error("Authentication required");
  const address = normalize(walletAddress);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const expiresAt = new Date(Date.now() + CHALLENGE_TTL_MS);
  const nonce = randomUUID();
  const message = buildMessage(nonce, address, expiresAt);
  await db.insert(walletLinkChallenges).values({
    id: randomUUID(), userOpenId, walletAddress: address, nonce, message, expiresAt,
  });
  return { message, expiresAt: expiresAt.toISOString() };
}

export async function verifyWalletLink(userOpenId: string, walletAddress: string, message: string, signature: string) {
  const address = normalize(walletAddress);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [challenge] = await db.select().from(walletLinkChallenges)
    .where(and(eq(walletLinkChallenges.userOpenId, userOpenId), eq(walletLinkChallenges.walletAddress, address), eq(walletLinkChallenges.message, message), gt(walletLinkChallenges.expiresAt, new Date())))
    .limit(1);
  if (!challenge) throw new Error("Wallet-link request is invalid or expired. Please try again.");
  let recovered: string;
  try { recovered = ethers.getAddress(ethers.verifyMessage(message, signature)); }
  catch { throw new Error("Wallet signature could not be verified."); }
  if (recovered !== address) throw new Error("Wallet signature does not prove ownership of this address.");
  const [existing] = await db.select().from(walletLinks).where(and(eq(walletLinks.userOpenId, userOpenId), eq(walletLinks.walletAddress, address))).limit(1);
  if (!existing) {
    const links = await db.select().from(walletLinks).where(eq(walletLinks.userOpenId, userOpenId));
    if (links.length >= MAX_LINKS_PER_USER) throw new Error("Maximum number of linked wallets reached.");
    await db.insert(walletLinks).values({ id: randomUUID(), userOpenId, walletAddress: address, chainType: "evm", verifiedAt: new Date() });
  }
  await db.delete(walletLinkChallenges).where(eq(walletLinkChallenges.id, challenge.id));
  return { linked: true, walletAddress: address };
}

export async function requireLinkedWallet(userOpenId: string, walletAddress: string): Promise<string> {
  const address = normalize(walletAddress);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [row] = await db.select().from(walletLinks).where(and(eq(walletLinks.userOpenId, userOpenId), eq(walletLinks.walletAddress, address))).limit(1);
  if (!row) throw new Error("This wallet is not linked to your PAXI account. Please verify wallet ownership first.");
  return row.walletAddress;
}
