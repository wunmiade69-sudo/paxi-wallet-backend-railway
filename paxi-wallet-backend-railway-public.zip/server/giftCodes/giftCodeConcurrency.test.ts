import { describe, expect, it } from "vitest";
import { assertGiftCodeReservationUpdate } from "./giftCodeRepository";

describe("Gift Code reservation concurrency guard", () => {
  it("accepts exactly one affected row and rejects a concurrent zero-row update", () => {
    expect(() => assertGiftCodeReservationUpdate(1)).not.toThrow();
    expect(() => assertGiftCodeReservationUpdate(0)).toThrow(
      "Gift code was redeemed concurrently; try again"
    );
  });
});
