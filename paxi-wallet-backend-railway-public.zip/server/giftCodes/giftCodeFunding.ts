import { getAssociatedTokenAddress, getAccount, getMint } from "@solana/spl-token";
import { Connection, Keypair, PublicKey } from "@solana/web3.js";
import { ethers } from "ethers";
import { ENV } from "../_core/env";
import { getConfiguredPayoutSignerAddress, decimalToUnits } from "../campaigns/rewardEscrow";

const EVM_ERC20_ABI = [
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function balanceOf(address) view returns (uint256)",
];

export interface GiftCodeFundingInput {
  network: string;
  tokenAddress: string;
  tokenSymbol: string;
  decimals: number;
  rewardAmount: string;
  maxRedemptions: number;
}

export interface GiftCodeFundingResult {
  rewardWalletAddress: string;
  tokenDecimals: number;
  availableUnits: bigint;
  requiredUnits: bigint;
}

export function requiredGiftCodeUnits(rewardAmount: string, decimals: number, maxRedemptions: number): bigint {
  if (!Number.isSafeInteger(maxRedemptions) || maxRedemptions <= 0) throw new Error("Invalid maximum redemptions");
  return decimalToUnits(rewardAmount, decimals) * BigInt(maxRedemptions);
}

export function assertSufficientRewardBalance(availableUnits: bigint, requiredUnits: bigint): void {
  if (availableUnits < requiredUnits) throw new Error("Insufficient reward balance");
}

function evmProvider(network: string): ethers.JsonRpcProvider {
  const rpcUrl = network === "bsc"
    ? ENV.paxiPayoutRpcUrl
    : ENV.ethereumPayoutRpcUrl || "https://ethereum-rpc.publicnode.com";
  const request = new ethers.FetchRequest(rpcUrl);
  request.timeout = 8_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

function ethereumRewardWallet(): string {
  if (!ENV.ethereumPayoutPrivateKey) throw new Error("Ethereum Gift Code payout signer is not configured");
  return new ethers.Wallet(ENV.ethereumPayoutPrivateKey).address;
}

function solanaSigner(): Keypair {
  if (!ENV.solanaPayoutPrivateKey) throw new Error("Solana Gift Code payout signer is not configured");
  let bytes: number[];
  try { bytes = JSON.parse(ENV.solanaPayoutPrivateKey) as number[]; } catch { throw new Error("SOLANA_PAYOUT_PRIVATE_KEY must be a JSON secret-key array"); }
  if (!Array.isArray(bytes) || (bytes.length !== 64 && bytes.length !== 32) || bytes.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255)) throw new Error("Invalid Solana payout secret key");
  return bytes.length === 64 ? Keypair.fromSecretKey(Uint8Array.from(bytes)) : Keypair.fromSeed(Uint8Array.from(bytes));
}

export async function assertGiftCodeRewardFunding(input: GiftCodeFundingInput): Promise<GiftCodeFundingResult> {
  const network = input.network.toLowerCase();
  if (network === "ton") throw new Error("Coming soon");
  if (!["bsc", "ethereum", "solana"].includes(network)) throw new Error(`Gift Code fulfillment is not enabled for ${input.network} yet`);

  if (network === "solana") {
    let mint: PublicKey;
    try { mint = new PublicKey(input.tokenAddress); } catch { throw new Error("Gift Code token contract is invalid"); }
    const payer = solanaSigner();
    const connection = new Connection(ENV.solanaPayoutRpcUrl, "confirmed");
    const mintInfo = await getMint(connection, mint);
    if (mintInfo.decimals !== input.decimals) throw new Error("Gift Code token decimals do not match the asset registry");
    const requiredUnits = requiredGiftCodeUnits(input.rewardAmount, mintInfo.decimals, input.maxRedemptions);
    const associatedAddress = await getAssociatedTokenAddress(mint, payer.publicKey);
    let availableUnits = 0n;
    try { availableUnits = (await getAccount(connection, associatedAddress)).amount; } catch { availableUnits = 0n; }
    assertSufficientRewardBalance(availableUnits, requiredUnits);
    return { rewardWalletAddress: payer.publicKey.toBase58(), tokenDecimals: mintInfo.decimals, availableUnits, requiredUnits };
  }

  if (!ethers.isAddress(input.tokenAddress)) throw new Error("Gift Code token contract is invalid");
  const provider = evmProvider(network);
  const rewardWalletAddress = network === "bsc" ? getConfiguredPayoutSignerAddress() : ethereumRewardWallet();
  const tokenAddress = ethers.getAddress(input.tokenAddress);
  const deployedCode = await provider.getCode(tokenAddress);
  if (deployedCode === "0x") throw new Error("Gift Code token contract is not deployed");
  const token = new ethers.Contract(tokenAddress, EVM_ERC20_ABI, provider);
  const [onChainDecimals, onChainSymbol, availableUnits] = await Promise.all([
    token.decimals().then(Number),
    token.symbol().then(String),
    token.balanceOf(rewardWalletAddress).then((value: bigint) => BigInt(value)),
  ]);
  if (!Number.isInteger(onChainDecimals) || onChainDecimals < 0 || onChainDecimals > 36 || onChainDecimals !== input.decimals) {
    throw new Error("Gift Code token decimals do not match the asset registry");
  }
  if (!onChainSymbol.trim() || onChainSymbol.trim().toUpperCase() !== input.tokenSymbol.trim().toUpperCase()) {
    throw new Error("Gift Code token contract does not match the asset registry");
  }
  const requiredUnits = requiredGiftCodeUnits(input.rewardAmount, onChainDecimals, input.maxRedemptions);
  assertSufficientRewardBalance(availableUnits, requiredUnits);
  return { rewardWalletAddress, tokenDecimals: onChainDecimals, availableUnits, requiredUnits };
}
