import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  assertGiftCodeRedeemable,
  assertNoDuplicateRedemption,
} from "./giftCodePolicy";
import {
  assertGiftCodeRewardFunding,
  assertSufficientRewardBalance,
  requiredGiftCodeUnits,
} from "./giftCodeFunding";

const mocks = vi.hoisted(() => ({
  sendCampaignReward: vi.fn(),
  inspectCampaignPayout: vi.fn(),
  transferGiftCodeReward: vi.fn(),
  verifyGiftCodeReward: vi.fn(),
  updateFulfillment: vi.fn(),
  getAssetById: vi.fn(),
  recordAdminAuditEvent: vi.fn(),
}));

vi.mock("../campaigns/rewardEscrow", () => ({
  decimalToUnits: (amount: string, decimals: number) => {
    const [whole, fraction = ""] = amount.split(".");
    return BigInt(`${whole}${fraction.padEnd(decimals, "0")}`);
  },
  sendCampaignReward: mocks.sendCampaignReward,
  inspectCampaignPayout: mocks.inspectCampaignPayout,
}));
vi.mock("../rewards/rewardTransferService", () => ({
  transferGiftCodeReward: mocks.transferGiftCodeReward,
  verifyGiftCodeReward: mocks.verifyGiftCodeReward,
}));
vi.mock("./giftCodeRepository", () => ({
  getAssetById: mocks.getAssetById,
  updateFulfillment: mocks.updateFulfillment,
}));
vi.mock("../adminAudit", () => ({
  recordAdminAuditEvent: mocks.recordAdminAuditEvent,
}));

beforeEach(() => vi.clearAllMocks());

describe("Gift Code lifecycle policy", () => {
  it("rejects expired and disabled codes", () => {
    expect(() => assertGiftCodeRedeemable("active", new Date(1), 2)).toThrow(
      "Gift code has expired"
    );
    expect(() => assertGiftCodeRedeemable("cancelled", null)).toThrow(
      "Gift code is disabled"
    );
  });

  it("blocks duplicate pending redemption but permits confirmed idempotent retry", () => {
    const pending = {
      rewardLedgerId: 10,
      fulfillmentStatus: "pending",
      transactionHash: null,
    } as never;
    expect(() => assertNoDuplicateRedemption(pending)).toThrow(
      "already redeemed"
    );
    const confirmed = {
      rewardLedgerId: 10,
      fulfillmentStatus: "confirmed",
      transactionHash: "0xabc",
    } as never;
    expect(() => assertNoDuplicateRedemption(confirmed)).not.toThrow();
  });

  it("rejects an invalid recipient wallet through the existing network validator", async () => {
    const { validateGiftRecipient } =
      await import("../rewards/giftCodeSecurity");
    expect(() => validateGiftRecipient("bsc", "not-an-address")).toThrow();
  });
});

describe("Gift Code funding validation", () => {
  it("keeps TON Jetton fulfillment explicitly disabled", async () => {
    await expect(
      assertGiftCodeRewardFunding({
        network: "ton",
        tokenAddress: "EQ-test",
        tokenSymbol: "PAXI",
        decimals: 9,
        rewardAmount: "1",
        maxRedemptions: 1,
      })
    ).rejects.toThrow("Coming soon");
  });

  it("requires enough reward balance for every redemption", () => {
    expect(requiredGiftCodeUnits("2.5", 6, 4)).toBe(10_000_000n);
    expect(() =>
      assertSufficientRewardBalance(9_999_999n, 10_000_000n)
    ).toThrow("Insufficient reward balance");
    expect(() =>
      assertSufficientRewardBalance(10_000_000n, 10_000_000n)
    ).not.toThrow();
  });
});

describe("BSC Gift Code fulfillment", () => {
  it("broadcasts the configured BSC token transfer with exact base units", async () => {
    mocks.sendCampaignReward.mockResolvedValue({
      transactionHash: "0x123",
      senderAddress: "0xsender",
      nonce: 4,
    });
    const { bscAdapter } = await import("../blockchain/adapters/bscAdapter");
    const result = await bscAdapter.transfer({
      network: "bsc",
      tokenAddress: "0x0000000000000000000000000000000000000001",
      recipientAddress: "0x0000000000000000000000000000000000000002",
      amount: "1.25",
      decimals: 6,
    });
    expect(result).toMatchObject({
      state: "broadcast",
      transactionHash: "0x123",
      senderAddress: "0xsender",
    });
    expect(mocks.sendCampaignReward).toHaveBeenCalledWith({
      network: "bsc",
      tokenContractAddress: "0x0000000000000000000000000000000000000001",
      recipientAddress: "0x0000000000000000000000000000000000000002",
      amountUnits: "1250000",
    });
  });
});

describe("Gift Code transfer failure and recovery", () => {
  const giftCode = {
    id: 3,
    assetId: null,
    assetNetwork: "bsc",
    assetContractAddress: "0x0000000000000000000000000000000000000001",
    rewardAmount: "1",
    assetSymbol: "PAXI",
  } as never;
  const recipientWalletAddress = "0x0000000000000000000000000000000000000002";

  it("marks a reverted transfer as failed and never credits it", async () => {
    mocks.transferGiftCodeReward.mockResolvedValue({
      state: "broadcast",
      transactionHash: "0xfailed",
    });
    mocks.verifyGiftCodeReward.mockResolvedValue({
      state: "broadcast",
      transactionHash: "0xfailed",
      reason: "transaction reverted",
    });
    mocks.updateFulfillment.mockResolvedValue({ id: 7 });
    const { fulfillGiftCode } = await import("./giftCodeRedeemer");
    await expect(
      fulfillGiftCode({
        redemptionId: 7,
        giftCode,
        recipientWalletAddress,
        actorOpenId: "user-1",
      })
    ).rejects.toThrow("transaction reverted");
    expect(mocks.updateFulfillment).toHaveBeenCalledWith(
      7,
      expect.objectContaining({
        fulfillmentStatus: "failed",
        transactionHash: "0xfailed",
        ledgerStatus: "failed",
      })
    );
  });

  it("recovers an existing transaction hash and confirms it without rebroadcasting", async () => {
    mocks.verifyGiftCodeReward.mockResolvedValue({
      state: "confirmed",
      transactionHash: "0xrecovered",
      senderAddress: "0xsender",
      blockNumber: 22,
    });
    mocks.updateFulfillment.mockResolvedValue({
      id: 8,
      fulfillmentStatus: "confirmed",
    });
    const { fulfillGiftCode } = await import("./giftCodeRedeemer");
    await fulfillGiftCode({
      redemptionId: 8,
      giftCode: { ...giftCode, id: 4 },
      recipientWalletAddress,
      existingTransactionHash: "0xrecovered",
      actorOpenId: "user-2",
    });
    expect(mocks.transferGiftCodeReward).not.toHaveBeenCalled();
    expect(mocks.recordAdminAuditEvent).toHaveBeenCalledWith(
      expect.objectContaining({
        action: "Reward transfer completed",
        details: expect.objectContaining({ recovery: true }),
      })
    );
  });
});
