import type { GiftCodeRedemption } from "../../drizzle/schema";

export function assertGiftCodeRedeemable(status: string, expiresAt: Date | null, now = Date.now()): void {
  if (status !== "active") throw new Error(status === "cancelled" ? "Gift code is disabled" : "Gift code is no longer available");
  if (expiresAt && expiresAt.getTime() <= now) throw new Error("Gift code has expired");
}

export function assertNoDuplicateRedemption(existing: GiftCodeRedemption | null): void {
  if (!existing?.rewardLedgerId) return;
  if (existing.fulfillmentStatus === "confirmed" || existing.fulfillmentStatus === "not_required") return;
  if (existing.fulfillmentStatus === "broadcast" && existing.transactionHash) return;
  throw new Error("Gift code already redeemed by this user");
}
