import { getAssetById, updateFulfillment } from "./giftCodeRepository";
import { transferGiftCodeReward, verifyGiftCodeReward } from "../rewards/rewardTransferService";
import { recordAdminAuditEvent } from "../adminAudit";
import type { GiftCode } from "../../drizzle/schema";

export interface FulfillGiftCodeInput {
  redemptionId: number;
  giftCode: GiftCode;
  recipientWalletAddress: string;
  existingTransactionHash?: string | null;
  actorOpenId: string;
}

async function assetDecimals(giftCode: GiftCode): Promise<number> {
  if (!giftCode.assetId) return 18;
  const asset = await getAssetById(giftCode.assetId);
  if (!asset) throw new Error("Gift Code asset is no longer present in the asset registry");
  if (asset.chainId !== giftCode.assetNetwork || asset.identifier.toLowerCase() !== (giftCode.assetContractAddress ?? "").toLowerCase()) throw new Error("Gift Code asset binding does not match the asset registry");
  if (!Number.isInteger(asset.decimals) || asset.decimals < 0 || asset.decimals > 36) throw new Error("Gift Code asset decimals are invalid");
  return asset.decimals;
}

export async function fulfillGiftCode(input: FulfillGiftCodeInput) {
  const decimals = await assetDecimals(input.giftCode);
  const request = {
    network: input.giftCode.assetNetwork,
    tokenAddress: input.giftCode.assetContractAddress ?? "",
    recipientAddress: input.recipientWalletAddress,
    amount: input.giftCode.rewardAmount,
    decimals,
  };

  if (!request.tokenAddress) throw new Error("Gift Code fulfillment requires a token contract address");

  let transactionHash = input.existingTransactionHash ?? null;
  if (transactionHash) {
    const recovered = await verifyGiftCodeReward({ ...request, transactionHash });
    if (recovered.state === "confirmed") {
      const confirmed = await updateFulfillment(input.redemptionId, { fulfillmentStatus: "confirmed", transactionHash, fulfillmentError: null, redemptionStatus: "credited", ledgerStatus: "distributed", fulfilledAt: new Date() });
      await recordAdminAuditEvent({ actorOpenId: input.actorOpenId, action: "Reward transfer completed", resourceType: "giftCodeRedemption", resourceId: input.redemptionId, details: { giftCodeId: input.giftCode.id, transactionHash, assetNetwork: input.giftCode.assetNetwork, rewardAmount: input.giftCode.rewardAmount, recovery: true } });
      return confirmed;
    }
    if (recovered.state === "pending") {
      return updateFulfillment(input.redemptionId, { fulfillmentStatus: "broadcast", transactionHash, fulfillmentError: recovered.reason ?? null });
    }
    await updateFulfillment(input.redemptionId, { fulfillmentStatus: "failed", transactionHash, fulfillmentError: recovered.reason ?? "On-chain verification failed", redemptionStatus: "rejected", ledgerStatus: "failed" });
    throw new Error(recovered.reason ?? "Gift Code transaction verification failed");
  }

  const broadcast = await transferGiftCodeReward(request);
  transactionHash = broadcast.transactionHash;
  await updateFulfillment(input.redemptionId, { fulfillmentStatus: "broadcast", transactionHash, fulfillmentError: null });
  if (broadcast.state === "confirmed") {
    const confirmed = await updateFulfillment(input.redemptionId, { fulfillmentStatus: "confirmed", transactionHash, fulfillmentError: null, redemptionStatus: "credited", ledgerStatus: "distributed", fulfilledAt: new Date() });
    await recordAdminAuditEvent({ actorOpenId: input.actorOpenId, action: "Reward transfer completed", resourceType: "giftCodeRedemption", resourceId: input.redemptionId, details: { giftCodeId: input.giftCode.id, transactionHash, assetNetwork: input.giftCode.assetNetwork, rewardAmount: input.giftCode.rewardAmount, recovery: false } });
    return confirmed;
  }

  const verified = await verifyGiftCodeReward({ ...request, transactionHash });
  if (verified.state === "confirmed") {
    const confirmed = await updateFulfillment(input.redemptionId, { fulfillmentStatus: "confirmed", transactionHash, fulfillmentError: null, redemptionStatus: "credited", ledgerStatus: "distributed", fulfilledAt: new Date() });
    await recordAdminAuditEvent({ actorOpenId: input.actorOpenId, action: "Reward transfer completed", resourceType: "giftCodeRedemption", resourceId: input.redemptionId, details: { giftCodeId: input.giftCode.id, transactionHash, assetNetwork: input.giftCode.assetNetwork, rewardAmount: input.giftCode.rewardAmount, recovery: false } });
    return confirmed;
  }
  if (verified.state === "pending") {
    return updateFulfillment(input.redemptionId, { fulfillmentStatus: "broadcast", transactionHash, fulfillmentError: verified.reason ?? null });
  }
  await updateFulfillment(input.redemptionId, { fulfillmentStatus: "failed", transactionHash, fulfillmentError: verified.reason ?? "On-chain verification failed", redemptionStatus: "rejected", ledgerStatus: "failed" });
  throw new Error(verified.reason ?? "Gift Code transaction verification failed");
}
