import { and, desc, eq, gte, lt, sql } from "drizzle-orm";
import {
  assets,
  giftCodeRedemptions,
  giftCodes,
  rewardLedger,
  type GiftCode,
  type GiftCodeRedemption,
  type RewardLedgerEntry,
} from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import { normalizeIdentifier } from "../assetRegistry";

function insertId(result: unknown): number {
  const id = Number((result as { insertId?: number | string }).insertId);
  if (!Number.isSafeInteger(id) || id <= 0)
    throw new Error("Database insert did not return an id");
  return id;
}

export async function findGiftCodeByHash(
  codeHash: string
): Promise<GiftCode | null> {
  const db = await getReadDb();
  if (!db) throw new Error("Database not available");
  const [row] = await db
    .select()
    .from(giftCodes)
    .where(eq(giftCodes.codeHash, codeHash))
    .limit(1);
  return row ?? null;
}

export async function findRedemption(
  giftCodeId: number,
  userOpenId: string
): Promise<GiftCodeRedemption | null> {
  const db = await getReadDb();
  if (!db) throw new Error("Database not available");
  const [row] = await db
    .select()
    .from(giftCodeRedemptions)
    .where(
      and(
        eq(giftCodeRedemptions.giftCodeId, giftCodeId),
        eq(giftCodeRedemptions.userOpenId, userOpenId)
      )
    )
    .limit(1);
  return row ?? null;
}

export interface ReserveGiftCodeInput {
  giftCodeId: number;
  userOpenId: string;
  recipientWalletAddress: string | null;
  fulfillmentStatus: "not_required" | "pending";
  assetSymbol: string;
  assetNetwork: string;
  assetContractAddress: string | null;
  rewardAmount: string;
  codeHint: string;
}

export interface ReservedGiftCode {
  redemption: GiftCodeRedemption;
  ledger: RewardLedgerEntry;
}

export function assertGiftCodeReservationUpdate(affectedRows: number): void {
  if (affectedRows !== 1)
    throw new Error("Gift code was redeemed concurrently; try again");
}

/** Atomically claims one code slot and creates the pending reward ledger reservation. */
export async function reserveGiftCode(
  input: ReserveGiftCodeInput
): Promise<ReservedGiftCode> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.transaction(async tx => {
    const [code] = await tx
      .select()
      .from(giftCodes)
      .where(eq(giftCodes.id, input.giftCodeId))
      .limit(1);
    if (!code) throw new Error("Gift code not found");
    if (code.status !== "active" || code.redemptionCount >= code.maxRedemptions)
      throw new Error("Gift code is no longer available");
    if (code.expiresAt && code.expiresAt.getTime() <= Date.now())
      throw new Error("Gift code has expired");

    const [existing] = await tx
      .select()
      .from(giftCodeRedemptions)
      .where(
        and(
          eq(giftCodeRedemptions.giftCodeId, input.giftCodeId),
          eq(giftCodeRedemptions.userOpenId, input.userOpenId)
        )
      )
      .limit(1);
    if (existing?.rewardLedgerId) {
      const [ledger] = await tx
        .select()
        .from(rewardLedger)
        .where(eq(rewardLedger.id, existing.rewardLedgerId))
        .limit(1);
      if (ledger) return { redemption: existing, ledger };
    }
    if (existing) throw new Error("Gift code already redeemed by this user");

    const updated = await tx
      .update(giftCodes)
      .set({
        redemptionCount: sql`${giftCodes.redemptionCount} + 1`,
        status:
          code.redemptionCount + 1 >= code.maxRedemptions
            ? "exhausted"
            : "active",
      })
      .where(
        and(
          eq(giftCodes.id, code.id),
          eq(giftCodes.status, "active"),
          lt(giftCodes.redemptionCount, giftCodes.maxRedemptions)
        )
      );
    assertGiftCodeReservationUpdate(
      Number((updated as { affectedRows?: number }).affectedRows ?? 0)
    );

    const redemptionResult = await tx.insert(giftCodeRedemptions).values({
      giftCodeId: input.giftCodeId,
      userOpenId: input.userOpenId,
      recipientWalletAddress: input.recipientWalletAddress,
      fulfillmentStatus: input.fulfillmentStatus,
      status: "pending",
    });
    const redemptionId = insertId(redemptionResult);
    const idempotencyKey = `gift-code:${input.giftCodeId}:user:${input.userOpenId}`;
    const ledgerResult = await tx.insert(rewardLedger).values({
      userOpenId: input.userOpenId,
      sourceType: "gift_code",
      sourceId: String(input.giftCodeId),
      assetSymbol: input.assetSymbol,
      assetNetwork: input.assetNetwork,
      assetContractAddress: input.assetContractAddress,
      amount: input.rewardAmount,
      status: "pending",
      idempotencyKey,
      metadata: { giftCodeHint: input.codeHint, redemptionId },
    });
    const ledgerId = insertId(ledgerResult);
    await tx
      .update(giftCodeRedemptions)
      .set({ rewardLedgerId: ledgerId })
      .where(eq(giftCodeRedemptions.id, redemptionId));
    const [redemption] = await tx
      .select()
      .from(giftCodeRedemptions)
      .where(eq(giftCodeRedemptions.id, redemptionId))
      .limit(1);
    const [ledger] = await tx
      .select()
      .from(rewardLedger)
      .where(eq(rewardLedger.id, ledgerId))
      .limit(1);
    if (!redemption || !ledger)
      throw new Error("Gift Code reservation could not be reloaded");
    return { redemption, ledger };
  });
}

export async function updateFulfillment(
  redemptionId: number,
  update: {
    fulfillmentStatus:
      "not_required" | "pending" | "broadcast" | "confirmed" | "failed";
    transactionHash?: string | null;
    fulfillmentError?: string | null;
    fulfilledAt?: Date | null;
    redemptionStatus?: "pending" | "credited" | "rejected" | "reversed";
    ledgerStatus?: "pending" | "approved" | "distributed" | "failed";
  }
): Promise<GiftCodeRedemption> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.transaction(async tx => {
    const [current] = await tx
      .select()
      .from(giftCodeRedemptions)
      .where(eq(giftCodeRedemptions.id, redemptionId))
      .limit(1);
    if (!current) throw new Error("Gift Code redemption not found");
    await tx
      .update(giftCodeRedemptions)
      .set({
        fulfillmentStatus: update.fulfillmentStatus,
        transactionHash: update.transactionHash ?? current.transactionHash,
        fulfillmentError: update.fulfillmentError ?? null,
        fulfilledAt:
          update.fulfilledAt ??
          (update.fulfillmentStatus === "confirmed"
            ? new Date()
            : current.fulfilledAt),
        ...(update.redemptionStatus ? { status: update.redemptionStatus } : {}),
      })
      .where(eq(giftCodeRedemptions.id, redemptionId));
    if (current.rewardLedgerId && update.ledgerStatus) {
      await tx
        .update(rewardLedger)
        .set({
          status: update.ledgerStatus,
          ...(update.ledgerStatus === "distributed"
            ? { distributedAt: new Date() }
            : {}),
        })
        .where(eq(rewardLedger.id, current.rewardLedgerId));
    }
    const [updated] = await tx
      .select()
      .from(giftCodeRedemptions)
      .where(eq(giftCodeRedemptions.id, redemptionId))
      .limit(1);
    if (!updated)
      throw new Error("Gift Code redemption update could not be reloaded");
    return updated;
  });
}

export async function listGiftCodes(filters: {
  status?: GiftCode["status"];
  creatorOpenId?: string;
  limit: number;
  offset: number;
}): Promise<GiftCode[]> {
  const db = await getReadDb();
  if (!db) return [];
  const predicates = [];
  if (filters.status) predicates.push(eq(giftCodes.status, filters.status));
  if (filters.creatorOpenId)
    predicates.push(eq(giftCodes.createdByOpenId, filters.creatorOpenId));
  return db
    .select()
    .from(giftCodes)
    .where(predicates.length ? and(...predicates) : undefined)
    .orderBy(desc(giftCodes.createdAt))
    .limit(filters.limit)
    .offset(filters.offset);
}

export async function listRedemptions(filters: {
  giftCodeId?: number;
  userOpenId?: string;
  limit: number;
  offset: number;
}): Promise<GiftCodeRedemption[]> {
  const db = await getReadDb();
  if (!db) return [];
  const predicates = [];
  if (filters.giftCodeId)
    predicates.push(eq(giftCodeRedemptions.giftCodeId, filters.giftCodeId));
  if (filters.userOpenId)
    predicates.push(eq(giftCodeRedemptions.userOpenId, filters.userOpenId));
  return db
    .select()
    .from(giftCodeRedemptions)
    .where(predicates.length ? and(...predicates) : undefined)
    .orderBy(desc(giftCodeRedemptions.createdAt))
    .limit(filters.limit)
    .offset(filters.offset);
}

export async function disableGiftCode(
  giftCodeId: number
): Promise<GiftCode | null> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(giftCodes)
    .set({ status: "cancelled" })
    .where(and(eq(giftCodes.id, giftCodeId), eq(giftCodes.status, "active")));
  const [row] = await db
    .select()
    .from(giftCodes)
    .where(eq(giftCodes.id, giftCodeId))
    .limit(1);
  return row ?? null;
}

export async function giftCodeAnalytics(): Promise<{
  total: number;
  active: number;
  redemptions: number;
  confirmed: number;
  failed: number;
}> {
  const db = await getReadDb();
  if (!db)
    return { total: 0, active: 0, redemptions: 0, confirmed: 0, failed: 0 };
  const [codes] = await db
    .select({
      total: sql<number>`count(*)`,
      active: sql<number>`sum(case when ${giftCodes.status} = 'active' then 1 else 0 end)`,
    })
    .from(giftCodes);
  const [redemptions] = await db
    .select({
      redemptions: sql<number>`count(*)`,
      confirmed: sql<number>`sum(case when ${giftCodeRedemptions.fulfillmentStatus} = 'confirmed' or ${giftCodeRedemptions.fulfillmentStatus} = 'not_required' then 1 else 0 end)`,
      failed: sql<number>`sum(case when ${giftCodeRedemptions.fulfillmentStatus} = 'failed' then 1 else 0 end)`,
    })
    .from(giftCodeRedemptions);
  return {
    total: Number(codes?.total ?? 0),
    active: Number(codes?.active ?? 0),
    redemptions: Number(redemptions?.redemptions ?? 0),
    confirmed: Number(redemptions?.confirmed ?? 0),
    failed: Number(redemptions?.failed ?? 0),
  };
}

export async function findAssetByIdentity(chainId: string, identifier: string) {
  const db = await getReadDb();
  if (!db) throw new Error("Database not available");
  const normalized = normalizeIdentifier(chainId, identifier);
  const [asset] = await db
    .select()
    .from(assets)
    .where(and(eq(assets.chainId, chainId), eq(assets.identifier, normalized)))
    .limit(1);
  return asset ?? null;
}

export async function getAssetById(assetId: number) {
  const db = await getReadDb();
  if (!db) throw new Error("Database not available");
  const [asset] = await db
    .select()
    .from(assets)
    .where(eq(assets.id, assetId))
    .limit(1);
  return asset ?? null;
}
