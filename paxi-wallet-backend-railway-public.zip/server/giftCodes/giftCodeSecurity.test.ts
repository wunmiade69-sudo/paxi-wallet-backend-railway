import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";
import { generateGiftCode, hashGiftCode, normalizeGiftCode, parseDecimalUnits, validateGiftRecipient } from "../rewards/giftCodeSecurity";
import { isDirectGiftCodeFulfillmentSupported } from "../rewards/rewardTransferService";

describe("Gift Code security", () => {
  it("canonicalizes and hashes codes with the existing SHA-256 format", () => {
    const code = generateGiftCode();
    expect(code).toMatch(/^GIFT-[0-9A-F]{20}$/);
    expect(normalizeGiftCode(` ${code.toLowerCase()} `)).toBe(code);
    expect(hashGiftCode(code)).toBe(createHash("sha256").update(code).digest("hex"));
  });

  it("rejects malformed codes and unsupported recipient networks", () => {
    expect(() => normalizeGiftCode("bad code")).toThrow();
    expect(validateGiftRecipient("bsc", "0x0000000000000000000000000000000000000001")).toBe("0x0000000000000000000000000000000000000001");
    expect(validateGiftRecipient("solana", "11111111111111111111111111111111")).toBe("11111111111111111111111111111111");
    expect(() => validateGiftRecipient("ton", "UQ-invalid")).toThrow("Unsupported Gift Code network");
  });

  it("enforces token precision before converting to base units", () => {
    expect(parseDecimalUnits("1.25", 6)).toBe(1_250_000n);
    expect(() => parseDecimalUnits("1.0000001", 6)).toThrow("asset precision");
    expect(() => parseDecimalUnits("0", 18)).toThrow();
  });
});

describe("Gift Code fulfillment routing", () => {
  it("supports only audited direct fulfillment chains", () => {
    expect(isDirectGiftCodeFulfillmentSupported("bsc")).toBe(true);
    expect(isDirectGiftCodeFulfillmentSupported("ethereum")).toBe(true);
    expect(isDirectGiftCodeFulfillmentSupported("solana")).toBe(true);
    expect(isDirectGiftCodeFulfillmentSupported("ton")).toBe(false);
    expect(isDirectGiftCodeFulfillmentSupported("bitcoin")).toBe(false);
  });
});
