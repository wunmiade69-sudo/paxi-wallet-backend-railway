import { disableGiftCode as disableGiftCodeRecord, findAssetByIdentity, findGiftCodeByHash, findRedemption, getAssetById, reserveGiftCode, updateFulfillment } from "./giftCodeRepository";
import { fulfillGiftCode } from "./giftCodeRedeemer";
import { assertGiftCodeRewardFunding } from "./giftCodeFunding";
import { assertGiftCodeRedeemable } from "./giftCodePolicy";
import { enforceGiftCodeRateLimit, generateGiftCode, hashGiftCode, normalizeGiftCode, validateGiftRecipient, withGiftCodeLock } from "../rewards/giftCodeSecurity";
import { isDirectGiftCodeFulfillmentSupported } from "../rewards/rewardTransferService";
import { recordAdminAuditEvent } from "../adminAudit";
import type { GiftCode, RewardLedgerEntry } from "../../drizzle/schema";

const MAX_GIFT_REDEMPTIONS = 1_000_000;

export interface CreateGiftCodeInput {
  createdByOpenId: string;
  assetId?: number;
  assetSymbol?: string;
  assetNetwork?: string;
  assetContractAddress?: string | null;
  rewardAmount: string;
  maxRedemptions: number;
  expiresAt?: Date | null;
}

function assertUser(value: string): void {
  if (!value || value.length > 64) throw new Error("Invalid user identifier");
}

async function resolveCreationAsset(input: CreateGiftCodeInput) {
  if (input.assetId) {
    const asset = await getAssetById(input.assetId);
    if (!asset || asset.status !== "active" || asset.verificationStatus !== "verified") throw new Error("Select an active verified asset from the asset registry");
    return { assetId: asset.id, symbol: asset.symbol, network: asset.chainId, contractAddress: asset.identifier === "native" ? null : asset.identifier, decimals: asset.decimals };
  }
  if (!input.assetNetwork || !input.assetContractAddress) throw new Error("An asset registry selection is required");
  const asset = await findAssetByIdentity(input.assetNetwork.toLowerCase(), input.assetContractAddress);
  if (!asset || asset.status !== "active" || asset.verificationStatus !== "verified") throw new Error("The selected asset is not an active verified registry asset");
  return { assetId: asset.id, symbol: asset.symbol, network: asset.chainId, contractAddress: asset.identifier, decimals: asset.decimals };
}

function assertRewardAmount(amount: string, decimals: number): void {
  if (!/^(?:0|[1-9]\d{0,37})(?:\.\d{1,36})?$/.test(amount) || amount === "0") throw new Error("Reward amount must be a positive decimal");
  const fraction = amount.split(".")[1] ?? "";
  if (fraction.length > decimals) throw new Error("Reward amount exceeds asset precision");
}

export async function createGiftCode(input: CreateGiftCodeInput): Promise<{ giftCode: GiftCode; rawCode: string }> {
  assertUser(input.createdByOpenId);
  await enforceGiftCodeRateLimit("create", input.createdByOpenId);
  if (!Number.isSafeInteger(input.maxRedemptions) || input.maxRedemptions <= 0 || input.maxRedemptions > MAX_GIFT_REDEMPTIONS) throw new Error("Invalid maximum redemptions");
  if (input.expiresAt && input.expiresAt.getTime() <= Date.now()) throw new Error("Gift Code expiry must be in the future");
  const asset = await resolveCreationAsset(input);
  assertRewardAmount(input.rewardAmount, asset.decimals);
  if (!isDirectGiftCodeFulfillmentSupported(asset.network)) throw new Error(asset.network.toLowerCase() === "ton" ? "Coming soon" : `Gift Code fulfillment is not enabled for ${asset.network} yet`);
  await assertGiftCodeRewardFunding({
    network: asset.network,
    tokenAddress: asset.contractAddress ?? "",
    tokenSymbol: asset.symbol,
    decimals: asset.decimals,
    rewardAmount: input.rewardAmount,
    maxRedemptions: input.maxRedemptions,
  });

  const dbModule = await import("../db");
  const db = await dbModule.getDb();
  if (!db) throw new Error("Database not available");
  const { giftCodes } = await import("../../drizzle/schema");
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const rawCode = generateGiftCode();
    try {
      await db.insert(giftCodes).values({
        codeHash: hashGiftCode(rawCode),
        codeHint: rawCode.slice(-4),
        assetId: asset.assetId,
        assetSymbol: asset.symbol,
        assetNetwork: asset.network,
        assetContractAddress: asset.contractAddress,
        rewardAmount: input.rewardAmount,
        maxRedemptions: input.maxRedemptions,
        expiresAt: input.expiresAt ?? null,
        createdByOpenId: input.createdByOpenId,
      });
      const [giftCode] = await db.select().from(giftCodes).where((await import("drizzle-orm")).eq(giftCodes.codeHash, hashGiftCode(rawCode))).limit(1);
      if (giftCode) {
        await recordAdminAuditEvent({
          actorOpenId: input.createdByOpenId,
          action: "Gift Code created",
          resourceType: "giftCode",
          resourceId: giftCode.id,
          details: { assetId: giftCode.assetId, assetNetwork: giftCode.assetNetwork, assetSymbol: giftCode.assetSymbol, rewardAmount: giftCode.rewardAmount, maxRedemptions: giftCode.maxRedemptions },
        });
        return { giftCode, rawCode };
      }
    } catch {
      // A generated-code collision is the only retryable creation failure.
    }
  }
  throw new Error("Could not create Gift Code");
}

export async function redeemGiftCode(userOpenId: string, rawCode: string, requestedRecipientWalletAddress?: string): Promise<RewardLedgerEntry> {
  assertUser(userOpenId);
  await enforceGiftCodeRateLimit("redeem", userOpenId);
  const normalizedCode = normalizeGiftCode(rawCode);
  const codeHash = hashGiftCode(normalizedCode);
  return withGiftCodeLock(`${userOpenId}:${codeHash}`, async () => {
    const giftCode = await findGiftCodeByHash(codeHash);
    if (!giftCode) throw new Error("Gift Code not found");
    const existing = await findRedemption(giftCode.id, userOpenId);
    if (existing?.rewardLedgerId) {
      if (existing.fulfillmentStatus === "confirmed" || existing.fulfillmentStatus === "not_required") {
        const dbModule = await import("../db");
        const db = await dbModule.getReadDb();
        if (!db) throw new Error("Database not available");
        const { rewardLedger } = await import("../../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        const [ledger] = await db.select().from(rewardLedger).where(eq(rewardLedger.id, existing.rewardLedgerId)).limit(1);
        if (ledger) return ledger;
      }
      if (existing.fulfillmentStatus === "broadcast" && existing.transactionHash) {
        await fulfillGiftCode({ redemptionId: existing.id, giftCode, recipientWalletAddress: existing.recipientWalletAddress ?? requestedRecipientWalletAddress ?? "", existingTransactionHash: existing.transactionHash, actorOpenId: userOpenId });
      }
      const dbModule = await import("../db");
      const db = await dbModule.getReadDb();
      if (!db) throw new Error("Database not available");
      const { rewardLedger } = await import("../../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const [ledger] = await db.select().from(rewardLedger).where(eq(rewardLedger.id, existing.rewardLedgerId)).limit(1);
      if (ledger) return ledger;
    }

    assertGiftCodeRedeemable(giftCode.status, giftCode.expiresAt);
    const recipient = validateGiftRecipient(giftCode.assetNetwork, requestedRecipientWalletAddress ?? "");
    if (!isDirectGiftCodeFulfillmentSupported(giftCode.assetNetwork)) throw new Error(giftCode.assetNetwork.toLowerCase() === "ton" ? "Coming soon" : `Gift Code fulfillment is not enabled for ${giftCode.assetNetwork} yet`);
    const reserved = await reserveGiftCode({
      giftCodeId: giftCode.id,
      userOpenId,
      recipientWalletAddress: recipient,
      fulfillmentStatus: "pending",
      assetSymbol: giftCode.assetSymbol,
      assetNetwork: giftCode.assetNetwork,
      assetContractAddress: giftCode.assetContractAddress,
      rewardAmount: giftCode.rewardAmount,
      codeHint: giftCode.codeHint,
    });
    try {
      await fulfillGiftCode({ redemptionId: reserved.redemption.id, giftCode, recipientWalletAddress: recipient, actorOpenId: userOpenId });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Gift Code fulfillment failed";
      await updateFulfillment(reserved.redemption.id, { fulfillmentStatus: "failed", fulfillmentError: message, redemptionStatus: "rejected", ledgerStatus: "failed" }).catch(() => undefined);
      await recordAdminAuditEvent({ actorOpenId: userOpenId, action: "Reward transfer failed", resourceType: "giftCodeRedemption", resourceId: reserved.redemption.id, details: { giftCodeId: giftCode.id, transactionHash: reserved.redemption.transactionHash, error: message } });
      throw error;
    }
    const dbModule = await import("../db");
    const db = await dbModule.getReadDb();
    if (!db) throw new Error("Database not available");
    const { rewardLedger } = await import("../../drizzle/schema");
    const { eq } = await import("drizzle-orm");
    const [ledger] = await db.select().from(rewardLedger).where(eq(rewardLedger.id, reserved.ledger.id)).limit(1);
    if (!ledger) throw new Error("Gift Code reward ledger could not be loaded");
    await recordAdminAuditEvent({ actorOpenId: userOpenId, action: "Gift Code redeemed", resourceType: "giftCodeRedemption", resourceId: reserved.redemption.id, details: { giftCodeId: giftCode.id, transactionHash: reserved.redemption.transactionHash, assetNetwork: giftCode.assetNetwork, rewardAmount: giftCode.rewardAmount } });
    return ledger;
  });
}

export async function disableGiftCodeForAdmin(actorOpenId: string, giftCodeId: number): Promise<GiftCode | null> {
  const giftCode = await disableGiftCodeRecord(giftCodeId);
  if (giftCode?.status === "cancelled") {
    await recordAdminAuditEvent({ actorOpenId, action: "Gift Code disabled", resourceType: "giftCode", resourceId: giftCode.id, details: { assetNetwork: giftCode.assetNetwork, assetSymbol: giftCode.assetSymbol, redemptionCount: giftCode.redemptionCount } });
  }
  return giftCode;
}
