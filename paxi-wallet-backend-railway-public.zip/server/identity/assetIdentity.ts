import type { SupportedNetwork } from "../chains/types";

export type CanonicalChain = SupportedNetwork;
export type AssetIdentityKind = "native" | "token";

export interface AssetIdentityInput {
  chain?: string | null;
  network?: string | null;
  chainId?: string | number | null;
  contractAddress?: string | null;
  mintAddress?: string | null;
  contractOrMint?: string | null;
  identifier?: string | null;
  kind?: AssetIdentityKind | null;
}

export interface AssetIdentity {
  chain: CanonicalChain;
  kind: AssetIdentityKind;
  contractOrMint: string;
  key: string;
}

const CHAIN_ALIASES: Record<string, CanonicalChain> = {
  ethereum: "ethereum",
  eth: "ethereum",
  "1": "ethereum",
  bsc: "bsc",
  bnb: "bsc",
  "binance-smart-chain": "bsc",
  "56": "bsc",
  polygon: "polygon",
  "polygon-pos": "polygon",
  pol: "polygon",
  "137": "polygon",
  arbitrum: "arbitrum",
  "arbitrum-one": "arbitrum",
  "42161": "arbitrum",
  solana: "solana",
  bitcoin: "bitcoin",
  btc: "bitcoin",
};

const EVM_CHAINS = new Set<CanonicalChain>(["ethereum", "bsc", "polygon", "arbitrum"]);

export function normalizeChain(value: unknown): CanonicalChain | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  return CHAIN_ALIASES[String(value).trim().toLowerCase()] ?? null;
}

export function normalizeAssetAddress(chain: string, address: string): string {
  const trimmed = address.trim();
  if (EVM_CHAINS.has(normalizeChain(chain) as CanonicalChain)) return trimmed.toLowerCase();
  return trimmed;
}

export function getAssetIdentityKey(identity: Pick<AssetIdentity, "chain" | "contractOrMint"> | AssetIdentityInput): string {
  const input = identity as AssetIdentityInput;
  const chain = normalizeChain(input.chain ?? input.network ?? input.chainId);
  if (!chain) throw new Error("Unsupported asset chain");
  const identifier = input.contractOrMint ?? input.contractAddress ?? input.mintAddress ?? input.identifier;
  const isNative = input.kind === "native" || !identifier || identifier.trim().toLowerCase() === "native";
  return `${chain}:${isNative ? "native" : normalizeAssetAddress(chain, identifier)}`;
}

export function resolveAssetIdentity(input: AssetIdentityInput): AssetIdentity | null {
  const chain = normalizeChain(input.chain ?? input.network ?? input.chainId);
  if (!chain) return null;
  const rawIdentifier = input.contractOrMint ?? input.contractAddress ?? input.mintAddress ?? input.identifier;
  const isNative = input.kind === "native" || !rawIdentifier || rawIdentifier.trim().toLowerCase() === "native";
  const contractOrMint = isNative ? "native" : normalizeAssetAddress(chain, rawIdentifier);
  if (!contractOrMint) return null;
  return {
    chain,
    kind: isNative ? "native" : "token",
    contractOrMint,
    key: `${chain}:${contractOrMint}`,
  };
}

export function isSameAsset(a: AssetIdentityInput | AssetIdentity, b: AssetIdentityInput | AssetIdentity): boolean {
  try {
    return getAssetIdentityKey(a) === getAssetIdentityKey(b);
  } catch {
    return false;
  }
}

export function isEvmChain(chain: string | null | undefined): boolean {
  return Boolean(chain && EVM_CHAINS.has(normalizeChain(chain) as CanonicalChain));
}
