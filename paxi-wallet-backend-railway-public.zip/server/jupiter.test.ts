import { beforeEach, describe, expect, it, vi } from "vitest";

describe("Jupiter server token adapter", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.restoreAllMocks();
    vi.stubEnv("JUPITER_API_KEY", "unit-test-jupiter-key");
  });

  it("does not call Jupiter when the optional server key is missing", async () => {
    vi.stubEnv("JUPITER_API_KEY", "");
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    const jupiter = await import("./jupiter");

    await expect(jupiter.getJupiterToken("Mint111")).resolves.toBeNull();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("normalizes only the exact mint and preserves genuinely supplied fields", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => [
        { id: "OtherMint", name: "Wrong token", usdPrice: 999 },
        {
          id: "Mint111",
          name: "Example SPL",
          symbol: "EX",
          icon: "https://example.test/ex.png",
          decimals: 6,
          usdPrice: 1.25,
          stats24h: { priceChange: -2.5 },
          liquidity: 5000,
          mcap: 10000,
          fdv: 12000,
          circSupply: 100,
          totalSupply: 200,
          holderCount: 42,
          isVerified: true,
          audit: { isSus: false },
          updatedAt: "2026-08-27T00:00:00Z",
        },
      ],
    });
    vi.stubGlobal("fetch", fetchMock);
    const jupiter = await import("./jupiter");

    await expect(jupiter.getJupiterToken("Mint111")).resolves.toEqual({
      id: "Mint111",
      name: "Example SPL",
      symbol: "EX",
      icon: "https://example.test/ex.png",
      decimals: 6,
      usdPrice: 1.25,
      priceChange24h: -2.5,
      liquidity: 5000,
      mcap: 10000,
      fdv: 12000,
      circSupply: 100,
      totalSupply: 200,
      holderCount: 42,
      isVerified: true,
      auditIsSus: false,
      updatedAt: "2026-08-27T00:00:00Z",
      source: "jupiter",
    });
    expect(fetchMock.mock.calls[0]?.[1]?.headers).toMatchObject({ "x-api-key": "unit-test-jupiter-key" });
  });

  it("returns null for nonmatching, malformed, and rate-limited responses", async () => {
    const cases = [
      { ok: true, json: async () => [{ id: "DifferentMint", symbol: "NO" }] },
      { ok: true, json: async () => ({ not: "an array" }) },
      { ok: false, status: 429 },
    ];

    for (const response of cases) {
      vi.resetModules();
      vi.stubGlobal("fetch", vi.fn().mockResolvedValue(response));
      const jupiter = await import("./jupiter");
      await expect(jupiter.getJupiterToken("Mint111")).resolves.toBeNull();
    }
  });
});

