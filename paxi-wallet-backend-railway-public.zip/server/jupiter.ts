import { ENV } from "./_core/env";
import { fetchJson } from "./providers/http";

const JUPITER_BASE = "https://api.jup.ag/tokens/v2";

export interface JupiterTokenRecord {
  id: string;
  name: string | null;
  symbol: string | null;
  icon: string | null;
  decimals: number | null;
  usdPrice: number | null;
  priceChange24h: number | null;
  liquidity: number | null;
  mcap: number | null;
  fdv: number | null;
  circSupply: number | null;
  totalSupply: number | null;
  holderCount: number | null;
  isVerified: boolean | null;
  auditIsSus: boolean | null;
  updatedAt: string | null;
  source: "jupiter";
}

type JupiterApiToken = {
  id?: unknown;
  name?: unknown;
  symbol?: unknown;
  icon?: unknown;
  decimals?: unknown;
  usdPrice?: unknown;
  mcap?: unknown;
  fdv?: unknown;
  liquidity?: unknown;
  circSupply?: unknown;
  totalSupply?: unknown;
  holderCount?: unknown;
  isVerified?: unknown;
  audit?: { isSus?: unknown } | null;
  stats24h?: { priceChange?: unknown } | null;
  updatedAt?: unknown;
};

function finiteNumber(value: unknown): number | null {
  const number = typeof value === "number" ? value : Number(value);
  return Number.isFinite(number) ? number : null;
}

function optionalString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function normalizeToken(value: JupiterApiToken, mint: string): JupiterTokenRecord | null {
  if (value.id !== mint) return null;
  const decimals = finiteNumber(value.decimals);
  return {
    id: mint,
    name: optionalString(value.name),
    symbol: optionalString(value.symbol),
    icon: optionalString(value.icon),
    decimals: decimals !== null && decimals >= 0 && decimals <= 255 ? decimals : null,
    usdPrice: finiteNumber(value.usdPrice),
    priceChange24h: finiteNumber(value.stats24h?.priceChange),
    liquidity: finiteNumber(value.liquidity),
    mcap: finiteNumber(value.mcap),
    fdv: finiteNumber(value.fdv),
    circSupply: finiteNumber(value.circSupply),
    totalSupply: finiteNumber(value.totalSupply),
    holderCount: finiteNumber(value.holderCount),
    isVerified: typeof value.isVerified === "boolean" ? value.isVerified : null,
    auditIsSus: typeof value.audit?.isSus === "boolean" ? value.audit.isSus : null,
    updatedAt: optionalString(value.updatedAt),
    source: "jupiter",
  };
}

/** Returns null when the optional server key is not configured or the provider is unavailable. */
export async function getJupiterToken(mint: string): Promise<JupiterTokenRecord | null> {
  const normalizedMint = mint.trim();
  if (!normalizedMint || !ENV.jupiterApiKey) return null;

  try {
    const url = `${JUPITER_BASE}/search?query=${encodeURIComponent(normalizedMint)}`;
    const response = await fetchJson<JupiterApiToken[]>(url, "jupiter", {
      "x-api-key": ENV.jupiterApiKey,
    });
    if (!Array.isArray(response)) return null;
    const exact = response.find((token) => token?.id === normalizedMint);
    return exact ? normalizeToken(exact, normalizedMint) : null;
  } catch (error) {
    console.warn("[jupiter] token lookup unavailable:", error instanceof Error ? error.message : "provider request failed");
    return null;
  }
}

export function isJupiterSuspicious(token: JupiterTokenRecord | null): boolean | null {
  return token?.auditIsSus ?? null;
}
