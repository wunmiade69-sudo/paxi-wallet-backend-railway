import { PublicKey } from "@solana/web3.js";
import { ENV } from "./_core/env";
import { fetchJson } from "./providers/http";

/** Jupiter’s current Swap API v2 requires a server-side x-api-key. */
const JUPITER_API_BASE = "https://api.jup.ag/swap/v2";
function jupiterHeaders(extra: Record<string, string> = {}): Record<string, string> {
  if (!ENV.jupiterApiKey) throw new Error("JUPITER_API_KEY is not configured.");
  return { ...extra, "x-api-key": ENV.jupiterApiKey };
}
const SOLANA_NATIVE_MINT = "So11111111111111111111111111111111111111112";

export interface JupiterSwapQuoteInput {
  inputMint: string;
  outputMint: string;
  amount: string;
  slippageBps: number;
}

export interface JupiterSwapQuoteResult {
  quoteResponse: Record<string, unknown>;
  inputAmountUnits: string;
  outputAmountUnits: string;
  minimumOutputAmountUnits: string;
  routeNames: string[];
}

function assertSolanaAddress(value: string, field: string): string {
  try {
    return new PublicKey(value).toBase58();
  } catch {
    throw new Error(`Invalid ${field}.`);
  }
}

function assertUnits(value: string, field: string): string {
  if (!/^[0-9]+$/.test(value) || value === "0" || value.length > 80) throw new Error(`Invalid ${field}.`);
  return value;
}

function routeNames(quote: Record<string, unknown>): string[] {
  const routes = Array.isArray(quote.routePlan) ? quote.routePlan : [];
  return Array.from(new Set(routes.map((route) => {
    const info = route && typeof route === "object" ? (route as Record<string, unknown>).swapInfo : null;
    return info && typeof info === "object" && typeof (info as Record<string, unknown>).label === "string"
      ? (info as Record<string, unknown>).label as string
      : null;
  }).filter((label): label is string => Boolean(label))));
}

export function buildJupiterQuoteUrl(input: JupiterSwapQuoteInput): string {
  const url = new URL(`${JUPITER_API_BASE}/order`);
  url.search = new URLSearchParams({
    inputMint: assertSolanaAddress(input.inputMint, "input mint"),
    outputMint: assertSolanaAddress(input.outputMint, "output mint"),
    amount: assertUnits(input.amount, "amount"),
    slippageBps: String(input.slippageBps),
  }).toString();
  if (!Number.isSafeInteger(input.slippageBps) || input.slippageBps < 0 || input.slippageBps > 5_000) throw new Error("Invalid slippage.");
  return url.toString();
}

export async function fetchJupiterSwapQuote(input: JupiterSwapQuoteInput): Promise<JupiterSwapQuoteResult> {
  const quote = await fetchJson<Record<string, unknown>>(buildJupiterQuoteUrl(input), "jupiter-swap", jupiterHeaders());
  const inputAmountUnits = typeof quote.inAmount === "string" ? quote.inAmount : "";
  const outputAmountUnits = typeof quote.outAmount === "string" ? quote.outAmount : "";
  const minimumOutputAmountUnits = typeof quote.otherAmountThreshold === "string" ? quote.otherAmountThreshold : outputAmountUnits;
  assertUnits(inputAmountUnits, "Jupiter input amount");
  assertUnits(outputAmountUnits, "Jupiter output amount");
  assertUnits(minimumOutputAmountUnits, "Jupiter minimum output amount");
  return {
    quoteResponse: quote,
    inputAmountUnits,
    outputAmountUnits,
    minimumOutputAmountUnits,
    routeNames: routeNames(quote),
  };
}

export interface JupiterInstructionInput {
  quoteResponse: Record<string, unknown>;
  userPublicKey: string;
}

export interface JupiterInstructionResult {
  computeBudgetInstructions: unknown[];
  setupInstructions: unknown[];
  swapInstruction: Record<string, unknown>;
  cleanupInstruction: Record<string, unknown> | null;
  addressLookupTableAddresses: string[];
}

export async function buildJupiterSwapInstructions(input: JupiterInstructionInput): Promise<JupiterInstructionResult> {
  const userPublicKey = assertSolanaAddress(input.userPublicKey, "wallet address");
  const quote = input.quoteResponse;
  const inputMint = typeof quote.inputMint === "string" ? assertSolanaAddress(quote.inputMint, "input mint") : "";
  const outputMint = typeof quote.outputMint === "string" ? assertSolanaAddress(quote.outputMint, "output mint") : "";
  const amount = typeof quote.inAmount === "string" ? assertUnits(quote.inAmount, "Jupiter input amount") : "";
  const slippageBps = typeof quote.slippageBps === "number" ? quote.slippageBps : 50;
  if (!inputMint || !outputMint || !amount) throw new Error("Jupiter quote response is missing build parameters.");
  const url = new URL(`${JUPITER_API_BASE}/build`);
  url.search = new URLSearchParams({ inputMint, outputMint, amount, taker: userPublicKey, slippageBps: String(slippageBps), wrapAndUnwrapSol: "true" }).toString();
  const data = await fetchJson<Record<string, unknown>>(url.toString(), "jupiter-swap", jupiterHeaders());
  const swapInstruction = data.swapInstruction;
  if (!swapInstruction || typeof swapInstruction !== "object") throw new Error("Jupiter returned invalid swap instructions.");
  const addresses = Array.isArray(data.addressLookupTableAddresses)
    ? data.addressLookupTableAddresses.filter((value): value is string => typeof value === "string").map((value) => assertSolanaAddress(value, "address lookup table"))
    : data.addressesByLookupTableAddress && typeof data.addressesByLookupTableAddress === "object"
      ? Object.keys(data.addressesByLookupTableAddress).map((value) => assertSolanaAddress(value, "address lookup table"))
      : [];
  return {
    computeBudgetInstructions: Array.isArray(data.computeBudgetInstructions) ? data.computeBudgetInstructions : [],
    setupInstructions: Array.isArray(data.setupInstructions) ? data.setupInstructions : [],
    swapInstruction: swapInstruction as Record<string, unknown>,
    cleanupInstruction: data.cleanupInstruction && typeof data.cleanupInstruction === "object" ? data.cleanupInstruction as Record<string, unknown> : null,
    addressLookupTableAddresses: addresses,
  };
}

export { SOLANA_NATIVE_MINT };
