import { describe, expect, it } from "vitest";
import { buildLifiQuoteRequest } from "./lifiQuote";

const validInput = {
  fromChain: 1,
  toChain: 56,
  fromToken: "0x0000000000000000000000000000000000000000",
  toToken: "0x0000000000000000000000000000000000000000",
  fromAddress: "0x1111111111111111111111111111111111111111",
  toAddress: "0x2222222222222222222222222222222222222222",
  fromAmount: "1000000000000000000",
  slippage: 0.01,
};

describe("LI.FI server request", () => {
  it("keeps the API key in the server header and out of the URL", () => {
    const apiKey = "test-lifi-secret";
    const request = buildLifiQuoteRequest(validInput, apiKey);

    expect(request.headers).toMatchObject({
      accept: "application/json",
      "x-lifi-api-key": apiKey,
    });
    expect(request.url).not.toContain(apiKey);
    expect(request.url).toContain("integrator=paxiwallet");
    expect(request.url).toContain("fee=0.003");
  });

  it("rejects unsupported chains before making a provider request", () => {
    expect(() => buildLifiQuoteRequest({ ...validInput, fromChain: 999 })).toThrow(
      "LI.FI does not support one of the selected networks.",
    );
  });
});
