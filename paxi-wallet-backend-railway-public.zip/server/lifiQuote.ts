import { ENV } from "./_core/env";
import { fetchJson } from "./providers/http";

const LIFI_API = "https://li.quest/v1";
export const LIFI_INTEGRATOR = "paxiwallet";
export const LIFI_FEE = 0.003;

export const SUPPORTED_LIFI_CHAIN_IDS = new Set([
  1, // Ethereum
  56, // BNB Smart Chain
  137, // Polygon
  42161, // Arbitrum One
  1151111081099710, // LI.FI Solana chain id
]);

export interface LifiQuoteInput {
  fromChain: number;
  toChain: number;
  fromToken: string;
  toToken: string;
  fromAddress: string;
  toAddress: string;
  fromAmount: string;
  slippage: number;
}

function assertValidQuoteInput(input: LifiQuoteInput) {
  if (!SUPPORTED_LIFI_CHAIN_IDS.has(input.fromChain) || !SUPPORTED_LIFI_CHAIN_IDS.has(input.toChain)) {
    throw new Error("LI.FI does not support one of the selected networks.");
  }
  if (!input.fromToken || !input.toToken || !input.fromAddress || !input.toAddress) {
    throw new Error("LI.FI quote is missing a token or wallet address.");
  }
  if (!/^[0-9]+$/.test(input.fromAmount) || input.fromAmount === "0") {
    throw new Error("LI.FI quote amount is invalid.");
  }
  if (!Number.isFinite(input.slippage) || input.slippage < 0 || input.slippage > 0.5) {
    throw new Error("LI.FI slippage must be between 0% and 50%.");
  }
}

export function buildLifiQuoteRequest(input: LifiQuoteInput, apiKey = ENV.lifiApiKey) {
  assertValidQuoteInput(input);

  const qs = new URLSearchParams({
    fromChain: String(input.fromChain),
    toChain: String(input.toChain),
    fromToken: input.fromToken,
    toToken: input.toToken,
    fromAddress: input.fromAddress,
    toAddress: input.toAddress,
    fromAmount: input.fromAmount,
    slippage: String(input.slippage),
    integrator: LIFI_INTEGRATOR,
    fee: String(LIFI_FEE),
  });

  const headers: Record<string, string> = { accept: "application/json" };
  if (apiKey) headers["x-lifi-api-key"] = apiKey;

  return { url: `${LIFI_API}/quote?${qs.toString()}`, headers };
}

/**
 * Server-side LI.FI quote request. The API key is deliberately read only from
 * the server environment and is never accepted from or returned to the client.
 */
export async function fetchLifiQuote(input: LifiQuoteInput): Promise<any> {
  const request = buildLifiQuoteRequest(input);
  const body = await fetchJson<Record<string, any>>(request.url, "lifi", request.headers);
  if (!body?.estimate || !body?.transactionRequest) {
    throw new Error("LI.FI returned no executable route for this pair.");
  }
  return body;
}
