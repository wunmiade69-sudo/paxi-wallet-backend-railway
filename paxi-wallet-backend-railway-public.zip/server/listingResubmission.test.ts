import { describe, expect, it } from "vitest";
import { canResubmitRejectedListing } from "./listingResubmission";

describe("listing resubmission eligibility", () => {
  it("permits only the same owner to resubmit the exact rejected listing", () => {
    expect(canResubmitRejectedListing({ existingId: 7, existingStatus: "rejected", existingOwnerMatches: true, resubmissionListingId: 7 })).toBe(true);
    expect(canResubmitRejectedListing({ existingId: 7, existingStatus: "pending", existingOwnerMatches: true, resubmissionListingId: 7 })).toBe(false);
    expect(canResubmitRejectedListing({ existingId: 7, existingStatus: "rejected", existingOwnerMatches: false, resubmissionListingId: 7 })).toBe(false);
    expect(canResubmitRejectedListing({ existingId: 7, existingStatus: "rejected", existingOwnerMatches: true, resubmissionListingId: 8 })).toBe(false);
  });
});
