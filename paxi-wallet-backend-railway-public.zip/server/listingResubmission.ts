export function canResubmitRejectedListing(input: {
  existingId?: number;
  existingStatus?: "pending" | "verified" | "rejected";
  existingOwnerMatches: boolean;
  resubmissionListingId?: number;
}): boolean {
  return Boolean(
    input.resubmissionListingId &&
      input.existingId === input.resubmissionListingId &&
      input.existingStatus === "rejected" &&
      input.existingOwnerMatches,
  );
}
