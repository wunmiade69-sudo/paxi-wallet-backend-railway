import { describe, expect, it } from "vitest";
import { canonicalTokenInput } from "./routers/listings";

describe("listing token identity validation", () => {
  it("normalizes valid EVM listing contracts server-side", () => {
    expect(canonicalTokenInput("bsc", "0xEDA04581461BC308E60052FE489E20C3F78D6E4E")).toEqual({
      network: "bsc",
      contractAddress: "0xEdA04581461Bc308E60052FE489E20c3F78D6E4e",
    });
  });

  it("rejects unsupported networks and invalid contract identifiers", () => {
    expect(() => canonicalTokenInput("ton", "EQB-invalid")).toThrow("Unsupported network or invalid token identifier");
    expect(() => canonicalTokenInput("bsc", "not-a-contract")).toThrow("Unsupported network or invalid token identifier");
  });
});
