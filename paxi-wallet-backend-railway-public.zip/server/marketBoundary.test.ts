import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("Solana/Jupiter market-data boundary", () => {
  it("keeps provider and market procedures free of signing and Jupiter execution code", () => {
    const serverSources = [
      "server/marketData.ts",
      "server/marketProviders.ts",
      "server/routers/market.ts",
    ].map((relativePath) => readFileSync(resolve(process.cwd(), relativePath), "utf8")).join("\n");

    expect(serverSources).not.toMatch(/jupiterSwap|executeSolanaSwap|deriveSolanaKeypair|privateKey/i);
  });

  it("keeps Jupiter quote and signing functions in the existing client wallet module", () => {
    const jupiterSource = readFileSync(resolve(process.cwd(), "client/src/lib/wallet/jupiterSwap.ts"), "utf8");
    expect(jupiterSource).toMatch(/getSolanaSwapQuote/);
    expect(jupiterSource).toMatch(/executeSolanaSwap/);
    expect(jupiterSource).toMatch(/deriveSolanaKeypair/);
  });
});
