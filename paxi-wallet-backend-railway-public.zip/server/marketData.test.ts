import { describe, expect, it } from "vitest";
import { getBinanceChartConfig, getBinanceChartSymbolCandidates, marketTokenFromCoinGecko, paginateMarketTokens } from "./marketData";

describe("market chart fallbacks", () => {
  it("uses a known mapping first and falls back to a normalized USDT market symbol", () => {
    expect(getBinanceChartSymbolCandidates("bitcoin", "btc")).toEqual(["BTCUSDT"]);
    expect(getBinanceChartSymbolCandidates("zcash", "zec")).toEqual(["ZECUSDT"]);
    expect(getBinanceChartSymbolCandidates("wrapped-asset", "w-asset")).toEqual(["WASSETUSDT"]);
  });

  it("keeps timeframes within the exchange candle limits used by the history retry path", () => {
    expect(getBinanceChartConfig(1)).toEqual({ interval: "1h", limit: 24 });
    expect(getBinanceChartConfig(365)).toEqual({ interval: "1w", limit: 52 });
    expect(getBinanceChartConfig("max")).toEqual({ interval: "1w", limit: 1000 });
  });

  it("reports no more results when the provider returned no lookahead item", () => {
    expect(paginateMarketTokens([1, 2, 3], 1, 3, true)).toEqual({ items: [1, 2, 3], hasMore: false });
    expect(paginateMarketTokens([1, 2], 2, 3, false)).toEqual({ items: [], hasMore: false });
  });

  it("reports another page only from an actual lookahead item or remaining pool data", () => {
    expect(paginateMarketTokens([1, 2, 3, 4], 1, 3, true)).toEqual({ items: [1, 2, 3], hasMore: true });
    expect(paginateMarketTokens([1, 2, 3, 4], 1, 3, false)).toEqual({ items: [1, 2, 3], hasMore: true });
    expect(paginateMarketTokens([1, 2, 3, 4], 2, 3, false)).toEqual({ items: [4], hasMore: false });
  });
});

describe("CoinGecko native identity normalization", () => {
  it("maps exact native coin IDs to supported chain:native identities", () => {
    const cases = [
      ["ethereum", "ethereum"],
      ["bitcoin", "bitcoin"],
      ["solana", "solana"],
      ["binancecoin", "bsc"],
      ["polygon-ecosystem-token", "polygon"],
    ] as const;
    for (const [id, chain] of cases) {
      const token = marketTokenFromCoinGecko({ id, symbol: id.slice(0, 3), name: id });
      expect(token.chain).toBe(chain);
      expect(token.identifier).toBe("native");
      expect(token.contractAddress).toBeNull();
    }
  });

  it("does not infer native identity from a symbol alone", () => {
    const token = marketTokenFromCoinGecko({ id: "some-token", symbol: "ETH", name: "Wrapped Example" });
    expect(token.chain).toBeNull();
    expect(token.identifier).toBeNull();
  });
});
