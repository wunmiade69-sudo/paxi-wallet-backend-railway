/**
 * Real market data via CoinGecko's public API - this is how "thousands of
 * tokens, without maintaining them yourself" actually works: fetch from a
 * market data provider, don't hand-curate a list.
 *
 * CoinGecko's free tier is rate-limited (roughly 10-30 calls/min), so
 * results are cached three ways, cheapest first:
 *   1. In-memory (per server process) - near-zero latency, but wiped on
 *      every restart and not shared across instances.
 *   2. Our own DB (marketDataCache table) - survives restarts, shared by
 *      every server instance, so the Markets list and Token Detail chart
 *      are served from *our* data instead of waiting on CoinGecko live.
 *   3. CoinGecko itself - only hit when nothing is cached anywhere yet, or
 *      when a background refresh decides the DB copy is due for one.
 *
 * Reads never block on a refresh: if the DB has anything at all, it's
 * returned immediately, and a refresh (if the entry is stale) happens
 * afterwards in the background (stale-while-revalidate). A background
 * timer also proactively keeps the most-viewed Markets pages warm so
 * they're rarely even stale by the time someone loads them.
 */
import { eq } from "drizzle-orm";
import { marketDataCache } from "../drizzle/schema";
import { getDb } from "./db";
import { syncAssetFromCoinGeckoDetail } from "./assetRegistry";
import { getCachedMarketJson, setCachedMarketJson } from "./redis";
import { fetchJson } from "./providers/http";
import {
  dedupeProviderTokens,
  isLikelyAddressQuery,
  normalizeHistoricalPoint,
  normalizeMarketChain,
  normalizeProviderAddress,
  type CanonicalMarketIdentity,
  type NormalizedProviderToken,
  type ProviderChartResult,
  type MarketChartTimeframe,
} from "./marketProviders";
import { orchestratedSearchTokens, orchestratedTokenMetadata, orchestratedChart, orchestratedLiquidity } from "./providers";
import { getAssetIdentityKey, resolveAssetIdentity } from "./identity/assetIdentity";

const COINGECKO_BASE = "https://api.coingecko.com/api/v3";
/** Optional CoinGecko "Demo" API key (free, no card needed - coingecko.com/en/developers/dashboard).
 * Raises the rate limit well above the anonymous public endpoint used when this is unset. */
const COINGECKO_API_KEY = process.env.COINGECKO_API_KEY;
const COINGECKO_HEADERS: Record<string, string> = COINGECKO_API_KEY ? { "x-cg-demo-api-key": COINGECKO_API_KEY } : {};
const CACHE_TTL_MS = 60_000; // how long an in-memory hit is considered fresh
const DB_STALE_MS = 5 * 60_000; // how long a DB entry is served without triggering a background refresh

interface CacheEntry {
  data: unknown;
  expiresAt: number;
}
const memCache = new Map<string, CacheEntry>();
const inFlight = new Map<string, Promise<unknown>>();

async function readDbCache(cacheKey: string): Promise<{ data: unknown; ageMs: number } | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const rows = await db.select().from(marketDataCache).where(eq(marketDataCache.cacheKey, cacheKey)).limit(1);
    if (!rows.length) return null;
    return { data: rows[0].payload, ageMs: Date.now() - new Date(rows[0].updatedAt).getTime() };
  } catch (err) {
    console.warn("[marketData] DB cache read failed, falling back to live fetch:", err);
    return null;
  }
}

async function writeDbCache(cacheKey: string, data: unknown): Promise<void> {
  const db = await getDb();
  if (!db) return;
  try {
    await db
      .insert(marketDataCache)
      .values({ cacheKey, payload: data as any })
      .onDuplicateKeyUpdate({ set: { payload: data as any } });
  } catch (err) {
    console.warn("[marketData] DB cache write failed (non-fatal):", err);
  }
}

/** Fetches from CoinGecko and populates both cache layers. Coalesces concurrent callers for the same key. */
function refreshInBackground<T>(cacheKey: string, url: string): Promise<T> {
  const existing = inFlight.get(cacheKey);
  if (existing) return existing as Promise<T>;

  const promise = (async () => {
    const data = await fetchJson<T>(url, "coingecko", COINGECKO_HEADERS);
    memCache.set(cacheKey, { data, expiresAt: Date.now() + CACHE_TTL_MS });
    await writeDbCache(cacheKey, data);
    return data;
  })().finally(() => inFlight.delete(cacheKey));

  inFlight.set(cacheKey, promise);
  return promise;
}

async function cachedFetch<T>(cacheKey: string, url: string): Promise<T> {
  // 1. Hot in-memory hit - fastest path, no DB round trip at all.
  const mem = memCache.get(cacheKey);
  if (mem && mem.expiresAt > Date.now()) return mem.data as T;

  // 2. Our own DB - instant, survives restarts, shared across instances.
  const dbEntry = await readDbCache(cacheKey);
  if (dbEntry) {
    memCache.set(cacheKey, { data: dbEntry.data, expiresAt: Date.now() + CACHE_TTL_MS });
    if (dbEntry.ageMs > DB_STALE_MS) {
      // Stale-while-revalidate: caller still gets the DB copy instantly.
      refreshInBackground(cacheKey, url).catch((err) => console.warn("[marketData] background refresh failed:", cacheKey, err));
    }
    return dbEntry.data as T;
  }

  // 3. Nothing cached anywhere yet - the only path that waits on CoinGecko live.
  try {
    return await refreshInBackground<T>(cacheKey, url);
  } catch (err) {
    throw err instanceof Error ? err : new Error(String(err));
  }
}

/** The Markets list pages people actually land on. Kept warm proactively so they're almost never a cold/stale read. */
const HOT_MARKET_PAGES: Array<{ page: number; perPage: number; order: MarketOrder }> = [
  { page: 1, perPage: 50, order: "market_cap_desc" },
  { page: 2, perPage: 50, order: "market_cap_desc" },
  { page: 1, perPage: 50, order: "volume_desc" },
  { page: 1, perPage: 50, order: "price_change_percentage_24h_desc" },
  { page: 1, perPage: 50, order: "price_change_percentage_24h_asc" },
];

let prewarmTimer: ReturnType<typeof setInterval> | null = null;

/** Call once on server boot. Populates the hot Markets pages immediately, then keeps refreshing them in the background. */
export function startMarketDataPrewarm(): void {
  if (prewarmTimer) return;
  const tick = () => {
    for (const p of HOT_MARKET_PAGES) {
      listMarketTokens(p).catch((err) => console.warn("[marketData] prewarm failed:", p, err));
    }
  };
  tick();
  prewarmTimer = setInterval(tick, CACHE_TTL_MS);
}

export type TokenVerificationStatus = "verified" | "unverified";

export type MarketTokenField =
  | "identity"
  | "name"
  | "symbol"
  | "decimals"
  | "image"
  | "price"
  | "priceChange24h"
  | "marketCap"
  | "volume24h"
  | "liquidity"
  | "verification"
  | "security";

export type MarketTokenFieldSources = Partial<Record<MarketTokenField, string[]>>;

export interface MarketToken {
  id: string;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number | null;
  marketCap: number | null;
  marketCapRank: number | null;
  volume24h: number | null;
  liquidity: number | null;
  priceChangePercent24h: number | null;
  decimals: number | null;
  /** Canonical identity is chain + contract/mint; native assets use identifier `native`. */
  chain: string | null;
  contractAddress: string | null;
  identifier: string | null;
  coinId?: string | null;
  /** Provider discovery is never equivalent to PAXI verification. */
  verificationStatus: TokenVerificationStatus;
  securityStatus: "available" | "unavailable";
  source: "coingecko" | "birdeye" | "dexpaprika";
  /** Providers that contributed normalized market fields to this response. */
  sources: Array<"coingecko" | "birdeye" | "dexpaprika">;
  /** Field-level provenance for debugging and truthful UI attribution. */
  fieldSources: MarketTokenFieldSources;
  marketDataAvailable: boolean;
}

function finiteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function safeImageUrl(value: unknown): string {
  return typeof value === "string" && /^https?:\/\//i.test(value) ? value : "";
}

const COINGECKO_NATIVE_CHAINS: Record<string, string> = {
  ethereum: "ethereum",
  bitcoin: "bitcoin",
  solana: "solana",
  binancecoin: "bsc",
  "polygon-ecosystem-token": "polygon",
  "matic-network": "polygon",
};

export function marketTokenFromCoinGecko(c: any, fallbackId?: string): MarketToken {
  const source = "coingecko";
  const coinId = typeof c?.id === "string" ? c.id : fallbackId ?? "unknown";
  const nativeChain = COINGECKO_NATIVE_CHAINS[coinId];
  const fieldSources: MarketTokenFieldSources = {
    identity: [source],
    name: typeof c?.name === "string" && c.name.trim() ? [source] : undefined,
    symbol: typeof c?.symbol === "string" && c.symbol.trim() ? [source] : undefined,
    image: safeImageUrl(c?.image) ? [source] : undefined,
    price: finiteNumber(c?.current_price) !== null ? [source] : undefined,
    priceChange24h: finiteNumber(c?.price_change_percentage_24h) !== null ? [source] : undefined,
    marketCap: finiteNumber(c?.market_cap) !== null ? [source] : undefined,
    volume24h: finiteNumber(c?.total_volume) !== null ? [source] : undefined,
  };
  return {
    id: coinId,
    coinId: typeof c?.id === "string" ? c.id : fallbackId ?? null,
    symbol: (typeof c?.symbol === "string" ? c.symbol : "").toUpperCase(),
    name: typeof c?.name === "string" ? c.name : "Unknown token",
    image: safeImageUrl(c?.image),
    currentPrice: finiteNumber(c?.current_price),
    marketCap: finiteNumber(c?.market_cap),
    marketCapRank: finiteNumber(c?.market_cap_rank),
    volume24h: finiteNumber(c?.total_volume),
    liquidity: null,
    priceChangePercent24h: finiteNumber(c?.price_change_percentage_24h),
    decimals: null,
    chain: nativeChain ?? null,
    contractAddress: null,
    identifier: nativeChain ? "native" : null,
    verificationStatus: "unverified",
    securityStatus: "unavailable",
    source,
    sources: [source],
    fieldSources,
    marketDataAvailable: finiteNumber(c?.current_price) !== null,
  };
}

export interface MarketSearchCandidate {
  id: string;
  name: string;
  symbol: string;
  marketCapRank: number | null;
  thumb?: string;
  large?: string;
}

/**
 * CoinGecko search is market-cap ordered rather than query-relevance ordered.
 * Rank exact symbol/name matches first and deduplicate by CoinGecko id so a
 * broad query such as "Sol" does not present an arbitrary duplicate set.
 */
export function rankAndDedupeSearchCandidates(candidates: MarketSearchCandidate[], query: string): MarketSearchCandidate[] {
  const q = query.trim().toLowerCase();
  const unique = new Map<string, MarketSearchCandidate>();
  for (const candidate of candidates) {
    if (!candidate.id || unique.has(candidate.id)) continue;
    unique.set(candidate.id, candidate);
  }

  const score = (candidate: MarketSearchCandidate): number => {
    const name = candidate.name.toLowerCase();
    const symbol = candidate.symbol.toLowerCase();
    if (symbol === q) return 1000;
    if (name === q) return 950;
    if (symbol.startsWith(q)) return 850;
    if (name.startsWith(q)) return 800;
    if (symbol.includes(q)) return 700;
    if (name.includes(q)) return 650;
    return 0;
  };

  return Array.from(unique.values()).sort((a, b) => {
    const scoreDiff = score(b) - score(a);
    if (scoreDiff !== 0) return scoreDiff;
    const rankA = a.marketCapRank ?? Number.MAX_SAFE_INTEGER;
    const rankB = b.marketCapRank ?? Number.MAX_SAFE_INTEGER;
    return rankA - rankB || a.name.localeCompare(b.name);
  });
}

export type MarketOrder = "market_cap_desc" | "price_change_percentage_24h_desc" | "price_change_percentage_24h_asc" | "volume_desc";

/** CoinGecko's `order` param on /coins/markets only actually supports market_cap and volume
 * sorts (see their docs) - passing a price-change value is silently ignored server-side and
 * you just get market-cap order back, so "Top Gainers"/"Top Losers" would show whatever's
 * biggest by market cap that day, not the coins that actually moved the most. Sorting by
 * 24h % change has to happen here instead, against a real ranked pool. */
const GAINER_LOSER_POOL_SIZE = 250; // CoinGecko's per_page max in one call - one request, cached, covers every page

export interface MarketTokenPage {
  items: MarketToken[];
  /** True only when the provider returned evidence of another page. */
  hasMore: boolean;
}

/** Paginate only from already-returned provider data; this never invents a total count. */
export function paginateMarketTokens<T>(items: readonly T[], page: number, perPage: number, hasLookaheadItem = false): { items: T[]; hasMore: boolean } {
  const start = Math.max(0, (page - 1) * perPage);
  return {
    items: hasLookaheadItem ? [...items].slice(0, perPage) : [...items].slice(start, start + perPage),
    hasMore: hasLookaheadItem ? items.length > perPage : start + perPage < items.length,
  };
}

export async function listMarketTokens(params: { page: number; perPage: number; order: MarketOrder }): Promise<MarketTokenPage> {
  const { page, perPage, order } = params;

  if (order === "price_change_percentage_24h_desc" || order === "price_change_percentage_24h_asc") {
    const url =
      `${COINGECKO_BASE}/coins/markets?vs_currency=usd&order=market_cap_desc` +
      `&per_page=${GAINER_LOSER_POOL_SIZE}&page=1&sparkline=false&price_change_percentage=24h`;
    const data = await cachedFetch<any[]>(`markets:24h-pool:${GAINER_LOSER_POOL_SIZE}`, url);

    const sorted = [...data]
      .filter((c) => typeof c.price_change_percentage_24h === "number")
      .sort((a, b) =>
        order === "price_change_percentage_24h_desc"
          ? b.price_change_percentage_24h - a.price_change_percentage_24h
          : a.price_change_percentage_24h - b.price_change_percentage_24h
      );

    const pageResult = paginateMarketTokens(sorted, params.page, params.perPage);
    return {
      items: pageResult.items.map((c) => marketTokenFromCoinGecko(c)),
      hasMore: pageResult.hasMore,
    };
  }

  const lookaheadPageSize = Math.min(perPage + 1, 250);
  const url =
    `${COINGECKO_BASE}/coins/markets?vs_currency=usd&order=${order}` +
    `&per_page=${lookaheadPageSize}&page=${page}&sparkline=false&price_change_percentage=24h`;

  const data = await cachedFetch<any[]>(`markets:${order}:${page}:${lookaheadPageSize}`, url);
  const pageResult = paginateMarketTokens(data, params.page, params.perPage, true);

  return {
    items: pageResult.items.map((c) => marketTokenFromCoinGecko(c)),
    hasMore: pageResult.hasMore,
  };
}

function marketTokenFromProvider(token: NormalizedProviderToken): MarketToken {
  const source = token.source;
  const contributed = (field: keyof MarketTokenFieldSources, available: boolean): string[] | undefined => {
    if (!available) return undefined;
    return token.fieldSources?.[field] ? [...token.fieldSources[field]!] : [...token.sources];
  };
  const fieldSources: MarketTokenFieldSources = {
    identity: contributed("identity", Boolean(token.chain || token.contractAddress)),
    name: contributed("name", Boolean(token.name)),
    symbol: contributed("symbol", Boolean(token.symbol)),
    decimals: contributed("decimals", token.decimals !== null),
    image: contributed("image", Boolean(token.image)),
    price: contributed("price", token.currentPrice !== null),
    priceChange24h: contributed("priceChange24h", token.priceChangePercent24h !== null),
    marketCap: contributed("marketCap", token.marketCap !== null),
    volume24h: contributed("volume24h", token.volume24h !== null),
    liquidity: contributed("liquidity", token.liquidity !== null),
    verification: contributed("verification", true) ?? [source],
    security: contributed("security", true) ?? [source],
  };
  return {
    id: token.id,
    coinId: null,
    symbol: token.symbol,
    name: token.name,
    image: token.image,
    currentPrice: token.currentPrice,
    marketCap: token.marketCap,
    marketCapRank: token.marketCapRank,
    volume24h: token.volume24h,
    liquidity: token.liquidity,
    priceChangePercent24h: token.priceChangePercent24h,
    decimals: token.decimals,
    chain: token.chain,
    contractAddress: token.contractAddress,
    identifier: token.contractAddress ?? "native",
    verificationStatus: "unverified",
    securityStatus: token.securityStatus,
    source,
    sources: token.sources,
    fieldSources,
    marketDataAvailable: token.marketDataAvailable,
  };
}

function providerRelevanceScore(token: NormalizedProviderToken, query: string): number {
  const q = query.toLowerCase();
  const symbol = token.symbol.toLowerCase();
  const name = token.name.toLowerCase();
  const address = token.contractAddress?.toLowerCase() ?? "";
  if (address && address === q) return 5000;
  if (symbol === q) return 4000;
  if (name === q) return 3900;
  if (symbol.startsWith(q)) return 3000;
  if (name.startsWith(q)) return 2900;
  if (symbol.includes(q)) return 2000;
  if (name.includes(q)) return 1900;
  return 1000;
}

export function rankProviderTokens(tokens: NormalizedProviderToken[], query: string): NormalizedProviderToken[] {
  return dedupeProviderTokens(tokens).sort((a, b) => {
    const relevance = providerRelevanceScore(b, query) - providerRelevanceScore(a, query);
    if (relevance !== 0) return relevance;
    const liquidity = (b.liquidity ?? -1) - (a.liquidity ?? -1);
    if (liquidity !== 0) return liquidity;
    const volume = (b.volume24h ?? -1) - (a.volume24h ?? -1);
    if (volume !== 0) return volume;
    return a.name.localeCompare(b.name);
  });
}

export async function searchMarketTokens(query: string): Promise<MarketToken[]> {
  const normalizedQuery = query.trim();
  if (!normalizedQuery) return [];
  const redisKey = normalizedQuery.toLowerCase();
  const cached = await getCachedMarketJson<MarketToken[]>("search", redisKey);
  if (cached) return cached;

  // Address searches go to the capability orchestrator first. A provider result
  // is still UNVERIFIED until it is matched to an approved PAXI asset/listing.
  const orchestrated = await orchestratedSearchTokens(normalizedQuery);
  const providerTokens = rankProviderTokens(orchestrated.value ?? [], normalizedQuery);

  let coingeckoTokens: MarketToken[] = [];
  try {
    const url = `${COINGECKO_BASE}/search?query=${encodeURIComponent(normalizedQuery)}`;
    const data = await cachedFetch<any>(`search:${normalizedQuery.toLowerCase()}`, url);
    const candidates = rankAndDedupeSearchCandidates(
      Array.isArray(data.coins)
        ? data.coins.slice(0, 30).map((c: any) => ({
            id: typeof c.id === "string" ? c.id : "",
            name: typeof c.name === "string" ? c.name : "Unknown token",
            symbol: typeof c.symbol === "string" ? c.symbol : "",
            marketCapRank: finiteNumber(c.market_cap_rank),
            thumb: c.thumb,
            large: c.large,
          }))
        : [],
      normalizedQuery,
    );
    const selected = candidates.slice(0, 15);
    const coinIds = selected.map((c) => c.id);
    if (coinIds.length) {
      const priceUrl = `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${coinIds.join(",")}&price_change_percentage=24h`;
      const priced = await cachedFetch<any[]>(`search-prices:${coinIds.join(",")}`, priceUrl);
      const pricedById = new Map(priced.map((c) => [c.id, c]));
      coingeckoTokens = selected.flatMap((candidate) => {
        const c = pricedById.get(candidate.id);
        if (!c) return [];
        const token = marketTokenFromCoinGecko(c, candidate.id);
        if (!token.image) token.image = safeImageUrl(candidate.large) || safeImageUrl(candidate.thumb);
        if (!token.symbol) token.symbol = candidate.symbol.toUpperCase();
        if (!token.name) token.name = candidate.name;
        return [token];
      });
    }
  } catch (error) {
    console.warn("[marketData] CoinGecko search unavailable:", error instanceof Error ? error.message : "provider error");
  }

  // Provider results are canonical when they carry chain + address. CoinGecko
  // rows remain useful global enrichment, but never merge with an address-only
  // result merely because symbol/name happens to match.
  const result = [...providerTokens.map(marketTokenFromProvider), ...coingeckoTokens].slice(0, 30);
  await setCachedMarketJson("search", redisKey, result);
  return result;
}

export interface ChartResponse {
  points: Array<{
    timestamp: number;
    open: number | null;
    high: number | null;
    low: number | null;
    close: number;
    volume: number | null;
  }>;
  source: "birdeye" | "dexpaprika" | "coingecko" | "binance" | "unavailable";
  historicalAvailable: boolean;
}

function canonicalIdentity(input: CanonicalMarketIdentity | string): CanonicalMarketIdentity {
  if (typeof input === "string") return { chain: null, contractAddress: null, coinId: input };
  const chain = normalizeMarketChain(input.chain) ?? input.chain ?? null;
  const resolved = resolveAssetIdentity({
    chain,
    contractAddress: input.contractAddress,
    kind: input.contractAddress ? "token" : "native",
  });
  return {
    chain: resolved?.chain ?? chain,
    contractAddress: resolved?.kind === "token" ? resolved.contractOrMint : input.contractAddress ? normalizeProviderAddress(chain, input.contractAddress) : null,
    coinId: input.coinId ?? null,
  };
}

function chartResponse(result: ProviderChartResult | null): ChartResponse {
  return result
    ? { points: result.points, source: result.source, historicalAvailable: result.historicalAvailable }
    : { points: [], source: "unavailable", historicalAvailable: false };
}

function identityCacheKey(identity: CanonicalMarketIdentity): string {
  const resolved = identity.chain
    ? resolveAssetIdentity({ chain: identity.chain, contractAddress: identity.contractAddress, kind: identity.contractAddress ? "token" : "native" })
    : null;
  const baseKey = resolved ? getAssetIdentityKey(resolved) : `${identity.chain ?? "unknown"}:${identity.contractAddress ?? "native"}`;
  return `${baseKey}${identity.coinId ? `:${identity.coinId}` : ""}`;
}

/** Preferred chain-specific provider candles, then DexPaprika highest-volume pool candles, then CoinGecko only when a coinId is available. */
export async function getMarketChart(input: CanonicalMarketIdentity | string, timeframe: number | "max" | MarketChartTimeframe): Promise<ChartResponse> {
  const identity = canonicalIdentity(input);
  const redisKey = `${identityCacheKey(identity)}:${timeframe}`;
  const cached = await getCachedMarketJson<ChartResponse>("chart", redisKey);
  if (cached) return cached;
  if (identity.chain && identity.contractAddress) {
    const orchestrated = await orchestratedChart(identity, timeframe);
    if (orchestrated.value?.points.length) {
      const result = chartResponse(orchestrated.value);
      await setCachedMarketJson("chart", redisKey, result);
      return result;
    }
  }
  if (identity.coinId) {
    const coingeckoDays = typeof timeframe === "string"
      ? (timeframe === "ALL" ? "max" : timeframe === "1H" ? 1 : timeframe === "1D" ? 1 : timeframe === "1W" ? 7 : timeframe === "1M" ? 30 : timeframe === "3M" ? 90 : 365)
      : timeframe;
    const url = `${COINGECKO_BASE}/coins/${encodeURIComponent(identity.coinId)}/market_chart?vs_currency=usd&days=${coingeckoDays}`;
    try {
      const data = await cachedFetch<any>(`chart:${identity.coinId}:${timeframe}`, url);
      const points = (Array.isArray(data?.prices) ? data.prices : [])
        .map((pair: unknown) => Array.isArray(pair) ? normalizeHistoricalPoint({ timestamp: pair[0], close: pair[1] }) : null)
        .filter(Boolean) as NonNullable<ReturnType<typeof normalizeHistoricalPoint>>[];
      if (points.length) {
        const result = { points, source: "coingecko" as const, historicalAvailable: true };
        await setCachedMarketJson("chart", redisKey, result);
        return result;
      }
    } catch (error) {
      console.warn("[marketData] CoinGecko chart unavailable:", error instanceof Error ? error.message : "provider error");
    }
  }
  const unavailable = chartResponse(null);
  await setCachedMarketJson("chart", redisKey, unavailable);
  return unavailable;
}

export interface TokenDetail extends MarketToken {
  description: string;
  homepage: string | null;
  explorerUrl: string | null;
  /** CoinGecko platform slug used only for the existing Add-to-Wallet mapping. */
  platformId: string | null;
  circulatingSupply: number | null;
  totalSupply: number | null;
  maxSupply: number | null;
  athUsd: number | null;
  athDate: string | null;
  atlUsd: number | null;
  atlDate: string | null;
  priceChangePercent7d: number | null;
  priceChangePercent30d: number | null;
}

function detailFromProvider(token: NormalizedProviderToken, identity: CanonicalMarketIdentity): TokenDetail {
  return {
    ...marketTokenFromProvider(token),
    id: token.id,
    coinId: identity.coinId ?? null,
    chain: identity.chain ?? token.chain,
    contractAddress: identity.contractAddress ?? token.contractAddress,
    identifier: identity.contractAddress ?? token.contractAddress ?? "native",
    description: "",
    homepage: null,
    explorerUrl: null,
    platformId: identity.chain,
    circulatingSupply: null,
    totalSupply: null,
    maxSupply: null,
    athUsd: null,
    athDate: null,
    atlUsd: null,
    atlDate: null,
    priceChangePercent7d: null,
    priceChangePercent30d: null,
  };
}

export async function getTokenDetail(input: CanonicalMarketIdentity | string): Promise<TokenDetail | null> {
  const identity = canonicalIdentity(input);
  const redisKey = identityCacheKey(identity);
  const cached = await getCachedMarketJson<TokenDetail>("detail", redisKey);
  if (cached) return cached;
  if (identity.chain && identity.contractAddress) {
    const orchestrated = await orchestratedTokenMetadata(identity);
    if (orchestrated.value) {
      const detail = detailFromProvider(orchestrated.value, identity);
      await setCachedMarketJson("detail", redisKey, detail);
      return detail;
    }
  }

  if (!identity.coinId) return null;
  const url = `${COINGECKO_BASE}/coins/${encodeURIComponent(identity.coinId)}?localization=false&tickers=false&community_data=false&developer_data=false&sparkline=false`;
  try {
    const c = await cachedFetch<any>(`detail:${identity.coinId}`, url);
    const platforms = c.platforms ?? {};
    const matchingPlatform = identity.chain
      ? Object.entries(platforms).find(([platform, addr]) => normalizeMarketChain(platform) === identity.chain && typeof addr === "string" && addr)
      : null;
    const firstPlatformEntry = matchingPlatform ?? Object.entries(platforms).find(([, addr]) => typeof addr === "string" && addr);
    const contractAddress = identity.contractAddress ?? (firstPlatformEntry ? normalizeProviderAddress(normalizeMarketChain(firstPlatformEntry[0]), firstPlatformEntry[1]) : null);
    const chain = identity.chain ?? (firstPlatformEntry ? normalizeMarketChain(firstPlatformEntry[0]) : null);
    const detail: TokenDetail = {
      id: c.id,
      coinId: identity.coinId,
      symbol: (c.symbol ?? "").toUpperCase(),
      name: c.name ?? "Unknown token",
      image: safeImageUrl(c.image?.large ?? c.image?.small),
      currentPrice: finiteNumber(c.market_data?.current_price?.usd),
      marketCap: finiteNumber(c.market_data?.market_cap?.usd),
      marketCapRank: finiteNumber(c.market_cap_rank),
      volume24h: finiteNumber(c.market_data?.total_volume?.usd),
      liquidity: null,
      priceChangePercent24h: finiteNumber(c.market_data?.price_change_percentage_24h),
      decimals: null,
      chain,
      contractAddress,
      identifier: contractAddress ?? "native",
      verificationStatus: "unverified",
      securityStatus: "unavailable",
      source: "coingecko",
      sources: ["coingecko"],
      fieldSources: {
        identity: ["coingecko"],
        name: c.name ? ["coingecko"] : undefined,
        symbol: c.symbol ? ["coingecko"] : undefined,
        image: safeImageUrl(c.image?.large ?? c.image?.small) ? ["coingecko"] : undefined,
        price: finiteNumber(c.market_data?.current_price?.usd) !== null ? ["coingecko"] : undefined,
        priceChange24h: finiteNumber(c.market_data?.price_change_percentage_24h) !== null ? ["coingecko"] : undefined,
        marketCap: finiteNumber(c.market_data?.market_cap?.usd) !== null ? ["coingecko"] : undefined,
        volume24h: finiteNumber(c.market_data?.total_volume?.usd) !== null ? ["coingecko"] : undefined,
        verification: ["coingecko"],
        security: ["coingecko"],
      },
      marketDataAvailable: finiteNumber(c.market_data?.current_price?.usd) !== null,
      priceChangePercent7d: finiteNumber(c.market_data?.price_change_percentage_7d),
      priceChangePercent30d: finiteNumber(c.market_data?.price_change_percentage_30d),
      description: (c.description?.en ?? "").split("\r\n")[0] ?? "",
      homepage: c.links?.homepage?.[0] || null,
      explorerUrl: c.links?.blockchain_site?.find((s: string) => s) || null,
      platformId: firstPlatformEntry ? firstPlatformEntry[0] : null,
      circulatingSupply: finiteNumber(c.market_data?.circulating_supply),
      totalSupply: finiteNumber(c.market_data?.total_supply),
      maxSupply: finiteNumber(c.market_data?.max_supply),
      athUsd: finiteNumber(c.market_data?.ath?.usd),
      athDate: c.market_data?.ath_date?.usd ?? null,
      atlUsd: finiteNumber(c.market_data?.atl?.usd),
      atlDate: c.market_data?.atl_date?.usd ?? null,
    };
    if (detail.currentPrice !== null && detail.volume24h !== null && detail.marketCap !== null) {
      syncAssetFromCoinGeckoDetail({ ...detail, currentPrice: detail.currentPrice, volume24h: detail.volume24h, marketCap: detail.marketCap }).catch((err) =>
        console.warn("[marketData] asset registry sync failed (non-fatal):", identity.coinId, err),
      );
    }
    await setCachedMarketJson("detail", redisKey, detail);
    return detail;
  } catch (error) {
    console.warn("[marketData] CoinGecko detail unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

/** Compatibility helpers retained for the latest archive's existing chart tests and callers. */
const BINANCE_CHART_SYMBOLS: Record<string, string> = {
  bitcoin: "BTCUSDT",
  "wrapped-bitcoin": "BTCUSDT",
  ethereum: "ETHUSDT",
  binancecoin: "BNBUSDT",
  solana: "SOLUSDT",
  "polygon-ecosystem-token": "POLUSDT",
  "usd-coin": "USDCUSDT",
  tether: "USDTUSDT",
  dai: "DAIUSDT",
  dogecoin: "DOGEUSDT",
  xrp: "XRPUSDT",
  cardano: "ADAUSDT",
  "avalanche-2": "AVAXUSDT",
  chainlink: "LINKUSDT",
  tron: "TRXUSDT",
  shiba: "SHIBUSDT",
  "shiba-inu": "SHIBUSDT",
};

export function getBinanceChartConfig(days: number | "max"): { interval: string; limit: number } {
  if (days === 1) return { interval: "1h", limit: 24 };
  if (days === 7) return { interval: "4h", limit: 42 };
  if (days === 30) return { interval: "1d", limit: 30 };
  if (days === 365) return { interval: "1w", limit: 52 };
  return { interval: "1w", limit: 1000 };
}

export function getBinanceChartSymbolCandidates(coinId: string, marketSymbol?: string | null): string[] {
  const known = BINANCE_CHART_SYMBOLS[coinId];
  const normalizedSymbol = marketSymbol?.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  return [...new Set([
    known,
    normalizedSymbol && normalizedSymbol !== "USDT" ? `${normalizedSymbol}USDT` : undefined,
  ].filter((value): value is string => Boolean(value)))];
}

export interface AssetStats {
  source: "coingecko" | "dexscreener";
  /** Providers that contributed fields to this held-asset statistics response. */
  sources: Array<"coingecko" | "dexscreener">;
  priceUsd: number | null;
  priceChangePercent24h: number | null;
  marketCap: number | null;
  volume24h: number | null;
  liquidityUsd: number | null;
  circulatingSupply: number | null;
  totalSupply: number | null;
  circulatingSupplyPct: number | null;
  genesisDate: string | null;
  homepage: string | null;
  twitter: string | null;
  reddit: string | null;
  whitepaper: string | null;
  dexPairUrl: string | null;
  dexId: string | null;
}

/** Backward-compatible held-asset statistics for the existing Asset Detail screen. */
export async function getAssetStats(params: {
  coinId?: string;
  network?: string;
  contractAddress?: string;
}): Promise<AssetStats | null> {
  if (params.coinId) {
    const url = `${COINGECKO_BASE}/coins/${encodeURIComponent(params.coinId)}?localization=false&tickers=false&community_data=false&developer_data=false&sparkline=false`;
    try {
      const c = await cachedFetch<any>(`detail:${params.coinId}`, url);
      const circulating = finiteNumber(c.market_data?.circulating_supply);
      const total = finiteNumber(c.market_data?.total_supply);
      return {
        source: "coingecko",
        sources: ["coingecko"],
        priceUsd: finiteNumber(c.market_data?.current_price?.usd),
        priceChangePercent24h: finiteNumber(c.market_data?.price_change_percentage_24h),
        marketCap: finiteNumber(c.market_data?.market_cap?.usd),
        volume24h: finiteNumber(c.market_data?.total_volume?.usd),
        liquidityUsd: null,
        circulatingSupply: circulating,
        totalSupply: total,
        circulatingSupplyPct: circulating !== null && total !== null && total > 0 ? (circulating / total) * 100 : null,
        genesisDate: typeof c.genesis_date === "string" ? c.genesis_date : null,
        homepage: c.links?.homepage?.[0] || null,
        twitter: c.links?.twitter_screen_name ? `https://x.com/${c.links.twitter_screen_name}` : null,
        reddit: c.links?.subreddit_url || null,
        whitepaper: c.links?.whitepaper || null,
        dexPairUrl: null,
        dexId: null,
      };
    } catch {
      // Fall through to the address-based DEX path.
    }
  }

  const marketChain = params.network ? normalizeMarketChain(params.network) : null;
  if (marketChain && params.contractAddress) {
    const orchestrated = await orchestratedLiquidity({ chain: marketChain, contractAddress: params.contractAddress });
    const snapshot = orchestrated.value;
    if (snapshot) {
      const { pair } = snapshot;
      return {
        source: snapshot.source,
        sources: [snapshot.source],
        priceUsd: snapshot.tokenPriceUsd,
        priceChangePercent24h: finiteNumber(pair.priceChange?.h24),
        marketCap: null,
        volume24h: finiteNumber(pair.volume?.h24),
        liquidityUsd: finiteNumber(pair.liquidity?.usd),
        circulatingSupply: null,
        totalSupply: null,
        circulatingSupplyPct: null,
        genesisDate: null,
        homepage: null,
        twitter: null,
        reddit: null,
        whitepaper: null,
        dexPairUrl: pair.pairAddress ? `https://dexscreener.com/${pair.chainId}/${pair.pairAddress}` : null,
        dexId: pair.dexId ?? null,
      };
    }
  }

  return null;
}
