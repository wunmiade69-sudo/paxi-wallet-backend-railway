/**
 * Real market data via CoinGecko's public API - this is how "thousands of
 * tokens, without maintaining them yourself" actually works: fetch from a
 * market data provider, don't hand-curate a list.
 *
 * CoinGecko's free tier is rate-limited (roughly 10-30 calls/min), so
 * results are cached three ways, cheapest first:
 *   1. In-memory (per server process) - near-zero latency, but wiped on
 *      every restart and not shared across instances.
 *   2. Our own DB (marketDataCache table) - survives restarts, shared by
 *      every server instance, so the Markets list and Token Detail chart
 *      are served from *our* data instead of waiting on CoinGecko live.
 *   3. CoinGecko itself - only hit when nothing is cached anywhere yet, or
 *      when a background refresh decides the DB copy is due for one.
 *
 * Reads never block on a refresh: if the DB has anything at all, it's
 * returned immediately, and a refresh (if the entry is stale) happens
 * afterwards in the background (stale-while-revalidate). A background
 * timer also proactively keeps the most-viewed Markets pages warm so
 * they're rarely even stale by the time someone loads them.
 */
import { eq } from "drizzle-orm";
import { marketDataCache } from "../drizzle/schema";
import { getDb } from "./db";
import { getTokenMarketSnapshot, resolveTokenPriceUsd } from "./dexLiquidity";
import { syncAssetFromCoinGeckoDetail } from "./assetRegistry";

const COINGECKO_BASE = "https://api.coingecko.com/api/v3";
/** Optional CoinGecko "Demo" API key (free, no card needed - coingecko.com/en/developers/dashboard).
 * Raises the rate limit well above the anonymous public endpoint used when this is unset. */
const COINGECKO_API_KEY = process.env.COINGECKO_API_KEY;
const COINGECKO_HEADERS: Record<string, string> = COINGECKO_API_KEY ? { "x-cg-demo-api-key": COINGECKO_API_KEY } : {};
const CACHE_TTL_MS = 60_000; // how long an in-memory hit is considered fresh
const DB_STALE_MS = 5 * 60_000; // how long a DB entry is served without triggering a background refresh

interface CacheEntry {
  data: unknown;
  expiresAt: number;
}
const memCache = new Map<string, CacheEntry>();
const inFlight = new Map<string, Promise<unknown>>();

async function readDbCache(cacheKey: string): Promise<{ data: unknown; ageMs: number } | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const rows = await db.select().from(marketDataCache).where(eq(marketDataCache.cacheKey, cacheKey)).limit(1);
    if (!rows.length) return null;
    return { data: rows[0].payload, ageMs: Date.now() - new Date(rows[0].updatedAt).getTime() };
  } catch (err) {
    console.warn("[marketData] DB cache read failed, falling back to live fetch:", err);
    return null;
  }
}

async function writeDbCache(cacheKey: string, data: unknown): Promise<void> {
  const db = await getDb();
  if (!db) return;
  try {
    await db
      .insert(marketDataCache)
      .values({ cacheKey, payload: data as any })
      .onDuplicateKeyUpdate({ set: { payload: data as any } });
  } catch (err) {
    console.warn("[marketData] DB cache write failed (non-fatal):", err);
  }
}

/** Fetches from CoinGecko and populates both cache layers. Coalesces concurrent callers for the same key. */
function refreshInBackground<T>(cacheKey: string, url: string): Promise<T> {
  const existing = inFlight.get(cacheKey);
  if (existing) return existing as Promise<T>;

  const promise = (async () => {
    const res = await fetch(url, { headers: COINGECKO_HEADERS, signal: AbortSignal.timeout(10_000) });
    if (!res.ok) throw new Error(`CoinGecko request failed (${res.status})`);
    const data = (await res.json()) as T;
    memCache.set(cacheKey, { data, expiresAt: Date.now() + CACHE_TTL_MS });
    await writeDbCache(cacheKey, data);
    return data;
  })().finally(() => inFlight.delete(cacheKey));

  inFlight.set(cacheKey, promise);
  return promise;
}

async function cachedFetch<T>(cacheKey: string, url: string): Promise<T> {
  // 1. Hot in-memory hit - fastest path, no DB round trip at all.
  const mem = memCache.get(cacheKey);
  if (mem && mem.expiresAt > Date.now()) return mem.data as T;

  // 2. Our own DB - instant, survives restarts, shared across instances.
  const dbEntry = await readDbCache(cacheKey);
  if (dbEntry) {
    memCache.set(cacheKey, { data: dbEntry.data, expiresAt: Date.now() + CACHE_TTL_MS });
    if (dbEntry.ageMs > DB_STALE_MS) {
      // Stale-while-revalidate: caller still gets the DB copy instantly.
      refreshInBackground(cacheKey, url).catch((err) => console.warn("[marketData] background refresh failed:", cacheKey, err));
    }
    return dbEntry.data as T;
  }

  // 3. Nothing cached anywhere yet - the only path that waits on CoinGecko live.
  try {
    return await refreshInBackground<T>(cacheKey, url);
  } catch (err) {
    throw err instanceof Error ? err : new Error(String(err));
  }
}

/** The Markets list pages people actually land on. Kept warm proactively so they're almost never a cold/stale read. */
const HOT_MARKET_PAGES: Array<{ page: number; perPage: number; order: MarketOrder }> = [
  { page: 1, perPage: 50, order: "market_cap_desc" },
  { page: 2, perPage: 50, order: "market_cap_desc" },
  { page: 1, perPage: 50, order: "volume_desc" },
  { page: 1, perPage: 50, order: "price_change_percentage_24h_desc" },
  { page: 1, perPage: 50, order: "price_change_percentage_24h_asc" },
];

let prewarmTimer: ReturnType<typeof setInterval> | null = null;
let prewarmCursor = 0;
let prewarmInFlight = false;

/** Call once on server boot. Refreshes one hot Markets page at a time so anonymous CoinGecko
 * rate limits cannot be exhausted by a burst of five simultaneous requests. */
export function startMarketDataPrewarm(): void {
  if (prewarmTimer) return;
  const tick = async () => {
    if (prewarmInFlight) return;
    prewarmInFlight = true;
    const page = HOT_MARKET_PAGES[prewarmCursor % HOT_MARKET_PAGES.length];
    prewarmCursor += 1;
    try {
      await listMarketTokens(page);
    } catch (err) {
      console.warn("[marketData] prewarm failed:", page, err);
    } finally {
      prewarmInFlight = false;
    }
  };
  void tick();
  prewarmTimer = setInterval(() => void tick(), CACHE_TTL_MS);
}

export interface MarketToken {
  id: string;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number;
  marketCap: number;
  marketCapRank: number | null;
  volume24h: number;
  priceChangePercent24h: number | null;
}

export type MarketOrder = "market_cap_desc" | "price_change_percentage_24h_desc" | "price_change_percentage_24h_asc" | "volume_desc";

/** CoinGecko's `order` param on /coins/markets only actually supports market_cap and volume
 * sorts (see their docs) - passing a price-change value is silently ignored server-side and
 * you just get market-cap order back, so "Top Gainers"/"Top Losers" would show whatever's
 * biggest by market cap that day, not the coins that actually moved the most. Sorting by
 * 24h % change has to happen here instead, against a real ranked pool. */
const GAINER_LOSER_POOL_SIZE = 250; // CoinGecko's per_page max in one call - one request, cached, covers every page

export async function listMarketTokens(params: { page: number; perPage: number; order: MarketOrder }): Promise<MarketToken[]> {
  const { page, perPage, order } = params;

  if (order === "price_change_percentage_24h_desc" || order === "price_change_percentage_24h_asc") {
    const url =
      `${COINGECKO_BASE}/coins/markets?vs_currency=usd&order=market_cap_desc` +
      `&per_page=${GAINER_LOSER_POOL_SIZE}&page=1&sparkline=false&price_change_percentage=24h`;
    const data = await cachedFetch<any[]>(`markets:24h-pool:${GAINER_LOSER_POOL_SIZE}`, url);

    const sorted = [...data]
      .filter((c) => typeof c.price_change_percentage_24h === "number")
      .sort((a, b) =>
        order === "price_change_percentage_24h_desc"
          ? b.price_change_percentage_24h - a.price_change_percentage_24h
          : a.price_change_percentage_24h - b.price_change_percentage_24h
      );

    const start = (page - 1) * perPage;
    return sorted.slice(start, start + perPage).map((c) => ({
      id: c.id,
      symbol: (c.symbol ?? "").toUpperCase(),
      name: c.name,
      image: c.image,
      currentPrice: c.current_price,
      marketCap: c.market_cap,
      marketCapRank: c.market_cap_rank,
      volume24h: c.total_volume,
      priceChangePercent24h: c.price_change_percentage_24h,
    }));
  }

  const url =
    `${COINGECKO_BASE}/coins/markets?vs_currency=usd&order=${order}` +
    `&per_page=${perPage}&page=${page}&sparkline=false&price_change_percentage=24h`;

  const data = await cachedFetch<any[]>(`markets:${order}:${page}:${perPage}`, url);

  return data.map((c) => ({
    id: c.id,
    symbol: (c.symbol ?? "").toUpperCase(),
    name: c.name,
    image: c.image,
    currentPrice: c.current_price,
    marketCap: c.market_cap,
    marketCapRank: c.market_cap_rank,
    volume24h: c.total_volume,
    priceChangePercent24h: c.price_change_percentage_24h,
  }));
}

export async function searchMarketTokens(query: string): Promise<MarketToken[]> {
  if (!query.trim()) return [];
  const url = `${COINGECKO_BASE}/search?query=${encodeURIComponent(query.trim())}`;
  const data = await cachedFetch<any>(`search:${query.trim().toLowerCase()}`, url);

  const coinIds: string[] = (data.coins ?? []).slice(0, 15).map((c: any) => c.id);
  if (coinIds.length === 0) return [];

  // Search results don't include live price data - fetch it for just the matched coins.
  const priceUrl = `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${coinIds.join(",")}&price_change_percentage=24h`;
  const priced = await cachedFetch<any[]>(`search-prices:${coinIds.join(",")}`, priceUrl);

  return priced.map((c) => ({
    id: c.id,
    symbol: (c.symbol ?? "").toUpperCase(),
    name: c.name,
    image: c.image,
    currentPrice: c.current_price,
    marketCap: c.market_cap,
    marketCapRank: c.market_cap_rank,
    volume24h: c.total_volume,
    priceChangePercent24h: c.price_change_percentage_24h,
  }));
}

export interface ChartPoint {
  timestamp: number;
  price: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
  volume?: number | null;
  source?: string;
  fallback?: boolean;
}

const BINANCE_CHART_SYMBOLS: Record<string, string> = {
  bitcoin: 'BTCUSDT',
  'wrapped-bitcoin': 'BTCUSDT',
  ethereum: 'ETHUSDT',
  binancecoin: 'BNBUSDT',
  solana: 'SOLUSDT',
  'polygon-ecosystem-token': 'POLUSDT',
  'usd-coin': 'USDCUSDT',
  tether: 'USDTUSDT',
  dai: 'DAIUSDT',
  dogecoin: 'DOGEUSDT',
  xrp: 'XRPUSDT',
  cardano: 'ADAUSDT',
  'avalanche-2': 'AVAXUSDT',
  chainlink: 'LINKUSDT',
  tron: 'TRXUSDT',
  shiba: 'SHIBUSDT',
  'shiba-inu': 'SHIBUSDT',
};

export function getBinanceChartConfig(days: number | 'max'): { interval: string; limit: number } {
  if (days === 1) return { interval: '1h', limit: 24 };
  if (days === 7) return { interval: '4h', limit: 42 };
  if (days === 30) return { interval: '1d', limit: 30 };
  if (days === 365) return { interval: '1w', limit: 52 };
  return { interval: '1w', limit: 1000 };
}

export function getBinanceChartSymbolCandidates(coinId: string, marketSymbol?: string | null): string[] {
  const known = BINANCE_CHART_SYMBOLS[coinId];
  const normalizedSymbol = marketSymbol?.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  return [...new Set([known, normalizedSymbol && normalizedSymbol !== "USDT" ? `${normalizedSymbol}USDT` : undefined].filter((value): value is string => Boolean(value)))];
}

async function getBinanceChart(coinId: string, days: number | 'max', marketSymbol?: string | null): Promise<ChartPoint[]> {
  const symbols = getBinanceChartSymbolCandidates(coinId, marketSymbol);
  if (symbols.length === 0) return [];
  const { interval, limit } = getBinanceChartConfig(days);
  for (const symbol of symbols) {
    try {
      const response = await fetch(
        `https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
        { signal: AbortSignal.timeout(8000) }
      );
      if (!response.ok) continue;
      const rows = (await response.json()) as Array<Array<string | number>>;
      const chart = rows
        .map((row): ChartPoint | null => {
          const timestamp = Number(row[0]);
          const open = Number(row[1]);
          const high = Number(row[2]);
          const low = Number(row[3]);
          const close = Number(row[4]);
          const volume = Number(row[5]);
          if (![timestamp, open, high, low, close].every(Number.isFinite)) return null;
          return { timestamp, price: close, open, high, low, close, volume, source: 'binance', fallback: true };
        })
        .filter((row): row is ChartPoint => row !== null);
      if (chart.length > 0) return chart;
    } catch {
      // Try the next compatible market symbol. The CoinGecko path has already failed.
    }
  }
  return [];
}

/** days: 1 = 1D (hourly-ish points), 7 = 1W, 30 = 1M, 365 = 1Y, "max" = All. */
export async function getMarketChart(coinId: string, days: number | "max", marketSymbol?: string | null): Promise<ChartPoint[]> {
  const url = `${COINGECKO_BASE}/coins/${coinId}/market_chart?vs_currency=usd&days=${days}`;
  try {
    const data = await cachedFetch<any>(`chart:${coinId}:${days}`, url);
    const prices: [number, number][] = data.prices ?? [];
    if (prices.length > 0) {
      return prices.map(([timestamp, price]) => ({
        timestamp,
        price,
        open: price,
        high: price,
        low: price,
        close: price,
        volume: null,
        source: 'coingecko',
        fallback: true,
      }));
    }
  } catch {
    // Binance fallback below
  }
  return getBinanceChart(coinId, days, marketSymbol);
}

export interface TokenDetail extends MarketToken {
  description: string;
  homepage: string | null;
  explorerUrl: string | null;
  contractAddress: string | null;
  /** CoinGecko's platform slug for `contractAddress` (e.g. "ethereum", "binance-smart-chain",
   * "polygon-pos") - the client maps this to its own network ids to offer "Add to Wallet". */
  platformId: string | null;
  circulatingSupply: number | null;
  totalSupply: number | null;
  maxSupply: number | null;
  athUsd: number | null;
  athDate: string | null;
  atlUsd: number | null;
  atlDate: string | null;
  priceChangePercent7d: number | null;
  priceChangePercent30d: number | null;
}

export async function getTokenDetail(coinId: string): Promise<TokenDetail | null> {
  const url = `${COINGECKO_BASE}/coins/${coinId}?localization=false&tickers=false&community_data=false&developer_data=false&sparkline=false`;
  try {
    const c = await cachedFetch<any>(`detail:${coinId}`, url);
    const platforms = c.platforms ?? {};
    const firstPlatformEntry = Object.entries(platforms).find(([, addr]) => typeof addr === "string" && addr);

    const detail: TokenDetail = {
      id: c.id,
      symbol: (c.symbol ?? "").toUpperCase(),
      name: c.name,
      image: c.image?.large ?? c.image?.small ?? "",
      currentPrice: c.market_data?.current_price?.usd ?? 0,
      marketCap: c.market_data?.market_cap?.usd ?? 0,
      marketCapRank: c.market_cap_rank ?? null,
      volume24h: c.market_data?.total_volume?.usd ?? 0,
      priceChangePercent24h: c.market_data?.price_change_percentage_24h ?? null,
      priceChangePercent7d: c.market_data?.price_change_percentage_7d ?? null,
      priceChangePercent30d: c.market_data?.price_change_percentage_30d ?? null,
      description: (c.description?.en ?? "").split("\r\n")[0] ?? "",
      homepage: c.links?.homepage?.[0] || null,
      explorerUrl: c.links?.blockchain_site?.find((s: string) => s) || null,
      contractAddress: firstPlatformEntry ? (firstPlatformEntry[1] as string) : null,
      platformId: firstPlatformEntry ? firstPlatformEntry[0] : null,
      circulatingSupply: c.market_data?.circulating_supply ?? null,
      totalSupply: c.market_data?.total_supply ?? null,
      maxSupply: c.market_data?.max_supply ?? null,
      athUsd: c.market_data?.ath?.usd ?? null,
      athDate: c.market_data?.ath_date?.usd ?? null,
      atlUsd: c.market_data?.atl?.usd ?? null,
      atlDate: c.market_data?.atl_date?.usd ?? null,
    };
    // Fire-and-forget: every real CoinGecko lookup grows PAXI's own asset registry, so over
    // time the wallet needs CoinGecko less and less for tokens it's already seen once.
    syncAssetFromCoinGeckoDetail(detail).catch((err) => console.warn("[marketData] asset registry sync failed (non-fatal):", coinId, err));
    return detail;
  } catch {
    // A detail request can be rate-limited even while the cached Markets list is healthy.
    // Return the cached summary so the user can still open the token and its chart fallback.
    try {
      const marketSummary = (await listMarketTokens({ page: 1, perPage: 50, order: "market_cap_desc" })).find((row) => row.id === coinId);
      if (marketSummary) {
        return {
          ...marketSummary,
          description: "Market details are temporarily limited; live market data is shown from the cached summary.",
          homepage: null,
          explorerUrl: null,
          contractAddress: null,
          platformId: null,
          circulatingSupply: null,
          totalSupply: null,
          maxSupply: null,
          athUsd: null,
          athDate: null,
          atlUsd: null,
          atlDate: null,
          priceChangePercent7d: null,
          priceChangePercent30d: null,
        };
      }
    } catch {
      // No cached summary is available; preserve the existing null contract.
    }
    return null;
  }
}

export interface AssetStats {
  source: "coingecko" | "dexscreener";
  priceUsd: number | null;
  priceChangePercent24h: number | null;
  marketCap: number | null; // fully-diluted valuation, when sourced from DexScreener - see AssetStats.source
  volume24h: number | null;
  liquidityUsd: number | null; // DexScreener only - CoinGecko doesn't report this
  circulatingSupply: number | null;
  totalSupply: number | null;
  circulatingSupplyPct: number | null;
  genesisDate: string | null;
  homepage: string | null;
  twitter: string | null;
  reddit: string | null;
  whitepaper: string | null;
  dexPairUrl: string | null; // DexScreener only - link to view the actual trading pair
}

/**
 * Held-asset "Stats" tab data (Dashboard > Asset Detail) - tries CoinGecko first when the asset
 * has a known coinId (real supply/social data, cached + API-keyed same as Markets/Token Detail),
 * and falls back to live on-chain DexScreener data when CoinGecko has no listing at all (a new
 * or unlisted token) or is otherwise failing. Real on-chain price/liquidity beats a permanent
 * "Couldn't load stats" for a token that's genuinely trading, just not CoinGecko-listed.
 */
export async function getAssetStats(params: {
  coinId?: string;
  network?: string;
  contractAddress?: string;
}): Promise<AssetStats | null> {
  if (params.coinId) {
    const url = `${COINGECKO_BASE}/coins/${params.coinId}?localization=false&tickers=false&community_data=false&developer_data=false&sparkline=false`;
    try {
      const c = await cachedFetch<any>(`detail:${params.coinId}`, url);
      const circulating = c.market_data?.circulating_supply ?? null;
      const total = c.market_data?.total_supply ?? null;
      return {
        source: "coingecko",
        priceUsd: c.market_data?.current_price?.usd ?? null,
        priceChangePercent24h: c.market_data?.price_change_percentage_24h ?? null,
        marketCap: c.market_data?.market_cap?.usd ?? null,
        volume24h: c.market_data?.total_volume?.usd ?? null,
        liquidityUsd: null,
        circulatingSupply: circulating,
        totalSupply: total,
        circulatingSupplyPct: circulating && total ? (circulating / total) * 100 : null,
        genesisDate: c.genesis_date ?? null,
        homepage: c.links?.homepage?.[0] || null,
        twitter: c.links?.twitter_screen_name ? `https://x.com/${c.links.twitter_screen_name}` : null,
        reddit: c.links?.subreddit_url || null,
        whitepaper: c.links?.whitepaper || null,
        dexPairUrl: null,
      };
    } catch {
      /* fall through to DexScreener below */
    }
  }

  if (params.network && params.contractAddress) {
    const pair = await getTokenMarketSnapshot(params.network, params.contractAddress);
    if (pair) {
      const priceUsd = resolveTokenPriceUsd(params.network, pair, params.contractAddress);
      return {
        source: "dexscreener",
        priceUsd,
        priceChangePercent24h: pair.priceChange?.h24 ?? null,
        marketCap: null, // DexScreener's fdv is base-token-specific like priceUsd is - not safe to report for whichever side we looked up
        volume24h: pair.volume?.h24 ?? null,
        liquidityUsd: pair.liquidity?.usd ?? null,
        circulatingSupply: null,
        totalSupply: null,
        circulatingSupplyPct: null,
        genesisDate: null,
        homepage: null,
        twitter: null,
        reddit: null,
        whitepaper: null,
        dexPairUrl: `https://dexscreener.com/${pair.chainId}/${pair.pairAddress}`,
      };
    }
  }

  return null;
}
