import { beforeEach, describe, expect, it, vi } from "vitest";

describe("provider HTTP adapters", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.restoreAllMocks();
    vi.stubEnv("BIRDEYE_API_KEY", "unit-test-birdeye-key");
    vi.stubEnv("DEXPAPRIKA_API_KEY", "");
  });

  it("sends Birdeye server headers per chain and degrades on rate limits", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: false, status: 429 });
    vi.stubGlobal("fetch", fetchMock);
    const providers = await import("./marketProviders");

    await expect(providers.searchBirdeyeTokens("PAXI")).resolves.toEqual([]);
    expect(fetchMock).toHaveBeenCalledTimes(6);
    const firstRequest = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(firstRequest[0]).toContain("/defi/v3/search?keyword=PAXI");
    expect(firstRequest[1]?.headers).toMatchObject({ "X-API-KEY": "unit-test-birdeye-key", "x-chain": "ethereum" });
    expect(firstRequest[1]?.headers).not.toHaveProperty("authorization");
  });

  it("maps the explicit 1H window to Birdeye minute candles", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ data: [{ unixTime: 1_700_000_000, o: 1, h: 2, l: 0.5, c: 1.5, v: 10 }] }),
    });
    vi.stubGlobal("fetch", fetchMock);
    const providers = await import("./marketProviders");

    const result = await providers.getBirdeyeChart({ chain: "ethereum", contractAddress: "0xabc", coinId: null }, "1H");

    expect(result?.points).toHaveLength(1);
    const request = fetchMock.mock.calls[0] as [string, RequestInit];
    const requestUrl = new URL(request[0]);
    expect(requestUrl.pathname).toBe("/defi/ohlcv");
    expect(requestUrl.searchParams.get("type")).toBe("1m");
    expect(Number(requestUrl.searchParams.get("time_to")) - Number(requestUrl.searchParams.get("time_from"))).toBe(60 * 60);
    expect(request[1]?.headers).toMatchObject({ "x-chain": "ethereum" });
  });

  it("maps every explicit timeframe to the intended Birdeye candle interval", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ data: [{ unixTime: 1_700_000_000, o: 1, h: 2, l: 0.5, c: 1.5, v: 10 }] }),
    });
    vi.stubGlobal("fetch", fetchMock);
    const providers = await import("./marketProviders");
    const expected = [
      ["1H", "1m", 60 * 60],
      ["1D", "1H", 24 * 60 * 60],
      ["1W", "4H", 7 * 24 * 60 * 60],
      ["1M", "1D", 30 * 24 * 60 * 60],
      ["3M", "1D", 90 * 24 * 60 * 60],
      ["1Y", "1D", 365 * 24 * 60 * 60],
      ["ALL", "1D", 365 * 24 * 60 * 60],
    ] as const;

    for (const [timeframe, interval, seconds] of expected) {
      await expect(providers.getBirdeyeChart({ chain: "ethereum", contractAddress: "0xabc", coinId: null }, timeframe)).resolves.toMatchObject({
        source: "birdeye",
        historicalAvailable: true,
      });
      const request = fetchMock.mock.calls.at(-1) as [string, RequestInit];
      const requestUrl = new URL(request[0]);
      expect(requestUrl.searchParams.get("type")).toBe(interval);
      expect(Number(requestUrl.searchParams.get("time_to")) - Number(requestUrl.searchParams.get("time_from"))).toBe(seconds);
    }
  });

  it("normalizes a keyless DexPaprika search response and preserves Solana mint case", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ data: [{ network: "solana", address: "MintCaseSensitive", symbol: "PAXI", name: "PAXI Token", price_usd: "1.50" }] }),
    });
    vi.stubGlobal("fetch", fetchMock);
    const providers = await import("./marketProviders");

    const result = await providers.searchDexPaprikaTokens("PAXI");

    expect(result[0]).toMatchObject({ chain: "solana", contractAddress: "MintCaseSensitive", currentPrice: 1.5 });
    const request = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(request[0]).toContain("https://api.dexpaprika.com/search?query=PAXI");
    expect(request[1]?.headers).not.toHaveProperty("authorization");
  });
});
