import { describe, expect, it } from "vitest";
import {
  dedupeProviderTokens,
  mergeProviderToken,
  normalizeHistoricalPoint,
  normalizeMarketChain,
  normalizeProviderAddress,
  type NormalizedProviderToken,
} from "./marketProviders";

function token(overrides: Partial<NormalizedProviderToken>): NormalizedProviderToken {
  return {
    id: "provider:token",
    symbol: "PAXI",
    name: "PAXI",
    chain: "ethereum",
    contractAddress: "0xabc",
    decimals: null,
    image: "",
    currentPrice: null,
    marketCap: null,
    marketCapRank: null,
    liquidity: null,
    volume24h: null,
    priceChangePercent24h: null,
    verificationStatus: "unverified",
    securityStatus: "unavailable",
    source: "dexpaprika",
    providerId: null,
    marketDataAvailable: false,
    ...overrides,
    sources: overrides.sources ?? [overrides.source ?? "dexpaprika"],
  };
}

describe("canonical provider identity", () => {
  it("normalizes EVM addresses but preserves Solana and Bitcoin identifiers", () => {
    expect(normalizeMarketChain("binance-smart-chain")).toBe("bsc");
    expect(normalizeProviderAddress("ethereum", "  0xAbC  ")).toBe("0xabc");
    expect(normalizeProviderAddress("solana", "AbCdEf")).toBe("AbCdEf");
    expect(normalizeProviderAddress("bitcoin", "Bc1QCaseSensitive")).toBe("Bc1QCaseSensitive");
  });

  it("merges duplicate provider rows only when chain and canonical address match", () => {
    const result = dedupeProviderTokens([
      token({ source: "dexpaprika", contractAddress: "0xABC", currentPrice: null }),
      token({
        source: "birdeye",
        contractAddress: "0xabc",
        image: "https://example.com/paxi.png",
        currentPrice: 1.25,
        liquidity: 900,
        fieldSources: { price: ["birdeye"], liquidity: ["birdeye"], image: ["birdeye"] },
      }),
      token({ source: "dexpaprika", chain: "bsc", contractAddress: "0xabc", currentPrice: 2 }),
    ]);

    expect(result).toHaveLength(2);
    const ethereum = result.find((item) => item.chain === "ethereum");
    expect(ethereum).toMatchObject({
      currentPrice: 1.25,
      liquidity: 900,
      image: "https://example.com/paxi.png",
      sources: ["dexpaprika", "birdeye"],
    });
    expect(ethereum?.fieldSources?.price).toEqual(["birdeye"]);
    expect(ethereum?.fieldSources?.liquidity).toEqual(["birdeye"]);
    expect(ethereum?.fieldSources?.image).toEqual(["birdeye"]);
  });

  it("keeps same-symbol assets on different chains distinct", () => {
    const result = dedupeProviderTokens([
      token({ chain: "ethereum", contractAddress: "0xaaa" }),
      token({ chain: "bsc", contractAddress: "0xaaa" }),
      token({ chain: "solana", contractAddress: "MintOne" }),
      token({ chain: "solana", contractAddress: "mintone" }),
    ]);

    expect(result).toHaveLength(4);
  });
});

describe("provider enrichment and charts", () => {
  it("fills missing provider fields without overwriting existing values", () => {
    const merged = mergeProviderToken(
      token({ currentPrice: 1, image: "", liquidity: null, fieldSources: { price: ["dexpaprika"] } }),
      token({
        source: "birdeye",
        currentPrice: 2,
        image: "https://example.com/logo.png",
        liquidity: 1000,
        volume24h: 2000,
        fieldSources: { image: ["birdeye"], liquidity: ["birdeye"], volume24h: ["birdeye"] },
      }),
    );
    expect(merged.currentPrice).toBe(1);
    expect(merged.image).toBe("https://example.com/logo.png");
    expect(merged.liquidity).toBe(1000);
    expect(merged.volume24h).toBe(2000);
    expect(merged.sources).toEqual(["dexpaprika", "birdeye"]);
    expect(merged.fieldSources?.price).toEqual(["dexpaprika"]);
    expect(merged.fieldSources?.image).toEqual(["birdeye"]);
    expect(merged.fieldSources?.liquidity).toEqual(["birdeye"]);
    expect(merged.fieldSources?.volume24h).toEqual(["birdeye"]);
  });

  it("does not fabricate unknown OHLCV fields", () => {
    expect(normalizeHistoricalPoint({ time_open: "2026-08-26T00:00:00Z", close: "1.25" })).toMatchObject({
      close: 1.25,
      open: null,
      high: null,
      low: null,
      volume: null,
    });
  });
});
