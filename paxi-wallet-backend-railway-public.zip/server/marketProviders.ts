import { ENV } from "./_core/env";

import { fetchJson as fetchProviderJson } from "./providers/http";
import type { AssetIdentity } from "./identity/assetIdentity";

export type MarketChain = "ethereum" | "bsc" | "base" | "polygon" | "arbitrum" | "solana" | "bitcoin";

export interface CanonicalMarketIdentity {
  chain: MarketChain | null;
  contractAddress: string | null;
  coinId?: string | null;
}

export type ProviderTokenField =
  | "identity"
  | "name"
  | "symbol"
  | "decimals"
  | "image"
  | "price"
  | "priceChange24h"
  | "marketCap"
  | "volume24h"
  | "liquidity"
  | "verification"
  | "security";

export type ProviderTokenFieldSources = Partial<Record<ProviderTokenField, string[]>>;

export interface NormalizedProviderToken {
  id: string;
  symbol: string;
  name: string;
  chain: MarketChain | null;
  contractAddress: string | null;
  decimals: number | null;
  image: string;
  currentPrice: number | null;
  marketCap: number | null;
  marketCapRank: number | null;
  liquidity: number | null;
  volume24h: number | null;
  priceChangePercent24h: number | null;
  verificationStatus: "verified" | "unverified";
  securityStatus: "available" | "unavailable";
  source: "birdeye" | "dexpaprika" | "coingecko";
  /** Providers that contributed at least one normalized field to this identity. */
  sources: Array<"birdeye" | "dexpaprika" | "coingecko">;
  /** Field-level provider attribution; absent fields are genuinely unavailable. */
  fieldSources?: ProviderTokenFieldSources;
  providerId: string | null;
  marketDataAvailable: boolean;
}

export interface NormalizedChartPoint {
  timestamp: number;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number;
  volume: number | null;
}

const BIRDEYE_BASE = "https://public-api.birdeye.so";
const DEXPAPRIKA_BASE = "https://api.dexpaprika.com";

const NETWORK_ALIASES: Record<string, MarketChain> = {
  ethereum: "ethereum",
  eth: "ethereum",
  "binance-smart-chain": "bsc",
  bsc: "bsc",
  bnb: "bsc",
  base: "base",
  "base-mainnet": "base",
  polygon: "polygon",
  "polygon-pos": "polygon",
  arbitrum: "arbitrum",
  "arbitrum-one": "arbitrum",
  solana: "solana",
  bitcoin: "bitcoin",
};

export function normalizeMarketChain(value: unknown): MarketChain | null {
  if (typeof value !== "string") return null;
  return NETWORK_ALIASES[value.trim().toLowerCase()] ?? null;
}

export function normalizeProviderAddress(chain: string | null | undefined, value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > 128) return null;
  return chain && ["ethereum", "bsc", "base", "polygon", "arbitrum"].includes(chain.toLowerCase())
    ? trimmed.toLowerCase()
    : trimmed;
}

export function normalizeAddress(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > 128) return null;
  return trimmed;
}

export function isLikelyAddressQuery(value: string): boolean {
  const query = value.trim();
  return /^0x[a-fA-F0-9]{40}$/.test(query) || /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(query);
}

function finiteNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function stringValue(...values: unknown[]): string {
  for (const value of values) if (typeof value === "string" && value.trim()) return value.trim();
  return "";
}

function safeImage(value: unknown): string {
  const image = stringValue(value);
  return /^https?:\/\//i.test(image) ? image : "";
}

function pickArray(payload: any): any[] {
  const candidates = [payload?.data, payload?.data?.items, payload?.data?.tokens, payload?.data?.results, payload?.items, payload?.tokens, payload?.results, payload];
  return candidates.find(Array.isArray) ?? [];
}

function headersFor(provider: "birdeye" | "dexpaprika", chain?: MarketChain | null): Record<string, string> {
  if (provider === "birdeye") {
    return {
      accept: "application/json",
      ...(ENV.birdeyeApiKey ? { "X-API-KEY": ENV.birdeyeApiKey } : {}),
      ...(chain && chain !== "bitcoin" ? { "x-chain": chain } : {}),
    };
  }
  return {
    accept: "application/json",
    ...(ENV.dexpaprikaApiKey ? { authorization: ENV.dexpaprikaApiKey } : {}),
  };
}

async function fetchJson<T>(url: string, headers: Record<string, string>, provider: "birdeye" | "dexpaprika"): Promise<T> {
  return fetchProviderJson<T>(url, provider, headers);
}

function normalizeToken(raw: any, source: "birdeye" | "dexpaprika", requestedChain?: MarketChain | null): NormalizedProviderToken | null {
  const chain = normalizeMarketChain(raw?.chain ?? raw?.network ?? raw?.chainId ?? raw?.platform ?? requestedChain);
  const address = normalizeProviderAddress(chain, raw?.address ?? raw?.token_address ?? raw?.tokenAddress ?? raw?.mint ?? raw?.contract_address ?? raw?.contractAddress);
  const symbol = stringValue(raw?.symbol, raw?.ticker, raw?.base_symbol);
  const name = stringValue(raw?.name, raw?.token_name, raw?.base_name) || symbol || "Unknown token";
  if (!symbol && !address) return null;

  const price = finiteNumber(raw?.price_usd ?? raw?.priceUsd ?? raw?.price ?? raw?.summary?.price_usd ?? raw?.price?.value);
  const liquidity = finiteNumber(raw?.liquidity_usd ?? raw?.liquidityUsd ?? raw?.liquidity ?? raw?.summary?.liquidity_usd);
  const volume = finiteNumber(raw?.volume24h_usd ?? raw?.volume24hUsd ?? raw?.volume_24h ?? raw?.volume24h ?? raw?.summary?.volume_24h_usd ?? raw?.volume_usd);
  const change = finiteNumber(raw?.price_change_24h ?? raw?.priceChange24h ?? raw?.price_change_percentage_24h ?? raw?.priceChangePercent24h);
  const providerId = stringValue(raw?.id, raw?.token_id, raw?.address, raw?.mint) || null;
  const fieldSources: ProviderTokenFieldSources = {
    identity: chain || address ? [source] : undefined,
    name: name ? [source] : undefined,
    symbol: symbol ? [source] : undefined,
    decimals: finiteNumber(raw?.decimals) !== null ? [source] : undefined,
    image: safeImage(raw?.logoURI ?? raw?.logo_url ?? raw?.logo ?? raw?.image ?? raw?.icon) ? [source] : undefined,
    price: price !== null ? [source] : undefined,
    priceChange24h: change !== null ? [source] : undefined,
    marketCap: finiteNumber(raw?.market_cap_usd ?? raw?.marketCapUsd ?? raw?.market_cap ?? raw?.marketCap) !== null ? [source] : undefined,
    volume24h: volume !== null ? [source] : undefined,
    liquidity: liquidity !== null ? [source] : undefined,
    verification: [source],
    security: [source],
  };

  return {
    id: `${source}:${chain ?? "unknown"}:${address ?? providerId ?? symbol.toLowerCase()}`,
    symbol: symbol.toUpperCase(),
    name,
    chain,
    contractAddress: address,
    decimals: finiteNumber(raw?.decimals),
    image: safeImage(raw?.logoURI ?? raw?.logo_url ?? raw?.logo ?? raw?.image ?? raw?.icon),
    currentPrice: price,
    marketCap: finiteNumber(raw?.market_cap_usd ?? raw?.marketCapUsd ?? raw?.market_cap ?? raw?.marketCap),
    marketCapRank: finiteNumber(raw?.market_cap_rank ?? raw?.marketCapRank),
    liquidity,
    volume24h: volume,
    priceChangePercent24h: change,
    verificationStatus: "unverified",
    securityStatus: "unavailable",
    source,
    sources: [source],
    fieldSources,
    providerId,
    marketDataAvailable: price !== null || liquidity !== null || volume !== null,
  };
}

function mergeFieldSources(
  existing: ProviderTokenFieldSources | undefined,
  incoming: ProviderTokenFieldSources | undefined,
): ProviderTokenFieldSources {
  const merged: ProviderTokenFieldSources = { ...(existing ?? {}) };
  for (const [field, sources] of Object.entries(incoming ?? {})) {
    if (!sources?.length) continue;
    merged[field as ProviderTokenField] = Array.from(new Set([...(merged[field as ProviderTokenField] ?? []), ...sources]));
  }
  return merged;
}

function providerIdentityKey(token: NormalizedProviderToken): string {
  if (!token.chain || !token.contractAddress) return `${token.source}:${token.id}`;
  const address = ["ethereum", "bsc", "base", "polygon", "arbitrum"].includes(token.chain)
    ? token.contractAddress.toLowerCase()
    : token.contractAddress;
  return `${token.chain}:${address}`;
}

export function dedupeProviderTokens(tokens: NormalizedProviderToken[]): NormalizedProviderToken[] {
  const byIdentity = new Map<string, NormalizedProviderToken>();
  for (const token of tokens) {
    const identity = providerIdentityKey(token);
    const existing = byIdentity.get(identity);
    if (!existing) {
      byIdentity.set(identity, token);
      continue;
    }
    byIdentity.set(identity, {
      ...existing,
      image: existing.image || token.image,
      currentPrice: existing.currentPrice ?? token.currentPrice,
      marketCap: existing.marketCap ?? token.marketCap,
      marketCapRank: existing.marketCapRank ?? token.marketCapRank,
      liquidity: existing.liquidity ?? token.liquidity,
      volume24h: existing.volume24h ?? token.volume24h,
      priceChangePercent24h: existing.priceChangePercent24h ?? token.priceChangePercent24h,
      decimals: existing.decimals ?? token.decimals,
      source: existing.source === "coingecko" ? token.source : existing.source,
      sources: Array.from(new Set([...existing.sources, ...token.sources])),
      fieldSources: mergeFieldSources(existing.fieldSources, token.fieldSources),
      marketDataAvailable: existing.marketDataAvailable || token.marketDataAvailable,
    });
  }
  return Array.from(byIdentity.values());
}

export async function searchBirdeyeTokens(query: string, requestedChain: MarketChain | null = null): Promise<NormalizedProviderToken[]> {
  if (!ENV.birdeyeApiKey) return [];
  const chains: MarketChain[] = requestedChain
    ? [requestedChain]
    : ["ethereum", "bsc", "solana", "polygon", "arbitrum", "base"];
  const url = `${BIRDEYE_BASE}/defi/v3/search?keyword=${encodeURIComponent(query.trim())}`;
  const results = await Promise.all(chains.map(async (chain) => {
    try {
      const payload = await fetchJson<any>(url, headersFor("birdeye", chain), "birdeye");
      return pickArray(payload)
        .map((item) => normalizeToken(item, "birdeye", chain))
        .filter(Boolean) as NormalizedProviderToken[];
    } catch (error) {
      console.warn(`[marketData] Birdeye ${chain} search unavailable:`, error instanceof Error ? error.message : "provider error");
      return [];
    }
  }));
  return results.flat();
}

export async function searchDexPaprikaTokens(query: string, requestedChain: MarketChain | null = null): Promise<NormalizedProviderToken[]> {
  const url = `${DEXPAPRIKA_BASE}/search?query=${encodeURIComponent(query.trim())}`;
  try {
    const payload = await fetchJson<any>(url, headersFor("dexpaprika"), "dexpaprika");
    return pickArray(payload)
      .map((item) => normalizeToken(item, "dexpaprika", requestedChain))
      .filter(Boolean) as NormalizedProviderToken[];
  } catch (error) {
    console.warn("[marketData] DexPaprika search unavailable:", error instanceof Error ? error.message : "provider error");
    return [];
  }
}

export async function getBirdeyeToken(identity: CanonicalMarketIdentity): Promise<NormalizedProviderToken | null> {
  if (!ENV.birdeyeApiKey || !identity.chain || !identity.contractAddress) return null;
  const url = `${BIRDEYE_BASE}/defi/token_overview?address=${encodeURIComponent(identity.contractAddress)}`;
  try {
    const payload = await fetchJson<any>(url, headersFor("birdeye", identity.chain), "birdeye");
    return normalizeToken({ ...(payload?.data ?? payload), address: identity.contractAddress }, "birdeye", identity.chain);
  } catch (error) {
    console.warn("[marketData] Birdeye token overview unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

export async function getDexPaprikaToken(identity: CanonicalMarketIdentity): Promise<NormalizedProviderToken | null> {
  if (!identity.chain || !identity.contractAddress) return null;
  const url = `${DEXPAPRIKA_BASE}/networks/${identity.chain}/tokens/${encodeURIComponent(identity.contractAddress)}`;
  try {
    const payload = await fetchJson<any>(url, headersFor("dexpaprika", identity.chain), "dexpaprika");
    const data = payload?.data ?? payload;
    return normalizeToken({ ...data, address: identity.contractAddress, network: identity.chain }, "dexpaprika", identity.chain);
  } catch (error) {
    console.warn("[marketData] DexPaprika token unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

export interface ProviderChartResult {
  identity?: AssetIdentity;
  points: NormalizedChartPoint[];
  source: "birdeye" | "dexpaprika" | "binance" | "coingecko";
  historicalAvailable: boolean;
  providerId?: string | null;
}

export type MarketChartTimeframe = "1H" | "1D" | "1W" | "1M" | "3M" | "1Y" | "ALL";

type ChartWindowInput = number | "max" | MarketChartTimeframe;

function chartWindow(input: ChartWindowInput): { timeFrom: number; timeTo: number; birdeyeType: string; dexInterval: string } {
  const timeTo = Math.floor(Date.now() / 1000);
  let windowSeconds: number;
  let birdeyeType: string;
  let dexInterval: string;

  if (typeof input === "string" && input !== "max") {
    switch (input) {
      case "1H":
        windowSeconds = 60 * 60;
        birdeyeType = "1m";
        dexInterval = "1m";
        break;
      case "1D":
        windowSeconds = 24 * 60 * 60;
        birdeyeType = "1H";
        dexInterval = "1h";
        break;
      case "1W":
        windowSeconds = 7 * 24 * 60 * 60;
        birdeyeType = "4H";
        dexInterval = "4h";
        break;
      case "1M":
        windowSeconds = 30 * 24 * 60 * 60;
        birdeyeType = "1D";
        dexInterval = "1d";
        break;
      case "3M":
        windowSeconds = 90 * 24 * 60 * 60;
        birdeyeType = "1D";
        dexInterval = "1d";
        break;
      case "1Y":
      case "ALL":
        windowSeconds = 365 * 24 * 60 * 60;
        birdeyeType = "1D";
        dexInterval = "1d";
        break;
    }
  } else {
    const boundedDays = input === "max" ? 365 : Math.max(1, Math.min(365, input));
    windowSeconds = boundedDays * 24 * 60 * 60;
    if (boundedDays <= 1) {
      birdeyeType = "1H";
      dexInterval = "1h";
    } else if (boundedDays <= 7) {
      birdeyeType = "4H";
      dexInterval = "4h";
    } else {
      birdeyeType = "1D";
      dexInterval = "1d";
    }
  }

  return { timeFrom: timeTo - windowSeconds, timeTo, birdeyeType, dexInterval };
}

function chartPoints(payload: any): NormalizedChartPoint[] {
  return pickArray(payload)
    .map((raw) => normalizeHistoricalPoint({
      ...raw,
      timestamp: raw?.timestamp ?? raw?.time ?? raw?.unixTime ?? raw?.time_close ?? raw?.time_open,
    }))
    .filter(Boolean)
    .sort((a, b) => (a as NormalizedChartPoint).timestamp - (b as NormalizedChartPoint).timestamp) as NormalizedChartPoint[];
}

export async function getBirdeyeChart(identity: CanonicalMarketIdentity, days: ChartWindowInput): Promise<ProviderChartResult | null> {
  if (!ENV.birdeyeApiKey || !identity.chain || identity.chain === "bitcoin" || !identity.contractAddress) return null;
  const window = chartWindow(days);
  const params = new URLSearchParams({
    address: identity.contractAddress,
    time_from: String(window.timeFrom),
    time_to: String(window.timeTo),
    type: window.birdeyeType,
  });
  try {
    const payload = await fetchJson<any>(`${BIRDEYE_BASE}/defi/ohlcv?${params.toString()}`, headersFor("birdeye", identity.chain), "birdeye");
    const points = chartPoints(payload);
    return points.length ? { points, source: "birdeye", historicalAvailable: true, providerId: identity.contractAddress } : null;
  } catch (error) {
    console.warn("[marketData] Birdeye OHLCV unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

function poolAddress(raw: any): string | null {
  return stringValue(raw?.pool_address, raw?.poolAddress, raw?.address, raw?.id) || null;
}

function poolScore(raw: any): number {
  return finiteNumber(raw?.volume_usd ?? raw?.volumeUsd ?? raw?.volume_24h_usd ?? raw?.volume24hUsd ?? raw?.liquidity_usd ?? raw?.liquidityUsd) ?? -1;
}

export async function getDexPaprikaChart(identity: CanonicalMarketIdentity, days: ChartWindowInput): Promise<ProviderChartResult | null> {
  if (!identity.chain || identity.chain === "bitcoin" || !identity.contractAddress) return null;
  const window = chartWindow(days);
  try {
    const poolSearchUrl = `${DEXPAPRIKA_BASE}/networks/${identity.chain}/pools/search?token_address=${encodeURIComponent(identity.contractAddress)}&limit=10`;
    const poolPayload = await fetchJson<any>(poolSearchUrl, headersFor("dexpaprika", identity.chain), "dexpaprika");
    const pools = pickArray(poolPayload).filter((pool) => poolAddress(pool)).sort((a, b) => poolScore(b) - poolScore(a));
    const selectedPool = pools[0];
    const selectedPoolAddress = selectedPool ? poolAddress(selectedPool) : null;
    if (!selectedPoolAddress) return null;

    const params = new URLSearchParams({
      start: new Date(window.timeFrom * 1000).toISOString(),
      end: new Date(window.timeTo * 1000).toISOString(),
      limit: "366",
      interval: window.dexInterval,
    });
    const ohlcvUrl = `${DEXPAPRIKA_BASE}/networks/${identity.chain}/pools/${encodeURIComponent(selectedPoolAddress)}/ohlcv?${params.toString()}`;
    const payload = await fetchJson<any>(ohlcvUrl, headersFor("dexpaprika", identity.chain), "dexpaprika");
    const points = chartPoints(payload);
    return points.length ? { points, source: "dexpaprika", historicalAvailable: true, providerId: selectedPoolAddress } : null;
  } catch (error) {
    console.warn("[marketData] DexPaprika OHLCV unavailable:", error instanceof Error ? error.message : "provider error");
    return null;
  }
}

export function mergeProviderToken(primary: NormalizedProviderToken, secondary: NormalizedProviderToken | null): NormalizedProviderToken {
  if (!secondary) return primary;
  return {
    ...primary,
    image: primary.image || secondary.image,
    symbol: primary.symbol || secondary.symbol,
    name: primary.name || secondary.name,
    currentPrice: primary.currentPrice ?? secondary.currentPrice,
    marketCap: primary.marketCap ?? secondary.marketCap,
    marketCapRank: primary.marketCapRank ?? secondary.marketCapRank,
    liquidity: primary.liquidity ?? secondary.liquidity,
    volume24h: primary.volume24h ?? secondary.volume24h,
    priceChangePercent24h: primary.priceChangePercent24h ?? secondary.priceChangePercent24h,
    decimals: primary.decimals ?? secondary.decimals,
    sources: Array.from(new Set([...primary.sources, ...secondary.sources])),
    fieldSources: mergeFieldSources(primary.fieldSources, secondary.fieldSources),
    marketDataAvailable: primary.marketDataAvailable || secondary.marketDataAvailable,
  };
}

function timestampValue(value: unknown): number | null {
  const numeric = finiteNumber(value);
  if (numeric !== null) return numeric;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

export function normalizeHistoricalPoint(raw: any): NormalizedChartPoint | null {
  const timestamp = timestampValue(raw?.timestamp ?? raw?.time ?? raw?.unixTime ?? raw?.t ?? raw?.time_close ?? raw?.time_open);
  const close = finiteNumber(raw?.close ?? raw?.price ?? raw?.value ?? raw?.c);
  if (timestamp === null || close === null) return null;
  const ts = timestamp < 10_000_000_000 ? timestamp * 1000 : timestamp;
  return {
    timestamp: ts,
    open: finiteNumber(raw?.open ?? raw?.o),
    high: finiteNumber(raw?.high ?? raw?.h),
    low: finiteNumber(raw?.low ?? raw?.l),
    close,
    volume: finiteNumber(raw?.volume ?? raw?.v),
  };
}

export function getProviderEnvStatus(): { birdeyeConfigured: boolean; dexPaprikaConfigured: boolean } {
  return { birdeyeConfigured: Boolean(ENV.birdeyeApiKey), dexPaprikaConfigured: Boolean(ENV.dexpaprikaApiKey) };
}
