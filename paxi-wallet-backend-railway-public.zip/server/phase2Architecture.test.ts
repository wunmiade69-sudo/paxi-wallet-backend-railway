import { describe, expect, it } from "vitest";
import {
  getAssetIdentityKey,
  isSameAsset,
  resolveAssetIdentity,
} from "./identity/assetIdentity";
import {
  createCacheEnvelope,
  markCacheEnvelopeStale,
  assetCacheKey,
  searchCacheKey,
} from "./cache/keys";
import { listRegisteredChainDefinitions } from "./chains/registry";
import { listProviderDefinitions, providersForCapability } from "./providers/definitions";
import { orchestratedSearchTokens } from "./providers/orchestrator";

describe("Phase 2 canonical identity architecture", () => {
  it("uses canonical native identity for Bitcoin and other native assets", () => {
    expect(resolveAssetIdentity({ chain: "btc", kind: "native" })).toMatchObject({ chain: "bitcoin", kind: "native", contractOrMint: "native", key: "bitcoin:native" });
    expect(getAssetIdentityKey({ chain: "ethereum", identifier: "native" })).toBe("ethereum:native");
  });

  it("normalizes EVM addresses but preserves Solana mint case", () => {
    const evm = "0xAbCd000000000000000000000000000000000001";
    const solana = "So1anaMintCaseSensitive111111111111111111111";
    expect(getAssetIdentityKey({ chain: "ethereum", contractAddress: evm })).toBe(`ethereum:${evm.toLowerCase()}`);
    expect(getAssetIdentityKey({ chain: "solana", mintAddress: solana })).toBe(`solana:${solana}`);
    expect(isSameAsset({ chain: "ethereum", contractAddress: evm }, { chain: "eth", contractAddress: evm.toLowerCase() })).toBe(true);
    expect(isSameAsset({ chain: "solana", mintAddress: solana }, { chain: "solana", mintAddress: solana.toLowerCase() })).toBe(false);
  });
});

describe("Phase 2 chain and provider registries", () => {
  it("exposes explicit supported-chain types and capabilities without provider calls", () => {
    const chains = listRegisteredChainDefinitions();
    expect(chains.map((chain) => chain.chainKey)).toEqual(["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"]);
    expect(chains.find((chain) => chain.chainKey === "solana")?.chainType).toBe("SOLANA");
    expect(chains.find((chain) => chain.chainKey === "bitcoin")?.chainType).toBe("BITCOIN");
  });

  it("orders providers by capability priority and declares operational policy", () => {
    const searchProviders = providersForCapability("SEARCH", "solana");
    expect(searchProviders.length).toBeGreaterThan(0);
    expect(searchProviders[0].priority.SEARCH).toBeLessThanOrEqual(searchProviders.at(-1)?.priority.SEARCH ?? Number.MAX_SAFE_INTEGER);
    for (const provider of listProviderDefinitions()) {
      expect(provider.authentication).toBeTruthy();
      expect(provider.timeoutMs).toBeGreaterThan(0);
      expect(provider.cachePolicy.allowStaleOnError).toBe(true);
      expect(provider.healthPolicy.failureThreshold).toBeGreaterThan(0);
    }
  });
});

describe("Phase 2 cache and orchestrator boundaries", () => {
  it("uses identity-aware cache keys and preserves source/freshness metadata", () => {
    const identity = resolveAssetIdentity({ chain: "ethereum", contractAddress: "0xAbCd000000000000000000000000000000000001" });
    expect(identity).not.toBeNull();
    expect(assetCacheKey("price", identity!)).toBe("asset:price:ethereum:0xabcd000000000000000000000000000000000001");
    expect(searchCacheKey("  USDC ", "solana")).toBe("asset:search:solana:usdc");

    const envelope = createCacheEnvelope({ price: 1.2 }, "coingecko", 1000, 123, 1000);
    expect(envelope).toMatchObject({ source: "coingecko", sourceTimestamp: 123, expiresAt: 2000, stale: false });
    expect(markCacheEnvelopeStale(envelope, 2000).stale).toBe(true);
  });

  it("returns an empty normalized result without calling providers for blank search", async () => {
    await expect(orchestratedSearchTokens("   ")).resolves.toEqual({ value: [], attempts: [], source: null });
  });
});
