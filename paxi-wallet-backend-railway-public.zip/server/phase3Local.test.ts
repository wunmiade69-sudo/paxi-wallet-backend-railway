import { beforeEach, describe, expect, it } from 'vitest';
import {
  addContact,
  addressesMatch,
  contactMatchesNetwork,
  getContacts,
  normalizeContactAddress,
} from '../client/src/lib/wallet/addressBook';
import {
  addNotification,
  disconnectConnectedDapp,
  getConnectedDapps,
  getNotifications,
  getTokenApprovals,
  markNotificationRead,
} from '../client/src/lib/phase3Local';
import { walletConnectManager } from '../client/src/lib/wallet/walletconnect';

function installStorage() {
  const values = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
    clear: () => values.clear(),
    key: (index: number) => [...values.keys()][index] ?? null,
    get length() { return values.size; },
  };
}

describe('Phase 3 network-aware address book', () => {
  beforeEach(() => installStorage());

  it('normalizes validation by network while preserving the entered address', () => {
    const evm = '0x000000000000000000000000000000000000000A';
    expect(normalizeContactAddress('ethereum', evm)).toBe(evm);
    expect(addressesMatch('ethereum', evm, evm.toLowerCase())).toBe(true);

    const solana = 'So11111111111111111111111111111111111111112';
    expect(normalizeContactAddress('solana', solana)).toBe(solana);
    expect(addressesMatch('solana', solana, solana.toLowerCase())).toBe(false);
  });

  it('prevents duplicate recipients on the same network but allows the same EVM address on another network', () => {
    const address = '0x000000000000000000000000000000000000000A';
    const contact = addContact({ name: 'Treasury', network: 'ethereum', address });
    expect(contact.network).toBe('ethereum');
    expect(contact.verificationStatus).toBe('unconfirmed');
    expect(() => addContact({ name: 'Duplicate', network: 'ethereum', address: address.toLowerCase() })).toThrow('already saved');
    expect(addContact({ name: 'BNB Treasury', network: 'bsc', address }).network).toBe('bsc');
    expect(getContacts()).toHaveLength(2);
    expect(contactMatchesNetwork(contact, 'ethereum')).toBe(true);
    expect(contactMatchesNetwork(contact, 'bsc')).toBe(false);
  });

  it('rejects malformed or unsupported contacts before persistence', () => {
    expect(() => addContact({ name: 'Bad', network: 'ethereum', address: 'not-an-address' })).toThrow();
    expect(() => addContact({ name: 'Bad', network: 'unknown', address: '0x0000000000000000000000000000000000000001' })).toThrow('supported network');
    expect(getContacts()).toEqual([]);
  });
});

describe('Phase 3 local security foundations', () => {
  beforeEach(() => {
    installStorage();
    walletConnectManager.sessions = [];
  });

  it('reads real WalletConnect sessions without inventing local records', () => {
    walletConnectManager.sessions = [{
      topic: 'wc-1',
      dapp: { name: 'Example', url: 'https://example.org/app', icons: [] },
      chains: ['eip155:1'],
    }];
    expect(getConnectedDapps()).toHaveLength(1);
    expect(getConnectedDapps()[0].domain).toBe('example.org');
    expect(getConnectedDapps()[0].canDisconnect).toBe(true);
  });

  it('keeps approval scanning unavailable and filters malformed notifications', () => {
    expect(getTokenApprovals()).toEqual([]);
    localStorage.setItem('paxi-notifications', JSON.stringify([
      { id: 'n1', title: 'Confirmed', body: 'Transaction confirmed', type: 'transaction-confirmed', createdAt: 1, read: false, source: 'indexed-transaction' },
      { id: 'n2', title: '', body: 'invalid' },
    ]));
    expect(getNotifications()).toHaveLength(1);
  });

  it('persists a canonical token target and deduplicates by explicit key', () => {
    const target = {
      entityType: 'token' as const,
      chain: 'ethereum',
      contractOrMint: '0x0000000000000000000000000000000000000001',
      navigation: 'token-detail' as const,
    };
    const first = addNotification({
      id: 'price-1',
      dedupeKey: 'price:ethereum:0x1:up:window',
      type: 'price-alert',
      title: 'TKN moved',
      body: 'A real market movement was observed.',
      target,
      source: 'market-data',
    });
    const duplicate = addNotification({
      id: 'price-2',
      dedupeKey: 'price:ethereum:0x1:up:window',
      type: 'price-alert',
      title: 'Duplicate',
      body: 'Should not be stored.',
      target,
      source: 'market-data',
    });
    expect(duplicate.id).toBe(first.id);
    expect(getNotifications()).toHaveLength(1);
    expect(getNotifications()[0]?.target?.contractOrMint).toBe(target.contractOrMint);

    markNotificationRead(first.id);
    expect(getNotifications()[0]?.read).toBe(true);
    expect(getNotifications()[0]?.readAt).toEqual(expect.any(Number));
  });
});
