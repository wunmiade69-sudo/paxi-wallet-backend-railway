import { describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({ getDb: vi.fn().mockResolvedValue(null) }));
vi.mock("./assetRegistry", () => ({
  getOrCreateAsset: vi.fn(),
  normalizeIdentifier: (network: string, identifier: string) => network === "solana" ? identifier : identifier.toLowerCase(),
}));
vi.mock("./dexLiquidity", () => ({ getTokenMarketSnapshot: vi.fn(), resolveTokenPriceUsd: vi.fn() }));
vi.mock("./redis", () => ({
  acquirePriceRefreshLock: vi.fn().mockResolvedValue({ acquired: false, reason: "unavailable" }),
  releasePriceRefreshLock: vi.fn(),
  getCachedAssetPrice: vi.fn().mockResolvedValue(null),
  setCachedAssetPrice: vi.fn(),
}));
vi.mock("./jupiter", () => ({ getJupiterToken: vi.fn().mockResolvedValue(null) }));
vi.mock("./providers/http", () => ({ fetchJson: vi.fn() }));

describe("canonical portfolio quote batching", () => {
  it("bounds at 100 inputs, removes duplicate identities, keeps native identity, and skips invalid tokens", async () => {
    const { prepareAssetPriceQueries } = await import("./priceEngine");
    const inputs = [
      ...Array.from({ length: 98 }, (_, index) => ({ network: "ethereum", isNative: false, contractAddress: `0x${index.toString(16).padStart(40, "0")}` })),
      { network: "ethereum", isNative: true },
      { network: "ethereum", isNative: false, contractAddress: "0x0000000000000000000000000000000000000001" },
      { network: "ethereum", isNative: true },
      { network: "ethereum", isNative: false, contractAddress: "0x0000000000000000000000000000000000000001" },
      ...Array.from({ length: 4 }, (_, index) => ({ network: "ethereum", isNative: false, contractAddress: `0x${(100 + index).toString(16).padStart(40, "0")}` })),
    ];

    const result = prepareAssetPriceQueries(inputs);
    expect(result).toHaveLength(99);
    expect(prepareAssetPriceQueries(Array.from({ length: 101 }, (_, index) => ({ network: "ethereum", isNative: false, contractAddress: `0x${(index + 1000).toString(16).padStart(40, "0")}` })))).toHaveLength(100);
    expect(result.filter((entry) => entry.isNative)).toHaveLength(1);
    expect(result.find((entry) => entry.isNative)?.network).toBe("ethereum");
    expect(result.filter((entry) => entry.contractAddress === "0x0000000000000000000000000000000000000001")).toHaveLength(1);
  });

  it("normalizes surrounding whitespace and retains Solana mint case for identity", async () => {
    const { prepareAssetPriceQueries } = await import("./priceEngine");
    const result = prepareAssetPriceQueries([
      { network: " ethereum ", isNative: false, contractAddress: " 0xAbC " },
      { network: "ethereum", isNative: false, contractAddress: "0xabc" },
      { network: "solana", isNative: false, contractAddress: "MintCase" },
    ]);

    expect(result).toEqual([
      { network: "ethereum", isNative: false, contractAddress: "0xAbC" },
      { network: "solana", isNative: false, contractAddress: "MintCase" },
    ]);
  });

  it("uses the shared Binance provider for native prices and normalizes change", async () => {
    const { fetchJson } = await import("./providers/http");
    const { getNativeAssetPrice } = await import("./priceEngine");
    vi.mocked(fetchJson).mockReset().mockResolvedValueOnce({ lastPrice: "612.50", priceChangePercent: "2.5" });

    await expect(getNativeAssetPrice(" Ethereum ")).resolves.toEqual({ priceUsd: 612.5, change24h: 2.5, source: "binance" });
    expect(fetchJson).toHaveBeenCalledWith(expect.stringContaining("symbol=ETHUSDT"), "binance-price");
  });

  it("falls back to CoinGecko and returns null when both native providers fail", async () => {
    const { fetchJson } = await import("./providers/http");
    const { getNativeAssetPrice } = await import("./priceEngine");
    vi.mocked(fetchJson).mockReset()
      .mockRejectedValueOnce(new Error("binance unavailable"))
      .mockRejectedValueOnce(new Error("binance retry unavailable"))
      .mockResolvedValueOnce({ solana: { usd: "141.20", usd_24h_change: null } });

    await expect(getNativeAssetPrice("solana")).resolves.toEqual({ priceUsd: 141.2, change24h: null, source: "coingecko" });
    expect(fetchJson).toHaveBeenNthCalledWith(1, expect.stringContaining("symbol=SOLUSDT"), "binance-price");
    expect(fetchJson).toHaveBeenNthCalledWith(3, expect.stringContaining("ids=solana"), "coingecko-price", expect.any(Object));

    vi.mocked(fetchJson).mockReset()
      .mockRejectedValueOnce(new Error("binance unavailable"))
      .mockRejectedValueOnce(new Error("binance retry unavailable"))
      .mockRejectedValueOnce(new Error("coingecko unavailable"))
      .mockRejectedValueOnce(new Error("coingecko retry unavailable"));
    await expect(getNativeAssetPrice("polygon")).resolves.toBeNull();
  });
});

