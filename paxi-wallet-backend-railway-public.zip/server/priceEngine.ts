/**
 * Server-side canonical price for a single token asset (chainId +
 * contract address) - the "not on Binance/CoinGecko" case that used to
 * mean every wallet, on every load, independently hitting DexScreener and
 * then (if that missed) an RPC node directly. That fan-out is what was
 * flagged after Phase 2: the data was already being fetched and persisted
 * server-side (dexLiquidity.ts), just never served back out.
 *
 * Phase 3A: four-tier cache, reads never block on a refresh, and a live
 * refresh is coalesced both within one process AND across every API
 * instance (the earlier version only had the former - see the Redis lock
 * note below):
 *   1. In-memory (per server process) - near-zero latency, but private to
 *      one process/instance.
 *   2. Redis (server/redis.ts) - shared across every API instance. Still a
 *      network round trip, but a sub-millisecond one, and this is what
 *      lets instance B serve a price instance A just fetched without
 *      touching MySQL or DexScreener at all.
 *   3. assetMarketData (MySQL) - shared and durable, survives a Redis
 *      flush/restart. Served immediately even if stale; a stale entry
 *      triggers a background refresh instead of making the caller wait
 *      (stale-while-revalidate).
 *   4. Live fetch (DexScreener, then on-chain reserve read) - only hit
 *      when nothing is cached anywhere, or by the background refresh a
 *      stale entry triggers.
 *
 * The refresh itself is coalesced twice over:
 *   - `inFlight` (in-memory Map) - concurrent requests within ONE process
 *     share a single Promise instead of each calling fetchLive().
 *   - The Redis lock (`acquirePriceRefreshLock`/`releasePriceRefreshLock` in
 *     redis.ts - token-based SET NX PX + atomic Lua compare-and-delete, see
 *     that file for why a plain constant-value lock isn't safe)
 *     - concurrent requests across MULTIPLE processes/instances agree on
 *     exactly one "winner" that's allowed to call DexScreener/RPC; every
 *     other instance gets `{ acquired: false, reason: "held" }` and just
 *     serves the last-known value instead. This is the piece that
 *     actually solves the cache-stampede problem "millions of users
 *     hitting DexScreener at once" describes - `inFlight` alone only ever
 *     protected one process.
 *
 * Redis is a cache/coordination layer, never a source of truth, and a down
 * Redis must never mean "stop refreshing prices" - so `acquirePriceRefreshLock`
 * returns `reason: "unavailable"` (not "held") when Redis itself is
 * unreachable, and this file's refresh path treats that as "proceed
 * unprotected" rather than "someone else has it covered". Getting this
 * distinction wrong (collapsing both reasons into one signal) is exactly
 * the kind of bug that looks like graceful degradation while actually
 * being an outage that silently freezes every cached price the moment
 * Redis has a bad day.
 */
import { JsonRpcProvider, Contract, formatUnits } from "ethers";
import { eq } from "drizzle-orm";
import { assetMarketData, type InsertAssetMarketData } from "../drizzle/schema";
import { getDb } from "./db";
import { getOrCreateAsset, normalizeIdentifier } from "./assetRegistry";
import { fetchAggregatedMarket } from "./providers/aggregator";
import type { Confidence } from "./providers/aggregator";
import { acquirePriceRefreshLock, getCachedAssetPrice, releasePriceRefreshLock, setCachedAssetPrice } from "./redis";

const MEM_TTL_MS = 15_000; // in-memory hit considered fresh for this long
const DB_STALE_MS = 90_000; // DB row served without triggering a background refresh

export interface AssetPriceResult {
  priceUsd: number;
  change24h: number | null;
  source: string;
  confidence?: Confidence;
  confidenceScore?: number;
  providerCount?: number;
  sources?: string[];
  outlierSources?: string[];
  sourceUpdatedAt?: number | null;
  isStale?: boolean;
}

interface CacheEntry {
  data: AssetPriceResult;
  expiresAt: number;
}
const memCache = new Map<string, CacheEntry>();
const inFlight = new Map<string, Promise<AssetPriceResult | null>>();

// --- Native coin price (needed to convert an on-chain pool ratio to USD) ---
// Mirrors client/src/lib/wallet/balances.ts's COINGECKO_IDS / Binance symbols,
// scoped to the chains that also appear in DEX_FACTORIES below.
const BINANCE_API = "https://data-api.binance.vision/api/v3";
const COINGECKO_API = "https://api.coingecko.com/api/v3";
const NATIVE_PRICE_SYMBOL: Record<string, { binance: string; coingecko: string }> = {
  bsc: { binance: "BNBUSDT", coingecko: "binancecoin" },
  ethereum: { binance: "ETHUSDT", coingecko: "ethereum" },
  bitcoin: { binance: "BTCUSDT", coingecko: "bitcoin" },
  solana: { binance: "SOLUSDT", coingecko: "solana" },
  polygon: { binance: "POLUSDT", coingecko: "polygon-ecosystem-token" },
  arbitrum: { binance: "ETHUSDT", coingecko: "ethereum" },
};

const nativePriceMemCache = new Map<string, { result: AssetPriceResult; expiresAt: number }>();

const VERIFIED_STABLECOIN_ADDRESSES = new Set([
  'polygon:0xc2132d05d31c914a87c6611c10748aeb04b58e8',
  'polygon:0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
  'bsc:0x55d398326f99059ff775485246999027b3197955',
  'bsc:0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d',
  'ethereum:0xdac17f958d2ee523a2206206994597c13d831ec7',
  'ethereum:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
  'arbitrum:0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9',
  'arbitrum:0xaf88d065e77c8cc2239327c5edb3a432268e5831',
]);

function getVerifiedStablecoinPrice(network: string, contractAddress: string): AssetPriceResult | null {
  const key = `${network.toLowerCase()}:${normalizeIdentifier(network, contractAddress)}`;
  return VERIFIED_STABLECOIN_ADDRESSES.has(key)
    ? { priceUsd: 1, change24h: 0, source: 'verified-stablecoin-peg' }
    : null;
}

export async function getNativeAssetPrice(chainId: string): Promise<AssetPriceResult | null> {
  const cached = nativePriceMemCache.get(chainId);
  if (cached && cached.expiresAt > Date.now()) return cached.result;

  const sym = NATIVE_PRICE_SYMBOL[chainId];
  if (!sym) return null;

  try {
    const res = await fetch(`${BINANCE_API}/ticker/24hr?symbol=${sym.binance}`, { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      const priceUsd = Number(data.lastPrice);
      const change24h = Number(data.priceChangePercent);
      if (Number.isFinite(priceUsd)) {
        const result = { priceUsd, change24h: Number.isFinite(change24h) ? change24h : null, source: "binance" };
        nativePriceMemCache.set(chainId, { result, expiresAt: Date.now() + MEM_TTL_MS });
        return result;
      }
    }
  } catch {
    // fall through to CoinGecko
  }

  try {
    const res = await fetch(`${COINGECKO_API}/simple/price?ids=${sym.coingecko}&vs_currencies=usd&include_24hr_change=true`, { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      const row = data[sym.coingecko];
      const priceUsd = Number(row?.usd);
      const change24h = Number(row?.usd_24h_change);
      if (Number.isFinite(priceUsd)) {
        const result = { priceUsd, change24h: Number.isFinite(change24h) ? change24h : null, source: "coingecko" };
        nativePriceMemCache.set(chainId, { result, expiresAt: Date.now() + MEM_TTL_MS });
        return result;
      }
    }
  } catch {
    // both sources unavailable
  }

  return null;
}

async function getNativeUsdPrice(chainId: string): Promise<number | null> {
  const result = await getNativeAssetPrice(chainId);
  return result?.priceUsd ?? null;
}
// --- On-chain reserve read, mirrors client/src/lib/wallet/dexAnalytics.ts fetchOnChainPrice ---
// Add a network here if it's also added to the client's DEX_FACTORIES.
const DEX_FACTORIES: Record<string, { factoryAddress: string; wrappedNativeAddress: string; wrappedNativeDecimals: number; rpcUrl: string }> = {
  bsc: {
    factoryAddress: "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73", // PancakeSwap V2 Factory
    wrappedNativeAddress: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c", // WBNB
    wrappedNativeDecimals: 18,
    rpcUrl: "https://bsc-rpc.publicnode.com",
  },
};

const FACTORY_ABI = ["function getPair(address tokenA, address tokenB) view returns (address pair)"];
const PAIR_ABI = [
  "function getReserves() view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)",
  "function token0() view returns (address)",
];

async function fetchOnChainPrice(network: string, contractAddress: string, tokenDecimals: number): Promise<number | null> {
  const config = DEX_FACTORIES[network];
  if (!config) return null;
  const nativeUsdPrice = await getNativeUsdPrice(network);
  if (!nativeUsdPrice) return null;

  try {
    const provider = new JsonRpcProvider(config.rpcUrl);
    const factory = new Contract(config.factoryAddress, FACTORY_ABI, provider);
    const pairAddress: string = await factory.getPair(contractAddress, config.wrappedNativeAddress);
    if (!pairAddress || pairAddress === "0x0000000000000000000000000000000000000000") return null;

    const pair = new Contract(pairAddress, PAIR_ABI, provider);
    const [reserve0, reserve1]: [bigint, bigint] = await pair.getReserves();
    const token0: string = await pair.token0();

    const tokenIsToken0 = normalizeIdentifier(network, token0) === normalizeIdentifier(network, contractAddress);
    const [tokenReserveRaw, nativeReserveRaw] = tokenIsToken0 ? [reserve0, reserve1] : [reserve1, reserve0];

    const tokenReserve = Number(formatUnits(tokenReserveRaw, tokenDecimals));
    const nativeReserve = Number(formatUnits(nativeReserveRaw, config.wrappedNativeDecimals));
    if (tokenReserve <= 0 || nativeReserve <= 0) return null;

    return (nativeReserve / tokenReserve) * nativeUsdPrice;
  } catch (err) {
    console.warn(`[priceEngine] on-chain reserve read failed for ${contractAddress}:`, err);
    return null;
  }
}

async function readDbEntry(assetId: number): Promise<{ result: AssetPriceResult; ageMs: number } | null> {
  const db = await getDb();
  if (!db) return null;
  const [row] = await db.select().from(assetMarketData).where(eq(assetMarketData.assetId, assetId)).limit(1);
  if (!row?.priceUsd) return null;
  return {
    result: {
      priceUsd: Number(row.priceUsd),
      change24h: row.priceChange24h != null ? Number(row.priceChange24h) : null,
      source: row.source ?? "cache",
      confidence: row.confidence as Confidence | undefined,
      sources: row.providerSources ? row.providerSources.split(",").filter(Boolean) : undefined,
      sourceUpdatedAt: row.sourceUpdatedAt ? new Date(row.sourceUpdatedAt).getTime() : null,
      isStale: row.isStale,
    },
    ageMs: Date.now() - new Date(row.updatedAt).getTime(),
  };
}

/** Multi-provider consensus -> on-chain reserve fallback. */
async function fetchLive(assetId: number, network: string, contractAddress: string, decimals: number): Promise<AssetPriceResult | null> {
  // The aggregator fans out to every configured provider with Promise.allSettled,
  // filters invalid prices, computes a median and confidence, and exposes the
  // provider provenance. It is now the canonical wallet pricing path rather
  // than a disconnected diagnostic helper.
  const aggregate = await fetchAggregatedMarket(network, contractAddress);
  if (aggregate?.priceUsd != null) {
    const source = "provider-aggregate";
    const result: AssetPriceResult = {
      priceUsd: aggregate.priceUsd,
      change24h: aggregate.change24h,
      source,
      confidence: aggregate.confidence,
      confidenceScore: aggregate.confidenceScore,
      providerCount: aggregate.providerCount,
      sources: aggregate.sources,
      outlierSources: aggregate.outlierSources,
      sourceUpdatedAt: aggregate.sourceUpdatedAt,
      isStale: aggregate.isStale,
    };
    const db = await getDb();
    if (db) {
      const values: InsertAssetMarketData = {
        assetId,
        priceUsd: String(aggregate.priceUsd),
        priceChange24h: aggregate.change24h == null ? null : String(aggregate.change24h),
        volume24hUsd: aggregate.volume24hUsd == null ? null : String(aggregate.volume24hUsd),
        liquidityUsd: aggregate.liquidityUsd == null ? null : String(aggregate.liquidityUsd),
        marketCapUsd: aggregate.marketCapUsd == null ? null : String(aggregate.marketCapUsd),
        fdvUsd: aggregate.fdvUsd == null ? null : String(aggregate.fdvUsd),
        source,
        confidence: aggregate.confidence,
        providerSources: aggregate.sources.join(",").slice(0, 255),
        sourceUpdatedAt: aggregate.sourceUpdatedAt == null ? null : new Date(aggregate.sourceUpdatedAt),
        isStale: aggregate.isStale,
      };
      await db.insert(assetMarketData).values(values).onDuplicateKeyUpdate({ set: values });
    }
    return result;
  }

  // Tier: on-chain reserve read - catches markets no provider has indexed yet.
  const onChainPrice = await fetchOnChainPrice(network, contractAddress, decimals);
  if (onChainPrice != null) {
    const db = await getDb();
    if (db) {
      const values: InsertAssetMarketData = { assetId, priceUsd: String(onChainPrice), source: "onchain" };
      await db.insert(assetMarketData).values(values).onDuplicateKeyUpdate({ set: values });
    }
    return { priceUsd: onChainPrice, change24h: null, source: "onchain", confidence: "low", sources: ["onchain"], isStale: false };
  }

  return null;
}

/**
 * Worker entry point for a single distributed price refresh. The live fetch
 * path already persists the canonical market row; this function only adds the
 * worker-facing lock and cache lifecycle.
 */
export async function performPriceRefresh(
  assetId: number,
  network: string,
  contractAddress: string,
  decimals: number,
  cacheKey: string,
): Promise<AssetPriceResult | null> {
  void assetId;
  const lock = await acquirePriceRefreshLock(cacheKey);
  if (!lock.acquired && lock.reason === "held") return null;
  try {
    const result = await fetchLive(assetId, network, contractAddress, decimals);
    if (result) {
      memCache.set(cacheKey, { data: result, expiresAt: Date.now() + MEM_TTL_MS });
      await setCachedAssetPrice(cacheKey, result);
    }
    return result;
  } finally {
    if (lock.acquired) await releasePriceRefreshLock(cacheKey, lock.token);
  }
}

/**
 * Coalesces concurrent live-fetch requests within this process (inFlight),
 * AND across every process via the Redis lock above. If another instance
 * already holds the lock, this returns `stale` immediately instead of
 * calling DexScreener/RPC itself - that's the whole point: only the lock
 * winner does the live fetch, everyone else rides on its result via the
 * Redis/DB cache it writes when done.
 */
async function refreshInBackground(
  assetId: number,
  network: string,
  contractAddress: string,
  decimals: number,
  cacheKey: string,
  stale: AssetPriceResult | null,
): Promise<AssetPriceResult | null> {
  const existing = inFlight.get(cacheKey);
  if (existing) return existing;

  const promise = (async () => {
    const lock = await acquirePriceRefreshLock(cacheKey);

    if (!lock.acquired && lock.reason === "held") {
      // Another instance genuinely holds the lock and is already
      // refreshing this token right now. Don't duplicate the external
      // call - serve what we've got and let their result land in
      // Redis/MySQL for the next read to pick up.
      return stale;
    }

    // Either we hold the lock, or Redis itself is unavailable
    // (lock.reason === "unavailable"). Both cases proceed to fetch live -
    // refusing to refresh just because Redis is down would mean a Redis
    // outage silently freezes every price forever, which is worse than
    // running without cross-instance coordination for a while. `inFlight`
    // above still coalesces concurrent callers within THIS process either way.
    try {
      const result = await fetchLive(assetId, network, contractAddress, decimals);
      if (result) {
        memCache.set(cacheKey, { data: result, expiresAt: Date.now() + MEM_TTL_MS });
        await setCachedAssetPrice(cacheKey, result); // no-op if Redis is down - setCachedAssetPrice degrades gracefully too
      }
      return result ?? stale;
    } finally {
      if (lock.acquired) await releasePriceRefreshLock(cacheKey, lock.token);
    }
  })().finally(() => inFlight.delete(cacheKey));

  inFlight.set(cacheKey, promise);
  return promise;
}

/**
 * Main entry point - what market.assetPrice (the tRPC endpoint) calls.
 * `symbol`/`decimals` are hints used only if an asset row has to be
 * created for the first time; they're never required for a cache hit.
 */
export async function getAssetPrice(input: {
  network: string;
  contractAddress: string;
  symbol?: string;
  decimals?: number;
}): Promise<AssetPriceResult | null> {
  const stablecoinPrice = getVerifiedStablecoinPrice(input.network, input.contractAddress);
  if (stablecoinPrice) return stablecoinPrice;

  const db = await getDb();
  if (!db) return null;

  const asset = await getOrCreateAsset({
    chainId: input.network,
    identifier: input.contractAddress,
    symbol: input.symbol ?? "UNKNOWN",
    name: input.symbol ?? "Unknown token",
    decimals: input.decimals,
  });
  if (!asset) return null;

  const cacheKey = `${input.network}:${normalizeIdentifier(input.network, input.contractAddress)}`;
  const decimals = input.decimals ?? asset.decimals ?? 18;

  // 1. Hot in-memory hit - fastest path, no round trip at all.
  const mem = memCache.get(cacheKey);
  if (mem && mem.expiresAt > Date.now()) return mem.data;

  // 2. Redis - shared across every API instance, still much faster than MySQL.
  const redisEntry = await getCachedAssetPrice(cacheKey);
  if (redisEntry) {
    memCache.set(cacheKey, { data: redisEntry, expiresAt: Date.now() + MEM_TTL_MS });
    return redisEntry;
  }

  // 3. DB - shared, persistent, but a real round trip. Served even if
  //    stale; a stale row triggers a background refresh (behind the
  //    distributed lock) instead of making the caller wait.
  const dbEntry = await readDbEntry(asset.id);
  if (dbEntry) {
    memCache.set(cacheKey, { data: dbEntry.result, expiresAt: Date.now() + MEM_TTL_MS });
    void setCachedAssetPrice(cacheKey, dbEntry.result); // repopulate Redis - it may have evicted/expired independently of MySQL's own staleness
    if (dbEntry.ageMs > DB_STALE_MS) {
      refreshInBackground(asset.id, input.network, input.contractAddress, decimals, cacheKey, dbEntry.result).catch((err) =>
        console.warn("[priceEngine] background refresh failed:", cacheKey, err),
      );
    }
    return dbEntry.result;
  }

  // 4. Nothing cached anywhere yet - the only path that waits on a live fetch.
  return refreshInBackground(asset.id, input.network, input.contractAddress, decimals, cacheKey, null);
}
