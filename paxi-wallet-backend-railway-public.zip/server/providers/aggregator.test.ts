import { describe, expect, it } from 'vitest';
import { aggregateMarkets } from './aggregator';
import { timestampMs, type ProviderMarket } from './types';

function market(overrides: Partial<ProviderMarket>): ProviderMarket {
  return {
    chainId: 'bsc',
    tokenAddress: '0x0000000000000000000000000000000000000001',
    pairAddress: '0x0000000000000000000000000000000000000002',
    baseToken: { address: '0x0000000000000000000000000000000000000001', name: 'Paxi', symbol: 'PAXI' },
    quoteToken: { address: '0x0000000000000000000000000000000000000003', name: 'USD Coin', symbol: 'USDC' },
    priceUsd: 1,
    volume24hUsd: 100,
    liquidityUsd: 1_000,
    priceChange24h: 2,
    fdvUsd: 10_000,
    marketCapUsd: 8_000,
    timestamp: Date.now(),
    source: 'test',
    sourceUpdatedAt: Date.now(),
    fetchedAt: Date.now(),
    ...overrides,
  };
}

describe('provider timestamp normalization', () => {
  it('converts seconds, milliseconds, and ISO timestamps to millisecond epoch', () => {
    expect(timestampMs(1_700_000_000)).toBe(1_700_000_000_000);
    expect(timestampMs('1700000000')).toBe(1_700_000_000_000);
    expect(timestampMs(1_700_000_000_000)).toBe(1_700_000_000_000);
    expect(timestampMs('2023-11-14T22:13:20.000Z')).toBe(1_700_000_000_000);
  });

  it('does not interpret a valid seconds timestamp as a 1996-era millisecond date', () => {
    const normalized = timestampMs(1_700_000_000);
    expect(new Date(normalized).getUTCFullYear()).toBe(2023);
  });
});

describe('provider price aggregation', () => {
  it('uses the median price and reports high confidence when three providers agree', () => {
    const result = aggregateMarkets([
      market({ source: 'dexpaprika', priceUsd: 1.002 }),
      market({ source: 'dexscreener', priceUsd: 1.0, liquidityUsd: 2_000 }),
      market({ source: 'geckoterminal', priceUsd: 0.998 }),
    ]);

    expect(result.priceUsd).toBe(1);
    expect(result.confidence).toBe('high');
    expect(result.primarySource).toBe('dexscreener');
    expect(result.sources).toEqual(['dexpaprika', 'dexscreener', 'geckoterminal']);
  });

  it('marks a single provider as low confidence and preserves provenance', () => {
    const result = aggregateMarkets([market({ source: 'geckoterminal', priceUsd: 2.5 })]);

    expect(result.priceUsd).toBe(2.5);
    expect(result.confidence).toBe('low');
    expect(result.sources).toEqual(['geckoterminal']);
    expect(result.primarySource).toBe('geckoterminal');
  });
});
