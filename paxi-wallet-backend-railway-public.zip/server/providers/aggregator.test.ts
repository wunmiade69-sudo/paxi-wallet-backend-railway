import { describe, expect, it } from 'vitest';
import { aggregateMarkets } from './aggregator';
import { timestampMs, type ProviderMarket } from './types';

function market(overrides: Partial<ProviderMarket>): ProviderMarket {
  return {
    chainId: 'bsc',
    tokenAddress: '0x0000000000000000000000000000000000000001',
    pairAddress: '0x0000000000000000000000000000000000000002',
    baseToken: { address: '0x0000000000000000000000000000000000000001', name: 'Paxi', symbol: 'PAXI' },
    quoteToken: { address: '0x0000000000000000000000000000000000000003', name: 'USD Coin', symbol: 'USDC' },
    priceUsd: 1,
    volume24hUsd: 100,
    liquidityUsd: 1_000,
    priceChange24h: 2,
    fdvUsd: 10_000,
    marketCapUsd: 8_000,
    timestamp: Date.now(),
    source: 'test',
    sourceUpdatedAt: Date.now(),
    fetchedAt: Date.now(),
    ...overrides,
  };
}

describe('provider timestamp normalization', () => {
  it('converts seconds, milliseconds, and ISO timestamps to millisecond epoch', () => {
    expect(timestampMs(1_700_000_000)).toBe(1_700_000_000_000);
    expect(timestampMs('1700000000')).toBe(1_700_000_000_000);
    expect(timestampMs(1_700_000_000_000)).toBe(1_700_000_000_000);
    expect(timestampMs('2023-11-14T22:13:20.000Z')).toBe(1_700_000_000_000);
  });

  it('does not interpret a valid seconds timestamp as a 1996-era millisecond date', () => {
    const normalized = timestampMs(1_700_000_000);
    expect(new Date(normalized).getUTCFullYear()).toBe(2023);
  });
});

describe('provider price aggregation', () => {
  it('uses the median price and reports high confidence when three providers agree', () => {
    const result = aggregateMarkets([
      market({ source: 'dexpaprika', priceUsd: 1.002 }),
      market({ source: 'dexscreener', priceUsd: 1.0, liquidityUsd: 2_000 }),
      market({ source: 'geckoterminal', priceUsd: 0.998 }),
    ]);

    expect(result.priceUsd).toBe(1);
    expect(result.confidence).toBe('high');
    expect(result.primarySource).toBe('dexscreener');
    expect(result.sources).toEqual(['dexpaprika', 'dexscreener', 'geckoterminal']);
  });

  it('marks a single provider as low confidence and preserves provenance', () => {
    const result = aggregateMarkets([market({ source: 'geckoterminal', priceUsd: 2.5 })]);

    expect(result.priceUsd).toBe(2.5);
    expect(result.confidence).toBe('low');
    expect(result.sources).toEqual(['geckoterminal']);
    expect(result.primarySource).toBe('geckoterminal');
  });
});


describe('provider-level consensus hardening', () => {
  it('counts one observation per provider even when one provider returns multiple pools', () => {
    const result = aggregateMarkets([
      market({ source: 'dexscreener', priceUsd: 1.0, liquidityUsd: 500_000 }),
      market({ source: 'dexscreener', priceUsd: 7.8, liquidityUsd: 10 }),
      market({ source: 'geckoterminal', priceUsd: 1.01, liquidityUsd: 20_000 }),
      market({ source: 'dexpaprika', priceUsd: 1.02, liquidityUsd: 30_000 }),
    ]);
    expect(result.sources).toEqual(['dexscreener', 'geckoterminal', 'dexpaprika']);
    expect(result.providerCount).toBe(3);
    expect(result.priceUsd).toBeCloseTo(1.01, 4);
  });

  it('selects the stronger liquid market within a provider', () => {
    const result = aggregateMarkets([
      market({ source: 'dexscreener', priceUsd: 1.4, liquidityUsd: 500 }),
      market({ source: 'dexscreener', priceUsd: 1.0, liquidityUsd: 500_000 }),
      market({ source: 'geckoterminal', priceUsd: 1.01, liquidityUsd: 20_000 }),
      market({ source: 'dexpaprika', priceUsd: 1.02, liquidityUsd: 30_000 }),
    ]);
    expect(result.primarySource).toBe('dexscreener');
    expect(result.priceUsd).toBeCloseTo(1.01, 4);
  });

  it('rejects an extreme provider-level outlier', () => {
    const result = aggregateMarkets([
      market({ source: 'dexscreener', priceUsd: 1.0, liquidityUsd: 100_000 }),
      market({ source: 'geckoterminal', priceUsd: 1.01, liquidityUsd: 100_000 }),
      market({ source: 'dexpaprika', priceUsd: 1.02, liquidityUsd: 100_000 }),
      market({ source: 'coingecko', priceUsd: 7.8, liquidityUsd: 100_000 }),
    ]);
    expect(result.outlierSources).toEqual(['coingecko']);
    expect(result.priceUsd).toBeCloseTo(1.01, 4);
  });

  it('lowers confidence for stale data rather than treating it as fresh', () => {
    const stale = Date.now() - 20 * 60_000;
    const result = aggregateMarkets([
      market({ source: 'dexscreener', priceUsd: 1.0, sourceUpdatedAt: stale, fetchedAt: stale }),
      market({ source: 'geckoterminal', priceUsd: 1.01, sourceUpdatedAt: stale, fetchedAt: stale }),
    ]);
    expect(result.isStale).toBe(true);
    expect(result.confidence).toBe('low');
  });

  it('returns an explicit unavailable result when no valid market exists', () => {
    const result = aggregateMarkets([market({ priceUsd: null }), market({ source: 'geckoterminal', priceUsd: 0 })]);
    expect(result.priceUsd).toBeNull();
    expect(result.confidence).toBe('none');
    expect(result.sources).toEqual([]);
  });
});


  it('does not let an extremely stale high-liquidity pool dominate a fresh pool', () => {
    const stale = Date.now() - 60 * 60_000;
    const result = aggregateMarkets([
      market({ source: 'dexscreener', priceUsd: 9.0, liquidityUsd: 10_000_000, sourceUpdatedAt: stale, fetchedAt: stale }),
      market({ source: 'dexscreener', priceUsd: 1.0, liquidityUsd: 1_000, sourceUpdatedAt: Date.now(), fetchedAt: Date.now() }),
      market({ source: 'geckoterminal', priceUsd: 1.01, liquidityUsd: 20_000 }),
    ]);
    expect(result.priceUsd).toBeCloseTo(1.005, 3);
    expect(result.outlierSources).toEqual([]);
  });
