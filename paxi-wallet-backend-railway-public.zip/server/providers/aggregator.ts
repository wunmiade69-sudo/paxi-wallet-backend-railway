import { marketProviders } from "./index";
import type { ProviderMarket } from "./types";
import { recordProviderFailure, recordProviderSuccess } from "./health";

export type Confidence = "high" | "medium" | "low" | "none";

export interface AggregatedMarket {
  priceUsd: number | null;
  change24h: number | null;
  volume24hUsd: number | null;
  liquidityUsd: number | null;
  fdvUsd: number | null;
  marketCapUsd: number | null;
  confidence: Confidence;
  confidenceScore: number;
  providerCount: number;
  sources: string[];
  outlierSources: string[];
  primarySource: string | null;
  sourceUpdatedAt: number | null;
  fetchedAt: number;
  isStale: boolean;
  markets: ProviderMarket[];
}

function median(values: number[]): number | null {
  if (!values.length) return null;
  const ordered = [...values].sort((a, b) => a - b);
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2
    ? ordered[middle]
    : (ordered[middle - 1] + ordered[middle]) / 2;
}

function marketFreshness(market: ProviderMarket, now: number): number {
  const updatedAt = market.sourceUpdatedAt ?? market.fetchedAt ?? now;
  const ageMs = Math.max(0, now - updatedAt);
  return Math.max(0, 1 - ageMs / (15 * 60_000));
}

function selectionScore(market: ProviderMarket, now: number): number {
  const liquidity = Math.log10(Math.max(0, market.liquidityUsd ?? 0) + 1);
  const volume = Math.log10(Math.max(0, market.volume24hUsd ?? 0) + 1);
  return liquidity * 0.6 + volume * 0.25 + marketFreshness(market, now) * 0.15;
}

function bestByProvider(
  markets: ProviderMarket[],
  now: number
): ProviderMarket | undefined {
  const freshnessCutoff = 10 * 60_000;
  const freshCandidates = markets.filter(
    market =>
      now - (market.sourceUpdatedAt ?? market.fetchedAt) <= freshnessCutoff
  );
  const candidates = freshCandidates.length ? freshCandidates : markets;
  return [...candidates].sort((a, b) => {
    const aAge = Math.max(0, now - (a.sourceUpdatedAt ?? a.fetchedAt));
    const bAge = Math.max(0, now - (b.sourceUpdatedAt ?? b.fetchedAt));
    const bothStale = aAge > freshnessCutoff && bAge > freshnessCutoff;
    if (bothStale && aAge !== bAge) return aAge - bAge;
    const score = selectionScore(b, now) - selectionScore(a, now);
    if (score !== 0) return score;
    return (
      (b.sourceUpdatedAt ?? b.fetchedAt) - (a.sourceUpdatedAt ?? a.fetchedAt)
    );
  })[0];
}

function confidenceFor(
  observations: ProviderMarket[],
  outlierCount: number,
  isStale: boolean
): { level: Confidence; score: number } {
  if (!observations.length) return { level: "none", score: 0 };
  const prices = observations.map(market => market.priceUsd as number);
  const center = median(prices) ?? 0;
  if (!center || !Number.isFinite(center)) return { level: "none", score: 0 };
  const relativeSpread = (Math.max(...prices) - Math.min(...prices)) / center;
  const agreement = Math.max(0, 1 - Math.min(relativeSpread / 0.35, 1));
  const providerFactor = Math.min(observations.length / 4, 1);
  const liquidity = observations.reduce(
    (sum, market) => sum + Math.max(0, market.liquidityUsd ?? 0),
    0
  );
  const liquidityFactor = Math.min(Math.log10(liquidity + 1) / 6, 1);
  const freshnessFactor = isStale ? 0.35 : 1;
  const outlierPenalty = outlierCount ? 0.8 : 1;
  let score = Math.round(
    100 *
      (providerFactor * 0.35 +
        agreement * 0.35 +
        liquidityFactor * 0.15 +
        freshnessFactor * 0.15) *
      outlierPenalty
  );
  if (observations.length < 2) score = Math.min(score, 44);
  else if (observations.length === 2) score = Math.min(score, 69);
  score = Math.max(0, Math.min(score, 100));
  const level: Confidence = isStale
    ? "low"
    : observations.length >= 3 && score >= 80
      ? "high"
      : observations.length >= 2 && score >= 55
        ? "medium"
        : "low";
  return { level, score: isStale ? Math.min(score, 44) : score };
}

function validMarkets(markets: ProviderMarket[]): ProviderMarket[] {
  return markets.filter(
    market =>
      market.priceUsd != null &&
      Number.isFinite(market.priceUsd) &&
      market.priceUsd > 0
  );
}

export function aggregateMarkets(markets: ProviderMarket[]): AggregatedMarket {
  const now = Date.now();
  const valid = validMarkets(markets);
  const byProvider = new Map<string, ProviderMarket[]>();
  for (const market of valid) {
    const bucket = byProvider.get(market.source) ?? [];
    bucket.push(market);
    byProvider.set(market.source, bucket);
  }

  const selected = [...byProvider.entries()]
    .map(
      ([source, candidates]) =>
        bestByProvider(candidates, now) ?? { ...candidates[0], source }
    )
    .filter((market): market is ProviderMarket => Boolean(market));

  const selectedMedian = median(
    selected.map(market => market.priceUsd as number)
  );
  const outlierSources =
    selected.length >= 3 && selectedMedian != null
      ? selected
          .filter(
            market =>
              Math.abs(
                ((market.priceUsd as number) - selectedMedian) / selectedMedian
              ) > 0.35
          )
          .map(market => market.source)
      : [];
  const observations = selected.filter(
    market => !outlierSources.includes(market.source)
  );
  const priceUsd = median(
    observations.map(market => market.priceUsd as number)
  );
  const primary = observations.length
    ? bestByProvider(observations, now)
    : undefined;
  const sourceUpdatedAt = observations.reduce<number | null>(
    (latest, market) => {
      if (market.sourceUpdatedAt == null) return latest;
      return latest == null
        ? market.sourceUpdatedAt
        : Math.max(latest, market.sourceUpdatedAt);
    },
    null
  );
  const isStale =
    observations.length > 0 &&
    observations.every(
      market => now - (market.sourceUpdatedAt ?? market.fetchedAt) > 120_000
    );
  const confidenceResult = confidenceFor(
    observations,
    outlierSources.length,
    isStale
  );

  return {
    priceUsd,
    change24h: primary?.priceChange24h ?? null,
    volume24hUsd: primary?.volume24hUsd ?? null,
    liquidityUsd: primary?.liquidityUsd ?? null,
    fdvUsd: primary?.fdvUsd ?? null,
    marketCapUsd: primary?.marketCapUsd ?? null,
    confidence: confidenceResult.level,
    confidenceScore: confidenceResult.score,
    providerCount: observations.length,
    sources: observations.map(market => market.source),
    outlierSources,
    primarySource: primary?.source ?? null,
    sourceUpdatedAt,
    fetchedAt: now,
    isStale,
    markets,
  };
}

export async function fetchAggregatedMarket(
  chainId: string,
  tokenAddress: string
): Promise<AggregatedMarket | null> {
  const results = await Promise.allSettled(
    marketProviders.map(async provider => {
      const startedAt = Date.now();
      try {
        const markets = await provider.getMarketsForToken(
          chainId,
          tokenAddress
        );
        recordProviderSuccess(provider.name, Date.now() - startedAt);
        return markets;
      } catch (error) {
        recordProviderFailure(
          provider.name,
          error instanceof Error ? error.message : String(error)
        );
        throw error;
      }
    })
  );
  const markets: ProviderMarket[] = [];
  for (const result of results) {
    if (result.status === "fulfilled") markets.push(...result.value);
    else
      console.warn(
        "[provider-layer] provider request failed:",
        result.reason instanceof Error ? result.reason.message : result.reason
      );
  }
  if (!markets.length) return null;
  return aggregateMarkets(markets);
}
