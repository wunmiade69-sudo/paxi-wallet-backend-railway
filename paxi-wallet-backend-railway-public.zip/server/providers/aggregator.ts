import { marketProviders } from "./index";
import type { ProviderMarket } from "./types";

export type Confidence = "high" | "medium" | "low" | "none";

export interface AggregatedMarket {
  priceUsd: number | null;
  change24h: number | null;
  volume24hUsd: number | null;
  liquidityUsd: number | null;
  fdvUsd: number | null;
  marketCapUsd: number | null;
  confidence: Confidence;
  sources: string[];
  primarySource: string | null;
  sourceUpdatedAt: number | null;
  fetchedAt: number;
  isStale: boolean;
  markets: ProviderMarket[];
}

function median(values: number[]): number | null {
  if (!values.length) return null;
  const ordered = [...values].sort((a, b) => a - b);
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2 ? ordered[middle] : (ordered[middle - 1] + ordered[middle]) / 2;
}

function confidence(prices: number[]): Confidence {
  if (!prices.length) return "none";
  if (prices.length === 1) return "low";
  const center = median(prices);
  if (center == null || center === 0) return "low";
  const spread = (Math.max(...prices) - Math.min(...prices)) / center;
  if (prices.length >= 3 && spread <= 0.01) return "high";
  if (spread <= 0.05) return "medium";
  return "low";
}

function bestByProvider(markets: ProviderMarket[]): ProviderMarket | undefined {
  return [...markets].sort((a, b) => {
    const liquidity = (b.liquidityUsd ?? 0) - (a.liquidityUsd ?? 0);
    if (liquidity !== 0) return liquidity;
    return b.fetchedAt - a.fetchedAt;
  })[0];
}

export function aggregateMarkets(markets: ProviderMarket[]): AggregatedMarket {
  const valid = markets.filter((market) => market.priceUsd != null && Number.isFinite(market.priceUsd));
  const prices = valid.map((market) => market.priceUsd as number);
  const priceUsd = median(prices);
  const primary = bestByProvider(valid);
  const fetchedAt = Date.now();
  const sourceUpdatedAt = valid.reduce<number | null>((latest, market) => {
    if (market.sourceUpdatedAt == null) return latest;
    return latest == null ? market.sourceUpdatedAt : Math.max(latest, market.sourceUpdatedAt);
  }, null);
  const ageMs = sourceUpdatedAt == null ? 0 : Math.max(0, fetchedAt - sourceUpdatedAt);
  return {
    priceUsd,
    change24h: primary?.priceChange24h ?? null,
    volume24hUsd: primary?.volume24hUsd ?? null,
    liquidityUsd: primary?.liquidityUsd ?? null,
    fdvUsd: primary?.fdvUsd ?? null,
    marketCapUsd: primary?.marketCapUsd ?? null,
    confidence: confidence(prices),
    sources: [...new Set(valid.map((market) => market.source))],
    primarySource: primary?.source ?? null,
    sourceUpdatedAt,
    fetchedAt,
    isStale: ageMs > 120_000,
    markets,
  };
}

export async function fetchAggregatedMarket(chainId: string, tokenAddress: string): Promise<AggregatedMarket | null> {
  const results = await Promise.allSettled(marketProviders.map((provider) => provider.getMarketsForToken(chainId, tokenAddress)));
  const markets: ProviderMarket[] = [];
  for (const result of results) {
    if (result.status === "fulfilled") markets.push(...result.value);
    else console.warn("[provider-layer] provider request failed:", result.reason instanceof Error ? result.reason.message : result.reason);
  }
  if (!markets.length) return null;
  return aggregateMarkets(markets);
}
