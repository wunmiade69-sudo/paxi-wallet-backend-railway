import { ENV } from "../_core/env";
import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, token, timestampMs, type MarketProvider, type ProviderMarket } from "./types";

interface BirdeyeEnvelope<T> {
  success?: boolean;
  data?: T | null;
  message?: string;
}

interface BirdeyePrice {
  value?: number | string | null;
  updateUnixTime?: number | string | null;
  updateHumanTime?: string | null;
}

interface BirdeyeOverview {
  name?: string | null;
  symbol?: string | null;
  liquidity?: number | string | null;
  v24hUSD?: number | string | null;
  priceChange24hPercent?: number | string | null;
  fdv?: number | string | null;
  mc?: number | string | null;
  marketCap?: number | string | null;
}

const CHAINS: Record<string, string> = {
  ethereum: "ethereum",
  eth: "ethereum",
  bsc: "bsc",
  binance: "bsc",
  polygon: "polygon",
  arbitrum: "arbitrum",
  base: "base",
  solana: "solana",
  avalanche: "avalanche",
  optimism: "optimism",
};

export class BirdeyeAdapter implements MarketProvider {
  readonly name = "birdeye";
  private readonly baseUrl = ENV.birdeyeApiBaseUrl.replace(/\/$/, "");

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const chain = normalizeChainSlug(chainId, CHAINS);
    const address = tokenAddress.trim();
    if (!ENV.birdeyeApiKey || !chain || !address) return [];

    const headers = { "X-API-KEY": ENV.birdeyeApiKey, "x-chain": chain };
    const priceResponse = await fetchJson<BirdeyeEnvelope<BirdeyePrice>>(
      `${this.baseUrl}/defi/price?address=${encodeURIComponent(address)}`,
      this.name,
      headers,
    );
    const overviewResponse = await fetchJson<BirdeyeEnvelope<BirdeyeOverview>>(
      `${this.baseUrl}/defi/token_overview?address=${encodeURIComponent(address)}`,
      this.name,
      headers,
    ).catch(() => ({ data: null }));

    const price = priceResponse.data;
    if (!price || numberOrNull(price.value) == null) return [];
    const overview = overviewResponse.data;
    const fetchedAt = Date.now();
    const sourceUpdatedAt = timestampMs(price.updateUnixTime ?? price.updateHumanTime, fetchedAt);

    return [{
      chainId,
      tokenAddress: address,
      pairAddress: null,
      baseToken: token({ address, name: overview?.name ?? null, symbol: overview?.symbol ?? null }),
      quoteToken: token({ address: "USD", name: "US Dollar", symbol: "USD" }),
      priceUsd: numberOrNull(price.value),
      volume24hUsd: numberOrNull(overview?.v24hUSD),
      liquidityUsd: numberOrNull(overview?.liquidity),
      priceChange24h: numberOrNull(overview?.priceChange24hPercent),
      fdvUsd: numberOrNull(overview?.fdv),
      marketCapUsd: numberOrNull(overview?.mc ?? overview?.marketCap),
      timestamp: fetchedAt,
      source: this.name,
      sourceUpdatedAt,
      fetchedAt,
    }];
  }
}
