import { fetchJson } from "./http";
import { ENV } from "../_core/env";

/**
 * BscScan contract lookup for EVM (BSC) tokens - used to check whether a
 * contract address the user is adding/sending has verified source on-chain,
 * as an extra signal alongside the RPC decimals check already done in
 * validateAsset() (server/fees/sendFee.ts). This never blocks a send by
 * itself; it is metadata for the UI to optionally surface ("Unverified
 * contract" warnings etc.), matching the codebase's "unavailable, not fake"
 * philosophy - a missing key or failed request returns null, not a guess.
 *
 * Docs: https://docs.bscscan.com/api-endpoints/contracts
 * Get a free key at https://bscscan.com/myapikey - this is a low-privilege
 * read key (no wallet/account access), safe to store as a plain env var.
 */
export interface BscScanContractInfo {
  address: string;
  contractName: string | null;
  isVerified: boolean;
  compilerVersion: string | null;
  /** Verified Solidity source, if available - used by aiSecurityAnalysis.ts for pattern review. Not exposed in the UI directly. */
  sourceCode: string | null;
}

interface BscScanSourceCodeResult {
  ContractName?: string;
  CompilerVersion?: string;
  SourceCode?: string;
  ABI?: string;
}

interface BscScanApiResponse<T> {
  status: string;
  message: string;
  result: T;
}

const BSCSCAN_BASE_URL = "https://api.bscscan.com/api";

export async function getBscScanContractInfo(address: string): Promise<BscScanContractInfo | null> {
  if (!ENV.bscscanApiKey) return null;
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) return null;

  try {
    const url = `${BSCSCAN_BASE_URL}?module=contract&action=getsourcecode&address=${encodeURIComponent(address)}&apikey=${encodeURIComponent(ENV.bscscanApiKey)}`;
    const data = await fetchJson<BscScanApiResponse<BscScanSourceCodeResult[]>>(url, "bscscan");
    const entry = Array.isArray(data.result) ? data.result[0] : undefined;
    if (!entry) return null;

    const hasSource = typeof entry.SourceCode === "string" && entry.SourceCode.trim().length > 0;
    return {
      address,
      contractName: entry.ContractName?.trim() || null,
      isVerified: hasSource,
      compilerVersion: entry.CompilerVersion?.trim() || null,
      sourceCode: hasSource ? entry.SourceCode! : null,
    };
  } catch (err) {
    console.warn(`BscScan contract lookup failed for ${address}:`, err);
    return null;
  }
}
