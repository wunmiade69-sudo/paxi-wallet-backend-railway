import { fetchJson } from "./http";

const BYBIT_BASE_URL = "https://api.bybit.com/v5";

interface BybitTickerResponse {
  retCode: number;
  result?: { list?: Array<{ symbol: string; lastPrice: string }> };
}

/** Public spot ticker, no API key needed. `symbol` is Bybit format e.g. "BTCUSDT". */
export async function getBybitSpotTicker(symbol: string): Promise<{ priceUsd: number; timestampMs: number } | null> {
  try {
    const url = `${BYBIT_BASE_URL}/market/tickers?category=spot&symbol=${encodeURIComponent(symbol)}`;
    const data = await fetchJson<BybitTickerResponse>(url, "bybit");
    const entry = data.result?.list?.[0];
    const price = entry ? Number(entry.lastPrice) : NaN;
    if (data.retCode !== 0 || !entry || !Number.isFinite(price)) return null;
    return { priceUsd: price, timestampMs: Date.now() };
  } catch (err) {
    console.warn(`Bybit ticker lookup failed for ${symbol}:`, err);
    return null;
  }
}
