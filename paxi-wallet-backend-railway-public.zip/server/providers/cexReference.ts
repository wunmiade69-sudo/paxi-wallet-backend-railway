import { getBinanceNativePrice } from "./nativePrice";
import { getOkxSpotTicker } from "./okx";
import { getGateioSpotTicker } from "./gateio";
import { getBybitSpotTicker } from "./bybit";
import { getKucoinSpotTicker } from "./kucoin";

/**
 * Cross-references a native asset's price across five CEXs instead of
 * trusting one. Two uses: (1) a "reference price" for the Markets tab that
 * doesn't go dark if any single exchange has an outage (the exact failure
 * mode that broke Jupiter), and (2) a sanity check against DEX/aggregator
 * swap quotes - if a swap quote's implied price is wildly off the CEX
 * median, that's worth surfacing before the user signs.
 */
export type CexSource = "binance" | "okx" | "gateio" | "bybit" | "kucoin";

interface CexSymbols {
  okx: string; // "BNB-USDT"
  gateio: string; // "BNB_USDT"
  bybit: string; // "BNBUSDT"
  kucoin: string; // "BNB-USDT"
}

const CEX_SYMBOLS: Record<string, CexSymbols> = {
  bsc: { okx: "BNB-USDT", gateio: "BNB_USDT", bybit: "BNBUSDT", kucoin: "BNB-USDT" },
  ethereum: { okx: "ETH-USDT", gateio: "ETH_USDT", bybit: "ETHUSDT", kucoin: "ETH-USDT" },
  bitcoin: { okx: "BTC-USDT", gateio: "BTC_USDT", bybit: "BTCUSDT", kucoin: "BTC-USDT" },
  solana: { okx: "SOL-USDT", gateio: "SOL_USDT", bybit: "SOLUSDT", kucoin: "SOL-USDT" },
  polygon: { okx: "POL-USDT", gateio: "POL_USDT", bybit: "POLUSDT", kucoin: "POL-USDT" },
  arbitrum: { okx: "ETH-USDT", gateio: "ETH_USDT", bybit: "ETHUSDT", kucoin: "ETH-USDT" },
};

export interface CexReferencePrice {
  medianPriceUsd: number;
  sourceCount: number;
  sources: Partial<Record<CexSource, number>>;
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

export async function getCexReferencePrice(chain: string): Promise<CexReferencePrice | null> {
  const symbols = CEX_SYMBOLS[chain.trim().toLowerCase()];
  if (!symbols) return null;

  const [binance, okx, gateio, bybit, kucoin] = await Promise.allSettled([
    getBinanceNativePrice(chain),
    getOkxSpotTicker(symbols.okx),
    getGateioSpotTicker(symbols.gateio),
    getBybitSpotTicker(symbols.bybit),
    getKucoinSpotTicker(symbols.kucoin),
  ]);

  const sources: Partial<Record<CexSource, number>> = {};
  if (binance.status === "fulfilled" && binance.value) sources.binance = binance.value.priceUsd;
  if (okx.status === "fulfilled" && okx.value) sources.okx = okx.value.priceUsd;
  if (gateio.status === "fulfilled" && gateio.value) sources.gateio = gateio.value.priceUsd;
  if (bybit.status === "fulfilled" && bybit.value) sources.bybit = bybit.value.priceUsd;
  if (kucoin.status === "fulfilled" && kucoin.value) sources.kucoin = kucoin.value.priceUsd;

  const values = Object.values(sources).filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  if (values.length === 0) return null;
  return { medianPriceUsd: median(values), sourceCount: values.length, sources };
}
