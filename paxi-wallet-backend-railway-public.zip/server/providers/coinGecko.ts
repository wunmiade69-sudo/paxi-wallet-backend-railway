import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, timestampMs, token, type MarketProvider, type ProviderMarket, type ProviderOhlcv } from "./types";

interface CoinGeckoMarket {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number | null;
  total_volume: number;
  price_change_percentage_24h: number | null;
  last_updated: string;
}

interface CoinGeckoChartResponse {
  prices: [number, number][];
  market_caps: [number, number][];
  total_volumes: [number, number][];
}

const NETWORKS: Record<string, string> = {
  ethereum: "ethereum",
  eth: "ethereum",
  bsc: "binance-smart-chain",
  binance: "binance-smart-chain",
  polygon: "polygon-pos",
  arbitrum: "arbitrum-one",
  solana: "solana",
};

export class CoinGeckoAdapter implements MarketProvider {
  readonly name = "coingecko";
  private readonly baseUrl = "https://api.coingecko.com/api/v3";
  private readonly apiKey = process.env.COINGECKO_API_KEY;
  private readonly headers: Record<string, string> = this.apiKey ? { "x-cg-demo-api-key": this.apiKey } : {};

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const platform = normalizeChainSlug(chainId, NETWORKS);
    if (!platform || !tokenAddress.trim()) return [];

    // CoinGecko /coins/markets doesn't support direct address lookup easily for all tokens,
    // but we can use /coins/{platform}/contract/{contract_address}
    const url = `${this.baseUrl}/coins/${encodeURIComponent(platform)}/contract/${encodeURIComponent(tokenAddress.trim())}`;
    try {
      const c = await fetchJson<any>(url, this.name, this.headers);
      const fetchedAt = Date.now();
      const sourceUpdatedAt = c.last_updated ? timestampMs(c.last_updated, fetchedAt) : null;
      
      return [{
        chainId,
        tokenAddress,
        pairAddress: tokenAddress, // CoinGecko treats the contract itself as the identifier
        baseToken: token({ address: tokenAddress, name: c.name, symbol: c.symbol }),
        quoteToken: token({ address: "USD", name: "US Dollar", symbol: "USD" }),
        priceUsd: numberOrNull(c.market_data?.current_price?.usd),
        volume24hUsd: numberOrNull(c.market_data?.total_volume?.usd),
        liquidityUsd: null,
        priceChange24h: numberOrNull(c.market_data?.price_change_percentage_24h),
        fdvUsd: numberOrNull(c.market_data?.fully_diluted_valuation?.usd),
        marketCapUsd: numberOrNull(c.market_data?.market_cap?.usd),
        timestamp: sourceUpdatedAt ?? fetchedAt,
        source: this.name,
        sourceUpdatedAt,
        fetchedAt,
      }];
    } catch {
      return [];
    }
  }

  async getOhlcv(chainId: string, pairAddress: string, timeframe: string, limit: number): Promise<ProviderOhlcv[]> {
    const platform = normalizeChainSlug(chainId, NETWORKS);
    if (!platform || !pairAddress.trim()) return [];

    // timeframe to days mapping
    const timeframeToDays: Record<string, string> = {
      "1m": "1",
      "5m": "1",
      "15m": "1",
      "30m": "1",
      "1h": "1",
      "4h": "7",
      "1d": "30",
    };
    const days = timeframeToDays[timeframe] || "30";

    const url = `${this.baseUrl}/coins/${encodeURIComponent(platform)}/contract/${encodeURIComponent(pairAddress.trim())}/market_chart?vs_currency=usd&days=${days}`;
    try {
      const data = await fetchJson<CoinGeckoChartResponse>(url, `${this.name}-ohlcv`, this.headers);
      return (data.prices ?? []).map(([timestamp, price]) => ({
        timestamp: timestampMs(timestamp),
        open: price,
        high: price,
        low: price,
        close: price,
        volume: null,
        source: this.name,
      })).slice(-limit);
    } catch {
      return [];
    }
  }

  /** Special method for native assets that don't have a contract address */
  async getNativeOhlcv(coinId: string, timeframe: string, limit: number): Promise<ProviderOhlcv[]> {
    const timeframeToDays: Record<string, string> = {
      "1m": "1",
      "5m": "1",
      "15m": "1",
      "30m": "1",
      "1h": "1",
      "4h": "7",
      "1d": "30",
    };
    const days = timeframeToDays[timeframe] || "30";
    const url = `${this.baseUrl}/coins/${encodeURIComponent(coinId)}/market_chart?vs_currency=usd&days=${days}`;
    
    try {
      const data = await fetchJson<CoinGeckoChartResponse>(url, `${this.name}-native-ohlcv`, this.headers);
      return (data.prices ?? []).map(([timestamp, price]) => ({
        timestamp: timestampMs(timestamp),
        open: price,
        high: price,
        low: price,
        close: price,
        volume: null,
        source: this.name,
      })).slice(-limit);
    } catch {
      return [];
    }
  }
}
