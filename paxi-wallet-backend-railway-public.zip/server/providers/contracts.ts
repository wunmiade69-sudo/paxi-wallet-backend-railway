import type { AssetIdentity } from "../identity/assetIdentity";

export const PROVIDER_CAPABILITIES = [
  "PRICE",
  "TOKEN_METADATA",
  "LOGO",
  "SEARCH",
  "OHLCV",
  "LIQUIDITY",
  "DEX_PAIRS",
  "CEX_TICKER",
  "CEX_ORDERBOOK",
  "SECURITY",
  "NFT",
  "RPC",
  "BALANCE",
  "TRANSACTION_HISTORY",
  "SWAP_QUOTE",
  "BRIDGE_QUOTE",
] as const;

export type ProviderCapability = (typeof PROVIDER_CAPABILITIES)[number];
export type ProviderHealthState = "unknown" | "healthy" | "degraded" | "open";

export interface FieldProvenance {
  source: string;
  sourceTimestamp: number | null;
  fetchedAt: number;
  confidence?: "low" | "medium" | "high";
}

export interface NormalizedValue<T> {
  value: T | null;
  provenance: FieldProvenance | null;
}

export interface AssetMetadataSnapshot {
  identity: AssetIdentity;
  name: string | null;
  symbol: string | null;
  decimals: number | null;
  logo: string | null;
  description: string | null;
  verified: boolean | null;
  source: string | null;
  timestamp: number;
  stale: boolean;
}

export interface MarketSnapshot {
  identity: AssetIdentity;
  price: NormalizedValue<number>;
  currency: string;
  priceChange24h: NormalizedValue<number>;
  marketCap: NormalizedValue<number>;
  volume24h: NormalizedValue<number>;
  source: string | null;
  timestamp: number;
  confidence: "low" | "medium" | "high" | null;
  stale: boolean;
}

export interface LiquiditySnapshot {
  identity: AssetIdentity;
  chain: string;
  dex: string | null;
  pairAddress: string | null;
  baseToken: string | null;
  quoteToken: string | null;
  liquidityUsd: NormalizedValue<number>;
  volume24h: NormalizedValue<number>;
  type: "pair" | "observed_aggregate";
  source: string | null;
  timestamp: number;
  stale: boolean;
}

export interface ChartSnapshot {
  identity: AssetIdentity;
  timeframe: string;
  candles: Array<{ timestamp: number; open: number; high: number; low: number; close: number; volume: number | null }>;
  source: string | null;
  timestamp: number;
  stale: boolean;
}

export interface SecuritySnapshot {
  identity: AssetIdentity;
  provider: string | null;
  riskLevel: "low" | "medium" | "high" | "unknown";
  signals: string[];
  warnings: string[];
  timestamp: number;
  stale: boolean;
}

export interface ProviderDefinition {
  id: string;
  name: string;
  type: "market" | "dex" | "cex" | "security" | "rpc" | "nft" | "metadata";
  authentication: "none" | "api_key" | "oauth" | "server_secret";
  supportedChains: readonly string[];
  capabilities: readonly ProviderCapability[];
  priority: Partial<Record<ProviderCapability, number>>;
  enabled: boolean;
  configured: boolean;
  timeoutMs: number;
  cacheTtlMs: number;
  rateLimit: { requests: number; windowMs: number } | null;
  cachePolicy: { staleWhileRevalidate: boolean; allowStaleOnError: boolean };
  healthPolicy: { failureThreshold: number; resetTimeoutMs: number };
  health: ProviderHealthState;
}

export interface ProviderRequestContext {
  identity?: AssetIdentity;
  chain?: string;
  operation: string;
  signal?: AbortSignal;
}

export interface MarketDataProvider {
  readonly definition: ProviderDefinition;
  getMarketSnapshot(context: ProviderRequestContext): Promise<MarketSnapshot | null>;
}

export interface TokenMetadataProvider {
  readonly definition: ProviderDefinition;
  getTokenMetadata(context: ProviderRequestContext): Promise<AssetMetadataSnapshot | null>;
}

export interface LogoProvider {
  readonly definition: ProviderDefinition;
  getTokenLogo(context: ProviderRequestContext): Promise<string | null>;
}

export interface ChartProvider {
  readonly definition: ProviderDefinition;
  getChart(context: ProviderRequestContext & { timeframe: string }): Promise<ChartSnapshot | null>;
}

export interface LiquidityProvider {
  readonly definition: ProviderDefinition;
  getLiquidity(context: ProviderRequestContext): Promise<LiquiditySnapshot | null>;
}

export interface SecurityProvider {
  readonly definition: ProviderDefinition;
  getSecurity(context: ProviderRequestContext): Promise<SecuritySnapshot | null>;
}

export interface DexProvider {
  readonly definition: ProviderDefinition;
  getDexPairs(context: ProviderRequestContext): Promise<LiquiditySnapshot[] | null>;
}

export interface CexProvider {
  readonly definition: ProviderDefinition;
  getCexMarkets(context: ProviderRequestContext): Promise<Array<{ symbol: string; price: number | null; volume24h: number | null; source: string }> | null>;
}

export interface RpcProvider {
  readonly definition: ProviderDefinition;
  execute<T>(context: ProviderRequestContext, operation: (endpoint: string) => Promise<T>): Promise<T>;
}

export interface NftProvider {
  readonly definition: ProviderDefinition;
  getNfts(context: ProviderRequestContext): Promise<unknown[] | null>;
}

/** Execution capabilities remain separate from market-data adapters. */
export interface SwapQuoteProvider {
  readonly definition: ProviderDefinition;
  getSwapQuote(context: ProviderRequestContext): Promise<unknown | null>;
}

export interface BridgeQuoteProvider {
  readonly definition: ProviderDefinition;
  getBridgeQuote(context: ProviderRequestContext): Promise<unknown | null>;
}

export interface CapabilityProvider {
  readonly definition: ProviderDefinition;
  getMarketSnapshot?(context: ProviderRequestContext): Promise<MarketSnapshot | null>;
  getTokenMetadata?(context: ProviderRequestContext): Promise<AssetMetadataSnapshot | null>;
  getTokenLogo?(context: ProviderRequestContext): Promise<string | null>;
  searchTokens?(query: string, chain: string | null, context: ProviderRequestContext): Promise<AssetMetadataSnapshot[]>;
  getLiquidity?(context: ProviderRequestContext): Promise<LiquiditySnapshot | null>;
  getChart?(context: ProviderRequestContext & { timeframe: string }): Promise<ChartSnapshot | null>;
  getSecurity?(context: ProviderRequestContext): Promise<SecuritySnapshot | null>;
}

export interface ProviderRequestTelemetry {
  provider: string;
  operation: string;
  chain: string | null;
  latencyMs: number;
  success: boolean;
  status: number | null;
  cacheHit: boolean;
  fallbackUsed: boolean;
}
