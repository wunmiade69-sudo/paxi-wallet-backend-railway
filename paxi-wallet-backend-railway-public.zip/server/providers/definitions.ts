import type { ProviderCapability, ProviderDefinition } from "./contracts";

function configured(...keys: string[]): boolean {
  return keys.some((key) => Boolean(process.env[key]?.trim()));
}

function definition(
  id: string,
  name: string,
  type: ProviderDefinition["type"],
  supportedChains: readonly string[],
  capabilities: readonly ProviderCapability[],
  priority: Partial<Record<ProviderCapability, number>>,
  configuredBy: string[] = [],
): ProviderDefinition {
  const isConfigured = configuredBy.length === 0 ? true : configured(...configuredBy);
  return {
    id,
    name,
    type,
    authentication: configuredBy.length === 0 ? "none" : "api_key",
    supportedChains,
    capabilities,
    priority,
    enabled: isConfigured,
    configured: isConfigured,
    timeoutMs: 8_000,
    cacheTtlMs: 60_000,
    rateLimit: { requests: 60, windowMs: 60_000 },
    cachePolicy: { staleWhileRevalidate: true, allowStaleOnError: true },
    healthPolicy: { failureThreshold: 5, resetTimeoutMs: 30_000 },
    health: "unknown",
  };
}

export const providerDefinitions: readonly ProviderDefinition[] = [
  definition("binance", "Binance", "cex", ["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"], ["PRICE", "OHLCV", "CEX_TICKER"], { PRICE: 5, OHLCV: 5, CEX_TICKER: 10 }),
  definition("coingecko", "CoinGecko", "market", ["ethereum", "bsc", "polygon", "arbitrum", "solana", "bitcoin"], ["PRICE", "TOKEN_METADATA", "LOGO", "SEARCH", "OHLCV"], { PRICE: 10, TOKEN_METADATA: 10, LOGO: 10, SEARCH: 10, OHLCV: 10 }),
  definition("dexpaprika", "DexPaprika", "market", ["ethereum", "bsc", "polygon", "arbitrum", "solana"], ["PRICE", "TOKEN_METADATA", "LOGO", "SEARCH", "OHLCV", "LIQUIDITY"], { PRICE: 30, TOKEN_METADATA: 20, LOGO: 30, SEARCH: 20, OHLCV: 20, LIQUIDITY: 30 }),
  definition("dexscreener", "DexScreener", "dex", ["ethereum", "bsc", "polygon", "arbitrum", "solana"], ["PRICE", "LOGO", "SEARCH", "OHLCV", "LIQUIDITY", "DEX_PAIRS"], { PRICE: 20, LOGO: 20, SEARCH: 30, OHLCV: 20, LIQUIDITY: 10, DEX_PAIRS: 10 }),
  definition("geckoterminal", "GeckoTerminal", "dex", ["ethereum", "bsc", "polygon", "arbitrum", "solana"], ["PRICE", "SEARCH", "OHLCV", "LIQUIDITY", "DEX_PAIRS"], { PRICE: 40, SEARCH: 40, OHLCV: 30, LIQUIDITY: 20, DEX_PAIRS: 20 }),
  definition("birdeye", "Birdeye", "market", ["ethereum", "bsc", "polygon", "arbitrum", "solana"], ["PRICE", "TOKEN_METADATA", "LOGO", "SEARCH", "OHLCV", "LIQUIDITY"], { PRICE: 10, TOKEN_METADATA: 10, LOGO: 10, SEARCH: 10, OHLCV: 10, LIQUIDITY: 10 }, ["BIRDEYE_API_KEY"]),
  definition("goplus", "GoPlus", "security", ["ethereum", "bsc", "polygon", "arbitrum"], ["SECURITY"], { SECURITY: 10 }),
];

export function getProviderDefinition(id: string): ProviderDefinition | undefined {
  return providerDefinitions.find((provider) => provider.id === id);
}

export function listProviderDefinitions(): ProviderDefinition[] {
  return providerDefinitions.map((provider) => ({ ...provider, capabilities: [...provider.capabilities], supportedChains: [...provider.supportedChains] }));
}

export function providersForCapability(capability: ProviderCapability, chain: string | null): ProviderDefinition[] {
  return providerDefinitions
    .filter((provider) => provider.enabled && provider.capabilities.includes(capability) && (!chain || provider.supportedChains.includes(chain)))
    .sort((a, b) => (a.priority[capability] ?? Number.MAX_SAFE_INTEGER) - (b.priority[capability] ?? Number.MAX_SAFE_INTEGER));
}
