import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, timestampMs, token, type MarketProvider, type ProviderMarket } from "./types";

interface DexPaprikaTokenResponse {
  id?: string;
  name?: string;
  symbol?: string;
  chain?: string;
  summary?: {
    price_usd?: number;
    fdv?: number;
    liquidity_usd?: number;
    volume_usd?: number;
    [key: string]: unknown;
  };
  last_updated?: string;
}

const NETWORKS: Record<string, string> = {
  ethereum: "ethereum",
  eth: "ethereum",
  bsc: "bsc",
  binance: "bsc",
  polygon: "polygon",
  polygon_pos: "polygon",
  arbitrum: "arbitrum",
  base: "base",
  solana: "solana",
};

export class DexPaprikaAdapter implements MarketProvider {
  readonly name = "dexpaprika";
  private readonly baseUrl = "https://api.dexpaprika.com";

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const network = normalizeChainSlug(chainId, NETWORKS);
    if (!network || !tokenAddress.trim()) return [];
    const data = await fetchJson<DexPaprikaTokenResponse>(
      `${this.baseUrl}/networks/${encodeURIComponent(network)}/tokens/${encodeURIComponent(tokenAddress.trim())}`,
      this.name,
    );
    const summary = data.summary ?? {};
    const fetchedAt = Date.now();
    const sourceUpdatedAt = data.last_updated ? timestampMs(data.last_updated, fetchedAt) : null;
    return [{
      chainId,
      tokenAddress,
      pairAddress: null,
      baseToken: token({ address: data.id ?? tokenAddress, name: data.name, symbol: data.symbol }),
      quoteToken: token({ address: "USD", name: "US Dollar", symbol: "USD" }),
      priceUsd: numberOrNull(summary.price_usd),
      volume24hUsd: numberOrNull(summary.volume_usd ?? (summary["24h"] as Record<string, unknown> | undefined)?.volume_usd),
      liquidityUsd: numberOrNull(summary.liquidity_usd),
      priceChange24h: null,
      fdvUsd: numberOrNull(summary.fdv),
      marketCapUsd: null,
      timestamp: sourceUpdatedAt ?? fetchedAt,
      source: this.name,
      sourceUpdatedAt,
      fetchedAt,
    }];
  }
}
