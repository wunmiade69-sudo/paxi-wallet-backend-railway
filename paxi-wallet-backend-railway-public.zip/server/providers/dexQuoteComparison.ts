import { getUniswapV3Quote, isUniswapSupportedChain } from "./uniswap";
import { getPancakeSwapV3Quote } from "./pancakeswap";

export interface DirectDexQuote {
  source: "uniswap_v3" | "pancakeswap_v3";
  amountOut: string;
  feeTierBps: number;
}

/**
 * Direct, on-chain quotes from the underlying DEXs themselves - independent
 * of Velora/ParaSwap. Velora already routes through Uniswap/PancakeSwap
 * internally (see routeNames in server/veloraQuote.ts), so this isn't a
 * replacement; it's a second, API-independent opinion the swap screen can
 * show alongside the aggregator quote, and something to fall back to
 * displaying if Velora is ever unreachable.
 */
export async function getDirectDexQuotes(chain: string, tokenIn: string, tokenOut: string, amountIn: string): Promise<DirectDexQuote[]> {
  const normalizedChain = chain.trim().toLowerCase();
  const quotes: DirectDexQuote[] = [];

  if (normalizedChain === "bsc") {
    const quote = await getPancakeSwapV3Quote(tokenIn, tokenOut, amountIn).catch(() => null);
    if (quote) quotes.push({ source: "pancakeswap_v3", amountOut: quote.amountOut, feeTierBps: quote.feeTier / 100 });
  }
  if (isUniswapSupportedChain(normalizedChain)) {
    const quote = await getUniswapV3Quote(normalizedChain, tokenIn, tokenOut, amountIn).catch(() => null);
    if (quote) quotes.push({ source: "uniswap_v3", amountOut: quote.amountOut, feeTierBps: quote.feeTier / 100 });
  }
  return quotes;
}
