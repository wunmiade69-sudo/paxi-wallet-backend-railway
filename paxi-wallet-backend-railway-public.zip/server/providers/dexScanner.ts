import { ENV } from "../_core/env";
import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, token, timestampMs, type MarketProvider, type ProviderMarket } from "./types";

/**
 * DexScanner is intentionally opt-in. No current official public API contract
 * was found during the audit, so PAXI must not invent a URL or silently parse
 * an unrelated service. A deployment can enable this adapter by providing a
 * documented endpoint that returns the shared ProviderMarket-compatible shape.
 */
interface DexScannerMarketResponse {
  markets?: Array<{
    pairAddress?: string | null;
    baseToken?: { address?: string; name?: string; symbol?: string };
    quoteToken?: { address?: string; name?: string; symbol?: string };
    priceUsd?: number | string | null;
    volume24hUsd?: number | string | null;
    liquidityUsd?: number | string | null;
    priceChange24h?: number | string | null;
    fdvUsd?: number | string | null;
    marketCapUsd?: number | string | null;
    sourceUpdatedAt?: number | string | null;
  }>;
}

const CHAINS: Record<string, string> = {
  ethereum: "ethereum",
  eth: "ethereum",
  bsc: "bsc",
  binance: "bsc",
  polygon: "polygon",
  arbitrum: "arbitrum",
  base: "base",
  solana: "solana",
};

export class DexScannerAdapter implements MarketProvider {
  readonly name = "dexscanner";
  private readonly baseUrl = ENV.dexScannerApiBaseUrl.replace(/\/$/, "");

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const chain = normalizeChainSlug(chainId, CHAINS);
    const address = tokenAddress.trim();
    if (!this.baseUrl || !ENV.dexScannerApiKey || !chain || !address) return [];

    const data = await fetchJson<DexScannerMarketResponse>(
      `${this.baseUrl}/token/${encodeURIComponent(chain)}/${encodeURIComponent(address)}`,
      this.name,
      { Authorization: `Bearer ${ENV.dexScannerApiKey}` },
    );
    const fetchedAt = Date.now();
    return (data.markets ?? []).map((market) => ({
      chainId,
      tokenAddress: address,
      pairAddress: market.pairAddress ?? null,
      baseToken: token(market.baseToken),
      quoteToken: token(market.quoteToken),
      priceUsd: numberOrNull(market.priceUsd),
      volume24hUsd: numberOrNull(market.volume24hUsd),
      liquidityUsd: numberOrNull(market.liquidityUsd),
      priceChange24h: numberOrNull(market.priceChange24h),
      fdvUsd: numberOrNull(market.fdvUsd),
      marketCapUsd: numberOrNull(market.marketCapUsd),
      timestamp: fetchedAt,
      source: this.name,
      sourceUpdatedAt: timestampMs(market.sourceUpdatedAt, fetchedAt),
      fetchedAt,
    }));
  }
}
