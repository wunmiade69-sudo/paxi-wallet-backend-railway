import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, token, type MarketProvider, type ProviderMarket } from "./types";

interface DexScreenerPair {
  chainId?: string;
  pairAddress?: string;
  baseToken?: { address?: string; name?: string; symbol?: string };
  quoteToken?: { address?: string; name?: string; symbol?: string };
  priceUsd?: string | null;
  volume?: Record<string, number>;
  priceChange?: Record<string, number> | null;
  liquidity?: { usd?: number | null } | null;
  fdv?: number | null;
  marketCap?: number | null;
  pairCreatedAt?: number | null;
}

interface DexScreenerResponse {
  pairs?: DexScreenerPair[] | null;
}

const NETWORKS: Record<string, string> = {
  ethereum: "ethereum",
  eth: "ethereum",
  bsc: "bsc",
  binance: "bsc",
  polygon: "polygon",
  arbitrum: "arbitrum",
  base: "base",
  solana: "solana",
};

export class DexScreenerAdapter implements MarketProvider {
  readonly name = "dexscreener";
  private readonly baseUrl = "https://api.dexscreener.com";

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const network = normalizeChainSlug(chainId, NETWORKS);
    if (!network || !tokenAddress.trim()) return [];
    const data = await fetchJson<DexScreenerResponse>(
      `${this.baseUrl}/token-pairs/v1/${encodeURIComponent(network)}/${encodeURIComponent(tokenAddress.trim())}`,
      this.name,
    );
    const fetchedAt = Date.now();
    return (data.pairs ?? []).map((pair) => ({
      chainId,
      tokenAddress,
      pairAddress: pair.pairAddress ?? null,
      baseToken: token(pair.baseToken),
      quoteToken: token(pair.quoteToken),
      priceUsd: numberOrNull(pair.priceUsd),
      volume24hUsd: numberOrNull(pair.volume?.h24),
      liquidityUsd: numberOrNull(pair.liquidity?.usd),
      priceChange24h: numberOrNull(pair.priceChange?.h24),
      fdvUsd: numberOrNull(pair.fdv),
      marketCapUsd: numberOrNull(pair.marketCap),
      timestamp: fetchedAt,
      source: this.name,
      sourceUpdatedAt: null,
      fetchedAt,
    }));
  }
}
