import { fetchJson } from "./http";
import { ENV } from "../_core/env";

/**
 * Etherscan contract lookup for EVM (Ethereum) tokens, mirroring
 * bscscan.ts (BscScan and Etherscan share the identical legacy API shape).
 * Get a free key at https://etherscan.io/myapikey.
 */
export interface EtherscanContractInfo {
  address: string;
  contractName: string | null;
  isVerified: boolean;
  compilerVersion: string | null;
  sourceCode: string | null;
}

interface EtherscanSourceCodeResult {
  ContractName?: string;
  CompilerVersion?: string;
  SourceCode?: string;
  ABI?: string;
}

interface EtherscanApiResponse<T> {
  status: string;
  message: string;
  result: T;
}

const ETHERSCAN_BASE_URL = "https://api.etherscan.io/api";

export async function getEtherscanContractInfo(address: string): Promise<EtherscanContractInfo | null> {
  if (!ENV.etherscanApiKey) return null;
  if (!/^0x[0-9a-fA-F]{40}$/.test(address)) return null;

  try {
    const url = `${ETHERSCAN_BASE_URL}?module=contract&action=getsourcecode&address=${encodeURIComponent(address)}&apikey=${encodeURIComponent(ENV.etherscanApiKey)}`;
    const data = await fetchJson<EtherscanApiResponse<EtherscanSourceCodeResult[]>>(url, "etherscan");
    const entry = Array.isArray(data.result) ? data.result[0] : undefined;
    if (!entry) return null;

    const hasSource = typeof entry.SourceCode === "string" && entry.SourceCode.trim().length > 0;
    return {
      address,
      contractName: entry.ContractName?.trim() || null,
      isVerified: hasSource,
      compilerVersion: entry.CompilerVersion?.trim() || null,
      sourceCode: hasSource ? entry.SourceCode! : null,
    };
  } catch (err) {
    console.warn(`Etherscan contract lookup failed for ${address}:`, err);
    return null;
  }
}
