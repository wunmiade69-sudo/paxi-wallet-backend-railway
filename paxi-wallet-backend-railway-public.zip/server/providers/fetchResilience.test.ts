import { describe, expect, it, vi } from 'vitest';
import type { ProviderMarket } from './types';

const providers = vi.hoisted(() => ({
  first: { getMarketsForToken: vi.fn() },
  second: { getMarketsForToken: vi.fn() },
}));

vi.mock('./index', () => ({ marketProviders: [providers.first, providers.second] }));

import { fetchAggregatedMarket } from './aggregator';

function market(source: string): ProviderMarket {
  return {
    chainId: 'bsc',
    tokenAddress: '0x0000000000000000000000000000000000000001',
    pairAddress: '0x0000000000000000000000000000000000000002',
    baseToken: { address: '0x0000000000000000000000000000000000000001', name: 'Paxi', symbol: 'PAXI' },
    quoteToken: { address: '0x0000000000000000000000000000000000000003', name: 'USD Coin', symbol: 'USDC' },
    priceUsd: 1,
    volume24hUsd: 100,
    liquidityUsd: 10_000,
    priceChange24h: 0,
    fdvUsd: null,
    marketCapUsd: null,
    timestamp: Date.now(),
    source,
    sourceUpdatedAt: Date.now(),
    fetchedAt: Date.now(),
  };
}

describe('provider fetch resilience', () => {
  it('continues with the successful provider when one provider fails', async () => {
    providers.first.getMarketsForToken.mockRejectedValueOnce(new Error('provider unavailable'));
    providers.second.getMarketsForToken.mockResolvedValueOnce([market('geckoterminal')]);

    const result = await fetchAggregatedMarket('bsc', '0x0000000000000000000000000000000000000001');

    expect(result?.priceUsd).toBe(1);
    expect(result?.sources).toEqual(['geckoterminal']);
  });

  it('returns null when every provider fails', async () => {
    providers.first.getMarketsForToken.mockRejectedValueOnce(new Error('first unavailable'));
    providers.second.getMarketsForToken.mockRejectedValueOnce(new Error('second unavailable'));

    await expect(fetchAggregatedMarket('bsc', '0x0000000000000000000000000000000000000001')).resolves.toBeNull();
  });
});
