import { fetchJson } from "./http";

const GATEIO_BASE_URL = "https://api.gateio.ws/api/v4";

interface GateioTicker {
  currency_pair: string;
  last: string;
}

/** Public spot ticker, no API key needed. `pair` is Gate.io format e.g. "BTC_USDT". */
export async function getGateioSpotTicker(pair: string): Promise<{ priceUsd: number; timestampMs: number } | null> {
  try {
    const url = `${GATEIO_BASE_URL}/spot/tickers?currency_pair=${encodeURIComponent(pair)}`;
    const data = await fetchJson<GateioTicker[]>(url, "gateio");
    const entry = data?.[0];
    const price = entry ? Number(entry.last) : NaN;
    if (!entry || !Number.isFinite(price)) return null;
    return { priceUsd: price, timestampMs: Date.now() };
  } catch (err) {
    console.warn(`Gate.io ticker lookup failed for ${pair}:`, err);
    return null;
  }
}
