import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, timestampMs, token, type MarketProvider, type ProviderMarket, type ProviderOhlcv } from "./types";

interface GeckoPoolResource {
  id?: string;
  attributes?: {
    address?: string;
    name?: string;
    base_token_price_usd?: string | null;
    quote_token_price_usd?: string | null;
    reserve_in_usd?: string | null;
    volume_usd?: Record<string, string | null> | null;
    price_change_percentage?: Record<string, string | null> | null;
    fdv_usd?: string | null;
    market_cap_usd?: string | null;
    updated_at?: string | null;
    ohlcv_list?: unknown[][];
  };
  relationships?: {
    base_token?: { data?: { id?: string } };
    quote_token?: { data?: { id?: string } };
  };
}

interface GeckoResponse {
  data?: GeckoPoolResource[] | GeckoPoolResource;
}

const NETWORKS: Record<string, string> = {
  ethereum: "eth",
  eth: "eth",
  bsc: "bsc",
  binance: "bsc",
  polygon: "polygon_pos",
  polygon_pos: "polygon_pos",
  arbitrum: "arbitrum",
  base: "base",
  solana: "solana",
  avalanche: "avax",
};

function addressFromResourceId(id: string | undefined): string {
  return id?.includes("_") ? id.slice(id.indexOf("_") + 1) : id ?? "";
}

function timeframeParts(timeframe: string): { timeframe: string; aggregate: number } | null {
  switch (timeframe) {
    case "1m": return { timeframe: "minute", aggregate: 1 };
    case "5m": return { timeframe: "minute", aggregate: 5 };
    case "15m": return { timeframe: "minute", aggregate: 15 };
    case "30m": return { timeframe: "minute", aggregate: 30 };
    case "1h": return { timeframe: "hour", aggregate: 1 };
    case "4h": return { timeframe: "hour", aggregate: 4 };
    case "1d": return { timeframe: "day", aggregate: 1 };
    default: return null;
  }
}

export class GeckoTerminalAdapter implements MarketProvider {
  readonly name = "geckoterminal";
  private readonly baseUrl = "https://api.geckoterminal.com/api/v2";

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const network = normalizeChainSlug(chainId, NETWORKS);
    if (!network || !tokenAddress.trim()) return [];
    const data = await fetchJson<GeckoResponse>(
      `${this.baseUrl}/networks/${encodeURIComponent(network)}/tokens/${encodeURIComponent(tokenAddress.trim())}/pools`,
      this.name,
      { Accept: "application/json;version=20230203" },
    );
    const rows = Array.isArray(data.data) ? data.data : data.data ? [data.data] : [];
    const fetchedAt = Date.now();
    return rows.map((row) => {
      const attributes = row.attributes ?? {};
      const baseAddress = addressFromResourceId(row.relationships?.base_token?.data?.id) || tokenAddress;
      const quoteAddress = addressFromResourceId(row.relationships?.quote_token?.data?.id);
      const sourceUpdatedAt = attributes.updated_at ? timestampMs(attributes.updated_at, fetchedAt) : null;
      return {
        chainId,
        tokenAddress,
        pairAddress: attributes.address ?? addressFromResourceId(row.id) ?? null,
        baseToken: token({ address: baseAddress, name: attributes.name?.split("_")[0] ?? null, symbol: null }),
        quoteToken: token({ address: quoteAddress, name: null, symbol: null }),
        priceUsd: numberOrNull(attributes.base_token_price_usd),
        volume24hUsd: numberOrNull(attributes.volume_usd?.h24),
        liquidityUsd: numberOrNull(attributes.reserve_in_usd),
        priceChange24h: numberOrNull(attributes.price_change_percentage?.h24),
        fdvUsd: numberOrNull(attributes.fdv_usd),
        marketCapUsd: numberOrNull(attributes.market_cap_usd),
        timestamp: sourceUpdatedAt ?? fetchedAt,
        source: this.name,
        sourceUpdatedAt,
        fetchedAt,
      };
    });
  }

  async getOhlcv(chainId: string, pairAddress: string, timeframe: string, limit: number): Promise<ProviderOhlcv[]> {
    const network = normalizeChainSlug(chainId, NETWORKS);
    const parts = timeframeParts(timeframe);
    if (!network || !parts || !pairAddress.trim()) return [];
    const params = new URLSearchParams({ aggregate: String(parts.aggregate), limit: String(Math.min(Math.max(limit, 1), 1000)) });
    const response = await fetchJson<GeckoResponse>(
      `${this.baseUrl}/networks/${encodeURIComponent(network)}/pools/${encodeURIComponent(pairAddress.trim())}/ohlcv/${parts.timeframe}?${params}`,
      `${this.name}-ohlcv`,
      { Accept: "application/json;version=20230203" },
    );
    const resource = Array.isArray(response.data) ? response.data[0] : response.data;
    return (resource?.attributes?.ohlcv_list ?? []).flatMap((row) => {
      if (row.length < 5) return [];
      const [timestamp, open, high, low, close, volume] = row;
      const numbers = [open, high, low, close].map(Number);
      if (numbers.some((value) => !Number.isFinite(value))) return [];
      return [{ timestamp: timestampMs(timestamp), open: numbers[0], high: numbers[1], low: numbers[2], close: numbers[3], volume: numberOrNull(volume), source: this.name }];
    });
  }
}
