import { describe, expect, it, beforeEach } from "vitest";
import {
  getProviderHealth,
  recordProviderFailure,
  recordProviderSuccess,
  resetProviderHealthForTests,
} from "./health";

describe("provider health registry", () => {
  beforeEach(() => {
    resetProviderHealthForTests();
  });

  it("records successful latency and healthy state", () => {
    recordProviderSuccess("test-provider", 42.6);
    expect(getProviderHealth()).toEqual([
      expect.objectContaining({
        name: "test-provider",
        state: "healthy",
        successes: 1,
        failures: 0,
        lastLatencyMs: 43,
        lastError: null,
      }),
    ]);
  });

  it("records failures and preserves a bounded error message", () => {
    recordProviderFailure("test-provider", new Error("provider unavailable"));
    expect(getProviderHealth()).toEqual([
      expect.objectContaining({
        name: "test-provider",
        state: "unavailable",
        successes: 0,
        failures: 1,
        lastError: "provider unavailable",
      }),
    ]);
  });

  it("degrades after a failure following a successful observation", () => {
    recordProviderSuccess("test-provider", 12);
    recordProviderFailure("test-provider", "rate limited", true);
    expect(getProviderHealth()[0]).toEqual(
      expect.objectContaining({
        state: "degraded",
        successes: 1,
        failures: 1,
        rateLimited: 1,
        lastError: "rate limited",
      })
    );
  });
});
