export type ProviderHealthState =
  "unknown" | "healthy" | "degraded" | "unavailable";

export interface ProviderHealth {
  name: string;
  state: ProviderHealthState;
  successes: number;
  failures: number;
  rateLimited: number;
  lastLatencyMs: number | null;
  lastSuccessAt: number | null;
  lastFailureAt: number | null;
  lastError: string | null;
}

const health = new Map<string, ProviderHealth>();

function getOrCreate(name: string): ProviderHealth {
  const existing = health.get(name);
  if (existing) return existing;
  const created: ProviderHealth = {
    name,
    state: "unknown",
    successes: 0,
    failures: 0,
    rateLimited: 0,
    lastLatencyMs: null,
    lastSuccessAt: null,
    lastFailureAt: null,
    lastError: null,
  };
  health.set(name, created);
  return created;
}

export function recordProviderSuccess(name: string, latencyMs: number): void {
  const entry = getOrCreate(name);
  entry.successes += 1;
  entry.lastLatencyMs = Math.max(0, Math.round(latencyMs));
  entry.lastSuccessAt = Date.now();
  entry.lastError = null;
  entry.state = "healthy";
}

export function recordProviderFailure(
  name: string,
  error: unknown,
  rateLimited = false
): void {
  const entry = getOrCreate(name);
  entry.failures += 1;
  if (rateLimited) entry.rateLimited += 1;
  entry.lastFailureAt = Date.now();
  entry.lastError =
    error instanceof Error
      ? error.message.slice(0, 240)
      : String(error).slice(0, 240);
  entry.state =
    entry.successes > 0 && entry.failures <= entry.successes
      ? "degraded"
      : "unavailable";
}

export function getProviderHealth(): ProviderHealth[] {
  return [...health.values()].map(entry => ({ ...entry }));
}

export function resetProviderHealthForTests(): void {
  health.clear();
}
