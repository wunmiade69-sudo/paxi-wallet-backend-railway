import type { MarketProvider } from "./types";
import { DexPaprikaAdapter } from "./dexPaprika";
import { DexScreenerAdapter } from "./dexScreener";
import { GeckoTerminalAdapter } from "./geckoTerminal";
import { CoinGeckoAdapter } from "./coinGecko";

export * from "./contracts";
export * from "./definitions";
export * from "./orchestrator";

export const marketProviders: MarketProvider[] = [
  new DexPaprikaAdapter(),
  new DexScreenerAdapter(),
  new GeckoTerminalAdapter(),
  new CoinGeckoAdapter(),
];

export function getMarketProvider(name: string): MarketProvider | undefined {
  return marketProviders.find((provider) => provider.name === name);
}
