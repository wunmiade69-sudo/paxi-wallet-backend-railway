import type { MarketProvider } from "./types";
import { DexPaprikaAdapter } from "./dexPaprika";
import { DexScreenerAdapter } from "./dexScreener";
import { GeckoTerminalAdapter } from "./geckoTerminal";
import { CoinGeckoAdapter } from "./coinGecko";
import { BirdeyeAdapter } from "./birdeye";
import { DexScannerAdapter } from "./dexScanner";

export const marketProviders: MarketProvider[] = [
  new DexPaprikaAdapter(),
  new DexScreenerAdapter(),
  new GeckoTerminalAdapter(),
  new CoinGeckoAdapter(),
  new BirdeyeAdapter(),
  new DexScannerAdapter(),
];

export function getMarketProvider(name: string): MarketProvider | undefined {
  return marketProviders.find((provider) => provider.name === name);
}
