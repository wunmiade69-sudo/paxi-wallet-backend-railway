import { fetchJson } from "./http";

const KUCOIN_BASE_URL = "https://api.kucoin.com/api/v1";

interface KucoinTickerResponse {
  code: string;
  data?: { price: string; time: number };
}

/** Public level-1 orderbook (best bid/ask + last price), no API key needed. `symbol` is KuCoin format e.g. "BTC-USDT". */
export async function getKucoinSpotTicker(symbol: string): Promise<{ priceUsd: number; timestampMs: number } | null> {
  try {
    const url = `${KUCOIN_BASE_URL}/market/orderbook/level1?symbol=${encodeURIComponent(symbol)}`;
    const data = await fetchJson<KucoinTickerResponse>(url, "kucoin");
    const price = data.data ? Number(data.data.price) : NaN;
    if (data.code !== "200000" || !data.data || !Number.isFinite(price)) return null;
    return { priceUsd: price, timestampMs: data.data.time || Date.now() };
  } catch (err) {
    console.warn(`KuCoin ticker lookup failed for ${symbol}:`, err);
    return null;
  }
}
