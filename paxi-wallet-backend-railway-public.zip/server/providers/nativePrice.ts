import { fetchJson } from "./http";

export interface NativePriceQuote {
  priceUsd: number;
  change24h: number | null;
  source: "binance" | "coingecko";
  sourceTimestamp: number | null;
}

const BINANCE_API = "https://data-api.binance.vision/api/v3";
const COINGECKO_API = "https://api.coingecko.com/api/v3";

const NATIVE_PRICE_SYMBOL: Record<string, { binance: string; coingecko: string }> = {
  bsc: { binance: "BNBUSDT", coingecko: "binancecoin" },
  ethereum: { binance: "ETHUSDT", coingecko: "ethereum" },
  bitcoin: { binance: "BTCUSDT", coingecko: "bitcoin" },
  solana: { binance: "SOLUSDT", coingecko: "solana" },
  polygon: { binance: "POLUSDT", coingecko: "polygon-ecosystem-token" },
  arbitrum: { binance: "ETHUSDT", coingecko: "ethereum" },
};

function finiteNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const number = typeof value === "number" ? value : Number(value);
  return Number.isFinite(number) ? number : null;
}

export function nativePriceSymbols(chain: string): { binance: string; coingecko: string } | null {
  return NATIVE_PRICE_SYMBOL[chain.trim().toLowerCase()] ?? null;
}

export async function getBinanceNativePrice(chain: string): Promise<NativePriceQuote | null> {
  const symbols = nativePriceSymbols(chain);
  if (!symbols) return null;
  const data = await fetchJson<{ lastPrice?: unknown; priceChangePercent?: unknown }>(
    `${BINANCE_API}/ticker/24hr?symbol=${symbols.binance}`,
    "binance-price",
  );
  const priceUsd = finiteNumber(data.lastPrice);
  if (priceUsd === null) return null;
  const change = finiteNumber(data.priceChangePercent);
  return { priceUsd, change24h: change, source: "binance", sourceTimestamp: Date.now() };
}

export interface NativeOhlcvPoint {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number | null;
}

const NATIVE_CANDLE_INTERVALS: Record<string, string> = {
  "1H": "1m",
  "1D": "1h",
  "1W": "4h",
  "1M": "1d",
  "3M": "1d",
  "1Y": "1d",
  ALL: "1d",
};

export async function getBinanceNativeOhlcv(chain: string, timeframe: string, limit = 1000): Promise<NativeOhlcvPoint[] | null> {
  const symbols = nativePriceSymbols(chain);
  if (!symbols) return null;
  const interval = NATIVE_CANDLE_INTERVALS[timeframe] ?? "1d";
  const boundedLimit = Math.min(Math.max(Math.trunc(limit), 1), 1000);
  const rows = await fetchJson<unknown>(
    `${BINANCE_API}/klines?symbol=${symbols.binance}&interval=${interval}&limit=${boundedLimit}`,
    "binance-chart",
  );
  if (!Array.isArray(rows)) return null;
  const points = rows.map((row): NativeOhlcvPoint | null => {
    if (!Array.isArray(row) || row.length < 6) return null;
    const timestamp = finiteNumber(row[0]);
    const open = finiteNumber(row[1]);
    const high = finiteNumber(row[2]);
    const low = finiteNumber(row[3]);
    const close = finiteNumber(row[4]);
    const volume = finiteNumber(row[5]);
    if (timestamp === null || open === null || high === null || low === null || close === null) return null;
    return { timestamp: timestamp < 10_000_000_000 ? Math.round(timestamp * 1000) : Math.round(timestamp), open, high, low, close, volume };
  }).filter((point): point is NativeOhlcvPoint => point !== null);
  return points.length > 0 ? points : null;
}

export async function getCoinGeckoNativePrice(chain: string): Promise<NativePriceQuote | null> {
  const symbols = nativePriceSymbols(chain);
  if (!symbols) return null;
  const apiKey = process.env.COINGECKO_API_KEY?.trim();
  const headers: Record<string, string> = apiKey ? { "x-cg-demo-api-key": apiKey } : {};
  const data = await fetchJson<Record<string, { usd?: unknown; usd_24h_change?: unknown }>>(
    `${COINGECKO_API}/simple/price?ids=${encodeURIComponent(symbols.coingecko)}&vs_currencies=usd&include_24hr_change=true`,
    "coingecko-price",
    headers,
  );
  const row = data[symbols.coingecko];
  const priceUsd = finiteNumber(row?.usd);
  if (priceUsd === null) return null;
  return {
    priceUsd,
    change24h: finiteNumber(row?.usd_24h_change),
    source: "coingecko",
    sourceTimestamp: Date.now(),
  };
}
