import { createHmac } from "node:crypto";
import { fetchJson } from "./http";
import { ENV } from "../_core/env";

/**
 * OKX API client.
 *
 * IMPORTANT - unlike BscScan/Jupiter, OKX's authenticated endpoints (their
 * Web3/DEX aggregator: swap quotes, DEX token price-by-contract, etc.) need
 * FOUR credentials, not one: API Key, Secret Key, Passphrase, and Project ID,
 * all from the OKX Developer Portal (web3.okx.com) - not the regular OKX
 * exchange account settings. Every signed request must include a valid
 * OK-ACCESS-PROJECT header or OKX rejects it.
 *
 * Public endpoints (like the spot ticker below) need none of this - anyone
 * can call them with no key at all. getOkxSpotTicker() proves the pipeline
 * works end-to-end right now, with zero credentials required.
 *
 * buildOkxSignedHeaders() is ready for whichever authenticated DEX endpoint
 * you actually need (their exact request paths/params are versioned and
 * change - confirm the current path at https://web3.okx.com/build/dev-docs
 * before wiring a specific one, rather than guessing at an endpoint shape
 * here). Once you know which one (e.g. DEX market price by contract, or a
 * swap quote), give me the exact endpoint and I'll wire the caller.
 */

const OKX_BASE_URL = "https://www.okx.com";

export function hasOkxSignedCredentials(): boolean {
  return Boolean(ENV.okxApiKey && ENV.okxApiSecret && ENV.okxApiPassphrase && ENV.okxProjectId);
}

/** Builds the signed headers OKX requires on every authenticated request. */
export function buildOkxSignedHeaders(method: "GET" | "POST", requestPath: string, body = ""): Record<string, string> | null {
  if (!hasOkxSignedCredentials()) return null;
  const timestamp = new Date().toISOString();
  const prehash = `${timestamp}${method}${requestPath}${body}`;
  const signature = createHmac("sha256", ENV.okxApiSecret).update(prehash).digest("base64");
  return {
    "Content-Type": "application/json",
    "OK-ACCESS-KEY": ENV.okxApiKey,
    "OK-ACCESS-SIGN": signature,
    "OK-ACCESS-TIMESTAMP": timestamp,
    "OK-ACCESS-PASSPHRASE": ENV.okxApiPassphrase,
    "OK-ACCESS-PROJECT": ENV.okxProjectId,
  };
}

interface OkxTickerResult {
  instId: string;
  last: string;
  ts: string;
}

interface OkxApiResponse<T> {
  code: string;
  msg: string;
  data: T[];
}

/**
 * Public spot ticker - no API key needed. `instId` is an OKX spot pair like
 * "BTC-USDT" or "BNB-USDT", not a contract address. Working today with zero
 * configuration; useful as a fallback native-asset price source.
 */
export async function getOkxSpotTicker(instId: string): Promise<{ priceUsd: number; timestampMs: number } | null> {
  try {
    const url = `${OKX_BASE_URL}/api/v5/market/ticker?instId=${encodeURIComponent(instId)}`;
    const data = await fetchJson<OkxApiResponse<OkxTickerResult>>(url, "okx");
    const entry = data.data?.[0];
    const price = entry ? Number(entry.last) : NaN;
    if (!entry || !Number.isFinite(price)) return null;
    return { priceUsd: price, timestampMs: Number(entry.ts) || Date.now() };
  } catch (err) {
    console.warn(`OKX ticker lookup failed for ${instId}:`, err);
    return null;
  }
}
