import { ethers } from "ethers";
import { withEvmRpc, type RpcNetwork } from "../chains/rpc";
import type { NormalizedProviderToken, CanonicalMarketIdentity } from "../marketProviders";

/**
 * Last-resort TOKEN_METADATA source: reads name/symbol/decimals straight off
 * the ERC-20 contract via RPC. Unlike every other provider in this module,
 * this one needs no API key and cannot be "not indexed yet" - if the
 * contract exists and implements the standard read functions, this works,
 * even for a token that was deployed a minute ago and appears on no
 * aggregator. It is registered with the lowest TOKEN_METADATA priority (see
 * providers/definitions.ts) so it only fills gaps left by richer sources via
 * mergeProviderToken - it never overrides a logo/price/market-cap that only
 * an indexer can supply, and it never claims price data itself.
 */

const ONCHAIN_EVM_CHAINS: readonly RpcNetwork[] = ["ethereum", "bsc", "polygon", "arbitrum"];

function isOnchainEvmChain(chain: string | null | undefined): chain is Exclude<RpcNetwork, "solana" | "bitcoin"> {
  return Boolean(chain) && (ONCHAIN_EVM_CHAINS as readonly string[]).includes(chain as string);
}

const ERC20_METADATA_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
];

export async function getOnchainErc20Metadata(identity: CanonicalMarketIdentity): Promise<NormalizedProviderToken | null> {
  const chain = identity.chain;
  const address = identity.contractAddress;
  if (!isOnchainEvmChain(chain) || !address || !/^0x[0-9a-fA-F]{40}$/.test(address)) return null;

  try {
    const [name, symbol, decimals] = await withEvmRpc(chain, async (provider) => {
      const token = new ethers.Contract(address, ERC20_METADATA_ABI, provider);
      const [nameResult, symbolResult, decimalsResult] = await Promise.allSettled([
        token.name() as Promise<string>,
        token.symbol() as Promise<string>,
        token.decimals() as Promise<bigint | number>,
      ]);
      return [
        nameResult.status === "fulfilled" ? nameResult.value : null,
        symbolResult.status === "fulfilled" ? symbolResult.value : null,
        decimalsResult.status === "fulfilled" ? Number(decimalsResult.value) : null,
      ] as const;
    });

    if (!name && !symbol && decimals === null) return null;
    const resolvedSymbol = (symbol ?? "").trim();
    const resolvedName = (name ?? "").trim() || resolvedSymbol || "Unknown token";

    const token: NormalizedProviderToken = {
      id: `onchain:${chain}:${address.toLowerCase()}`,
      symbol: resolvedSymbol.toUpperCase(),
      name: resolvedName,
      chain,
      contractAddress: address.toLowerCase(),
      decimals: Number.isInteger(decimals) && decimals !== null && decimals >= 0 && decimals <= 36 ? decimals : null,
      image: "",
      currentPrice: null,
      marketCap: null,
      marketCapRank: null,
      liquidity: null,
      volume24h: null,
      priceChangePercent24h: null,
      verificationStatus: "unverified",
      securityStatus: "unavailable",
      source: "onchain",
      sources: ["onchain"],
      fieldSources: {
        identity: ["onchain"],
        name: resolvedName ? ["onchain"] : undefined,
        symbol: resolvedSymbol ? ["onchain"] : undefined,
        decimals: decimals !== null ? ["onchain"] : undefined,
      },
      providerId: null,
      marketDataAvailable: false,
    };
    return token;
  } catch (error) {
    console.warn(`[marketData] On-chain ERC20 metadata unavailable for ${chain}:${address}:`, error instanceof Error ? error.message : "rpc error");
    return null;
  }
}
