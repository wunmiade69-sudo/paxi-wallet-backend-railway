import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.BIRDEYE_API_KEY = "phase2-test-key";
});

const providerToken = (source: "birdeye" | "dexpaprika", image: string, price: number | null) => ({
  id: `${source}:solana:mint`,
  symbol: "USDC",
  name: "USD Coin",
  chain: "solana" as const,
  contractAddress: "MintAddress",
  decimals: 6,
  image,
  currentPrice: price,
  marketCap: null,
  marketCapRank: null,
  liquidity: null,
  volume24h: null,
  priceChangePercent24h: null,
  verificationStatus: "unverified" as const,
  securityStatus: "unavailable" as const,
  source,
  sources: [source],
  fieldSources: { identity: [source], image: image ? [source] : undefined, price: price === null ? undefined : [source] },
  providerId: "MintAddress",
  marketDataAvailable: price !== null,
});

vi.mock("./nativePrice", () => ({
  getBinanceNativePrice: vi.fn(async () => ({ priceUsd: 612.5, change24h: 2.5, source: "binance", sourceTimestamp: 123 })),
  getBinanceNativeOhlcv: vi.fn(async () => [
    { timestamp: 1_700_000_000_000, open: 600, high: 620, low: 590, close: 612.5, volume: 1000 },
  ]),
  getCoinGeckoNativePrice: vi.fn(async () => ({ priceUsd: 600, change24h: null, source: "coingecko", sourceTimestamp: 456 })),
}));

vi.mock("../contractSecurity", () => ({
  getContractSecurity: vi.fn(async () => ({
    status: "safe",
    riskLevel: "LOW",
    score: 92,
    checks: {
      verifiedContract: true,
      liquidityLocked: true,
      noHoneypot: true,
      ownershipRenounced: true,
      lowRugRisk: true,
    },
    buyTaxPercent: 0,
    sellTaxPercent: 0,
    holderCount: 250,
  })),
}));

vi.mock("../securityProviders", () => ({
  getHoneypotSecurity: vi.fn(async () => ({ provider: "honeypot", available: false, isHoneypot: null, buyTaxPercent: null, sellTaxPercent: null, holderCount: null })),
  getChainabuseSecurity: vi.fn(async () => ({ provider: "chainabuse", available: false, reportCount: null, hasReports: null })),
}));

vi.mock("../marketProviders", async () => {
  const actual = await vi.importActual<typeof import("../marketProviders")>("../marketProviders");
  return {
    ...actual,
    searchBirdeyeTokens: vi.fn(async () => [providerToken("birdeye", "https://birdeye.example/logo.png", null)]),
    searchDexPaprikaTokens: vi.fn(async () => [providerToken("dexpaprika", "", 1)]),
    getBirdeyeToken: vi.fn(async () => providerToken("birdeye", "https://birdeye.example/logo.png", null)),
    getDexPaprikaToken: vi.fn(async () => providerToken("dexpaprika", "", 1)),
  };
});

import { getProviderHealthSnapshot, orchestratedChart, orchestratedNativePrice, orchestratedSearchTokens, orchestratedSecurity, orchestratedTokenMetadata, resetProviderRuntimeForTests } from "./orchestrator";
import { searchBirdeyeTokens, searchDexPaprikaTokens } from "../marketProviders";

describe("provider orchestrator", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    resetProviderRuntimeForTests();
  });

  it("combines capability providers by canonical identity and preserves available fields", async () => {
    const result = await orchestratedSearchTokens("usdc", "solana");
    expect(result.value).toHaveLength(1);
    expect(result.value?.[0]).toMatchObject({ chain: "solana", contractAddress: "MintAddress", image: "https://birdeye.example/logo.png", currentPrice: 1 });
    expect(result.value?.[0].sources).toEqual(expect.arrayContaining(["birdeye", "dexpaprika"]));
    expect(result.attempts.every((attempt) => attempt.error === null)).toBe(true);
    expect(searchBirdeyeTokens).toHaveBeenCalledWith("usdc", "solana");
    expect(searchDexPaprikaTokens).toHaveBeenCalledWith("usdc", "solana");
  });

  it("orchestrates native price with chain:native identity and field provenance", async () => {
    const result = await orchestratedNativePrice("ethereum");
    expect(result.value).toMatchObject({ identity: { chain: "ethereum", kind: "native", contractOrMint: "native", key: "ethereum:native" }, source: "binance", stale: false });
    expect(result.value?.price).toMatchObject({ value: 612.5, provenance: { source: "binance", sourceTimestamp: 123 } });
    expect(result.value?.priceChange24h.value).toBe(2.5);
    expect(result.attempts).toEqual(expect.arrayContaining([expect.objectContaining({ provider: "binance", capability: "PRICE", success: true })]));
  });

  it("uses primary metadata identity while filling missing data from fallback providers", async () => {
    const result = await orchestratedTokenMetadata({ chain: "solana", contractAddress: "MintAddress" });
    expect(result.value).toMatchObject({ source: "birdeye", image: "https://birdeye.example/logo.png", currentPrice: 1 });
    expect(result.value?.sources).toEqual(expect.arrayContaining(["birdeye", "dexpaprika"]));
  });

  it("orchestrates native OHLCV through Binance with bounded normalized points", async () => {
    const result = await orchestratedChart({ chain: "ethereum", contractAddress: "native" }, "1D", 2);
    expect(result.value).toMatchObject({ source: "binance", historicalAvailable: true, providerId: "binance" });
    expect(result.value?.identity).toMatchObject({ chain: "ethereum", kind: "native", contractOrMint: "native", key: "ethereum:native" });
    expect(result.value?.points).toEqual([{ timestamp: 1_700_000_000_000, open: 600, high: 620, low: 590, close: 612.5, volume: 1000 }]);
    expect(result.attempts).toEqual(expect.arrayContaining([expect.objectContaining({ provider: "binance", capability: "OHLCV", success: true })]));
  });

  it("orchestrates GoPlus security without collapsing unknown data into safe state", async () => {
    const result = await orchestratedSecurity({ chain: "ethereum", contractAddress: "0x1111111111111111111111111111111111111111" });
    expect(result.value).toMatchObject({ provider: "goplus", riskLevel: "low", stale: false });
    expect(result.value?.identity).toMatchObject({ key: "ethereum:0x1111111111111111111111111111111111111111", kind: "token" });
    expect(result.value?.signals).toEqual(expect.arrayContaining(["verifiedContract", "noHoneypot"]));
    expect(result.attempts).toEqual(expect.arrayContaining([expect.objectContaining({ provider: "goplus", capability: "SECURITY", success: true })]));
  });

  it("reports sanitized provider health without secret material", async () => {
    await orchestratedSearchTokens("USDC", "solana");
    const health = getProviderHealthSnapshot();
    expect(health.find((provider) => provider.provider === "birdeye")).toMatchObject({ provider: "birdeye", configured: true, enabled: true, state: "healthy" });
    expect(JSON.stringify(health)).not.toContain("phase2-test-key");
  });
});
