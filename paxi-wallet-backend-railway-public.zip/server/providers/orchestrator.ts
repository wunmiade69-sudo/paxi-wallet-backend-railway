import { getTokenMarketSnapshot, resolveTokenPriceUsd, type DexScreenerPairRaw } from "../dexLiquidity";
import {
  dedupeProviderTokens,
  mergeProviderToken,
  getBirdeyeChart,
  getBirdeyeToken,
  getCoinGeckoToken,
  getDexPaprikaChart,
  getDexPaprikaToken,
  searchBirdeyeTokens,
  searchDexPaprikaTokens,
  type CanonicalMarketIdentity,
  type MarketChartTimeframe,
  type NormalizedProviderToken,
  type ProviderChartResult,
} from "../marketProviders";
import { getOnchainErc20Metadata } from "./onchainMetadata";
import { normalizeChain, resolveAssetIdentity } from "../identity/assetIdentity";
import type { MarketSnapshot, NormalizedValue, SecuritySnapshot } from "./contracts";
import { getBinanceNativeOhlcv, getBinanceNativePrice, getCoinGeckoNativePrice } from "./nativePrice";
import { getContractSecurity, type ContractSecurityReport } from "../contractSecurity";
import { getProviderDefinition, listProviderDefinitions, providersForCapability } from "./definitions";
import type { ProviderCapability, ProviderHealthState } from "./contracts";
import { createCacheEnvelope, markCacheEnvelopeStale, searchCacheKey, type CacheEnvelope } from "../cache/keys";
import { getCachedMarketJson, setCachedMarketJson } from "../redis";

export interface ProviderAttempt {
  provider: string;
  capability: ProviderCapability;
  success: boolean;
  latencyMs: number;
  error: string | null;
}

export interface OrchestratedResult<T> {
  value: T | null;
  attempts: ProviderAttempt[];
  source: string | null;
}

interface RuntimeHealth {
  state: ProviderHealthState;
  successes: number;
  failures: number;
  lastSuccessAt: number | null;
  lastFailureAt: number | null;
  lastError: string | null;
}

const runtimeHealth = new Map<string, RuntimeHealth>();

function healthFor(provider: string): RuntimeHealth {
  const existing = runtimeHealth.get(provider);
  if (existing) return existing;
  const created: RuntimeHealth = { state: "unknown", successes: 0, failures: 0, lastSuccessAt: null, lastFailureAt: null, lastError: null };
  runtimeHealth.set(provider, created);
  return created;
}

function record(provider: string, success: boolean, error?: unknown): void {
  const health = healthFor(provider);
  if (success) {
    health.successes += 1;
    health.failures = 0;
    health.lastSuccessAt = Date.now();
    health.lastError = null;
    health.state = "healthy";
    return;
  }
  health.failures += 1;
  health.lastFailureAt = Date.now();
  health.lastError = error instanceof Error ? error.message.slice(0, 160) : "provider request failed";
  const definition = getProviderDefinition(provider);
  health.state = health.failures >= (definition?.healthPolicy.failureThreshold ?? 5) ? "open" : "degraded";
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message.slice(0, 160) : "provider request failed";
}

const requestWindows = new Map<string, number[]>();

function providerMayBeCalled(provider: string): { allowed: boolean; reason?: string } {
  const definition = getProviderDefinition(provider);
  const health = healthFor(provider);
  const now = Date.now();
  if (health.state === "open") {
    const resetTimeoutMs = definition?.healthPolicy.resetTimeoutMs ?? 30_000;
    if (health.lastFailureAt !== null && now - health.lastFailureAt < resetTimeoutMs) return { allowed: false, reason: "provider circuit open" };
    health.state = "degraded";
  }
  const requests = requestWindows.get(provider) ?? [];
  const windowMs = definition?.rateLimit?.windowMs ?? 60_000;
  const retained = requests.filter((timestamp) => now - timestamp < windowMs);
  const limit = definition?.rateLimit?.requests ?? 60;
  if (retained.length >= limit) {
    requestWindows.set(provider, retained);
    return { allowed: false, reason: "provider rate limit reached" };
  }
  retained.push(now);
  requestWindows.set(provider, retained);
  return { allowed: true };
}

function skippedAttempt(provider: string, capability: ProviderCapability, reason: string): ProviderAttempt {
  return { provider, capability, success: false, latencyMs: 0, error: reason };
}

async function withBoundedRetry<T>(operation: () => Promise<T>, retries = 1): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      if (attempt >= retries) break;
      await new Promise((resolve) => setTimeout(resolve, 25 * (attempt + 1)));
    }
  }
  throw lastError instanceof Error ? lastError : new Error("provider request failed");
}

function supportedProviderIds(capability: ProviderCapability, chain: string | null): string[] {
  return providersForCapability(capability, chain).map((provider) => provider.id);
}

function selectedChain(identity: CanonicalMarketIdentity): string | null {
  return normalizeChain(identity.chain);
}

export async function orchestratedSearchTokens(query: string, chain: string | null = null): Promise<OrchestratedResult<NormalizedProviderToken[]>> {
  const normalizedQuery = query.trim();
  if (!normalizedQuery) return { value: [], attempts: [], source: null };
  const providerIds = supportedProviderIds("SEARCH", chain);
  const attempts: ProviderAttempt[] = [];
  const results: NormalizedProviderToken[] = [];
  const cacheKey = searchCacheKey(normalizedQuery, chain);
  const cached = await getCachedMarketJson<CacheEnvelope<NormalizedProviderToken[]>>("search", cacheKey);
  const staleCache = cached?.data && Array.isArray(cached.data) ? markCacheEnvelopeStale(cached) : null;
  if (staleCache && !staleCache.stale) return { value: staleCache.data, attempts, source: staleCache.source };

  for (const provider of providerIds) {
    const gate = providerMayBeCalled(provider);
    if (!gate.allowed) {
      attempts.push(skippedAttempt(provider, "SEARCH", gate.reason ?? "provider unavailable"));
      continue;
    }
    const started = Date.now();
    try {
      let tokens: NormalizedProviderToken[] = [];
      if (provider === "birdeye") tokens = await withBoundedRetry(() => searchBirdeyeTokens(normalizedQuery));
      else if (provider === "dexpaprika") tokens = await withBoundedRetry(() => searchDexPaprikaTokens(normalizedQuery));
      else continue;
      const filtered = chain ? tokens.filter((token) => token.chain === chain) : tokens;
      results.push(...filtered);
      record(provider, true);
      attempts.push({ provider, capability: "SEARCH", success: true, latencyMs: Date.now() - started, error: null });
    } catch (error) {
      record(provider, false, error);
      attempts.push({ provider, capability: "SEARCH", success: false, latencyMs: Date.now() - started, error: errorMessage(error) });
      console.warn(`[provider-orchestrator] ${provider} search unavailable:`, errorMessage(error));
    }
  }

  const deduped = dedupeProviderTokens(results);
  if (deduped.length > 0) {
    const source = Array.from(new Set(deduped.flatMap((token) => token.sources))).join(",") || deduped[0]?.source || "provider";
    setCachedMarketJson("search", cacheKey, createCacheEnvelope(deduped, source, 60_000)).catch(() => undefined);
    return { value: deduped, attempts, source };
  }
  if (staleCache) return { value: staleCache.data, attempts, source: staleCache.source };
  return { value: deduped, attempts, source: null };
}

export async function orchestratedNativePrice(chain: string): Promise<OrchestratedResult<MarketSnapshot>> {
  const identity = resolveAssetIdentity({ chain, kind: "native" });
  const attempts: ProviderAttempt[] = [];
  if (!identity) return { value: null, attempts, source: null };
  const providerIds = supportedProviderIds("PRICE", identity.chain);
  for (const provider of providerIds) {
    if (provider !== "binance" && provider !== "coingecko") continue;
    const gate = providerMayBeCalled(provider);
    if (!gate.allowed) {
      attempts.push(skippedAttempt(provider, "PRICE", gate.reason ?? "provider unavailable"));
      continue;
    }
    const started = Date.now();
    try {
      const quote = provider === "binance"
        ? await withBoundedRetry(() => getBinanceNativePrice(identity.chain))
        : await withBoundedRetry(() => getCoinGeckoNativePrice(identity.chain));
      const success = Boolean(quote);
      record(provider, success, success ? undefined : "price unavailable");
      attempts.push({ provider, capability: "PRICE", success, latencyMs: Date.now() - started, error: success ? null : "price unavailable" });
      if (!quote) continue;
      const value = (data: number | null, sourceTimestamp: number | null): NormalizedValue<number> => ({
        value: data,
        provenance: data === null ? null : { source: provider, sourceTimestamp, fetchedAt: Date.now(), confidence: provider === "binance" ? "high" : "medium" },
      });
      const snapshot: MarketSnapshot = {
        identity,
        price: value(quote.priceUsd, quote.sourceTimestamp),
        currency: "USD",
        priceChange24h: value(quote.change24h, quote.sourceTimestamp),
        marketCap: { value: null, provenance: null },
        volume24h: { value: null, provenance: null },
        source: provider,
        timestamp: Date.now(),
        confidence: provider === "binance" ? "high" : "medium",
        stale: false,
      };
      return { value: snapshot, attempts, source: provider };
    } catch (error) {
      record(provider, false, error);
      attempts.push({ provider, capability: "PRICE", success: false, latencyMs: Date.now() - started, error: errorMessage(error) });
    }
  }
  return { value: null, attempts, source: null };
}

export async function orchestratedTokenMetadata(identity: CanonicalMarketIdentity): Promise<OrchestratedResult<NormalizedProviderToken>> {
  const chain = selectedChain(identity);
  const providerIds = supportedProviderIds("TOKEN_METADATA", chain);
  const attempts: ProviderAttempt[] = [];
  const results: NormalizedProviderToken[] = [];

  await Promise.all(providerIds.map(async (provider) => {
    const gate = providerMayBeCalled(provider);
    if (!gate.allowed) {
      attempts.push(skippedAttempt(provider, "TOKEN_METADATA", gate.reason ?? "provider unavailable"));
      return;
    }
    const started = Date.now();
    try {
      let token: NormalizedProviderToken | null = null;
      if (provider === "birdeye") token = await withBoundedRetry(() => getBirdeyeToken(identity));
      else if (provider === "dexpaprika") token = await withBoundedRetry(() => getDexPaprikaToken(identity));
      else if (provider === "coingecko") token = await withBoundedRetry(() => getCoinGeckoToken(identity));
      // RPC failover already retries internally (chains/rpc.ts) - no need to retry again here.
      else if (provider === "onchain") token = await getOnchainErc20Metadata(identity);
      else return;
      if (token) results.push(token);
      record(provider, true);
      attempts.push({ provider, capability: "TOKEN_METADATA", success: true, latencyMs: Date.now() - started, error: null });
    } catch (error) {
      record(provider, false, error);
      attempts.push({ provider, capability: "TOKEN_METADATA", success: false, latencyMs: Date.now() - started, error: errorMessage(error) });
    }
  }));

  const ordered = providerIds.map((id) => results.find((token) => token.source === id)).filter(Boolean) as NormalizedProviderToken[];
  const value = ordered.length ? ordered.slice(1).reduce((merged, token) => mergeProviderToken(merged, token), ordered[0]) : null;
  return { value, attempts, source: value?.source ?? null };
}

export interface OrchestratedLiquiditySnapshot {
  pair: DexScreenerPairRaw;
  tokenPriceUsd: number | null;
  source: "dexscreener";
}

export interface OrchestratedSecuritySnapshot extends SecuritySnapshot {
  report: ContractSecurityReport;
}

function securitySignals(report: ContractSecurityReport): { signals: string[]; warnings: string[] } {
  const signals = Object.entries(report.checks).filter(([, value]) => value === true).map(([key]) => key);
  const warnings = Object.entries(report.checks).filter(([, value]) => value === false).map(([key]) => key);
  if (report.status === "high-risk") warnings.push("provider-reported high risk");
  if (report.status === "unknown") warnings.push("security status unavailable or incomplete");
  return { signals, warnings };
}

export async function orchestratedSecurity(identity: CanonicalMarketIdentity): Promise<OrchestratedResult<OrchestratedSecuritySnapshot>> {
  const chain = selectedChain(identity);
  const providerIds = supportedProviderIds("SECURITY", chain);
  const attempts: ProviderAttempt[] = [];
  if (!identity.chain || !identity.contractAddress || identity.contractAddress === "native") return { value: null, attempts, source: null };

  for (const provider of providerIds) {
    const gate = providerMayBeCalled(provider);
    if (!gate.allowed) {
      attempts.push(skippedAttempt(provider, "SECURITY", gate.reason ?? "provider unavailable"));
      continue;
    }
    const started = Date.now();
    try {
      if (provider !== "goplus") continue;
      const report = await withBoundedRetry(() => getContractSecurity(identity.chain!, identity.contractAddress!));
      const { signals, warnings } = securitySignals(report);
      const resolvedIdentity = resolveAssetIdentity({ chain: identity.chain, contractAddress: identity.contractAddress, kind: "token" });
      const result = resolvedIdentity ? {
        identity: resolvedIdentity,
        provider: provider,
        riskLevel: report.riskLevel === "LOW" ? "low" : report.riskLevel === "MEDIUM" ? "medium" : report.riskLevel === "HIGH" ? "high" : "unknown",
        signals,
        warnings,
        timestamp: Date.now(),
        stale: false,
        report,
      } satisfies OrchestratedSecuritySnapshot : null;
      record(provider, Boolean(result), result ? undefined : "security identity unavailable");
      attempts.push({ provider, capability: "SECURITY", success: Boolean(result), latencyMs: Date.now() - started, error: result ? null : "security identity unavailable" });
      if (result) return { value: result, attempts, source: provider };
    } catch (error) {
      record(provider, false, error);
      attempts.push({ provider, capability: "SECURITY", success: false, latencyMs: Date.now() - started, error: errorMessage(error) });
    }
  }
  return { value: null, attempts, source: null };
}

export async function orchestratedLiquidity(identity: CanonicalMarketIdentity): Promise<OrchestratedResult<OrchestratedLiquiditySnapshot>> {
  const chain = selectedChain(identity);
  const providerIds = supportedProviderIds("LIQUIDITY", chain);
  const attempts: ProviderAttempt[] = [];
  if (!identity.chain || !identity.contractAddress) return { value: null, attempts, source: null };

  for (const provider of providerIds) {
    const gate = providerMayBeCalled(provider);
    if (!gate.allowed) {
      attempts.push(skippedAttempt(provider, "LIQUIDITY", gate.reason ?? "provider unavailable"));
      continue;
    }
    const started = Date.now();
    try {
      if (provider !== "dexscreener") continue;
      const pair = await withBoundedRetry(() => getTokenMarketSnapshot(identity.chain!, identity.contractAddress!));
      const success = Boolean(pair);
      record(provider, success, success ? undefined : "no liquidity pair");
      attempts.push({ provider, capability: "LIQUIDITY", success, latencyMs: Date.now() - started, error: success ? null : "no liquidity pair" });
      if (pair) {
        return { value: { pair, tokenPriceUsd: resolveTokenPriceUsd(identity.chain, pair, identity.contractAddress), source: "dexscreener" }, attempts, source: provider };
      }
    } catch (error) {
      record(provider, false, error);
      attempts.push({ provider, capability: "LIQUIDITY", success: false, latencyMs: Date.now() - started, error: errorMessage(error) });
    }
  }
  return { value: null, attempts, source: null };
}

export async function orchestratedChart(identity: CanonicalMarketIdentity, timeframe: MarketChartTimeframe | number | "max", limit = 1000): Promise<OrchestratedResult<ProviderChartResult>> {
  const chain = selectedChain(identity);
  const providerIds = supportedProviderIds("OHLCV", chain);
  const attempts: ProviderAttempt[] = [];
  for (const provider of providerIds) {
    if (identity.contractAddress === "native" && provider !== "binance") continue;
    if (identity.contractAddress !== "native" && provider === "binance") continue;
    const gate = providerMayBeCalled(provider);
    if (!gate.allowed) {
      attempts.push(skippedAttempt(provider, "OHLCV", gate.reason ?? "provider unavailable"));
      continue;
    }
    const started = Date.now();
    try {
      let result: ProviderChartResult | null = null;
      if (provider === "binance" && identity.contractAddress === "native") {
        const points = await withBoundedRetry(() => getBinanceNativeOhlcv(identity.chain!, String(timeframe), limit));
        result = points ? { points, source: "binance", historicalAvailable: points.length > 0, providerId: "binance" } : null;
      } else if (provider === "birdeye") result = await withBoundedRetry(() => getBirdeyeChart(identity, timeframe));
      else if (provider === "dexpaprika") result = await withBoundedRetry(() => getDexPaprikaChart(identity, timeframe));
      else continue;
      const resolvedIdentity = resolveAssetIdentity({
        chain: identity.chain,
        contractAddress: identity.contractAddress,
        kind: identity.contractAddress === "native" ? "native" : "token",
      });
      if (result && resolvedIdentity) result = { ...result, identity: result.identity ?? resolvedIdentity };
      const hasPoints = Boolean(result?.points.length);
      record(provider, hasPoints, hasPoints ? undefined : "empty chart response");
      attempts.push({ provider, capability: "OHLCV", success: hasPoints, latencyMs: Date.now() - started, error: hasPoints ? null : "empty chart response" });
      if (hasPoints && result) return { value: result, attempts, source: provider };
    } catch (error) {
      record(provider, false, error);
      attempts.push({ provider, capability: "OHLCV", success: false, latencyMs: Date.now() - started, error: errorMessage(error) });
    }
  }
  return { value: null, attempts, source: null };
}

export function resetProviderRuntimeForTests(): void {
  runtimeHealth.clear();
  requestWindows.clear();
}

export function getProviderHealthSnapshot(): Array<RuntimeHealth & { provider: string; configured: boolean; enabled: boolean }> {
  return Array.from(new Set([...runtimeHealth.keys(), ...listProviderDefinitions().map((provider) => provider.id)])).map((providerId) => {
    const definition = getProviderDefinition(providerId);
    const health = healthFor(providerId);
    return {
      provider: providerId,
      configured: definition?.configured ?? false,
      enabled: definition?.enabled ?? false,
      state: health.state,
      successes: health.successes,
      failures: health.failures,
      lastSuccessAt: health.lastSuccessAt,
      lastFailureAt: health.lastFailureAt,
      lastError: health.lastError ? health.lastError.replace(/(api[_-]?key|token|secret)=?[^\s]*/gi, "$1=[redacted]") : null,
    };
  });
}
