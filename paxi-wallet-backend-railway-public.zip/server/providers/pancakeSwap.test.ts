import { beforeEach, describe, expect, it, vi } from "vitest";

const fetchJson = vi.fn();
vi.mock("./http", () => ({ fetchJson }));

describe("PancakeSwapAdapter", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubEnv("UNISWAP_API_KEY", "test-graph-key");
    vi.stubEnv("PANCAKESWAP_API_KEY", "");
    vi.stubEnv("PANCAKESWAP_BSC_SUBGRAPH_URL", "");
  });

  it("queries the documented BSC V3 deployment and derives BSC token price and liquidity", async () => {
    fetchJson.mockResolvedValue({
      data: {
        bundle: { ethPriceUSD: "3000" },
        pools: [{
          id: "0xpancakepool",
          totalValueLockedUSD: "750000.25",
          token0: { id: "0x1111111111111111111111111111111111111111", symbol: "AAA", name: "AAA", decimals: "18", derivedETH: "0.001" },
          token1: { id: "0x2222222222222222222222222222222222222222", symbol: "WBNB", name: "Wrapped BNB", decimals: "18", derivedETH: "0.2" },
        }],
      },
    });
    const { PancakeSwapAdapter } = await import("./pancakeSwapMarket");
    const result = await new PancakeSwapAdapter().getMarketsForToken("bsc", "0x1111111111111111111111111111111111111111");
    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ source: "pancakeswap", chainId: "bsc", pairAddress: "0xpancakepool", priceUsd: 3, liquidityUsd: 750000.25 });
    expect(fetchJson.mock.calls[0]?.[0]).toContain("/subgraphs/id/Hv1GncLY5docZoGtXjo4kwbTvxm3MAhVZqBZE4sUT9eZ");
  });

  it("does not query unsupported chains or invalid addresses", async () => {
    const { PancakeSwapAdapter } = await import("./pancakeSwapMarket");
    await expect(new PancakeSwapAdapter().getMarketsForToken("ethereum", "0x1111111111111111111111111111111111111111")).resolves.toEqual([]);
    await expect(new PancakeSwapAdapter().getMarketsForToken("bsc", "not-an-address")).resolves.toEqual([]);
    expect(fetchJson).not.toHaveBeenCalled();
  });
});
