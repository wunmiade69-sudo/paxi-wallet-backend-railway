import { ENV } from "../_core/env";
import { fetchJson } from "./http";
import { numberOrNull, token, type MarketProvider, type ProviderMarket } from "./types";

interface PancakeToken { id?: string; symbol?: string; name?: string; decimals?: string; derivedETH?: string | null }
interface PancakePool { id?: string; token0?: PancakeToken; token1?: PancakeToken; totalValueLockedUSD?: string | null; volumeUSD?: string | null }
interface PancakeGraphResponse { data?: { bundle?: { ethPriceUSD?: string | null }; pools?: PancakePool[] }; errors?: Array<{ message?: string }> }

const QUERY = `query TokenPools($token: String!) {
  bundle(id: "1") { ethPriceUSD }
  pools(first: 50, orderBy: totalValueLockedUSD, orderDirection: desc,
    where: { or: [{ token0: $token }, { token1: $token }] }) {
    id totalValueLockedUSD volumeUSD
    token0 { id symbol name decimals derivedETH }
    token1 { id symbol name decimals derivedETH }
  }
}`;

function matches(left: string | undefined, right: string): boolean {
  return Boolean(left && left.toLowerCase() === right.toLowerCase());
}

/** PancakeSwap V3 BSC market provider backed by the official BSC subgraph deployment. */
export class PancakeSwapAdapter implements MarketProvider {
  readonly name = "pancakeswap";

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const address = tokenAddress.trim();
    if (!/^0x[a-fA-F0-9]{40}$/.test(address) || !["bsc", "binance", "56"].includes(chainId.trim().toLowerCase())) return [];
    const apiKey = process.env.PANCAKESWAP_API_KEY || process.env.UNISWAP_API_KEY || ENV.pancakeswapApiKey;
    const endpointOverride = process.env.PANCAKESWAP_BSC_SUBGRAPH_URL ?? ENV.pancakeswapSubgraphUrl;
    const subgraphId = process.env.PANCAKESWAP_BSC_SUBGRAPH_ID ?? ENV.pancakeswapSubgraphId;
    const endpoint = endpointOverride || (apiKey
      ? `https://gateway.thegraph.com/api/${encodeURIComponent(apiKey)}/subgraphs/id/${subgraphId}`
      : "");
    if (!endpoint) return [];
    const response = await fetchJson<PancakeGraphResponse>(endpoint, this.name, { "Content-Type": "application/json" }, {
      method: "POST",
      body: JSON.stringify({ query: QUERY, variables: { token: address.toLowerCase() } }),
    });
    if (response.errors?.length) throw new Error(response.errors.map((error) => error.message ?? "GraphQL error").join("; "));
    const fetchedAt = Date.now();
    const ethPriceUsd = numberOrNull(response.data?.bundle?.ethPriceUSD);
    return (response.data?.pools ?? []).flatMap((pool) => {
      const base = pool.token0;
      const quote = pool.token1;
      if (!base?.id || !quote?.id) return [];
      const target = matches(base.id, address) ? base : matches(quote.id, address) ? quote : null;
      if (!target) return [];
      const derivedEth = numberOrNull(target.derivedETH);
      const priceUsd = derivedEth != null && ethPriceUsd != null ? derivedEth * ethPriceUsd : null;
      return [{
        chainId: "bsc", tokenAddress: address, pairAddress: pool.id ?? null,
        baseToken: token(base), quoteToken: token(quote),
        priceUsd: priceUsd != null && Number.isFinite(priceUsd) ? priceUsd : null,
        volume24hUsd: null, liquidityUsd: numberOrNull(pool.totalValueLockedUSD),
        priceChange24h: null, fdvUsd: null, marketCapUsd: null,
        timestamp: fetchedAt, source: this.name, sourceUpdatedAt: null, fetchedAt,
      } satisfies ProviderMarket];
    });
  }
}
