import { quoteV3ExactInputSingle } from "./v3Quoter";

/**
 * Official PancakeSwap V3 QuoterV2 deployment on BSC (verified on BscScan).
 * PancakeSwap V3 is a fork of Uniswap V3 and exposes the identical
 * QuoterV2 interface.
 * https://developer.pancakeswap.finance/contracts/v3/addresses
 */
const PANCAKESWAP_V3_QUOTER_V2 = "0xB048Bbc1Ee6b733FFfCFb9e9CeF7375518e25997";

/** Direct PancakeSwap V3 quote - no ParaSwap/Velora involved. Read-only rate comparison. */
export async function getPancakeSwapV3Quote(tokenIn: string, tokenOut: string, amountIn: string) {
  return quoteV3ExactInputSingle({ network: "bsc", quoterAddress: PANCAKESWAP_V3_QUOTER_V2, tokenIn, tokenOut, amountIn });
}
