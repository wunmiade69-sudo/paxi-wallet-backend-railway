export interface ProviderToken {
  address: string;
  name: string | null;
  symbol: string | null;
}

export interface ProviderMarket {
  chainId: string;
  tokenAddress: string;
  pairAddress: string | null;
  baseToken: ProviderToken;
  quoteToken: ProviderToken;
  priceUsd: number | null;
  volume24hUsd: number | null;
  liquidityUsd: number | null;
  priceChange24h: number | null;
  fdvUsd: number | null;
  marketCapUsd: number | null;
  timestamp: number;
  source: string;
  sourceUpdatedAt: number | null;
  fetchedAt: number;
}

export interface ProviderOhlcv {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number | null;
  source: string;
}

export interface MarketProvider {
  readonly name: string;
  getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]>;
  getOhlcv?(chainId: string, pairAddress: string, timeframe: string, limit: number): Promise<ProviderOhlcv[]>;
}

export function numberOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Normalize ISO, seconds, or milliseconds to a safe millisecond timestamp. */
export function timestampMs(value: unknown, fallback = Date.now()): number {
  const parsed = typeof value === "string" && !/^\d+(\.\d+)?$/.test(value) ? Date.parse(value) : Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return parsed < 10_000_000_000 ? Math.round(parsed * 1000) : Math.round(parsed);
}

export function token(value: unknown): ProviderToken {
  const row = (value ?? {}) as Record<string, unknown>;
  return {
    address: String(row.address ?? ""),
    name: row.name == null ? null : String(row.name),
    symbol: row.symbol == null ? null : String(row.symbol),
  };
}

export function normalizeChainSlug(chainId: string, map: Record<string, string>): string | null {
  const normalized = chainId.trim().toLowerCase();
  return map[normalized] ?? null;
}
