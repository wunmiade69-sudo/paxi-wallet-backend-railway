import { beforeEach, describe, expect, it, vi } from "vitest";

const fetchJson = vi.fn();
vi.mock("./http", () => ({ fetchJson }));

describe("UniswapAdapter", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubEnv("UNISWAP_ETHEREUM_SUBGRAPH_URL", "https://graph.example/uniswap");
    vi.stubEnv("UNISWAP_API_KEY", "test-key");
  });

  it("normalizes top-pool liquidity and derives the target token USD price", async () => {
    fetchJson.mockResolvedValue({
      data: {
        bundle: { ethPriceUSD: "3000" },
        pools: [{
          id: "0xpool",
          totalValueLockedUSD: "1250000.50",
          token0: { id: "0x1111111111111111111111111111111111111111", symbol: "AAA", name: "AAA", decimals: "18", derivedETH: "0.002" },
          token1: { id: "0x2222222222222222222222222222222222222222", symbol: "WETH", name: "Wrapped Ether", decimals: "18", derivedETH: "1" },
        }],
      },
    });
    const { UniswapAdapter } = await import("./uniswap");
    const result = await new UniswapAdapter().getMarketsForToken("ethereum", "0x1111111111111111111111111111111111111111");
    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ source: "uniswap", pairAddress: "0xpool", priceUsd: 6, liquidityUsd: 1250000.5 });
    expect(fetchJson).toHaveBeenCalledWith("https://graph.example/uniswap", "uniswap", expect.objectContaining({ Authorization: "Bearer test-key" }), expect.objectContaining({ method: "POST" }));
  });

  it("returns no markets when the chain or endpoint is not configured", async () => {
    vi.stubEnv("UNISWAP_ETHEREUM_SUBGRAPH_URL", "");
    const { UniswapAdapter } = await import("./uniswap");
    const result = await new UniswapAdapter().getMarketsForToken("bsc", "0x1111111111111111111111111111111111111111");
    expect(result).toEqual([]);
    expect(fetchJson).not.toHaveBeenCalled();
  });
});
