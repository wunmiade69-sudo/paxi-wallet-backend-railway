import { quoteV3ExactInputSingle } from "./v3Quoter";

/**
 * Official Uniswap V3 QuoterV2 deployment - same address on Ethereum,
 * Polygon, and Arbitrum (verified on Etherscan/Polygonscan/Arbiscan).
 * https://docs.uniswap.org/contracts/v3/reference/deployments
 */
const UNISWAP_V3_QUOTER_V2 = "0x61fFE014bA17989E743c5F6cB21bF9697530B21";

const SUPPORTED_CHAINS = ["ethereum", "polygon", "arbitrum"] as const;
export type UniswapChain = (typeof SUPPORTED_CHAINS)[number];

export function isUniswapSupportedChain(chain: string): chain is UniswapChain {
  return (SUPPORTED_CHAINS as readonly string[]).includes(chain);
}

/** Direct Uniswap V3 quote - no ParaSwap/Velora involved. Read-only rate comparison. */
export async function getUniswapV3Quote(chain: UniswapChain, tokenIn: string, tokenOut: string, amountIn: string) {
  return quoteV3ExactInputSingle({ network: chain, quoterAddress: UNISWAP_V3_QUOTER_V2, tokenIn, tokenOut, amountIn });
}
