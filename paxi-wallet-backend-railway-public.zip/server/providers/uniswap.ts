import { ENV } from "../_core/env";
import { quoteV3ExactInputSingle } from "./v3Quoter";
import { fetchJson } from "./http";
import { normalizeChainSlug, numberOrNull, token, type MarketProvider, type ProviderMarket } from "./types";

/** Official Uniswap V3 QuoterV2 deployment - same address on Ethereum, Polygon, and Arbitrum. */
const UNISWAP_V3_QUOTER_V2 = "0x61fFE014bA17989E743c5F6cB21bF9697530B21";
const SUPPORTED_CHAINS = ["ethereum", "polygon", "arbitrum"] as const;
export type UniswapChain = (typeof SUPPORTED_CHAINS)[number];

export function isUniswapSupportedChain(chain: string): chain is UniswapChain {
  return (SUPPORTED_CHAINS as readonly string[]).includes(chain);
}

/** Direct Uniswap V3 quote - no ParaSwap/Velora involved. Read-only rate comparison. */
export function getUniswapV3Quote(chain: UniswapChain, tokenIn: string, tokenOut: string, amountIn: string) {
  return quoteV3ExactInputSingle({ network: chain, quoterAddress: UNISWAP_V3_QUOTER_V2, tokenIn, tokenOut, amountIn });
}

interface UniswapToken { id?: string; symbol?: string; name?: string; decimals?: string; derivedETH?: string | null }
interface UniswapPool { id?: string; token0?: UniswapToken; token1?: UniswapToken; totalValueLockedUSD?: string | null }
interface UniswapGraphResponse {
  data?: { bundle?: { ethPriceUSD?: string | null }; pools?: UniswapPool[] };
  errors?: Array<{ message?: string }>;
}

const NETWORKS: Record<string, keyof typeof ENV.uniswapSubgraphUrls> = {
  ethereum: "ethereum", eth: "ethereum", polygon: "polygon", polygon_pos: "polygon", arbitrum: "arbitrum",
};
const QUERY = `query TokenPools($token: String!) {
  bundle(id: "1") { ethPriceUSD }
  pools(first: 50, orderBy: totalValueLockedUSD, orderDirection: desc,
    where: { or: [{ token0: $token }, { token1: $token }] }) {
    id totalValueLockedUSD
    token0 { id symbol name decimals derivedETH }
    token1 { id symbol name decimals derivedETH }
  }
}`;

function matches(left: string | undefined, right: string): boolean {
  return Boolean(left && left.toLowerCase() === right.toLowerCase());
}

/** Uniswap V3 subgraph market provider. Configure one GraphQL endpoint per supported chain. */
export class UniswapAdapter implements MarketProvider {
  readonly name = "uniswap";

  async getMarketsForToken(chainId: string, tokenAddress: string): Promise<ProviderMarket[]> {
    const network = normalizeChainSlug(chainId, NETWORKS);
    const address = tokenAddress.trim();
    const endpoint = network ? ENV.uniswapSubgraphUrls[network as keyof typeof ENV.uniswapSubgraphUrls] : undefined;
    if (!network || !endpoint || !/^0x[a-fA-F0-9]{40}$/.test(address)) return [];
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (ENV.uniswapApiKey) headers.Authorization = `Bearer ${ENV.uniswapApiKey}`;
    const response = await fetchJson<UniswapGraphResponse>(endpoint, this.name, headers, {
      method: "POST",
      body: JSON.stringify({ query: QUERY, variables: { token: address.toLowerCase() } }),
    });
    if (response.errors?.length) throw new Error(response.errors.map((error) => error.message ?? "GraphQL error").join("; "));
    const fetchedAt = Date.now();
    const ethPriceUsd = numberOrNull(response.data?.bundle?.ethPriceUSD);
    return (response.data?.pools ?? []).flatMap((pool) => {
      const base = pool.token0;
      const quote = pool.token1;
      if (!base?.id || !quote?.id) return [];
      const target = matches(base.id, address) ? base : matches(quote.id, address) ? quote : null;
      if (!target) return [];
      const derivedEth = numberOrNull(target.derivedETH);
      const priceUsd = derivedEth != null && ethPriceUsd != null ? derivedEth * ethPriceUsd : null;
      return [{
        chainId, tokenAddress: address, pairAddress: pool.id ?? null,
        baseToken: token(base), quoteToken: token(quote),
        priceUsd: priceUsd != null && Number.isFinite(priceUsd) ? priceUsd : null,
        volume24hUsd: null, liquidityUsd: numberOrNull(pool.totalValueLockedUSD),
        priceChange24h: null, fdvUsd: null, marketCapUsd: null,
        timestamp: fetchedAt, source: this.name, sourceUpdatedAt: null, fetchedAt,
      } satisfies ProviderMarket];
    });
  }
}
