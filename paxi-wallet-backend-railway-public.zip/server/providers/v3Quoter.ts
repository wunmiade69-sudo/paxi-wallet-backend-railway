import { Contract, getAddress } from "ethers";
import { withEvmRpc, type RpcNetwork } from "../chains/rpc";

/**
 * Direct on-chain AMM quoting - no third-party REST API, no API key, and no
 * dependency that can be quietly retired the way Jupiter's old quote-api.jup.ag
 * was. Uniswap V3 and PancakeSwap V3 both expose the same QuoterV2 interface
 * (PancakeSwap V3 is a fork of Uniswap V3), so one helper covers both.
 *
 * This is READ-ONLY rate comparison. It does not build swap transactions -
 * Velora/ParaSwap (server/veloraQuote.ts) remains the only execution path.
 * Quoting is a `callStatic`/staticCall against a non-view function, which is
 * how Uniswap's own docs recommend using QuoterV2: it's not gas-efficient
 * and must never be sent as a real transaction.
 */
const QUOTER_V2_ABI = [
  "function quoteExactInputSingle((address tokenIn,address tokenOut,uint256 amountIn,uint24 fee,uint160 sqrtPriceLimitX96) params) returns (uint256 amountOut,uint160 sqrtPriceX96After,uint32 initializedTicksCrossed,uint256 gasEstimate)",
];

/** Fee tiers in hundredths of a bip: 0.01%, 0.05%, 0.25% (Pancake-specific), 0.3%, 1%. */
const COMMON_FEE_TIERS = [100, 500, 2_500, 3_000, 10_000] as const;

export interface V3QuoteResult {
  amountOut: string;
  feeTier: number;
  quoterAddress: string;
}

export async function quoteV3ExactInputSingle(params: {
  network: Exclude<RpcNetwork, "solana" | "bitcoin">;
  quoterAddress: string;
  tokenIn: string;
  tokenOut: string;
  amountIn: string;
}): Promise<V3QuoteResult | null> {
  const quoterAddress = getAddress(params.quoterAddress);
  const tokenIn = getAddress(params.tokenIn);
  const tokenOut = getAddress(params.tokenOut);

  const attempts = await Promise.allSettled(
    COMMON_FEE_TIERS.map((fee) =>
      withEvmRpc(params.network, async (provider) => {
        const quoter = new Contract(quoterAddress, QUOTER_V2_ABI, provider);
        const result = await quoter.quoteExactInputSingle.staticCall({
          tokenIn,
          tokenOut,
          amountIn: BigInt(params.amountIn),
          fee,
          sqrtPriceLimitX96: 0n,
        });
        const amountOut = (result.amountOut ?? result[0]) as bigint;
        return { amountOut, fee };
      }),
    ),
  );

  let best: { amountOut: bigint; fee: number } | null = null;
  for (const attempt of attempts) {
    if (attempt.status !== "fulfilled") continue;
    if (!best || attempt.value.amountOut > best.amountOut) best = attempt.value;
  }
  if (!best || best.amountOut <= 0n) return null;
  return { amountOut: best.amountOut.toString(), feeTier: best.fee, quoterAddress };
}
