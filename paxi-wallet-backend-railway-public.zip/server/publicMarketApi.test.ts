import { describe, expect, it } from "vitest";
import { getDataFreshness } from "./publicMarketApi";

describe("public market API freshness", () => {
  it("marks a recent timestamp as recently updated", () => {
    const result = getDataFreshness(new Date(Date.now() - 30_000));
    expect(result.dataStatus).toBe("recently_updated");
    expect(result.ageSeconds).toBeGreaterThanOrEqual(29);
  });

  it("marks older data as cached instead of calling it live", () => {
    const result = getDataFreshness(new Date(Date.now() - 10 * 60_000));
    expect(result.dataStatus).toBe("cached");
    expect(result.ageSeconds).toBeGreaterThanOrEqual(599);
  });

  it("marks missing timestamps as unavailable", () => {
    expect(getDataFreshness(null)).toEqual({ dataStatus: "unavailable", ageSeconds: null });
  });
});
