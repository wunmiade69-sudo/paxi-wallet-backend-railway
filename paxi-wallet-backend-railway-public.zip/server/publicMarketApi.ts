import type { Express, Request, Response } from "express";
import { and, desc, eq, notInArray } from "drizzle-orm";
import {
  assetMarketData,
  assetMetadata,
  assets,
  candles,
  markets,
} from "../drizzle/schema";
import { normalizeIdentifier } from "./assetRegistry";
import { getReadDb } from "./db";
import { getChainAdapter, listChainAdapters } from "./chains/registry";
import { requireValidIdentifier } from "./chains/types";
import { distributedPublicApiRateLimit } from "./_core/distributedRateLimit";
import { CHART_TIMEFRAMES, getChartData, type ChartTimeframe } from "./chartService";

function numeric(value: string | null | undefined): number | null {
  if (value == null) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

type DataStatus = "recently_updated" | "cached" | "unavailable";

export function getDataFreshness(updatedAt: Date | null | undefined): { dataStatus: DataStatus; ageSeconds: number | null } {
  if (!updatedAt) return { dataStatus: "unavailable", ageSeconds: null };
  const timestamp = updatedAt.getTime();
  if (!Number.isFinite(timestamp)) return { dataStatus: "unavailable", ageSeconds: null };
  const ageSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  return { dataStatus: ageSeconds <= 120 ? "recently_updated" : "cached", ageSeconds };
}

function sendDbUnavailable(res: Response) {
  res.status(503).json({ error: "Database unavailable" });
}

async function findAsset(network: string, rawIdentifier: string) {
  const db = await getReadDb();
  if (!db) return { db: null, asset: null } as const;
  const identifier = normalizeIdentifier(network, decodeURIComponent(rawIdentifier));
  const [row] = await db
    .select()
    .from(assets)
    .where(and(eq(assets.chainId, network), eq(assets.identifier, identifier)))
    .limit(1);
  return { db, asset: row ?? null } as const;
}

function assetResponse(row: typeof assets.$inferSelect, market: typeof assetMarketData.$inferSelect | null) {
  return {
    chain: row.chainId,
    identifier: row.identifier,
    type: row.assetType,
    symbol: row.symbol,
    name: row.name,
    decimals: row.decimals,
    logoUrl: row.logoUrl,
    status: row.status,
    verificationStatus: row.verificationStatus,
    market: market
      ? {
          priceUsd: numeric(market.priceUsd),
          priceChange1h: numeric(market.priceChange1h),
          priceChange24h: numeric(market.priceChange24h),
          priceChange7d: numeric(market.priceChange7d),
          volume24hUsd: numeric(market.volume24hUsd),
          liquidityUsd: numeric(market.liquidityUsd),
          marketCapUsd: numeric(market.marketCapUsd),
          fdvUsd: numeric(market.fdvUsd),
          source: market.source,
          ...getDataFreshness(market.updatedAt),
          updatedAt: market.updatedAt,
        }
      : null,
    ...getDataFreshness(row.updatedAt),
    updatedAt: row.updatedAt,
  };
}

function handleError(res: Response, error: unknown) {
  console.error("[public-market-api] request failed", error);
  res.status(500).json({ error: "Internal server error" });
}

function publicEdgeCache(req: Request, res: Response, next: () => void) {
  if (req.method === "GET") {
    const maxAge = req.path.startsWith("/chains") ? 300 : 5;
    const sharedAge = req.path.startsWith("/chains") ? 900 : 15;
    res.setHeader("Cache-Control", `public, max-age=${maxAge}, s-maxage=${sharedAge}, stale-while-revalidate=30`);
    res.setHeader("Vary", "Accept-Encoding");
  }
  next();
}

export function registerPublicMarketApi(app: Express) {
  // Apply rate limiting to all public asset and chain routes
  app.use("/api/assets", distributedPublicApiRateLimit, publicEdgeCache);
  app.use("/api/chains", distributedPublicApiRateLimit, publicEdgeCache);

  app.get("/api/chains", (_req: Request, res: Response) => {
    res.json(listChainAdapters());
  });

  app.get("/api/chains/:network/validate/:identifier", (req: Request, res: Response) => {
    try {
      const adapter = getChainAdapter(req.params.network);
      const identifier = decodeURIComponent(req.params.identifier);
      const normalized = adapter.normalizeIdentifier(identifier);
      res.json({
        network: adapter.network,
        family: adapter.family,
        identifier: normalized,
        valid: adapter.validateIdentifier(normalized),
        explorerUrl: adapter.getExplorerUrl("address", normalized),
      });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid chain identifier" });
    }
  });

  app.get("/api/chains/:network/balance/:address", async (req: Request, res: Response) => {
    try {
      const adapter = getChainAdapter(req.params.network);
      const address = requireValidIdentifier(adapter, decodeURIComponent(req.params.address));
      const balance = await adapter.getNativeBalance(address);
      res.json({ network: adapter.network, address, symbol: adapter.nativeSymbol, balance });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unable to read chain balance" });
    }
  });

  app.get("/api/assets", async (req: Request, res: Response) => {
    try {
      const db = await getReadDb();
      if (!db) return sendDbUnavailable(res);
      const limit = Math.min(Math.max(Number(req.query.limit ?? 50) || 50, 1), 100);
      const rows = await db
        .select({ asset: assets, market: assetMarketData })
        .from(assets)
        .leftJoin(assetMarketData, eq(assetMarketData.assetId, assets.id))
        .where(notInArray(assets.status, ["blocked", "spam"]))
        .orderBy(desc(assets.updatedAt))
        .limit(limit);
      res.json(rows.map(({ asset, market }) => assetResponse(asset, market)));
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/assets/:chain/:identifier", async (req: Request, res: Response) => {
    try {
      const result = await findAsset(req.params.chain, req.params.identifier);
      if (!result.db) return sendDbUnavailable(res);
      if (!result.asset) return res.status(404).json({ error: "Asset not found" });
      const [market] = await result.db
        .select()
        .from(assetMarketData)
        .where(eq(assetMarketData.assetId, result.asset.id))
        .limit(1);
      res.json(assetResponse(result.asset, market ?? null));
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/assets/:chain/:identifier/price", async (req: Request, res: Response) => {
    try {
      const result = await findAsset(req.params.chain, req.params.identifier);
      if (!result.db) return sendDbUnavailable(res);
      if (!result.asset) return res.status(404).json({ error: "Asset not found" });
      const [market] = await result.db
        .select()
        .from(assetMarketData)
        .where(eq(assetMarketData.assetId, result.asset.id))
        .limit(1);
      res.json({
        chain: result.asset.chainId,
        identifier: result.asset.identifier,
        priceUsd: numeric(market?.priceUsd),
        source: market?.source ?? null,
        ...getDataFreshness(market?.updatedAt),
        updatedAt: market?.updatedAt ?? null,
      });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/assets/:chain/:identifier/markets", async (req: Request, res: Response) => {
    try {
      const result = await findAsset(req.params.chain, req.params.identifier);
      if (!result.db) return sendDbUnavailable(res);
      if (!result.asset) return res.status(404).json({ error: "Asset not found" });
      const rows = await result.db
        .select()
        .from(markets)
        .where(and(eq(markets.assetId, result.asset.id), eq(markets.status, "active")))
        .orderBy(desc(markets.updatedAt));
      res.json(rows);
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/assets/:chain/:identifier/chart", async (req: Request, res: Response) => {
    try {
      const result = await findAsset(req.params.chain, req.params.identifier);
      if (!result.db) return sendDbUnavailable(res);
      if (!result.asset) return res.status(404).json({ error: "Asset not found" });
      const timeframe = String(req.query.timeframe ?? "1h").toLowerCase();
      if (!CHART_TIMEFRAMES.includes(timeframe as ChartTimeframe)) {
        res.status(400).json({ error: `Invalid timeframe. Expected one of: ${CHART_TIMEFRAMES.join(", ")}` });
        return;
      }
      const limit = Math.min(Math.max(Number(req.query.limit ?? 500) || 500, 1), 2_000);
      const chart = await getChartData({
        db: result.db,
        assetId: result.asset.id,
        chainId: result.asset.chainId,
        tokenAddress: result.asset.identifier,
        timeframe: timeframe as ChartTimeframe,
        limit,
      });
      res.json({
        chain: result.asset.chainId,
        identifier: result.asset.identifier,
        timeframe,
        ...chart,
      });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/assets/:chain/:identifier/stats", async (req: Request, res: Response) => {
    try {
      const result = await findAsset(req.params.chain, req.params.identifier);
      if (!result.db) return sendDbUnavailable(res);
      if (!result.asset) return res.status(404).json({ error: "Asset not found" });
      const [market] = await result.db
        .select()
        .from(assetMarketData)
        .where(eq(assetMarketData.assetId, result.asset.id))
        .limit(1);
      res.json({
        chain: result.asset.chainId,
        identifier: result.asset.identifier,
        priceUsd: numeric(market?.priceUsd),
        marketCapUsd: numeric(market?.marketCapUsd),
        fdvUsd: numeric(market?.fdvUsd),
        volume24hUsd: numeric(market?.volume24hUsd),
        liquidityUsd: numeric(market?.liquidityUsd),
        priceChange1h: numeric(market?.priceChange1h),
        priceChange24h: numeric(market?.priceChange24h),
        priceChange7d: numeric(market?.priceChange7d),
        source: market?.source ?? null,
        ...getDataFreshness(market?.updatedAt),
        updatedAt: market?.updatedAt ?? null,
      });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.get("/api/assets/:chain/:identifier/metadata", async (req: Request, res: Response) => {
    try {
      const result = await findAsset(req.params.chain, req.params.identifier);
      if (!result.db) return sendDbUnavailable(res);
      if (!result.asset) return res.status(404).json({ error: "Asset not found" });
      const [metadata] = await result.db
        .select()
        .from(assetMetadata)
        .where(eq(assetMetadata.assetId, result.asset.id))
        .limit(1);
      res.json({
        chain: result.asset.chainId,
        identifier: result.asset.identifier,
        symbol: result.asset.symbol,
        name: result.asset.name,
        logoUrl: result.asset.logoUrl,
        metadata: metadata ?? null,
      });
    } catch (error) {
      handleError(res, error);
    }
  });
}
