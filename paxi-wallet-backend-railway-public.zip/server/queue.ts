import { Queue } from "bullmq";
import { getQueueConnection } from "./redis";

/**
 * Phase 3B - Background Worker Queue
 * 
 * We use a single queue for all market data background tasks:
 * - price.refresh: Update a specific asset's price
 * - market.discover: Find new pools/markets for a chain
 * - metadata.refresh: Update token metadata (logo, name, etc.)
 * - liquidity.refresh: Update pool liquidity/volume
 * - candle.generate: Aggregate snapshots into OHLCV candles
 */

export const MARKET_DATA_QUEUE_NAME = "paxi-market-data";

let _queue: Queue | null | undefined;

export function getMarketDataQueue(): Queue | null {
  if (_queue !== undefined) return _queue;

  const connection = getQueueConnection();
  if (!connection) {
    console.warn("[queue] Redis connection unavailable, queue disabled");
    _queue = null;
    return null;
  }

  _queue = new Queue(MARKET_DATA_QUEUE_NAME, {
    connection,
    defaultJobOptions: {
      attempts: 3,
      backoff: {
        type: "exponential",
        delay: 5000,
      },
      removeOnComplete: true,
      removeOnFail: 1000, // keep some history for debugging
    },
  });

  return _queue;
}

export type JobType = 
  | "price.refresh" 
  | "market.discover" 
  | "metadata.refresh" 
  | "liquidity.refresh" 
  | "candle.generate";

export interface MarketJobData {
  type: JobType;
  chainId?: string;
  identifier?: string;
  assetId?: number;
  timeframe?: string;
  dexId?: number;
  poolAddress?: string;
  force?: boolean;
}

/**
 * Enqueue a background task.
 * Returns the job ID if successful, or null if queue is disabled.
 */
export async function enqueueMarketTask(data: MarketJobData): Promise<string | null> {
  const queue = getMarketDataQueue();
  if (!queue) return null;

  try {
    const jobName = `${data.type}:${data.chainId || "any"}:${data.identifier || "any"}`;
    const job = await queue.add(jobName, data, {
      // Use job name as jobId for price refreshes to avoid duplicate active jobs
      // for the same asset within a short window.
      jobId: data.type === "price.refresh" ? jobName : undefined,
    });
    return job.id || null;
  } catch (err) {
    console.error("[queue] failed to enqueue task:", err);
    return null;
  }
}
