import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const root = resolve(import.meta.dirname, "..");

function readProjectFile(relativePath: string): string {
  return readFileSync(resolve(root, relativePath), "utf8");
}

describe("Railway staging and Android security boundaries", () => {
  it("keeps the production database contract MySQL-compatible", () => {
    const drizzleConfig = readProjectFile("drizzle.config.ts");
    const databaseLayer = readProjectFile("server/db.ts");

    expect(drizzleConfig).toContain('dialect: "mysql"');
    expect(databaseLayer).toContain('from "drizzle-orm/mysql2"');
    expect(databaseLayer).toContain("mysql2");
  });

  it("requires an explicit HTTPS API origin for native builds", () => {
    const envExample = readProjectFile(".env.example");
    expect(envExample).toContain("VITE_PAXI_API_ORIGIN=");
    expect(envExample).toContain("HTTPS");
  });

  it("does not retain the stale client-side Forge-key map path", () => {
    const envExample = readProjectFile(".env.example");

    expect(envExample).not.toContain("VITE_FRONTEND_FORGE_API_KEY");
    expect(envExample).not.toContain("VITE_FRONTEND_FORGE_API_URL");
    expect(existsSync(resolve(root, "client/src/components/Map.tsx"))).toBe(
      false
    );
  });

  it("keeps Forge and payout credentials server-side in the environment template", () => {
    const envExample = readProjectFile(".env.example");
    const serverEnv = readProjectFile("server/_core/env.ts");

    expect(envExample).toContain("BUILT_IN_FORGE_API_KEY=");
    expect(envExample).toContain("PAXI_PAYOUT_PRIVATE_KEY=");
    expect(serverEnv).toContain("forgeApiKey");
    expect(serverEnv).toContain("paxiPayoutPrivateKey");
  });

  it("preserves the Railway staging deployment contract", () => {
    const packageJson = JSON.parse(readProjectFile("package.json")) as {
      scripts?: Record<string, string>;
    };
    const server = readProjectFile("server/_core/index.ts");

    expect(packageJson.scripts?.build).toContain("vite build");
    expect(packageJson.scripts?.start).toContain("node dist/index.js");
    expect(packageJson.scripts?.["db:push"]).toBe(
      "npm run db:deploy && npm run db:regression"
    );
    expect(server).toContain("/healthz");
    expect(server).toContain("/readyz");
  });
});
