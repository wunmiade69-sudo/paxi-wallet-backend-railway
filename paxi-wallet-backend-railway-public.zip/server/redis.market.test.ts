import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("ioredis", () => {
  class FakeRedis {
    public readonly status = process.env.TEST_REDIS_STATUS ?? "ready";
    private readonly store = new Map<string, string>();

    on(): this {
      return this;
    }

    async get(key: string): Promise<string | null> {
      return this.store.get(key) ?? null;
    }

    async set(key: string, value: string, ...args: unknown[]): Promise<string | null> {
      if (args.includes("NX") && this.store.has(key)) return null;
      this.store.set(key, value);
      return "OK";
    }

    async del(key: string): Promise<number> {
      return this.store.delete(key) ? 1 : 0;
    }

    async ping(): Promise<string> {
      return "PONG";
    }
  }

  return { default: FakeRedis };
});

describe("optional market Redis cache", () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it("reads a value it previously wrote when Redis is configured", async () => {
    vi.stubEnv("REDIS_URL", "redis://unit-test.invalid");
    const redis = await import("./redis");

    await redis.setCachedMarketJson("search", "paxi", { items: [{ chain: "solana", contractAddress: "Mint" }] });

    await expect(redis.getCachedMarketJson("search", "paxi")).resolves.toEqual({
      items: [{ chain: "solana", contractAddress: "Mint" }],
    });
    await expect(redis.getRedisHealth()).resolves.toBe("healthy");
  });

  it("recreates a terminal Redis client after the service recovers", async () => {
    vi.stubEnv("REDIS_URL", "redis://unit-test.invalid");
    vi.stubEnv("TEST_REDIS_STATUS", "end");
    const redis = await import("./redis");

    const terminal = redis.getRedis();
    vi.stubEnv("TEST_REDIS_STATUS", "ready");
    const recovered = redis.getRedis();

    expect(terminal?.status).toBe("end");
    expect(recovered).not.toBe(terminal);
    await expect(redis.getRedisHealth()).resolves.toBe("healthy");
  });

  it("treats an unset Redis URL as a cache miss and does not throw", async () => {
    vi.stubEnv("REDIS_URL", "");
    const redis = await import("./redis");

    await expect(redis.getCachedMarketJson("detail", "ethereum:0xabc")).resolves.toBeNull();
    await expect(redis.setCachedMarketJson("detail", "ethereum:0xabc", { value: 1 })).resolves.toBeUndefined();
    await expect(redis.getRedisHealth()).resolves.toBe("unavailable");
  });
});
