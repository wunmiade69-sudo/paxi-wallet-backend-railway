/**
 * Lazy Redis connection, same pattern as server/db.ts's getDb(): returns
 * null instead of throwing when REDIS_URL isn't set or the connection
 * fails, so local dev and any environment without Redis keeps working -
 * just without the shared cache / distributed lock benefits. Every caller
 * in this codebase (priceEngine.ts) is written to treat a null client the
 * same as a cache miss, never as an error.
 */
import Redis from "ioredis";
import { randomUUID } from "node:crypto";
import { ENV } from "./_core/env";

let _redis: Redis | null | undefined; // undefined = not attempted yet, null = attempted and unavailable

function redisTlsOptions(): { tls?: { rejectUnauthorized: boolean } } {
  if (!ENV.redisUrl.startsWith("rediss://")) return {};
  return { tls: { rejectUnauthorized: true } };
}

export function getRedis(): Redis | null {
  if (_redis !== undefined) return _redis;
  if (!ENV.redisUrl) {
    _redis = null;
    return _redis;
  }
  try {
    if (ENV.redisTlsRequired && !ENV.redisUrl.startsWith("rediss://")) {
      throw new Error("REDIS_TLS_REQUIRED=true requires a rediss:// URL");
    }
    const client = new Redis(ENV.redisUrl, {
      ...redisTlsOptions(),
      // Fail fast instead of buffering commands indefinitely when Redis is
      // down - callers already have a MySQL/live-fetch fallback, so a slow
      // hang here is strictly worse than a quick "treat this as a miss".
      maxRetriesPerRequest: 1,
      connectTimeout: 3_000,
      commandTimeout: 1_500,
      enableOfflineQueue: false,
      retryStrategy: (times) => (times > 3 ? null : Math.min(times * 200, 1000)),
      lazyConnect: false,
    });
    client.on("error", (err) => {
      console.warn("[redis] connection error (falling back to MySQL/live fetch):", err.message);
    });
    _redis = client;
  } catch (err) {
    console.warn("[redis] failed to initialize client:", err);
    _redis = null;
  }
  return _redis;
}

/**
 * Returns a new Redis connection specifically for BullMQ.
 * BullMQ requires maxRetriesPerRequest to be null.
 */
export function getQueueConnection(): Redis | null {
  if (!ENV.redisUrl) return null;
  try {
    if (ENV.redisTlsRequired && !ENV.redisUrl.startsWith("rediss://")) {
      throw new Error("REDIS_TLS_REQUIRED=true requires a rediss:// URL");
    }
    return new Redis(ENV.redisUrl, {
      ...redisTlsOptions(),
      maxRetriesPerRequest: null,
      connectTimeout: 5_000,
      enableReadyCheck: true,
      retryStrategy: (times) => Math.min(times * 500, 5_000),
      lazyConnect: false,
    });
  } catch (err) {
    console.warn("[redis] failed to initialize queue connection:", err);
    return null;
  }
}

/** Wraps a Redis call so a down/misbehaving Redis degrades to "miss" instead of throwing into caller code. */
export async function redisSafe<T>(fn: (client: Redis) => Promise<T>): Promise<T | null> {
  const client = getRedis();
  if (!client) return null;
  try {
    return await fn(client);
  } catch (err) {
    console.warn("[redis] operation failed (falling back):", err);
    return null;
  }
}

/**
 * Shared asset-price cache helpers - used by both priceEngine.ts (the
 * read/refresh path) and dexLiquidity.ts (which writes assetMarketData
 * directly during the listing auto-verify check, bypassing priceEngine's
 * own fetch path, and should still keep Redis in sync so a subsequent
 * priceEngine read isn't served a stale entry Redis doesn't know changed).
 * `cacheKey` is always `${chainId}:${normalizedIdentifier}` - callers build
 * it via assetRegistry.ts's normalizeIdentifier so casing stays consistent
 * with how assets.identifier itself is normalized.
 */
export interface CachedAssetPrice {
  priceUsd: number;
  change24h: number | null;
  source: string;
  confidence?: "high" | "medium" | "low" | "none";
  sources?: string[];
  sourceUpdatedAt?: number | null;
  fetchedAt?: number;
  isStale?: boolean;
  volume24hUsd?: number | null;
  liquidityUsd?: number | null;
  fdvUsd?: number | null;
  marketCapUsd?: number | null;
}

const PRICE_CACHE_TTL_SEC = 90; // matches priceEngine.ts's DB_STALE_MS - once this expires, the next reader falls through to MySQL and repopulates it

export async function getCachedAssetPrice(cacheKey: string): Promise<CachedAssetPrice | null> {
  const raw = await redisSafe((client) => client.get(`price:${cacheKey}`));
  if (!raw) return null;
  try {
    return JSON.parse(raw) as CachedAssetPrice;
  } catch {
    return null; // corrupt/old-format entry - treat as a miss rather than throwing
  }
}

export async function setCachedAssetPrice(cacheKey: string, price: CachedAssetPrice): Promise<void> {
  await redisSafe((client) => client.set(`price:${cacheKey}`, JSON.stringify(price), "EX", PRICE_CACHE_TTL_SEC));
}

export type ChartCacheTimeframe = "1m" | "5m" | "15m" | "30m" | "1h" | "4h" | "1d";
export interface CachedChartData {
  candles: unknown[];
  source: string;
  fallback: boolean;
  requestedLimit: number;
  returned: number;
  generatedAt: number;
}

const CHART_CACHE_TTL_SEC: Record<ChartCacheTimeframe, number> = {
  "1m": 20,
  "5m": 60,
  "15m": 120,
  "30m": 180,
  "1h": 45,
  "4h": 120,
  "1d": 600,
};

export async function getCachedChartData(cacheKey: string): Promise<CachedChartData | null> {
  const raw = await redisSafe((client) => client.get(`chart:${cacheKey}`));
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as CachedChartData;
    if (!Array.isArray(parsed.candles) || typeof parsed.source !== "string") return null;
    return parsed;
  } catch {
    return null;
  }
}

export async function setCachedChartData(cacheKey: string, timeframe: ChartCacheTimeframe, value: CachedChartData): Promise<void> {
  await redisSafe((client) => client.set(`chart:${cacheKey}`, JSON.stringify(value), "EX", CHART_CACHE_TTL_SEC[timeframe]));
}

/**
 * Distributed refresh lock (Redis SET NX PX - atomic "only if not already
 * held"). This is what actually solves the cache-stampede problem across
 * multiple API instances, not just within one process: when a price
 * expires under load, every instance's request for it converges here, but
 * only the one that wins the SET NX call proceeds to call
 * DexScreener/RPC. Every other instance that finds the lock already held
 * gets `{ acquired: false, reason: "held" }` immediately and falls back to
 * serving the last-known value instead of piling onto the same external
 * call. Auto-expires via PX so a crashed holder can't wedge it.
 *
 * The lock value is a random token PER ACQUISITION, not a constant "1" -
 * required for release to be safe. Without this: if a holder's operation
 * runs past the TTL (slow DexScreener/RPC call), the lock auto-expires,
 * a second instance acquires a NEW lock, and then the FIRST holder's
 * eventual `DEL` would delete the second holder's still-active lock - one
 * instance deleting a lock it no longer owns. Returning/checking a unique
 * token means release only ever removes a lock this exact acquisition
 * created; a `DEL` that's actually for an expired-and-reacquired lock is a
 * no-op instead of a corruption.
 *
 * The compare-then-delete has to be one atomic Redis operation (a Lua
 * script), not a GET followed by a separate DEL from application code -
 * two round trips leaves a window where the lock could expire and be
 * reacquired by someone else in between them, reintroducing the exact
 * race this is meant to close.
 *
 * "Couldn't acquire" has two completely different causes, and callers
 * need to tell them apart: another instance legitimately holds the lock
 * (reason: "held" - correct to back off and serve stale data), versus
 * Redis itself being unreachable (reason: "unavailable" - backing off
 * here would be wrong, since nothing is actually protecting anyone from a
 * stale price; the caller should fall through and fetch live directly,
 * same as if Redis had never been configured at all). Collapsing both
 * into a single `null` - which the previous version of this function did
 * - meant a Redis outage silently stopped every instance from ever
 * refreshing a price again, the opposite of graceful degradation.
 */
const PRICE_LOCK_TTL_MS = 30_000; // generous enough for a DexScreener call + DB writes + possibly an RPC read, without needing perfect ownership tracking to stay safe

const RELEASE_LOCK_SCRIPT = `
if redis.call("get", KEYS[1]) == ARGV[1] then
  return redis.call("del", KEYS[1])
else
  return 0
end
`;

export type PriceLockResult = { acquired: true; token: string } | { acquired: false; reason: "held" | "unavailable" };

export async function acquirePriceRefreshLock(cacheKey: string): Promise<PriceLockResult> {
  const client = getRedis();
  if (!client) return { acquired: false, reason: "unavailable" };

  const token = randomUUID();
  try {
    const result = await client.set(`price:${cacheKey}:lock`, token, "PX", PRICE_LOCK_TTL_MS, "NX");
    return result === "OK" ? { acquired: true, token } : { acquired: false, reason: "held" };
  } catch (err) {
    console.warn("[redis] lock acquire failed (falling back to unprotected refresh):", err);
    return { acquired: false, reason: "unavailable" };
  }
}

/** No-ops (rather than deleting) if `token` doesn't match the current holder - i.e. this acquisition's lock already expired and someone else has since acquired it. Never call this unless acquirePriceRefreshLock returned `acquired: true` for this token. */
export async function releasePriceRefreshLock(cacheKey: string, token: string): Promise<void> {
  await redisSafe((client) => client.eval(RELEASE_LOCK_SCRIPT, 1, `price:${cacheKey}:lock`, token));
}

/**
 * Provider-specific cooldown helpers. Used to temporarily back off from a 
 * provider that is rate-limiting (429) or failing (5xx/timeout).
 */
export async function isProviderOnCooldown(providerName: string): Promise<boolean> {
  const result = await redisSafe((client) => client.get(`cooldown:${providerName}`));
  return result === "1";
}

export async function setProviderCooldown(providerName: string, durationSec = 60): Promise<void> {
  await redisSafe((client) => client.set(`cooldown:${providerName}`, "1", "EX", durationSec));
}
