export class CircuitOpenError extends Error {
  constructor(public readonly name: string, public readonly retryAfterMs: number) {
    super(`Circuit breaker ${name} is open; retry after ${retryAfterMs}ms`);
    this.name = "CircuitOpenError";
  }
}

interface CircuitState {
  failures: number;
  openedAt: number | null;
  halfOpenInFlight: boolean;
}

export interface CircuitBreakerOptions {
  failureThreshold?: number;
  resetTimeoutMs?: number;
}

export class CircuitBreaker {
  private readonly failureThreshold: number;
  private readonly resetTimeoutMs: number;
  private state: CircuitState = { failures: 0, openedAt: null, halfOpenInFlight: false };

  constructor(public readonly name: string, options: CircuitBreakerOptions = {}) {
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 30_000;
  }

  get status(): "closed" | "open" | "half-open" {
    if (this.state.openedAt == null) return "closed";
    return Date.now() - this.state.openedAt >= this.resetTimeoutMs ? "half-open" : "open";
  }

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    const status = this.status;
    if (status === "open") {
      throw new CircuitOpenError(this.name, this.resetTimeoutMs - (Date.now() - (this.state.openedAt ?? Date.now())));
    }
    if (status === "half-open") {
      if (this.state.halfOpenInFlight) {
        throw new CircuitOpenError(this.name, this.resetTimeoutMs);
      }
      this.state.halfOpenInFlight = true;
    }

    try {
      const result = await operation();
      this.state = { failures: 0, openedAt: null, halfOpenInFlight: false };
      return result;
    } catch (error) {
      this.state.halfOpenInFlight = false;
      this.state.failures += 1;
      if (this.state.failures >= this.failureThreshold) {
        this.state.openedAt = Date.now();
      }
      throw error;
    }
  }

  reset() {
    this.state = { failures: 0, openedAt: null, halfOpenInFlight: false };
  }
}

const breakers = new Map<string, CircuitBreaker>();

export function getCircuitBreaker(name: string, options?: CircuitBreakerOptions): CircuitBreaker {
  const existing = breakers.get(name);
  if (existing) return existing;
  const breaker = new CircuitBreaker(name, options);
  breakers.set(name, breaker);
  return breaker;
}

export function listCircuitBreakers() {
  return [...breakers.values()].map((breaker) => ({ name: breaker.name, status: breaker.status }));
}
