import { beforeEach, describe, expect, it, vi } from 'vitest';

const getReadDb = vi.hoisted(() => vi.fn());

vi.mock('../db', () => ({
  getDb: vi.fn(),
  getReadDb,
}));

import { hashRewardCode, previewGiftCode } from './rewardService';

type FakeDb = {
  select: () => { from: () => { where: () => { limit: (count: number) => Promise<unknown[]> } } };
};

function createReadDb(rows: unknown[]): FakeDb {
  return {
    select: () => ({
      from: () => ({
        where: () => ({
          limit: async (_count: number) => [rows.shift()],
        }),
      }),
    }),
  };
}

const baseGiftCode = {
  id: 42,
  codeHash: hashRewardCode('GIFT-AB1234'),
  codeHint: '1234',
  assetSymbol: 'USDT',
  assetNetwork: 'bsc',
  assetContractAddress: '0x2222222222222222222222222222222222222222',
  rewardAmount: '12.5',
  maxRedemptions: 5,
  redemptionCount: 2,
  expiresAt: null,
  status: 'active',
  createdByOpenId: 'admin',
};

describe('Gift Code preview service', () => {
  beforeEach(() => {
    getReadDb.mockReset();
  });

  it('returns server-owned amount, network, contract identity, and remaining limit', async () => {
    getReadDb.mockResolvedValue(createReadDb([baseGiftCode, undefined]));
    await expect(previewGiftCode('user-1', 'gift-ab1234')).resolves.toMatchObject({
      assetSymbol: 'USDT',
      assetNetwork: 'bsc',
      assetContractAddress: baseGiftCode.assetContractAddress,
      rewardAmount: '12.5',
      redemptionsRemaining: 3,
      fulfillment: 'credited',
      requiresRecipientWallet: false,
    });
  });

  it('rejects malformed codes before touching the database', async () => {
    await expect(previewGiftCode('user-1', 'bad')).rejects.toThrow('Invalid gift or referral code');
    expect(getReadDb).not.toHaveBeenCalled();
  });

  it.each([
    ['expired', { ...baseGiftCode, expiresAt: new Date(Date.now() - 1) }, 'Gift code has expired'],
    ['paused', { ...baseGiftCode, status: 'paused' }, 'Gift code is no longer available'],
    ['exhausted', { ...baseGiftCode, redemptionCount: 5 }, 'Gift code is no longer available'],
  ])('rejects %s codes without returning reward details', async (_label, giftCode, message) => {
    getReadDb.mockResolvedValue(createReadDb([giftCode]));
    await expect(previewGiftCode('user-1', 'GIFT-AB1234')).rejects.toThrow(message);
  });

  it('rejects a code already redeemed by the requesting wallet', async () => {
    getReadDb.mockResolvedValue(createReadDb([baseGiftCode, { id: 7, giftCodeId: 42, userOpenId: 'user-1', status: 'credited' }]));
    await expect(previewGiftCode('user-1', 'GIFT-AB1234')).rejects.toThrow('Gift code already redeemed by this user');
  });

  it('marks WPAXI as claimable and requires an explicit BSC recipient without pretending a transfer happened', async () => {
    getReadDb.mockResolvedValue(createReadDb([{
      ...baseGiftCode,
      assetSymbol: 'WPAXI',
      assetNetwork: 'bsc',
    }, undefined]));
    await expect(previewGiftCode('user-1', 'GIFT-AB1234')).resolves.toMatchObject({
      fulfillment: 'claimable',
      requiresRecipientWallet: true,
    });
  });
});
