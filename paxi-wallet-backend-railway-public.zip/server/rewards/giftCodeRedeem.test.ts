import { beforeEach, describe, expect, it, vi } from 'vitest';

const getDb = vi.hoisted(() => vi.fn());

vi.mock('../db', () => ({
  getDb,
  getReadDb: vi.fn(),
}));

import { hashRewardCode, redeemGiftCode } from './rewardService';

type GiftCodeState = {
  id: number;
  codeHash: string;
  codeHint: string;
  assetSymbol: string;
  assetNetwork: string;
  assetContractAddress: string | null;
  rewardAmount: string;
  maxRedemptions: number;
  redemptionCount: number;
  expiresAt: Date | null;
  status: 'active' | 'paused' | 'exhausted' | 'expired' | 'cancelled';
  createdByOpenId: string;
};

function createTransactionalDb(giftCode: GiftCodeState) {
  const redemptions = new Map<string, { id: number; rewardLedgerId: number | null }>();
  let ledgerId = 100;
  let nextRedemptionId = 1;
  const db = {
    transaction: async <T>(callback: (tx: any) => Promise<T>) => {
      let selectCount = 0;
      let updateCount = 0;
      let insertCount = 0;
      const tx = {
        select: () => ({
          from: () => ({
            where: () => ({
              limit: async (_count: number) => {
                selectCount += 1;
                if (selectCount === 1) return [giftCode];
                if (selectCount === 2) {
                  const existing = redemptions.get('user-1');
                  return existing ? [{ ...existing, giftCodeId: giftCode.id, userOpenId: 'user-1' }] : [];
                }
                return [{ id: ledgerId, userOpenId: 'user-1', amount: giftCode.rewardAmount, assetSymbol: giftCode.assetSymbol, assetNetwork: giftCode.assetNetwork, status: 'approved' }];
              },
            }),
          }),
        }),
        update: () => ({
          set: () => ({
            where: async () => {
              updateCount += 1;
              if (updateCount > 1) return { affectedRows: 1 };
              if (giftCode.redemptionCount >= giftCode.maxRedemptions || giftCode.status !== 'active') return { affectedRows: 0 };
              giftCode.redemptionCount += 1;
              if (giftCode.redemptionCount >= giftCode.maxRedemptions) giftCode.status = 'exhausted';
              return { affectedRows: 1 };
            },
          }),
        }),
        insert: (table: unknown) => ({
          values: async () => {
            insertCount += 1;
            if (insertCount === 1) {
              const id = nextRedemptionId++;
              redemptions.set('user-1', { id, rewardLedgerId: null });
              return { insertId: id };
            }
            return { insertId: ledgerId };
          },
        }),
      };
      return callback(tx);
    },
  };
  return { db, redemptions };
}

function baseGiftCode(maxRedemptions = 2): GiftCodeState {
  return {
    id: 7,
    codeHash: hashRewardCode('GIFT-AB1234'),
    codeHint: '1234',
    assetSymbol: 'USDT',
    assetNetwork: 'bsc',
    assetContractAddress: '0x2222222222222222222222222222222222222222',
    rewardAmount: '3',
    maxRedemptions,
    redemptionCount: 0,
    expiresAt: null,
    status: 'active',
    createdByOpenId: 'admin',
  };
}

describe('Gift Code redemption safety', () => {
  beforeEach(() => getDb.mockReset());

  it('does not over-redeem the final available use under concurrent requests', async () => {
    const { db } = createTransactionalDb(baseGiftCode(1));
    getDb.mockResolvedValue(db);
    const results = await Promise.allSettled([
      redeemGiftCode('user-1', 'GIFT-AB1234'),
      redeemGiftCode('user-1', 'GIFT-AB1234'),
    ]);
    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((result) => result.status === 'rejected')).toHaveLength(1);
  });

  it('uses the existing user redemption and ledger on a safe retry path', async () => {
    const giftCode = baseGiftCode(2);
    const { db, redemptions } = createTransactionalDb(giftCode);
    getDb.mockResolvedValue(db);
    const first = await redeemGiftCode('user-1', 'GIFT-AB1234');
    const redemption = redemptions.get('user-1');
    expect(first.amount).toBe('3');
    expect(redemption).toBeDefined();
    if (redemption) redemption.rewardLedgerId = first.id;
    await expect(redeemGiftCode('user-1', 'GIFT-AB1234')).resolves.toMatchObject({ amount: '3', assetSymbol: 'USDT' });
    expect(giftCode.redemptionCount).toBe(1);
  });
});
