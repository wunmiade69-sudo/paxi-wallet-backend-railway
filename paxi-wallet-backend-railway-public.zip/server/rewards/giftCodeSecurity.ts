import { createHash, randomBytes } from "node:crypto";
import { PublicKey } from "@solana/web3.js";
import { ethers } from "ethers";
import { ENV } from "../_core/env";
import { redisSafe } from "../redis";

const CODE_PATTERN = /^[A-Z0-9][A-Z0-9_-]{5,31}$/;
const fallbackBuckets = new Map<string, { count: number; resetAt: number }>();
const fallbackLocks = new Set<string>();
const RELEASE_LOCK_SCRIPT = `if redis.call("get", KEYS[1]) == ARGV[1] then return redis.call("del", KEYS[1]) else return 0 end`;

export function normalizeGiftCode(value: string): string {
  const code = value.trim().toUpperCase();
  if (!CODE_PATTERN.test(code)) throw new Error("Invalid gift or referral code");
  return code;
}

export function hashGiftCode(value: string): string {
  return createHash("sha256").update(normalizeGiftCode(value), "utf8").digest("hex");
}

export function generateGiftCode(): string {
  return `GIFT-${randomBytes(10).toString("hex").toUpperCase()}`;
}

export function validateGiftRecipient(chainId: string, address: string): string {
  const value = address.trim();
  switch (chainId) {
    case "ethereum":
    case "bsc":
    case "polygon":
    case "arbitrum":
      if (!ethers.isAddress(value)) throw new Error("Invalid EVM recipient wallet address");
      return ethers.getAddress(value);
    case "solana":
      try {
        return new PublicKey(value).toBase58();
      } catch {
        throw new Error("Invalid Solana recipient wallet address");
      }
    case "bitcoin":
      if (!/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{20,90}$/.test(value)) throw new Error("Invalid Bitcoin recipient wallet address");
      return value;
    default:
      throw new Error("Unsupported Gift Code network");
  }
}

export async function enforceGiftCodeRateLimit(scope: "create" | "redeem", identity: string): Promise<void> {
  const normalizedIdentity = identity.replace(/[^a-zA-Z0-9:._-]/g, "_").slice(0, 128);
  const key = `gift-code:${scope}:${normalizedIdentity}`;
  const windowSeconds = 60 * 60;
  const max = Math.max(1, Math.floor(ENV.giftCodeMaxAttemptsPerHour));
  const count = await redisSafe(async (client) => {
    const current = Number(await client.incr(key));
    if (current === 1) await client.expire(key, windowSeconds);
    return current;
  });
  if (count != null) {
    if (count > max) throw new Error("Gift Code rate limit exceeded; try again later");
    return;
  }

  const now = Date.now();
  const current = fallbackBuckets.get(key);
  if (!current || current.resetAt <= now) {
    fallbackBuckets.set(key, { count: 1, resetAt: now + windowSeconds * 1000 });
    return;
  }
  current.count += 1;
  if (current.count > max) throw new Error("Gift Code rate limit exceeded; try again later");
}

export async function withGiftCodeLock<T>(keySuffix: string, operation: () => Promise<T>): Promise<T> {
  const key = `gift-code-lock:${keySuffix.replace(/[^a-zA-Z0-9:._-]/g, "_").slice(0, 160)}`;
  const token = randomBytes(16).toString("hex");
  const acquired = await redisSafe(async (client) => (await client.set(key, token, "EX", 120, "NX")) === "OK");
  if (acquired === false) throw new Error("A Gift Code redemption is already being processed");
  if (acquired === null) {
    if (fallbackLocks.has(key)) throw new Error("A Gift Code redemption is already being processed");
    fallbackLocks.add(key);
  }
  try {
    return await operation();
  } finally {
    if (acquired === null) fallbackLocks.delete(key);
    else await redisSafe((client) => client.eval(RELEASE_LOCK_SCRIPT, 1, key, token).then(() => undefined));
  }
}

export function parseDecimalUnits(value: string, decimals: number): bigint {
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) throw new Error("Invalid asset decimals");
  const match = /^(?:0|[1-9]\d{0,37})(?:\.(\d{1,36}))?$/.exec(value.trim());
  if (!match || value === "0") throw new Error("Reward amount must be a positive decimal");
  const [whole, fraction = ""] = value.trim().split(".");
  if (fraction.length > decimals) throw new Error("Reward amount exceeds asset precision");
  const raw = `${whole}${fraction.padEnd(decimals, "0")}`.replace(/^0+(?=\d)/, "");
  return BigInt(raw || "0");
}
