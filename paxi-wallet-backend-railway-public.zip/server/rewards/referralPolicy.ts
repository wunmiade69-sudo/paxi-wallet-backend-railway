import { and, eq } from "drizzle-orm";
import { rewardPolicies, type RewardPolicy } from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";

export const REFERRAL_POLICY_KEY = "bsc-paxi-trading-referral-v1";

export const DEFAULT_REFERRAL_POLICY = {
  policyKey: REFERRAL_POLICY_KEY,
  network: "bsc",
  qualifyingAssetSymbol: "PAXI",
  qualifyingAssetAddress: null,
  minimumVolumeUsd: "20",
  rewardAssetSymbol: "WPAXI",
  rewardAssetNetwork: "bsc",
  rewardAmount: "150",
  minimumTradeUsd: "0",
  cooldownSeconds: 0,
  isActive: false,
  config: {
    qualifyingEventTypes: ["buy", "sell"],
    excludedEventTypes: ["send", "receive", "deposit", "withdrawal", "bridge"],
    activationRequiresVerifiedTokenAddress: true,
    activationRequiresVerifiedRewardPools: true,
  },
} as const;

function assertPolicy(policy: RewardPolicy): RewardPolicy {
  if (policy.network !== "bsc" || policy.rewardAssetNetwork !== "bsc") throw new Error("Referral policy must use BSC");
  if (policy.rewardAssetSymbol !== "WPAXI") throw new Error("Referral policy must reward WPAXI");
  if (!policy.qualifyingAssetAddress || !/^0x[0-9a-fA-F]{40}$/.test(policy.qualifyingAssetAddress)) throw new Error("Referral policy has no verified PAXI token address");
  if (!/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/.test(policy.minimumVolumeUsd) || policy.minimumVolumeUsd === "0") throw new Error("Referral policy minimum volume is invalid");
  if (!/^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/.test(policy.rewardAmount) || policy.rewardAmount === "0") throw new Error("Referral policy reward amount is invalid");
  if (!policy.isActive) throw new Error("Referral policy is not active");
  const config = policy.config && typeof policy.config === "object" ? policy.config as Record<string, unknown> : {};
  const trustedRouters = Array.isArray(config.trustedRouterAddresses) ? config.trustedRouterAddresses : [];
  const trustedPairs = Array.isArray(config.trustedPairAddresses) ? config.trustedPairAddresses : [];
  if (trustedRouters.length === 0 || trustedPairs.length === 0) throw new Error("Referral policy requires trusted BSC router and pair allowlists");
  return policy;
}

export async function getActiveReferralPolicy(): Promise<RewardPolicy> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [policy] = await db.select().from(rewardPolicies).where(and(eq(rewardPolicies.policyKey, REFERRAL_POLICY_KEY), eq(rewardPolicies.isActive, true))).limit(1);
  if (!policy) throw new Error("Verified referral reward policy is not active");
  return assertPolicy(policy);
}

export async function upsertReferralPolicy(patch: Partial<{
  qualifyingAssetAddress: string | null;
  minimumVolumeUsd: string;
  rewardAmount: string;
  isActive: boolean;
  minimumTradeUsd: string;
  cooldownSeconds: number;
  trustedRouterAddresses: string[];
  trustedPairAddresses: string[];
}> = {}): Promise<RewardPolicy> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const current = await db.select().from(rewardPolicies).where(eq(rewardPolicies.policyKey, REFERRAL_POLICY_KEY)).limit(1);
  const currentConfig = (current[0]?.config && typeof current[0].config === "object" ? current[0].config : {}) as Record<string, unknown>;
  const { trustedRouterAddresses, trustedPairAddresses, ...scalarPatch } = patch;
  const configPatch = {
    ...currentConfig,
    ...(trustedRouterAddresses ? { trustedRouterAddresses } : {}),
    ...(trustedPairAddresses ? { trustedPairAddresses } : {}),
  };
  if (!current[0]) {
    await db.insert(rewardPolicies).values({ ...DEFAULT_REFERRAL_POLICY, ...scalarPatch, config: configPatch });
  } else {
    await db.update(rewardPolicies).set({ ...scalarPatch, config: configPatch }).where(eq(rewardPolicies.id, current[0].id));
  }
  const [updated] = await db.select().from(rewardPolicies).where(eq(rewardPolicies.policyKey, REFERRAL_POLICY_KEY)).limit(1);
  if (!updated) throw new Error("Referral policy was not persisted");
  if (updated.isActive) assertPolicy(updated);
  return updated;
}
