import { and, desc, eq, gt, sql } from "drizzle-orm";
import {
  referrals,
  referralTradingVolume,
  type ReferralTradingVolume,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { getActiveReferralPolicy } from "./referralPolicy";
import { formatUsdMicros, meetsUsdThreshold, parseUsdMicros, sumUsd } from "./rewardMath";
import { verifyBscPaxiTrade } from "./referralTradingVerifier";
import { issueReferralReward } from "./rewardPoolService";

const DECIMAL_RE = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/;

function assertId(value: number, label: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`Invalid ${label}`);
}

export async function processConfirmedReferralTrade(params: { userOpenId: string; walletAddress: string; transactionHash: string; eventType: "buy" | "sell" }): Promise<void> {
  const db = await getDb();
  if (!db) return;
  const pending = await db.select({ id: referrals.id }).from(referrals).where(and(eq(referrals.inviteeOpenId, params.userOpenId), eq(referrals.status, "pending")));
  for (const referral of pending) {
    try {
      await recordVerifiedReferralTrade({ referralId: referral.id, userOpenId: params.userOpenId, walletAddress: params.walletAddress, transactionHash: params.transactionHash });
    } catch (error) {
      console.warn("[referral] confirmed trade did not qualify referral", { referralId: referral.id, eventType: params.eventType, reason: error instanceof Error ? error.message : "unknown error" });
    }
  }
}

export async function recordVerifiedReferralTrade(params: {
  referralId: number;
  userOpenId: string;
  walletAddress: string;
  transactionHash: string;
}): Promise<{ volume: ReferralTradingVolume; qualifyingVolumeUsd: string; qualified: boolean; reward?: { ledgerId: number; claimId: number; poolId: number } }> {
  assertId(params.referralId, "referral id");
  if (!params.userOpenId || params.userOpenId.length > 64) throw new Error("Invalid user identifier");
  const policy = await getActiveReferralPolicy();
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [referral] = await db.select().from(referrals).where(eq(referrals.id, params.referralId)).limit(1);
  if (!referral) throw new Error("Referral not found");
  if (referral.inviteeOpenId !== params.userOpenId) throw new Error("Only the referred wallet can submit qualifying volume");
  if (!["pending", "qualified"].includes(referral.status)) throw new Error("Referral is not eligible for trading verification");

  const verifiedTrade = await verifyBscPaxiTrade(params.transactionHash, params.walletAddress, policy);
  if (!DECIMAL_RE.test(verifiedTrade.volumeUsd) || parseUsdMicros(verifiedTrade.volumeUsd) <= 0n) throw new Error("Verified trade has invalid USD volume");
  if (parseUsdMicros(verifiedTrade.volumeUsd) < parseUsdMicros(policy.minimumTradeUsd)) throw new Error("Trade is below the configured minimum trade size");

  const cooldownMs = policy.cooldownSeconds * 1000;
  if (cooldownMs > 0) {
    const [recent] = await db.select({ id: referralTradingVolume.id }).from(referralTradingVolume).where(and(eq(referralTradingVolume.referralId, referral.id), eq(referralTradingVolume.userOpenId, params.userOpenId), eq(referralTradingVolume.riskStatus, "approved"), gt(referralTradingVolume.createdAt, new Date(Date.now() - cooldownMs)))).limit(1);
    if (recent) throw new Error("Trade is inside the referral qualification cooldown window");
  }

  const [existing] = await db.select().from(referralTradingVolume).where(and(eq(referralTradingVolume.transactionHash, verifiedTrade.transactionHash), eq(referralTradingVolume.eventType, verifiedTrade.eventType))).limit(1);
  if (existing) {
    return {
      volume: existing,
      qualifyingVolumeUsd: referral.qualifyingVolumeUsd,
      qualified: referral.status === "qualified",
    };
  }

  let volume: ReferralTradingVolume;
  try {
    const result = await db.insert(referralTradingVolume).values({
      referralId: referral.id,
      userOpenId: params.userOpenId,
      transactionHash: verifiedTrade.transactionHash,
      eventType: verifiedTrade.eventType,
      network: "bsc",
      pairAddress: verifiedTrade.pairAddress,
      qualifyingAssetAddress: verifiedTrade.qualifyingAssetAddress,
      volumeUsd: verifiedTrade.volumeUsd,
      verified: true,
      riskStatus: "approved",
      riskFlags: [],
      blockNumber: verifiedTrade.blockNumber,
      verifiedAt: new Date(),
    });
    const id = Number((result as unknown as { insertId?: number | string }).insertId);
    const [created] = await db.select().from(referralTradingVolume).where(eq(referralTradingVolume.id, id)).limit(1);
    if (!created) throw new Error("Verified trade volume was not persisted");
    volume = created;
  } catch (error) {
    const [concurrent] = await db.select().from(referralTradingVolume).where(and(eq(referralTradingVolume.transactionHash, verifiedTrade.transactionHash), eq(referralTradingVolume.eventType, verifiedTrade.eventType))).limit(1);
    if (!concurrent) throw error;
    volume = concurrent;
  }

  const rows = await db.select({ volumeUsd: referralTradingVolume.volumeUsd }).from(referralTradingVolume).where(and(eq(referralTradingVolume.referralId, referral.id), eq(referralTradingVolume.verified, true), eq(referralTradingVolume.riskStatus, "approved")));
  const qualifyingVolumeUsd = sumUsd(rows.map((row) => row.volumeUsd));
  await db.update(referrals).set({ qualifyingVolumeUsd }).where(and(eq(referrals.id, referral.id), eq(referrals.status, "pending")));

  const minimumReached = meetsUsdThreshold(qualifyingVolumeUsd, policy.minimumVolumeUsd);
  if (!minimumReached || referral.status === "qualified") {
    return { volume, qualifyingVolumeUsd, qualified: referral.status === "qualified" };
  }

  const reward = await issueReferralReward({ referralId: referral.id, qualifyingVolumeUsd, policy });
  return { volume, qualifyingVolumeUsd, qualified: true, reward };
}
