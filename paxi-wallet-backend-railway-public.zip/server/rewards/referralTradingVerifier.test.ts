import { describe, expect, it } from "vitest";
import { calculateDirectionalTradeAmounts } from "./referralTradingVerifier";

describe("referral trade directional amounts", () => {
  it("uses PAXI out and stablecoin in for buys", () => {
    const amounts = calculateDirectionalTradeAmounts({
      paxiIsToken0: true,
      stableIsToken0: false,
      paxiToWallet: true,
      amount0In: 0n,
      amount1In: 20n,
      amount0Out: 5n,
      amount1Out: 0n,
    });
    expect(amounts).toEqual({ paxiAmount: 5n, stablecoinAmount: 20n });
  });

  it("uses PAXI in and stablecoin out for sells", () => {
    const amounts = calculateDirectionalTradeAmounts({
      paxiIsToken0: true,
      stableIsToken0: false,
      paxiToWallet: false,
      amount0In: 5n,
      amount1In: 0n,
      amount0Out: 0n,
      amount1Out: 20n,
    });
    expect(amounts).toEqual({ paxiAmount: 5n, stablecoinAmount: 20n });
  });
});
