import { and, asc, eq } from "drizzle-orm";
import { ethers } from "ethers";
import { rewardClaims, rewardLedger, rewardPools, type RewardClaim } from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import { withEvmRpc } from "../chains/rpc";

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;

function affectedRows(result: unknown): number {
  return Number((result as { affectedRows?: number }).affectedRows ?? 0);
}

function topicAddress(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`).toLowerCase();
  } catch {
    return null;
  }
}

export async function listMyRewardClaims(userOpenId: string, limit = 100): Promise<RewardClaim[]> {
  if (!userOpenId || userOpenId.length > 64) throw new Error("Invalid user identifier");
  const db = await getReadDb();
  if (!db) return [];
  return db.select().from(rewardClaims).where(eq(rewardClaims.userOpenId, userOpenId)).orderBy(asc(rewardClaims.id)).limit(Math.min(Math.max(limit, 1), 200));
}

export async function finalizeRewardClaim(params: { userOpenId: string; claimId: number; txHash: string }): Promise<RewardClaim> {
  if (!params.userOpenId || params.userOpenId.length > 64) throw new Error("Invalid user identifier");
  if (!Number.isSafeInteger(params.claimId) || params.claimId <= 0 || !TX_HASH_RE.test(params.txHash)) throw new Error("Invalid claim or transaction hash");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [claim] = await db.select().from(rewardClaims).where(and(eq(rewardClaims.id, params.claimId), eq(rewardClaims.userOpenId, params.userOpenId))).limit(1);
  if (!claim) throw new Error("Reward claim not found");
  if (claim.status === "claimed") return claim;
  if (claim.status !== "claimable") throw new Error("Reward claim is not claimable");
  if (!claim.poolId) throw new Error("Reward claim has no source pool");
  const [pool] = await db.select().from(rewardPools).where(eq(rewardPools.id, claim.poolId)).limit(1);
  if (!pool?.verified || !pool.distributorAddress) throw new Error("Reward pool is not verified for claims");

  const { distributorBalance, receipt } = await withEvmRpc("bsc", async (rpcProvider) => {
    const tokenContract = new ethers.Contract(pool.tokenAddress, ["function balanceOf(address) view returns (uint256)"], rpcProvider);
    const claimUnits = ethers.parseUnits(claim.amount, pool.tokenDecimals);
    const [balance, confirmedReceipt] = await Promise.all([
      tokenContract.balanceOf(pool.distributorAddress) as Promise<bigint>,
      rpcProvider.getTransactionReceipt(params.txHash),
    ]);
    return { distributorBalance: balance, receipt: confirmedReceipt };
  });
  const claimUnits = ethers.parseUnits(claim.amount, pool.tokenDecimals);
  if (distributorBalance < claimUnits) {
    throw new Error("Reward pool distributor has insufficient funds remaining on-chain to cover this claim");
  }
  if (!receipt) throw new Error("Claim transaction is not confirmed");
  if (receipt.status !== 1) throw new Error("Claim transaction failed on-chain");

  const expectedToken = pool.tokenAddress.toLowerCase();
  const expectedDistributor = pool.distributorAddress.toLowerCase();
  const expectedUser = claim.recipientWalletAddress.toLowerCase();
  let paid = false;
  const minimumUnits = ethers.parseUnits(claim.amount, pool.tokenDecimals);
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() !== expectedToken || log.topics[0] !== TRANSFER_TOPIC) continue;
    const from = topicAddress(log.topics[1]);
    const to = topicAddress(log.topics[2]);
    if (from !== expectedDistributor || to !== expectedUser) continue;
    let amount: bigint;
    try {
      amount = BigInt(log.data);
    } catch {
      continue;
    }
    if (amount >= minimumUnits) {
      paid = true;
      break;
    }
  }
  if (!paid) throw new Error("Claim transaction does not show the configured distributor paying the required WPAXI amount");

  return db.transaction(async (tx) => {
    const claimUpdate = await tx.update(rewardClaims).set({ status: "claimed", txHash: params.txHash, claimedAt: new Date() }).where(and(eq(rewardClaims.id, claim.id), eq(rewardClaims.userOpenId, params.userOpenId), eq(rewardClaims.status, "claimable")));
    if (affectedRows(claimUpdate) !== 1) {
      const [current] = await tx.select().from(rewardClaims).where(eq(rewardClaims.id, claim.id)).limit(1);
      if (current?.status === "claimed") return current;
      throw new Error("Reward claim was finalized concurrently; reload and try again");
    }
    await tx.update(rewardLedger).set({ status: "claimed", claimedAt: new Date(), distributedAt: new Date() }).where(and(eq(rewardLedger.id, claim.rewardLedgerId), eq(rewardLedger.status, "claimable")));
    const [updated] = await tx.select().from(rewardClaims).where(eq(rewardClaims.id, claim.id)).limit(1);
    if (!updated) throw new Error("Reward claim disappeared after finalization");
    return updated;
  });
}
