import { describe, expect, it } from "vitest";
import { formatUsdMicros, meetsUsdThreshold, parseUsdMicros, sumUsd } from "./rewardMath";
import { PAXI_BSC_ADDRESS, REFERRAL_MINIMUM_VOLUME_USD, WPAXI_POOL_ADDRESSES, WPAXI_POOL_ALLOCATION, WPAXI_REWARD_AMOUNT, WPAXI_TOKEN_DECIMALS } from "./wpaxiConfig";

describe("WPAXI referral reward math", () => {
  it("qualifies exactly at the configured minimum", () => {
    expect(meetsUsdThreshold("20", REFERRAL_MINIMUM_VOLUME_USD)).toBe(true);
    expect(meetsUsdThreshold("19.999999", REFERRAL_MINIMUM_VOLUME_USD)).toBe(false);
  });

  it("sums multiple verified trades without binary floating-point drift", () => {
    expect(sumUsd(["0.10", "0.20", "19.70"])).toBe("20");
    expect(formatUsdMicros(parseUsdMicros("20.000001"))).toBe("20.000001");
  });

  it("rejects malformed or negative USD values", () => {
    expect(() => parseUsdMicros("-1")).toThrow();
    expect(() => parseUsdMicros("01")).toThrow();
    expect(() => parseUsdMicros("1.1234567")).toThrow();
  });
});

describe("confirmed WPAXI configuration", () => {
  it("uses the supplied PAXI qualifying token and four ordered 50M pools", () => {
    expect(PAXI_BSC_ADDRESS).toBe("0xeda04581461bc308e60052fe489e20c3f78d6e4e");
    expect(WPAXI_POOL_ADDRESSES).toHaveLength(4);
    expect(new Set(WPAXI_POOL_ADDRESSES).size).toBe(4);
    expect(WPAXI_POOL_ALLOCATION).toBe("50000000");
    expect(WPAXI_REWARD_AMOUNT).toBe("150");
    expect(WPAXI_TOKEN_DECIMALS).toBe(18);
  });
});
