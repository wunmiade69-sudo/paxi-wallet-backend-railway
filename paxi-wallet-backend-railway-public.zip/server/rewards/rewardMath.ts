const USD_SCALE = 1_000_000n;
const USD_RE = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/;

export function parseUsdMicros(value: string): bigint {
  if (!USD_RE.test(value)) throw new Error("Invalid USD decimal");
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * USD_SCALE + BigInt((fraction.padEnd(6, "0") || "0").slice(0, 6));
}

export function formatUsdMicros(value: bigint): string {
  if (value < 0n) throw new Error("USD amount cannot be negative");
  const whole = value / USD_SCALE;
  const fraction = (value % USD_SCALE).toString().padStart(6, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

export function meetsUsdThreshold(volumeUsd: string, thresholdUsd: string): boolean {
  return parseUsdMicros(volumeUsd) >= parseUsdMicros(thresholdUsd);
}

export function sumUsd(values: readonly string[]): string {
  return formatUsdMicros(values.reduce((total, value) => total + parseUsdMicros(value), 0n));
}
