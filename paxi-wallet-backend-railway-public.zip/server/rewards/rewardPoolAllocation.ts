import { and, asc, eq, sql } from "drizzle-orm";
import { ethers } from "ethers";
import { rewardPools, type RewardPool } from "../../drizzle/schema";
import { getDb } from "../db";

type Database = NonNullable<Awaited<ReturnType<typeof getDb>>>;
type TransactionCallback = Parameters<Database["transaction"]>[0];
export type RewardDbTransaction = TransactionCallback extends (tx: infer T, ...args: never[]) => unknown ? T : never;

function affectedRows(result: unknown): number {
  return Number((result as { affectedRows?: number }).affectedRows ?? 0);
}

function parseUnits(value: string, decimals: number): bigint {
  return ethers.parseUnits(value, decimals);
}

export interface PoolAllocation {
  pool: RewardPool;
  allocatedAmount: string;
  remainingAmount: string;
}

/**
 * Allocates one reward under a caller-owned database transaction. All eligible
 * pools are row-locked before inspection, so an exhausted active pool and the
 * next verified reserve pool are handled atomically without double allocation.
 */
export async function allocateFromVerifiedWpaxiPools(
  tx: RewardDbTransaction,
  params: { policyId?: number; tokenAddress?: string; rewardAmount: string },
): Promise<PoolAllocation> {
  await tx.execute(sql`
    SELECT id FROM rewardPools
    WHERE verified = 1
      AND status IN ('active', 'reserve')
      ${params.policyId ? sql`AND policyId = ${params.policyId}` : sql``}
      ${params.tokenAddress ? sql`AND tokenAddress = ${params.tokenAddress}` : sql``}
    ORDER BY priority ASC
    FOR UPDATE
  `);

  const conditions = [
    eq(rewardPools.verified, true),
    sql`${rewardPools.status} IN ('active', 'reserve')`,
  ];
  if (params.policyId) conditions.push(eq(rewardPools.policyId, params.policyId));
  if (params.tokenAddress) conditions.push(eq(rewardPools.tokenAddress, params.tokenAddress));
  const pools = await tx.select().from(rewardPools).where(and(...conditions)).orderBy(asc(rewardPools.priority));

  for (const pool of pools) {
    const rewardUnits = parseUnits(params.rewardAmount, pool.tokenDecimals);
    const remainingUnits = parseUnits(pool.remainingAmount, pool.tokenDecimals);
    if (remainingUnits < rewardUnits) {
      if (pool.status === "active") {
        await tx.update(rewardPools).set({ status: "exhausted" }).where(and(eq(rewardPools.id, pool.id), eq(rewardPools.status, "active")));
      }
      continue;
    }

    if (pool.status === "reserve") {
      // Explicitly deactivate any existing active pool for this policy first
      await tx.update(rewardPools)
        .set({ status: "reserve" })
        .where(and(
          eq(rewardPools.policyId, pool.policyId), 
          eq(rewardPools.status, "active")
        ));
        
      const promoted = await tx.update(rewardPools)
        .set({ status: "active" })
        .where(and(
          eq(rewardPools.id, pool.id), 
          eq(rewardPools.status, "reserve"), 
          eq(rewardPools.verified, true)
        ));
      if (affectedRows(promoted) !== 1) throw new Error("WPAXI reserve-pool promotion race; retry the reward");
    }

    const nextRemainingUnits = remainingUnits - rewardUnits;
    const nextRemaining = ethers.formatUnits(nextRemainingUnits, pool.tokenDecimals);
    const nextAllocated = ethers.formatUnits(parseUnits(pool.allocatedAmount, pool.tokenDecimals) + rewardUnits, pool.tokenDecimals);
    const updated = await tx.update(rewardPools).set({
      allocatedAmount: nextAllocated,
      remainingAmount: nextRemaining,
      status: nextRemaining === "0" ? "exhausted" : "active",
    }).where(and(eq(rewardPools.id, pool.id), eq(rewardPools.status, "active"), eq(rewardPools.remainingAmount, pool.remainingAmount)));
    if (affectedRows(updated) !== 1) throw new Error("WPAXI reward pool changed concurrently; retry the reward");

    return {
      pool: { ...pool, status: nextRemaining === "0" ? "exhausted" : "active", allocatedAmount: nextAllocated, remainingAmount: nextRemaining },
      allocatedAmount: nextAllocated,
      remainingAmount: nextRemaining,
    };
  }

  throw new Error("No verified WPAXI reward pool has enough remaining allocation");
}
