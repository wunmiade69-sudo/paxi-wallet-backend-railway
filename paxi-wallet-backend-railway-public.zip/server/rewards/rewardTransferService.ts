import { bscAdapter } from "../blockchain/adapters/bscAdapter";
import { ethereumAdapter } from "../blockchain/adapters/ethereumAdapter";
import { solanaAdapter } from "../blockchain/adapters/solanaAdapter";
import { tonAdapter } from "../blockchain/adapters/tonAdapter";
import type { GiftCodeTransferAdapter, GiftCodeTransferRequest, GiftCodeTransferResult } from "../blockchain/adapters/types";

const adapters: Record<string, GiftCodeTransferAdapter> = {
  bsc: bscAdapter,
  ethereum: ethereumAdapter,
  solana: solanaAdapter,
  ton: tonAdapter,
};

function adapterFor(network: string): GiftCodeTransferAdapter {
  const adapter = adapters[network.toLowerCase()];
  if (!adapter) throw new Error(`Gift Code fulfillment is not supported on ${network}`);
  return adapter;
}

export function isDirectGiftCodeFulfillmentSupported(network: string): boolean {
  return ["bsc", "ethereum", "solana"].includes(network.toLowerCase());
}

export async function transferGiftCodeReward(request: GiftCodeTransferRequest): Promise<GiftCodeTransferResult> {
  return adapterFor(request.network).transfer(request);
}

export async function verifyGiftCodeReward(request: GiftCodeTransferRequest & { transactionHash: string }): Promise<GiftCodeTransferResult> {
  return adapterFor(request.network).verify(request);
}
