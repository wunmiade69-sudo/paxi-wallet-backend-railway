export const PAXI_BSC_ADDRESS = "0xeda04581461bc308e60052fe489e20c3f78d6e4e" as const;

export const WPAXI_POOL_ADDRESSES = [
  "0x093b86bcbaf0a723e4bd4a4922a9f986a25c6b52",
  "0xed806ccd5958fe1926402a28748e5ffa2bad2239",
  "0x6229aa83a83c04347a663e77c3ed3d3cd1530fb8",
  "0x1df8d99d2118f76d88c4f46317b03cf4b1ef5592",
] as const;

export const WPAXI_POOL_ALLOCATION = "50000000" as const;
export const WPAXI_TOKEN_DECIMALS = 18 as const;
export const WPAXI_REWARD_AMOUNT = "150" as const;
export const REFERRAL_MINIMUM_VOLUME_USD = "20" as const;
