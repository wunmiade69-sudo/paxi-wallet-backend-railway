import { TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { PublicKey } from "@solana/web3.js";
import { describe, expect, it } from "vitest";
import { classifySolanaMintAccount } from "./riskEngine";

function mintData(
  options: {
    mintAuthorityRevoked?: boolean;
    freezeAuthorityRevoked?: boolean;
  } = {}
) {
  const data = new Uint8Array(82);
  const view = new DataView(data.buffer);
  view.setUint32(0, options.mintAuthorityRevoked === false ? 1 : 0, true);
  view.setUint32(46, options.freezeAuthorityRevoked === false ? 1 : 0, true);
  return data;
}

describe("classifySolanaMintAccount", () => {
  it("accepts a classic SPL Token mint", () => {
    expect(
      classifySolanaMintAccount({ owner: TOKEN_PROGRAM_ID, data: mintData() })
    ).toMatchObject({
      program: "classic",
      supported: true,
      mintAuthorityRevoked: true,
      freezeAuthorityRevoked: true,
    });
  });

  it("accepts a Token-2022 mint using the canonical SDK owner", () => {
    expect(
      classifySolanaMintAccount({
        owner: TOKEN_2022_PROGRAM_ID,
        data: mintData({ mintAuthorityRevoked: false }),
      })
    ).toMatchObject({
      program: "token-2022",
      supported: true,
      mintAuthorityRevoked: false,
      freezeAuthorityRevoked: true,
    });
  });

  it("rejects an unsupported account owner", () => {
    expect(
      classifySolanaMintAccount({ owner: PublicKey.unique(), data: mintData() })
    ).toMatchObject({
      program: "unsupported",
      supported: false,
    });
  });

  it("rejects malformed mint account data", () => {
    expect(
      classifySolanaMintAccount({
        owner: TOKEN_PROGRAM_ID,
        data: new Uint8Array(81),
      })
    ).toMatchObject({
      program: "malformed",
      supported: false,
    });
  });

  it("fails closed when account information is unavailable", () => {
    expect(classifySolanaMintAccount(null)).toMatchObject({
      program: "unknown",
      supported: false,
    });
  });
});
