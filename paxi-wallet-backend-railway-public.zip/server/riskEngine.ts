import { Connection, PublicKey } from "@solana/web3.js";
import { and, eq } from "drizzle-orm";
import { assetMetadata, assets, securityReports } from "../drizzle/schema";
import { getDb } from "./db";
import { UNSUPPORTED_REPORT, type ContractSecurityReport } from "./contractSecurity";
import { withRpcHttp } from "./chains/rpc";
import { orchestratedLiquidity, orchestratedSecurity } from "./providers";
import { normalizeMarketChain } from "./marketProviders";

export type RiskLabel = "verified" | "unverified" | "risky" | "scam_suspicious";

export interface AssetRiskReport {
  label: RiskLabel;
  score: number | null;
  provider: string;
  checks: Record<string, boolean | number | string | null>;
  checkedAt: Date;
}


function evmRisk(report: ContractSecurityReport): AssetRiskReport {
  const label: RiskLabel =
    report.checks.noHoneypot === false ? "scam_suspicious" : report.status === "high-risk" ? "risky" : report.status === "safe" ? "verified" : "unverified";
  return {
    label,
    score: report.score,
    provider: "goplus",
    checks: {
      ...report.checks,
      buyTaxPercent: report.buyTaxPercent,
      sellTaxPercent: report.sellTaxPercent,
      holderCount: report.holderCount,
    },
    checkedAt: new Date(),
  };
}

async function solanaRisk(mintAddress: string): Promise<AssetRiskReport> {
  try {
    const mint = new PublicKey(mintAddress);
    const account = await withRpcHttp("solana", (endpoint) => new Connection(endpoint, "confirmed").getAccountInfo(mint));
    if (!account) throw new Error("Solana mint account not found");
    const owner = account.owner.toBase58();
    const tokenProgramOwners = new Set([
      "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
      "TokenzQdBNbR2GxxHn7vZ4mA5w1XxF6YbJr9t8d7c6b5",
    ]);
    if (!tokenProgramOwners.has(owner)) throw new Error("Account is not owned by a supported Solana token program");
    if (account.data.length < 82) throw new Error("Solana mint account data is truncated");
    const data = account.data instanceof Uint8Array ? account.data : new Uint8Array(account.data);
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    const mintAuthorityOption = view.getUint32(0, true);
    const freezeAuthorityOption = view.getUint32(46, true);
    const mintAuthorityRevoked = mintAuthorityOption === 0;
    const freezeAuthorityRevoked = freezeAuthorityOption === 0;
    let holderConcentrationPercent: number | null = null;
    let holderConcentrationChecked = false;
    try {
      const [largest, supply] = await withRpcHttp("solana", (endpoint) => {
        const connection = new Connection(endpoint, "confirmed");
        return Promise.all([connection.getTokenLargestAccounts(mint), connection.getTokenSupply(mint)]);
      });
      const total = BigInt(supply.value.amount);
      const topTen = largest.value.slice(0, 10).reduce((sum, holder) => sum + BigInt(holder.amount), 0n);
      if (total > 0n) {
        holderConcentrationPercent = Number((topTen * 10_000n) / total) / 100;
        holderConcentrationChecked = true;
      }
    } catch (err) {
      console.warn(`[risk-engine] Solana holder check failed for ${mintAddress}:`, err);
    }

    let liquidityUsd: number | null = null;
    let liquidityChecked = false;
    try {
      const liquidity = await orchestratedLiquidity({ chain: "solana", contractAddress: mintAddress });
      const pair = liquidity.value?.pair ?? null;
      liquidityUsd = pair?.liquidity?.usd != null ? Number(pair.liquidity.usd) : null;
      liquidityChecked = pair !== null;
    } catch (err) {
      console.warn(`[risk-engine] Solana liquidity check failed for ${mintAddress}:`, err);
    }

    let score = 0;
    score += mintAuthorityRevoked ? 35 : 15;
    score += freezeAuthorityRevoked ? 25 : 5;
    if (holderConcentrationPercent == null) score += 0;
    else if (holderConcentrationPercent <= 20) score += 25;
    else if (holderConcentrationPercent <= 50) score += 12;
    if (liquidityUsd != null && liquidityUsd >= 10_000) score += 15;
    else if (liquidityUsd != null && liquidityUsd >= 1_000) score += 8;

    const hasKnownRisk = !mintAuthorityRevoked || !freezeAuthorityRevoked || (holderConcentrationPercent != null && holderConcentrationPercent > 50) || (liquidityUsd != null && liquidityUsd < 1_000);
    const metadataChecked = false;
    const hasUnknownChecks = !holderConcentrationChecked || !liquidityChecked || !metadataChecked;
    const label: RiskLabel = hasKnownRisk ? "risky" : hasUnknownChecks ? "unverified" : score >= 75 ? "verified" : "unverified";
    return {
      label,
      score,
      provider: "solana-rpc+dexscreener",
      checks: {
        mintAuthorityRevoked,
        freezeAuthorityRevoked,
        holderConcentrationChecked,
        holderConcentrationPercent,
        liquidityChecked,
        liquidityUsd,
        metadataChecked: false,
      },
      checkedAt: new Date(),
    };
  } catch (err) {
    console.warn(`[risk-engine] Solana risk check failed for ${mintAddress}:`, err);
    return {
      label: "unverified",
      score: null,
      provider: "solana-rpc",
      checks: { rpcCheckFailed: true, error: err instanceof Error ? err.message : "unknown" },
      checkedAt: new Date(),
    };
  }
}

export async function assessAssetRisk(network: string, identifier: string): Promise<AssetRiskReport> {
  if (["ethereum", "bsc", "polygon", "arbitrum"].includes(network)) {
    const chain = normalizeMarketChain(network);
    const security = chain ? await orchestratedSecurity({ chain, contractAddress: identifier }) : null;
    return evmRisk(security?.value?.report ?? UNSUPPORTED_REPORT);
  }
  if (network === "solana") return solanaRisk(identifier);
  return {
    label: "unverified",
    score: null,
    provider: "unsupported",
    checks: { supportedChain: false },
    checkedAt: new Date(),
  };
}

export async function persistAssetRisk(assetId: number, network: string, identifier: string): Promise<AssetRiskReport> {
  const report = await assessAssetRisk(network, identifier);
  const db = await getDb();
  if (!db) return report;

  const values = {
    assetId,
    label: report.label,
    score: report.score,
    checks: report.checks,
    provider: report.provider,
    checkedAt: report.checkedAt,
    updatedAt: report.checkedAt,
  } as const;
  await db.insert(securityReports).values(values).onDuplicateKeyUpdate({ set: values });
  await db
    .insert(assetMetadata)
    .values({ assetId, riskScore: report.score })
    .onDuplicateKeyUpdate({ set: { riskScore: report.score } });
  return report;
}

export async function getPersistedAssetRisk(network: string, identifier: string) {
  const db = await getDb();
  if (!db) return null;
  const [asset] = await db
    .select({ id: assets.id })
    .from(assets)
    .where(and(eq(assets.chainId, network), eq(assets.identifier, identifier)))
    .limit(1);
  if (!asset) return null;
  const [report] = await db.select().from(securityReports).where(eq(securityReports.assetId, asset.id)).limit(1);
  return report ?? null;
}
