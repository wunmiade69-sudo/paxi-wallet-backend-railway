import { TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { Connection, PublicKey } from "@solana/web3.js";
import { and, eq } from "drizzle-orm";
import { assetMetadata, assets, securityReports } from "../drizzle/schema";
import { getDb } from "./db";
import {
  getContractSecurity,
  type ContractSecurityReport,
} from "./contractSecurity";
import { getCircuitBreaker } from "./resilience/circuitBreaker";

export type RiskLabel = "verified" | "unverified" | "risky" | "scam_suspicious";

export interface AssetRiskReport {
  label: RiskLabel;
  score: number | null;
  provider: string;
  checks: Record<string, boolean | number | string | null>;
  checkedAt: Date;
}

const solanaConnection = new Connection(
  "https://solana-rpc.publicnode.com",
  "confirmed"
);
const solanaRpcBreaker = getCircuitBreaker("solana-rpc", {
  failureThreshold: 5,
  resetTimeoutMs: 30_000,
});
const solanaDexBreaker = getCircuitBreaker("dexscreener-solana-risk", {
  failureThreshold: 5,
  resetTimeoutMs: 30_000,
});

function evmRisk(report: ContractSecurityReport): AssetRiskReport {
  const label: RiskLabel =
    report.checks.noHoneypot === false
      ? "scam_suspicious"
      : report.status === "high-risk"
        ? "risky"
        : report.status === "safe"
          ? "verified"
          : "unverified";
  return {
    label,
    score: report.score,
    provider: "goplus",
    checks: {
      ...report.checks,
      buyTaxPercent: report.buyTaxPercent,
      sellTaxPercent: report.sellTaxPercent,
      holderCount: report.holderCount,
    },
    checkedAt: new Date(),
  };
}

export type SolanaMintProgram =
  "classic" | "token-2022" | "unsupported" | "malformed" | "unknown";

export interface SolanaMintClassification {
  program: SolanaMintProgram;
  supported: boolean;
  mintAuthorityRevoked: boolean | null;
  freezeAuthorityRevoked: boolean | null;
  reason?: string;
}

/**
 * Classify a mint account using the canonical SPL Token program identifiers.
 * This stays pure so unsupported, malformed, and unavailable account states can
 * be tested without contacting an RPC provider.
 */
export function classifySolanaMintAccount(
  account: { owner: PublicKey; data: Uint8Array } | null | undefined
): SolanaMintClassification {
  if (!account) {
    return {
      program: "unknown",
      supported: false,
      mintAuthorityRevoked: null,
      freezeAuthorityRevoked: null,
      reason: "Solana mint account information is unavailable",
    };
  }

  const program = account.owner.equals(TOKEN_PROGRAM_ID)
    ? "classic"
    : account.owner.equals(TOKEN_2022_PROGRAM_ID)
      ? "token-2022"
      : "unsupported";
  if (program === "unsupported") {
    return {
      program,
      supported: false,
      mintAuthorityRevoked: null,
      freezeAuthorityRevoked: null,
      reason: "Account is not owned by a supported Solana token program",
    };
  }

  if (account.data.byteLength < 82) {
    return {
      program: "malformed",
      supported: false,
      mintAuthorityRevoked: null,
      freezeAuthorityRevoked: null,
      reason: "Solana mint account data is truncated",
    };
  }

  const data =
    account.data instanceof Uint8Array
      ? account.data
      : new Uint8Array(account.data);
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  return {
    program,
    supported: true,
    mintAuthorityRevoked: view.getUint32(0, true) === 0,
    freezeAuthorityRevoked: view.getUint32(46, true) === 0,
  };
}

async function solanaRisk(mintAddress: string): Promise<AssetRiskReport> {
  try {
    const mint = new PublicKey(mintAddress);
    const account = await solanaRpcBreaker.execute(() =>
      solanaConnection.getAccountInfo(mint)
    );
    if (!account) throw new Error("Solana mint account not found");
    const classification = classifySolanaMintAccount(account);
    if (!classification.supported)
      throw new Error(
        classification.reason ?? "Solana mint account is not supported"
      );
    const { mintAuthorityRevoked, freezeAuthorityRevoked } = classification;
    if (mintAuthorityRevoked == null || freezeAuthorityRevoked == null)
      throw new Error("Solana mint authority information is unavailable");
    let holderConcentrationPercent: number | null = null;
    let holderConcentrationChecked = false;
    try {
      const [largest, supply] = await solanaRpcBreaker.execute(() =>
        Promise.all([
          solanaConnection.getTokenLargestAccounts(mint),
          solanaConnection.getTokenSupply(mint),
        ])
      );
      const total = BigInt(supply.value.amount);
      const topTen = largest.value
        .slice(0, 10)
        .reduce((sum, holder) => sum + BigInt(holder.amount), 0n);
      if (total > 0n) {
        holderConcentrationPercent = Number((topTen * 10_000n) / total) / 100;
        holderConcentrationChecked = true;
      }
    } catch (err) {
      console.warn(
        `[risk-engine] Solana holder check failed for ${mintAddress}:`,
        err
      );
    }

    let liquidityUsd: number | null = null;
    let liquidityChecked = false;
    try {
      const response = await solanaDexBreaker.execute(() =>
        fetch(
          `https://api.dexscreener.com/latest/dex/tokens/${encodeURIComponent(mintAddress)}`,
          { signal: AbortSignal.timeout(8_000) }
        )
      );
      if (!response.ok)
        throw new Error(`DexScreener returned ${response.status}`);
      const data = await response.json();
      const solanaPairs = (data.pairs ?? []).filter(
        (pair: { chainId?: string }) => pair.chainId === "solana"
      );
      liquidityUsd = solanaPairs.reduce(
        (max: number, pair: { liquidity?: { usd?: number } }) =>
          Math.max(max, Number(pair.liquidity?.usd ?? 0)),
        0
      );
      liquidityChecked = true;
    } catch (err) {
      console.warn(
        `[risk-engine] Solana liquidity check failed for ${mintAddress}:`,
        err
      );
    }

    let score = 0;
    score += mintAuthorityRevoked ? 35 : 15;
    score += freezeAuthorityRevoked ? 25 : 5;
    if (holderConcentrationPercent == null) score += 0;
    else if (holderConcentrationPercent <= 20) score += 25;
    else if (holderConcentrationPercent <= 50) score += 12;
    if (liquidityUsd != null && liquidityUsd >= 10_000) score += 15;
    else if (liquidityUsd != null && liquidityUsd >= 1_000) score += 8;

    const hasKnownRisk =
      !mintAuthorityRevoked ||
      !freezeAuthorityRevoked ||
      (holderConcentrationPercent != null && holderConcentrationPercent > 50) ||
      (liquidityUsd != null && liquidityUsd < 1_000);
    const metadataChecked = false;
    const hasUnknownChecks =
      !holderConcentrationChecked || !liquidityChecked || !metadataChecked;
    const label: RiskLabel = hasKnownRisk
      ? "risky"
      : hasUnknownChecks
        ? "unverified"
        : score >= 75
          ? "verified"
          : "unverified";
    return {
      label,
      score,
      provider: "solana-rpc+dexscreener",
      checks: {
        mintAuthorityRevoked,
        freezeAuthorityRevoked,
        holderConcentrationChecked,
        holderConcentrationPercent,
        liquidityChecked,
        liquidityUsd,
        metadataChecked: false,
        tokenProgram: classification.program,
      },
      checkedAt: new Date(),
    };
  } catch (err) {
    console.warn(
      `[risk-engine] Solana risk check failed for ${mintAddress}:`,
      err
    );
    return {
      label: "unverified",
      score: null,
      provider: "solana-rpc",
      checks: {
        rpcCheckFailed: true,
        error: err instanceof Error ? err.message : "unknown",
      },
      checkedAt: new Date(),
    };
  }
}

export async function assessAssetRisk(
  network: string,
  identifier: string
): Promise<AssetRiskReport> {
  if (["ethereum", "bsc", "polygon", "arbitrum"].includes(network)) {
    return evmRisk(await getContractSecurity(network, identifier));
  }
  if (network === "solana") return solanaRisk(identifier);
  return {
    label: "unverified",
    score: null,
    provider: "unsupported",
    checks: { supportedChain: false },
    checkedAt: new Date(),
  };
}

export async function persistAssetRisk(
  assetId: number,
  network: string,
  identifier: string
): Promise<AssetRiskReport> {
  const report = await assessAssetRisk(network, identifier);
  const db = await getDb();
  if (!db) return report;

  const values = {
    assetId,
    label: report.label,
    score: report.score,
    checks: report.checks,
    provider: report.provider,
    checkedAt: report.checkedAt,
    updatedAt: report.checkedAt,
  } as const;
  await db
    .insert(securityReports)
    .values(values)
    .onDuplicateKeyUpdate({ set: values });
  await db
    .insert(assetMetadata)
    .values({ assetId, riskScore: report.score })
    .onDuplicateKeyUpdate({ set: { riskScore: report.score } });
  return report;
}

export async function getPersistedAssetRisk(
  network: string,
  identifier: string
) {
  const db = await getDb();
  if (!db) return null;
  const [asset] = await db
    .select({ id: assets.id })
    .from(assets)
    .where(and(eq(assets.chainId, network), eq(assets.identifier, identifier)))
    .limit(1);
  if (!asset) return null;
  const [report] = await db
    .select()
    .from(securityReports)
    .where(eq(securityReports.assetId, asset.id))
    .limit(1);
  return report ?? null;
}
