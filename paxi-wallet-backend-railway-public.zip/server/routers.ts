import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { campaignsRouter } from "./routers/campaigns";
import { listingsRouter } from "./routers/listings";
import { securityRouter } from "./routers/security";
import { marketRouter } from "./routers/market";
import { activityRouter } from "./routers/activity";
import { feesRouter } from "./routers/fees";
import { campaignSnapshotsRouter } from "./routers/campaignSnapshots";
import { referralsRouter } from "./routers/referrals";
import { giftCodesRouter } from "./routers/giftCodes";
import { rewardsRouter } from "./routers/rewards";
import { eligibilityRouter } from "./routers/eligibility";
import { airdropsRouter } from "./routers/airdrops";
import { rewardPoolsRouter } from "./routers/rewardPools";
import { adminRouter } from "./routers/admin";
import { bridgeRouter } from "./routers/bridge";
import { swapRouter } from "./routers/swap";
import { walletLinkRouter } from "./routers/walletLink";
import { getUsdFiatRates } from "./currency";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  listings: listingsRouter,
  campaigns: campaignsRouter,
  security: securityRouter,
  market: marketRouter,
  activity: activityRouter,
  fees: feesRouter,
  campaignSnapshots: campaignSnapshotsRouter,
  referrals: referralsRouter,
  giftCodes: giftCodesRouter,
  rewards: rewardsRouter,
  eligibility: eligibilityRouter,
  airdrops: airdropsRouter,
  rewardPools: rewardPoolsRouter,
  admin: adminRouter,
  bridge: bridgeRouter,
  swap: swapRouter,
  walletLink: walletLinkRouter,
  currency: router({
    usdRates: publicProcedure.query(() => getUsdFiatRates()),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
