import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  exportActivityForEligibility,
  getActivityStats,
  listActivityHistory,
} from "../activity/activityService";
import { recordVerifiedTransaction } from "../wallet/transactionService";

export const activityRouter = router({
  recordVerifiedTransaction: protectedProcedure
    .input(
      z.object({
        walletAddress: z.string().trim().min(1).max(128),
        chainId: z.string().trim().regex(/^[A-Za-z0-9._:-]{1,32}$/),
        transactionHash: z.string().trim().regex(/^0x[0-9a-fA-F]{64}$/),
      }),
    )
    .mutation(({ ctx, input }) =>
      recordVerifiedTransaction(ctx.user.openId, {
        walletAddress: input.walletAddress,
        chainId: input.chainId,
        transactionHash: input.transactionHash,
      }),
    ),

  myStats: protectedProcedure.query(({ ctx }) => getActivityStats(ctx.user.openId)),

  myHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().int().min(1).max(100).optional(),
        cursor: z.string().regex(/^\d{1,16}$/).optional(),
      }).optional(),
    )
    .query(({ ctx, input }) => listActivityHistory(ctx.user.openId, input ?? {})),

  eligibilityExport: protectedProcedure.query(({ ctx }) => exportActivityForEligibility(ctx.user.openId)),
});
