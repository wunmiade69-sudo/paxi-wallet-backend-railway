import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import type { TrpcContext } from "../_core/context";
import { adminRouter } from "./admin";

function contextFor(role: "user" | "admin", adminRole?: string): TrpcContext {
  return {
    user: {
      id: 1,
      openId: `${role}-audit-test`,
      name: "PAXI test user",
      email: null,
      loginMethod: "test",
      role,
      adminRole: adminRole as any,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("PAXI Admin workspace authorization", () => {
  it("blocks ordinary authenticated users from the administrator audit ledger", async () => {
    const caller = adminRouter.createCaller(contextFor("user"));
    await expect(caller.auditEvents()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("does not let support or content administrators enter system management or approval execution", async () => {
    const support = adminRouter.createCaller(contextFor("admin", "support_admin"));
    const content = adminRouter.createCaller(contextFor("admin", "content_admin"));
    await expect(support.me()).resolves.toMatchObject({ role: "support_admin" });
    await expect(content.me()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(support.featureFlags.upsert({ key: "test.flag", enabled: true, reason: "separation boundary test" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(content.featureFlags.upsert({ key: "test.flag", enabled: true, reason: "separation boundary test" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(support.approvals.execute({ id: 1, reason: "separation boundary test" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("keeps the executable approval action set explicitly whitelisted", () => {
    const source = readFileSync(new URL("./admin.ts", import.meta.url), "utf8");
    expect(source).toContain('z.enum(["user.suspend", "user.restore", "user.role_change", "asset.status_change", "asset.verification_change"])');
    expect(source).not.toContain("transaction.broadcast");
    expect(source).not.toContain("wallet.sign");
    expect(source).toContain("The requester cannot execute the same high-risk request");
    expect(source).toContain("The approver cannot execute the same high-risk request");
  });

  it("keeps credentials and signing material out of the Admin API and UI source", () => {
    const api = readFileSync(new URL("./admin.ts", import.meta.url), "utf8");
    const ui = readFileSync(new URL("../../client/src/pages/AdminScreen.tsx", import.meta.url), "utf8");
    for (const source of [api, ui]) {
      expect(source).not.toMatch(/PRIVATE_KEY|MNEMONIC|SEED_PHRASE|JWT_SECRET|DATABASE_URL|REDIS_URL|API_KEY|privateKey|mnemonic|seedPhrase|signingKey/);
    }
  });

  it("keeps the dedicated admin entry addressable through /admin", () => {
    const server = readFileSync(new URL("../_core/vite.ts", import.meta.url), "utf8");
    const entry = readFileSync(new URL("../../client/src/admin-main.tsx", import.meta.url), "utf8");
    expect(server).toContain('requestPath === "/admin"');
    expect(server).toContain('app.get(["/admin", "/admin/"]');
    expect(server).toContain('"admin.html"');
    expect(entry).toContain('AdminScreen');
    expect(entry).not.toContain('AdminWorkspace');
  });

  it("keeps the unapplied SQL artifact aligned with Phase 4 schema additions", () => {
    const schema = readFileSync(new URL("../../drizzle/schema.ts", import.meta.url), "utf8");
    const sql = readFileSync(new URL("../../drizzle/phase4_admin_console.sql", import.meta.url), "utf8");
    for (const field of ["actorRole", "result", "reason", "previousState", "newState", "requestMetadata"]) {
      expect(schema).toContain(`${field}:`);
      expect(sql).toContain(`\`${field}\``);
    }
    expect(schema).toContain("executedByOpenId");
    expect(sql).toContain("`executedByOpenId`");
    expect(sql).toContain("REVIEW ONLY");
  });
});
