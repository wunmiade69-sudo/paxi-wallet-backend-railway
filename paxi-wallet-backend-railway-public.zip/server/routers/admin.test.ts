import { describe, expect, it } from "vitest";
import type { TrpcContext } from "../_core/context";
import { adminRouter } from "./admin";

function contextFor(role: "user" | "admin"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: `${role}-audit-test`,
      name: "PAXI test user",
      email: null,
      loginMethod: "test",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("PAXI Admin workspace authorization", () => {
  it("blocks ordinary authenticated users from the administrator audit ledger", async () => {
    const caller = adminRouter.createCaller(contextFor("user"));
    await expect(caller.auditEvents()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
