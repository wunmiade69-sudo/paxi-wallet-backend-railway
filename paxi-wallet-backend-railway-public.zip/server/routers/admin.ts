import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { adminAuditEvents } from "../../drizzle/schema";
import { getDb } from "../db";
import { adminProcedure, router } from "../_core/trpc";
import {
  addSupportMessage,
  getSupportTicketForAdmin,
  listSupportTickets,
  updateSupportTicket,
} from "../support/supportService";
import { getProviderHealth } from "../providers/health";

/**
 * Privileged-only operational data for the independently addressable PAXI Admin workspace.
 * Sensitive writes remain in their feature routers and are protected server-side by adminProcedure.
 */
export const adminRouter = router({
  providerHealth: adminProcedure.query(() => getProviderHealth()),

  auditEvents: adminProcedure
    .input(
      z
        .object({
          limit: z.number().int().min(1).max(200).default(100),
          resourceType: z.string().trim().max(48).optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const limit = input?.limit ?? 100;
      const query = db.select().from(adminAuditEvents);
      const rows = input?.resourceType
        ? await query
            .where(eq(adminAuditEvents.resourceType, input.resourceType))
            .orderBy(desc(adminAuditEvents.createdAt))
            .limit(limit)
        : await query.orderBy(desc(adminAuditEvents.createdAt)).limit(limit);
      return rows;
    }),

  supportTickets: adminProcedure
    .input(
      z
        .object({
          status: z
            .enum([
              "OPEN",
              "IN_REVIEW",
              "WAITING_FOR_USER",
              "RESOLVED",
              "CLOSED",
            ])
            .optional(),
          limit: z.number().int().min(1).max(200).default(100),
        })
        .optional()
    )
    .query(({ input }) => listSupportTickets(input)),

  supportTicket: adminProcedure
    .input(z.object({ ticketKey: z.string().trim().min(1).max(32) }))
    .query(({ input }) => getSupportTicketForAdmin(input.ticketKey)),

  updateSupportTicket: adminProcedure
    .input(
      z.object({
        ticketKey: z.string().trim().min(1).max(32),
        status: z
          .enum(["OPEN", "IN_REVIEW", "WAITING_FOR_USER", "RESOLVED", "CLOSED"])
          .optional(),
        priority: z.enum(["LOW", "NORMAL", "HIGH", "URGENT"]).optional(),
        assignedToOpenId: z.string().trim().max(64).nullable().optional(),
      })
    )
    .mutation(({ ctx, input }) =>
      updateSupportTicket({ ...input, actorOpenId: ctx.user.openId })
    ),

  replyToSupportTicket: adminProcedure
    .input(
      z.object({
        ticketKey: z.string().trim().min(1).max(32),
        body: z.string().trim().min(1).max(8_000),
        clientMessageKey: z.string().trim().max(96).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const ticket = await getSupportTicketForAdmin(input.ticketKey);
      if (!ticket) throw new Error("Support ticket not found");
      return addSupportMessage({
        ticketId: ticket.ticket.id,
        authorType: "SUPPORT",
        authorOpenId: ctx.user.openId,
        body: input.body,
        clientMessageKey: input.clientMessageKey,
      });
    }),
});
