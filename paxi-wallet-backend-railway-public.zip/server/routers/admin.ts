import { and, count, desc, eq, like, or } from "drizzle-orm";
import { z } from "zod";
import {
  activityEvents,
  adminAnnouncements,
  adminApprovalRequests,
  adminAuditEvents,
  adminFeatureFlags,
  assets,
  assetMetadata,
  assetMarketData,
  campaigns,
  campaignEntries,
  feeRecords,
  securityReports,
  users,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { recordAdminAudit } from "../adminAudit";
import { getAdminRole, hasAdminPermission, permissionsForAdminRole, type AdminPermission } from "../adminRbac";
import { getRedisHealth } from "../redis";
import { ENV } from "../_core/env";
import { adminPermissionProcedure, router } from "../_core/trpc";

const optionalLimit = z.number().int().min(1).max(200).default(100);
const resourceType = z.string().trim().min(1).max(48);
const approvalAction = z.enum(["user.suspend", "user.restore", "user.role_change", "asset.status_change", "asset.verification_change"]);


async function scalarCount(db: Awaited<ReturnType<typeof getDb>>, table: any): Promise<number> {
  if (!db) return 0;
  const [row] = await db.select({ value: count() }).from(table);
  return Number(row?.value ?? 0);
}

export const adminRouter = router({
  me: adminPermissionProcedure("system.read").query(({ ctx }) => {
    const role = getAdminRole(ctx.user);
    return {
      openId: ctx.user.openId,
      name: ctx.user.name,
      email: ctx.user.email,
      role,
      permissions: role ? permissionsForAdminRole(role) : ([] as readonly AdminPermission[]),
    };
  }),

  dashboard: adminPermissionProcedure("system.read").query(async () => {
    const db = await getDb();
    const redisStatus = await getRedisHealth();
    if (!db) {
      return {
        available: false,
        message: "Database unavailable; operational metrics are not available.",
        counts: null,
        infrastructure: {
          database: "unavailable" as const,
          redis: redisStatus,
          workers: ENV.workersEnabled ? "enabled" : "disabled",
        },
      };
    }
    const [usersCount, assetsCount, activityCount, auditCount, securityCount, campaignsCount, pendingEntries] = await Promise.all([
      scalarCount(db, users),
      scalarCount(db, assets),
      scalarCount(db, activityEvents),
      scalarCount(db, adminAuditEvents),
      scalarCount(db, securityReports),
      scalarCount(db, campaigns),
      db.select({ value: count() }).from(campaignEntries).where(eq(campaignEntries.payoutStatus, "claimable")),
    ]);
    return {
      available: true,
      message: "Counts are read from durable database tables. Provider health is reported only when independently probed.",
      counts: {
        users: usersCount,
        assets: assetsCount,
        activityEvents: activityCount,
        auditEvents: auditCount,
        securityReports: securityCount,
        campaigns: campaignsCount,
        pendingCampaignReviews: Number(pendingEntries[0]?.value ?? 0),
      },
      infrastructure: {
        database: "connected" as const,
        redis: redisStatus,
        workers: ENV.workersEnabled ? "enabled" : "disabled",
      },
    };
  }),

  auditEvents: adminPermissionProcedure("audit.read")
    .input(z.object({ limit: optionalLimit, resourceType: resourceType.optional(), action: z.string().trim().max(80).optional() }).optional())
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const filters = [
        input?.resourceType ? eq(adminAuditEvents.resourceType, input.resourceType) : undefined,
        input?.action ? eq(adminAuditEvents.action, input.action) : undefined,
      ].filter(Boolean) as any[];
      const query = db.select().from(adminAuditEvents);
      const rows = filters.length
        ? await query.where(and(...filters)).orderBy(desc(adminAuditEvents.createdAt)).limit(input?.limit ?? 100)
        : await query.orderBy(desc(adminAuditEvents.createdAt)).limit(input?.limit ?? 100);
      return rows;
    }),

  approvals: router({
    list: adminPermissionProcedure("approvals.read")
      .input(z.object({ status: z.enum(["pending", "approved", "rejected", "executed"]).optional(), limit: optionalLimit }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const query = db.select().from(adminApprovalRequests);
        return input?.status
          ? query.where(eq(adminApprovalRequests.status, input.status)).orderBy(desc(adminApprovalRequests.requestedAt)).limit(input.limit ?? 100)
          : query.orderBy(desc(adminApprovalRequests.requestedAt)).limit(input?.limit ?? 100);
      }),

    request: adminPermissionProcedure("approvals.request")
      .input(z.object({
        action: approvalAction,
        resourceType,
        resourceId: z.number().int().positive().nullable().optional(),
        payload: z.record(z.string(), z.unknown()).default({}),
        reason: z.string().trim().min(10).max(1000),
      }))
      .mutation(async ({ ctx, input }) => {
        const requiredPermission: AdminPermission = input.action.startsWith("user.") ? "users.manage" : input.action === "asset.verification_change" ? "assets.verify" : "assets.manage";
        if (!hasAdminPermission(ctx.user, requiredPermission)) throw new Error("Insufficient permission for this approval action");
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; approval request was not created");
        const [created] = await db.insert(adminApprovalRequests).values({
          requestedByOpenId: ctx.user.openId,
          action: input.action,
          resourceType: input.resourceType,
          resourceId: input.resourceId ?? null,
          payload: input.payload,
          requestReason: input.reason,
        }).$returningId();
        await recordAdminAudit(ctx, {
          action: "approval.requested",
          resourceType: input.resourceType,
          resourceId: input.resourceId,
          details: { approvalId: created?.id ?? null, requestedAction: input.action },
          reason: input.reason,
        });
        return { id: created?.id ?? null, status: "pending" as const };
      }),

    decide: adminPermissionProcedure("approvals.decide")
      .input(z.object({ id: z.number().int().positive(), decision: z.enum(["approved", "rejected"]), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; approval decision was not recorded");
        const [request] = await db.select().from(adminApprovalRequests).where(eq(adminApprovalRequests.id, input.id)).limit(1);
        if (!request) throw new Error("Approval request not found");
        if (request.status !== "pending") throw new Error("Approval request is no longer pending");
        if (request.requestedByOpenId === ctx.user.openId) throw new Error("A request cannot be approved by its requester");
        const nextStatus = input.decision;
        await db.update(adminApprovalRequests).set({
          status: nextStatus,
          approvedByOpenId: ctx.user.openId,
          decisionReason: input.reason,
          decidedAt: new Date(),
        }).where(eq(adminApprovalRequests.id, input.id));
        await recordAdminAudit(ctx, {
          action: `approval.${input.decision}`,
          resourceType: request.resourceType,
          resourceId: request.resourceId,
          details: { approvalId: request.id, requestedByOpenId: request.requestedByOpenId },
          reason: input.reason,
          previousState: { status: request.status },
          newState: { status: nextStatus },
        });
        return { id: request.id, status: nextStatus };
      }),

    execute: adminPermissionProcedure("approvals.execute")
      .input(z.object({ id: z.number().int().positive(), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; approval was not executed");
        const result = await db.transaction(async (tx) => {
          const [request] = await tx.select().from(adminApprovalRequests).where(eq(adminApprovalRequests.id, input.id)).limit(1);
          if (!request) throw new Error("Approval request not found");
          if (request.status !== "approved") throw new Error("Only approved requests can be executed");
          if (request.requestedByOpenId === ctx.user.openId) throw new Error("The requester cannot execute the same high-risk request");
          if (request.approvedByOpenId === ctx.user.openId) throw new Error("The approver cannot execute the same high-risk request");

          let previousState: Record<string, unknown> = { status: request.status };
          let newState: Record<string, unknown> = { status: "executed" };
          const payload = request.payload ?? {};

          if (request.action === "user.suspend" || request.action === "user.restore") {
            const userId = typeof payload.userId === "number" ? payload.userId : request.resourceId;
            if (!userId) throw new Error("Approval payload is missing a user ID");
            const [target] = await tx.select({ id: users.id, suspendedAt: users.suspendedAt, suspensionReason: users.suspensionReason }).from(users).where(eq(users.id, userId)).limit(1);
            if (!target) throw new Error("User not found");
            previousState = { suspendedAt: target.suspendedAt, suspensionReason: target.suspensionReason };
            if (request.action === "user.suspend") {
              await tx.update(users).set({ suspendedAt: new Date(), suspensionReason: request.requestReason }).where(eq(users.id, userId));
              newState = { suspended: true };
            } else {
              await tx.update(users).set({ suspendedAt: null, suspensionReason: null }).where(eq(users.id, userId));
              newState = { suspended: false };
            }
          } else if (request.action === "user.role_change") {
            const userId = typeof payload.userId === "number" ? payload.userId : request.resourceId;
            const nextRole = payload.adminRole === null ? null : payload.adminRole;
            if (!userId || (nextRole !== null && !["super_admin", "operations_admin", "support_admin", "compliance_admin", "content_admin"].includes(String(nextRole)))) throw new Error("Approval payload contains an invalid role change");
            const [target] = await tx.select({ id: users.id, role: users.role, adminRole: users.adminRole }).from(users).where(eq(users.id, userId)).limit(1);
            if (!target) throw new Error("User not found");
            previousState = { role: target.role, adminRole: target.adminRole };
            await tx.update(users).set({ role: nextRole ? "admin" : "user", adminRole: nextRole as any }).where(eq(users.id, userId));
            newState = { role: nextRole ? "admin" : "user", adminRole: nextRole };
          } else if (request.action === "asset.status_change") {
            const assetId = request.resourceId;
            const nextStatus = payload.status;
            if (!assetId || !["active", "blocked", "spam"].includes(String(nextStatus))) throw new Error("Approval payload contains an invalid asset status change");
            const [asset] = await tx.select({ id: assets.id, status: assets.status }).from(assets).where(eq(assets.id, assetId)).limit(1);
            if (!asset) throw new Error("Asset not found");
            previousState = { status: asset.status };
            await tx.update(assets).set({ status: nextStatus as "active" | "blocked" | "spam" }).where(eq(assets.id, assetId));
            newState = { status: nextStatus };
          } else if (request.action === "asset.verification_change") {
            const assetId = request.resourceId;
            const nextVerification = payload.verificationStatus;
            if (!assetId || !["unverified", "registered", "verified"].includes(String(nextVerification))) throw new Error("Approval payload contains an invalid verification change");
            const [asset] = await tx.select({ id: assets.id, verificationStatus: assets.verificationStatus }).from(assets).where(eq(assets.id, assetId)).limit(1);
            if (!asset) throw new Error("Asset not found");
            previousState = { verificationStatus: asset.verificationStatus };
            await tx.update(assets).set({ verificationStatus: nextVerification as "unverified" | "registered" | "verified" }).where(eq(assets.id, assetId));
            newState = { verificationStatus: nextVerification };
          } else {
            throw new Error(`Unsupported approval action: ${request.action}`);
          }

          await tx.update(adminApprovalRequests).set({ status: "executed", executedByOpenId: ctx.user.openId, executedAt: new Date() }).where(eq(adminApprovalRequests.id, request.id));
          return { request, previousState, newState };
        });

        await recordAdminAudit(ctx, {
          action: "approval.executed",
          resourceType: result.request.resourceType,
          resourceId: result.request.resourceId,
          details: { approvalId: result.request.id, requestedByOpenId: result.request.requestedByOpenId, approvedByOpenId: result.request.approvedByOpenId, executedByOpenId: ctx.user.openId },
          reason: input.reason,
          previousState: result.previousState,
          newState: result.newState,
        });
        return { id: result.request.id, status: "executed" as const };
      }),
  }),

  users: router({
    list: adminPermissionProcedure("users.read")
      .input(z.object({ search: z.string().trim().max(160).optional(), limit: optionalLimit }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const search = input?.search;
        const query = db.select({
          id: users.id,
          openId: users.openId,
          name: users.name,
          email: users.email,
          role: users.role,
          adminRole: users.adminRole,
          suspendedAt: users.suspendedAt,
          suspensionReason: users.suspensionReason,
          createdAt: users.createdAt,
          lastSignedIn: users.lastSignedIn,
        }).from(users);
        return search
          ? query.where(or(like(users.openId, `%${search}%`), like(users.email, `%${search}%`), like(users.name, `%${search}%`))).orderBy(desc(users.lastSignedIn)).limit(input?.limit ?? 100)
          : query.orderBy(desc(users.lastSignedIn)).limit(input?.limit ?? 100);
      }),

    requestRoleChange: adminPermissionProcedure("users.manage")
      .input(z.object({ userId: z.number().int().positive(), adminRole: z.enum(["super_admin", "operations_admin", "support_admin", "compliance_admin", "content_admin"]).nullable(), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; role change was not requested");
        const [target] = await db.select({ id: users.id, openId: users.openId, role: users.role, adminRole: users.adminRole }).from(users).where(eq(users.id, input.userId)).limit(1);
        if (!target) throw new Error("User not found");
        const payload = { userId: target.id, openId: target.openId, adminRole: input.adminRole, role: input.adminRole ? "admin" : "user" };
        const [created] = await db.insert(adminApprovalRequests).values({
          requestedByOpenId: ctx.user.openId,
          action: "user.role_change",
          resourceType: "user",
          resourceId: target.id,
          payload,
          requestReason: input.reason,
        }).$returningId();
        await recordAdminAudit(ctx, { action: "user.role_change_requested", resourceType: "user", resourceId: target.id, reason: input.reason, details: { approvalId: created?.id ?? null, targetOpenId: target.openId } });
        return { approvalId: created?.id ?? null, status: "pending" as const };
      }),

    requestSuspension: adminPermissionProcedure("users.manage")
      .input(z.object({ userId: z.number().int().positive(), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; suspension was not requested");
        const [target] = await db.select({ id: users.id, openId: users.openId, suspendedAt: users.suspendedAt }).from(users).where(eq(users.id, input.userId)).limit(1);
        if (!target) throw new Error("User not found");
        const [created] = await db.insert(adminApprovalRequests).values({ requestedByOpenId: ctx.user.openId, action: "user.suspend", resourceType: "user", resourceId: target.id, payload: { userId: target.id, openId: target.openId }, requestReason: input.reason }).$returningId();
        await recordAdminAudit(ctx, { action: "user.suspension_requested", resourceType: "user", resourceId: target.id, reason: input.reason, details: { approvalId: created?.id ?? null, wasSuspended: Boolean(target.suspendedAt) } });
        return { approvalId: created?.id ?? null, status: "pending" as const };
      }),

    requestRestore: adminPermissionProcedure("users.manage")
      .input(z.object({ userId: z.number().int().positive(), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; restore was not requested");
        const [target] = await db.select({ id: users.id, openId: users.openId, suspendedAt: users.suspendedAt }).from(users).where(eq(users.id, input.userId)).limit(1);
        if (!target) throw new Error("User not found");
        const [created] = await db.insert(adminApprovalRequests).values({ requestedByOpenId: ctx.user.openId, action: "user.restore", resourceType: "user", resourceId: target.id, payload: { userId: target.id, openId: target.openId }, requestReason: input.reason }).$returningId();
        await recordAdminAudit(ctx, { action: "user.restore_requested", resourceType: "user", resourceId: target.id, reason: input.reason, details: { approvalId: created?.id ?? null, wasSuspended: Boolean(target.suspendedAt) } });
        return { approvalId: created?.id ?? null, status: "pending" as const };
      }),
  }),

  assets: router({
    list: adminPermissionProcedure("assets.read")
      .input(z.object({ chainId: z.string().trim().max(32).optional(), status: z.enum(["active", "blocked", "spam"]).optional(), search: z.string().trim().max(160).optional(), limit: optionalLimit }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const filters = [
          input?.chainId ? eq(assets.chainId, input.chainId) : undefined,
          input?.status ? eq(assets.status, input.status) : undefined,
          input?.search ? or(like(assets.identifier, `%${input.search}%`), like(assets.symbol, `%${input.search}%`), like(assets.name, `%${input.search}%`)) : undefined,
        ].filter(Boolean) as any[];
        const query = db.select({
          id: assets.id,
          chainId: assets.chainId,
          assetType: assets.assetType,
          identifier: assets.identifier,
          symbol: assets.symbol,
          name: assets.name,
          decimals: assets.decimals,
          logoUrl: assets.logoUrl,
          status: assets.status,
          verificationStatus: assets.verificationStatus,
          market: { priceUsd: assetMarketData.priceUsd, source: assetMarketData.source, isStale: assetMarketData.isStale },
          updatedAt: assets.updatedAt,
        }).from(assets).leftJoin(assetMarketData, eq(assetMarketData.assetId, assets.id));
        return filters.length ? query.where(and(...filters)).orderBy(desc(assets.updatedAt)).limit(input?.limit ?? 100) : query.orderBy(desc(assets.updatedAt)).limit(input?.limit ?? 100);
      }),

    requestStatusChange: adminPermissionProcedure("assets.manage")
      .input(z.object({ assetId: z.number().int().positive(), status: z.enum(["active", "blocked", "spam"]), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; asset status change was not requested");
        const [asset] = await db.select({ id: assets.id, chainId: assets.chainId, identifier: assets.identifier, status: assets.status }).from(assets).where(eq(assets.id, input.assetId)).limit(1);
        if (!asset) throw new Error("Asset not found");
        const [created] = await db.insert(adminApprovalRequests).values({ requestedByOpenId: ctx.user.openId, action: "asset.status_change", resourceType: "asset", resourceId: asset.id, payload: { status: input.status }, requestReason: input.reason }).$returningId();
        await recordAdminAudit(ctx, { action: "asset.status_change_requested", resourceType: "asset", resourceId: asset.id, reason: input.reason, details: { approvalId: created?.id ?? null, chainId: asset.chainId, identifier: asset.identifier }, previousState: { status: asset.status }, newState: { status: input.status } });
        return { approvalId: created?.id ?? null, status: "pending" as const };
      }),

    requestVerificationChange: adminPermissionProcedure("assets.verify")
      .input(z.object({ assetId: z.number().int().positive(), verificationStatus: z.enum(["unverified", "registered", "verified"]), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; verification change was not requested");
        const [asset] = await db.select({ id: assets.id, chainId: assets.chainId, identifier: assets.identifier, verificationStatus: assets.verificationStatus }).from(assets).where(eq(assets.id, input.assetId)).limit(1);
        if (!asset) throw new Error("Asset not found");
        const [created] = await db.insert(adminApprovalRequests).values({ requestedByOpenId: ctx.user.openId, action: "asset.verification_change", resourceType: "asset", resourceId: asset.id, payload: { verificationStatus: input.verificationStatus }, requestReason: input.reason }).$returningId();
        await recordAdminAudit(ctx, { action: "asset.verification_change_requested", resourceType: "asset", resourceId: asset.id, reason: input.reason, details: { approvalId: created?.id ?? null, chainId: asset.chainId, identifier: asset.identifier }, previousState: { verificationStatus: asset.verificationStatus }, newState: { verificationStatus: input.verificationStatus } });
        return { approvalId: created?.id ?? null, status: "pending" as const };
      }),

    updateMetadata: adminPermissionProcedure("assets.manage")
      .input(z.object({ assetId: z.number().int().positive(), description: z.string().max(5000).nullable().optional(), website: z.string().url().max(500).nullable().optional(), twitter: z.string().max(255).nullable().optional(), telegram: z.string().max(255).nullable().optional(), discord: z.string().max(255).nullable().optional(), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; metadata was not changed");
        const [asset] = await db.select({ id: assets.id }).from(assets).where(eq(assets.id, input.assetId)).limit(1);
        if (!asset) throw new Error("Asset not found");
        const [previous] = await db.select().from(assetMetadata).where(eq(assetMetadata.assetId, input.assetId)).limit(1);
        const nextState = { description: input.description ?? null, website: input.website ?? null, twitter: input.twitter ?? null, telegram: input.telegram ?? null, discord: input.discord ?? null };
        await db.insert(assetMetadata).values({ assetId: input.assetId, ...nextState }).onDuplicateKeyUpdate({ set: { ...nextState, updatedAt: new Date() } });
        await recordAdminAudit(ctx, { action: "asset.metadata_updated", resourceType: "asset", resourceId: input.assetId, reason: input.reason, previousState: previous ? { description: previous.description, website: previous.website, twitter: previous.twitter, telegram: previous.telegram, discord: previous.discord } : undefined, newState: nextState });
        return { assetId: input.assetId, updated: true };
      }),
  }),

  providers: router({
    status: adminPermissionProcedure("providers.read").query(async () => ({
      providers: [
        { id: "coingecko", configured: true, status: "unknown", note: "No live provider probe is performed by this read-only endpoint." },
        { id: "birdeye", configured: Boolean(ENV.birdeyeApiKey), status: "unknown", note: "Server-only key presence is shown; secret values are never returned." },
        { id: "dexpaprika", configured: Boolean(ENV.dexpaprikaApiKey), status: "unknown", note: "Server-only key presence is shown; secret values are never returned." },
        { id: "dexscreener", configured: true, status: "unknown", note: "Used through existing market/liquidity adapters; live reachability is not asserted here." },
        { id: "goplus", configured: true, status: "unknown", note: "Security data remains unverified when the provider does not return a report." },
        { id: "lifi", configured: Boolean(ENV.lifiApiKey), status: "unknown", note: "Server-only key presence is shown; secret values are never returned." },
      ],
      fallbackPolicy: "Provider failures degrade to the existing waterfall, durable MySQL cache, or explicit unavailable state.",
    })),
  }),

  transactions: router({
    list: adminPermissionProcedure("transactions.read")
      .input(z.object({ status: z.enum(["pending", "confirmed", "failed"]).optional(), chainId: z.string().trim().max(32).optional(), limit: optionalLimit }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const filters = [input?.status ? eq(activityEvents.status, input.status) : undefined, input?.chainId ? eq(activityEvents.chainId, input.chainId) : undefined].filter(Boolean) as any[];
        const query = db.select().from(activityEvents);
        return filters.length ? query.where(and(...filters)).orderBy(desc(activityEvents.createdAt)).limit(input?.limit ?? 100) : query.orderBy(desc(activityEvents.createdAt)).limit(input?.limit ?? 100);
      }),
    feeRecords: adminPermissionProcedure("transactions.read")
      .input(z.object({ status: z.enum(["pending", "confirmed", "failed"]).optional(), limit: optionalLimit }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const query = db.select().from(feeRecords);
        return input?.status ? query.where(eq(feeRecords.status, input.status)).orderBy(desc(feeRecords.createdAt)).limit(input.limit ?? 100) : query.orderBy(desc(feeRecords.createdAt)).limit(input?.limit ?? 100);
      }),
  }),

  security: router({
    reports: adminPermissionProcedure("security.read")
      .input(z.object({ label: z.enum(["verified", "unverified", "risky", "scam_suspicious"]).optional(), limit: optionalLimit }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const query = db.select().from(securityReports);
        return input?.label ? query.where(eq(securityReports.label, input.label)).orderBy(desc(securityReports.updatedAt)).limit(input.limit ?? 100) : query.orderBy(desc(securityReports.updatedAt)).limit(input?.limit ?? 100);
      }),
  }),

  campaigns: router({
    overview: adminPermissionProcedure("campaigns.read").query(async () => {
      const db = await getDb();
      if (!db) return { available: false, campaigns: 0, entries: 0, pendingReviews: 0 };
      const [campaignCount, entryCount, pending] = await Promise.all([
        scalarCount(db, campaigns),
        scalarCount(db, campaignEntries),
        db.select({ value: count() }).from(campaignEntries).where(eq(campaignEntries.payoutStatus, "claimable")),
      ]);
      return { available: true, campaigns: campaignCount, entries: entryCount, pendingReviews: Number(pending[0]?.value ?? 0) };
    }),
  }),

  featureFlags: router({
    list: adminPermissionProcedure("system.read").query(async () => {
      const db = await getDb();
      return db ? db.select().from(adminFeatureFlags).orderBy(adminFeatureFlags.key) : [];
    }),
    upsert: adminPermissionProcedure("system.manage")
      .input(z.object({ key: z.string().trim().regex(/^[a-z][a-z0-9_.-]{1,79}$/), enabled: z.boolean(), config: z.record(z.string(), z.unknown()).optional(), reason: z.string().trim().min(10).max(1000) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable; feature flag was not changed");
        const [previous] = await db.select().from(adminFeatureFlags).where(eq(adminFeatureFlags.key, input.key)).limit(1);
        await db.insert(adminFeatureFlags).values({ key: input.key, enabled: input.enabled, config: input.config, updatedByOpenId: ctx.user.openId }).onDuplicateKeyUpdate({ set: { enabled: input.enabled, config: input.config, updatedByOpenId: ctx.user.openId, updatedAt: new Date() } });
        await recordAdminAudit(ctx, { action: "feature_flag.upsert", resourceType: "feature_flag", reason: input.reason, details: { key: input.key }, previousState: previous ? { enabled: previous.enabled, config: previous.config } : undefined, newState: { enabled: input.enabled, config: input.config } });
        return { key: input.key, enabled: input.enabled };
      }),
  }),

  announcements: router({
    list: adminPermissionProcedure("notifications.manage").input(z.object({ status: z.enum(["draft", "published", "archived"]).optional(), limit: optionalLimit }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const query = db.select().from(adminAnnouncements);
      return input?.status ? query.where(eq(adminAnnouncements.status, input.status)).orderBy(desc(adminAnnouncements.createdAt)).limit(input.limit ?? 100) : query.orderBy(desc(adminAnnouncements.createdAt)).limit(input?.limit ?? 100);
    }),
    create: adminPermissionProcedure("notifications.manage").input(z.object({ kind: z.enum(["system", "security", "maintenance", "provider_outage", "ecosystem"]), title: z.string().trim().min(1).max(160), message: z.string().trim().min(1).max(5000), reason: z.string().trim().min(10).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable; announcement was not created");
      const [created] = await db.insert(adminAnnouncements).values({ kind: input.kind, title: input.title, message: input.message, createdByOpenId: ctx.user.openId }).$returningId();
      await recordAdminAudit(ctx, { action: "announcement.created", resourceType: "announcement", resourceId: created?.id ?? null, reason: input.reason, details: { kind: input.kind, title: input.title } });
      return { id: created?.id ?? null, status: "draft" as const };
    }),
    publish: adminPermissionProcedure("notifications.manage").input(z.object({ id: z.number().int().positive(), reason: z.string().trim().min(10).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable; announcement was not published");
      const [previous] = await db.select().from(adminAnnouncements).where(eq(adminAnnouncements.id, input.id)).limit(1);
      if (!previous) throw new Error("Announcement not found");
      if (previous.status === "archived") throw new Error("Archived announcements cannot be published");
      await db.update(adminAnnouncements).set({ status: "published", publishedAt: new Date() }).where(eq(adminAnnouncements.id, input.id));
      await recordAdminAudit(ctx, { action: "announcement.published", resourceType: "announcement", resourceId: input.id, reason: input.reason, previousState: { status: previous.status }, newState: { status: "published" } });
      return { id: input.id, status: "published" as const };
    }),
    archive: adminPermissionProcedure("notifications.manage").input(z.object({ id: z.number().int().positive(), reason: z.string().trim().min(10).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable; announcement was not archived");
      const [previous] = await db.select().from(adminAnnouncements).where(eq(adminAnnouncements.id, input.id)).limit(1);
      if (!previous) throw new Error("Announcement not found");
      await db.update(adminAnnouncements).set({ status: "archived", archivedAt: new Date() }).where(eq(adminAnnouncements.id, input.id));
      await recordAdminAudit(ctx, { action: "announcement.archived", resourceType: "announcement", resourceId: input.id, reason: input.reason, previousState: { status: previous.status }, newState: { status: "archived" } });
      return { id: input.id, status: "archived" as const };
    }),
  }),

  support: router({
    status: adminPermissionProcedure("system.read").query(() => ({
      available: false,
      message: "Support queue integration is not configured in this source; no fake tickets or response metrics are shown.",
    })),
  }),

  /** Compatibility alias for the pre-Phase 4 review workspace. */
  legacyReviewAccess: adminPermissionProcedure("audit.read").query(({ ctx }) => ({ allowed: Boolean(getAdminRole(ctx.user)), message: "Use the protected Admin workspace procedures for new operations." })),
});
