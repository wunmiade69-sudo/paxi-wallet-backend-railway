import { z } from "zod";
import { adminPermissionProcedure, router } from "../_core/trpc";
import {
  allocateAirdrop,
  approveAirdrop,
  createAirdropDistribution,
  markAirdropDistributed,
} from "../airdrop/airdropService";

const assetSchema = z.object({
  assetSymbol: z.string().trim().min(1).max(32),
  assetNetwork: z.string().trim().min(1).max(32),
  assetContractAddress: z.string().trim().max(128).nullable().optional(),
  totalAmount: z.string().trim().regex(/^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/).refine((value) => value !== "0", "Airdrop amount must be positive"),
});

export const airdropsRouter = router({
  create: adminPermissionProcedure("campaigns.manage")
    .input(assetSchema.extend({ campaignId: z.number().int().positive().optional(), snapshotId: z.number().int().positive().optional() }))
    .mutation(({ ctx, input }) => createAirdropDistribution({ ...input, createdByOpenId: ctx.user.openId })),

  allocate: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ distributionId: z.number().int().positive() }))
    .mutation(({ input }) => allocateAirdrop(input.distributionId)),

  approve: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ distributionId: z.number().int().positive() }))
    .mutation(({ ctx, input }) => approveAirdrop(input.distributionId, ctx.user.openId)),

  markDistributed: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ distributionId: z.number().int().positive(), distributionTxHash: z.string().trim().min(8).max(128) }))
    .mutation(({ input }) => markAirdropDistributed(input.distributionId, input.distributionTxHash)),
});
