import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { fetchLifiQuote, SUPPORTED_LIFI_CHAIN_IDS } from "../lifiQuote";

const chainId = z.number().int().refine((value) => SUPPORTED_LIFI_CHAIN_IDS.has(value), {
  message: "Unsupported LI.FI chain",
});

export const bridgeRouter = router({
  /** Quote only; transaction signing and broadcasting remain client-side. */
  quote: publicProcedure
    .input(
      z.object({
        fromChain: chainId,
        toChain: chainId,
        fromToken: z.string().min(1).max(128),
        toToken: z.string().min(1).max(128),
        fromAddress: z.string().min(20).max(128),
        toAddress: z.string().min(20).max(128),
        fromAmount: z.string().regex(/^[0-9]+$/).max(80),
        slippage: z.number().finite().min(0).max(0.5),
      }),
    )
    .query(({ input }) => fetchLifiQuote(input)),
});
