import { z } from "zod";
import { adminPermissionProcedure, router } from "../_core/trpc";
import {
  applyExternalEligibility,
  createCampaignSnapshot,
  exportCampaignSnapshot,
  freezeCampaignSnapshot,
  getCampaignSnapshotEligibilityPayload,
} from "../campaigns/snapshotService";
import { and, eq } from "drizzle-orm";
import { campaignSnapshots } from "../../drizzle/schema";
import { getDb } from "../db";

const snapshotIdSchema = z.number().int().positive();
const requirementsSchema = z.record(z.string().trim().min(1).max(64), z.boolean()).refine((value) => Object.keys(value).length <= 10, "At most ten requirements may be supplied");

export const campaignSnapshotsRouter = router({
  create: adminPermissionProcedure("campaigns.manage")
    .input(
      z.object({
        campaignId: z.number().int().positive(),
        snapshotDateMs: z.number().int().nonnegative(),
      }),
    )
    .mutation(({ ctx, input }) => createCampaignSnapshot(input.campaignId, new Date(input.snapshotDateMs), ctx.user.openId)),

  freeze: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ snapshotId: snapshotIdSchema }))
    .mutation(({ input }) => freezeCampaignSnapshot(input.snapshotId)),

  calculate: adminPermissionProcedure("campaigns.manage")
    .input(
      z.object({
        snapshotId: snapshotIdSchema,
        results: z.array(
          z.object({
            userOpenId: z.string().trim().min(1).max(64),
            score: z.number().int().min(0).max(10),
            requirements: requirementsSchema.optional(),
          }),
        ).max(5_000).optional(),
        finalize: z.boolean().default(false),
      }),
    )
    .mutation(({ input }) => applyExternalEligibility(input.snapshotId, input.results ?? [], input.finalize)),

  export: adminPermissionProcedure("campaigns.read")
    .input(
      z.object({
        snapshotId: snapshotIdSchema,
        limit: z.number().int().min(1).max(1_000).optional(),
        cursor: z.string().regex(/^\d{1,16}$/).optional(),
        eligibleOnly: z.boolean().default(true),
      }),
    )
    .query(({ input }) => exportCampaignSnapshot(input.snapshotId, input)),

  eligibilityPayload: adminPermissionProcedure("campaigns.read")
    .input(z.object({ snapshotId: snapshotIdSchema }))
    .query(({ input }) => getCampaignSnapshotEligibilityPayload(input.snapshotId)),

  distribute: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ snapshotId: snapshotIdSchema }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const result = await db
        .update(campaignSnapshots)
        .set({ status: "distributed", distributedAt: new Date() })
        .where(and(eq(campaignSnapshots.id, input.snapshotId), eq(campaignSnapshots.status, "complete")));
      if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Only a complete snapshot can be marked distributed");
      const [row] = await db.select().from(campaignSnapshots).where(eq(campaignSnapshots.id, input.snapshotId)).limit(1);
      if (!row) throw new Error("Snapshot not found after distribution update");
      return row;
    }),
});
