import { TRPCError } from "@trpc/server";
import { and, desc, eq, gte, isNull, lte, or, sql } from "drizzle-orm";
import { z } from "zod";
import { adminAuditEvents, campaignEntries, campaigns, tokenListings } from "../../drizzle/schema";
import { getDb } from "../db";
import { verifyFeePayment, verifyTokenTransferProof } from "../feeVerification";
import { adminPermissionProcedure, protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { calculateCampaignPoolUsd } from "../campaignPool";
import { campaignTokensMatchApprovedListing } from "../campaignGuards";
import { CAMPAIGN_BANNER_MAX_BYTES, CAMPAIGN_ICON_MAX_BYTES, decodeCampaignImage } from "../campaignAssets";
import { storagePut } from "../storage";
import { campaignCanPublish } from "../campaignModeration";
import { clearCachedFeaturedCampaigns, getCachedFeaturedCampaigns, setCachedFeaturedCampaigns } from "../campaigns/featuredCache";
import { evaluateLiveCampaignEligibility } from "../campaigns/liveEligibility";
import { ensureDefaultRequirements } from "../eligibility/requirementService";
import { campaignRequirements } from "../../drizzle/schema";
import { campaignClaimBlockReason } from "../campaigns/claimGuards";
import { claimFeePayment } from "../fees/paymentLedger";
import { getTreasuryConfiguration, type TreasuryNetwork } from "../fees/treasury";

const campaignImageDataUrl = z.string().max(7_200_000).regex(/^data:image\/(png|jpeg|jpg|webp);base64,/, "Campaign image must be a PNG, JPEG, or WebP data URL.");
const campaignSocialsSchema = z.object({ twitter: z.string().trim().max(255).optional(), telegram: z.string().trim().max(255).optional(), discord: z.string().trim().max(255).optional() });

function publicCampaignWindow(now = new Date()) {
  return [
    eq(campaigns.status, "active"),
    eq(tokenListings.status, "verified"),
    or(isNull(campaigns.startAt), lte(campaigns.startAt, now)),
    or(isNull(campaigns.endAt), gte(campaigns.endAt, now)),
  ];
}

async function listCurrentPublicCampaigns(limit: number, featuredOnly = false) {
  const db = await getDb();
  if (!db) return [];
  const conditions = publicCampaignWindow();
  if (featuredOnly) conditions.push(eq(campaigns.isFeatured, true));
  const rows = await db.select({ campaign: campaigns }).from(campaigns).innerJoin(tokenListings, eq(campaigns.listingId, tokenListings.id)).where(and(...conditions)).orderBy(desc(campaigns.featuredAt), desc(campaigns.updatedAt)).limit(limit);
  return rows.map((row) => row.campaign);
}

async function requireListingOwnerOrAdmin(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  listingId: number,
  openId: string,
  isAdmin: boolean,
) {
  const listing = await db.select().from(tokenListings).where(eq(tokenListings.id, listingId)).limit(1);
  if (!listing[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found." });
  if (listing[0].status !== "verified") {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Only verified listings can run a campaign." });
  }
  if (!isAdmin && listing[0].submittedByOpenId !== openId) {
    throw new TRPCError({ code: "FORBIDDEN", message: "You don't own this listing." });
  }
  return listing[0];
}

export const campaignsRouter = router({
  /** Campaigns for a listing's own page (any status - owner wants to see drafts too). */
  listForListing: protectedProcedure
    .input(z.object({ listingId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      await requireListingOwnerOrAdmin(db, input.listingId, ctx.user.openId, ctx.user.role === "admin");
      return db.select().from(campaigns).where(eq(campaigns.listingId, input.listingId)).orderBy(desc(campaigns.updatedAt)).limit(100);
    }),

  myCampaigns: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(campaigns).where(eq(campaigns.createdByOpenId, ctx.user.openId)).orderBy(desc(campaigns.updatedAt)).limit(100);
  }),

  /** Live campaigns across every listing, for the Discover feed. */
  listActive: publicProcedure.query(async () => {
    return listCurrentPublicCampaigns(100);
  }),

  /** Compact home-screen feed: active, approved, in-window, and featured only. */
  featured: publicProcedure.query(async () => {
    const cached = await getCachedFeaturedCampaigns<Awaited<ReturnType<typeof listCurrentPublicCampaigns>>>();
    if (cached) return cached;
    const rows = await listCurrentPublicCampaigns(12, true);
    await setCachedFeaturedCampaigns(rows);
    return rows;
  }),

  /** Public campaign detail is deliberately limited to admin-approved active campaigns. */
  getPublic: publicProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const rows = await db.select({ campaign: campaigns }).from(campaigns).innerJoin(tokenListings, eq(campaigns.listingId, tokenListings.id)).where(and(eq(campaigns.id, input.campaignId), ...publicCampaignWindow())).limit(1);
      return rows[0]?.campaign ?? null;
    }),

  publicRequirements: publicProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const visible = await listCurrentPublicCampaigns(100);
      if (!visible.some((campaign) => campaign.id === input.campaignId)) return [];
      const db = await getDb();
      if (!db) return [];
      return db.select({ key: campaignRequirements.requirementKey, label: campaignRequirements.label, threshold: campaignRequirements.threshold, sortOrder: campaignRequirements.sortOrder }).from(campaignRequirements).where(and(eq(campaignRequirements.campaignId, input.campaignId), eq(campaignRequirements.isActive, true))).orderBy(campaignRequirements.sortOrder);
    }),

  /** The backend evaluates progress from confirmed PAXI activity; clients never submit completion flags. */
  myEligibility: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(({ ctx, input }) => evaluateLiveCampaignEligibility(input.campaignId, ctx.user.openId)),

  /**
   * Step 1: the (already-verified) listing owner defines the campaign.
   * Starts as `draft` - it can't go live until the reward pool is funded
   * (see fundPool), so you're never on the hook for payouts you haven't
   * actually received.
   */
  create: protectedProcedure
    .input(
      z.object({
        listingId: z.number().int().positive(),
        title: z.string().trim().min(1).max(128),
        description: z.string().trim().max(2000).optional(),
        banner: campaignImageDataUrl,
        icon: campaignImageDataUrl,
        website: z.string().trim().url().max(500).optional(),
        socials: campaignSocialsSchema.optional(),
        minTokenAmount: z.string().trim().min(1).max(64),
        taskTokenSymbol: z.string().trim().min(1).max(32),
        taskTokenContractAddress: z.string().trim().min(1).max(128),
        taskTokenNetwork: z.string().trim().min(1).max(32),
        rewardAmount: z.string().trim().min(1).max(64),
        rewardValueUsd: z.string().trim().regex(/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/),
        rewardTokenSymbol: z.string().trim().min(1).max(32),
        rewardTokenContractAddress: z.string().trim().max(128).optional(),
        rewardNetwork: z.string().trim().min(1).max(32),
        maxWinners: z.number().int().min(1).max(100_000),
        startAt: z.string().datetime().optional(),
        endAt: z.string().datetime().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const listing = await requireListingOwnerOrAdmin(db, input.listingId, ctx.user.openId, ctx.user.role === "admin");
      let poolRequiredAmountUsd: string;
      try {
        poolRequiredAmountUsd = calculateCampaignPoolUsd(input.rewardValueUsd, input.maxWinners);
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Invalid campaign pool requirement." });
      }

      // A verified listing is the source of truth for the campaign token. This
      // prevents a creator from borrowing an approved listing to advertise a
      // different contract in campaign claims or rewards.
      if (!campaignTokensMatchApprovedListing(input, listing)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Campaign task and reward tokens must match the approved listing." });
      }
      if (input.startAt && input.endAt && new Date(input.endAt) <= new Date(input.startAt)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Campaign end time must be after its start time." });
      }
      const banner = decodeCampaignImage(input.banner, CAMPAIGN_BANNER_MAX_BYTES, "Campaign banner");
      const icon = decodeCampaignImage(input.icon, CAMPAIGN_ICON_MAX_BYTES, "Campaign icon");

      const [result] = await db.insert(campaigns).values({
        listingId: input.listingId,
        title: input.title,
        description: input.description,
        website: input.website,
        socials: input.socials,
        minTokenAmount: input.minTokenAmount,
        taskTokenSymbol: input.taskTokenSymbol,
        taskTokenContractAddress: input.taskTokenContractAddress,
        taskTokenNetwork: input.taskTokenNetwork,
        rewardAmount: input.rewardAmount,
        rewardTokenSymbol: input.rewardTokenSymbol,
        rewardTokenContractAddress: input.rewardTokenContractAddress,
        rewardNetwork: input.rewardNetwork,
        maxWinners: input.maxWinners,
        poolRequiredAmountUsd,
        status: "draft",
        startAt: input.startAt ? new Date(input.startAt) : undefined,
        endAt: input.endAt ? new Date(input.endAt) : undefined,
        createdByOpenId: ctx.user.openId,
      });

      const campaignId = Number(result.insertId);
      const [bannerStored, iconStored] = await Promise.all([
        storagePut(`campaign-assets/campaign/${campaignId}/banner.${banner.extension}`, banner.buffer, banner.contentType),
        storagePut(`campaign-assets/campaign/${campaignId}/icon.${icon.extension}`, icon.buffer, icon.contentType),
      ]);
      await db.update(campaigns).set({ bannerKey: bannerStored.key, iconKey: iconStored.key }).where(eq(campaigns.id, campaignId));
      await ensureDefaultRequirements(campaignId);

      return { id: campaignId, poolRequiredAmountUsd } as const;
    }),

  /**
   * Step 2: owner deposits maxWinners * rewardAmount (as USD value) to the
   * Paxi treasury as escrow, then confirms the tx here. Verified on-chain
   * the same way as listing/creation fees - only once verified does the
       * campaign move into administrator review. It cannot be public until
       * that review approves the funded draft.
   */
  fundPool: protectedProcedure
    .input(z.object({
      campaignId: z.number().int().positive(),
      feeTxHash: z.string().trim().min(1).max(128),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rows = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      const campaign = rows[0];
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      if (ctx.user.role !== "admin" && campaign.createdByOpenId !== ctx.user.openId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You don't own this campaign." });
      }
      await requireListingOwnerOrAdmin(db, campaign.listingId, ctx.user.openId, ctx.user.role === "admin");
      if (campaign.poolFundedTxHash) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign's pool is already funded." });
      }
      if (!campaign.bannerKey || !campaign.iconKey) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Campaign banner and icon must be validated before funding submission." });
      }

      const verification = await verifyFeePayment(campaign.rewardNetwork, input.feeTxHash, campaign.poolRequiredAmountUsd);
      if (!verification.ok) throw new TRPCError({ code: "BAD_REQUEST", message: verification.reason });
      const treasury = getTreasuryConfiguration(campaign.rewardNetwork as TreasuryNetwork);
      if (!treasury.address) throw new TRPCError({ code: "BAD_REQUEST", message: "Treasury is not configured for this campaign network." });
      await claimFeePayment({
        transactionHash: input.feeTxHash,
        userOpenId: ctx.user.openId,
        product: "campaign",
        operationKey: `campaign:${campaign.id}`,
        network: campaign.rewardNetwork,
        treasury: treasury.address,
        asset: "USDT/USDC",
        amount: campaign.poolRequiredAmountUsd,
      });

      const updateResult = await db
        .update(campaigns)
        .set({
          poolFundedTxHash: input.feeTxHash,
          poolFundedAmountUsd: campaign.poolRequiredAmountUsd,
          status: "pending_review",
          submittedAt: new Date(),
        })
        .where(and(eq(campaigns.id, input.campaignId), isNull(campaigns.poolFundedTxHash), eq(campaigns.status, "draft")));
      if (Number((updateResult as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
        throw new TRPCError({ code: "CONFLICT", message: "This campaign has already been funded or is no longer draft." });
      }
      await clearCachedFeaturedCampaigns();

      return { success: true } as const;
    }),

  /** Owner or admin can end a campaign early (e.g. pool exhausted, issue found). */
  end: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const rows = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      const campaign = rows[0];
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      if (ctx.user.role !== "admin" && campaign.createdByOpenId !== ctx.user.openId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You don't own this campaign." });
      }
      await db.update(campaigns).set({ status: "ended" }).where(eq(campaigns.id, input.campaignId));
      await clearCachedFeaturedCampaigns();
      return { success: true } as const;
    }),

  myEntry: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;
      const rows = await db
        .select()
        .from(campaignEntries)
        .where(and(eq(campaignEntries.campaignId, input.campaignId), eq(campaignEntries.userOpenId, ctx.user.openId)))
        .limit(1);
      return rows[0] ?? null;
    }),

  /**
   * Converts an eligible winner into a claimable payout request. This does not
   * send tokens; the existing admin payout confirmation remains responsible for
   * recording an on-chain distribution transaction.
   */
  requestClaim: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const eligibility = await evaluateLiveCampaignEligibility(input.campaignId, ctx.user.openId);
      if (!eligibility.eligible) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `You have completed ${eligibility.metRequirements} of ${eligibility.totalRequirements} requirements; ${eligibility.minimumRequired} are required.` });
      }
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      return db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM campaigns WHERE id = ${input.campaignId} FOR UPDATE`);
        const [campaign] = await tx.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
        if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
        const [listing] = await tx.select({ status: tokenListings.status }).from(tokenListings).where(eq(tokenListings.id, campaign.listingId)).limit(1);
        const reason = campaignClaimBlockReason({ status: campaign.status, claimsPaused: campaign.claimsPaused, poolFundedTxHash: campaign.poolFundedTxHash, listingVerified: listing?.status === "verified", startAt: campaign.startAt, endAt: campaign.endAt });
        if (reason) throw new TRPCError({ code: "BAD_REQUEST", message: reason });
        const [entry] = await tx.select().from(campaignEntries).where(and(eq(campaignEntries.campaignId, campaign.id), eq(campaignEntries.userOpenId, ctx.user.openId))).limit(1);
        if (!entry?.slotNumber) throw new TRPCError({ code: "BAD_REQUEST", message: "A verified campaign task proof and available winner slot are required before claiming." });
        if (entry.payoutStatus === "paid" || entry.payoutStatus === "claimable") return { success: true, status: entry.payoutStatus } as const;
        const updated = await tx.update(campaignEntries).set({ payoutStatus: "claimable", claimRequestedAt: new Date() }).where(and(eq(campaignEntries.id, entry.id), eq(campaignEntries.payoutStatus, "pending")));
        if (Number((updated as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new TRPCError({ code: "CONFLICT", message: "Claim request changed concurrently; reload and try again." });
        return { success: true, status: "claimable" } as const;
      });
    }),

  /**
   * User submits the swap tx that (they say) meets the task requirement.
   * Verified on-chain, then a winner slot is claimed atomically - a row
   * lock on the campaign serializes concurrent claims so two people can
   * never both land slot #100. See feeVerification.ts for what this proof
   * does and doesn't guarantee.
   */
  submitTaskProof: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive(), walletAddress: z.string().trim().min(1).max(128), swapTxHash: z.string().trim().min(1).max(128) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rows = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      const campaign = rows[0];
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      if (campaign.status !== "active") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign isn't active." });
      }
      const [listing] = await db.select({ status: tokenListings.status }).from(tokenListings).where(eq(tokenListings.id, campaign.listingId)).limit(1);
      if (listing?.status !== "verified") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign's listing is no longer approved." });
      }
      const now = new Date();
      if (campaign.startAt && now < campaign.startAt) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign hasn't started yet." });
      }
      if (campaign.endAt && now > campaign.endAt) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign has ended." });
      }
      if (!campaign.taskTokenContractAddress) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign's task token isn't configured for verification." });
      }

      const verification = await verifyTokenTransferProof(
        campaign.taskTokenNetwork,
        input.swapTxHash,
        campaign.taskTokenContractAddress,
        input.walletAddress,
        campaign.minTokenAmount,
      );
      if (!verification.ok) throw new TRPCError({ code: "BAD_REQUEST", message: verification.reason });

      return db.transaction(async (tx) => {
        // Lock the campaign row so concurrent claims serialize instead of racing.
        await tx.execute(sql`SELECT id FROM campaigns WHERE id = ${input.campaignId} FOR UPDATE`);

        const fresh = await tx.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
        const [existingEntry] = await tx
          .select()
          .from(campaignEntries)
          .where(and(eq(campaignEntries.campaignId, input.campaignId), eq(campaignEntries.userOpenId, ctx.user.openId)))
          .limit(1);
        const [proofUsed] = await tx
          .select({ id: campaignEntries.id, userOpenId: campaignEntries.userOpenId })
          .from(campaignEntries)
          .where(eq(campaignEntries.proofTxHash, input.swapTxHash))
          .limit(1);
        if (proofUsed && proofUsed.userOpenId !== ctx.user.openId) {
          throw new TRPCError({ code: "CONFLICT", message: "This transaction proof has already been used." });
        }
        if (existingEntry?.slotNumber != null) {
          return { success: true, slotNumber: existingEntry.slotNumber } as const;
        }
        if (!fresh[0] || fresh[0].winnersCount >= fresh[0].maxWinners) {
          // Still record the entry (they did the trade) but with no slot - all winner spots are gone.
          if (existingEntry) {
            await tx.update(campaignEntries).set({ progressAmount: campaign.minTokenAmount, proofTxHash: input.swapTxHash, qualifiedAt: new Date() }).where(eq(campaignEntries.id, existingEntry.id));
          } else {
            await tx.insert(campaignEntries).values({
              campaignId: input.campaignId,
              userOpenId: ctx.user.openId,
              progressAmount: campaign.minTokenAmount,
              proofTxHash: input.swapTxHash,
              qualifiedAt: new Date(),
            });
          }
          throw new TRPCError({ code: "BAD_REQUEST", message: "All winner slots for this campaign are already claimed." });
        }

        const nextSlot = fresh[0].winnersCount + 1;

        if (existingEntry) {
          await tx.update(campaignEntries).set({
            progressAmount: campaign.minTokenAmount,
            slotNumber: nextSlot,
            qualifiedAt: new Date(),
            proofTxHash: input.swapTxHash,
          }).where(eq(campaignEntries.id, existingEntry.id));
        } else {
          await tx.insert(campaignEntries).values({
            campaignId: input.campaignId,
            userOpenId: ctx.user.openId,
            progressAmount: campaign.minTokenAmount,
            slotNumber: nextSlot,
            qualifiedAt: new Date(),
            proofTxHash: input.swapTxHash,
          });
        }

        await tx.update(campaigns).set({ winnersCount: nextSlot }).where(eq(campaigns.id, input.campaignId));

        return { success: true, slotNumber: nextSlot } as const;
      });
    }),

  // --- Admin ---

  adminListPendingReview: adminPermissionProcedure("campaigns.read").query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(campaigns).where(eq(campaigns.status, "pending_review")).orderBy(desc(campaigns.submittedAt)).limit(200);
  }),

  adminReview: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ campaignId: z.number().int().positive(), decision: z.enum(["active", "rejected"]), rejectionReason: z.string().trim().max(2000).optional(), reason: z.string().trim().min(10).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      if (!campaign || (input.decision === "active" && !campaignCanPublish(campaign))) {
        throw new TRPCError({ code: "CONFLICT", message: "Campaign is missing verified escrow or private campaign assets." });
      }
      if (input.decision === "active") {
        const requirements = await ensureDefaultRequirements(campaign.id);
        if (requirements.filter((requirement) => requirement.isActive).length !== 10) {
          throw new TRPCError({ code: "CONFLICT", message: "Campaign requires exactly ten active requirements before approval." });
        }
      }
      const updateResult = await db
        .update(campaigns)
        .set({
          status: input.decision,
          reviewedAt: new Date(),
          reviewedByOpenId: ctx.user.openId,
          rejectionReason: input.decision === "rejected" ? input.rejectionReason ?? "Campaign did not meet review requirements." : null,
        })
        .where(and(eq(campaigns.id, input.campaignId), eq(campaigns.status, "pending_review")));
      if (Number((updateResult as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
        throw new TRPCError({ code: "CONFLICT", message: "Campaign is no longer awaiting review." });
      }
      await db.insert(adminAuditEvents).values({
        actorOpenId: ctx.user.openId,
        action: input.decision === "active" ? "APPROVE_CAMPAIGN" : "REJECT_CAMPAIGN",
        resourceType: "campaign",
        resourceId: input.campaignId,
        details: { decision: input.decision, reason: input.reason, rejectionReason: input.decision === "rejected" ? input.rejectionReason ?? null : null },
      });
      await clearCachedFeaturedCampaigns();
      return { success: true } as const;
    }),

  adminSetOperations: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ campaignId: z.number().int().positive(), isFeatured: z.boolean().optional(), claimsPaused: z.boolean().optional(), suspended: z.boolean().optional(), reason: z.string().trim().min(10).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      const values: Partial<typeof campaigns.$inferInsert> = {};
      if (input.isFeatured !== undefined) {
        values.isFeatured = input.isFeatured;
        values.featuredAt = input.isFeatured ? new Date() : null;
      }
      if (input.claimsPaused !== undefined) values.claimsPaused = input.claimsPaused;
      if (input.suspended === true) {
        if (campaign.status !== "active") throw new TRPCError({ code: "CONFLICT", message: "Only active campaigns can be suspended." });
        values.status = "suspended";
      }
      if (input.suspended === false) {
        if (campaign.status !== "suspended") throw new TRPCError({ code: "CONFLICT", message: "Only suspended campaigns can be resumed." });
        values.status = "active";
      }
      if (Object.keys(values).length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "No campaign operation was requested." });
      await db.update(campaigns).set(values).where(eq(campaigns.id, campaign.id));
      await db.insert(adminAuditEvents).values({
        actorOpenId: ctx.user.openId,
        action: "UPDATE_CAMPAIGN_OPERATIONS",
        resourceType: "campaign",
        resourceId: campaign.id,
        details: { isFeatured: input.isFeatured, claimsPaused: input.claimsPaused, suspended: input.suspended, reason: input.reason },
      });
      await clearCachedFeaturedCampaigns();
      return { success: true } as const;
    }),

  adminListOperational: adminPermissionProcedure("campaigns.read").query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(campaigns).where(or(eq(campaigns.status, "active"), eq(campaigns.status, "suspended"))).orderBy(desc(campaigns.isFeatured), desc(campaigns.updatedAt)).limit(200);
  }),

  adminListEntries: adminPermissionProcedure("campaigns.read")
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(campaignEntries).where(eq(campaignEntries.campaignId, input.campaignId));
    }),

  /** Marks a winner as paid out, once you've actually sent the reward. Manual on purpose - see feedback re: payouts. */
  markPayout: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ entryId: z.number().int().positive(), payoutTxHash: z.string().trim().min(1).max(128), reason: z.string().trim().min(10).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const payoutUpdate = await db
        .update(campaignEntries)
        .set({ payoutStatus: "paid", payoutTxHash: input.payoutTxHash })
        .where(and(eq(campaignEntries.id, input.entryId), eq(campaignEntries.payoutStatus, "claimable")));
      if (Number((payoutUpdate as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
        throw new TRPCError({ code: "CONFLICT", message: "Only claimable campaign rewards can be marked paid." });
      }
      await db.insert(adminAuditEvents).values({
        actorOpenId: ctx.user.openId,
        action: "MARK_CAMPAIGN_PAYOUT_PAID",
        resourceType: "campaign_entry",
        resourceId: input.entryId,
        details: { payoutTxHash: input.payoutTxHash, reason: input.reason },
      });
      return { success: true } as const;
    }),
});
