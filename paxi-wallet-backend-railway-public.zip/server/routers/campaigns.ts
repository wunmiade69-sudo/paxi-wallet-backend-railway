import { TRPCError } from "@trpc/server";
import { and, desc, eq, gte, isNotNull, isNull, lte, or, sql } from "drizzle-orm";
import { z } from "zod";
import { adminAuditEvents, campaignEntries, campaignPayouts, campaigns, campaignRewardEscrowVerifications, tokenListings } from "../../drizzle/schema";
import { getDb } from "../db";
import { verifyTokenTransferProof } from "../feeVerification";
import { getConfiguredPayoutSignerAddress, getNextPayoutNonce, inspectCampaignPayout, multiplyDecimalByInteger, sendCampaignReward, verifyRewardTokenDeposit } from "../campaigns/rewardEscrow";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { calculateCampaignPoolUsd } from "../campaignPool";
import { campaignTokensMatchApprovedListing } from "../campaignGuards";
import { CAMPAIGN_BANNER_MAX_BYTES, CAMPAIGN_ICON_MAX_BYTES, decodeCampaignImage } from "../campaignAssets";
import { storagePut } from "../storage";
import { campaignCanPublish } from "../campaignModeration";
import { clearCachedFeaturedCampaigns, getCachedFeaturedCampaigns, setCachedFeaturedCampaigns } from "../campaigns/featuredCache";
import { evaluateLiveCampaignEligibility } from "../campaigns/liveEligibility";
import { ensureDefaultRequirements } from "../eligibility/requirementService";
import { campaignRequirements } from "../../drizzle/schema";
import { campaignClaimBlockReason } from "../campaigns/claimGuards";
import { assertRewardAccounting, confirmReward, releaseReward, reserveReward } from "../campaigns/rewardAccounting";

const campaignImageDataUrl = z.string().max(7_200_000).regex(/^data:image\/(png|jpeg|jpg|webp);base64,/, "Campaign image must be a PNG, JPEG, or WebP data URL.");
const campaignSocialsSchema = z.object({ twitter: z.string().trim().max(255).optional(), telegram: z.string().trim().max(255).optional(), discord: z.string().trim().max(255).optional() });

function publicCampaignWindow(now = new Date()) {
  return [
    eq(campaigns.status, "active"),
    isNotNull(campaigns.rewardEscrowFundedTxHash),
    eq(tokenListings.status, "verified"),
    or(isNull(campaigns.startAt), lte(campaigns.startAt, now)),
    or(isNull(campaigns.endAt), gte(campaigns.endAt, now)),
  ];
}

async function listCurrentPublicCampaigns(limit: number, featuredOnly = false) {
  const db = await getDb();
  if (!db) return [];
  const conditions = publicCampaignWindow();
  if (featuredOnly) conditions.push(eq(campaigns.isFeatured, true));
  const rows = await db.select({ campaign: campaigns }).from(campaigns).innerJoin(tokenListings, eq(campaigns.listingId, tokenListings.id)).where(and(...conditions)).orderBy(desc(campaigns.featuredAt), desc(campaigns.updatedAt)).limit(limit);
  return rows.map((row) => row.campaign);
}

async function requireListingOwnerOrAdmin(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  listingId: number,
  openId: string,
  isAdmin: boolean,
) {
  const listing = await db.select().from(tokenListings).where(eq(tokenListings.id, listingId)).limit(1);
  if (!listing[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found." });
  if (listing[0].status !== "verified") {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Only verified listings can run a campaign." });
  }
  if (!isAdmin && listing[0].submittedByOpenId !== openId) {
    throw new TRPCError({ code: "FORBIDDEN", message: "You don't own this listing." });
  }
  return listing[0];
}

export const campaignsRouter = router({
  /** Campaigns for a listing's own page (any status - owner wants to see drafts too). */
  listForListing: protectedProcedure
    .input(z.object({ listingId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      await requireListingOwnerOrAdmin(db, input.listingId, ctx.user.openId, ctx.user.role === "admin");
      return db.select().from(campaigns).where(eq(campaigns.listingId, input.listingId)).orderBy(desc(campaigns.updatedAt)).limit(100);
    }),

  myCampaigns: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(campaigns).where(eq(campaigns.createdByOpenId, ctx.user.openId)).orderBy(desc(campaigns.updatedAt)).limit(100);
  }),

  /** Live campaigns across every listing, for the Discover feed. */
  listActive: publicProcedure.query(async () => {
    return listCurrentPublicCampaigns(100);
  }),

  /** Compact home-screen feed: active, approved, in-window, and featured only. */
  featured: publicProcedure.query(async () => {
    const cached = await getCachedFeaturedCampaigns<Awaited<ReturnType<typeof listCurrentPublicCampaigns>>>();
    if (cached) return cached;
    const rows = await listCurrentPublicCampaigns(12, true);
    await setCachedFeaturedCampaigns(rows);
    return rows;
  }),

  /** Public campaign detail is deliberately limited to admin-approved active campaigns. */
  getPublic: publicProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const rows = await db.select({ campaign: campaigns }).from(campaigns).innerJoin(tokenListings, eq(campaigns.listingId, tokenListings.id)).where(and(eq(campaigns.id, input.campaignId), ...publicCampaignWindow())).limit(1);
      return rows[0]?.campaign ?? null;
    }),

  publicRequirements: publicProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const visible = await listCurrentPublicCampaigns(100);
      if (!visible.some((campaign) => campaign.id === input.campaignId)) return [];
      const db = await getDb();
      if (!db) return [];
      return db.select({ key: campaignRequirements.requirementKey, label: campaignRequirements.label, threshold: campaignRequirements.threshold, sortOrder: campaignRequirements.sortOrder }).from(campaignRequirements).where(and(eq(campaignRequirements.campaignId, input.campaignId), eq(campaignRequirements.isActive, true))).orderBy(campaignRequirements.sortOrder);
    }),

  /** The backend evaluates progress from confirmed PAXI activity; clients never submit completion flags. */
  myEligibility: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(({ ctx, input }) => evaluateLiveCampaignEligibility(input.campaignId, ctx.user.openId)),

  /**
   * Step 1: the (already-verified) listing owner defines the campaign.
   * Starts as `draft` - it can't go live until the reward pool is funded
   * (see fundPool), so you're never on the hook for payouts you haven't
   * actually received.
   */
  create: protectedProcedure
    .input(
      z.object({
        listingId: z.number().int().positive(),
        title: z.string().trim().min(1).max(128),
        description: z.string().trim().max(2000).optional(),
        banner: campaignImageDataUrl,
        icon: campaignImageDataUrl,
        website: z.string().trim().url().max(500).optional(),
        socials: campaignSocialsSchema.optional(),
        minTokenAmount: z.string().trim().min(1).max(64),
        taskTokenSymbol: z.string().trim().min(1).max(32),
        taskTokenContractAddress: z.string().trim().min(1).max(128),
        taskTokenNetwork: z.string().trim().min(1).max(32),
        rewardAmount: z.string().trim().min(1).max(64),
        rewardValueUsd: z.string().trim().regex(/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/),
        rewardTokenSymbol: z.string().trim().min(1).max(32),
        rewardTokenContractAddress: z.string().trim().max(128).optional(),
        rewardNetwork: z.string().trim().min(1).max(32),
        maxWinners: z.number().int().min(1).max(100_000),
        startAt: z.string().datetime().optional(),
        endAt: z.string().datetime().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const listing = await requireListingOwnerOrAdmin(db, input.listingId, ctx.user.openId, ctx.user.role === "admin");
      let poolRequiredAmountUsd: string;
      try {
        poolRequiredAmountUsd = calculateCampaignPoolUsd(input.rewardValueUsd, input.maxWinners);
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Invalid campaign pool requirement." });
      }

      // A verified listing is the source of truth for the campaign token. This
      // prevents a creator from borrowing an approved listing to advertise a
      // different contract in campaign claims or rewards.
      if (!campaignTokensMatchApprovedListing(input, listing)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Campaign task and reward tokens must match the approved listing." });
      }
      if (input.startAt && input.endAt && new Date(input.endAt) <= new Date(input.startAt)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Campaign end time must be after its start time." });
      }
      const banner = decodeCampaignImage(input.banner, CAMPAIGN_BANNER_MAX_BYTES, "Campaign banner");
      const icon = decodeCampaignImage(input.icon, CAMPAIGN_ICON_MAX_BYTES, "Campaign icon");

      const [result] = await db.insert(campaigns).values({
        listingId: input.listingId,
        title: input.title,
        description: input.description,
        website: input.website,
        socials: input.socials,
        minTokenAmount: input.minTokenAmount,
        taskTokenSymbol: input.taskTokenSymbol,
        taskTokenContractAddress: input.taskTokenContractAddress,
        taskTokenNetwork: input.taskTokenNetwork,
        rewardAmount: input.rewardAmount,
        rewardTokenSymbol: input.rewardTokenSymbol,
        rewardTokenContractAddress: input.rewardTokenContractAddress,
        rewardNetwork: input.rewardNetwork,
        maxWinners: input.maxWinners,
        poolRequiredAmountUsd,
        rewardEscrowRequiredAmount: multiplyDecimalByInteger(input.rewardAmount, input.maxWinners),
        rewardRequiredAmountUnits: null,
        rewardEscrowedAmountUnits: "0",
        rewardReservedAmountUnits: "0",
        rewardClaimedAmountUnits: "0",
        rewardRemainingAmountUnits: "0",
        status: "draft",
        startAt: input.startAt ? new Date(input.startAt) : undefined,
        endAt: input.endAt ? new Date(input.endAt) : undefined,
        createdByOpenId: ctx.user.openId,
      });

      const campaignId = Number(result.insertId);
      const [bannerStored, iconStored] = await Promise.all([
        storagePut(`campaign-assets/campaign/${campaignId}/banner.${banner.extension}`, banner.buffer, banner.contentType),
        storagePut(`campaign-assets/campaign/${campaignId}/icon.${icon.extension}`, icon.buffer, icon.contentType),
      ]);
      await db.update(campaigns).set({ bannerKey: bannerStored.key, iconKey: iconStored.key }).where(eq(campaigns.id, campaignId));
      await ensureDefaultRequirements(campaignId);

      return {
        id: campaignId,
        poolRequiredAmountUsd,
        rewardEscrowRequiredAmount: multiplyDecimalByInteger(input.rewardAmount, input.maxWinners),
      } as const;
    }),

  /**
   * Step 2: owner deposits the exact maxWinners * rewardAmount of the approved
   * reward token to PAXI's server-controlled escrow address. The backend reads
   * token decimals and verifies the mined receipt, sender, token, recipient,
   * and exact raw amount before moving the draft into administrator review.
   */
  fundPool: protectedProcedure
    .input(z.object({
      campaignId: z.number().int().positive(),
      rewardTxHash: z.string().trim().min(1).max(128),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rows = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      const campaign = rows[0];
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      if (ctx.user.role !== "admin" && campaign.createdByOpenId !== ctx.user.openId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You don't own this campaign." });
      }
      await requireListingOwnerOrAdmin(db, campaign.listingId, ctx.user.openId, ctx.user.role === "admin");
      if (campaign.rewardEscrowFundedTxHash) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign's reward escrow is already funded." });
      }
      if (!campaign.bannerKey || !campaign.iconKey) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Campaign banner and icon must be validated before funding submission." });
      }
      if (!campaign.rewardTokenContractAddress || !campaign.rewardEscrowRequiredAmount) {
        throw new TRPCError({ code: "CONFLICT", message: "This campaign is missing its server-derived reward escrow requirements." });
      }

      const verification = await verifyRewardTokenDeposit({
        network: campaign.rewardNetwork,
        transactionHash: input.rewardTxHash,
        tokenContractAddress: campaign.rewardTokenContractAddress,
        requiredHumanAmount: campaign.rewardEscrowRequiredAmount,
      });
      if (!verification.ok) throw new TRPCError({ code: "BAD_REQUEST", message: verification.reason });
      if (verification.tokenSymbol.trim().toLowerCase() !== campaign.rewardTokenSymbol.trim().toLowerCase()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "The deposited token symbol does not match the approved campaign reward token." });
      }

      try {
        await db.transaction(async (tx) => {
          await tx.insert(campaignRewardEscrowVerifications).values({
            campaignId: campaign.id,
            transactionHash: verification.transactionHash,
            network: campaign.rewardNetwork,
            tokenContractAddress: campaign.rewardTokenContractAddress!,
            senderAddress: verification.senderAddress,
            escrowRecipient: verification.escrowRecipient,
            tokenDecimals: verification.tokenDecimals,
            amountUnits: verification.amountUnits,
            status: "verified",
            verificationData: {
              tokenSymbol: verification.tokenSymbol,
              amountHuman: verification.amountHuman,
              blockNumber: verification.blockNumber,
            },
          });
          const updateResult = await tx.update(campaigns).set({
            rewardEscrowFundedTxHash: verification.transactionHash,
            rewardEscrowFundedAt: new Date(),
            rewardEscrowTokenDecimals: verification.tokenDecimals,
            rewardEscrowAmountUnits: verification.amountUnits,
            rewardRequiredAmountUnits: verification.amountUnits,
            rewardEscrowedAmountUnits: verification.amountUnits,
            rewardReservedAmountUnits: "0",
            rewardClaimedAmountUnits: "0",
            rewardRemainingAmountUnits: verification.amountUnits,
            rewardAccountingUpdatedAt: new Date(),
            rewardEscrowRecipient: verification.escrowRecipient,
            rewardEscrowVerification: {
              senderAddress: verification.senderAddress,
              tokenSymbol: verification.tokenSymbol,
              amountHuman: verification.amountHuman,
              blockNumber: verification.blockNumber,
            },
            status: "pending_review",
            submittedAt: new Date(),
          }).where(and(eq(campaigns.id, input.campaignId), isNull(campaigns.rewardEscrowFundedTxHash), eq(campaigns.status, "draft")));
          if (Number((updateResult as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
            throw new TRPCError({ code: "CONFLICT", message: "This campaign has already been funded or is no longer draft." });
          }
        });
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({ code: "CONFLICT", message: "That reward deposit is already linked to another campaign or could not be recorded." });
      }
      await clearCachedFeaturedCampaigns();

      return {
        success: true,
        escrow: {
          transactionHash: verification.transactionHash,
          tokenSymbol: verification.tokenSymbol,
          amountHuman: verification.amountHuman,
          senderAddress: verification.senderAddress,
          escrowRecipient: verification.escrowRecipient,
        },
      } as const;
    }),

  /** Owner or admin can end a campaign early (e.g. pool exhausted, issue found). */
  end: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const rows = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      const campaign = rows[0];
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      if (ctx.user.role !== "admin" && campaign.createdByOpenId !== ctx.user.openId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You don't own this campaign." });
      }
      await db.update(campaigns).set({ status: "ended" }).where(eq(campaigns.id, input.campaignId));
      await clearCachedFeaturedCampaigns();
      return { success: true } as const;
    }),

  myEntry: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;
      const rows = await db
        .select()
        .from(campaignEntries)
        .where(and(eq(campaignEntries.campaignId, input.campaignId), eq(campaignEntries.userOpenId, ctx.user.openId)))
        .limit(1);
      return rows[0] ?? null;
    }),

  /**
   * Converts an eligible winner into a claimable payout request. This does not
   * send tokens; the existing admin payout confirmation remains responsible for
   * recording an on-chain distribution transaction.
   */
  requestClaim: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const eligibility = await evaluateLiveCampaignEligibility(input.campaignId, ctx.user.openId);
      if (!eligibility.eligible) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `You have completed ${eligibility.metRequirements} of ${eligibility.totalRequirements} requirements; ${eligibility.minimumRequired} are required.` });
      }
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      return db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM campaigns WHERE id = ${input.campaignId} FOR UPDATE`);
        const [campaign] = await tx.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
        if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
        const [listing] = await tx.select({ status: tokenListings.status }).from(tokenListings).where(eq(tokenListings.id, campaign.listingId)).limit(1);
        const reason = campaignClaimBlockReason({ status: campaign.status, claimsPaused: campaign.claimsPaused, rewardEscrowFundedTxHash: campaign.rewardEscrowFundedTxHash, listingVerified: listing?.status === "verified", startAt: campaign.startAt, endAt: campaign.endAt });
        if (reason) throw new TRPCError({ code: "BAD_REQUEST", message: reason });
        const [entry] = await tx.select().from(campaignEntries).where(and(eq(campaignEntries.campaignId, campaign.id), eq(campaignEntries.userOpenId, ctx.user.openId))).limit(1);
        if (!entry?.slotNumber) throw new TRPCError({ code: "BAD_REQUEST", message: "A verified campaign task proof and available winner slot are required before claiming." });
        if (entry.payoutStatus === "paid" || entry.payoutStatus === "claimable") return { success: true, status: entry.payoutStatus } as const;
        if (!campaign.rewardEscrowAmountUnits || !campaign.rewardEscrowedAmountUnits) {
          throw new TRPCError({ code: "CONFLICT", message: "Verified reward escrow accounting is missing." });
        }
        const totalUnits = BigInt(campaign.rewardEscrowAmountUnits);
        const winnerUnits = totalUnits / BigInt(campaign.maxWinners);
        if (winnerUnits <= 0n || totalUnits % BigInt(campaign.maxWinners) !== 0n) {
          throw new TRPCError({ code: "CONFLICT", message: "Campaign escrow cannot be divided into exact winner payouts." });
        }
        const accounting = {
          rewardRequired: BigInt(campaign.rewardRequiredAmountUnits || campaign.rewardEscrowAmountUnits),
          rewardEscrowed: BigInt(campaign.rewardEscrowedAmountUnits || campaign.rewardEscrowAmountUnits),
          rewardReserved: BigInt(campaign.rewardReservedAmountUnits || "0"),
          rewardClaimed: BigInt(campaign.rewardClaimedAmountUnits || "0"),
          rewardRemaining: BigInt(campaign.rewardRemainingAmountUnits || campaign.rewardEscrowAmountUnits),
        };
        try { assertRewardAccounting(accounting); } catch (error) { throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: error instanceof Error ? error.message : "Reward accounting invariant failed." }); }
        let reservedAccounting;
        try { reservedAccounting = reserveReward(accounting, winnerUnits); } catch (error) { throw new TRPCError({ code: "CONFLICT", message: error instanceof Error ? error.message : "The campaign has no unreserved reward balance remaining." }); }
        const updated = await tx.update(campaignEntries).set({ payoutStatus: "claimable", claimRequestedAt: new Date() }).where(and(eq(campaignEntries.id, entry.id), eq(campaignEntries.payoutStatus, "pending")));
        if (Number((updated as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new TRPCError({ code: "CONFLICT", message: "Claim request changed concurrently; reload and try again." });
        await tx.update(campaigns).set({
          rewardReservedAmountUnits: reservedAccounting.rewardReserved.toString(),
          rewardRemainingAmountUnits: reservedAccounting.rewardRemaining.toString(),
          rewardAccountingUpdatedAt: new Date(),
        }).where(eq(campaigns.id, campaign.id));
        return { success: true, status: "claimable" } as const;
      });
    }),

  /**
   * User submits the swap tx that (they say) meets the task requirement.
   * Verified on-chain, then a winner slot is claimed atomically - a row
   * lock on the campaign serializes concurrent claims so two people can
   * never both land slot #100. See feeVerification.ts for what this proof
   * does and doesn't guarantee.
   */
  submitTaskProof: protectedProcedure
    .input(z.object({ campaignId: z.number().int().positive(), walletAddress: z.string().trim().min(1).max(128), swapTxHash: z.string().trim().min(1).max(128) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const rows = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      const campaign = rows[0];
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      if (campaign.status !== "active") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign isn't active." });
      }
      const [listing] = await db.select({ status: tokenListings.status }).from(tokenListings).where(eq(tokenListings.id, campaign.listingId)).limit(1);
      if (listing?.status !== "verified") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign's listing is no longer approved." });
      }
      const now = new Date();
      if (campaign.startAt && now < campaign.startAt) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign hasn't started yet." });
      }
      if (campaign.endAt && now > campaign.endAt) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign has ended." });
      }
      if (!campaign.taskTokenContractAddress) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "This campaign's task token isn't configured for verification." });
      }

      const verification = await verifyTokenTransferProof(
        campaign.taskTokenNetwork,
        input.swapTxHash,
        campaign.taskTokenContractAddress,
        input.walletAddress,
        campaign.minTokenAmount,
      );
      if (!verification.ok) throw new TRPCError({ code: "BAD_REQUEST", message: verification.reason });

      return db.transaction(async (tx) => {
        // Lock the campaign row so concurrent claims serialize instead of racing.
        await tx.execute(sql`SELECT id FROM campaigns WHERE id = ${input.campaignId} FOR UPDATE`);

        const fresh = await tx.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
        const [existingEntry] = await tx
          .select()
          .from(campaignEntries)
          .where(and(eq(campaignEntries.campaignId, input.campaignId), eq(campaignEntries.userOpenId, ctx.user.openId)))
          .limit(1);
        const [proofUsed] = await tx
          .select({ id: campaignEntries.id, userOpenId: campaignEntries.userOpenId })
          .from(campaignEntries)
          .where(eq(campaignEntries.proofTxHash, input.swapTxHash))
          .limit(1);
        if (proofUsed && proofUsed.userOpenId !== ctx.user.openId) {
          throw new TRPCError({ code: "CONFLICT", message: "This transaction proof has already been used." });
        }
        if (existingEntry?.slotNumber != null) {
          return { success: true, slotNumber: existingEntry.slotNumber } as const;
        }
        if (!fresh[0] || fresh[0].winnersCount >= fresh[0].maxWinners) {
          // Still record the entry (they did the trade) but with no slot - all winner spots are gone.
          if (existingEntry) {
            await tx.update(campaignEntries).set({ payoutWalletAddress: input.walletAddress, progressAmount: campaign.minTokenAmount, proofTxHash: input.swapTxHash, qualifiedAt: new Date() }).where(eq(campaignEntries.id, existingEntry.id));
          } else {
            await tx.insert(campaignEntries).values({
              campaignId: input.campaignId,
              userOpenId: ctx.user.openId,
              payoutWalletAddress: input.walletAddress,
              progressAmount: campaign.minTokenAmount,
              proofTxHash: input.swapTxHash,
              qualifiedAt: new Date(),
            });
          }
          throw new TRPCError({ code: "BAD_REQUEST", message: "All winner slots for this campaign are already claimed." });
        }

        const nextSlot = fresh[0].winnersCount + 1;

        if (existingEntry) {
          await tx.update(campaignEntries).set({
            payoutWalletAddress: input.walletAddress,
            progressAmount: campaign.minTokenAmount,
            slotNumber: nextSlot,
            qualifiedAt: new Date(),
            proofTxHash: input.swapTxHash,
          }).where(eq(campaignEntries.id, existingEntry.id));
        } else {
          await tx.insert(campaignEntries).values({
            campaignId: input.campaignId,
            userOpenId: ctx.user.openId,
            payoutWalletAddress: input.walletAddress,
            progressAmount: campaign.minTokenAmount,
            slotNumber: nextSlot,
            qualifiedAt: new Date(),
            proofTxHash: input.swapTxHash,
          });
        }

        await tx.update(campaigns).set({ winnersCount: nextSlot }).where(eq(campaigns.id, input.campaignId));

        return { success: true, slotNumber: nextSlot } as const;
      });
    }),

  // --- Admin ---

  adminListPendingReview: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(campaigns).where(eq(campaigns.status, "pending_review")).orderBy(desc(campaigns.submittedAt)).limit(200);
  }),

  adminReview: adminProcedure
    .input(z.object({ campaignId: z.number().int().positive(), decision: z.enum(["active", "rejected"]), rejectionReason: z.string().trim().max(2000).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      if (!campaign || (input.decision === "active" && !campaignCanPublish(campaign))) {
        throw new TRPCError({ code: "CONFLICT", message: "Campaign is missing verified escrow or private campaign assets." });
      }
      if (input.decision === "active") {
        const requirements = await ensureDefaultRequirements(campaign.id);
        if (requirements.filter((requirement) => requirement.isActive).length !== 10) {
          throw new TRPCError({ code: "CONFLICT", message: "Campaign requires exactly ten active requirements before approval." });
        }
      }
      const updateResult = await db
        .update(campaigns)
        .set({
          status: input.decision,
          reviewedAt: new Date(),
          reviewedByOpenId: ctx.user.openId,
          rejectionReason: input.decision === "rejected" ? input.rejectionReason ?? "Campaign did not meet review requirements." : null,
        })
        .where(and(eq(campaigns.id, input.campaignId), eq(campaigns.status, "pending_review")));
      if (Number((updateResult as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
        throw new TRPCError({ code: "CONFLICT", message: "Campaign is no longer awaiting review." });
      }
      await db.insert(adminAuditEvents).values({
        actorOpenId: ctx.user.openId,
        action: input.decision === "active" ? "APPROVE_CAMPAIGN" : "REJECT_CAMPAIGN",
        resourceType: "campaign",
        resourceId: input.campaignId,
        details: { decision: input.decision, rejectionReason: input.decision === "rejected" ? input.rejectionReason ?? null : null },
      });
      await clearCachedFeaturedCampaigns();
      return { success: true } as const;
    }),

  adminSetOperations: adminProcedure
    .input(z.object({ campaignId: z.number().int().positive(), isFeatured: z.boolean().optional(), claimsPaused: z.boolean().optional(), suspended: z.boolean().optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, input.campaignId)).limit(1);
      if (!campaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found." });
      const values: Partial<typeof campaigns.$inferInsert> = {};
      if (input.isFeatured !== undefined) {
        values.isFeatured = input.isFeatured;
        values.featuredAt = input.isFeatured ? new Date() : null;
      }
      if (input.claimsPaused !== undefined) values.claimsPaused = input.claimsPaused;
      if (input.suspended === true) {
        if (campaign.status !== "active") throw new TRPCError({ code: "CONFLICT", message: "Only active campaigns can be suspended." });
        values.status = "suspended";
      }
      if (input.suspended === false) {
        if (campaign.status !== "suspended") throw new TRPCError({ code: "CONFLICT", message: "Only suspended campaigns can be resumed." });
        values.status = "active";
      }
      if (Object.keys(values).length === 0) throw new TRPCError({ code: "BAD_REQUEST", message: "No campaign operation was requested." });
      await db.update(campaigns).set(values).where(eq(campaigns.id, campaign.id));
      await db.insert(adminAuditEvents).values({
        actorOpenId: ctx.user.openId,
        action: "UPDATE_CAMPAIGN_OPERATIONS",
        resourceType: "campaign",
        resourceId: campaign.id,
        details: { isFeatured: input.isFeatured, claimsPaused: input.claimsPaused, suspended: input.suspended },
      });
      await clearCachedFeaturedCampaigns();
      return { success: true } as const;
    }),

  adminListOperational: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(campaigns).where(or(eq(campaigns.status, "active"), eq(campaigns.status, "suspended"))).orderBy(desc(campaigns.isFeatured), desc(campaigns.updatedAt)).limit(200);
  }),

  adminListEntries: adminProcedure
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(campaignEntries).where(eq(campaignEntries.campaignId, input.campaignId));
    }),

  /**
   * Reserves one payout attempt durably and treats the transaction hash as the
   * idempotency anchor. A timeout never releases the reward or creates another
   * transfer; only an explicit reverted receipt permits a new nonce.
   */
  markPayout: adminProcedure
    .input(z.object({ entryId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const idempotencyKey = `campaign-entry:${input.entryId}`;
      const reservation = await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM campaignEntries WHERE id = ${input.entryId} FOR UPDATE`);
        const [entry] = await tx.select().from(campaignEntries).where(eq(campaignEntries.id, input.entryId)).limit(1);
        if (!entry) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign entry not found." });
        const [campaign] = await tx.select().from(campaigns).where(eq(campaigns.id, entry.campaignId)).limit(1);
        if (!campaign || !campaign.rewardTokenContractAddress || !campaign.rewardEscrowAmountUnits) {
          throw new TRPCError({ code: "CONFLICT", message: "Verified campaign escrow metadata is missing." });
        }
        const [existing] = await tx.select().from(campaignPayouts).where(eq(campaignPayouts.entryId, entry.id)).limit(1);
        if (existing?.status === "confirmed" && existing.transactionHash) return { entry, campaign, payout: existing } as const;
        if (entry.payoutStatus !== "claimable") throw new TRPCError({ code: "CONFLICT", message: "Only claimable campaign rewards can be paid." });
        if (!entry.payoutWalletAddress) throw new TRPCError({ code: "CONFLICT", message: "Winner wallet evidence is missing." });
        const totalUnits = BigInt(campaign.rewardEscrowAmountUnits);
        const winnerUnits = totalUnits / BigInt(campaign.maxWinners);
        if (winnerUnits <= 0n || totalUnits % BigInt(campaign.maxWinners) !== 0n) throw new TRPCError({ code: "CONFLICT", message: "Campaign escrow cannot be divided into exact winner payouts." });
        if (existing) return { entry, campaign, payout: existing } as const;
        const nonceInfo = await getNextPayoutNonce();
        const [created] = await tx.insert(campaignPayouts).values({
          campaignId: campaign.id,
          entryId: entry.id,
          idempotencyKey,
          network: campaign.rewardNetwork,
          tokenContractAddress: campaign.rewardTokenContractAddress,
          recipientAddress: entry.payoutWalletAddress,
          senderAddress: nonceInfo.senderAddress,
          amountUnits: winnerUnits.toString(),
          nonce: nonceInfo.nonce,
          nonceKey: nonceInfo.senderAddress.toLowerCase() + ":" + nonceInfo.nonce,
          status: "reserved",
        }).$returningId();
        const [payout] = await tx.select().from(campaignPayouts).where(eq(campaignPayouts.id, Number(created.id))).limit(1);
        if (!payout) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Payout reservation was not created." });
        return { entry, campaign, payout } as const;
      });

      const { entry, campaign } = reservation;
      let payout = reservation.payout;
      if (payout.status === "confirmed" && payout.transactionHash) return { success: true, payoutTxHash: payout.transactionHash } as const;
      if (!entry.payoutWalletAddress || !campaign.rewardTokenContractAddress) throw new TRPCError({ code: "CONFLICT", message: "Winner payout metadata is incomplete." });

      const inspect = async (hash: string) => inspectCampaignPayout({
        network: payout.network,
        transactionHash: hash,
        tokenContractAddress: payout.tokenContractAddress,
        recipientAddress: payout.recipientAddress,
        amountUnits: payout.amountUnits,
        expectedSenderAddress: payout.senderAddress ?? undefined,
      });

      if (payout.transactionHash) {
        const state = await inspect(payout.transactionHash);
        if (state.state === "confirmed") {
          await db.update(campaignPayouts).set({ status: "broadcast", lastError: null, broadcastLeaseUntil: null }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.transactionHash, payout.transactionHash)));
        } else if (state.state === "reverted") {
          const nonceInfo = await getNextPayoutNonce();
          const oldHash = payout.transactionHash;
          const reset = await db.update(campaignPayouts).set({ status: "reserved", transactionHash: null, nonce: nonceInfo.nonce, nonceKey: nonceInfo.senderAddress.toLowerCase() + ":" + nonceInfo.nonce, senderAddress: nonceInfo.senderAddress, broadcastAt: null, broadcastLeaseUntil: null, lastError: "Previous payout transaction " + oldHash + " reverted; replacement nonce reserved." }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.transactionHash, oldHash), or(eq(campaignPayouts.status, "broadcast"), eq(campaignPayouts.status, "recovery_required"))));
          if (Number((reset as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new TRPCError({ code: "CONFLICT", message: "Payout recovery changed concurrently; reload and retry." });
          throw new TRPCError({ code: "CONFLICT", message: "The previous payout reverted. A replacement nonce is reserved; retry to broadcast the replacement." });
        } else {
          await db.update(campaignPayouts).set({ status: state.state === "invalid" ? "recovery_required" : "broadcast", broadcastLeaseUntil: null, lastError: state.reason }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.transactionHash, payout.transactionHash)));
          throw new TRPCError({ code: "CONFLICT", message: state.reason });
        }
      } else {
        const leaseUntil = new Date(Date.now() + 60_000);
        const lease = await db.update(campaignPayouts).set({ broadcastLeaseUntil: leaseUntil, lastError: null }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.status, "reserved"), isNull(campaignPayouts.transactionHash), or(isNull(campaignPayouts.broadcastLeaseUntil), lte(campaignPayouts.broadcastLeaseUntil, new Date()))));
        if (Number((lease as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new TRPCError({ code: "CONFLICT", message: "Another payout request is already broadcasting or recovering this reward." });
        try {
          const broadcast = await sendCampaignReward({ network: payout.network, tokenContractAddress: payout.tokenContractAddress, recipientAddress: payout.recipientAddress, amountUnits: payout.amountUnits, nonce: payout.nonce ?? undefined });
          const persisted = await db.update(campaignPayouts).set({ status: "broadcast", transactionHash: broadcast.transactionHash, senderAddress: broadcast.senderAddress, broadcastAt: new Date(), broadcastLeaseUntil: null, lastError: null }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.status, "reserved"), isNull(campaignPayouts.transactionHash)));
          if (Number((persisted as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
            await db.update(campaignPayouts).set({ status: "recovery_required", transactionHash: broadcast.transactionHash, senderAddress: broadcast.senderAddress, broadcastAt: new Date(), broadcastLeaseUntil: null, lastError: "Broadcast succeeded but the payout state changed before its hash was persisted." }).where(eq(campaignPayouts.id, payout.id));
            throw new Error("Payout broadcast succeeded but persistence raced; recover the recorded transaction hash before retrying.");
          }
          payout = { ...payout, status: "broadcast", transactionHash: broadcast.transactionHash, senderAddress: broadcast.senderAddress };
        } catch (error) {
          const knownHash = error instanceof Error && /0x[0-9a-fA-F]{64}/.test(error.message) ? error.message.match(/0x[0-9a-fA-F]{64}/)?.[0] : null;
          await db.update(campaignPayouts).set({ status: "recovery_required", transactionHash: knownHash ?? payout.transactionHash, broadcastLeaseUntil: null, lastError: error instanceof Error ? error.message : "Broadcast outcome is uncertain; recovery is required." }).where(eq(campaignPayouts.id, payout.id));
          throw new TRPCError({ code: "CONFLICT", message: error instanceof Error ? error.message : "Payout broadcast outcome is uncertain; recovery is required before retrying." });
        }
      }

      if (!payout.transactionHash) throw new TRPCError({ code: "CONFLICT", message: "Payout transaction hash is missing; reservation retained for recovery." });
      const finalState = await inspect(payout.transactionHash);
      if (finalState.state !== "confirmed") {
        if (finalState.state === "reverted") {
          await db.update(campaignPayouts).set({ status: "recovery_required", broadcastLeaseUntil: null, lastError: finalState.reason }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.transactionHash, payout.transactionHash)));
        } else {
          await db.update(campaignPayouts).set({ status: finalState.state === "invalid" ? "recovery_required" : "broadcast", broadcastLeaseUntil: null, lastError: finalState.reason }).where(and(eq(campaignPayouts.id, payout.id), eq(campaignPayouts.transactionHash, payout.transactionHash)));
        }
        throw new TRPCError({ code: "CONFLICT", message: finalState.reason });
      }

      const transactionHash = payout.transactionHash;
      const blockNumber = finalState.blockNumber;
      await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM campaignPayouts WHERE id = ${payout.id} FOR UPDATE`);
        const [freshPayout] = await tx.select().from(campaignPayouts).where(eq(campaignPayouts.id, payout.id)).limit(1);
        if (freshPayout?.status === "confirmed") return;
        if (!freshPayout || freshPayout.transactionHash !== transactionHash) throw new TRPCError({ code: "CONFLICT", message: "Payout attempt changed concurrently; reload and retry." });
        const updated = await tx.update(campaignEntries).set({ payoutStatus: "paid", payoutTxHash: transactionHash }).where(and(eq(campaignEntries.id, entry.id), eq(campaignEntries.payoutStatus, "claimable")));
        if (Number((updated as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new TRPCError({ code: "CONFLICT", message: "Campaign payout changed concurrently; reload and retry." });
        const [freshCampaign] = await tx.select().from(campaigns).where(eq(campaigns.id, campaign.id)).limit(1);
        if (!freshCampaign) throw new TRPCError({ code: "NOT_FOUND", message: "Campaign not found during payout finalization." });
        await tx.update(campaignPayouts).set({ status: "confirmed", confirmedBlockNumber: blockNumber, confirmedAt: new Date(), broadcastLeaseUntil: null, lastError: null, senderAddress: finalState.senderAddress }).where(eq(campaignPayouts.id, payout.id));
        const accounting = { rewardRequired: BigInt(freshCampaign.rewardRequiredAmountUnits || freshCampaign.rewardEscrowAmountUnits || "0"), rewardEscrowed: BigInt(freshCampaign.rewardEscrowedAmountUnits || freshCampaign.rewardEscrowAmountUnits || "0"), rewardReserved: BigInt(freshCampaign.rewardReservedAmountUnits || "0"), rewardClaimed: BigInt(freshCampaign.rewardClaimedAmountUnits || "0"), rewardRemaining: BigInt(freshCampaign.rewardRemainingAmountUnits || "0") };
        const confirmedAccounting = confirmReward(accounting, BigInt(payout.amountUnits));
        await tx.update(campaigns).set({ rewardReservedAmountUnits: confirmedAccounting.rewardReserved.toString(), rewardClaimedAmountUnits: confirmedAccounting.rewardClaimed.toString(), rewardAccountingUpdatedAt: new Date() }).where(eq(campaigns.id, campaign.id));
        await tx.insert(adminAuditEvents).values({ actorOpenId: ctx.user.openId, action: "PAY_CAMPAIGN_REWARD", resourceType: "campaign_entry", resourceId: entry.id, details: { payoutTxHash: transactionHash, recipient: entry.payoutWalletAddress, amountUnits: payout.amountUnits, blockNumber } });
      });
      return { success: true, payoutTxHash: transactionHash } as const;
    }),
});
