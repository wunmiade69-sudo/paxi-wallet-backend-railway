import { publicProcedure, router } from "../_core/trpc";
import { getDiscoverProtocolStats } from "../discoverStats";

export const discoverRouter = router({
  /** Real TVL + 1d/7d change for curated dApps that have on-chain TVL (see discoverStats.ts for which ones and why). */
  protocolStats: publicProcedure.query(async () => getDiscoverProtocolStats()),
});
