import { z } from "zod";
import { adminPermissionProcedure, router } from "../_core/trpc";
import {
  ensureDefaultRequirements,
  evaluateSnapshotRequirements,
  listEligibilityResults,
  listTierMultipliers,
  setTierMultiplier,
} from "../eligibility/requirementService";

const multiplierSchema = z.string().trim().regex(/^(?:0|[1-9]\d{0,27})(?:\.\d{1,18})?$/).refine((value) => value !== "0", "Multiplier must be positive");

export const eligibilityRouter = router({
  ensureDefaults: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ campaignId: z.number().int().positive() }))
    .mutation(({ input }) => ensureDefaultRequirements(input.campaignId)),

  tierMultipliers: adminPermissionProcedure("campaigns.read")
    .input(z.object({ campaignId: z.number().int().positive() }))
    .query(({ input }) => listTierMultipliers(input.campaignId)),

  setTierMultiplier: adminPermissionProcedure("campaigns.manage")
    .input(z.object({
      campaignId: z.number().int().positive(),
      tier: z.enum(["minimum", "highest"]),
      multiplier: multiplierSchema,
    }))
    .mutation(({ input }) => setTierMultiplier(input.campaignId, input.tier, input.multiplier)),

  evaluateSnapshot: adminPermissionProcedure("campaigns.manage")
    .input(z.object({ snapshotId: z.number().int().positive() }))
    .mutation(({ input }) => evaluateSnapshotRequirements(input.snapshotId)),

  results: adminPermissionProcedure("campaigns.read")
    .input(z.object({
      snapshotId: z.number().int().positive(),
      tier: z.enum(["not_qualified", "minimum", "highest"]).optional(),
    }))
    .query(({ input }) => listEligibilityResults(input.snapshotId, input.tier)),
});
