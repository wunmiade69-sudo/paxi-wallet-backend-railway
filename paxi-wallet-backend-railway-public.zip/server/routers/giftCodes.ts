import { z } from "zod";
import { and, desc, eq } from "drizzle-orm";
import { assets } from "../../drizzle/schema";
import { getReadDb } from "../db";
import { adminProcedure, protectedProcedure, router } from "../_core/trpc";
import { createGiftCode, disableGiftCodeForAdmin, redeemGiftCode } from "../giftCodes/giftCodeService";
import { isDirectGiftCodeFulfillmentSupported } from "../rewards/rewardTransferService";
import { giftCodeAnalytics, listGiftCodes, listRedemptions } from "../giftCodes/giftCodeRepository";

const paginationSchema = z.object({ limit: z.number().int().min(1).max(100).default(50), offset: z.number().int().min(0).max(100_000).default(0) });
const assetSchema = z.object({
  assetId: z.number().int().positive().optional(),
  assetSymbol: z.string().trim().min(1).max(32).optional(),
  assetNetwork: z.string().trim().min(1).max(32).optional(),
  assetContractAddress: z.string().trim().max(128).nullable().optional(),
  rewardAmount: z.string().trim().regex(/^(?:0|[1-9]\d{0,37})(?:\.\d{1,36})?$/).refine((value) => value !== "0", "Reward amount must be positive"),
});

export const giftCodesRouter = router({
  assets: adminProcedure.query(async () => {
    const db = await getReadDb();
    if (!db) return [];
    const rows = await db.select({ id: assets.id, chainId: assets.chainId, symbol: assets.symbol, name: assets.name, identifier: assets.identifier, decimals: assets.decimals, verificationStatus: assets.verificationStatus }).from(assets).where(and(eq(assets.status, "active"), eq(assets.verificationStatus, "verified"))).orderBy(desc(assets.symbol), assets.chainId);
    return rows.map((asset) => ({ ...asset, fulfillmentSupported: isDirectGiftCodeFulfillmentSupported(asset.chainId), fulfillmentLabel: asset.chainId.toLowerCase() === "ton" ? "Coming soon" : undefined }));
  }),

  create: adminProcedure
    .input(assetSchema.extend({ maxRedemptions: z.number().int().min(1).max(1_000_000), expiresAtMs: z.number().int().positive().optional() }))
    .mutation(({ ctx, input }) => createGiftCode({
      createdByOpenId: ctx.user.openId,
      assetId: input.assetId,
      assetSymbol: input.assetSymbol,
      assetNetwork: input.assetNetwork,
      assetContractAddress: input.assetContractAddress,
      rewardAmount: input.rewardAmount,
      maxRedemptions: input.maxRedemptions,
      expiresAt: input.expiresAtMs ? new Date(input.expiresAtMs) : null,
    })),

  redeem: protectedProcedure
    .input(z.object({ code: z.string().trim().min(6).max(32), recipientWalletAddress: z.string().trim().min(20).max(128) }))
    .mutation(({ ctx, input }) => redeemGiftCode(ctx.user.openId, input.code, input.recipientWalletAddress)),

  list: adminProcedure.input(paginationSchema.extend({ status: z.enum(["active", "paused", "exhausted", "expired", "cancelled"]).optional() })).query(({ input }) => listGiftCodes(input)),
  listRedemptions: adminProcedure.input(paginationSchema.extend({ giftCodeId: z.number().int().positive().optional() })).query(({ input }) => listRedemptions(input)),
  myRedemptions: protectedProcedure.input(paginationSchema).query(({ ctx, input }) => listRedemptions({ ...input, userOpenId: ctx.user.openId })),
  disable: adminProcedure.input(z.object({ giftCodeId: z.number().int().positive() })).mutation(({ ctx, input }) => disableGiftCodeForAdmin(ctx.user.openId, input.giftCodeId)),
  analytics: adminProcedure.query(() => giftCodeAnalytics()),
});
