import { z } from "zod";
import { adminPermissionProcedure, protectedProcedure, router } from "../_core/trpc";
import { createGiftCode, previewGiftCode, redeemGiftCode } from "../rewards/rewardService";

const assetSchema = z.object({
  assetSymbol: z.string().trim().min(1).max(32),
  assetNetwork: z.string().trim().min(1).max(32),
  assetContractAddress: z.string().trim().max(128).nullable().optional(),
  rewardAmount: z.string().trim().regex(/^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/).refine((value) => value !== "0", "Reward amount must be positive"),
});

export const giftCodesRouter = router({
  create: adminPermissionProcedure("rewards.manage")
    .input(assetSchema.extend({
      maxRedemptions: z.number().int().min(1).max(1_000_000),
      expiresAtMs: z.number().int().positive().optional(),
    }))
    .mutation(({ ctx, input }) => createGiftCode({
      createdByOpenId: ctx.user.openId,
      assetSymbol: input.assetSymbol,
      assetNetwork: input.assetNetwork,
      assetContractAddress: input.assetContractAddress,
      rewardAmount: input.rewardAmount,
      maxRedemptions: input.maxRedemptions,
      expiresAt: input.expiresAtMs ? new Date(input.expiresAtMs) : null,
    })),

  preview: protectedProcedure
    .input(z.object({ code: z.string().trim().min(6).max(32) }))
    .query(({ ctx, input }) => previewGiftCode(ctx.user.openId, input.code)),

  redeem: protectedProcedure
    .input(z.object({
      code: z.string().trim().min(6).max(32),
      recipientWalletAddress: z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/).optional(),
    }))
    .mutation(({ ctx, input }) => redeemGiftCode(ctx.user.openId, input.code, input.recipientWalletAddress)),
});
