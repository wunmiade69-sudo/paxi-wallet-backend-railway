import { z } from "zod";
import { listMarketTokens, searchMarketTokens, getTokenDetail, getMarketChart, getAssetStats } from "../marketData";
import { normalizeMarketChain, type MarketChain } from "../marketProviders";
import { getAssetPrice, getNativeAssetPrice, getAssetPriceBatch } from "../priceEngine";
import { getJupiterToken } from "../jupiter";
import { publicProcedure, router } from "../_core/trpc";

const orderEnum = z.enum([
  "market_cap_desc",
  "price_change_percentage_24h_desc",
  "price_change_percentage_24h_asc",
  "volume_desc",
]);

const marketIdentityInput = z.object({
  chain: z.string().trim().min(1).max(32).optional(),
  contractAddress: z.string().trim().min(1).max(128).optional(),
  coinId: z.string().trim().min(1).max(128).optional(),
  symbol: z.string().trim().max(64).optional(),
  name: z.string().trim().max(128).optional(),
}).refine((value) => Boolean(value.coinId || (value.chain && value.contractAddress)), {
  message: "Provide coinId or both chain and contractAddress/mint",
});

export const marketRouter = router({
  list: publicProcedure
    .input(
      z.object({
        page: z.number().min(1).max(50).default(1),
        perPage: z.number().min(1).max(100).default(50),
        order: orderEnum.default("market_cap_desc"),
      })
    )
    .query(async ({ input }) => listMarketTokens(input)),

  search: publicProcedure
    .input(z.object({ query: z.string().trim().min(1).max(128) }))
    .query(async ({ input }) => searchMarketTokens(input.query)),

  /** Server-only Jupiter lookup for exact Solana mint metadata. */
  jupiterToken: publicProcedure
    .input(z.object({ mint: z.string().trim().min(32).max(44) }))
    .query(async ({ input }) => getJupiterToken(input.mint)),

  detail: publicProcedure.input(marketIdentityInput).query(async ({ input }) => getTokenDetail({
    chain: normalizeMarketChain(input.chain) as MarketChain | null,
    contractAddress: input.contractAddress ?? null,
    coinId: input.coinId ?? null,
  })),

  chart: publicProcedure
    .input(marketIdentityInput.extend({ timeframe: z.enum(["1H", "1D", "1W", "1M", "3M", "1Y", "ALL"]) }))
    .query(async ({ input }) => getMarketChart({
      chain: normalizeMarketChain(input.chain) as MarketChain | null,
      contractAddress: input.contractAddress ?? null,
      coinId: input.coinId ?? null,
    }, input.timeframe)),

  /**
   * Canonical price for a token not covered by Binance/CoinGecko (most
   * imported/custom tokens) - server-side DexScreener + on-chain reserve
   * fallback, cached and shared across every wallet asking about the same
   * token instead of each one hitting DexScreener/RPC independently.
   * `symbol`/`decimals` only matter the very first time this token is
   * looked up (used to create its asset row) - omit them on later calls.
   */
  assetStats: publicProcedure
    .input(z.object({
      coinId: z.string().trim().min(1).max(128).optional(),
      network: z.string().trim().min(1).max(32).optional(),
      contractAddress: z.string().trim().min(1).max(128).optional(),
    }))
    .query(async ({ input }) => getAssetStats(input)),

  assetPrice: publicProcedure
    .input(
      z.object({
        network: z.string().trim().min(1).max(32),
        contractAddress: z.string().trim().min(1).max(128),
        symbol: z.string().trim().max(64).optional(),
        decimals: z.number().optional(),
      }),
    )
    .query(async ({ input }) => getAssetPrice(input)),

  nativePrice: publicProcedure
    .input(z.object({ network: z.string().trim().min(1).max(32) }))
    .query(async ({ input }) => getNativeAssetPrice(input.network)),

  portfolioQuotes: publicProcedure
    .input(z.object({
      assets: z.array(z.object({
        network: z.string().trim().min(1).max(32),
        isNative: z.boolean(),
        contractAddress: z.string().trim().min(1).max(128).optional(),
        symbol: z.string().trim().max(64).optional(),
        decimals: z.number().finite().min(0).max(255).optional(),
      })).max(100),
    }))
    .query(async ({ input }) => getAssetPriceBatch(input.assets)),
});
