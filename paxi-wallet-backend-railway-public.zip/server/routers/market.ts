import { z } from "zod";
import {
  listMarketTokens,
  searchMarketTokens,
  getTokenDetail,
  getMarketChart,
  getAssetStats,
} from "../marketData";
import { getAssetPrice, getNativeAssetPrice } from "../priceEngine";
import { getChartData, type ChartTimeframe } from "../chartService";
import { getOrCreateAsset, normalizeIdentifier } from "../assetRegistry";
import { getReadDb } from "../db";
import { timestampMs } from "../providers/types";
import { getProviderHealth } from "../providers/health";
import { discoverTokens, getTokenByCanonicalIdentity } from "../tokenDiscovery";
import { adminProcedure, publicProcedure, router } from "../_core/trpc";

const orderEnum = z.enum([
  "market_cap_desc",
  "price_change_percentage_24h_desc",
  "price_change_percentage_24h_asc",
  "volume_desc",
]);

const TIMEFRAME_TO_DAYS: Record<string, number | "max"> = {
  "1H": 1,
  "1D": 1,
  "1W": 7,
  "1M": 30,
  "1Y": 365,
  ALL: "max",
};

const COINGECKO_PLATFORM_TO_CHAIN: Record<string, string> = {
  ethereum: "ethereum",
  "binance-smart-chain": "bsc",
  "polygon-pos": "polygon",
  "arbitrum-one": "arbitrum",
  solana: "solana",
};

/**
 * Maps common native asset coinIds to our chain identifiers.
 */
const NATIVE_COIN_TO_CHAIN: Record<string, string> = {
  bitcoin: "bitcoin",
  ethereum: "ethereum",
  binancecoin: "bsc",
  solana: "solana",
  "polygon-ecosystem-token": "polygon",
};

export const marketRouter = router({
  list: publicProcedure
    .input(
      z.object({
        page: z.number().min(1).max(50).default(1),
        perPage: z.number().min(1).max(100).default(50),
        order: orderEnum.default("market_cap_desc"),
      })
    )
    .query(async ({ input }) => listMarketTokens(input)),

  search: publicProcedure
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => searchMarketTokens(input.query)),

  /** Canonical global discovery. Results are always chain + contract identities and never name-only tokens. */
  discover: publicProcedure
    .input(
      z.object({
        query: z.string().trim().min(1).max(128),
        preferredChain: z.string().trim().max(32).optional(),
      })
    )
    .query(({ input }) => discoverTokens(input.query, input.preferredChain)),

  detail: publicProcedure
    .input(z.object({ coinId: z.string() }))
    .query(async ({ input }) => getTokenDetail(input.coinId)),

  detailByIdentity: publicProcedure
    .input(
      z.object({
        chainId: z.string().trim().min(1).max(32),
        contractAddress: z.string().trim().min(1).max(128),
      })
    )
    .query(({ input }) =>
      getTokenByCanonicalIdentity(input.chainId, input.contractAddress)
    ),

  chart: publicProcedure
    .input(
      z.object({
        coinId: z.string(),
        timeframe: z.enum(["1H", "1D", "1W", "1M", "1Y", "ALL"]),
      })
    )
    .query(async ({ input }) => {
      try {
        const db = await getReadDb();
        if (db) {
          let chainId: string | null = null;
          let tokenAddress: string | null = null;

          // 1. Check if it's an explicit chain:address format
          if (input.coinId.includes(":")) {
            const parts = input.coinId.split(":");
            chainId = parts[0];
            tokenAddress = parts.slice(1).join(":");
          }
          // 2. Check if it's a known native asset
          else if (NATIVE_COIN_TO_CHAIN[input.coinId]) {
            chainId = NATIVE_COIN_TO_CHAIN[input.coinId];
            tokenAddress = "native";
          }
          // 3. Fallback to CoinGecko detail resolution for other tokens
          else {
            const detail = await getTokenDetail(input.coinId);
            if (detail?.platformId) {
              chainId = COINGECKO_PLATFORM_TO_CHAIN[detail.platformId] ?? null;
              tokenAddress = detail.contractAddress;
            }
          }

          if (chainId && tokenAddress) {
            const asset = await getOrCreateAsset({
              chainId,
              identifier: tokenAddress,
              symbol: input.coinId.toUpperCase(),
              name: input.coinId,
            });
            if (asset) {
              const TIMEFRAME_MAP: Record<
                string,
                { tf: ChartTimeframe; limit: number }
              > = {
                "1H": { tf: "5m", limit: 60 },
                "1D": { tf: "1h", limit: 24 },
                "1W": { tf: "4h", limit: 42 },
                "1M": { tf: "1d", limit: 30 },
                "1Y": { tf: "1d", limit: 365 },
                ALL: { tf: "1d", limit: 1000 },
              };
              const conf = TIMEFRAME_MAP[input.timeframe] ?? {
                tf: "1d",
                limit: 30,
              };
              const chartResult = await getChartData({
                db,
                assetId: asset.id,
                chainId,
                tokenAddress,
                timeframe: conf.tf,
                limit: conf.limit,
              });
              if (chartResult.candles.length > 0) {
                return chartResult.candles.map(c => ({
                  timestamp: timestampMs(c.timestamp),
                  open: c.open,
                  high: c.high,
                  low: c.low,
                  close: c.close,
                  price: c.close,
                  volume: c.volume,
                  source: c.source,
                  fallback: c.fallback,
                }));
              }
            }
          }
        }
      } catch (err) {
        console.warn(
          "[marketRouter] chartService failed, falling back to legacy CoinGecko:",
          err
        );
      }

      // Final price-history fallback. CoinGecko IDs without a supported contract
      // (for example Zcash) cannot use the DEX chart path, so recover the market
      // symbol from the cached detail record and try its Binance USDT market too.
      let marketSymbol: string | null = null;
      try {
        marketSymbol = (await getTokenDetail(input.coinId))?.symbol ?? null;
      } catch {
        // getMarketChart still safely tries the explicit legacy symbol map.
      }
      const fallback = await getMarketChart(
        input.coinId,
        TIMEFRAME_TO_DAYS[input.timeframe],
        marketSymbol
      );
      return fallback.map(point => ({
        timestamp: timestampMs(point.timestamp),
        open: point.open ?? point.price,
        high: point.high ?? point.price,
        low: point.low ?? point.price,
        close: point.close ?? point.price,
        price: point.price,
        volume: point.volume ?? null,
        source: point.source ?? "coingecko",
        fallback: point.fallback ?? true,
      }));
    }),

  assetStats: publicProcedure
    .input(
      z.object({
        coinId: z.string().optional(),
        network: z.string().optional(),
        contractAddress: z.string().optional(),
      })
    )
    .query(async ({ input }) => getAssetStats(input)),

  assetPrice: publicProcedure
    .input(
      z.object({
        network: z.string().min(1),
        contractAddress: z.string().min(1),
        symbol: z.string().optional(),
        decimals: z.number().optional(),
      })
    )
    .query(async ({ input }) => getAssetPrice(input)),

  nativePrice: publicProcedure
    .input(z.object({ network: z.string().min(1) }))
    .query(async ({ input }) => getNativeAssetPrice(input.network)),

  /** Operational provider state; no credentials or raw provider payloads are exposed. */
  providerHealth: adminProcedure.query(() => getProviderHealth()),
});
