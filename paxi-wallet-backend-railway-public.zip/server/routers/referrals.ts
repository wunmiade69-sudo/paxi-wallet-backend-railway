import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  attachReferral,
  ensureReferralProfile,
  listMyReferrals,
  setReferralRewardWallet,
} from "../rewards/rewardService";
import { recordVerifiedReferralTrade } from "../rewards/referralTradeService";

export const referralsRouter = router({
  myProfile: protectedProcedure.query(({ ctx }) => ensureReferralProfile(ctx.user.openId)),

  setRewardWallet: protectedProcedure
    .input(z.object({ walletAddress: z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/) }))
    .mutation(({ ctx, input }) => setReferralRewardWallet(ctx.user.openId, input.walletAddress)),

  attach: protectedProcedure
    .input(z.object({ inviteCode: z.string().trim().min(6).max(32) }))
    .mutation(({ ctx, input }) => attachReferral(ctx.user.openId, input.inviteCode)),

  myReferrals: protectedProcedure.query(({ ctx }) => listMyReferrals(ctx.user.openId)),

  recordTrade: protectedProcedure
    .input(z.object({
      referralId: z.number().int().positive(),
      walletAddress: z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/),
      transactionHash: z.string().regex(/^0x[0-9a-fA-F]{64}$/),
    }))
    .mutation(({ ctx, input }) => recordVerifiedReferralTrade({ ...input, userOpenId: ctx.user.openId })),
});
