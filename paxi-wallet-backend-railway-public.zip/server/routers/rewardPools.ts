import { z } from "zod";
import { adminPermissionProcedure, router } from "../_core/trpc";
import { getActiveReferralPolicy, upsertReferralPolicy } from "../rewards/referralPolicy";
import {
  activateRewardPool,
  listRewardPools,
  registerRewardPool,
  setRewardPoolDistributor,
  verifyRewardPool,
} from "../rewards/rewardPoolService";

const addressList = z.array(z.string().regex(/^0x[0-9a-fA-F]{40}$/)).max(100);

export const rewardPoolsRouter = router({
  policy: adminPermissionProcedure("rewards.read").query(async () => {
    try {
      return await getActiveReferralPolicy();
    } catch {
      return null;
    }
  }),

  configurePolicy: adminPermissionProcedure("rewards.manage")
    .input(z.object({
      qualifyingAssetAddress: z.string().regex(/^0x[0-9a-fA-F]{40}$/).nullable().optional(),
      trustedRouterAddresses: addressList.optional(),
      trustedPairAddresses: addressList.optional(),
      minimumVolumeUsd: z.string().regex(/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/).refine((value) => value !== "0").optional(),
      rewardAmount: z.string().regex(/^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/).refine((value) => value !== "0").optional(),
      minimumTradeUsd: z.string().regex(/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/).optional(),
      cooldownSeconds: z.number().int().min(0).max(86_400).optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(({ input }) => upsertReferralPolicy(input)),

  list: adminPermissionProcedure("rewards.read")
    .input(z.object({ policyId: z.number().int().positive() }))
    .query(({ input }) => listRewardPools(input.policyId)),

  register: adminPermissionProcedure("rewards.manage")
    .input(z.object({
      policyId: z.number().int().positive(),
      chainId: z.literal("bsc"),
      tokenAddress: z.string().regex(/^0x[0-9a-fA-F]{40}$/),
      distributorAddress: z.string().regex(/^0x[0-9a-fA-F]{40}$/).nullable().optional(),
      tokenSymbol: z.string().trim().min(1).max(32),
      tokenDecimals: z.number().int().min(0).max(36),
      totalAllocation: z.string().regex(/^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/).refine((value) => value !== "0"),
      priority: z.number().int().positive(),
    }))
    .mutation(({ input }) => registerRewardPool(input)),

  setDistributor: adminPermissionProcedure("rewards.manage")
    .input(z.object({ poolId: z.number().int().positive(), distributorAddress: z.string().regex(/^0x[0-9a-fA-F]{40}$/) }))
    .mutation(({ input }) => setRewardPoolDistributor(input.poolId, input.distributorAddress)),

  verify: adminPermissionProcedure("rewards.manage")
    .input(z.object({ poolId: z.number().int().positive() }))
    .mutation(({ input }) => verifyRewardPool(input.poolId)),

  activate: adminPermissionProcedure("rewards.manage")
    .input(z.object({ poolId: z.number().int().positive() }))
    .mutation(({ input }) => activateRewardPool(input.poolId)),
});
