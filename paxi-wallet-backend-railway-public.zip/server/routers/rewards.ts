import { z } from "zod";
import { and, asc, eq } from "drizzle-orm";
import { adminProcedure, protectedProcedure, router } from "../_core/trpc";
import { getDb, getReadDb } from "../db";
import { rewardLedger } from "../../drizzle/schema";
import { finalizeRewardClaim, listMyRewardClaims } from "../rewards/rewardClaimService";

export const rewardsRouter = router({
  mine: protectedProcedure
    .input(z.object({ limit: z.number().int().min(1).max(200).optional() }).optional())
    .query(async ({ ctx, input }) => {
      const db = await getReadDb();
      if (!db) return [];
      return db.select().from(rewardLedger)
        .where(eq(rewardLedger.userOpenId, ctx.user.openId))
        .orderBy(asc(rewardLedger.id))
        .limit(input?.limit ?? 50);
    }),

  myClaims: protectedProcedure
    .input(z.object({ limit: z.number().int().min(1).max(200).optional() }).optional())
    .query(({ ctx, input }) => listMyRewardClaims(ctx.user.openId, input?.limit ?? 100)),

  finalizeClaim: protectedProcedure
    .input(z.object({ claimId: z.number().int().positive(), txHash: z.string().regex(/^0x[0-9a-fA-F]{64}$/) }))
    .mutation(({ ctx, input }) => finalizeRewardClaim({ ...input, userOpenId: ctx.user.openId })),

  approve: adminProcedure
    .input(z.object({ ledgerId: z.number().int().positive() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const result = await db.update(rewardLedger)
        .set({ status: "approved", approvedAt: new Date() })
        .where(and(eq(rewardLedger.id, input.ledgerId), eq(rewardLedger.status, "pending")));
      if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) throw new Error("Only pending rewards can be approved");
      const [row] = await db.select().from(rewardLedger).where(eq(rewardLedger.id, input.ledgerId)).limit(1);
      if (!row) throw new Error("Reward ledger entry not found");
      return row;
    }),
});
