import { describe, expect, it } from "vitest";
import { securityScanInputSchema } from "./security";

describe("security.scan input validation", () => {
  it("accepts approval analysis fields", () => {
    const parsed = securityScanInputSchema.safeParse({
      targetType: "approval",
      network: "ethereum",
      target: "0xwallet",
      intendedAmount: 10,
      tokenAddress: "0xtoken",
    });
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.intendedAmount).toBe(10);
      expect(parsed.data.tokenAddress).toBe("0xtoken");
    }
  });

  it("rejects invalid approval amounts and unexpected keys", () => {
    expect(
      securityScanInputSchema.safeParse({
        targetType: "approval",
        network: "ethereum",
        target: "0xwallet",
        intendedAmount: 0,
      }).success
    ).toBe(false);
    expect(
      securityScanInputSchema.safeParse({
        targetType: "approval",
        network: "ethereum",
        target: "0xwallet",
        tokenAddress: "bad token",
      }).success
    ).toBe(false);
    expect(
      securityScanInputSchema.safeParse({
        targetType: "approval",
        network: "ethereum",
        target: "0xwallet",
        secret: "do-not-accept",
      }).success
    ).toBe(false);
  });
});
