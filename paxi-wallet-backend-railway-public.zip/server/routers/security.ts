import { z } from "zod";
import { getContractSecurity } from "../contractSecurity";
import { scanSecurity } from "../securityEngine";
import { recordSecurityEvent } from "../security/securityLogger";
import { publicProcedure, router } from "../_core/trpc";

export const securityScanInputSchema = z
  .object({
    targetType: z.enum([
      "contract",
      "address",
      "transaction",
      "approval",
      "dapp",
    ]),
    network: z.string().trim().min(1).max(64),
    target: z.string().trim().min(1).max(256),
    intendedAmount: z.number().finite().positive().max(1e36).optional(),
    tokenAddress: z
      .string()
      .trim()
      .min(1)
      .max(256)
      .regex(/^\S+$/, "tokenAddress must not contain whitespace")
      .optional(),
  })
  .strict();

export const securityRouter = router({
  /** Real contract security check (GoPlus-backed) - used for the PAXI Shield
   * badge/panel before a user sends/swaps into an unfamiliar token. Public -
   * this is safety information, not something that needs login to see. */
  checkContract: publicProcedure
    .input(z.object({ network: z.string(), contractAddress: z.string() }))
    .query(async ({ input }) => {
      return getContractSecurity(input.network, input.contractAddress);
    }),

  scan: publicProcedure
    .input(securityScanInputSchema)
    .query(async ({ input }) => {
      const result = await scanSecurity(input);
      recordSecurityEvent(
        `${input.targetType.toUpperCase()}_SECURITY_CHECK` as Parameters<
          typeof recordSecurityEvent
        >[0],
        result
      );
      if (result.status === "high-risk" || result.riskLevel === "MEDIUM")
        recordSecurityEvent("SECURITY_WARNING", result);
      return result;
    }),
});
