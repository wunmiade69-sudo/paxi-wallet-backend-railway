import { z } from "zod";
import { UNSUPPORTED_REPORT } from "../contractSecurity";
import { orchestratedSecurity } from "../providers";
import { analyzeContractWithAI } from "../aiSecurityAnalysis";
import { publicProcedure, router } from "../_core/trpc";

const securityNetwork = z.enum(["ethereum", "bsc"]);
const evmContractAddress = z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/, "Invalid EVM contract address");

export const securityRouter = router({
  /** Real contract security check (GoPlus-backed) - used for the PAXI Shield
   * badge/panel before a user sends/swaps into an unfamiliar token. Public -
   * this is safety information, not something that needs login to see. */
  checkContract: publicProcedure
    .input(z.object({ network: securityNetwork, contractAddress: evmContractAddress }))
    .query(async ({ input }) => {
      const result = await orchestratedSecurity({ chain: input.network, contractAddress: input.contractAddress });
      return result.value?.report ?? UNSUPPORTED_REPORT;
    }),

  /**
   * Deep, LLM-driven second opinion on top of checkContract's rule-based
   * score - reasons over raw scanner flags + verified source together to
   * surface combined risk patterns the fixed score doesn't. User-triggered
   * (mutation, not query) since it's a real LLM call with real latency/cost -
   * not run automatically on every token view.
   */
  aiAnalysis: publicProcedure
    .input(z.object({ network: securityNetwork, contractAddress: evmContractAddress }))
    .mutation(({ input }) => analyzeContractWithAI(input.network, input.contractAddress)),
});
