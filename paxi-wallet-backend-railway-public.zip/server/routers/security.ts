import { z } from "zod";
import { UNSUPPORTED_REPORT } from "../contractSecurity";
import { orchestratedSecurity } from "../providers";
import { analyzeContractWithAI } from "../aiSecurityAnalysis";
import { publicProcedure, router } from "../_core/trpc";

const securityNetwork = z.enum(["ethereum", "bsc", "polygon", "arbitrum", "base"]);
const evmContractAddress = z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/, "Invalid EVM contract address");

export const securityRouter = router({
  /** Real multi-provider contract security check - used for the PAXI Shield
   * badge/panel before a user sends/swaps into an unfamiliar token. Public -
   * this is safety information, not something that needs login to see. */
  checkContract: publicProcedure
    .input(z.object({ network: securityNetwork, contractAddress: evmContractAddress }))
    .query(async ({ input }) => {
      const result = await orchestratedSecurity({ chain: input.network, contractAddress: input.contractAddress });
      return result.value?.report ?? UNSUPPORTED_REPORT;
    }),

  /** Bounded, cached-friendly summary used by the Markets list. It deliberately
   * accepts only a small batch so browsing a page cannot create an upstream
   * security-provider fan-out storm. */
  checkContracts: publicProcedure
    .input(z.object({
      contracts: z.array(z.object({ network: securityNetwork, contractAddress: evmContractAddress })).max(8),
    }))
    .query(async ({ input }) => {
      const results = await Promise.all(input.contracts.map(async (contract) => {
        const result = await orchestratedSecurity({ chain: contract.network, contractAddress: contract.contractAddress });
        const report = result.value?.report ?? UNSUPPORTED_REPORT;
        return {
          key: `${contract.network}:${contract.contractAddress.toLowerCase()}`,
          status: report.status,
          riskLevel: report.riskLevel,
        };
      }));
      return results;
    }),

  /**
   * Deep, LLM-driven second opinion on top of checkContract's rule-based
   * score - reasons over raw scanner flags + verified source together to
   * surface combined risk patterns the fixed score doesn't. User-triggered
   * (mutation, not query) since it's a real LLM call with real latency/cost -
   * not run automatically on every token view.
   */
  aiAnalysis: publicProcedure
    .input(z.object({ network: securityNetwork, contractAddress: evmContractAddress }))
    .mutation(({ input }) => analyzeContractWithAI(input.network, input.contractAddress)),
});
