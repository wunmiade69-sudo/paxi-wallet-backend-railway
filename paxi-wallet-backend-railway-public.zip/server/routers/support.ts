import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  addSupportMessage,
  askPaxiAI,
  createSupportTicket,
  getUserTicket,
  listUserTickets,
} from "../support/supportService";

const diagnosticContext = z.record(z.string(), z.unknown()).optional();
const priority = z.enum(["LOW", "NORMAL", "HIGH", "URGENT"]);

export const supportRouter = router({
  faq: protectedProcedure.query(() => ({
    supportSafety:
      "PAXI Support will never ask for your recovery phrase, private key, PIN, password, or authentication codes.",
    topics: [
      "Wallet setup",
      "Transactions",
      "Swaps",
      "Bridges",
      "PAXI Shield",
      "Token discovery",
      "Support tickets",
    ],
  })),

  askAI: protectedProcedure
    .input(
      z.object({
        messages: z
          .array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string().min(1).max(8_000),
            })
          )
          .min(1)
          .max(20),
        diagnosticContext,
      })
    )
    .mutation(({ ctx, input }) =>
      askPaxiAI({
        messages: input.messages,
        diagnosticContext: {
          ...input.diagnosticContext,
          userId: ctx.user.openId,
        },
      })
    ),

  createTicket: protectedProcedure
    .input(
      z.object({
        category: z.string().trim().min(1).max(48),
        subject: z.string().trim().min(1).max(180),
        description: z.string().trim().min(1).max(8_000),
        walletId: z.string().trim().max(128).optional(),
        chain: z.string().trim().max(32).optional(),
        transactionHash: z.string().trim().max(160).optional(),
        contractAddress: z.string().trim().max(160).optional(),
        priority: priority.optional(),
        diagnosticContext,
        dedupeKey: z.string().trim().max(96).optional(),
      })
    )
    .mutation(({ ctx, input }) =>
      createSupportTicket({ ...input, userOpenId: ctx.user.openId })
    ),

  requestHuman: protectedProcedure
    .input(
      z.object({
        subject: z
          .string()
          .trim()
          .min(1)
          .max(180)
          .default("Human support requested"),
        description: z.string().trim().min(1).max(8_000),
        category: z.string().trim().min(1).max(48).default("human_escalation"),
        diagnosticContext,
        dedupeKey: z.string().trim().max(96).optional(),
        priority: priority.default("NORMAL"),
      })
    )
    .mutation(({ ctx, input }) =>
      createSupportTicket({ ...input, userOpenId: ctx.user.openId })
    ),

  myTickets: protectedProcedure.query(({ ctx }) =>
    listUserTickets(ctx.user.openId)
  ),

  ticket: protectedProcedure
    .input(z.object({ ticketKey: z.string().trim().min(1).max(32) }))
    .query(({ ctx, input }) => getUserTicket(ctx.user.openId, input.ticketKey)),

  addMessage: protectedProcedure
    .input(
      z.object({
        ticketKey: z.string().trim().min(1).max(32),
        body: z.string().trim().min(1).max(8_000),
        clientMessageKey: z.string().trim().max(96).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const ticket = await getUserTicket(ctx.user.openId, input.ticketKey);
      if (!ticket) throw new Error("Support ticket not found");
      return addSupportMessage({
        ticketId: ticket.ticket.id,
        authorType: "USER",
        authorOpenId: ctx.user.openId,
        body: input.body,
        clientMessageKey: input.clientMessageKey,
      });
    }),
});
