import { z } from "zod";
import { publicProcedure, protectedProcedure, adminPermissionProcedure, router } from "../_core/trpc";
import { answerSupportChat } from "../support/chatbot";
import { submitTicket, listTickets, updateTicket, getUserTickets } from "../support/tickets";
import { TICKET_CATEGORIES, TICKET_PRIORITIES } from "../support/ticketTriage";

const ticketStatus = z.enum(["open", "in_progress", "waiting_on_user", "resolved", "closed"]);

export const supportRouter = router({
  /**
   * In-app AI chatbot. Public - a not-yet-authenticated visitor should
   * still be able to ask "how do I..." questions. No server-side chat
   * history is stored; the client sends the running transcript each turn.
   */
  chat: publicProcedure
    .input(z.object({
      history: z.array(z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().trim().min(1).max(4000),
      })).min(1).max(30),
    }))
    .mutation(({ input }) => answerSupportChat(input.history)),

  /** Submit a support ticket - AI-triaged on arrival. Wallet-linked callers get userOpenId attached automatically; anonymous submission still works via contactEmail. */
  submitTicket: publicProcedure
    .input(z.object({
      walletAddress: z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/).optional(),
      contactEmail: z.string().trim().email().max(255).optional(),
      subject: z.string().trim().min(3).max(200),
      message: z.string().trim().min(10).max(5000),
    }))
    .mutation(async ({ ctx, input }) => {
      const ticket = await submitTicket({
        userOpenId: ctx.user?.openId ?? null,
        walletAddress: input.walletAddress ?? null,
        contactEmail: input.contactEmail ?? null,
        subject: input.subject,
        message: input.message,
      });
      return { id: ticket.id, status: ticket.status, category: ticket.category, priority: ticket.priority };
    }),

  /** A logged-in user's own ticket history. */
  myTickets: protectedProcedure.query(({ ctx }) => getUserTickets(ctx.user.openId)),

  admin: router({
    list: adminPermissionProcedure("support.read")
      .input(z.object({ status: ticketStatus.optional(), limit: z.number().int().min(1).max(200).optional() }))
      .query(({ input }) => listTickets(input)),

    update: adminPermissionProcedure("support.manage")
      .input(z.object({
        id: z.number().int().positive(),
        status: ticketStatus.optional(),
        priority: z.enum(TICKET_PRIORITIES).optional(),
        category: z.enum(TICKET_CATEGORIES).optional(),
        assignedAdminOpenId: z.string().trim().max(64).nullable().optional(),
        resolutionNote: z.string().trim().max(5000).nullable().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateTicket({ ...input, assignedAdminOpenId: input.assignedAdminOpenId === undefined ? ctx.user.openId : input.assignedAdminOpenId });
        return { ok: true };
      }),
  }),
});
