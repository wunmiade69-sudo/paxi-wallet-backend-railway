import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { buildVeloraTransaction, fetchVeloraSwapQuote } from "../veloraQuote";
import { buildJupiterSwapInstructions, fetchJupiterSwapQuote } from "../jupiterSwap";
import { fetchThorchainQuote, fetchThorchainSwapStatus } from "../thorchain";

const address = z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/, "Invalid EVM address");
const units = z.string().regex(/^[0-9]+$/).max(80);
const decimals = z.number().int().min(0).max(36);
const priceRoute = z.record(z.string(), z.unknown());
const solanaAddress = z.string().trim().min(32).max(44);

export const swapRouter = router({
  /** Provider quote only; user signing and broadcast remain in the non-custodial client. */
  quote: publicProcedure
    .input(z.object({
      networkId: z.string().trim().min(1).max(32),
      chainId: z.number().int().positive(),
      srcToken: address,
      destToken: address,
      srcDecimals: decimals,
      destDecimals: decimals,
      amount: units,
      userAddress: address,
      slippageBps: z.number().int().min(0).max(5_000),
    }))
    .query(({ input }) => fetchVeloraSwapQuote(input)),

  /** Builds unsigned provider transaction data; it never signs, sends, or settles. */
  transaction: publicProcedure
    .input(z.object({
      networkId: z.string().trim().min(1).max(32),
      chainId: z.number().int().positive(),
      srcToken: address,
      destToken: address,
      srcDecimals: decimals,
      destDecimals: decimals,
      srcAmount: units,
      destAmount: units,
      priceRoute,
      userAddress: address,
    }))
    .query(({ input }) => buildVeloraTransaction(input)),

  solanaQuote: publicProcedure
    .input(z.object({
      inputMint: solanaAddress,
      outputMint: solanaAddress,
      amount: units,
      slippageBps: z.number().int().min(0).max(5_000),
    }))
    .query(({ input }) => fetchJupiterSwapQuote(input)),

  solanaInstructions: publicProcedure
    .input(z.object({
      quoteResponse: priceRoute,
      userPublicKey: solanaAddress,
    }))
    .query(({ input }) => buildJupiterSwapInstructions(input)),

  thorchainQuote: publicProcedure
    .input(z.object({
      destinationAsset: z.string().trim().min(1).max(128),
      destinationAddress: z.string().trim().min(20).max(128),
      amountSats: units,
    }))
    .query(({ input }) => fetchThorchainQuote(input)),

  thorchainStatus: publicProcedure
    .input(z.object({ txid: z.string().trim().min(1).max(128) }))
    .query(({ input }) => fetchThorchainSwapStatus(input.txid)),
});
