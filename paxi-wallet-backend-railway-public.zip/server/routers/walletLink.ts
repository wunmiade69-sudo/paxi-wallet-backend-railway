import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { issueSession } from "../_core/session";
import { createWalletLinkChallenge, verifyWalletLink, requireLinkedWallet, walletOpenId } from "../fees/walletLink";
const addressSchema = z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/);

/**
 * Public (not protectedProcedure): this wallet is non-custodial, and wallet
 * ownership is proven cryptographically right here via ECDSA signature over
 * a fresh server nonce - that IS the login. A Manus session, if present
 * (ctx.user), still takes priority so wallets linked to a real account keep
 * working exactly as before. See server/fees/walletLink.ts for the
 * wallet-address-derived identity used when there is no Manus session.
 */
export const walletLinkRouter = router({
  challenge: publicProcedure
    .input(z.object({ walletAddress: addressSchema }))
    .mutation(({ ctx, input }) => createWalletLinkChallenge(ctx.user?.openId ?? null, input.walletAddress)),

  verify: publicProcedure
    .input(z.object({ walletAddress: addressSchema, message: z.string().min(1).max(4096), signature: z.string().regex(/^0x[0-9a-fA-F]+$/) }))
    .mutation(async ({ ctx, input }) => {
      const result = await verifyWalletLink(ctx.user?.openId ?? null, input.walletAddress, input.message, input.signature);
      // Fresh wallet-native identity: mint the same session cookie a Manus
      // login would, so the very next request (e.g. fees.getSendQuote) is
      // already authenticated - no separate login step for the user.
      if (result.isNewSession) {
        await issueSession(ctx.req, ctx.res, result.openId, input.walletAddress, { loginMethod: "wallet" });
      }
      return { linked: result.linked, walletAddress: result.walletAddress };
    }),

  check: publicProcedure
    .input(z.object({ walletAddress: addressSchema }))
    .query(({ ctx, input }) => {
      const openId = ctx.user?.openId ?? walletOpenId(input.walletAddress);
      return requireLinkedWallet(openId, input.walletAddress)
        .then(walletAddress => ({ linked: true, walletAddress }))
        .catch(() => ({ linked: false, walletAddress: null }));
    }),
});
