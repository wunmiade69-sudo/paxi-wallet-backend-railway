import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { createWalletLinkChallenge, verifyWalletLink, requireLinkedWallet } from "../fees/walletLink";
const addressSchema = z.string().trim().regex(/^0x[0-9a-fA-F]{40}$/);
export const walletLinkRouter = router({
  challenge: protectedProcedure.input(z.object({ walletAddress: addressSchema })).mutation(({ ctx, input }) => createWalletLinkChallenge(ctx.user.openId, input.walletAddress)),
  verify: protectedProcedure.input(z.object({ walletAddress: addressSchema, message: z.string().min(1).max(4096), signature: z.string().regex(/^0x[0-9a-fA-F]+$/) })).mutation(({ ctx, input }) => verifyWalletLink(ctx.user.openId, input.walletAddress, input.message, input.signature)),
  check: protectedProcedure.input(z.object({ walletAddress: addressSchema })).query(({ ctx, input }) => requireLinkedWallet(ctx.user.openId, input.walletAddress).then(walletAddress => ({ linked: true, walletAddress })).catch(() => ({ linked: false, walletAddress: null }))),
});
