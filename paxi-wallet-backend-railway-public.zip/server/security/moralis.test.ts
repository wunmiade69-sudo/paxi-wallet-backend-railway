import { describe, expect, it } from "vitest";
import { approvalFindings } from "./moralis";

const MAX_UINT256 =
  "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

describe("Moralis approval risk rules", () => {
  it("flags unlimited approvals as high risk", () => {
    const result = approvalFindings([
      {
        token_symbol: "PAXI",
        spender: "0xspender",
        allowance: MAX_UINT256,
        verified_contract: true,
      },
    ]);
    expect(result.riskLevel).toBe("HIGH");
    expect(result.findings[0]).toContain("Unlimited PAXI approval");
  });

  it("flags unverified or spam spenders as medium risk", () => {
    const result = approvalFindings([
      {
        token_symbol: "PAXI",
        spender: "0xunknown",
        allowance: "100",
        possible_spam: true,
      },
    ]);
    expect(result.riskLevel).toBe("MEDIUM");
    expect(result.findings[0]).toContain("unverified");
  });

  it("does not claim an empty approval set is dangerous", () => {
    const result = approvalFindings([]);
    expect(result.riskLevel).toBe("UNKNOWN");
    expect(result.findings).toEqual([]);
  });
});

it("flags an allowance that is materially larger than the intended transaction", () => {
  const result = approvalFindings(
    [
      {
        token_symbol: "PAXI",
        spender: "0xspender",
        allowance: "1000",
        allowance_formatted: "1000",
        verified_contract: true,
      },
    ],
    10
  );
  expect(result.riskLevel).toBe("MEDIUM");
  expect(result.findings[0]).toContain("significantly larger");
});

it("does not flag a normal approval equal to the intended amount", () => {
  const result = approvalFindings(
    [
      {
        token_symbol: "PAXI",
        spender: "0xspender",
        allowance: "10",
        allowance_formatted: "10",
        verified_contract: true,
      },
    ],
    10
  );
  expect(result.riskLevel).toBe("UNKNOWN");
  expect(result.findings[0]).toContain("active approval");
  expect(result.findings.join(" ").toLowerCase()).not.toContain("larger");
});

it("does not invent an oversized comparison when intendedAmount is missing", () => {
  const result = approvalFindings([
    {
      token_symbol: "PAXI",
      spender: "0xspender",
      allowance: "1000",
      allowance_formatted: "1000",
      verified_contract: true,
    },
  ]);
  expect(result.riskLevel).toBe("UNKNOWN");
  expect(result.findings.join(" ").toLowerCase()).not.toContain("larger");
  expect(result.findings.join(" ").toLowerCase()).not.toContain("malicious");
});
