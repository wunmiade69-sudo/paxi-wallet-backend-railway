import { ENV } from "../_core/env";
import { fetchJson } from "../providers/http";

export interface MoralisApproval {
  token_address?: string;
  token_symbol?: string;
  token_decimals?: string | number;
  spender?: string;
  allowance?: string;
  allowance_formatted?: string;
  possible_spam?: boolean | string;
  verified_contract?: boolean | string;
}

interface ApprovalResponse {
  result?: MoralisApproval[];
}

interface HistoryResponse {
  result?: Array<{
    hash?: string;
    receipt_status?: string | number;
    possible_spam?: boolean | string;
    summary?: string;
    block_timestamp?: string;
  }>;
}

const CHAIN_NAMES: Record<string, string> = {
  ethereum: "eth",
  eth: "eth",
  bsc: "bsc",
  polygon: "polygon",
  arbitrum: "arbitrum",
  base: "base",
};

const MORALIS_BASE_URL = "https://deep-index.moralis.io/api/v2.2";

function chainForMoralis(network: string): string | null {
  return CHAIN_NAMES[network.trim().toLowerCase()] ?? null;
}

function headers(): Record<string, string> {
  return { "X-API-Key": ENV.moralisApiKey };
}

export function moralisConfigured(): boolean {
  return Boolean(ENV.moralisApiKey);
}

export async function getWalletApprovals(
  network: string,
  address: string,
  tokenAddress?: string
): Promise<MoralisApproval[] | null> {
  const chain = chainForMoralis(network);
  if (!ENV.moralisApiKey || !chain) return null;
  const response = await fetchJson<ApprovalResponse>(
    `${MORALIS_BASE_URL}/${encodeURIComponent(address)}/approvals?chain=${encodeURIComponent(chain)}`,
    "moralis-approvals",
    headers()
  );
  const approvals = Array.isArray(response.result) ? response.result : [];
  if (!tokenAddress) return approvals;
  const normalizedToken = tokenAddress.trim().toLowerCase();
  return approvals.filter(
    approval => approval.token_address?.trim().toLowerCase() === normalizedToken
  );
}

export async function getWalletHistory(
  network: string,
  address: string
): Promise<HistoryResponse["result"] | null> {
  const chain = chainForMoralis(network);
  if (!ENV.moralisApiKey || !chain) return null;
  const response = await fetchJson<HistoryResponse>(
    `${MORALIS_BASE_URL}/wallets/${encodeURIComponent(address)}/history?chain=${encodeURIComponent(chain)}&order=DESC&limit=20`,
    "moralis-history",
    headers()
  );
  return Array.isArray(response.result) ? response.result : [];
}

export function approvalFindings(
  approvals: MoralisApproval[],
  intendedAmount?: number
): { riskLevel: "LOW" | "MEDIUM" | "HIGH" | "UNKNOWN"; findings: string[] } {
  const findings: string[] = [];
  let riskLevel: "LOW" | "MEDIUM" | "HIGH" | "UNKNOWN" = "UNKNOWN";
  for (const approval of approvals) {
    const allowance = approval.allowance?.toLowerCase();
    const isUnlimited =
      allowance ===
        "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff" ||
      allowance ===
        "115792089237316195423570985008687907853269984665640564039457584007913129639935";
    const spenderUnknown =
      approval.verified_contract === false ||
      approval.verified_contract === "false" ||
      approval.possible_spam === true ||
      approval.possible_spam === "true";
    const allowanceFormatted = Number(
      approval.allowance_formatted ?? approval.allowance ?? NaN
    );
    const unusuallyLarge =
      intendedAmount != null &&
      Number.isFinite(allowanceFormatted) &&
      intendedAmount > 0 &&
      allowanceFormatted >= intendedAmount * 100;
    if (isUnlimited) {
      findings.push(
        `Unlimited ${approval.token_symbol ?? "token"} approval to ${approval.spender ?? "an unknown spender"}`
      );
      riskLevel = "HIGH";
    } else if (unusuallyLarge) {
      findings.push(
        `Approval is significantly larger than the intended transaction amount (${allowanceFormatted} vs ${intendedAmount})`
      );
      if (riskLevel !== "HIGH") riskLevel = "MEDIUM";
    } else if (spenderUnknown) {
      findings.push(
        `Approval exists for an unverified or potentially spam spender (${approval.spender ?? "unknown"})`
      );
      if (riskLevel !== "HIGH") riskLevel = "MEDIUM";
    }
  }
  if (!findings.length && approvals.length > 0)
    findings.push(
      `${approvals.length} active approval${approvals.length === 1 ? "" : "s"} returned; review the spender and allowance before revoking or changing it`
    );
  return { riskLevel, findings };
}
