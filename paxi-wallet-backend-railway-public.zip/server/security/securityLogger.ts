import { createHash } from "node:crypto";
import type { SecurityScanResult } from "../securityEngine";

export type SecurityEventType =
  | "TOKEN_SECURITY_CHECK"
  | "ADDRESS_SECURITY_CHECK"
  | "TRANSACTION_SECURITY_CHECK"
  | "APPROVAL_SECURITY_CHECK"
  | "DAPP_SECURITY_CHECK"
  | "SECURITY_WARNING";

function targetDigest(target: string): string {
  return createHash("sha256").update(target.trim()).digest("hex").slice(0, 20);
}

export function recordSecurityEvent(eventType: SecurityEventType, result: SecurityScanResult): void {
  const warning = result.status === "high-risk" || result.riskLevel === "HIGH" || result.riskLevel === "MEDIUM";
  console.info("[security-event]", {
    eventType,
    network: result.network,
    targetDigest: targetDigest(result.target),
    targetType: result.targetType,
    status: result.status,
    riskLevel: result.riskLevel,
    confidence: result.confidence,
    provider: result.provider,
    dataAvailable: result.dataAvailable,
    warning,
  });
}
