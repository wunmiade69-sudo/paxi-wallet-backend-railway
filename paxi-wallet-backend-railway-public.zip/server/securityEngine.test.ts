import { describe, expect, it } from "vitest";
import { scanSecurity } from "./securityEngine";

describe("security engine", () => {
  it("returns an explicit unknown result for address scans without a configured provider", async () => {
    const result = await scanSecurity({ targetType: "address", network: "ethereum", target: "0xabc" });
    expect(result.status).toBe("unknown");
    expect(result.riskLevel).toBe("UNKNOWN");
    expect(result.score).toBeNull();
    expect(result.dataAvailable).toBe(false);
    expect(result.confidence).toBe("none");
    expect(result.findings[0]).toContain("not configured");
  });

  it("does not claim dApp safety when only a URL is supplied", async () => {
    const result = await scanSecurity({ targetType: "dapp", network: "ethereum", target: "https://example.com" });
    expect(result.status).toBe("unknown");
    expect(result.provider).toBe("not-configured");
    expect(result.findings).toHaveLength(1);
  });

  it("rejects an empty security target without calling a provider", async () => {
    const result = await scanSecurity({ targetType: "transaction", network: "bsc", target: "   " });
    expect(result.provider).toBe("validation");
    expect(result.findings[0]).toContain("target is required");
  });
});


  it('keeps unsupported transaction and approval scans unknown', async () => {
    const transaction = await scanSecurity({ targetType: 'transaction', network: 'bsc', target: '0xtransaction' });
    const approval = await scanSecurity({ targetType: 'approval', network: 'bsc', target: '0xwallet' });
    expect(transaction.riskLevel).toBe('UNKNOWN');
    expect(transaction.score).toBeNull();
    expect(approval.riskLevel).toBe('UNKNOWN');
    expect(approval.score).toBeNull();
  });

  it('does not turn an empty address history into a safe result', async () => {
    const result = await scanSecurity({ targetType: 'address', network: 'ethereum', target: '0xwallet' });
    expect(result.riskLevel).toBe('UNKNOWN');
    expect(result.status).toBe('unknown');
    expect(result.score).toBeNull();
  });
