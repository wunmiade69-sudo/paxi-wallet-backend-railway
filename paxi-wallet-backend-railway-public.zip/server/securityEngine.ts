import { eq } from "drizzle-orm";
import { securityReports } from "../drizzle/schema";
import { getDb } from "./db";
import { getOrCreateAsset } from "./assetRegistry";
import {
  getContractSecurity,
  type ContractSecurityReport,
  type RiskLevel,
  type SecurityStatus,
} from "./contractSecurity";
import {
  approvalFindings,
  getWalletApprovals,
  getWalletHistory,
  moralisConfigured,
} from "./security/moralis";

export type SecurityTargetType =
  "contract" | "address" | "transaction" | "approval" | "dapp";
export type SecurityConfidence = "high" | "medium" | "low" | "none";

export interface SecurityScanResult {
  targetType: SecurityTargetType;
  network: string;
  target: string;
  status: SecurityStatus;
  riskLevel: RiskLevel;
  score: number | null;
  confidence: SecurityConfidence;
  confidenceScore: number | null;
  provider: string;
  sources: string[];
  dataAvailable: boolean;
  indicators: string[];
  warnings: string[];
  findings: string[];
  checkedAt: number;
}

function unknownResult(
  targetType: SecurityTargetType,
  network: string,
  target: string,
  provider = "none",
  finding = "No independently verified security data is available",
  sources: string[] = provider === "none" ? [] : [provider]
): SecurityScanResult {
  return {
    targetType,
    network,
    target,
    status: "unknown",
    riskLevel: "UNKNOWN",
    score: null,
    confidence: "none",
    confidenceScore: null,
    provider,
    sources,
    dataAvailable: false,
    indicators: [],
    warnings: [finding],
    findings: [finding],
    checkedAt: Date.now(),
  };
}

function findingsFromContract(report: ContractSecurityReport): string[] {
  const findings: string[] = [];
  if (report.checks.verifiedContract === false)
    findings.push("Contract source is not verified by the provider");
  if (report.checks.noHoneypot === false)
    findings.push("Provider detected honeypot behavior");
  if (report.checks.liquidityLocked === false)
    findings.push("Liquidity lock was not confirmed");
  if (report.checks.ownershipRenounced === false)
    findings.push("Ownership is not renounced");
  if (report.buyTaxPercent != null && report.buyTaxPercent > 10)
    findings.push(`Buy tax is ${report.buyTaxPercent.toFixed(2)}%`);
  if (report.sellTaxPercent != null && report.sellTaxPercent > 10)
    findings.push(`Sell tax is ${report.sellTaxPercent.toFixed(2)}%`);
  if (!findings.length && report.score != null)
    findings.push(
      "No high-risk flags were returned by the configured contract-security provider"
    );
  return findings;
}

function indicatorsFromContract(report: ContractSecurityReport): string[] {
  return [
    report.checks.verifiedContract === true
      ? "Contract information is verified"
      : report.checks.verifiedContract === false
        ? "Contract verification is unavailable or negative"
        : "Contract verification was not returned",
    report.checks.noHoneypot === true
      ? "No honeypot flag was returned"
      : report.checks.noHoneypot === false
        ? "Honeypot risk was detected"
        : "Honeypot signal was not returned",
    report.checks.liquidityLocked === true
      ? "Liquidity lock signal returned"
      : report.checks.liquidityLocked === false
        ? "Liquidity lock was not confirmed"
        : "Liquidity lock signal was not returned",
  ];
}

async function persistContractReport(
  network: string,
  target: string,
  report: ContractSecurityReport
): Promise<void> {
  if (report.score == null) return;
  const asset = await getOrCreateAsset({
    chainId: network,
    identifier: target,
    symbol: "UNKNOWN",
    name: "Unknown token",
  });
  const db = await getDb();
  if (!asset || !db) return;
  const label =
    report.status === "safe"
      ? "verified"
      : report.status === "high-risk"
        ? "scam_suspicious"
        : "risky";
  await db
    .insert(securityReports)
    .values({
      assetId: asset.id,
      label,
      score: report.score,
      checks: {
        ...report.checks,
        buyTaxPercent: report.buyTaxPercent,
        sellTaxPercent: report.sellTaxPercent,
        holderCount: report.holderCount,
      },
      provider: "goplus",
    })
    .onDuplicateKeyUpdate({
      set: {
        label,
        score: report.score,
        checks: {
          ...report.checks,
          buyTaxPercent: report.buyTaxPercent,
          sellTaxPercent: report.sellTaxPercent,
          holderCount: report.holderCount,
        },
        provider: "goplus",
        checkedAt: new Date(),
      },
    });
}

export async function scanSecurity(input: {
  targetType: SecurityTargetType;
  network: string;
  target: string;
  intendedAmount?: number;
  tokenAddress?: string;
}): Promise<SecurityScanResult> {
  const target = input.target.trim();
  if (!target)
    return unknownResult(
      input.targetType,
      input.network,
      target,
      "validation",
      "A target is required"
    );

  if (input.targetType === "address" && moralisConfigured()) {
    try {
      const history = await getWalletHistory(input.network, target);
      if (history == null)
        return unknownResult(
          input.targetType,
          input.network,
          target,
          "moralis",
          "Moralis does not support this network"
        );
      const findings = history.flatMap(entry => {
        const item: string[] = [];
        if (entry.possible_spam === true || entry.possible_spam === "true")
          item.push(
            "Recent wallet activity includes a provider spam indicator"
          );
        if (entry.receipt_status === "0" || entry.receipt_status === 0)
          item.push("Recent wallet activity includes a reverted transaction");
        return item;
      });
      const indicators = [
        history.length
          ? `Sampled ${history.length} recent wallet-history record${history.length === 1 ? "" : "s"}`
          : "No wallet-history records were returned",
        ...findings,
      ];
      const warning = findings.length
        ? "Available wallet activity contains signals that require caution; this is not a definitive maliciousness determination"
        : "No major known risk indicators were detected in the available history, but there is insufficient evidence to classify this address as low risk";
      return {
        targetType: input.targetType,
        network: input.network,
        target,
        status: findings.length ? "unknown" : "unknown",
        riskLevel: findings.length ? "MEDIUM" : "UNKNOWN",
        score: findings.length ? 45 : null,
        confidence: history.length ? "low" : "none",
        confidenceScore: history.length ? 35 : null,
        provider: "moralis",
        sources: ["Moralis"],
        dataAvailable: true,
        indicators,
        warnings: [warning],
        findings: findings.length ? findings : [warning],
        checkedAt: Date.now(),
      };
    } catch (error) {
      console.warn(
        "[security-engine] Moralis address scan failed",
        error instanceof Error ? error.message : String(error)
      );
      return unknownResult(
        input.targetType,
        input.network,
        target,
        "moralis",
        "Moralis address intelligence is temporarily unavailable"
      );
    }
  }

  if (input.targetType === "approval" && moralisConfigured()) {
    try {
      const approvals = await getWalletApprovals(
        input.network,
        target,
        input.tokenAddress
      );
      if (approvals == null)
        return unknownResult(
          input.targetType,
          input.network,
          target,
          "moralis",
          "Moralis does not support this network"
        );
      const evaluation = approvalFindings(approvals, input.intendedAmount);
      const isHigh = evaluation.riskLevel === "HIGH";
      const isMedium = evaluation.riskLevel === "MEDIUM";
      const warning =
        isHigh || isMedium
          ? "Review the spender and allowance before signing; never approve automatically"
          : "Approval data is available, but absence of a flagged allowance is not proof of safety";
      return {
        targetType: input.targetType,
        network: input.network,
        target,
        status: isHigh ? "high-risk" : "unknown",
        riskLevel: evaluation.riskLevel,
        score: isHigh ? 20 : isMedium ? 45 : null,
        confidence: approvals.length ? "low" : "none",
        confidenceScore: approvals.length ? 35 : null,
        provider: "moralis",
        sources: ["Moralis"],
        dataAvailable: true,
        indicators: approvals.length
          ? [
              `${approvals.length} active approval${approvals.length === 1 ? "" : "s"} returned`,
              ...evaluation.findings,
            ]
          : ["No active approvals were returned"],
        warnings: [warning],
        findings: evaluation.findings.length ? evaluation.findings : [warning],
        checkedAt: Date.now(),
      };
    } catch (error) {
      console.warn(
        "[security-engine] Moralis approval scan failed",
        error instanceof Error ? error.message : String(error)
      );
      return unknownResult(
        input.targetType,
        input.network,
        target,
        "moralis",
        "Moralis approval intelligence is temporarily unavailable"
      );
    }
  }

  if (input.targetType !== "contract") {
    return unknownResult(
      input.targetType,
      input.network,
      target,
      "not-configured",
      `Independent ${input.targetType} security scanning is not configured for this deployment`
    );
  }

  const report = await getContractSecurity(input.network, target);
  await persistContractReport(input.network, target, report).catch(error => {
    console.warn(
      "[security-engine] report persistence failed",
      error instanceof Error ? error.message : String(error)
    );
  });
  const findings = findingsFromContract(report);
  const indicators = indicatorsFromContract(report);
  const score = report.score;
  const isHighRisk = report.status === "high-risk";
  const warning =
    score == null
      ? "Insufficient information is available to determine token risk reliably"
      : isHighRisk
        ? "High-risk contract indicators were detected; review carefully before interacting"
        : "Security assessments are informational and do not guarantee that an asset, address, or transaction is safe";
  return {
    targetType: input.targetType,
    network: input.network,
    target,
    status: report.status,
    riskLevel: report.riskLevel,
    score,
    confidence: score == null ? "none" : isHighRisk ? "medium" : "medium",
    confidenceScore: score == null ? null : 65,
    provider: score == null ? "goplus" : "goplus",
    sources: ["GoPlus"],
    dataAvailable: score != null,
    indicators,
    warnings: [warning],
    findings,
    checkedAt: Date.now(),
  };
}

export async function getPersistedContractSecurity(
  network: string,
  target: string
) {
  const db = await getDb();
  if (!db) return null;
  const asset = await getOrCreateAsset({
    chainId: network,
    identifier: target,
    symbol: "UNKNOWN",
    name: "Unknown token",
  });
  if (!asset) return null;
  const [row] = await db
    .select()
    .from(securityReports)
    .where(eq(securityReports.assetId, asset.id))
    .limit(1);
  return row ?? null;
}
