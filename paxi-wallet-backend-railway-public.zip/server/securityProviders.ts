import { ENV } from "./_core/env";
import { fetchJson } from "./providers/http";
import type { MarketChain } from "./marketProviders";

const HONEYPOT_CHAIN_ID: Partial<Record<MarketChain, number>> = {
  ethereum: 1,
  bsc: 56,
  polygon: 137,
  arbitrum: 42161,
  base: 8453,
};

const CHAINABUSE_CHAIN: Partial<Record<MarketChain, string>> = {
  ethereum: "ETH",
  bsc: "BINANCE",
  polygon: "POLYGON",
  arbitrum: "ARBITRUM",
  base: "BASE",
};

export interface HoneypotSecurityResult {
  provider: "honeypot";
  available: boolean;
  isHoneypot: boolean | null;
  buyTaxPercent: number | null;
  sellTaxPercent: number | null;
  holderCount: number | null;
}

export interface ChainabuseSecurityResult {
  provider: "chainabuse";
  available: boolean;
  reportCount: number | null;
  hasReports: boolean | null;
}

function finiteNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function asBoolean(value: unknown): boolean | null {
  if (typeof value === "boolean") return value;
  if (value === "true" || value === "1" || value === 1) return true;
  if (value === "false" || value === "0" || value === 0) return false;
  return null;
}

export async function getHoneypotSecurity(chain: MarketChain, contractAddress: string): Promise<HoneypotSecurityResult> {
  const chainId = HONEYPOT_CHAIN_ID[chain];
  const address = contractAddress.trim();
  if (!chainId || !/^0x[0-9a-fA-F]{40}$/.test(address)) {
    return { provider: "honeypot", available: false, isHoneypot: null, buyTaxPercent: null, sellTaxPercent: null, holderCount: null };
  }
  try {
    const url = new URL("https://api.honeypot.is/v2/IsHoneypot");
    url.searchParams.set("address", address);
    url.searchParams.set("chainID", String(chainId));
    const headers: Record<string, string> = ENV.honeypotApiKey ? { "X-API-KEY": ENV.honeypotApiKey } : {};
    const data = await fetchJson<any>(url.toString(), "honeypot", headers);
    const simulation = data?.simulationResult ?? {};
    const honeypotResult = data?.honeypotResult ?? {};
    return {
      provider: "honeypot",
      available: true,
      isHoneypot: asBoolean(honeypotResult.isHoneypot),
      buyTaxPercent: finiteNumber(simulation.buyTax),
      sellTaxPercent: finiteNumber(simulation.sellTax),
      holderCount: finiteNumber(data?.token?.holderCount ?? data?.token?.holders),
    };
  } catch {
    return { provider: "honeypot", available: false, isHoneypot: null, buyTaxPercent: null, sellTaxPercent: null, holderCount: null };
  }
}

export async function getChainabuseSecurity(chain: MarketChain, address: string): Promise<ChainabuseSecurityResult> {
  const chainName = CHAINABUSE_CHAIN[chain];
  const normalized = address.trim();
  if (!ENV.chainabuseApiKey || !chainName || !normalized) {
    return { provider: "chainabuse", available: false, reportCount: null, hasReports: null };
  }
  try {
    const url = new URL("https://api.chainabuse.com/v0/reports");
    url.searchParams.set("address", normalized);
    url.searchParams.set("chain", chainName);
    url.searchParams.set("page", "1");
    url.searchParams.set("perPage", "50");
    const basic = Buffer.from(`${ENV.chainabuseApiKey}:${ENV.chainabuseApiKey}`).toString("base64");
    const data = await fetchJson<any>(url.toString(), "chainabuse", { Authorization: `Basic ${basic}` });
    const reports = Array.isArray(data) ? data : data?.reports ?? data?.data ?? [];
    const reportCount = Array.isArray(reports) ? reports.length : finiteNumber(data?.total ?? data?.count);
    return { provider: "chainabuse", available: true, reportCount, hasReports: reportCount === null ? null : reportCount > 0 };
  } catch {
    return { provider: "chainabuse", available: false, reportCount: null, hasReports: null };
  }
}
