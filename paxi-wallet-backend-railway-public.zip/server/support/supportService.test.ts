import { describe, expect, it } from "vitest";
import {
  assertNoSecretText,
  buildModelSafeContext,
  sanitizeDiagnosticContext,
} from "./supportService";

describe("PAXI support safety boundary", () => {
  it("rejects wallet secrets in support text", () => {
    expect(() => assertNoSecretText("my recovery phrase is ...")).toThrow(
      /Never share/
    );
    expect(() => assertNoSecretText("private key: 0xabc")).toThrow(
      /Never share/
    );
    expect(() => assertNoSecretText("my PIN is 1234")).toThrow(/Never share/);
  });

  it("keeps only allowlisted safe diagnostic context", () => {
    const sanitized = sanitizeDiagnosticContext({
      publicAddress: "0xabc",
      chain: "ethereum",
      transactionHash: "0xhash",
      simulationAvailable: false,
      ignoredField: "not-retained",
    });
    expect(sanitized.publicAddress).toBe("0xabc");
    expect(sanitized.chain).toBe("ethereum");
    expect(sanitized.transactionHash).toBe("0xhash");
    expect(sanitized.simulationAvailable).toBe(false);
    expect(sanitized).not.toHaveProperty("ignoredField");
  });

  it("rejects secret-looking diagnostic keys and values", () => {
    expect(() => sanitizeDiagnosticContext({ recoveryPhrase: "abc" })).toThrow(
      /Sensitive wallet secrets/
    );
    expect(() =>
      sanitizeDiagnosticContext({ error: "send me your password" })
    ).toThrow(/Sensitive wallet secrets/);
  });

  it("keeps internal user identity server-side and excludes it from model context", () => {
    const sanitized = sanitizeDiagnosticContext({
      userId: "internal-user-123",
      walletId: "wallet-123",
      publicAddress: "0xabc",
    });
    expect(sanitized.userId).toBe("internal-user-123");
    expect(buildModelSafeContext(sanitized)).toEqual({
      walletId: "wallet-123",
      publicAddress: "0xabc",
    });
  });
});
