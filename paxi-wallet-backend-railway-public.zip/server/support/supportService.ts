import { randomUUID } from "node:crypto";
import { and, asc, desc, eq } from "drizzle-orm";
import {
  adminAuditEvents,
  supportMessages,
  supportTickets,
  type SupportTicket,
} from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import { invokeLLM, type Message } from "../_core/llm";

const SECRET_PATTERN =
  /(seed\s*phrase|recovery\s*phrase|private\s*key|mnemonic|pin\b|password|encryption\s*key|auth(?:entication)?\s*code|secret)/i;
const MAX_TEXT_LENGTH = 8_000;

export type SafeDiagnosticContext = {
  userId?: string;
  walletId?: string;
  publicAddress?: string;
  chain?: string;
  transactionHash?: string;
  transactionStatus?: string;
  error?: string;
  quoteStatus?: string;
  tokenPair?: string;
  timestamp?: string;
  marketSecurityResults?: string;
  simulationAvailable?: boolean;
};

export function assertNoSecretText(value: string): string {
  const normalized = value.trim();
  if (!normalized) throw new Error("Support content cannot be empty");
  if (normalized.length > MAX_TEXT_LENGTH)
    throw new Error("Support content is too long");
  if (SECRET_PATTERN.test(normalized))
    throw new Error(
      "Never share recovery phrases, private keys, PINs, passwords, or authentication codes with PAXI Support."
    );
  return normalized;
}

export function sanitizeDiagnosticContext(
  input: unknown
): SafeDiagnosticContext {
  if (!input || typeof input !== "object") return {};
  const source = input as Record<string, unknown>;
  for (const [key, value] of Object.entries(source)) {
    if (
      SECRET_PATTERN.test(key) ||
      (typeof value === "string" && SECRET_PATTERN.test(value))
    ) {
      throw new Error(
        "Sensitive wallet secrets cannot be provided to PAXI Support."
      );
    }
  }
  const stringFields = [
    "userId",
    "walletId",
    "publicAddress",
    "chain",
    "transactionHash",
    "transactionStatus",
    "error",
    "quoteStatus",
    "tokenPair",
    "timestamp",
    "marketSecurityResults",
  ] as const;
  const result: SafeDiagnosticContext = {};
  for (const field of stringFields) {
    const value = source[field];
    if (typeof value === "string" && value.trim())
      result[field] = value.trim().slice(0, 500);
  }
  if (typeof source.simulationAvailable === "boolean")
    result.simulationAvailable = source.simulationAvailable;
  return result;
}

function safeTicketKey(): string {
  return `PAXI-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
}

function safeDedupeKey(value: string | undefined): string | null {
  if (!value) return null;
  const key = value.trim();
  if (!key || key.length > 96 || SECRET_PATTERN.test(key))
    throw new Error("Invalid support idempotency key");
  return key;
}

export async function createSupportTicket(input: {
  userOpenId: string;
  category: string;
  subject: string;
  description: string;
  walletId?: string;
  chain?: string;
  transactionHash?: string;
  contractAddress?: string;
  priority?: "LOW" | "NORMAL" | "HIGH" | "URGENT";
  diagnosticContext?: unknown;
  dedupeKey?: string;
}): Promise<SupportTicket> {
  const db = await getDb();
  if (!db)
    throw new Error(
      "Support is temporarily unavailable. Please try again later."
    );
  const subject = assertNoSecretText(input.subject);
  const description = assertNoSecretText(input.description);
  const category = assertNoSecretText(input.category).slice(0, 48);
  const dedupeKey = safeDedupeKey(input.dedupeKey);
  const diagnosticContext = sanitizeDiagnosticContext(input.diagnosticContext);
  if (dedupeKey) {
    const [existing] = await db
      .select()
      .from(supportTickets)
      .where(eq(supportTickets.dedupeKey, dedupeKey))
      .limit(1);
    if (existing && existing.userOpenId === input.userOpenId) return existing;
  }
  const values = {
    ticketKey: safeTicketKey(),
    userOpenId: input.userOpenId,
    walletId: input.walletId?.trim().slice(0, 128) || null,
    category,
    subject: subject.slice(0, 180),
    description,
    chain: input.chain?.trim().slice(0, 32) || null,
    transactionHash: input.transactionHash?.trim().slice(0, 160) || null,
    contractAddress: input.contractAddress?.trim().slice(0, 160) || null,
    priority: input.priority ?? "NORMAL",
    diagnosticContext,
    dedupeKey,
  } as const;
  try {
    await db.insert(supportTickets).values(values);
  } catch (error) {
    if (dedupeKey) {
      const [existing] = await db
        .select()
        .from(supportTickets)
        .where(eq(supportTickets.dedupeKey, dedupeKey))
        .limit(1);
      if (existing && existing.userOpenId === input.userOpenId) return existing;
    }
    throw error;
  }
  const [ticket] = await db
    .select()
    .from(supportTickets)
    .where(eq(supportTickets.ticketKey, values.ticketKey))
    .limit(1);
  if (!ticket) throw new Error("Support ticket could not be created");
  await addSupportMessage({
    ticketId: ticket.id,
    authorType: "USER",
    authorOpenId: input.userOpenId,
    body: description,
    clientMessageKey: dedupeKey ? `${dedupeKey}:initial` : undefined,
  });
  return ticket;
}

export async function addSupportMessage(input: {
  ticketId: number;
  authorType: "USER" | "AI" | "SUPPORT";
  authorOpenId?: string;
  body: string;
  clientMessageKey?: string;
}) {
  const db = await getDb();
  if (!db)
    throw new Error(
      "Support is temporarily unavailable. Please try again later."
    );
  const body = assertNoSecretText(input.body);
  const clientMessageKey = input.clientMessageKey
    ? safeDedupeKey(input.clientMessageKey)
    : null;
  if (clientMessageKey) {
    const [existing] = await db
      .select()
      .from(supportMessages)
      .where(eq(supportMessages.clientMessageKey, clientMessageKey))
      .limit(1);
    if (existing) return existing;
  }
  try {
    await db.insert(supportMessages).values({
      ticketId: input.ticketId,
      authorType: input.authorType,
      authorOpenId: input.authorOpenId ?? null,
      body,
      clientMessageKey,
    });
  } catch (error) {
    if (clientMessageKey) {
      const [existing] = await db
        .select()
        .from(supportMessages)
        .where(eq(supportMessages.clientMessageKey, clientMessageKey))
        .limit(1);
      if (existing) return existing;
    }
    throw error;
  }
  const [message] = await db
    .select()
    .from(supportMessages)
    .where(
      clientMessageKey
        ? eq(supportMessages.clientMessageKey, clientMessageKey)
        : and(
            eq(supportMessages.ticketId, input.ticketId),
            eq(supportMessages.body, body)
          )
    )
    .orderBy(desc(supportMessages.createdAt))
    .limit(1);
  return message;
}

export async function listUserTickets(userOpenId: string) {
  const db = await getReadDb();
  if (!db) return [];
  return db
    .select()
    .from(supportTickets)
    .where(eq(supportTickets.userOpenId, userOpenId))
    .orderBy(desc(supportTickets.updatedAt))
    .limit(100);
}

export async function getUserTicket(userOpenId: string, ticketKey: string) {
  const db = await getReadDb();
  if (!db) return null;
  const [ticket] = await db
    .select()
    .from(supportTickets)
    .where(
      and(
        eq(supportTickets.userOpenId, userOpenId),
        eq(supportTickets.ticketKey, ticketKey)
      )
    )
    .limit(1);
  if (!ticket) return null;
  const messages = await db
    .select()
    .from(supportMessages)
    .where(eq(supportMessages.ticketId, ticket.id))
    .orderBy(asc(supportMessages.createdAt))
    .limit(200);
  return { ticket, messages };
}

export async function listSupportTickets(filters?: {
  status?: "OPEN" | "IN_REVIEW" | "WAITING_FOR_USER" | "RESOLVED" | "CLOSED";
  limit?: number;
}) {
  const db = await getReadDb();
  if (!db) return [];
  const query = db.select().from(supportTickets);
  return filters?.status
    ? query
        .where(eq(supportTickets.status, filters.status))
        .orderBy(desc(supportTickets.updatedAt))
        .limit(filters.limit ?? 100)
    : query
        .orderBy(desc(supportTickets.updatedAt))
        .limit(filters?.limit ?? 100);
}

export async function getSupportTicketForAdmin(ticketKey: string) {
  const db = await getReadDb();
  if (!db) return null;
  const [ticket] = await db
    .select()
    .from(supportTickets)
    .where(eq(supportTickets.ticketKey, ticketKey))
    .limit(1);
  if (!ticket) return null;
  const messages = await db
    .select()
    .from(supportMessages)
    .where(eq(supportMessages.ticketId, ticket.id))
    .orderBy(asc(supportMessages.createdAt))
    .limit(200);
  return { ticket, messages };
}

export async function updateSupportTicket(input: {
  ticketKey: string;
  status?: "OPEN" | "IN_REVIEW" | "WAITING_FOR_USER" | "RESOLVED" | "CLOSED";
  priority?: "LOW" | "NORMAL" | "HIGH" | "URGENT";
  assignedToOpenId?: string | null;
  actorOpenId: string;
}) {
  const db = await getDb();
  if (!db)
    throw new Error(
      "Support is temporarily unavailable. Please try again later."
    );
  const [ticket] = await db
    .select()
    .from(supportTickets)
    .where(eq(supportTickets.ticketKey, input.ticketKey))
    .limit(1);
  if (!ticket) throw new Error("Support ticket not found");
  await db
    .update(supportTickets)
    .set({
      status: input.status ?? ticket.status,
      priority: input.priority ?? ticket.priority,
      assignedToOpenId: input.assignedToOpenId ?? ticket.assignedToOpenId,
    })
    .where(eq(supportTickets.id, ticket.id));
  await db.insert(adminAuditEvents).values({
    actorOpenId: input.actorOpenId,
    action: "support_ticket_updated",
    resourceType: "support_ticket",
    resourceId: ticket.id,
    details: {
      status: input.status ?? ticket.status,
      priority: input.priority ?? ticket.priority,
    },
  });
  const [updated] = await db
    .select()
    .from(supportTickets)
    .where(eq(supportTickets.id, ticket.id))
    .limit(1);
  return updated;
}

const SUPPORT_SYSTEM_PROMPT = `You are PAXI AI Support. Use only the documented PAXI Wallet capabilities in this prompt and the safe diagnostic context supplied by the application. PAXI is a non-custodial wallet: private keys, recovery phrases, PINs, passwords, and signing authority remain on the user's device and are never available to you. Never request or infer secrets. You may explain wallet usage, token discovery, PAXI Shield labels, transaction/swap/bridge statuses, market-data freshness, and documented support flows. Do not claim that liquidity or a market listing means a token is legitimate. Do not fabricate transaction simulation, receipts, prices, security results, or provider data. If simulation is unavailable, say exactly: "Transaction simulation was not available." If the supplied context is insufficient or the user requests an action you cannot safely perform, say so and offer Contact Human Support. You cannot sign, approve, send funds, change wallet settings, or bypass WalletConnect approval. Current documented limitations include controlled-beta provider availability, supported-chain route limits, and WalletConnect being disabled by default.

The user may ask for help with: general wallet questions; product how-to guidance; transaction troubleshooting; swap or bridge troubleshooting; PAXI Shield explanations; token search; common error explanations; and ticket escalation.`;

export function buildModelSafeContext(
  context: SafeDiagnosticContext
): Omit<SafeDiagnosticContext, "userId"> {
  const { userId: _serverOnlyUserId, ...modelContext } = context;
  return modelContext;
}

function responseText(result: Awaited<ReturnType<typeof invokeLLM>>): string {
  const content = result.choices[0]?.message?.content;
  if (typeof content === "string" && content.trim()) return content.trim();
  if (Array.isArray(content))
    return content
      .filter(part => part.type === "text")
      .map(part => part.text)
      .join("\n")
      .trim();
  return "I could not safely produce an answer from the available information. Please contact human support.";
}

export async function askPaxiAI(input: {
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  diagnosticContext?: unknown;
}) {
  if (!Array.isArray(input.messages) || input.messages.length === 0) {
    throw new Error("At least one support message is required");
  }
  const safeContext = sanitizeDiagnosticContext(input.diagnosticContext);
  const safeMessages: Message[] = input.messages.slice(-12).map(message => ({
    role: message.role,
    content: assertNoSecretText(message.content),
  }));
  const contextMessage = `Safe read-only diagnostic context (may be incomplete): ${JSON.stringify({ ...buildModelSafeContext(safeContext), simulationAvailable: safeContext.simulationAvailable ?? false })}`;
  try {
    const result = await invokeLLM({
      model: process.env.PAXI_SUPPORT_MODEL || undefined,
      maxTokens: 700,
      messages: [
        { role: "system", content: SUPPORT_SYSTEM_PROMPT },
        { role: "system", content: contextMessage },
        ...safeMessages,
      ],
    });
    const answer = responseText(result);
    return {
      answer,
      escalationSuggested:
        /human support|contact support|do not know|cannot safely|simulation was not available/i.test(
          answer
        ),
    };
  } catch (error) {
    console.warn(
      "[support] AI provider unavailable; escalating to human support",
      error
    );
    return {
      answer:
        "PAXI AI Support is temporarily unavailable. No wallet action was taken. Please contact human support and include only your public address, transaction hash, network, and the visible error message.",
      escalationSuggested: true,
    };
  }
}
