import { invokePaxiAI } from "../_core/llm";

export const TICKET_CATEGORIES = [
  "wallet_access",
  "transaction_issue",
  "swap_bridge",
  "security_concern",
  "fees_billing",
  "feature_request",
  "other",
] as const;
export type TicketCategory = (typeof TICKET_CATEGORIES)[number];
export const TICKET_PRIORITIES = ["low", "normal", "high", "urgent"] as const;
export type TicketPriority = (typeof TICKET_PRIORITIES)[number];

export interface TicketTriageResult {
  category: TicketCategory;
  priority: TicketPriority;
  summary: string;
  confidencePercent: number;
}

const TRIAGE_SCHEMA = {
  name: "ticket_triage",
  schema: {
    type: "object",
    properties: {
      category: { type: "string", enum: TICKET_CATEGORIES as unknown as string[] },
      priority: { type: "string", enum: TICKET_PRIORITIES as unknown as string[] },
      summary: { type: "string", description: "One-sentence summary for a support admin scanning a queue." },
      confidencePercent: { type: "integer", minimum: 0, maximum: 100 },
    },
    required: ["category", "priority", "summary", "confidencePercent"],
    additionalProperties: false,
  },
  strict: true,
} as const;

const SYSTEM_PROMPT = `You triage incoming support tickets for a non-custodial crypto wallet app (PAXI). Classify each ticket so a human support agent can prioritize their queue.

Priority guide:
- urgent: funds appear at risk right now (stuck mid-transaction with money moving, suspected compromised wallet, active phishing).
- high: a core feature (send/swap/bridge) is broken or blocking the user right now, but funds are not actively at risk.
- normal: a question, a minor bug, or an issue with a workaround.
- low: feature requests, feedback, cosmetic issues.

Never downplay a report that mentions lost funds, an unauthorized transaction, or a suspected scam - route those security_concern + at least high priority.`;

/** Best-effort classification for the support admin queue - always advisory, an admin can override any field. */
export async function triageTicket(subject: string, message: string): Promise<TicketTriageResult | null> {
  try {
    const result = await invokePaxiAI({
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: `Subject: ${subject}\n\nMessage:\n${message}` },
      ],
      responseFormat: { type: "json_schema", json_schema: TRIAGE_SCHEMA },
      maxTokens: 400,
    });
    const raw = result.choices[0]?.message?.content;
    const text = typeof raw === "string" ? raw : Array.isArray(raw) ? raw.map((p) => (p.type === "text" ? p.text : "")).join("") : "";
    const parsed = JSON.parse(text) as TicketTriageResult;
    if (!TICKET_CATEGORIES.includes(parsed.category) || !TICKET_PRIORITIES.includes(parsed.priority)) return null;
    return {
      category: parsed.category,
      priority: parsed.priority,
      summary: parsed.summary,
      confidencePercent: Math.max(0, Math.min(100, Math.round(parsed.confidencePercent))),
    };
  } catch (error) {
    console.warn("[ticketTriage] AI triage failed, ticket will need manual triage:", error instanceof Error ? error.message : error);
    return null;
  }
}
