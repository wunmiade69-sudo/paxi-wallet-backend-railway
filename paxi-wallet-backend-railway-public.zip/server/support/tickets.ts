import { desc, eq } from "drizzle-orm";
import { getDb } from "../db";
import { supportTickets, type SupportTicket } from "../../drizzle/schema";
import { triageTicket, TICKET_CATEGORIES, TICKET_PRIORITIES, type TicketCategory, type TicketPriority } from "./ticketTriage";

export interface SubmitTicketInput {
  userOpenId: string | null;
  walletAddress: string | null;
  contactEmail: string | null;
  subject: string;
  message: string;
}

/** AI triage runs synchronously before insert so the ticket lands in the admin queue pre-sorted. If triage fails, the ticket still gets created with sane defaults - it just needs a human to categorize it. */
export async function submitTicket(input: SubmitTicketInput): Promise<SupportTicket> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const triage = await triageTicket(input.subject, input.message);

  const [result] = await db.insert(supportTickets).values({
    userOpenId: input.userOpenId,
    walletAddress: input.walletAddress,
    contactEmail: input.contactEmail,
    subject: input.subject,
    message: input.message,
    category: triage?.category ?? "other",
    priority: triage?.priority ?? "normal",
    aiSummary: triage?.summary ?? null,
    aiSuggestedCategory: triage?.category ?? null,
    aiSuggestedPriority: triage?.priority ?? null,
    aiConfidencePercent: triage?.confidencePercent ?? null,
  });

  const insertedId = Number((result as unknown as { insertId?: number | string }).insertId);
  const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.id, insertedId)).limit(1);
  if (!ticket) throw new Error("Ticket was created but could not be re-read");
  return ticket;
}

export interface ListTicketsInput {
  status?: SupportTicket["status"];
  limit?: number;
}

export async function listTickets(input: ListTicketsInput = {}): Promise<SupportTicket[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const limit = Math.min(Math.max(input.limit ?? 50, 1), 200);
  if (input.status) {
    return db.select().from(supportTickets).where(eq(supportTickets.status, input.status)).orderBy(desc(supportTickets.priority), desc(supportTickets.createdAt)).limit(limit);
  }
  return db.select().from(supportTickets).orderBy(desc(supportTickets.priority), desc(supportTickets.createdAt)).limit(limit);
}

export interface UpdateTicketInput {
  id: number;
  status?: SupportTicket["status"];
  priority?: TicketPriority;
  category?: TicketCategory;
  assignedAdminOpenId?: string | null;
  resolutionNote?: string | null;
}

export async function updateTicket(input: UpdateTicketInput): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updates: Partial<typeof supportTickets.$inferInsert> = {};
  if (input.status) updates.status = input.status;
  if (input.priority && TICKET_PRIORITIES.includes(input.priority)) updates.priority = input.priority;
  if (input.category && TICKET_CATEGORIES.includes(input.category)) updates.category = input.category;
  if (input.assignedAdminOpenId !== undefined) updates.assignedAdminOpenId = input.assignedAdminOpenId;
  if (input.resolutionNote !== undefined) updates.resolutionNote = input.resolutionNote;
  if (input.status === "resolved" || input.status === "closed") updates.resolvedAt = new Date();
  if (Object.keys(updates).length === 0) return;
  await db.update(supportTickets).set(updates).where(eq(supportTickets.id, input.id));
}

export async function getUserTickets(userOpenId: string): Promise<SupportTicket[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(supportTickets).where(eq(supportTickets.userOpenId, userOpenId)).orderBy(desc(supportTickets.createdAt)).limit(50);
}
