import { beforeEach, describe, expect, it, vi } from "vitest";

const SOL = "So11111111111111111111111111111111111111112";
const USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
const WALLET = "11111111111111111111111111111111";

describe("server-side swap provider adapters", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.restoreAllMocks();
    vi.unstubAllEnvs();
    vi.stubEnv("LIFI_API_KEY", "");
  });

  it("builds a validated Jupiter quote request and normalizes a real route shape", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        inputMint: SOL,
        outputMint: USDC,
        inAmount: "100000000",
        outAmount: "25000000",
        otherAmountThreshold: "24750000",
        routePlan: [{ swapInfo: { label: "Raydium" } }],
      }),
    });
    vi.stubGlobal("fetch", fetchMock);
    const adapter = await import("./jupiterSwap");

    const result = await adapter.fetchJupiterSwapQuote({ inputMint: SOL, outputMint: USDC, amount: "100000000", slippageBps: 100 });
    expect(result).toMatchObject({ inputAmountUnits: "100000000", outputAmountUnits: "25000000", minimumOutputAmountUnits: "24750000", routeNames: ["Raydium"] });
    expect(fetchMock.mock.calls[0]?.[0]).toContain("/v6/quote?");
  });

  it("rejects malformed Jupiter responses and provider failures without fabricating a route", async () => {
    const cases = [
      { ok: true, json: async () => ({ inAmount: "0", outAmount: "0" }) },
      { ok: false, status: 429 },
    ];
    for (const response of cases) {
      vi.resetModules();
      vi.stubGlobal("fetch", vi.fn().mockResolvedValue(response));
      const adapter = await import("./jupiterSwap");
      await expect(adapter.fetchJupiterSwapQuote({ inputMint: SOL, outputMint: USDC, amount: "100000000", slippageBps: 100 })).rejects.toThrow();
    }
  });

  it("builds unsigned Jupiter instructions through the server adapter", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        computeBudgetInstructions: [],
        setupInstructions: [],
        swapInstruction: { programId: SOL, accounts: [], data: "" },
        cleanupInstruction: null,
        addressLookupTableAddresses: [],
      }),
    });
    vi.stubGlobal("fetch", fetchMock);
    const adapter = await import("./jupiterSwap");
    const result = await adapter.buildJupiterSwapInstructions({ quoteResponse: { inAmount: "1" }, userPublicKey: WALLET });
    expect(result.swapInstruction).toMatchObject({ programId: SOL });
    expect(fetchMock.mock.calls[0]?.[1]).toMatchObject({ method: "POST" });
  });

  it("allowlists THORChain destinations and degrades status to unknown on provider failure", async () => {
    const fetchMock = vi.fn().mockRejectedValue(new Error("timeout"));
    vi.stubGlobal("fetch", fetchMock);
    const thor = await import("./thorchain");
    await expect(thor.fetchThorchainQuote({ destinationAsset: "FAKE.BTC", destinationAddress: WALLET, amountSats: "1000" })).rejects.toThrow(/not supported/i);
    await expect(thor.fetchThorchainSwapStatus("txid")).resolves.toBe("unknown");
  });

  it("normalizes a THORChain quote response without inventing missing fields", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ inbound_address: WALLET, memo: "=:ETH.ETH:0xabc", expected_amount_out: "123000000", fees: { total: "100000" }, expiry: 60 }),
    }));
    const thor = await import("./thorchain");
    await expect(thor.fetchThorchainQuote({ destinationAsset: "ETH.ETH", destinationAddress: WALLET, amountSats: "100000000" })).resolves.toMatchObject({ inboundAddress: WALLET, expectedAmountOutFormatted: "1.23", expirySeconds: 60 });
  });

  it("uses the shared provider helper for LI.FI and rejects malformed routes", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => ({ estimate: {}, transactionRequest: {} }) }));
    const lifi = await import("./lifiQuote");
    await expect(lifi.fetchLifiQuote({ fromChain: 1, toChain: 56, fromToken: "0x0000000000000000000000000000000000000001", toToken: "0x0000000000000000000000000000000000000002", fromAddress: "0x0000000000000000000000000000000000000003", toAddress: "0x0000000000000000000000000000000000000004", fromAmount: "1", slippage: 0.01 })).resolves.toMatchObject({ estimate: {}, transactionRequest: {} });
  });
});
