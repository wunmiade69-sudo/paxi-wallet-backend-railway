import { afterEach, describe, expect, it, vi } from "vitest";

// server/thorchain.ts talks to THORChain through server/providers/http.ts's
// fetchJson(), which layers a Redis-backed cooldown check and a circuit
// breaker on top of fetch(). Neither needs mocking here: with no REDIS_URL
// configured (the default in this sandbox, matching server/swapProviders.test.ts),
// the cooldown check safely no-ops and the circuit breaker is in-memory only.

const LIQUIFY_THORNODE_BASE = "https://gateway.liquify.com/chain/thorchain_api/thorchain";
const LIQUIFY_MIDGARD_BASE = "https://gateway.liquify.com/chain/thorchain_midgard/v2";
const NINE_REALMS_HOST_PATTERN = /ninerealms\.com/i;

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("THORChain gateway (server/thorchain.ts)", () => {
  // This is the load-bearing test for the fix in this audit: it fails loudly
  // if server/thorchain.ts is ever edited to point back at the Nine Realms
  // hosts, which reports/THORCHAIN_GATEWAY_FINDINGS.md documents as
  // unreachable from this server. The deployed code and the documented
  // working gateway must not be able to diverge silently.
  it("requests quotes from the documented Liquify gateway, never Nine Realms", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: { get: () => null },
      json: async () => ({
        inbound_address: "bc1qinbound",
        memo: "=:ETH.ETH:0x0000000000000000000000000000000000000001",
        expected_amount_out: "123456789",
        fees: { total: "1000" },
        expiry: 1_900_000_000,
      }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const { fetchThorchainQuote } = await import("./thorchain");
    await fetchThorchainQuote({
      destinationAsset: "ETH.ETH",
      destinationAddress: "0x0000000000000000000000000000000000000001",
      amountSats: "1000000",
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const requestedUrl = String(fetchMock.mock.calls[0]?.[0]);
    expect(requestedUrl.startsWith(`${LIQUIFY_THORNODE_BASE}/quote/swap?`)).toBe(true);
    expect(requestedUrl).not.toMatch(NINE_REALMS_HOST_PATTERN);
  });

  it("polls swap status from the documented Liquify Midgard gateway, never Nine Realms", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: { get: () => null },
      json: async () => ({ actions: [{ status: "success" }] }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const { fetchThorchainSwapStatus } = await import("./thorchain");
    const status = await fetchThorchainSwapStatus("a".repeat(64));

    expect(status).toBe("completed");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const requestedUrl = String(fetchMock.mock.calls[0]?.[0]);
    expect(requestedUrl.startsWith(`${LIQUIFY_MIDGARD_BASE}/actions?`)).toBe(true);
    expect(requestedUrl).not.toMatch(NINE_REALMS_HOST_PATTERN);
  });

  it("surfaces the upstream trading-halt error distinctly from other failures", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: { get: () => null },
      json: async () => ({ error: "failed to simulate swap: failed to simulate handler: trading is halted, can't process swap" }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const { fetchThorchainQuote } = await import("./thorchain");
    await expect(
      fetchThorchainQuote({
        destinationAsset: "ETH.ETH",
        destinationAddress: "0x0000000000000000000000000000000000000001",
        amountSats: "1000000",
      }),
    ).rejects.toThrow(/temporarily paused network-wide/);
  });
});
