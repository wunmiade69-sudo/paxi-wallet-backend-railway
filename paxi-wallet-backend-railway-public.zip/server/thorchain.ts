import { fetchJson } from "./providers/http";
import { formatBaseUnits, parseExactIntegerUnits } from "@shared/exactDecimal";

/** THORChain expresses all cross-chain swap amounts (input, output, fees) as
 * integer strings at a fixed 8-decimal scale, regardless of the destination
 * asset's own on-chain decimals. */
const THORCHAIN_UNIT_DECIMALS = 8;

// Per reports/THORCHAIN_GATEWAY_FINDINGS.md: the Nine Realms hosts
// (thornode.ninerealms.com / midgard.ninerealms.com) returned an upstream
// DNS/fetch failure from this server's network. The Liquify gateway is the
// confirmed-working path documented in THORChain's own developer
// quickstart (https://dev.thorchain.org/swap-guide/quickstart-guide.html)
// and is the endpoint this wallet has actually been verified against.
// server/thorchain.test.ts pins these constants so a future edit can't
// silently drift back to the Nine Realms hosts without a failing test.
const THORNODE_API = "https://gateway.liquify.com/chain/thorchain_api/thorchain";
const MIDGARD_API = "https://gateway.liquify.com/chain/thorchain_midgard/v2";

export const THORCHAIN_DESTINATION_ASSETS = new Set([
  "ETH.ETH",
  "BSC.BNB",
  "BSC.USDT-0X55D398326F99059FF775485246999027B3197955",
  "ETH.USDT-0XDAC17F958D2EE523A2206206994597C13D831EC",
]);

export interface ThorchainQuoteInput {
  destinationAsset: string;
  destinationAddress: string;
  amountSats: string;
}

export interface ThorchainQuoteResult {
  inboundAddress: string;
  memo: string;
  amountInBtc: string;
  expectedAmountOutFormatted: string;
  destAssetLabel: string;
  totalFeesUsd?: string;
  expirySeconds: number;
  warning?: string;
  raw: Record<string, unknown>;
}

function assertAmountSats(value: string): string {
  if (!/^[0-9]+$/.test(value) || value === "0" || value.length > 20) throw new Error("Enter a valid BTC amount.");
  return value;
}

function assertDestination(input: ThorchainQuoteInput): void {
  if (!THORCHAIN_DESTINATION_ASSETS.has(input.destinationAsset)) throw new Error("This THORChain destination is not supported yet.");
  if (!input.destinationAddress || input.destinationAddress.length > 128) throw new Error("A destination address is required.");
  assertAmountSats(input.amountSats);
}

export function buildThorchainQuoteUrl(input: ThorchainQuoteInput): string {
  assertDestination(input);
  const query = new URLSearchParams({
    from_asset: "BTC.BTC",
    to_asset: input.destinationAsset,
    amount: input.amountSats,
    destination: input.destinationAddress,
  });
  return `${THORNODE_API}/quote/swap?${query.toString()}`;
}

export async function fetchThorchainQuote(input: ThorchainQuoteInput): Promise<ThorchainQuoteResult> {
  const data = await fetchJson<Record<string, unknown>>(buildThorchainQuoteUrl(input), "thornode");
  if (typeof data.error === "string" && data.error) {
    if (/halt/i.test(data.error)) throw new Error("THORChain trading is temporarily paused network-wide. This is not specific to your swap - try again later.");
    throw new Error(`THORChain: ${data.error}`);
  }
  const inboundAddress = typeof data.inbound_address === "string" ? data.inbound_address : "";
  const memo = typeof data.memo === "string" ? data.memo : "";
  if (!inboundAddress || !memo) throw new Error("THORChain did not return a usable quote for this route.");

  // THORChain's expected_amount_out is a settlement-relevant monetary value
  // reported as an integer string at THORChAIN_UNIT_DECIMALS - parse it
  // exactly with bigint, never Number, since it can exceed 2^53 for
  // low-decimal high-supply destination assets.
  let expectedOutUnits: bigint;
  try {
    expectedOutUnits = parseExactIntegerUnits(data.expected_amount_out ?? "0", "expected_amount_out");
  } catch {
    throw new Error("THORChain returned an unavailable route.");
  }
  if (expectedOutUnits <= 0n) throw new Error("THORChain returned an unavailable route.");

  const fees = data.fees && typeof data.fees === "object" ? data.fees as Record<string, unknown> : null;
  let totalFeeUnits = 0n;
  if (fees?.total !== undefined) {
    try {
      totalFeeUnits = parseExactIntegerUnits(fees.total, "fees.total");
    } catch {
      totalFeeUnits = 0n;
    }
  }

  // amountSats is already validated as a plain non-negative integer string
  // by assertAmountSats() in buildThorchainQuoteUrl(), so it is safe to
  // parse the same way here.
  const amountSatsUnits = parseExactIntegerUnits(input.amountSats, "amountSats");

  return {
    inboundAddress,
    memo,
    amountInBtc: formatBaseUnits(amountSatsUnits, THORCHAIN_UNIT_DECIMALS),
    expectedAmountOutFormatted: formatBaseUnits(expectedOutUnits, THORCHAIN_UNIT_DECIMALS),
    destAssetLabel: input.destinationAsset,
    totalFeesUsd: totalFeeUnits > 0n ? formatBaseUnits(totalFeeUnits, THORCHAIN_UNIT_DECIMALS) : undefined,
    expirySeconds: typeof data.expiry === "number" && Number.isFinite(data.expiry) ? data.expiry : 0,
    warning: typeof data.warning === "string" ? data.warning : undefined,
    raw: data,
  };
}

export type ThorchainSwapStatus = "pending" | "observed" | "completed" | "unknown";

export async function fetchThorchainSwapStatus(txid: string): Promise<ThorchainSwapStatus> {
  if (!/^[A-Za-z0-9:_-]{1,128}$/.test(txid)) return "unknown";
  try {
    const data = await fetchJson<Record<string, unknown>>(`${MIDGARD_API}/actions?txid=${encodeURIComponent(txid)}`, "midgard");
    const actions = Array.isArray(data.actions) ? data.actions : [];
    const action = actions[0] && typeof actions[0] === "object" ? actions[0] as Record<string, unknown> : null;
    if (!action) return "pending";
    if (action.status === "success") return "completed";
    return "observed";
  } catch {
    return "unknown";
  }
}
