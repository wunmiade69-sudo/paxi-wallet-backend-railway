import { fetchJson } from "./providers/http";

const THORNODE_API = "https://thornode.ninerealms.com/thorchain";
const MIDGARD_API = "https://midgard.ninerealms.com/v2";

export const THORCHAIN_DESTINATION_ASSETS = new Set([
  "ETH.ETH",
  "BSC.BNB",
  "BSC.USDT-0X55D398326F99059FF775485246999027B3197955",
  "ETH.USDT-0XDAC17F958D2EE523A2206206994597C13D831EC",
]);

export interface ThorchainQuoteInput {
  destinationAsset: string;
  destinationAddress: string;
  amountSats: string;
}

export interface ThorchainQuoteResult {
  inboundAddress: string;
  memo: string;
  amountInBtc: string;
  expectedAmountOutFormatted: string;
  destAssetLabel: string;
  totalFeesUsd?: string;
  expirySeconds: number;
  warning?: string;
  raw: Record<string, unknown>;
}

function assertAmountSats(value: string): string {
  if (!/^[0-9]+$/.test(value) || value === "0" || value.length > 20) throw new Error("Enter a valid BTC amount.");
  return value;
}

function assertDestination(input: ThorchainQuoteInput): void {
  if (!THORCHAIN_DESTINATION_ASSETS.has(input.destinationAsset)) throw new Error("This THORChain destination is not supported yet.");
  if (!input.destinationAddress || input.destinationAddress.length > 128) throw new Error("A destination address is required.");
  assertAmountSats(input.amountSats);
}

export function buildThorchainQuoteUrl(input: ThorchainQuoteInput): string {
  assertDestination(input);
  const query = new URLSearchParams({
    from_asset: "BTC.BTC",
    to_asset: input.destinationAsset,
    amount: input.amountSats,
    destination: input.destinationAddress,
  });
  return `${THORNODE_API}/quote/swap?${query.toString()}`;
}

export async function fetchThorchainQuote(input: ThorchainQuoteInput): Promise<ThorchainQuoteResult> {
  const data = await fetchJson<Record<string, unknown>>(buildThorchainQuoteUrl(input), "thornode");
  if (typeof data.error === "string" && data.error) {
    if (/halt/i.test(data.error)) throw new Error("THORChain trading is temporarily paused network-wide. This is not specific to your swap - try again later.");
    throw new Error(`THORChain: ${data.error}`);
  }
  const inboundAddress = typeof data.inbound_address === "string" ? data.inbound_address : "";
  const memo = typeof data.memo === "string" ? data.memo : "";
  if (!inboundAddress || !memo) throw new Error("THORChain did not return a usable quote for this route.");
  const expectedOutUnits = Number(data.expected_amount_out ?? 0);
  if (!Number.isFinite(expectedOutUnits) || expectedOutUnits <= 0) throw new Error("THORChain returned an unavailable route.");
  const fees = data.fees && typeof data.fees === "object" ? data.fees as Record<string, unknown> : null;
  const totalFeeUnits = Number(fees?.total ?? 0);
  return {
    inboundAddress,
    memo,
    amountInBtc: (Number(input.amountSats) / 1e8).toString(),
    expectedAmountOutFormatted: (expectedOutUnits / 1e8).toString(),
    destAssetLabel: input.destinationAsset,
    totalFeesUsd: Number.isFinite(totalFeeUnits) && totalFeeUnits > 0 ? (totalFeeUnits / 1e8).toFixed(2) : undefined,
    expirySeconds: typeof data.expiry === "number" && Number.isFinite(data.expiry) ? data.expiry : 0,
    warning: typeof data.warning === "string" ? data.warning : undefined,
    raw: data,
  };
}

export type ThorchainSwapStatus = "pending" | "observed" | "completed" | "unknown";

export async function fetchThorchainSwapStatus(txid: string): Promise<ThorchainSwapStatus> {
  if (!/^[A-Za-z0-9:_-]{1,128}$/.test(txid)) return "unknown";
  try {
    const data = await fetchJson<Record<string, unknown>>(`${MIDGARD_API}/actions?txid=${encodeURIComponent(txid)}`, "midgard");
    const actions = Array.isArray(data.actions) ? data.actions : [];
    const action = actions[0] && typeof actions[0] === "object" ? actions[0] as Record<string, unknown> : null;
    if (!action) return "pending";
    if (action.status === "success") return "completed";
    return "observed";
  } catch {
    return "unknown";
  }
}
