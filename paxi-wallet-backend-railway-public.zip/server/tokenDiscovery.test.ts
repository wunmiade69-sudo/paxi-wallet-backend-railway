import { describe, expect, it } from "vitest";
import {
  detectAddressChains,
  looksLikeEvmAddress,
  looksLikeSolanaAddress,
  rankDiscoveryResults,
  selectCurrentSecurityReport,
  mapSecurityReportLabel,
  mapAssetVerificationStatus,
  mergeDiscoveryResults,
  tokenStandardForChain,
  type CanonicalTokenResult,
} from "./tokenDiscovery";

const evm = "0x0000000000000000000000000000000000000001";
const solana = "11111111111111111111111111111111";

function result(
  overrides: Partial<CanonicalTokenResult>
): CanonicalTokenResult {
  return {
    id: "ethereum:0x1",
    chainId: "ethereum",
    chainName: "Ethereum",
    contractAddress: evm,
    tokenStandard: "erc20",
    canonicalIdentity:
      "ethereum:erc20:0x0000000000000000000000000000000000000001",
    name: "Example Token",
    symbol: "EXT",
    logoUrl: null,
    priceUsd: null,
    change24h: null,
    liquidityUsd: 100,
    volume24hUsd: 100,
    marketCapUsd: null,
    fdvUsd: null,
    marketCount: 1,
    dataFreshness: "fresh",
    dataAgeMs: 1_000,
    trust: "unverified",
    security: "unknown",
    securityScore: null,
    confidence: "medium",
    confidenceScore: 50,
    sources: ["dexscreener"],
    explorerUrl: null,
    coinId: null,
    exactMatch: false,
    ...overrides,
  };
}

describe("token discovery identity and ranking", () => {
  it("detects EVM and Solana addresses without accepting malformed values", () => {
    expect(looksLikeEvmAddress(evm)).toBe(true);
    expect(looksLikeEvmAddress("0x1234")).toBe(false);
    expect(looksLikeSolanaAddress(solana)).toBe(true);
    expect(looksLikeSolanaAddress("not-a-chain-address")).toBe(false);
  });

  it("maps EVM addresses to supported EVM chains and Solana addresses only to Solana", () => {
    expect(detectAddressChains(evm)).toEqual([
      "ethereum",
      "bsc",
      "polygon",
      "arbitrum",
    ]);
    expect(detectAddressChains(solana)).toEqual(["solana"]);
    expect(detectAddressChains("PAXI")).toEqual([]);
  });

  it("uses the chain-specific token standard in canonical identity", () => {
    expect(tokenStandardForChain("ethereum", evm)).toBe("erc20");
    expect(tokenStandardForChain("bsc", evm)).toBe("bep20");
    expect(tokenStandardForChain("solana", solana)).toBe("spl-token");
    expect(tokenStandardForChain("ethereum", "native")).toBe("native");
    expect(result({}).canonicalIdentity).toBe(
      "ethereum:erc20:0x0000000000000000000000000000000000000001"
    );
  });

  it("merges duplicate observations by chain, token standard, and contract", () => {
    const merged = mergeDiscoveryResults([
      result({ sources: ["coingecko"], security: "unknown" }),
      result({
        sources: ["dexscreener"],
        security: "warning",
        securityScore: 20,
      }),
      result({
        chainId: "bsc",
        contractAddress: evm,
        tokenStandard: "bep20",
        canonicalIdentity: `bsc:bep20:${evm}`,
        sources: ["dexpaprika"],
      }),
    ]);
    expect(merged).toHaveLength(2);
    expect(merged[0].sources).toEqual(["coingecko", "dexscreener"]);
    expect(merged[0].security).toBe("warning");
    expect(merged[1].canonicalIdentity).toBe(`bsc:bep20:${evm}`);
  });

  it("ranks exact contract matches above symbols while preferring verified safe data", () => {
    const symbolMatch = result({
      symbol: "PAXI",
      canonicalIdentity: "ethereum:erc20:paxi",
    });
    const exact = result({
      symbol: "UNKNOWN",
      canonicalIdentity: `ethereum:erc20:${evm}`,
      contractAddress: evm,
      exactMatch: true,
      trust: "verified",
      security: "safe",
      confidenceScore: 90,
      liquidityUsd: 1_000_000,
    });
    expect(rankDiscoveryResults([symbolMatch, exact], evm)[0]).toBe(exact);
  });
});

describe("verification trust is separate from security assessment", () => {
  it("maps only explicit verification statuses and preserves unknown states", () => {
    expect(mapAssetVerificationStatus("verified")).toBe("verified");
    expect(mapAssetVerificationStatus("registered")).toBe("unverified");
    expect(mapAssetVerificationStatus("safe")).toBe("unknown");
    expect(mapAssetVerificationStatus(null)).toBe("unknown");
  });
});

describe("token security report freshness", () => {
  const now = Date.parse("2026-08-18T12:00:00.000Z");

  it("selects the newest report rather than an older historical assessment", () => {
    const current = selectCurrentSecurityReport(
      [
        { label: "verified", score: 95, checkedAt: "2026-08-17T12:00:00.000Z" },
        { label: "risky", score: 20, checkedAt: "2026-08-18T11:30:00.000Z" },
      ],
      now
    );
    expect(current?.label).toBe("risky");
    expect(mapSecurityReportLabel(current)).toEqual({
      security: "warning",
      securityScore: 20,
    });
  });

  it("returns unknown when no report exists", () => {
    expect(selectCurrentSecurityReport([], now)).toBeNull();
    expect(mapSecurityReportLabel(null)).toEqual({
      security: "unknown",
      securityScore: null,
    });
  });

  it("rejects malformed current reports instead of falling back to an older safe result", () => {
    const current = selectCurrentSecurityReport(
      [
        { label: "verified", score: 99, checkedAt: "2026-08-17T12:00:00.000Z" },
        {
          label: "not-a-valid-label",
          score: 100,
          checkedAt: "2026-08-18T11:30:00.000Z",
        },
      ],
      now
    );
    expect(current).toBeNull();
    expect(mapSecurityReportLabel(current)).toEqual({
      security: "unknown",
      securityScore: null,
    });
  });

  it("rejects stale current reports and exposes unknown security", () => {
    const current = selectCurrentSecurityReport(
      [{ label: "verified", score: 99, checkedAt: "2026-08-16T11:59:59.000Z" }],
      now
    );
    expect(current).toBeNull();
    expect(mapSecurityReportLabel(current).security).toBe("unknown");
  });
});
