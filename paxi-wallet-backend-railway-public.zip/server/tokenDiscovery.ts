import { isAddress } from "ethers";
import { PublicKey } from "@solana/web3.js";
import { and, desc, eq } from "drizzle-orm";
import { assets, securityReports } from "../drizzle/schema";
import { getReadDb } from "./db";
import {
  getTokenDetail,
  type MarketToken,
  type TokenDetail,
} from "./marketData";
import {
  fetchAggregatedMarket,
  type AggregatedMarket,
} from "./providers/aggregator";
import { marketProviders } from "./providers";
import type { ProviderSearchResult, TokenStandard } from "./providers/types";
import { normalizeIdentifier } from "./assetRegistry";

const PLATFORM_TO_CHAIN: Record<string, string> = {
  ethereum: "ethereum",
  "binance-smart-chain": "bsc",
  "polygon-pos": "polygon",
  "arbitrum-one": "arbitrum",
  solana: "solana",
};

const CHAIN_LABELS: Record<string, string> = {
  ethereum: "Ethereum",
  bsc: "BNB Smart Chain",
  polygon: "Polygon",
  arbitrum: "Arbitrum One",
  solana: "Solana",
  bitcoin: "Bitcoin",
};

export function tokenStandardForChain(
  chainId: string,
  contractAddress: string
): TokenStandard {
  if (contractAddress === "native") return "native";
  if (chainId === "bsc") return "bep20";
  if (chainId === "solana") return "spl-token";
  if (["ethereum", "polygon", "arbitrum"].includes(chainId)) return "erc20";
  return "unknown";
}

export type DiscoveryStatus =
  "found" | "not_found" | "unsupported_chain" | "provider_unavailable";
export type DiscoveryTrust = "verified" | "unverified" | "unknown";
export type DiscoverySecurity = "safe" | "warning" | "high_risk" | "unknown";

const SECURITY_REPORT_MAX_AGE_MS = 24 * 60 * 60 * 1_000;
const SECURITY_REPORT_LABELS = new Set([
  "verified",
  "unverified",
  "risky",
  "scam_suspicious",
]);

export type SecurityAssessmentRecord = {
  label: unknown;
  score?: unknown;
  checkedAt?: Date | string | null;
  updatedAt?: Date | string | null;
};

export function selectCurrentSecurityReport(
  reports: SecurityAssessmentRecord[],
  nowMs = Date.now()
): SecurityAssessmentRecord | null {
  const ordered = [...reports].sort((a, b) => {
    const aTime = new Date(a.checkedAt ?? a.updatedAt ?? 0).getTime();
    const bTime = new Date(b.checkedAt ?? b.updatedAt ?? 0).getTime();
    return bTime - aTime;
  });
  const current = ordered[0];
  if (!current || !SECURITY_REPORT_LABELS.has(String(current.label)))
    return null;
  const checkedAt = new Date(
    current.checkedAt ?? current.updatedAt ?? ""
  ).getTime();
  if (
    !Number.isFinite(checkedAt) ||
    nowMs - checkedAt > SECURITY_REPORT_MAX_AGE_MS
  )
    return null;
  return current;
}

export function mapAssetVerificationStatus(
  status: string | null | undefined
): DiscoveryTrust {
  if (status === "verified") return "verified";
  if (status === "registered") return "unverified";
  return "unknown";
}

export function mapSecurityReportLabel(
  report: SecurityAssessmentRecord | null
): { security: DiscoverySecurity; securityScore: number | null } {
  if (!report) return { security: "unknown", securityScore: null };
  const security: DiscoverySecurity =
    report.label === "verified"
      ? "safe"
      : report.label === "risky"
        ? "warning"
        : report.label === "scam_suspicious"
          ? "high_risk"
          : "unknown";
  return {
    security,
    securityScore: typeof report.score === "number" ? report.score : null,
  };
}

export interface CanonicalTokenResult {
  id: string;
  chainId: string;
  chainName: string;
  contractAddress: string;
  tokenStandard: TokenStandard;
  canonicalIdentity: string;
  name: string;
  symbol: string;
  logoUrl: string | null;
  priceUsd: number | null;
  change24h: number | null;
  liquidityUsd: number | null;
  volume24hUsd: number | null;
  marketCapUsd: number | null;
  fdvUsd: number | null;
  marketCount: number;
  dataFreshness: "fresh" | "stale" | "unknown";
  dataAgeMs: number | null;
  trust: DiscoveryTrust;
  security: DiscoverySecurity;
  securityScore: number | null;
  confidence: "high" | "medium" | "low" | "none";
  confidenceScore: number;
  sources: string[];
  explorerUrl: string | null;
  coinId: string | null;
  exactMatch: boolean;
}

export interface TokenDiscoveryResponse {
  query: string;
  status: DiscoveryStatus;
  results: CanonicalTokenResult[];
  message: string | null;
}

export function looksLikeEvmAddress(value: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(value.trim()) && isAddress(value.trim());
}

export function looksLikeSolanaAddress(value: string): boolean {
  const candidate = value.trim();
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(candidate)) return false;
  try {
    new PublicKey(candidate);
    return true;
  } catch {
    return false;
  }
}

export function detectAddressChains(value: string): string[] {
  const candidate = value.trim();
  if (looksLikeEvmAddress(candidate))
    return ["ethereum", "bsc", "polygon", "arbitrum"];
  if (looksLikeSolanaAddress(candidate)) return ["solana"];
  return [];
}

export function rankDiscoveryResults(
  results: CanonicalTokenResult[],
  query: string,
  preferredChain?: string
): CanonicalTokenResult[] {
  const normalized = query.trim().toLowerCase();
  const addressQuery =
    normalized.startsWith("0x") || looksLikeSolanaAddress(query);
  return [...results].sort((a, b) => {
    const score = (result: CanonicalTokenResult) => {
      const exactContract =
        addressQuery &&
        normalizeIdentifier(result.chainId, result.contractAddress) ===
          normalizeIdentifier(result.chainId, query.trim())
          ? 10000
          : 0;
      const exactName = result.name.toLowerCase() === normalized ? 1200 : 0;
      const exactSymbol = result.symbol.toLowerCase() === normalized ? 1100 : 0;
      const chain =
        preferredChain && result.chainId === preferredChain ? 180 : 0;
      const trust = result.trust === "verified" ? 140 : 0;
      const security =
        result.security === "safe"
          ? 80
          : result.security === "unknown"
            ? 0
            : -120;
      const liquidity =
        Math.log10(Math.max(0, result.liquidityUsd ?? 0) + 1) * 35;
      const volume = Math.log10(Math.max(0, result.volume24hUsd ?? 0) + 1) * 20;
      const confidence = result.confidenceScore * 0.8;
      const freshness =
        result.dataFreshness === "fresh"
          ? 20
          : result.dataFreshness === "stale"
            ? -15
            : 0;
      return (
        exactContract +
        exactName +
        exactSymbol +
        chain +
        trust +
        security +
        liquidity +
        volume +
        confidence +
        freshness
      );
    };
    return (
      score(b) - score(a) ||
      a.canonicalIdentity.localeCompare(b.canonicalIdentity)
    );
  });
}

function explorerFor(chainId: string, address: string): string | null {
  if (address === "native") return null;
  const base: Record<string, string> = {
    ethereum: "https://etherscan.io/token/",
    bsc: "https://bscscan.com/token/",
    polygon: "https://polygonscan.com/token/",
    arbitrum: "https://arbiscan.io/token/",
    solana: "https://solscan.io/token/",
  };
  return base[chainId] ? `${base[chainId]}${address}` : null;
}

function freshnessFor(market: AggregatedMarket | null): {
  freshness: "fresh" | "stale" | "unknown";
  ageMs: number | null;
} {
  if (!market || market.sourceUpdatedAt == null)
    return { freshness: "unknown", ageMs: null };
  const ageMs = Math.max(0, Date.now() - market.sourceUpdatedAt);
  return {
    freshness: market.isStale || ageMs > 120_000 ? "stale" : "fresh",
    ageMs,
  };
}

async function trustAndSecurity(
  chainId: string,
  contractAddress: string
): Promise<{
  trust: DiscoveryTrust;
  security: DiscoverySecurity;
  securityScore: number | null;
}> {
  const db = await getReadDb();
  if (!db)
    return { trust: "unverified", security: "unknown", securityScore: null };
  const identifier = normalizeIdentifier(chainId, contractAddress);
  try {
    const [asset] = await db
      .select({ verificationStatus: assets.verificationStatus })
      .from(assets)
      .where(
        and(eq(assets.chainId, chainId), eq(assets.identifier, identifier))
      )
      .limit(1);
    const [report] = await db
      .select({
        label: securityReports.label,
        score: securityReports.score,
        checkedAt: securityReports.checkedAt,
        updatedAt: securityReports.updatedAt,
      })
      .from(securityReports)
      .innerJoin(assets, eq(securityReports.assetId, assets.id))
      .where(
        and(eq(assets.chainId, chainId), eq(assets.identifier, identifier))
      )
      .orderBy(desc(securityReports.checkedAt), desc(securityReports.updatedAt))
      .limit(1);
    const currentReport = selectCurrentSecurityReport(report ? [report] : []);
    const mapped = mapSecurityReportLabel(currentReport);
    return {
      trust: mapAssetVerificationStatus(asset?.verificationStatus),
      security: mapped.security,
      securityScore: mapped.securityScore,
    };
  } catch {
    return { trust: "unverified", security: "unknown", securityScore: null };
  }
}

type DiscoveryMarketToken = Pick<
  MarketToken,
  "id" | "symbol" | "name" | "image"
> & {
  currentPrice: number | null;
  marketCap: number | null;
  marketCapRank: number | null;
  volume24h: number | null;
  priceChangePercent24h: number | null;
};

function fromMarketToken(
  token: MarketToken | DiscoveryMarketToken,
  detail: TokenDetail | null,
  chainId: string,
  contractAddress: string,
  market: AggregatedMarket | null,
  trust: DiscoveryTrust,
  security: DiscoverySecurity,
  securityScore: number | null,
  tokenStandard: TokenStandard,
  query: string
): CanonicalTokenResult {
  const freshness = freshnessFor(market);
  const exactMatch =
    normalizeIdentifier(chainId, contractAddress) ===
    normalizeIdentifier(chainId, query.trim());
  return {
    id: `${chainId}:${contractAddress}`,
    chainId,
    chainName: CHAIN_LABELS[chainId] ?? chainId,
    contractAddress,
    tokenStandard,
    canonicalIdentity: `${chainId}:${tokenStandard}:${normalizeIdentifier(chainId, contractAddress)}`,
    name: detail?.name ?? token.name,
    symbol: detail?.symbol ?? token.symbol,
    logoUrl: detail?.image || token.image || null,
    priceUsd: market?.priceUsd ?? token.currentPrice ?? null,
    change24h: market?.change24h ?? token.priceChangePercent24h ?? null,
    liquidityUsd: market?.liquidityUsd ?? null,
    volume24hUsd: market?.volume24hUsd ?? token.volume24h ?? null,
    marketCapUsd: market?.marketCapUsd ?? token.marketCap ?? null,
    fdvUsd: market?.fdvUsd ?? null,
    marketCount: market?.markets.length ?? 0,
    dataFreshness: freshness.freshness,
    dataAgeMs: freshness.ageMs,
    trust,
    security,
    securityScore,
    confidence: market?.confidence ?? "none",
    confidenceScore: market?.confidenceScore ?? 0,
    sources: market?.sources ?? ["coingecko"],
    explorerUrl: detail?.explorerUrl ?? explorerFor(chainId, contractAddress),
    coinId: detail?.id ?? token.id,
    exactMatch,
  };
}

async function resolveProviderSearchResult(
  candidate: ProviderSearchResult,
  query: string
): Promise<CanonicalTokenResult | null> {
  const detail = candidate.coinId
    ? await getTokenDetail(candidate.coinId)
    : null;
  const chainId =
    candidate.chainId ??
    (detail?.platformId ? PLATFORM_TO_CHAIN[detail.platformId] : undefined);
  const contractAddress =
    candidate.tokenAddress ??
    detail?.contractAddress ??
    (chainId ? "native" : null);
  if (!chainId || !contractAddress) return null;
  const market =
    contractAddress === "native"
      ? null
      : await fetchAggregatedMarket(chainId, contractAddress);
  const token: DiscoveryMarketToken = {
    id: candidate.coinId ?? `${chainId}:${contractAddress}`,
    symbol: candidate.symbol ?? detail?.symbol ?? "UNKNOWN",
    name: candidate.name ?? detail?.name ?? "Unknown token",
    image: candidate.imageUrl ?? detail?.image ?? "",
    currentPrice: null,
    marketCap: null,
    marketCapRank: null,
    volume24h: null,
    priceChangePercent24h: null,
  };
  const trustSecurity = await trustAndSecurity(chainId, contractAddress);
  const tokenStandard =
    candidate.tokenStandard ?? tokenStandardForChain(chainId, contractAddress);
  const result = fromMarketToken(
    token,
    detail,
    chainId,
    contractAddress,
    market,
    trustSecurity.trust,
    trustSecurity.security,
    trustSecurity.securityScore,
    tokenStandard,
    query
  );
  return {
    ...result,
    sources: Array.from(new Set([candidate.source, ...result.sources])),
  };
}

export function mergeDiscoveryResults(
  results: CanonicalTokenResult[]
): CanonicalTokenResult[] {
  const merged = new Map<string, CanonicalTokenResult>();
  for (const result of results) {
    const existing = merged.get(result.canonicalIdentity);
    if (!existing) {
      merged.set(result.canonicalIdentity, result);
      continue;
    }
    merged.set(result.canonicalIdentity, {
      ...existing,
      sources: Array.from(new Set([...existing.sources, ...result.sources])),
      exactMatch: existing.exactMatch || result.exactMatch,
      marketCount: Math.max(existing.marketCount, result.marketCount),
      dataFreshness:
        existing.dataFreshness === "fresh" || result.dataFreshness === "fresh"
          ? "fresh"
          : existing.dataFreshness === "stale" ||
              result.dataFreshness === "stale"
            ? "stale"
            : "unknown",
      trust:
        existing.trust === "verified" || result.trust === "verified"
          ? "verified"
          : existing.trust === "unverified" || result.trust === "unverified"
            ? "unverified"
            : "unknown",
      security:
        existing.security !== "unknown" ? existing.security : result.security,
      securityScore: existing.securityScore ?? result.securityScore,
    });
  }
  return Array.from(merged.values());
}

async function discoverByNameOrSymbol(
  query: string,
  preferredChain?: string
): Promise<TokenDiscoveryResponse> {
  const searchableProviders = marketProviders.filter(
    provider => provider.searchTokens
  );
  const providerResults = await Promise.allSettled(
    searchableProviders.map(provider => provider.searchTokens!(query))
  );
  const fulfilled = providerResults.filter(
    entry => entry.status === "fulfilled"
  ) as PromiseFulfilledResult<ProviderSearchResult[]>[];
  if (!fulfilled.length && searchableProviders.length) {
    return {
      query,
      status: "provider_unavailable",
      results: [],
      message: "Token discovery is temporarily unavailable. Please try again.",
    };
  }
  const candidates = fulfilled
    .flatMap(entry => entry.value)
    .filter(
      candidate =>
        !preferredChain ||
        !candidate.chainId ||
        candidate.chainId === preferredChain
    )
    .slice(0, 24);
  const resolved = await Promise.allSettled(
    candidates.map(candidate => resolveProviderSearchResult(candidate, query))
  );
  const results = mergeDiscoveryResults(
    resolved.flatMap(entry =>
      entry.status === "fulfilled" && entry.value ? [entry.value] : []
    )
  );
  const ranked = rankDiscoveryResults(results, query, preferredChain);
  return {
    query,
    status: ranked.length ? "found" : "not_found",
    results: ranked,
    message: ranked.length ? null : "Token not found.",
  };
}

async function discoverByAddress(
  query: string,
  chains: string[]
): Promise<TokenDiscoveryResponse> {
  const results: CanonicalTokenResult[] = [];
  await Promise.all(
    chains.map(async chainId => {
      const market = await fetchAggregatedMarket(chainId, query.trim());
      if (!market || market.markets.length === 0) return;
      const selected =
        market.markets.find(
          item =>
            item.baseToken.address === query.trim() ||
            item.quoteToken.address === query.trim()
        ) ?? market.markets[0];
      const token: MarketToken = {
        id: `${chainId}:${query.trim()}`,
        symbol:
          (selected.baseToken.address === query.trim()
            ? selected.baseToken.symbol
            : selected.quoteToken.symbol) ?? "UNKNOWN",
        name:
          (selected.baseToken.address === query.trim()
            ? selected.baseToken.name
            : selected.quoteToken.name) ?? "Unknown token",
        image: "",
        currentPrice: market.priceUsd ?? 0,
        marketCap: market.marketCapUsd ?? 0,
        marketCapRank: null,
        volume24h: market.volume24hUsd ?? 0,
        priceChangePercent24h: market.change24h,
      };
      const trustSecurity = await trustAndSecurity(chainId, query.trim());
      results.push(
        fromMarketToken(
          token,
          null,
          chainId,
          query.trim(),
          market,
          trustSecurity.trust,
          trustSecurity.security,
          trustSecurity.securityScore,
          tokenStandardForChain(chainId, query.trim()),
          query
        )
      );
    })
  );
  const ranked = rankDiscoveryResults(results, query);
  return {
    query,
    status: ranked.length ? "found" : "not_found",
    results: ranked,
    message: ranked.length
      ? null
      : "Contract found but token metadata/market data unavailable.",
  };
}

export async function discoverTokens(
  query: string,
  preferredChain?: string
): Promise<TokenDiscoveryResponse> {
  const normalizedQuery = query.trim();
  if (!normalizedQuery)
    return {
      query,
      status: "not_found",
      results: [],
      message: "Enter a token name, symbol, or contract address.",
    };
  const addressChains = detectAddressChains(normalizedQuery);
  if (/^0x/i.test(normalizedQuery) && !looksLikeEvmAddress(normalizedQuery))
    return {
      query,
      status: "not_found",
      results: [],
      message: "Invalid EVM contract address.",
    };
  if (addressChains.length)
    return discoverByAddress(
      normalizedQuery,
      preferredChain
        ? addressChains.filter(chain => chain === preferredChain)
        : addressChains
    );
  if (
    /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(normalizedQuery) &&
    !looksLikeSolanaAddress(normalizedQuery)
  )
    return {
      query,
      status: "not_found",
      results: [],
      message: "Invalid Solana contract address.",
    };
  return discoverByNameOrSymbol(normalizedQuery, preferredChain);
}

export async function getTokenByCanonicalIdentity(
  chainId: string,
  contractAddress: string
): Promise<CanonicalTokenResult | null> {
  const market =
    contractAddress === "native"
      ? null
      : await fetchAggregatedMarket(chainId, contractAddress);
  const trustSecurity = await trustAndSecurity(chainId, contractAddress);
  const best = market?.markets[0];
  if (!best && contractAddress !== "native") return null;
  const token: MarketToken = {
    id: `${chainId}:${contractAddress}`,
    symbol:
      (best?.baseToken.address === contractAddress
        ? best.baseToken.symbol
        : best?.quoteToken.symbol) ?? "UNKNOWN",
    name:
      (best?.baseToken.address === contractAddress
        ? best.baseToken.name
        : best?.quoteToken.name) ?? "Unknown token",
    image: "",
    currentPrice: market?.priceUsd ?? 0,
    marketCap: market?.marketCapUsd ?? 0,
    marketCapRank: null,
    volume24h: market?.volume24hUsd ?? 0,
    priceChangePercent24h: market?.change24h ?? null,
  };
  return fromMarketToken(
    token,
    null,
    chainId,
    contractAddress,
    market,
    trustSecurity.trust,
    trustSecurity.security,
    trustSecurity.securityScore,
    tokenStandardForChain(chainId, contractAddress),
    contractAddress
  );
}
