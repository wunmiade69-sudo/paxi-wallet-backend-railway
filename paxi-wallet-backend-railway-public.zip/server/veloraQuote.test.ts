import { describe, expect, it } from "vitest";
import { calculateVeloraFeeAmount } from "./veloraQuote";

describe("Velora exact fee math", () => {
  it("calculates fee from source base units without floating point", () => {
    expect(calculateVeloraFeeAmount("900719925474099300000000000000000000", 18, 30)).toBe("2702159776422297.9");
  });

  it("uses deterministic integer floor semantics for base-unit fees", () => {
    expect(calculateVeloraFeeAmount("1000001", 6, 30)).toBe("0.003");
  });

  it("rejects malformed source amounts and invalid fee basis points", () => {
    expect(() => calculateVeloraFeeAmount("1.2", 18, 30)).toThrow("Invalid source amount");
    expect(() => calculateVeloraFeeAmount("1000", 18, 10_001)).toThrow("Invalid fee basis points");
  });
});
