import { formatUnits, getAddress } from "ethers";
import { fetchJson } from "./providers/http";
import { getTreasuryConfiguration, type TreasuryNetwork } from "./fees/treasury";
import { getFeeConfig } from "./fees/feeEngine";

const VELORA_API = "https://api.velora.xyz";
const PARTNER_NAME = "paxiwallet";

export const VELORA_NATIVE_TOKEN_ADDRESS = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";

export interface VeloraQuoteInput {
  networkId: string;
  chainId: number;
  srcToken: string;
  destToken: string;
  srcDecimals: number;
  destDecimals: number;
  amount: string;
  userAddress: string;
  slippageBps: number;
}

export interface VeloraQuoteResult {
  priceRoute: Record<string, unknown>;
  srcAmountUnits: string;
  destAmountUnits: string;
  destAmountFormatted: string;
  destAmountMinFormatted: string;
  rate: number;
  feeBps: number;
  feeAmountFormatted: string;
  feeAddress: string | null;
  tokenTransferProxy: string;
  gasCostEstimate: string | null;
  routeNames: string[];
}

function assertEvmAddress(value: string, field: string): string {
  try {
    return getAddress(value);
  } catch {
    throw new Error(`Invalid ${field}.`);
  }
}

function extractRouteNames(node: unknown, acc = new Set<string>()): string[] {
  if (!node || typeof node !== "object") return [...acc];
  for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
    if (key === "exchange" && typeof value === "string") acc.add(value);
    else if (Array.isArray(value)) value.forEach((entry) => extractRouteNames(entry, acc));
    else if (value && typeof value === "object") extractRouteNames(value, acc);
  }
  return [...acc];
}

function treasuryNetworkFor(networkId: string): TreasuryNetwork {
  if (networkId === "bsc" || networkId === "polygon" || networkId === "arbitrum") return networkId;
  return "ethereum";
}

export function calculateVeloraFeeAmount(srcAmountUnits: string, srcDecimals: number, feeBps: number): string {
  if (!/^[0-9]+$/.test(srcAmountUnits) || srcAmountUnits === "0") throw new Error("Invalid source amount.");
  if (!Number.isInteger(srcDecimals) || srcDecimals < 0 || srcDecimals > 36) throw new Error("Invalid source decimals.");
  if (!Number.isSafeInteger(feeBps) || feeBps < 0 || feeBps > 10_000) throw new Error("Invalid fee basis points.");
  const feeAmountUnits = (BigInt(srcAmountUnits) * BigInt(feeBps)) / 10_000n;
  return formatUnits(feeAmountUnits, srcDecimals);
}

async function serverFeeContext(networkId: string) {
  const config = await getFeeConfig("swap_evm", "evm");
  const treasury = getTreasuryConfiguration(treasuryNetworkFor(networkId));
  const feeAddress = config.percentageBps > 0 && treasury.settlementEnabled && treasury.address
    ? treasury.address
    : null;
  return { feeBps: config.isActive ? config.percentageBps : 0, feeAddress };
}

export function buildVeloraPriceUrl(input: VeloraQuoteInput): string {
  const srcToken = assertEvmAddress(input.srcToken, "source token");
  const destToken = assertEvmAddress(input.destToken, "destination token");
  const userAddress = assertEvmAddress(input.userAddress, "wallet address");
  if (!Number.isSafeInteger(input.chainId) || input.chainId <= 0) throw new Error("Invalid network chain ID.");
  if (!Number.isInteger(input.srcDecimals) || input.srcDecimals < 0 || input.srcDecimals > 36) throw new Error("Invalid source decimals.");
  if (!Number.isInteger(input.destDecimals) || input.destDecimals < 0 || input.destDecimals > 36) throw new Error("Invalid destination decimals.");
  if (!Number.isSafeInteger(input.slippageBps) || input.slippageBps < 0 || input.slippageBps > 5_000) throw new Error("Invalid slippage.");
  if (!/^[0-9]+$/.test(input.amount) || input.amount === "0") throw new Error("Invalid source amount.");
  const url = new URL(`${VELORA_API}/prices`);
  url.search = new URLSearchParams({
    srcToken,
    destToken,
    srcDecimals: String(input.srcDecimals),
    destDecimals: String(input.destDecimals),
    amount: input.amount,
    side: "SELL",
    network: String(input.chainId),
    userAddress,
    partner: PARTNER_NAME,
    // Velora retired API v5's routing engine at the launch of v6.2 - without
    // this, /prices silently falls back to the unmaintained v5 Hopper
    // algorithm, which indexes fewer DEXs and returns "no route found" far
    // more often. https://developers.velora.xyz/api/velora-api/velora-market-api/master/api-v6.2
    version: "6.2",
  }).toString();
  return url.toString();
}

export async function fetchVeloraSwapQuote(input: VeloraQuoteInput): Promise<VeloraQuoteResult> {
  const { feeBps, feeAddress } = await serverFeeContext(input.networkId);
  const data = await fetchJson<{ priceRoute?: Record<string, unknown> }>(buildVeloraPriceUrl(input), "velora");
  const priceRoute = data?.priceRoute;
  if (!priceRoute || typeof priceRoute !== "object") throw new Error("No route found for this pair.");
  const destAmountUnits = typeof priceRoute.destAmount === "string" ? priceRoute.destAmount : "";
  if (!/^[0-9]+$/.test(destAmountUnits) || destAmountUnits === "0") throw new Error("Velora returned an invalid route.");
  const destAmountFormatted = formatUnits(destAmountUnits, input.destDecimals);
  const destAmountMin = (BigInt(destAmountUnits) * BigInt(10_000 - input.slippageBps)) / 10_000n;
  const destAmountMinFormatted = formatUnits(destAmountMin, input.destDecimals);
  const amountHuman = formatUnits(input.amount, input.srcDecimals);
  // `rate` is retained as a UI-only compatibility field. It is never used for
  // transaction construction or accounting; all executable amounts remain the
  // exact integer strings above.
  const rate = Number(destAmountFormatted) / Number(amountHuman);
  const feeAmountFormatted = calculateVeloraFeeAmount(input.amount, input.srcDecimals, feeBps);
  const tokenTransferProxy = typeof priceRoute.tokenTransferProxy === "string" ? assertEvmAddress(priceRoute.tokenTransferProxy, "token transfer proxy") : "";
  return {
    priceRoute,
    srcAmountUnits: input.amount,
    destAmountUnits,
    destAmountFormatted,
    destAmountMinFormatted,
    rate,
    feeBps,
    feeAmountFormatted,
    feeAddress,
    tokenTransferProxy,
    gasCostEstimate: typeof priceRoute.gasCostUSD === "string" ? priceRoute.gasCostUSD : null,
    routeNames: extractRouteNames(priceRoute),
  };
}

export interface VeloraTransactionInput {
  networkId: string;
  chainId: number;
  srcToken: string;
  destToken: string;
  srcDecimals: number;
  destDecimals: number;
  srcAmount: string;
  destAmount: string;
  priceRoute: Record<string, unknown>;
  userAddress: string;
}

export interface VeloraTransactionResult {
  to: string;
  data: string;
  value?: string;
  chainId?: number;
}

export async function buildVeloraTransaction(input: VeloraTransactionInput): Promise<VeloraTransactionResult> {
  const { feeBps, feeAddress } = await serverFeeContext(input.networkId);
  assertEvmAddress(input.userAddress, "wallet address");
  if (!Number.isSafeInteger(input.chainId) || input.chainId <= 0) throw new Error("Invalid network chain ID.");
  if (!/^[0-9]+$/.test(input.srcAmount) || input.srcAmount === "0") throw new Error("Invalid source amount.");
  if (!/^[0-9]+$/.test(input.destAmount) || input.destAmount === "0") throw new Error("Invalid minimum destination amount.");
  const body: Record<string, unknown> = {
    srcToken: assertEvmAddress(input.srcToken, "source token"),
    destToken: assertEvmAddress(input.destToken, "destination token"),
    srcAmount: input.srcAmount,
    destAmount: input.destAmount,
    priceRoute: input.priceRoute,
    userAddress: assertEvmAddress(input.userAddress, "wallet address"),
    partner: PARTNER_NAME,
    takeSurplus: true,
    srcDecimals: input.srcDecimals,
    destDecimals: input.destDecimals,
  };
  if (feeBps > 0) {
    if (!feeAddress) throw new Error("Swap fee destination is not configured.");
    body.partnerAddress = feeAddress;
    body.partnerFeeBps = feeBps;
    body.isDirectFeeTransfer = true;
  }
  const transaction = await fetchJson<Record<string, unknown>>(`${VELORA_API}/transactions/${input.chainId}?ignoreChecks=true`, "velora", {
    "Content-Type": "application/json",
  }, {
    method: "POST",
    body: JSON.stringify(body),
  });
  if (typeof transaction.to !== "string" || typeof transaction.data !== "string") throw new Error("Velora returned an invalid unsigned transaction.");
  return {
    to: transaction.to,
    data: transaction.data,
    value: typeof transaction.value === "string" ? transaction.value : undefined,
    chainId: typeof transaction.chainId === "number" ? transaction.chainId : undefined,
  };
}

