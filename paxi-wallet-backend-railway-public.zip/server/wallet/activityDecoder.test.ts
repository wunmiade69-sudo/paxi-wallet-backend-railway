import { describe, expect, it } from "vitest";
import { ethers } from "ethers";
import { decodeEvmActivity } from "./activityDecoder";

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const WALLET = "0x00000000000000000000000000000000000000aa";
const OTHER = "0x00000000000000000000000000000000000000bb";
const STABLE = "0x55d398326f99059ff775485246999027b3197955";
const TOKEN = "0x00000000000000000000000000000000000000cc";
const TOKEN_TWO = "0x00000000000000000000000000000000000000ce";
const BRIDGE = "0x00000000000000000000000000000000000000be";

function topicAddress(address: string): string {
  return `0x${address.slice(2).padStart(64, "0")}`;
}

function transferLog(token: string, from: string, to: string, amount: bigint) {
  return {
    address: token,
    topics: [TRANSFER_TOPIC, topicAddress(from), topicAddress(to)],
    data: ethers.zeroPadValue(ethers.toBeHex(amount), 32),
  } as unknown as ethers.Log;
}

function transaction(overrides: Record<string, unknown> = {}) {
  return {
    from: WALLET,
    to: "0x00000000000000000000000000000000000000dd",
    value: 0n,
    ...overrides,
  } as unknown as ethers.TransactionResponse;
}

function receipt(logs: ethers.Log[], status: 0 | 1 = 1) {
  return { status, logs, blockNumber: 123 } as unknown as ethers.TransactionReceipt;
}

describe("server activity semantic decoder", () => {
  it("classifies a stablecoin-for-token transaction as buy and derives USD from stablecoin outflow", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(STABLE, WALLET, OTHER, 20n * 10n ** 18n),
        transferLog(TOKEN, OTHER, WALLET, 5n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
      requestedAssetAddress: STABLE,
    });

    expect(result.eventType).toBe("buy");
    expect(result.amountUsd).toBe("20");
    expect(result.amountUsdSource).toBe("onchain_stablecoin");
  });

  it("classifies a token-for-stablecoin transaction as sell", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(TOKEN, WALLET, OTHER, 5n * 10n ** 18n),
        transferLog(STABLE, OTHER, WALLET, 20n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
      requestedAssetAddress: STABLE,
    });

    expect(result.eventType).toBe("sell");
    expect(result.amountUsd).toBe("20");
  });

  it("classifies a native outgoing transaction as send and never invents USD", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction({ value: 2n * 10n ** 18n }),
      receipt: receipt([]),
      provider: {} as ethers.Provider,
      read: async () => { throw new Error("unexpected provider lookup"); },
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("send");
    expect(result.amount).toBe("2");
    expect(result.amountUsd).toBeNull();
  });

  it("classifies a native incoming transaction as receive", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction({ from: OTHER, to: WALLET, value: 2n * 10n ** 18n }),
      receipt: receipt([]),
      provider: {} as ethers.Provider,
      read: async () => { throw new Error("unexpected provider lookup"); },
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("receive");
    expect(result.amount).toBe("2");
  });

  it("keeps the final asset as the primary flow in a multi-hop aggregator swap", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(STABLE, WALLET, OTHER, 20n * 10n ** 18n),
        transferLog(TOKEN, OTHER, WALLET, 5n * 10n ** 18n),
        transferLog(TOKEN, OTHER, BRIDGE, 3n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("buy");
    expect(result.assetAddress).toBe(TOKEN.toLowerCase());
    expect(result.amount).toBe("5");
  });

  it("ignores unrelated contract transfers when decoding wallet activity", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(STABLE, WALLET, OTHER, 20n * 10n ** 18n),
        transferLog(TOKEN, OTHER, WALLET, 5n * 10n ** 18n),
        transferLog(TOKEN_TWO, OTHER, BRIDGE, 999n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("buy");
    expect(result.assetAddress).toBe(TOKEN.toLowerCase());
  });

  it("preserves token semantics when a native value is also sent to a router", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction({ value: 1n * 10n ** 18n }),
      receipt: receipt([transferLog(TOKEN, WALLET, OTHER, 5n * 10n ** 18n)]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("send");
    expect(result.assetAddress).toBe(TOKEN.toLowerCase());
    expect(result.amount).toBe("5");
  });

  it("rejects failed receipts before creating activity semantics", async () => {
    await expect(decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([transferLog(TOKEN, WALLET, OTHER, 5n * 10n ** 18n)], 0),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
    })).rejects.toThrow("receipt indicates failure");
  });

  it("classifies transfers to a trusted bridge as bridge activity", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction({ to: BRIDGE, value: 1n * 10n ** 18n }),
      receipt: receipt([transferLog(TOKEN, WALLET, OTHER, 5n * 10n ** 18n)]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set([BRIDGE.toLowerCase()]),
    });

    expect(result.eventType).toBe("bridge");
  });

  it("uses the first verified stablecoin flow for multi-stablecoin USD value", async () => {
    const stableTwo = "0x8ac76a51cc9509822d68b83fe1ad97b32cd580d";
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(STABLE, WALLET, OTHER, 20n * 10n ** 18n),
        transferLog(stableTwo, WALLET, OTHER, 3n * 10n ** 18n),
        transferLog(TOKEN, OTHER, WALLET, 5n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("buy");
    expect(result.amountUsd).toBe("20");
  });

  it("does not invent a primary asset when multiple non-stable tokens are received", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(STABLE, WALLET, OTHER, 20n * 10n ** 18n),
        transferLog(TOKEN, OTHER, WALLET, 5n * 10n ** 18n),
        transferLog(TOKEN_TWO, OTHER, WALLET, 2n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
    });

    expect(result.eventType).toBe("buy");
    expect(result.assetAddress).toBeNull();
    expect(result.amount).toBeNull();
    expect(result.amountUsd).toBe("20");
  });

  it("rejects self-transfers as non-activity", async () => {
    await expect(decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([transferLog(TOKEN, WALLET, WALLET, 5n * 10n ** 18n)]),
      provider: {} as ethers.Provider,
      read: async () => { throw new Error("unexpected provider lookup"); },
      trustedBridgeAddresses: new Set(),
    })).rejects.toThrow("no server-decodable wallet activity");
  });

  it("rejects zero-value transfers and zero-value transactions", async () => {
    await expect(decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([transferLog(TOKEN, WALLET, OTHER, 0n)]),
      provider: {} as ethers.Provider,
      read: async () => { throw new Error("unexpected provider lookup"); },
      trustedBridgeAddresses: new Set(),
    })).rejects.toThrow("no server-decodable wallet activity");
  });

  it("requires an explicit asset when a complex aggregator returns multiple non-stable outputs", async () => {
    const result = await decodeEvmActivity({
      network: "bsc",
      walletAddress: WALLET,
      transaction: transaction(),
      receipt: receipt([
        transferLog(STABLE, WALLET, OTHER, 20n * 10n ** 18n),
        transferLog(TOKEN, OTHER, WALLET, 5n * 10n ** 18n),
        transferLog(TOKEN_TWO, OTHER, WALLET, 2n * 10n ** 18n),
        transferLog(TOKEN_TWO, OTHER, BRIDGE, 7n * 10n ** 18n),
      ]),
      provider: {} as ethers.Provider,
      read: async () => 18,
      trustedBridgeAddresses: new Set(),
      requestedAssetAddress: TOKEN,
    });

    expect(result.assetAddress).toBe(TOKEN.toLowerCase());
    expect(result.amount).toBe("5");
  });
});
