import { ethers } from "ethers";
import type { ActivityEventType } from "../activity/activityService";

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const ERC20_INTERFACE = new ethers.Interface(["function decimals() view returns (uint8)"]);
const MAX_TOKEN_DECIMALS = 36;

const STABLECOIN_DECIMALS: Record<string, Record<string, number>> = {
  bsc: {
    "0x55d398326f99059ff775485246999027b3197955": 18,
    "0x8ac76a51cc9509822d68b83fe1ad97b32cd580d": 18,
  },
  ethereum: {
    "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": 6,
    "0xdac17f958d2ee523a2206206994597c13d831ec7": 6,
  },
  polygon: {
    "0x2791bca1f2de4661ed88a30c99a7a9449aa84174": 6,
    "0x3c499c542cef5e3811e1192ce70d8cc03d5c3359": 6,
    "0xc2132d05d31c914a87c6611c10748aeb04b58e8f": 6,
  },
  arbitrum: {
    "0xaf88d065e77c8cc2239327c5edb3a432268e5831": 6,
    "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9": 6,
  },
};

const ADDRESS_TOPIC_RE = /^0x[0-9a-fA-F]{64}$/;

interface TokenFlow {
  tokenAddress: string;
  incoming: bigint;
  outgoing: bigint;
}

export interface DecodedEvmActivity {
  eventType: Exclude<ActivityEventType, "wallet_creation" | "token_creation" | "deposit" | "withdrawal">;
  assetAddress: string | null;
  amount: string | null;
  amountUsd: string | null;
  amountSource: "onchain_transfer" | "onchain_native" | "none";
  amountUsdSource: "onchain_stablecoin" | "none";
}

function topicAddress(topic: string | undefined): string | null {
  if (!topic || !ADDRESS_TOPIC_RE.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`).toLowerCase();
  } catch {
    return null;
  }
}

function addFlow(flows: Map<string, TokenFlow>, tokenAddress: string, incoming: bigint, outgoing: bigint): void {
  const current = flows.get(tokenAddress);
  if (current) {
    current.incoming += incoming;
    current.outgoing += outgoing;
    return;
  }
  flows.set(tokenAddress, { tokenAddress, incoming, outgoing });
}

function parseTransferAmount(data: string): bigint | null {
  try {
    if (!ethers.isHexString(data) || data.length !== 66) return null;
    return BigInt(data);
  } catch {
    return null;
  }
}

function formatUnits(value: bigint, decimals: number): string {
  const safeDecimals = Math.max(0, Math.min(MAX_TOKEN_DECIMALS, Math.trunc(decimals)));
  const scale = 10n ** BigInt(safeDecimals);
  const whole = value / scale;
  const fraction = (value % scale).toString().padStart(safeDecimals, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function sumFlows(flows: TokenFlow[], direction: "incoming" | "outgoing"): bigint {
  return flows.reduce((sum, flow) => sum + flow[direction], 0n);
}

function stableDecimals(network: string, tokenAddress: string): number | null {
  return STABLECOIN_DECIMALS[network.toLowerCase()]?.[tokenAddress.toLowerCase()] ?? null;
}

function selectPrimaryFlow(
  network: string,
  flows: TokenFlow[],
  eventType: DecodedEvmActivity["eventType"],
  requestedAssetAddress?: string | null,
): TokenFlow | null {
  const requested = requestedAssetAddress?.toLowerCase();
  if (requested) {
    const match = flows.find((flow) => flow.tokenAddress === requested);
    if (!match) throw new Error("The requested asset was not present in the verified transaction");
    return match;
  }

  const nonStable = flows.filter((flow) => stableDecimals(network, flow.tokenAddress) === null);
  const candidates = eventType === "buy" || eventType === "sell" || eventType === "swap" ? nonStable : flows;
  return candidates.length === 1 ? candidates[0] ?? null : null;
}

export async function decodeEvmActivity(params: {
  network: string;
  walletAddress: string;
  transaction: ethers.TransactionResponse;
  receipt: ethers.TransactionReceipt;
  provider: ethers.Provider;
  read: <T>(operation: () => Promise<T>) => Promise<T>;
  trustedBridgeAddresses: Set<string>;
  requestedAssetAddress?: string | null;
}): Promise<DecodedEvmActivity> {
  if (params.receipt.status === 0) {
    throw new Error("The transaction receipt indicates failure");
  }

  const wallet = params.walletAddress.toLowerCase();
  const network = params.network.toLowerCase();
  const flows = new Map<string, TokenFlow>();

  for (const log of params.receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC || log.topics.length < 3) continue;
    const from = topicAddress(log.topics[1]);
    const to = topicAddress(log.topics[2]);
    const amount = parseTransferAmount(log.data);
    if (!from || !to || amount == null || amount <= 0n) continue;
    if (from === wallet && to !== wallet) addFlow(flows, log.address.toLowerCase(), 0n, amount);
    if (to === wallet && from !== wallet) addFlow(flows, log.address.toLowerCase(), amount, 0n);
  }

  const tokenFlows = [...flows.values()].filter((flow) => flow.incoming > 0n || flow.outgoing > 0n);
  const incoming = tokenFlows.filter((flow) => flow.incoming > 0n);
  const outgoing = tokenFlows.filter((flow) => flow.outgoing > 0n);
  const target = params.transaction.to?.toLowerCase() ?? null;
  const nativeValue = params.transaction.value ?? 0n;

  let eventType: DecodedEvmActivity["eventType"];
  if (target && params.trustedBridgeAddresses.has(target) && (outgoing.length > 0 || nativeValue > 0n)) {
    eventType = "bridge";
  } else if (incoming.length > 0 && outgoing.length > 0) {
    const incomingStable = incoming.filter((flow) => stableDecimals(network, flow.tokenAddress) !== null);
    const outgoingStable = outgoing.filter((flow) => stableDecimals(network, flow.tokenAddress) !== null);
    const incomingNonStable = incoming.filter((flow) => stableDecimals(network, flow.tokenAddress) === null);
    const outgoingNonStable = outgoing.filter((flow) => stableDecimals(network, flow.tokenAddress) === null);
    if (outgoingStable.length > 0 && incomingNonStable.length > 0 && outgoingNonStable.length === 0) eventType = "buy";
    else if (incomingStable.length > 0 && outgoingNonStable.length > 0 && incomingNonStable.length === 0) eventType = "sell";
    else eventType = "swap";
  } else if (outgoing.length > 0 || (params.transaction.from?.toLowerCase() === wallet && nativeValue > 0n)) {
    eventType = "send";
  } else if (incoming.length > 0 || target === wallet) {
    eventType = "receive";
  } else {
    throw new Error("The confirmed transaction has no server-decodable wallet activity");
  }

  const primary = selectPrimaryFlow(network, tokenFlows, eventType, params.requestedAssetAddress);
  let amount: string | null = null;
  let amountSource: DecodedEvmActivity["amountSource"] = "none";
  if (primary) {
    const raw = primary.incoming > 0n ? primary.incoming : primary.outgoing;
    const knownDecimals = stableDecimals(network, primary.tokenAddress);
    let decimals = knownDecimals;
    if (decimals === null) {
      try {
        const token = new ethers.Contract(primary.tokenAddress, ERC20_INTERFACE, params.provider);
        decimals = Number(await params.read(() => token.decimals()));
      } catch {
        decimals = null;
      }
    }
    if (decimals !== null && Number.isInteger(decimals) && decimals >= 0 && decimals <= MAX_TOKEN_DECIMALS) {
      amount = formatUnits(raw, decimals);
      amountSource = "onchain_transfer";
    }
  }

  if (!primary && tokenFlows.length === 0 && nativeValue > 0n) {
    amount = formatUnits(nativeValue, 18);
    amountSource = "onchain_native";
  }

  const stableFlows = tokenFlows.filter((flow) => stableDecimals(network, flow.tokenAddress) !== null);
  let amountUsd: string | null = null;
  let amountUsdSource: DecodedEvmActivity["amountUsdSource"] = "none";
  if (stableFlows.length > 0) {
    const stableFlow = stableFlows[0];
    const decimals = stableDecimals(network, stableFlow.tokenAddress)!;
    const rawStable = eventType === "buy" ? stableFlow.outgoing : eventType === "sell" ? stableFlow.incoming : stableFlow.incoming > 0n ? stableFlow.incoming : stableFlow.outgoing;
    if (rawStable > 0n) {
      amountUsd = formatUnits(rawStable, decimals);
      amountUsdSource = "onchain_stablecoin";
    }
  }

  return {
    eventType,
    assetAddress: primary?.tokenAddress ?? null,
    amount,
    amountUsd,
    amountSource,
    amountUsdSource,
  };
}
