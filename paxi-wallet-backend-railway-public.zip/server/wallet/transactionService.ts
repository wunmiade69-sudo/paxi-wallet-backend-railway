import { and, eq } from "drizzle-orm";
import { activityEvents, type ActivityEvent } from "../../drizzle/schema";
import { getDb } from "../db";
import { recordActivity } from "../activity/activityService";
import { verifyConfirmedEvmTransaction } from "./transactionVerifier";
import { processConfirmedReferralTrade } from "../rewards/referralTradeService";

export interface RecordTransactionParams {
  walletAddress: string;
  chainId: string;
  transactionHash: string;
}

function assertUserOpenId(value: string): void {
  if (!value || value.length > 64) throw new Error("Invalid user identifier");
}

function referralEvent(event: ActivityEvent): boolean {
  return event.chainId === "bsc" && (event.eventType === "buy" || event.eventType === "sell") && Boolean(event.transactionHash);
}

async function processReferralIfApplicable(userOpenId: string, event: ActivityEvent): Promise<void> {
  if (!referralEvent(event)) return;
  await processConfirmedReferralTrade({
    userOpenId,
    walletAddress: event.walletAddress,
    transactionHash: event.transactionHash!,
    eventType: event.eventType as "buy" | "sell",
  });
}

/**
 * Confirms a transaction only through the server semantic decoder. The client
 * may identify the wallet and hash, but cannot choose the event type, token
 * amount, USD value, or timestamp used for eligibility.
 */
export async function recordVerifiedTransaction(
  userOpenId: string,
  params: RecordTransactionParams,
): Promise<ActivityEvent> {
  assertUserOpenId(userOpenId);
  const verified = await verifyConfirmedEvmTransaction(params.chainId, params.walletAddress, params.transactionHash);
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const sameTransaction = await db
    .select()
    .from(activityEvents)
    .where(and(
      eq(activityEvents.userOpenId, userOpenId),
      eq(activityEvents.walletAddress, verified.walletAddress),
      eq(activityEvents.chainId, verified.chainId),
      eq(activityEvents.transactionHash, verified.transactionHash),
    ))
    .limit(2);
  const conflicting = sameTransaction.find((row) => row.eventType !== verified.eventType);
  if (conflicting) throw new Error("This transaction is already recorded with a different server-derived activity type");

  const existing = sameTransaction.find((row) => row.eventType === verified.eventType);
  if (existing?.status === "confirmed") {
    await processReferralIfApplicable(userOpenId, existing);
    return existing;
  }
  if (existing?.status === "failed") return existing;
  if (existing?.status === "pending") {
    const updatedResult = await db
      .update(activityEvents)
      .set({
        eventType: verified.eventType,
        amount: verified.amount,
        amountUsd: verified.amountUsd,
        feeUsd: null,
        networkFeeUsd: null,
        paxiFeeUsd: null,
        verificationSource: "server_semantic",
        amountUsdSource: verified.amountUsdSource,
        createdAt: verified.blockTimestampMs == null ? existing.createdAt : new Date(verified.blockTimestampMs),
        status: "confirmed",
      })
      .where(and(eq(activityEvents.id, existing.id), eq(activityEvents.userOpenId, userOpenId), eq(activityEvents.status, "pending")));
    if (Number((updatedResult as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
      throw new Error("Pending activity confirmation race; retry the server verification");
    }
    const [updated] = await db.select().from(activityEvents).where(eq(activityEvents.id, existing.id)).limit(1);
    if (!updated) throw new Error("Verified activity event disappeared during confirmation");
    await processReferralIfApplicable(userOpenId, updated);
    return updated;
  }

  const inserted = await recordActivity({
    userOpenId,
    walletAddress: verified.walletAddress,
    chainId: verified.chainId,
    eventType: verified.eventType,
    transactionHash: verified.transactionHash,
    assetId: null,
    amount: verified.amount,
    amountUsd: verified.amountUsd,
    feeUsd: null,
    networkFeeUsd: null,
    paxiFeeUsd: null,
    verificationSource: "server_semantic",
    amountUsdSource: verified.amountUsdSource,
    status: "confirmed",
    createdAt: verified.blockTimestampMs == null ? new Date() : new Date(verified.blockTimestampMs),
  });
  await processReferralIfApplicable(userOpenId, inserted);
  return inserted;
}
