import { ethers } from "ethers";
import { getConfirmationDepth, getReceiptConfirmations, withEvmRpc } from "../chains/rpc";
import { getChainAdapter } from "../chains/registry";
import { requireValidIdentifier } from "../chains/types";
import { decodeEvmActivity, type DecodedEvmActivity } from "./activityDecoder";

export interface VerifiedTransaction extends DecodedEvmActivity {
  walletAddress: string;
  chainId: string;
  transactionHash: string;
  networkFeeNative: string;
  blockTimestampMs: number | null;
}

export interface EvmTransactionExpectation {
  expectedRecipient?: string;
  expectedAssetAddress?: string | null;
  /** Expected transfer amount in base units; checked against native value or ERC-20 Transfer logs. */
  expectedAmountUnits?: string;
}

export type EvmVerificationCode =
  | "WRONG_CHAIN"
  | "WRONG_PAYER"
  | "WRONG_RECIPIENT"
  | "WRONG_ASSET"
  | "WRONG_AMOUNT"
  | "TRANSACTION_NOT_FOUND"
  | "RPC_UNAVAILABLE"
  | "RPC_TIMEOUT"
  | "FAILED";

export function classifyEvmVerificationError(error: unknown): EvmVerificationCode {
  const message = error instanceof Error ? error.message.toLowerCase() : String(error).toLowerCase();
  if (message.includes("not found") || message.includes("details unavailable")) return "TRANSACTION_NOT_FOUND";
  if (message.includes("confirmations") || message.includes("provider") || message.includes("rpc") || message.includes("reach the network")) return "RPC_UNAVAILABLE";
  if (message.includes("failed on-chain") || message.includes("failed on chain")) return "FAILED";
  if (message.includes("sender") || message.includes("wallet") || message.includes("sent by")) return "WRONG_PAYER";
  if (message.includes("recipient") || message.includes("target") || message.includes("did not target")) return "WRONG_RECIPIENT";
  if (message.includes("amount") || message.includes("value")) return "WRONG_AMOUNT";
  if (message.includes("asset") || message.includes("token")) return "WRONG_ASSET";
  if (message.includes("chain") || message.includes("network")) return "WRONG_CHAIN";
  return "FAILED";
}

const TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;

function configuredBridgeAddresses(): Set<string> {
  return new Set(
    (process.env.PAXI_TRUSTED_BRIDGE_ADDRESSES ?? "")
      .split(",")
      .map((value) => value.trim().toLowerCase())
      .filter((value) => ethers.isAddress(value)),
  );
}

/**
 * Confirms a mined EVM transaction, proves wallet involvement, and derives the
 * operation/amounts from receipt semantics. Client-provided event labels and
 * USD values are deliberately not accepted here.
 */
export async function verifyConfirmedEvmTransaction(
  network: string,
  walletAddress: string,
  transactionHash: string,
  expectation: EvmTransactionExpectation = {},
): Promise<VerifiedTransaction> {
  if (!TX_HASH_RE.test(transactionHash)) throw new Error("Invalid EVM transaction hash");
  const adapter = getChainAdapter(network.toLowerCase());
  if (adapter.family !== "evm" || !adapter.rpcUrl) throw new Error("Server transaction verification is not available for this network");
  const normalizedWallet = requireValidIdentifier(adapter, walletAddress);
  return withEvmRpc(adapter.network as Parameters<typeof withEvmRpc>[0], async (provider) => {
    const receipt = await provider.getTransactionReceipt(transactionHash);
    if (!receipt) throw new Error("Transaction not found or not confirmed");
    if (receipt.status !== 1) throw new Error("Transaction failed on-chain");
    const latestBlock = await provider.getBlockNumber();
    const requiredConfirmations = getConfirmationDepth(adapter.network as Parameters<typeof getConfirmationDepth>[0]);
    const confirmations = getReceiptConfirmations(latestBlock, receipt.blockNumber);
    if (confirmations < requiredConfirmations) {
      throw new Error(`Transaction needs ${requiredConfirmations} confirmations; currently has ${confirmations}.`);
    }
    const transaction = await provider.getTransaction(transactionHash);
    if (!transaction) throw new Error("Transaction details unavailable");
    if (expectation.expectedRecipient && !ethers.isAddress(expectation.expectedRecipient)) {
      throw new Error("Invalid expected recipient address");
    }
    if (expectation.expectedAssetAddress != null && !ethers.isAddress(expectation.expectedAssetAddress)) {
      throw new Error("Invalid expected asset contract");
    }
    const expectedRecipient = expectation.expectedRecipient?.toLowerCase();
    const expectedAsset = expectation.expectedAssetAddress?.toLowerCase();
    const expectedAmount = expectation.expectedAmountUnits == null ? undefined : BigInt(expectation.expectedAmountUnits);
    if (expectedAsset == null) {
      if (expectedRecipient && transaction.to?.toLowerCase() !== expectedRecipient) {
        throw new Error("The confirmed native SEND did not target the requested recipient");
      }
      if (expectedAmount !== undefined && transaction.value !== expectedAmount) {
        throw new Error("The confirmed native SEND amount does not match the reviewed amount");
      }
    } else {
      const transferFound = receipt.logs.some((log) => {
        if (log.address.toLowerCase() !== expectedAsset || log.topics[0] !== ethers.id("Transfer(address,address,uint256)") || log.topics.length < 3) return false;
        const from = `0x${log.topics[1].slice(-40)}`.toLowerCase();
        const to = `0x${log.topics[2].slice(-40)}`.toLowerCase();
        const amount = BigInt(log.data);
        return from === normalizedWallet.toLowerCase() && (!expectedRecipient || to === expectedRecipient) && (expectedAmount === undefined || amount === expectedAmount);
      });
      if (!transferFound) throw new Error("The confirmed token SEND did not target the requested recipient");
    }
    const decoded = await decodeEvmActivity({
      network: adapter.network,
      walletAddress: normalizedWallet,
      transaction,
      receipt,
      provider,
      read: <T>(operation: () => Promise<T>) => operation(),
      trustedBridgeAddresses: configuredBridgeAddresses(),
      requestedAssetAddress: expectedAsset,
    });
    if (expectation.expectedAssetAddress !== undefined && decoded.assetAddress !== expectedAsset) {
      throw new Error("The confirmed transaction asset does not match the requested asset");
    }
    const block = await provider.getBlock(receipt.blockNumber);
    const gasPrice = receipt.gasPrice ?? 0n;
    const networkFeeNative = ethers.formatUnits(receipt.gasUsed * gasPrice, 18);
    const blockTimestampMs = block?.timestamp != null ? block.timestamp * 1000 : null;
    return {
      walletAddress: normalizedWallet,
      chainId: adapter.network,
      transactionHash,
      networkFeeNative,
      blockTimestampMs,
      ...decoded,
    };
  });
}


export type ReconciledEvmTransaction =
  | { status: "pending" | "confirming"; confirmations: number; requiredConfirmations: number }
  | { status: "confirmed"; confirmations: number; requiredConfirmations: number; verified: VerifiedTransaction }
  | { status: "failed"; reason: string }
  | { status: "unknown"; reason: string; code?: string };

/**
 * Reconciliation deliberately does not convert provider outages into failed
 * transactions. A receipt is only final after the configured server depth and
 * the existing semantic verifier has accepted the transaction.
 */
export async function reconcileEvmTransaction(
  network: string,
  walletAddress: string,
  transactionHash: string,
  expectation: EvmTransactionExpectation = {},
): Promise<ReconciledEvmTransaction> {
  try {
    const adapter = getChainAdapter(network.toLowerCase());
    if (adapter.family !== "evm") return { status: "unknown", reason: "This reconciliation path only supports EVM networks." };
    const requiredConfirmations = getConfirmationDepth(adapter.network as Parameters<typeof getConfirmationDepth>[0]);
    return await withEvmRpc(adapter.network as Parameters<typeof withEvmRpc>[0], async (provider) => {
      const receipt = await provider.getTransactionReceipt(transactionHash);
      if (!receipt) return { status: "pending" as const, confirmations: 0, requiredConfirmations };
      if (receipt.status !== 1) return { status: "failed" as const, reason: "Transaction failed on-chain." };
      const latestBlock = await provider.getBlockNumber();
      const confirmations = getReceiptConfirmations(latestBlock, receipt.blockNumber);
      if (confirmations < requiredConfirmations) return { status: "confirming" as const, confirmations, requiredConfirmations };
      try {
        const verified = await verifyConfirmedEvmTransaction(network, walletAddress, transactionHash, expectation);
        return { status: "confirmed" as const, confirmations, requiredConfirmations, verified };
      } catch (error) {
        return { status: "failed" as const, reason: error instanceof Error ? error.message : "Transaction verification failed." };
      }
    });
  } catch (error) {
    const typed = error as { code?: string; message?: string };
    return { status: "unknown", reason: typed.message ?? "Provider unavailable while checking transaction status.", code: typed.code };
  }
}
