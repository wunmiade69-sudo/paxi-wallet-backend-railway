import { and, eq, gte, lte, sql } from "drizzle-orm";
import { candles, marketSnapshots } from "../../drizzle/schema";
import { getDb } from "../db";

/**
 * Phase 4 - Candle Generation Worker
 * 
 * Aggregates raw price snapshots into OHLCV candles for a specific 
 * asset and timeframe.
 */
export async function processCandleGeneration(assetId: number, timeframe: string) {
  const db = await getDb();
  if (!db) return;

  console.log(`[candle-worker] generating ${timeframe} candle for asset ${assetId}`);

  // Determine the time range for the current candle
  const now = new Date();
  let startTime: Date;
  
  switch (timeframe) {
    case "1m": startTime = new Date(now.getTime() - 60 * 1000); break;
    case "5m": startTime = new Date(now.getTime() - 5 * 60 * 1000); break;
    case "15m": startTime = new Date(now.getTime() - 15 * 60 * 1000); break;
    case "1h": startTime = new Date(now.getTime() - 60 * 60 * 1000); break;
    case "4h": startTime = new Date(now.getTime() - 4 * 60 * 60 * 1000); break;
    case "1d": startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000); break;
    default: throw new Error(`Unsupported timeframe: ${timeframe}`);
  }

  // Fetch snapshots in the range
  const snapshots = await db
    .select()
    .from(marketSnapshots)
    .where(and(
      eq(marketSnapshots.assetId, assetId),
      gte(marketSnapshots.timestamp, startTime),
      lte(marketSnapshots.timestamp, now)
    ))
    .orderBy(marketSnapshots.timestamp);

  if (snapshots.length === 0) {
    console.log(`[candle-worker] no snapshots found for asset ${assetId} in ${timeframe} range`);
    return;
  }

  const open = snapshots[0].priceUsd;
  const close = snapshots[snapshots.length - 1].priceUsd;
  const high = String(Math.max(...snapshots.map(s => Number(s.priceUsd))));
  const low = String(Math.min(...snapshots.map(s => Number(s.priceUsd))));
  
  // Sum volume if available
  let totalVolume = 0;
  for (const s of snapshots) {
    if (s.volume24hUsd) totalVolume += Number(s.volume24hUsd);
  }

  const candleValues = {
    assetId,
    timeframe,
    open,
    high,
    low,
    close,
    volume: String(totalVolume),
    timestamp: startTime, // represent the start of the period
  };

  await db.insert(candles).values(candleValues).onDuplicateKeyUpdate({ set: candleValues });
  
  console.log(`[candle-worker] generated ${timeframe} candle for asset ${assetId}: ${close}`);
}
