import { Worker } from "bullmq";
import { getQueueConnection } from "../redis";
import { MARKET_DATA_QUEUE_NAME, MarketJobData } from "../queue";
import { processPriceRefresh } from "./priceWorker";
import { processMarketDiscovery } from "./discoveryWorker";
import { processCandleGeneration } from "./candleWorker";
import { processMetadataRefresh } from "./metadataWorker";

/**
 * Phase 3B - Background Worker Implementation
 * 
 * This file manages the worker process that consumes jobs from the 
 * paxi-market-data queue.
 */

let _worker: Worker | null = null;

export function startWorkers() {
  if (_worker) {
    console.warn("[worker] workers already started");
    return;
  }

  const connection = getQueueConnection();
  if (!connection) {
    console.warn("[worker] Redis connection unavailable, workers will not start");
    return;
  }

  try {
    _worker = new Worker<MarketJobData>(
    MARKET_DATA_QUEUE_NAME,
    async (job) => {
      console.log(`[worker] processing job ${job.id} [${job.data.type}]`);
      
      switch (job.data.type) {
        case "price.refresh":
          if (!job.data.chainId || !job.data.identifier) {
            throw new Error("Missing chainId or identifier for price.refresh");
          }
          await processPriceRefresh(job.data.chainId, job.data.identifier, !!job.data.force);
          break;
          
        case "market.discover":
          if (!job.data.chainId) {
            throw new Error("Missing chainId for market.discover");
          }
          await processMarketDiscovery(job.data.chainId);
          break;

        case "candle.generate":
          if (!job.data.assetId || !job.data.timeframe) {
            throw new Error("Missing assetId or timeframe for candle.generate");
          }
          await processCandleGeneration(job.data.assetId, job.data.timeframe);
          break;
          
        case "metadata.refresh":
          if (!job.data.assetId) {
            throw new Error("Missing assetId for metadata.refresh");
          }
          await processMetadataRefresh(job.data.assetId);
          break;
          
        default:
          console.warn(`[worker] unknown job type: ${job.data.type}`);
      }
    },
    {
      connection,
      concurrency: Math.max(1, Math.min(Number(process.env.WORKER_CONCURRENCY ?? 5) || 5, 20)),
      maxStalledCount: 2,
      stalledInterval: 30_000,
    }
  );

  _worker.on("completed", (job) => {
    console.log(`[worker] job ${job.id} completed`);
  });

  _worker.on("failed", (job, err) => {
    console.error(`[worker] job ${job?.id} failed:`, err.message);
  });
  _worker.on("stalled", (jobId) => {
    console.warn(`[worker] job stalled: ${jobId}`);
  });
  _worker.on("error", (error) => {
    console.error("[worker] worker error:", error.message);
  });

  console.log("[worker] background workers started");
  } catch (error) {
    console.error("[worker] failed to start:", error instanceof Error ? error.message : "unknown error");
    _worker = null;
    connection.disconnect();
  }
}

export async function stopWorkers() {
  if (_worker) {
    await _worker.close();
    _worker = null;
    console.log("[worker] background workers stopped");
  }
}
