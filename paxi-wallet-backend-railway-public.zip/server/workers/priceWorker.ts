import { getOrCreateAsset } from "../assetRegistry";
import { performPriceRefresh } from "../priceEngine";

/**
 * Phase 3B - Price Refresh Worker
 * 
 * Processes a single price refresh job by fetching live data from
 * DexScreener or on-chain reserves and updating the cache/DB.
 */
export async function processPriceRefresh(chainId: string, identifier: string, force: boolean = false) {
  const asset = await getOrCreateAsset({
    chainId: chainId,
    identifier: identifier,
    symbol: "UNKNOWN",
    name: "Unknown token",
  });

  if (!asset) {
    throw new Error(`Asset not found: ${chainId}:${identifier}`);
  }

  const cacheKey = `${chainId}:${identifier}`;
  const decimals = asset.decimals ?? 18;

  console.log(`[price-worker] refreshing ${cacheKey} (assetId: ${asset.id})`);
  
  await performPriceRefresh(asset.id, chainId, identifier, decimals, cacheKey);
}
