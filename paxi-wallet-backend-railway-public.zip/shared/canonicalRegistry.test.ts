import { describe, expect, it } from "vitest";
import { canonicalStablecoin, isCanonicalStablecoin } from "./canonicalRegistry";

describe("canonical registry", () => {
  it("uses the complete Ethereum USDT address", () => {
    expect(canonicalStablecoin("ethereum", "USDT")?.address).toBe("0xdac17f958d2ee523a2206206994597c13d831ec7");
  });
  it("recognizes canonical EVM stablecoins case-insensitively", () => {
    expect(isCanonicalStablecoin("ethereum", "USDT", "0xdAC17F958D2ee523A2206206994597C13D831ec7")).toBe(true);
  });
  it("does not treat a wrong contract as canonical", () => {
    expect(isCanonicalStablecoin("ethereum", "USDT", "0x0000000000000000000000000000000000000001")).toBe(false);
  });
});
