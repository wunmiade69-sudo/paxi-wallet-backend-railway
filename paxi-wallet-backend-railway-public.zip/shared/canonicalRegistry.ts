/** Canonical chain/token identities shared by client and server. */
export type CanonicalNetwork = 'ethereum' | 'bsc' | 'polygon' | 'arbitrum' | 'solana' | 'bitcoin';
export type FeeTokenSymbol = 'USDT' | 'USDC';

export interface CanonicalFeeToken {
  symbol: FeeTokenSymbol;
  address: string;
  decimals: number;
}

export interface CanonicalChainAssetConfig {
  network: CanonicalNetwork;
  displayName: string;
  nativeSymbol: string;
  addressFormat: 'evm' | 'solana' | 'bitcoin';
  stablecoins: Partial<Record<FeeTokenSymbol, CanonicalFeeToken>>;
}

export const CANONICAL_CHAINS: Record<CanonicalNetwork, CanonicalChainAssetConfig> = {
  ethereum: {
    network: 'ethereum', displayName: 'Ethereum', nativeSymbol: 'ETH', addressFormat: 'evm',
    stablecoins: {
      USDT: { symbol: 'USDT', address: '0xdac17f958d2ee523a2206206994597c13d831ec7', decimals: 6 },
      USDC: { symbol: 'USDC', address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48', decimals: 6 },
    },
  },
  bsc: {
    network: 'bsc', displayName: 'BNB Chain', nativeSymbol: 'BNB', addressFormat: 'evm',
    stablecoins: {
      USDT: { symbol: 'USDT', address: '0x55d398326f99059ff775485246999027b3197955', decimals: 18 },
      USDC: { symbol: 'USDC', address: '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d', decimals: 18 },
    },
  },
  polygon: {
    network: 'polygon', displayName: 'Polygon', nativeSymbol: 'POL', addressFormat: 'evm',
    stablecoins: {
      USDT: { symbol: 'USDT', address: '0xc2132d05d31c914a87c6611c10748aeb04b58e8f', decimals: 6 },
      USDC: { symbol: 'USDC', address: '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359', decimals: 6 },
    },
  },
  arbitrum: {
    network: 'arbitrum', displayName: 'Arbitrum', nativeSymbol: 'ETH', addressFormat: 'evm',
    stablecoins: {
      USDT: { symbol: 'USDT', address: '0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9', decimals: 6 },
      USDC: { symbol: 'USDC', address: '0xaf88d065e77c8cc2239327c5edb3a432268e5831', decimals: 6 },
    },
  },
  solana: { network: 'solana', displayName: 'Solana', nativeSymbol: 'SOL', addressFormat: 'solana', stablecoins: {} },
  bitcoin: { network: 'bitcoin', displayName: 'Bitcoin', nativeSymbol: 'BTC', addressFormat: 'bitcoin', stablecoins: {} },
};

export function canonicalStablecoin(network: string, symbol: string): CanonicalFeeToken | null {
  const chain = CANONICAL_CHAINS[network as CanonicalNetwork];
  return chain?.stablecoins[symbol.toUpperCase() as FeeTokenSymbol] ?? null;
}

export function canonicalAddress(network: string, address: string): string {
  const chain = CANONICAL_CHAINS[network as CanonicalNetwork];
  return chain?.addressFormat === 'evm' ? address.trim().toLowerCase() : address.trim();
}

export function isCanonicalStablecoin(network: string, symbol: string, address: string): boolean {
  const token = canonicalStablecoin(network, symbol);
  return Boolean(token && token.address === canonicalAddress(network, address));
}
