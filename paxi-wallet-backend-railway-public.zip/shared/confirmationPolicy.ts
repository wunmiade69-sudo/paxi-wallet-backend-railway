/**
 * Chain-aware confirmation policy shared by client and server.
 *
 * The server may raise these defaults with environment variables; values are
 * deliberately conservative and never reduce the minimum below 1.
 */
export const DEFAULT_EVM_CONFIRMATIONS = 2;

export const EVM_CONFIRMATION_DEFAULTS: Record<string, number> = {
  ethereum: 2,
  bsc: 3,
  polygon: 2,
  arbitrum: 2,
};

export function getDefaultConfirmationDepth(network: string): number {
  return EVM_CONFIRMATION_DEFAULTS[network.toLowerCase()] ?? DEFAULT_EVM_CONFIRMATIONS;
}

export type ConfirmationPolicy =
  | { family: "evm"; confirmations: number }
  | { family: "solana"; commitment: "confirmed" | "finalized" }
  | { family: "bitcoin"; confirmations: number };

export function getConfirmationPolicy(network: string): ConfirmationPolicy {
  const normalized = network.toLowerCase();
  if (normalized === "solana") return { family: "solana", commitment: "finalized" };
  if (normalized === "bitcoin") return { family: "bitcoin", confirmations: 3 };
  return { family: "evm", confirmations: getDefaultConfirmationDepth(normalized) };
}
