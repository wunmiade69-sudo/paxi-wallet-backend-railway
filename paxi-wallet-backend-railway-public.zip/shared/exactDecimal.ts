/**
 * Exact decimal-string <-> base-unit bigint conversion.
 *
 * This is the ONLY sanctioned way to turn a human-entered amount (e.g. the
 * text in an amount input, or an integer-string quote amount from an
 * external API) into/out of the integer base-unit value that goes into a
 * real transaction (lamports, satoshis, wei, SPL/ERC-20 base units,
 * THORChain 1e8-scale units, swap source amounts, fee amounts, etc.).
 *
 * It deliberately never touches `Number`, `parseFloat`, or `Math.round`:
 * those all route the value through an IEEE-754 double, which cannot
 * represent many exact decimal fractions and silently introduces rounding
 * error once the scaled value exceeds 2^53. For real money that is not
 * acceptable, even if the error is "only" a few base units.
 *
 * Both client and server code should import from this module (via
 * `@shared/exactDecimal`) rather than hand-rolling another parser -
 * multiple incompatible decimal parsers is itself a correctness risk.
 */

export class InvalidDecimalAmountError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidDecimalAmountError';
  }
}

// Strict decimal literal: optional leading `+`, digits, optional `.digits`.
// No leading/trailing whitespace, no scientific notation, no sign other than `+`,
// no empty string, no bare ".", no multiple dots, no digit-group separators.
const STRICT_DECIMAL_RE = /^\+?(\d+)(?:\.(\d+))?$/;

/**
 * Convert a decimal amount string (e.g. "1", "0.000000001") into an exact
 * base-unit bigint at the given number of decimals (e.g. 9 for lamports,
 * 18 for wei, 6 for USDT/USDC, 8 for BTC satoshis).
 *
 * Throws InvalidDecimalAmountError for anything that is not a clean,
 * non-negative, finite decimal literal representable exactly at the given
 * number of decimals (i.e. it does not silently truncate excess precision -
 * "0.0000000001" at 9 decimals is rejected rather than floored to 0).
 */
export function parseExactBaseUnits(value: unknown, decimals: number): bigint {
  if (typeof value !== 'string') {
    throw new InvalidDecimalAmountError('Amount must be provided as a string');
  }
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) {
    throw new InvalidDecimalAmountError('Invalid decimals configuration');
  }

  const trimmed = value.trim();
  if (trimmed.length === 0) {
    throw new InvalidDecimalAmountError('Amount is required');
  }
  if (trimmed !== value) {
    // Reject values with surrounding whitespace rather than silently trimming,
    // so a stray space/newline from a form field cannot slip through unnoticed.
    throw new InvalidDecimalAmountError('Amount must not contain leading or trailing whitespace');
  }

  // Explicitly reject the patterns Number() would otherwise happily accept:
  // scientific notation, "Infinity", "NaN", hex literals, underscores, etc.
  const match = STRICT_DECIMAL_RE.exec(trimmed);
  if (!match) {
    throw new InvalidDecimalAmountError(`Invalid decimal amount: "${value}"`);
  }

  const [, wholePart, fractionPartRaw] = match;
  const fractionPart = fractionPartRaw ?? '';

  if (fractionPart.length > decimals) {
    throw new InvalidDecimalAmountError(
      `Amount has more precision (${fractionPart.length} decimal places) than the asset supports (${decimals})`,
    );
  }

  const paddedFraction = fractionPart.padEnd(decimals, '0');
  const combined = `${wholePart}${paddedFraction}`.replace(/^0+(?=\d)/, '');
  const units = BigInt(combined === '' ? '0' : combined);

  if (units <= 0n) {
    throw new InvalidDecimalAmountError('Amount must be greater than zero');
  }

  return units;
}

/**
 * Same as parseExactBaseUnits, but allows a zero result (useful for
 * optional/informational amounts). Still rejects negative, malformed,
 * infinite, or over-precise values.
 */
export function parseExactBaseUnitsAllowZero(value: unknown, decimals: number): bigint {
  try {
    return parseExactBaseUnits(value, decimals);
  } catch (error) {
    if (error instanceof InvalidDecimalAmountError && typeof value === 'string' && value.trim() === '0') {
      return 0n;
    }
    throw error;
  }
}

/**
 * Exact base-unit bigint -> decimal-string conversion (the reverse of
 * parseExactBaseUnits). Uses only bigint/string arithmetic - never routes
 * the value through Number - so it is safe to use anywhere upstream of a
 * balance check, fee calculation, or transaction construction, not just at
 * a final display boundary.
 *
 * Trailing fractional zeros are trimmed (matching the strict-decimal
 * grammar parseExactBaseUnits accepts), and a bare-integer result is
 * returned without a trailing ".".
 */
export function formatBaseUnits(units: bigint, decimals: number): string {
  if (typeof units !== 'bigint' || units < 0n) {
    throw new InvalidDecimalAmountError('Base-unit amount must be a non-negative bigint');
  }
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) {
    throw new InvalidDecimalAmountError('Invalid decimals configuration');
  }
  const scale = 10n ** BigInt(decimals);
  const whole = units / scale;
  const fraction = (units % scale).toString().padStart(decimals, '0').replace(/0+$/, '');
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

/**
 * Parse an already-integer base-unit string (e.g. THORChain's
 * "expected_amount_out": "123000000", or "amountSats") into a bigint.
 * Unlike parseExactBaseUnits this expects NO decimal point - it is for
 * values that are already expressed as an integer count of base units.
 * Rejects negative values, leading/trailing whitespace, and non-digit
 * content (including scientific notation).
 */
export function parseExactIntegerUnits(value: unknown, field: string): bigint {
  if (typeof value === 'number') {
    // Never accept a Number here for a monetary base-unit count - if the
    // upstream source handed us a JS number instead of a string, precision
    // may already be lost before we see it.
    throw new InvalidDecimalAmountError(`${field} must be provided as an integer string, not a number`);
  }
  if (typeof value !== 'string' || !/^[0-9]+$/.test(value)) {
    throw new InvalidDecimalAmountError(`${field} must be a non-negative integer string`);
  }
  return BigInt(value);
}
