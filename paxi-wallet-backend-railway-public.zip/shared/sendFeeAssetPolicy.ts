import { isCanonicalStablecoin, canonicalStablecoin } from "./canonicalRegistry";

export type SendFeeAssetPolicy =
  | { kind: "native"; reason: "native_assets_are_not_token_taxable" }
  | { kind: "erc20"; symbol: "USDT" | "USDC"; reason: "canonical_stablecoin_allowlist" };

/**
 * SEND fees are settled in the same asset being sent. Arbitrary ERC-20s are
 * therefore unsafe until PAXI has a verified receipt model for transfer-tax,
 * rebasing, and other non-standard token behaviour.
 *
 * P2.2 deliberately fails closed: native ETH/BNB and canonical USDT/USDC are
 * supported for non-zero fee settlement; arbitrary/custom ERC-20s are not
 * eligible for a non-zero PAXI SEND fee. This prevents a tax/rebase token from causing a quoted fee to be
 * recorded even though the treasury received less than expected.
 */
export function getSendFeeAssetPolicy(
  network: string,
  assetAddress: string | null,
  assetSymbol: string,
  assetDecimals: number,
): SendFeeAssetPolicy {
  if (assetAddress == null) {
    if (assetDecimals !== 18) throw new Error("Native EVM assets must use 18 decimals");
    return { kind: "native", reason: "native_assets_are_not_token_taxable" };
  }

  const symbol = assetSymbol.trim().toUpperCase();
  if (symbol !== "USDT" && symbol !== "USDC") {
    throw new Error("PAXI SEND fees are currently limited to native assets and canonical USDT/USDC. This token is not eligible for fee settlement yet.");
  }

  const canonical = canonicalStablecoin(network, symbol);
  if (!canonical || canonical.decimals !== assetDecimals || !isCanonicalStablecoin(network, symbol, assetAddress)) {
    throw new Error("This token is not the canonical USDT/USDC contract for the selected network and cannot be used for PAXI SEND fee settlement.");
  }

  return { kind: "erc20", symbol: symbol as "USDT" | "USDC", reason: "canonical_stablecoin_allowlist" };
}
