/**
 * Final pre-signing balance guard for a SEND. All inputs are exact
 * base-unit bigints (never Number/float), since this is the last check
 * before the user is asked to sign a real transaction.
 *
 * `assetBalanceUnits` / `amountUnits` / `serviceFeeUnits` are in the SEND
 * asset's own base units. `nativeBalanceUnits` / `networkFeeNativeUnits`
 * are in the chain's native-asset base units (wei/lamports/etc.) - these
 * are a different unit space from the asset ones whenever the SEND asset
 * isn't the native asset, so the two pairs must never be mixed together.
 */
export function validateSendBalances(input: {
  assetBalanceUnits: bigint;
  amountUnits: bigint;
  serviceFeeUnits: bigint;
  nativeBalanceUnits: bigint;
  networkFeeNativeUnits: bigint;
  isNativeAsset: boolean;
}): void {
  for (const [key, value] of Object.entries(input)) {
    if (key === "isNativeAsset") continue;
    if (typeof value !== "bigint" || value < 0n) {
      throw new Error("Balance and fee values must be exact non-negative integers");
    }
  }

  const requiredAssetUnits =
    input.amountUnits + input.serviceFeeUnits + (input.isNativeAsset ? input.networkFeeNativeUnits : 0n);
  if (input.assetBalanceUnits < requiredAssetUnits) {
    throw new Error("Insufficient asset balance for the transfer plus applicable fees");
  }
  if (input.nativeBalanceUnits < input.networkFeeNativeUnits) {
    throw new Error("Insufficient native balance for the network fees");
  }
}
