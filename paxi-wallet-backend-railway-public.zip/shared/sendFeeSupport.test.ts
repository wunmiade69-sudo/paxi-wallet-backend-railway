import { describe, expect, it } from 'vitest';
import { isSendFeeSettlementSupported, sendFeeUnavailableReason } from './sendFeeSupport';

describe('SEND fee settlement support matrix', () => {
  it('supports only Ethereum and BSC', () => {
    expect(isSendFeeSettlementSupported('ethereum')).toBe(true);
    expect(isSendFeeSettlementSupported('bsc')).toBe(true);
    expect(isSendFeeSettlementSupported('polygon')).toBe(false);
    expect(isSendFeeSettlementSupported('arbitrum')).toBe(false);
    expect(isSendFeeSettlementSupported('sol')).toBe(false);
    expect(isSendFeeSettlementSupported('btc')).toBe(false);
  });
  it('explains unsupported networks explicitly', () => {
    expect(sendFeeUnavailableReason('polygon')).toContain('Polygon');
    expect(sendFeeUnavailableReason('arbitrum')).toContain('Arbitrum');
    expect(sendFeeUnavailableReason('sol')).toContain('Solana');
    expect(sendFeeUnavailableReason('btc')).toContain('Bitcoin');
  });
});
