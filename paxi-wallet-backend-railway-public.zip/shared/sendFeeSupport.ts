/** Canonical PAXI SEND-fee settlement support matrix. */
export const SEND_FEE_SETTLEMENT_NETWORKS = ["ethereum", "bsc"] as const;
export type SendFeeSettlementNetwork = (typeof SEND_FEE_SETTLEMENT_NETWORKS)[number];

export function isSendFeeSettlementSupported(network: string): network is SendFeeSettlementNetwork {
  return (SEND_FEE_SETTLEMENT_NETWORKS as readonly string[]).includes(network);
}

export function sendFeeUnavailableReason(network: string): string {
  if (network === "polygon") return "PAXI service-fee settlement is not currently available on Polygon. Enable its verified fee path before using PAXI fee settlement on this network.";
  if (network === "arbitrum") return "PAXI service-fee settlement is not currently available on Arbitrum. Enable its verified fee path before using PAXI fee settlement on this network.";
  if (network === "sol") return "PAXI service-fee settlement is not currently available on Solana.";
  if (network === "btc") return "PAXI service-fee settlement is not currently available on Bitcoin.";
  return "PAXI service-fee settlement is not currently available on this network.";
}
