import { describe, expect, it } from "vitest";
import { assertSendStateTransition, canTransitionSendState, displaySendState } from "./sendLifecycle";

describe("SEND lifecycle", () => {
  it("allows the fee-before-send happy path", () => {
    expect(canTransitionSendState("QUOTED", "AWAITING_FEE")).toBe(true);
    expect(canTransitionSendState("AWAITING_FEE", "FEE_SUBMITTED")).toBe(true);
    expect(canTransitionSendState("FEE_CONFIRMING", "FEE_CONFIRMED")).toBe(true);
    expect(canTransitionSendState("FEE_CONFIRMED", "SEND_SUBMITTED")).toBe(true);
    expect(canTransitionSendState("SEND_CONFIRMING", "SEND_CONFIRMED")).toBe(true);
    expect(canTransitionSendState("SEND_CONFIRMED", "COMPLETED")).toBe(true);
  });

  it("fails closed on invalid transitions", () => {
    expect(canTransitionSendState("FEE_CONFIRMED", "COMPLETED")).toBe(false);
    expect(() => assertSendStateTransition("SEND_SUBMITTED", "FEE_CONFIRMED")).toThrow(/Invalid SEND state transition/);
  });

  it("maps internal states to explicit user-facing states", () => {
    expect(displaySendState("SEND_SUBMITTED")).toBe("Pending");
    expect(displaySendState("SEND_CONFIRMING")).toBe("Confirming");
    expect(displaySendState("SEND_CONFIRMED")).toBe("Confirmed");
    expect(displaySendState("RECONCILIATION_REQUIRED")).toBe("Needs verification");
    expect(displaySendState("FAILED")).toBe("Failed");
  });
});
