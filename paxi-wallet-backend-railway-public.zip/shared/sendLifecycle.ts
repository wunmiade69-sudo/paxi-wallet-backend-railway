export const SEND_STATES = [
  "CREATED",
  "QUOTED",
  "AWAITING_FEE",
  "FEE_SUBMITTED",
  "FEE_CONFIRMING",
  "FEE_CONFIRMED",
  "SEND_SUBMITTED",
  "SEND_CONFIRMING",
  "SEND_CONFIRMED",
  "COMPLETED",
  "FAILED",
  "REJECTED",
  "RECONCILIATION_REQUIRED",
] as const;

export type SendState = (typeof SEND_STATES)[number];

const TRANSITIONS: Record<SendState, readonly SendState[]> = {
  CREATED: ["QUOTED", "REJECTED"],
  QUOTED: ["AWAITING_FEE", "SEND_SUBMITTED", "REJECTED"],
  AWAITING_FEE: ["FEE_SUBMITTED", "RECONCILIATION_REQUIRED", "REJECTED"],
  FEE_SUBMITTED: ["FEE_CONFIRMING", "RECONCILIATION_REQUIRED", "FAILED"],
  FEE_CONFIRMING: ["FEE_CONFIRMED", "RECONCILIATION_REQUIRED", "FAILED"],
  FEE_CONFIRMED: ["SEND_SUBMITTED", "REJECTED"],
  SEND_SUBMITTED: ["SEND_CONFIRMING", "RECONCILIATION_REQUIRED", "FAILED"],
  SEND_CONFIRMING: ["SEND_CONFIRMED", "RECONCILIATION_REQUIRED", "FAILED"],
  SEND_CONFIRMED: ["COMPLETED", "RECONCILIATION_REQUIRED"],
  COMPLETED: [],
  FAILED: ["RECONCILIATION_REQUIRED"],
  REJECTED: [],
  RECONCILIATION_REQUIRED: ["FEE_CONFIRMING", "FEE_CONFIRMED", "SEND_CONFIRMING", "SEND_CONFIRMED", "COMPLETED", "FAILED", "REJECTED"],
};

export function canTransitionSendState(from: SendState, to: SendState): boolean {
  return from === to || TRANSITIONS[from].includes(to);
}

export function assertSendStateTransition(from: SendState, to: SendState): void {
  if (!canTransitionSendState(from, to)) throw new Error(`Invalid SEND state transition: ${from} -> ${to}`);
}

export function displaySendState(state: SendState): "Pending" | "Confirming" | "Confirmed" | "Failed" | "Rejected" | "Needs verification" {
  if (state === "RECONCILIATION_REQUIRED") return "Needs verification";
  if (state === "FAILED") return "Failed";
  if (state === "REJECTED") return "Rejected";
  if (["FEE_CONFIRMING", "SEND_CONFIRMING"].includes(state)) return "Confirming";
  if (["FEE_CONFIRMED", "SEND_CONFIRMED", "COMPLETED"].includes(state)) return "Confirmed";
  return "Pending";
}
