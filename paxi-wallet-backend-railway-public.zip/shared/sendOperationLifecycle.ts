export const SEND_OPERATION_STATES = [
  "QUOTED", "FEE_BROADCAST", "FEE_CONFIRMED", "SEND_BROADCAST", "CONFIRMED", "FAILED", "RECONCILIATION_REQUIRED",
] as const;
export type SendOperationState = (typeof SEND_OPERATION_STATES)[number];

const TRANSITIONS: Record<SendOperationState, readonly SendOperationState[]> = {
  QUOTED: ["FEE_BROADCAST", "FEE_CONFIRMED", "SEND_BROADCAST", "CONFIRMED", "FAILED", "RECONCILIATION_REQUIRED"],
  FEE_BROADCAST: ["FEE_CONFIRMED", "FAILED", "RECONCILIATION_REQUIRED"],
  FEE_CONFIRMED: ["SEND_BROADCAST", "FAILED", "RECONCILIATION_REQUIRED"],
  SEND_BROADCAST: ["CONFIRMED", "FAILED", "RECONCILIATION_REQUIRED"],
  CONFIRMED: [],
  FAILED: ["RECONCILIATION_REQUIRED"],
  RECONCILIATION_REQUIRED: ["FEE_CONFIRMED", "SEND_BROADCAST", "CONFIRMED", "FAILED"],
};

export function canTransitionSendOperation(from: SendOperationState, to: SendOperationState): boolean {
  return from === to || TRANSITIONS[from].includes(to);
}

export function assertSendOperationTransition(from: SendOperationState, to: SendOperationState): void {
  if (!canTransitionSendOperation(from, to)) throw new Error(`Invalid durable SEND operation transition: ${from} -> ${to}`);
}
