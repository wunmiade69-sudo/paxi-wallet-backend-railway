# Historical — PAXI Wallet Beta v0.2 Core Wallet Task Ledger

> This task ledger is preserved as an implementation history. Some entries describe earlier gaps that are now closed or intentionally superseded. Use `PAXI_WALLET_README.md` for current capabilities and `TESTING_GUIDE.md` for current verification requirements.

Beta v0.1 built the screens with mock data. This pass replaces the mocks
with a real, non-custodial wallet engine and wires every screen from the
spec to it.

## 1. Authentication

- [x] Splash screen (unchanged)
- [x] Welcome screen (unchanged)
- [x] Create account - now generates a real BIP-39 mnemonic (ethers.js)
- [x] Login - new lock/unlock screen shown whenever a wallet already
      exists on the device (was previously skipped entirely)
- [x] PIN setup - PIN is never stored; it's run through PBKDF2 (150k
      rounds) to derive an AES-256-GCM key that encrypts the mnemonic
- [x] Biometric unlock - real WebAuthn platform-authenticator flow; a
      successful Face ID/fingerprint check unwraps a device-bound key
      that decrypts a wrapped copy of the PIN

## 2. Wallet Engine

- [x] Generate wallet (ethers.js `HDNodeWallet.createRandom`, standard
      `m/44'/60'/0'/0/0` path - same derivation MetaMask/Trust Wallet use)
- [x] Import wallet (BIP-39 checksum validated, not just "12 words")
- [x] Export wallet (password-protected keystore JSON, or raw private key
      behind a PIN re-check + explicit reveal tap)
- [x] Recovery phrase (real, checksummed)
- [x] Verify recovery phrase (unchanged UI, now verifies a real phrase)

## 3. Dashboard

- [x] Portfolio value - sums live balances x live CoinGecko prices;
      shows "-" for anything not wired up yet instead of a fake number
- [x] Wallet address - real derived EVM address
- [x] Asset list - live where possible (see Known Gaps)
- [x] Recent transactions - real merged history (see section 15 below),
      no longer a placeholder

## 4. Assets

- [x] BNB, ETH, BTC, SOL, USDT configured in `lib/wallet/chains.ts`
- [x] Live balances for ETH, BNB, USDT (ERC-20) via public RPC
- [x] Live prices + 24h change via Binance's public market API (fast,
      no key, no rate-limit issues like CoinGecko's free tier had)
- [x] Tap any asset to open a detail screen with a live price chart
      (1D/1W/1M/1Y, Binance klines) - only for assets traded on Binance
- [ ] PAXI/WPAXI removed as hardcoded placeholders (PAXI Network turned
      out to be a separate Cosmos chain, not EVM) - add them back via
      "Import Token" once you have the real contract address(es)
- [ ] BTC/SOL balances (needs real address derivation first, see below)

## 5. Receive

- [x] QR code (qrcode.react)
- [x] Copy address
- [x] Network selector (EVM networks share one real address; BTC/SOL are
      clearly marked "not yet supported" instead of showing a fake address)

## 6. Send

- [x] Recipient address (validated per chain type)
- [x] Amount
- [x] Gas fee estimate (real eth_estimateGas + fee data via the public RPC)
- [x] Transaction confirmation screen
- [x] Real signing + broadcast for EVM-family assets (ETH, BNB, USDT,
      PAXI/WPAXI once an RPC is configured)
- [ ] BTC/SOL sending (blocked on the same address-derivation gap)

## 7. Settings

- [x] Dark mode (now actually switchable - v0.1 had `switchable` off)
- [x] Currency selector (persisted; display formatting hookup is next)
- [x] Language selector (persisted; only English strings translated so far)
- [x] Backup wallet (PIN re-check, then reveal phrase)
- [x] Export wallet (encrypted keystore download + raw key reveal)
- [x] Lock wallet / remove wallet from device

## 8. Swap

- [x] Multi-DEX quotes - routed via the Velora (formerly ParaSwap) public
      aggregator API (`lib/wallet/swap.ts`), no API key needed. A single
      quote is priced across 300+ liquidity sources (Uniswap, PancakeSwap,
      Balancer, Curve, etc.) and Velora's routing picks the best price,
      splitting across multiple pools/DEXs when that's cheaper.
- [x] Wallet fee - 0.3% (30 bps), collected on-chain via the aggregator's
      built-in partner-fee mechanism in the same transaction as the swap
      (`WALLET_FEE_BPS` / `WALLET_FEE_ADDRESS` in `lib/wallet/swap.ts`).
      No separate transfer, no extra gas for the user.
- [x] ERC-20 approval flow - checks current allowance to the aggregator's
      token transfer proxy and only sends an approve tx when needed.
- [x] Real signing + broadcast, same pattern as Send (ethers signer over
      public RPC) - EVM only (Ethereum, BSC), matching every other gap
      called out below.
- [x] Route visibility - the DEXs a swap actually used (Uniswap,
      PancakeSwap, etc.) are pulled out of Velora's price route and shown
      in the quote/confirm screens, instead of just claiming "many DEXs"
      with nothing to back it up.
- [ ] Configurable slippage - currently fixed at 1% in `SwapPanel.tsx`
      (`SLIPPAGE_BPS`); exposing this as a user setting is a fast follow.

## 9. Bridge

- [x] Cross-chain transfers - `lib/wallet/bridge.ts`, via the LI.FI
      aggregator API (also no key needed). Aggregates multiple underlying
      bridges (Stargate, Across, Hop, etc.) the same way Velora aggregates
      DEXs for Swap, and the quote/confirm UI shows which ones a given
      route actually used.
- [x] Wallet fee - same 0.3% (`WALLET_FEE_BPS`, shared with swap.ts),
      collected on-chain via LI.FI's integrator-fee mechanism.
- [x] Same ERC-20 approval + real signing/broadcast pattern as Swap/Send.
- [x] "To" network picker lists every configured network so the option is
      visible, but only EVM destinations (Ethereum, BSC) are selectable.
      Bitcoin and Solana are shown disabled with an explanation, rather
      than silently omitted or (worse) allowed to send to an address this
      wallet can't actually derive.
- [ ] **Bridging to Solana.** LI.FI itself supports SOL as a destination,
      but this wallet still has no real SOL keypair/address (see Known
      Gaps below) - sending there would mean generating a plausible-
      looking address with no way to ever access the funds. This unlocks
      as soon as SOL address derivation (`@solana/web3.js` or
      `tweetnacl`) is added - that's a new dependency and a separate
      pass, not a small addition to this one.
- [ ] Bitcoin bridging - blocked on the same BTC address-derivation gap
      called out for Send/Receive.

## 10. Manage Wallets (added post-v0.2)

- [x] Vault upgraded to v3: multiple wallet entries per device behind one
      PIN, with automatic migration from the old single-wallet v2 record
- [x] Create additional signing wallets, import by recovery phrase, or
      add watch-only addresses (view-only, no keys stored)
- [x] Switch active wallet, rename, delete (blocked on deleting your last
      signing wallet - use Settings -> Remove Wallet for a full device
      wipe instead)
- [x] Send screen shows a clear banner and disables sending when the
      active wallet is watch-only

## 11. Wallet Guide (added post-v0.2)

- [x] Standalone guide screen (Me -> Wallet Guide) with expandable
      sections: security basics, managing wallets, send/receive, swap/bridge

## 12. Discover (added post-v0.2)

- [x] Link bar - paste any URL (bare domain or full link) and open it in a
      new browser tab, e.g. an airdrop registration page
- [x] Curated dapp directory (Uniswap, PancakeSwap, Curve, 1inch, Aave,
      OpenSea, Blur, Jumper/LI.FI) grouped by category
- [x] Favorites + recently-opened, saved locally (`lib/wallet/discover.ts`)
- [x] Quick "copy my address" card, since most airdrop/registration forms
      just want a pasted address rather than a live wallet connection
- [ ] **Real in-page wallet connect (WalletConnect v2).** Links open
      externally, not in an embedded webview - most dapps send
      X-Frame-Options/CSP headers that block iframing anyway, and this is
      a web app, not a native shell that can inject a provider into a
      page. Wiring up an actual "Connect Wallet" flow needs a WalletConnect
      Cloud project ID (a signup step, like the on-ramp) plus a session/
      signing UI; this pass intentionally stops short of that and is
      upfront about it in the screen itself rather than faking a connect
      button that doesn't do anything.

## 13. Experience, Invite Friends, About Us (wired up)

- [x] **Experience** - replay tutorial (6-slide carousel covering wallets,
      send/receive, swap/bridge, discover, security) + a Quick Tips
      accordion. Was already built (`ExperienceScreen.tsx`) but never
      linked from the Me screen - now it is.
- [x] **Invite Friends** - deterministic referral code/link per wallet
      address (`lib/wallet/referral.ts`), copy/share buttons. Invite count
      and WPAXI reward are explicitly labeled "Pending launch" rather than
      showing fake numbers - both need a backend + the WPAXI token to
      exist, neither of which are built yet.
- [x] **About Us** - version/build info from `lib/appInfo.ts`, a links
      list (Website/X/Telegram/Docs - currently placeholder `#` URLs,
      swap in real ones when you have them), and Contact Support (mailto).

## 14. Global price coverage + token security (fixes the "not on Binance" issue)

- [x] **Root cause**: prices/charts only ever came from Binance -> CoinGecko,
      both of which only cover majors. Any imported/custom token with no
      Binance listing showed a blank price - not a bug in the lookup, just
      no fallback for tokens that aren't there.
- [x] **Fix**: added `lib/wallet/dexAnalytics.ts` - DexScreener's public API
      (free, no key, ~300 req/min), which indexes on-chain DEX pairs by
      contract address across 60+ chains. `fetchAllBalancesStreaming` now
      falls back to it for any asset with a contract address that Binance/
      CoinGecko don't cover, so the dashboard price stops being blank.
- [x] Added `lib/wallet/tokenSecurity.ts` - GoPlus Security's public Token
      Security API (also free/no key). Asset Detail's Stats tab now shows,
      for any token with a contract address: Liquidity, Market Cap, 24h
      Volume, a Buys-vs-Sells bar chart across 5m/1h/6h/24h windows, and a
      Security card (holder count, top-10-holder %, buy/sell tax,
      open-source/honeypot/mintable/blacklist-function flags).
- [x] Currently covers Ethereum + BSC (our two live EVM networks); the
      DexScreener side is already mapped for Solana too, ready for when
      Solana wallet support lands. GoPlus chain mapping will need its
      numeric chain_id added per new network as they're wired up.
- [ ] Historical price _charts_ for non-Binance tokens are still not
      possible without a paid data provider - DexScreener's free tier
      doesn't expose OHLC history, only live/24h snapshots. The Stats tab
      covers this gap with live data + the buy/sell diagram instead of a
      line chart.

## 15. Transaction History (closed out ahead of the redesign)

- [x] **Real on-chain history**, not just what this app itself broadcast.
      `lib/wallet/txIndexer.ts` (`fetchOnChainHistory`) pulls native +
      ERC-20/BEP-20 transfers for the wallet's address from Blockscout's
      free, no-key public API instances (`eth.blockscout.com`,
      `bsc.blockscout.com` - same "no signup" bar as every other data
      source in this app). This is what makes **receives** show up at all;
      the local log (`txHistory.ts`) never saw those since the app never
      broadcasts them.
- [x] **Real pending -> confirmed/failed status.** New sends/swaps/bridges
      are logged locally as `pending` the moment they're submitted
      (`addTxRecord` in `txHistory.ts`). `getFullHistory`'s
      `resolvePendingStatus` checks the real receipt over the same public
      RPC already used for balances/sending and flips it to `confirmed` or
      `failed`, with the actual gas fee paid, once mined.
- [x] **One merged list**, not two competing sources of truth.
      `getFullHistory(address)` in `txIndexer.ts` unions local + on-chain
      by tx hash - on-chain wins for status/fee, local wins for richer
      in-app context (a swap's destination token/amount, the exact address
      the user typed). Wired into Dashboard's History tab, the
      Transaction Records screen, and a new "Recent Activity" section on
      Asset Detail (filtered to that asset). Every screen paints instantly
      from the local cache, then swaps in the resolved/merged list.
- [x] `TransactionList.tsx` now shows a Pending/Failed badge per row and
      "+"/"From ..." for receives instead of only ever showing outgoing
      sends.
- [x] **Stale-while-revalidate caching.** `getHistoryStaleWhileRevalidate`
      in `txIndexer.ts` caches the last successful merged result per
      address in localStorage and returns it instantly, kicking off a
      fresh background fetch to replace it. A slow/unreachable Blockscout
      or RPC now degrades to "last-known list, refreshing quietly" instead
      of a spinner or an empty screen on every repeat visit. The manual
      refresh button on Transaction Records bypasses the cache and forces
      a true fresh fetch.
- [ ] Covers Ethereum + BSC only, matching every other live gap in this
      pass (Bitcoin/Solana have no address yet - nothing to index). Also
      only covers native + token _transfer_ events, not full contract
      interaction decoding (e.g. an NFT mint would still just show as a
      0-value transaction and get filtered out) - out of scope for now.

---

## Known Gaps (carried into Beta v0.3)

- [ ] **BTC and SOL address derivation.** These use different curves than
      EVM chains (secp256k1 for BTC's legacy/P2SH paths + bech32 encoding,
      ed25519 for SOL) and need bitcoinjs-lib/@scure/bip32 and
      @solana/web3.js respectively. Rather than fabricate plausible-but-
      wrong addresses, the UI clearly labels these as unsupported until
      the libraries are added.
- [ ] **PAXI mainnet RPC endpoint.** `lib/wallet/chains.ts` has the slot
      (`NETWORKS.paxi.rpcUrl`) ready - drop in the URL once it's public.
- [ ] **Currency conversion.** The currency setting is stored but the
      dashboard still displays USD; needs an FX-rate source.
- [ ] **npm install was not run in this environment** (no network
      access) - ethers and qrcode.react were added to package.json
      but you'll need to install them before building/running.

## Security notes for reviewers

- Mnemonic is encrypted at rest with AES-256-GCM, key derived via PBKDF2
  (150k iterations, per-wallet random salt) from the PIN. Nothing is
  stored in plaintext.
- Biometric unlock is a real WebAuthn platform-authenticator check, not
  a UI-only gate: it unwraps a non-extractable device key (stored in
  IndexedDB) used to decrypt a wrapped copy of the PIN.
- The decrypted mnemonic lives in memory only while unlocked and is
  cleared on lock/refresh - never written to localStorage in plaintext.
- Sending is real: it signs and broadcasts to the actual public network
  for the selected chain. There's no testnet/sandbox mode yet.

## New design polish request

- [x] Replace the basic splash screen with a premium PAXI logo-led loading experience
- [x] Add the official PAXI logo and premium dark-gold visual treatment to the initial opening loading splash before onboarding
- [x] Redesign the wallet welcome/onboarding screen for a more professional first impression
- [x] Add a persistent verified badge for the official PAXI token in token detail and market listings
- [x] Verify the updated mobile experience, tests, build, and temporary preview
- [x] Simplify the loading splash into a clean, precisely centered premium state with a shorter transition
- [x] Remove the welcome-screen logo and replace the oversized orange Create action with a balanced dark action system
- [x] Visually verify the refined loading-to-welcome flow on a mobile viewport
- [x] Replace the plain dashboard PAXI header with a stronger official brand treatment
- [x] Add deterministic verified ticks for trusted native assets and canonical token contracts without verifying arbitrary imports
- [x] Add regression coverage and visually validate trusted-asset badges on the temporary dashboard

- [x] Prevent dashboard balance and token lists from automatically reloading on tab switch / page return; retain last loaded data and require manual refresh button use

- [x] Fix completed swaps displaying "Pending" instead of "Successful" after blockchain confirmation
- [x] Redesign the in-app transaction result screen and downloadable receipt with professional branding, clear status badges, and polished layout

- [ ] Deliver the complete updated source archive and a verified temporary preview URL for the latest swap-status and receipt changes

- [x] Remove Polygon USDT from default assets and verification registry
- [x] Ensure official PAXI token logo and identity persist correctly when logging out and logging into another wallet instance
- [x] Eliminate fallback token placeholder rendering for the official PAXI contract address
- [x] Polish the downloadable transaction receipt and the Trade swap history rows for a professional look

- [ ] Fix BTC Thorchain swap routing, balance prerequisites, and inactive BTC/Solana address activation

- [x] Polish the Trade swap preview, quote cards, warning boxes, and balance-error styling into a cohesive professional interface
- [x] Detect THORChain trading halts explicitly in ThorchainSwapPanel and show a clear maintenance/halt notice instead of raw simulation errors
- [x] Remove the white frame around the opening PAXI splash by making the initial page, root, and bootstrap container fill the dark viewport
- [x] Restart and verify a fresh temporary preview URL for the corrected full-viewport splash
- [x] Restore normal vertical scrolling throughout the mobile wallet without breaking intentional modal or drawer scroll locks
- [x] Remove the Eruda developer-console overlay from the temporary wallet UI
- [x] Diagnose and safely handle client API query errors and market-provider fallbacks without blocking wallet navigation
- [x] Format very small native-asset balances in fixed decimal notation instead of scientific notation across bridge and swap views
- [x] Restore a visible asset-security section with clear fallback messaging when a token has no available provider report
- [x] Audit and complete the token-listing submission, payment-proof, and admin review workflow before enabling campaigns
- [x] Enforce approved-listing and funded-reward-pool gates for campaign creation and participation
- [x] Add regression tests for listing review states and campaign eligibility gates
- [x] Add a dedicated My Listings screen with payment-verification, review-status, eligibility, and rejection-reason visibility
- [x] Validate submitted contract identities on the backend for every supported listing network before payment confirmation
- [x] Add a safe rejected-listing resubmission flow that preserves the token-identity lock and audit history
- [x] Add regression tests for listing status presentation, network validation, and resubmission eligibility
- [x] Add recognisable blockchain logos and labels to the paid listing network selector
- [x] Add server-validated campaign banner and campaign-icon storage keys with draft-only visibility
- [x] Require admin campaign approval after reward-pool verification before a campaign becomes publicly active
- [x] Add owner campaign submission status and admin campaign review/rejection controls
- [x] Add public campaign cards with approved banner/icon assets and non-sensitive campaign progress information
- [x] Add regression tests for campaign asset validation, approval gates, and public-visibility rules
- [x] Add featured-campaign controls and an approved active campaign banner carousel to the wallet home screen
- [x] Add server-authoritative campaign requirements and per-user eligibility evaluation from verified PAXI activity
- [x] Add campaign detail eligibility progress and requirement completion states without trusting client assertions
- [x] Add a guarded claim-readiness workflow with idempotency, active-listing, active-campaign, eligibility, and pool-sufficiency checks
- [x] Add owner and administrator controls for campaign feature status, suspension, and claim/reward operational states
- [x] Add regression tests for featured discovery, eligibility evaluation, and claim-safety gates
- [x] Separate the privileged PAXI administration workspace from public wallet routes and project-owner campaign/listing routes
- [x] Strengthen administrator authorization boundaries and add immutable audit events for sensitive administrative campaign operations
- [x] Add a dedicated project-owner workspace entry point for listings and campaigns without exposing platform administration controls
- [x] Diagnose and repair unavailable historical charts through validated asset identifiers, provider fallbacks, and explicit source/status states
- [x] Add regression coverage for administrative workspace authorization, audit-event recording, and chart provider fallback behavior
