# Paxi Wallet Database Migration Runbook

## Production command

Use the idempotent deployment command with `DATABASE_URL` set:

```bash
npm run db:push
```

The command runs, in order:

1. `scripts/applyProviderProvenance.ts`
2. `scripts/applyScalePartitioning.ts`
3. `scripts/checkIdentifierDuplicates.ts`
4. `scripts/applyIdentifierCollation.ts`
5. `scripts/applyReferenceConstraints.ts`
6. `scripts/applyActivitySchema.ts`
7. `scripts/applyRewardsSchema.ts`
8. `scripts/applyOptimizations.ts`
9. `scripts/seedFeeConfig.ts`
10. `scripts/applyDeploymentLedger.ts`
11. `scripts/dbRegressionTest.ts`

Each deployment step checks the live schema before changing it. The scripts use bounded MySQL connection timeouts and terminate their connections explicitly, so an unreachable database fails quickly instead of leaving a deployment process hanging.

## Important migration safety rule

Raw Drizzle migration execution is intentionally disabled for this deployment state. The database was historically updated through targeted/idempotent scripts, while the Drizzle migration ledger contains only a partial history. Running the raw Drizzle migration chain could attempt to replay partitioning or intermediate index operations against an already-updated database. Use `npm run db:generate` only to inspect local SQL during development; use `npm run db:push` for Railway and production changes.

The regression suite reports this state explicitly as:

```text
Manual/idempotent deployment history; do not run drizzle-kit migrate
```

The consolidated deployment ledger is updated by `scripts/applyDeploymentLedger.ts`; the rewards architecture is recorded as `rewards-eligibility-airdrop-v1` and `wpaxi-referral-pools-v1`. New schema changes must add an idempotent deployment script and a ledger version, then update the regression assertions. Raw Drizzle migration execution remains disabled.

## Verification expectations

A successful deployment must show all of the following:

- Provider provenance columns are present on `assetMarketData`.
- `candles` and `marketSnapshots` are partitioned.
- Both time-series tables use the composite primary key `(id, timestamp)`.
- The high-traffic and idempotency indexes are present.
- User-owned listings, campaigns, and entries have foreign-key constraints.
- Referral profiles, referrals, gift codes, reward ledger entries, eligibility results, airdrop allocations, verified referral trading volume, reward policies, reward pools, and reward claims have required indexes and foreign keys.
- The consolidated deployment ledger contains the current architecture milestones.
- The database regression suite exits successfully.

Never place a production `DATABASE_URL` in source control, `.env` files, logs, or issue reports.
