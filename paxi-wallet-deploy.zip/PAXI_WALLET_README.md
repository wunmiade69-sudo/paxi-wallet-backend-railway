# PAXI Wallet Beta v0.1 - Professional Crypto Wallet

A modern, non-custodial cryptocurrency wallet built with React, TypeScript, and Tailwind CSS. Features a beautiful glassmorphism UI with gold accents, complete onboarding flow, and secure wallet management using localStorage.

## 🎯 Features Implemented (Beta v0.1)

### ✅ Onboarding Flow
- **Splash Screen** - Animated introduction with PAXI branding
- **Welcome Screen** - Choice between creating a new wallet or importing existing one
- **Create Wallet** - Generate 12-word BIP39 recovery phrase with copy functionality
- **Import Wallet** - Import existing wallet using recovery phrase
- **Verify Recovery Phrase** - Secure verification by selecting words in correct order
- **PIN Setup** - 6-digit PIN for quick access with confirmation
- **Biometric Setup** - Optional Face ID/Fingerprint authentication (WebAuthn API)

### ✅ Dashboard
- **Portfolio Overview** - Total balance with 24h change percentage
- **Wallet Address** - Display and copy wallet address
- **QR Code** - Generate QR code for receiving funds (placeholder)
- **Asset Management** - Display all supported assets with balances and prices
- **Transaction History** - View recent send/receive transactions
- **Bottom Navigation** - Quick access to Home, Markets, Swap, and More

### ✅ Send/Receive Modals
- **Send Crypto** - Modal for sending funds with asset selection
- **Receive Crypto** - Display wallet address and QR code for receiving
- **Toast Notifications** - User feedback for all actions

### ✅ Settings
- **Backup Wallet** - Backup recovery phrase (stub)
- **Export Wallet** - Export wallet data (stub)
- **Dark Mode** - Enabled by default
- **Language** - English (extensible)
- **Currency** - USD (extensible)
- **Logout** - Clear wallet data and return to onboarding

### ✅ Supported Assets
- PAXI (Native token)
- WPAXI (Wrapped PAXI)
- BNB (Binance Coin)
- ETH (Ethereum)
- BTC (Bitcoin)
- SOL (Solana)
- USDT (Tether)

## 🎨 Design System

### Color Scheme
- **Primary Accent**: Gold (#FFD700 / oklch(0.75 0.22 70))
- **Background**: Black (oklch(0.05 0.01 0))
- **Cards**: Dark Gray (oklch(0.1 0.01 0))
- **Text**: White (oklch(0.98 0.001 0))

### UI Components
- **Glassmorphism**: Frosted glass effect with backdrop blur
- **Smooth Animations**: Fade-in and slide-up transitions
- **Responsive Design**: Mobile-first approach
- **Professional Icons**: Lucide React icons throughout

## 📁 Folder Structure

```
paxi-wallet/
├── client/
│   └── src/
│       ├── pages/
│       │   ├── SplashScreen.tsx          # Animated splash screen
│       │   ├── WelcomeScreen.tsx         # Welcome with Create/Import buttons
│       │   ├── CreateWallet.tsx          # Recovery phrase generation
│       │   ├── ImportWallet.tsx          # Import existing wallet
│       │   ├── VerifyRecoveryPhrase.tsx  # Phrase verification
│       │   ├── PINSetup.tsx              # 6-digit PIN setup
│       │   ├── BiometricSetup.tsx        # Biometric authentication
│       │   ├── Dashboard.tsx             # Main dashboard with modals
│       │   ├── Home.tsx                  # Template page
│       │   ├── NotFound.tsx              # 404 page
│       │   └── ComponentShowcase.tsx     # Component demo
│       ├── components/
│       │   └── ui/                       # Radix UI components
│       ├── lib/
│       │   └── walletUtils.ts            # Wallet utilities & crypto functions
│       ├── contexts/
│       │   └── ThemeContext.tsx          # Dark mode theme provider
│       ├── App.tsx                       # Main app router
│       ├── main.tsx                      # React entry point
│       ├── index.css                     # Global styles & theme
│       └── index.html                    # HTML shell
├── server/
│   ├── _core/                            # Core server utilities
│   ├── db.ts                             # Database setup
│   ├── routers.ts                        # API routes
│   └── storage.ts                        # Storage configuration
├── shared/
│   ├── types.ts                          # Shared TypeScript types
│   └── const.ts                          # Shared constants
├── drizzle/                              # Database migrations
├── package.json                          # Dependencies
├── vite.config.ts                        # Vite configuration
├── tsconfig.json                         # TypeScript configuration
├── tailwind.config.ts                    # Tailwind CSS configuration
└── README.md                             # Project documentation
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or 20+
- npm 10+

### Installation

```bash
# Navigate to project directory
cd paxi-wallet

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will be available at `http://localhost:3000`

### Build for Production

```bash
# Build the project
npm run build

# Start production server
npm run start
```

## 🔐 Security Features

### Implemented
- ✅ BIP39 recovery phrase generation and validation
- ✅ PIN encryption using base64 (production: use TweetNaCl.js)
- ✅ WebAuthn biometric authentication
- ✅ localStorage with encryption for sensitive data
- ✅ Secure phrase verification flow

### Recommended for Production
- 🔄 Replace base64 PIN encryption with proper cryptography (libsodium, TweetNaCl.js)
- 🔄 Implement proper key derivation (PBKDF2, Argon2)
- 🔄 Add hardware wallet support (Ledger, Trezor)
- 🔄 Implement transaction signing with proper cryptography
- 🔄 Add rate limiting and brute-force protection
- 🔄 Implement secure enclave for sensitive data

## 💾 Data Persistence

Currently uses **localStorage** for demo purposes:
- `paxi-wallet-data`: Encrypted wallet data (recovery phrase, PIN, address)
- `paxi-biometric-id`: Biometric credential ID

### Migration to Backend (Supabase)
1. Create Supabase project
2. Set up authentication with OAuth
3. Create `wallets` table with encrypted fields
4. Update `walletUtils.ts` to use API calls
5. Implement server-side encryption

## 📊 Supported Networks (Future)

- Binance Smart Chain (BSC)
- Ethereum Mainnet
- Polygon
- Solana
- Bitcoin (via bridge)

## 🎯 Roadmap

### Beta v0.2
- WPAXI Mining system
- Referral program
- Daily check-in rewards
- Task system
- Push notifications

### Beta v0.3
- Staking functionality
- VIP tiers
- Merchant center
- Merchant QR codes
- Payment receiving

### Beta v0.4
- KYC integration
- Admin panel
- Firebase integration
- Enhanced push notifications

### Final Release
- APK for Android
- iOS app
- Telegram Mini App
- Official website

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS 4
- **UI Components**: Radix UI, Lucide React
- **State Management**: React Hooks
- **Animations**: Framer Motion, Tailwind CSS animations
- **Backend**: Express.js, tRPC
- **Database**: MySQL/TiDB with Drizzle ORM
- **Build Tool**: Vite
- **Package Manager**: npm

## 📱 Browser Support

- Chrome/Chromium 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## 🧪 Testing

### Manual Testing Checklist
- [ ] Splash screen animation completes
- [ ] Welcome screen displays both buttons
- [ ] Create wallet generates 12-word phrase
- [ ] Recovery phrase can be copied
- [ ] Phrase verification works correctly
- [ ] PIN setup accepts 6 digits
- [ ] Biometric setup (if supported)
- [ ] Dashboard displays portfolio value
- [ ] Assets tab shows all tokens
- [ ] History tab shows transactions
- [ ] Send modal opens and closes
- [ ] Receive modal displays QR code
- [ ] Settings modal works correctly
- [ ] Logout clears data
- [ ] Import wallet flow works

## 📝 Environment Variables

Create `.env.local` file:

```env
VITE_API_URL=http://localhost:3000
VITE_ANALYTICS_ENDPOINT=https://analytics.example.com
VITE_ANALYTICS_WEBSITE_ID=your-website-id
```

## 🐛 Known Issues & Limitations

1. **QR Code**: Currently a placeholder. Integrate `qrcode.react` for real QR generation
2. **PIN Encryption**: Uses base64 (not secure). Replace with proper encryption
3. **Recovery Phrase**: Uses demo BIP39 words. Integrate full `bip39` library
4. **Biometric**: WebAuthn support varies by browser/device
5. **Transaction Signing**: Not implemented (demo only)
6. **Network Requests**: All data is mocked in localStorage

## 🔄 Next Steps

1. **Integrate Real Blockchain**
   - Add Web3.js or Ethers.js
   - Implement transaction signing
   - Connect to blockchain networks

2. **Backend Integration**
   - Migrate to Supabase for user data
   - Implement server-side encryption
   - Add API authentication

3. **Enhanced Security**
   - Implement proper cryptography
   - Add rate limiting
   - Add security audit

4. **Mobile App**
   - Wrap with React Native / Expo
   - Add native biometric support
   - Implement app-specific security

5. **Testing**
   - Add unit tests with Vitest
   - Add E2E tests with Playwright
   - Security testing

## 📞 Support

For issues, questions, or feature requests, please create an issue in the repository.

## 📄 License

MIT License - See LICENSE file for details

## 🙏 Acknowledgments

- Radix UI for accessible components
- Tailwind CSS for utility-first styling
- Lucide React for beautiful icons
- The crypto community for inspiration

---

**Version**: 0.1.0  
**Last Updated**: July 2026  
**Status**: Beta - Ready for testing
