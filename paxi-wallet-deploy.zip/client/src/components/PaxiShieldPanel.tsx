import { Check, X, HelpCircle, ShieldCheck, ShieldAlert } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface PaxiShieldPanelProps {
  network: string;
  contractAddress?: string;
  /** Native coins (BNB, ETH, SOL, BTC) have no contract to check - always shown as safe. */
  isNative?: boolean;
}

function supportedSecurityNetwork(network: string): "ethereum" | "bsc" | null {
  return network === "ethereum" || network === "bsc" ? network : null;
}

/** Small top-of-review status line: 🟢 Safe Contract / 🟡 Unknown Contract / 🔴 High Risk. */
export function SecurityStatusBadge({ network, contractAddress, isNative }: PaxiShieldPanelProps) {
  const securityNetwork = supportedSecurityNetwork(network);
  const { data, isLoading } = trpc.security.checkContract.useQuery(
    { network: securityNetwork ?? "ethereum", contractAddress: contractAddress ?? '' },
    { enabled: !isNative && !!contractAddress && !!securityNetwork }
  );

  if (isNative) {
    return <StatusLine tone="safe" label="Native asset" />;
  }
  if (isLoading) {
    return <StatusLine tone="checking" label="Checking contract" />;
  }
  if (!data || data.status === 'unknown') {
    return <StatusLine tone="unknown" label="Unverified contract" />;
  }
  if (data.status === 'high-risk') {
    return <StatusLine tone="risk" label="High-risk contract" />;
  }
  return <StatusLine tone="safe" label="Security review available" />;
}

function StatusLine({ tone, label }: { tone: 'safe' | 'checking' | 'unknown' | 'risk'; label: string }) {
  const styles = {
    safe: 'border-emerald-400/20 bg-emerald-400/10 text-emerald-300',
    checking: 'border-white/10 bg-white/[0.04] text-muted-foreground',
    unknown: 'border-amber-400/20 bg-amber-400/10 text-amber-300',
    risk: 'border-red-400/20 bg-red-400/10 text-red-300',
  }[tone];
  const dot = { safe: 'bg-emerald-400', checking: 'bg-white/40', unknown: 'bg-amber-400', risk: 'bg-red-400' }[tone];
  return (
    <span className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-[11px] font-semibold tracking-wide ${styles}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} aria-hidden="true" />
      {label}
    </span>
  );
}

/** The expandable "PAXI Shield" checklist + score - the detailed view under the badge. */
export function PaxiShieldPanel({ network, contractAddress, isNative }: PaxiShieldPanelProps) {
  const securityNetwork = supportedSecurityNetwork(network);
  const { data, isLoading } = trpc.security.checkContract.useQuery(
    { network: securityNetwork ?? "ethereum", contractAddress: contractAddress ?? '' },
    { enabled: !isNative && !!contractAddress && !!securityNetwork }
  );

  if (isNative) return null;

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-4 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-accent/20 bg-accent/10">
            {data?.status === 'high-risk' ? <ShieldAlert className="h-4 w-4 text-red-300" /> : <ShieldCheck className="h-4 w-4 text-accent" />}
          </span>
          <div>
            <p className="text-sm font-semibold text-foreground">PAXI Shield</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground">Contract signal, not a guarantee</p>
          </div>
        </div>
        <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Security</span>
      </div>

      {isLoading ? (
        <p className="text-xs text-muted-foreground">Checking contract…</p>
      ) : !data || data.score == null ? (
        <p className="text-xs text-muted-foreground">
          No security data available for this token yet. That's not the same as "safe" - proceed carefully,
          especially with a brand-new or low-liquidity token.
        </p>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2">
            <CheckRow label="Verified contract" value={data.checks.verifiedContract} />
            <CheckRow label="No honeypot" value={data.checks.noHoneypot} />
            <CheckRow label="Liquidity locked" value={data.checks.liquidityLocked} />
            <CheckRow label="Ownership renounced" value={data.checks.ownershipRenounced} />
            <CheckRow label="Low rug risk" value={data.checks.lowRugRisk} />
          </div>

          <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/10 px-3 py-2.5">
            <div>
              <p className="text-xs text-muted-foreground">Safety Score</p>
              <p className="text-lg font-bold text-foreground">{data.score}/100</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Risk Level</p>
              <p
                className={`text-lg font-bold ${
                  data.riskLevel === 'LOW' ? 'text-emerald-400' : data.riskLevel === 'MEDIUM' ? 'text-amber-400' : 'text-red-400'
                }`}
              >
                {data.riskLevel}
              </p>
            </div>
          </div>

          <p className="text-[11px] text-muted-foreground pt-1">
            Based on real on-chain data via GoPlus Security. This is a safety signal, not a guarantee - always do
            your own research.
          </p>
        </>
      )}
    </div>
  );
}

function CheckRow({ label, value }: { label: string; value: boolean | null }) {
  return (
    <div className="flex min-h-10 items-center justify-between gap-2 rounded-xl border border-white/[0.07] bg-white/[0.025] px-2.5 py-2">
      <span className="text-[11px] leading-tight text-foreground/75">{label}</span>
      {value === true ? (
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-400/10"><Check className="h-3.5 w-3.5 text-emerald-300" /></span>
      ) : value === false ? (
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-red-400/10"><X className="h-3.5 w-3.5 text-red-300" /></span>
      ) : (
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/[0.06]"><HelpCircle className="h-3.5 w-3.5 text-muted-foreground" /></span>
      )}
    </div>
  );
}
