/**
 * Static app metadata for the About Us screen. Website is still a
 * placeholder - swap in the real URL once it exists.
 */

export const APP_VERSION = '0.2.1';
export const APP_BUILD_NAME = 'Beta v0.2 - Core Wallet + Manage/Guide/Discover';

/** Official PAXI BSC token mark shared across the wallet identity surfaces. */
export const PAXI_LOGO_URL = 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663875467785/ncgNASoXGmuVDcrF.png';
export const PAXI_BSC_CONTRACT = '0xeda04581461bc308e60052fe489e20c3f78d6e4e';

type VerifiableAsset = {
  network?: string | null;
  contractAddress?: string | null;
  symbol?: string | null;
  isNative?: boolean | null;
  iconUrl?: string | null;
};

type VerifiableMarketToken = {
  id?: string | null;
  symbol?: string | null;
  name?: string | null;
};

const TRUSTED_NATIVE_ASSET_KEYS = new Set([
  'BNB:bsc',
  'ETH:ethereum',
  'ETH:arbitrum',
  'BTC:bitcoin',
  'SOL:solana',
  'POL:polygon',
]);

const TRUSTED_TOKEN_CONTRACT_KEYS = new Set([
  'USDT:ethereum:0xdac17f958d2ee523a2206206994597c13d831ec7',
  'USDC:ethereum:0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
  'USDT:bsc:0x55d398326f99059ff775485246999027b3197955',
  'USDC:bsc:0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d',
  'USDC:polygon:0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
  'USDT:arbitrum:0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9',
  'USDC:arbitrum:0xaf88d065e77c8cc2239327c5edb3a432268e5831',
]);

const TRUSTED_MARKET_IDENTITIES = new Set([
  'binancecoin:BNB',
  'ethereum:ETH',
  'bitcoin:BTC',
  'solana:SOL',
  'polygon-ecosystem-token:POL',
  'matic-network:MATIC',
  'tether:USDT',
  'usd-coin:USDC',
]);

export function isOfficialPaxiToken(input: { network?: string | null; contractAddress?: string | null; symbol?: string | null }): boolean {
  return input.network === 'bsc'
    && input.symbol?.toUpperCase() === 'PAXI'
    && input.contractAddress?.toLowerCase() === PAXI_BSC_CONTRACT;
}

/**
 * Identifies native assets and ERC-20-style contracts that ship in PAXI's
 * canonical registry. This uses exact network and contract keys, so a user
 * cannot receive a tick simply by importing a token called USDT or USDC.
 */
export function isTrustedAsset(input: VerifiableAsset): boolean {
  if (isOfficialPaxiToken(input)) return true;

  const symbol = input.symbol?.toUpperCase();
  const network = input.network?.toLowerCase();
  if (!symbol || !network) return false;

  if (input.isNative) return TRUSTED_NATIVE_ASSET_KEYS.has(`${symbol}:${network}`);
  if (!input.contractAddress) return false;
  return TRUSTED_TOKEN_CONTRACT_KEYS.has(`${symbol}:${network}:${input.contractAddress.toLowerCase()}`);
}

export function getTrustedAssetLabel(input: VerifiableAsset): string | null {
  if (!isTrustedAsset(input)) return null;
  return isOfficialPaxiToken(input) ? 'Official PAXI token' : 'Verified canonical asset';
}

/** Resolve the display logo from exact identity first, then the asset's stored URL. */
export function getAssetLogoUrl(input: VerifiableAsset): string | undefined {
  if (isOfficialPaxiToken(input)) return PAXI_LOGO_URL;
  return input.iconUrl ?? undefined;
}

/** Market-list payloads do not include contract platforms, so require the official PAXI identity fields. */
export function isOfficialPaxiMarketToken(input: { symbol?: string | null; name?: string | null }): boolean {
  return input.symbol?.toUpperCase() === 'PAXI' && input.name?.trim().toUpperCase() === 'PAXI';
}

/** Market listings have no contract address, so only exact provider IDs and symbols receive a tick. */
export function getTrustedMarketLabel(input: VerifiableMarketToken): string | null {
  if (isOfficialPaxiMarketToken(input)) return 'Official PAXI token';
  const marketKey = `${input.id?.trim().toLowerCase() ?? ''}:${input.symbol?.trim().toUpperCase() ?? ''}`;
  return TRUSTED_MARKET_IDENTITIES.has(marketKey) ? 'Verified canonical market asset' : null;
}

export interface AboutLink {
  label: string;
  url: string;
}

export const ABOUT_LINKS: AboutLink[] = [
  { label: 'Website', url: '#' },
  { label: 'X / Twitter', url: 'https://x.com/PaxiToken' },
  { label: 'Telegram', url: 'https://telegram.me/paxiofficial' },
];

export const SUPPORT_EMAIL = 'paxisupport@gmail.com';

export const TOKEN_STORY = `PAXI takes its name from "pax" - peace. Crypto wallets today force a tradeoff between control and convenience: self-custody usually means fumbling between chains, apps, and seed phrases, while convenience usually means giving up your keys to someone else. PAXI exists to close that gap - one wallet, multiple chains and multiple wallets side by side, without handing custody to anyone.

The WPAXI token carries that same idea into the network itself: a way to align everyone actually using the wallet - through fees, referrals, and governance - rather than just the earliest holders. It launches once the wallet itself is solid, not before - utility first, token second.`;
