import { describe, expect, it } from 'vitest';
import { filterLocalAssetsForSearch, filterProviderAssetsForSearch, type SearchMarketResult } from './assetSearch';
import type { AssetConfig } from '@/lib/wallet/chains';

const localAssets: AssetConfig[] = [
  {
    symbol: 'USDT',
    name: 'Tether USD',
    icon: '₮',
    network: 'ethereum',
    isNative: false,
    contractAddress: '0x1111111111111111111111111111111111111111',
    decimals: 6,
  },
  {
    symbol: 'USDT',
    name: 'Tether USD',
    icon: '₮',
    network: 'bsc',
    isNative: false,
    contractAddress: '0x2222222222222222222222222222222222222222',
    decimals: 6,
  },
];

describe('Assets search model', () => {
  it('requires a selected network and never mixes same-symbol assets across chains', () => {
    expect(filterLocalAssetsForSearch(localAssets, null, 'USDT')).toEqual([]);
    expect(filterLocalAssetsForSearch(localAssets, 'bsc', 'USDT')).toHaveLength(1);
    expect(filterLocalAssetsForSearch(localAssets, 'bsc', 'USDT')[0]?.network).toBe('bsc');
  });

  it('matches local assets by name or symbol within the selected network', () => {
    expect(filterLocalAssetsForSearch(localAssets, 'ethereum', 'tether')[0]?.contractAddress).toBe(
      '0x1111111111111111111111111111111111111111',
    );
    expect(filterLocalAssetsForSearch(localAssets, 'ethereum', '   ')).toEqual([]);
  });

  it('filters provider results by chain and removes canonical duplicates', () => {
    const results: SearchMarketResult[] = [
      {
        id: 'local-copy',
        chain: 'ethereum',
        contractAddress: '0x1111111111111111111111111111111111111111',
        symbol: 'USDT',
        name: 'Tether',
      },
      {
        id: 'bsc-result',
        chain: 'bsc',
        contractAddress: '0x3333333333333333333333333333333333333333',
        symbol: 'USDT',
        name: 'Tether USD',
      },
      {
        id: 'wrong-chain',
        chain: 'solana',
        contractAddress: 'mint',
        symbol: 'USDT',
        name: 'Solana Tether',
      },
    ];

    const matches = filterProviderAssetsForSearch(results, 'ethereum', 'USDT', localAssets);
    expect(matches).toEqual([]);
    expect(filterProviderAssetsForSearch(results, 'bsc', 'USDT', localAssets)[0]?.id).toBe('bsc-result');
  });

  it('prioritizes an exact contract query without changing chain scope', () => {
    const results: SearchMarketResult[] = [
      { id: 'other', chain: 'ethereum', contractAddress: '0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', symbol: 'TKN', name: 'Token' },
      { id: 'exact', chain: 'ethereum', contractAddress: '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', symbol: 'TKN', name: 'Token' },
    ];
    expect(filterProviderAssetsForSearch(results, 'ethereum', '0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', []).map((item) => item.id)).toEqual(['exact', 'other']);
  });
});
