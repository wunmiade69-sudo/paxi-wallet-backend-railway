import type { AssetConfig } from '@/lib/wallet/chains';
import { canonicalMarketIdentityKey, marketResultIdentityKey, matchesAssetSearchText } from '@/lib/marketIdentity';

export interface SearchMarketResult {
  id: string;
  chain?: string | null;
  contractAddress?: string | null;
  coinId?: string | null;
  symbol: string;
  name: string;
  image?: string | null;
}

/** Local assets are searchable only after a chain has been selected. */
export function filterLocalAssetsForSearch(
  assets: AssetConfig[],
  selectedNetwork: string | null,
  query: string,
): AssetConfig[] {
  const normalizedQuery = query.trim();
  if (!selectedNetwork || !normalizedQuery) return [];
  return assets.filter(
    (asset) => asset.network === selectedNetwork && matchesAssetSearchText(asset, normalizedQuery),
  );
}

/** Provider results are constrained to the selected chain and deduplicated by canonical identity. */
export function filterProviderAssetsForSearch(
  results: SearchMarketResult[],
  selectedNetwork: string | null,
  query: string,
  localAssets: AssetConfig[],
): SearchMarketResult[] {
  const normalizedQuery = query.trim();
  if (!selectedNetwork || !normalizedQuery) return [];

  const localIdentities = new Set(
    localAssets
      .filter((asset) => asset.contractAddress)
      .map((asset) => canonicalMarketIdentityKey(asset.network, asset.contractAddress!)),
  );
  const queryLower = normalizedQuery.toLowerCase();

  return results
    .filter((result) => result.chain === selectedNetwork)
    .filter((result) => {
      const identity = marketResultIdentityKey(result);
      return !identity || !localIdentities.has(identity);
    })
    .sort((a, b) => {
      const aExact = a.contractAddress?.toLowerCase() === queryLower ? 1 : 0;
      const bExact = b.contractAddress?.toLowerCase() === queryLower ? 1 : 0;
      return bExact - aExact;
    });
}
