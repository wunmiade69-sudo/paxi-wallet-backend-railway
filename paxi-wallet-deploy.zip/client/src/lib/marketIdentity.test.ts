import { describe, expect, it } from 'vitest';
import { canonicalMarketIdentityKey, marketResultIdentityKey, matchesAssetSearchText } from './marketIdentity';

describe('canonical market identity', () => {
  it('normalizes EVM contract casing but keeps chain context', () => {
    expect(canonicalMarketIdentityKey('ethereum', '0xAbC')).toBe('ethereum:0xabc');
    expect(canonicalMarketIdentityKey('bsc', '0xAbC')).toBe('bsc:0xabc');
    expect(canonicalMarketIdentityKey('solana', 'MintABC')).toBe('solana:MintABC');
  });

  it('does not deduplicate the same address across different chains', () => {
    expect(marketResultIdentityKey({ chain: 'ethereum', contractAddress: '0xABC' }))
      .not.toBe(marketResultIdentityKey({ chain: 'bsc', contractAddress: '0xABC' }));
  });

  it('matches names, symbols, and exact-address queries without symbol-only identity', () => {
    expect(matchesAssetSearchText({ name: 'Example Token', symbol: 'EXT', contractAddress: '0x1234' }, 'example')).toBe(true);
    expect(matchesAssetSearchText({ name: 'Example Token', symbol: 'EXT', contractAddress: '0x1234' }, '0x1234')).toBe(true);
    expect(matchesAssetSearchText({ name: 'Example Token', symbol: 'EXT', contractAddress: '0x1234' }, 'USDT')).toBe(false);
  });

  it('rejects empty and whitespace-only queries without fabricating matches', () => {
    const asset = { name: 'Example Token', symbol: 'EXT', contractAddress: '0x1234' };
    expect(matchesAssetSearchText(asset, '')).toBe(false);
    expect(matchesAssetSearchText(asset, '   ')).toBe(false);
  });

  it('handles malformed or incomplete assets safely', () => {
    expect(matchesAssetSearchText({}, 'token')).toBe(false);
    expect(matchesAssetSearchText({ symbol: 'EXT', name: null, contractAddress: null }, 'ext')).toBe(true);
    expect(matchesAssetSearchText({ symbol: 'EXT', name: null, contractAddress: null }, '0x')).toBe(false);
  });

  it('keeps duplicate symbols distinct through chain-plus-identifier identity', () => {
    const ethereumUsdc = marketResultIdentityKey({ chain: 'ethereum', contractAddress: '0xABC' });
    const bscUsdc = marketResultIdentityKey({ chain: 'bsc', contractAddress: '0xABC' });
    expect(ethereumUsdc).not.toBe(bscUsdc);
    expect(marketResultIdentityKey({ chain: 'unsupported-chain', contractAddress: 'Mint-1' })).toBe('unsupported-chain:Mint-1');
  });

  it('supports exact matches within a large result set without changing canonical identity', () => {
    const results = Array.from({ length: 2000 }, (_, index) => ({
      name: `Token ${index}`,
      symbol: index === 1999 ? 'TARGET' : `T${index}`,
      contractAddress: `0x${index.toString(16).padStart(40, '0')}`,
    }));
    expect(results.filter((asset) => matchesAssetSearchText(asset, 'TARGET'))).toHaveLength(1);
    expect(marketResultIdentityKey({ chain: 'ethereum', contractAddress: results[1999].contractAddress })).toContain('ethereum:0x');
  });
});
