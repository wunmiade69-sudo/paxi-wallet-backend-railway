import type { AssetConfig } from './wallet/chains';

const EVM_CHAINS = new Set(['ethereum', 'bsc', 'base', 'polygon', 'arbitrum']);

export interface MarketIdentityLike {
  chain?: string | null;
  contractAddress?: string | null;
  coinId?: string | null;
}

/** Canonical identity for a chain-specific asset. Symbols and names are never identity keys. */
export function canonicalMarketIdentityKey(chain: string, contractOrMint: string): string {
  const normalizedChain = chain.trim().toLowerCase();
  const normalizedIdentifier = EVM_CHAINS.has(normalizedChain)
    ? contractOrMint.trim().toLowerCase()
    : contractOrMint.trim();
  return `${normalizedChain}:${normalizedIdentifier}`;
}

export function assetIdentityKey(asset: Pick<AssetConfig, 'network' | 'contractAddress'>): string | null {
  return asset.contractAddress ? canonicalMarketIdentityKey(asset.network, asset.contractAddress) : null;
}

export function marketResultIdentityKey(result: MarketIdentityLike): string | null {
  return result.chain && result.contractAddress
    ? canonicalMarketIdentityKey(result.chain, result.contractAddress)
    : null;
}

export function matchesAssetSearchText(
  value: { symbol?: string | null; name?: string | null; contractAddress?: string | null },
  query: string,
): boolean {
  const q = query.trim().toLowerCase();
  if (!q) return false;
  return [value.symbol, value.name, value.contractAddress]
    .filter((part): part is string => Boolean(part))
    .some((part) => part.toLowerCase().includes(q));
}

export function shortenCanonicalIdentifier(identifier: string): string {
  return identifier.length > 14 ? `${identifier.slice(0, 6)}…${identifier.slice(-6)}` : identifier;
}
