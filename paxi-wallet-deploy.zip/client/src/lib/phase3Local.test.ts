import { describe, expect, it } from 'vitest';
import { getNotificationPreferences, notifyForPriceMovement, notifyForTransaction } from './phase3Local';

describe('transaction notification routing', () => {
  const base = {
    hash: '0xABC123',
    networkId: 'ethereum',
    type: 'send' as const,
    symbol: 'ETH',
    amount: '0.25',
  };

  it('creates a submitted notification for a real local broadcast event', () => {
    expect(notifyForTransaction({ ...base, status: 'submitted', source: 'local-wallet' })?.type).toBe('transaction-submitted');
  });

  it('routes confirmed and failed status transitions to their distinct event types', () => {
    expect(notifyForTransaction({ ...base, status: 'confirmed' })?.type).toBe('transaction-confirmed');
    expect(notifyForTransaction({ ...base, status: 'failed' })?.type).toBe('transaction-failed');
  });

  it('routes confirmed receives to incoming-transaction and keeps safe defaults in non-browser contexts', () => {
    expect(notifyForTransaction({ ...base, type: 'receive', status: 'confirmed' })?.type).toBe('incoming-transaction');
    expect(getNotificationPreferences().ecosystemAnnouncements).toBe(false);
  });

  it('does not create price alerts unless the user has enabled them', () => {
    expect(notifyForPriceMovement({ assetKey: 'ethereum:0xabc', symbol: 'TEST', currentPrice: 2 })).toBeNull();
  });
});
