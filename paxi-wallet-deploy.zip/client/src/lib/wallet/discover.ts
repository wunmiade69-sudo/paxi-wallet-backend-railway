import type { DiscoverCategory, DiscoverEntry, RiskStatus, VerificationStatus } from '@/lib/phase3Models';

/**
 * Discover data remains curated and client-side in this phase. The richer
 * fields make the catalog future-ready without implying that a listed dApp is
 * safe or that unavailable provider-backed categories contain live data.
 */
export interface DappEntry {
  id?: string;
  name: string;
  url: string;
  category: 'DEX' | 'NFT' | 'Bridge' | 'Aggregator' | 'Lending';
  description: string;
  featured?: boolean;
  supportedChains?: string[];
  verification?: VerificationStatus;
  risk?: RiskStatus;
  status?: 'available' | 'unavailable' | 'coming-soon';
}

export const CURATED_DAPPS: DappEntry[] = [
  { id: 'uniswap', name: 'Uniswap', url: 'https://app.uniswap.org', category: 'DEX', description: 'Leading Ethereum DEX', supportedChains: ['ethereum'], verification: 'unknown', risk: 'unknown', featured: true },
  { id: 'pancakeswap', name: 'PancakeSwap', url: 'https://pancakeswap.finance', category: 'DEX', description: 'Top DEX on BNB Chain', supportedChains: ['bsc'], verification: 'unknown', risk: 'unknown', featured: true },
  { id: 'curve', name: 'Curve', url: 'https://curve.fi', category: 'DEX', description: 'Stablecoin & pegged-asset swaps', supportedChains: ['ethereum', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: '1inch', name: '1inch', url: 'https://app.1inch.io', category: 'Aggregator', description: 'DEX aggregator, best-price routing', supportedChains: ['ethereum', 'bsc', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: 'aave', name: 'Aave', url: 'https://app.aave.com', category: 'Lending', description: 'Borrow & lend across chains', supportedChains: ['ethereum', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: 'opensea', name: 'OpenSea', url: 'https://opensea.io', category: 'NFT', description: 'NFT marketplace', supportedChains: ['ethereum', 'polygon', 'arbitrum'], verification: 'unknown', risk: 'unknown' },
  { id: 'blur', name: 'Blur', url: 'https://blur.io', category: 'NFT', description: 'NFT marketplace for pro traders', supportedChains: ['ethereum'], verification: 'unknown', risk: 'unknown' },
  { id: 'jumper', name: 'Jumper (LI.FI)', url: 'https://jumper.exchange', category: 'Bridge', description: 'Cross-chain bridge aggregator', supportedChains: ['ethereum', 'bsc', 'polygon', 'arbitrum', 'solana'], verification: 'unknown', risk: 'unknown', featured: true },
];

const CATEGORY_MAP: Record<DappEntry['category'], DiscoverCategory> = {
  DEX: 'defi',
  Aggregator: 'exchanges',
  Lending: 'lending',
  NFT: 'nft',
  Bridge: 'defi',
};

export function toDiscoverEntry(dapp: DappEntry): DiscoverEntry {
  let domain = '';
  try {
    domain = new URL(dapp.url).hostname.replace(/^www\./, '');
  } catch {
    // Curated URLs are validated at authoring time; empty domain is honest if one is malformed.
  }
  return {
    id: dapp.id ?? dapp.url,
    name: dapp.name,
    url: dapp.url,
    description: dapp.description,
    category: CATEGORY_MAP[dapp.category],
    supportedChains: dapp.supportedChains ?? [],
    domain,
    verification: dapp.verification ?? 'unknown',
    risk: dapp.risk ?? 'unknown',
    status: dapp.status ?? 'available',
    featured: dapp.featured,
    source: 'curated',
  };
}

/** Logo source for every dapp, curated or user-pasted alike. */
export function faviconFor(url: string, size: 64 | 128 = 64): string {
  try {
    const { hostname } = new URL(url);
    return `https://www.google.com/s2/favicons?domain=${hostname}&sz=${size}`;
  } catch {
    return '';
  }
}

export interface SavedLink {
  id: string;
  url: string;
  label: string;
  savedAt: number;
}

const RECENTS_KEY = 'paxi-discover-recents';
const FAVORITES_KEY = 'paxi-discover-favorites';
const MAX_RECENTS = 12;

function labelFromUrl(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

/** Accepts a bare domain or a full URL and normalizes to https://... */
export function normalizeUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) throw new Error('Paste or type a link first.');
  const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    throw new Error("That doesn't look like a valid link.");
  }
  if (!parsed.hostname.includes('.')) throw new Error("That doesn't look like a valid link.");
  return parsed.toString();
}

function readList(key: string): SavedLink[] {
  try {
    const raw = JSON.parse(localStorage.getItem(key) ?? '[]');
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

export function getRecents(): SavedLink[] { return readList(RECENTS_KEY); }
export function getFavorites(): SavedLink[] { return readList(FAVORITES_KEY); }
export function isFavorite(url: string): boolean { return getFavorites().some((l) => l.url === url); }

export function addRecent(url: string): void {
  const existing = getRecents().filter((l) => l.url !== url);
  const entry: SavedLink = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, url, label: labelFromUrl(url), savedAt: Date.now() };
  localStorage.setItem(RECENTS_KEY, JSON.stringify([entry, ...existing].slice(0, MAX_RECENTS)));
}

export function toggleFavorite(url: string): boolean {
  const favorites = getFavorites();
  const exists = favorites.find((l) => l.url === url);
  if (exists) {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites.filter((l) => l.url !== url)));
    return false;
  }
  const entry: SavedLink = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, url, label: labelFromUrl(url), savedAt: Date.now() };
  localStorage.setItem(FAVORITES_KEY, JSON.stringify([entry, ...favorites]));
  return true;
}

export function removeRecent(id: string): void {
  localStorage.setItem(RECENTS_KEY, JSON.stringify(getRecents().filter((l) => l.id !== id)));
}
