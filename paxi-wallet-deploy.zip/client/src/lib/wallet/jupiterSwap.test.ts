import { afterEach, describe, expect, it, vi } from 'vitest';
import { getSolanaSwapQuote, SOL_TREASURY_ADDRESS } from './jupiterSwap';
import type { AssetConfig } from './chains';

const sol: AssetConfig = {
  symbol: 'SOL',
  name: 'Solana',
  icon: '◎',
  network: 'solana',
  isNative: true,
  decimals: 9,
};

const usdc: AssetConfig = {
  symbol: 'USDC',
  name: 'USD Coin',
  icon: '$',
  network: 'solana',
  isNative: false,
  contractAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  decimals: 6,
};

describe('Jupiter Solana execution boundary', () => {
  afterEach(() => vi.restoreAllMocks());

  it('does not request or report a Solana platform fee without a treasury address', async () => {
    expect(SOL_TREASURY_ADDRESS).toBe('');
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({
      inAmount: '1000000000',
      outAmount: '150000000',
      otherAmountThreshold: '148500000',
      routePlan: [{ swapInfo: { label: 'Mock route' } }],
    }), { status: 200, headers: { 'content-type': 'application/json' } }));

    const quote = await getSolanaSwapQuote({
      fromAsset: sol,
      toAsset: usdc,
      amount: '1',
      slippageBps: 100,
    });

    const requestedUrl = String(fetchMock.mock.calls[0]?.[0]);
    expect(requestedUrl).not.toContain('platformFeeBps');
    expect(quote.feeBps).toBe(0);
    expect(quote.feeAmountFormatted).toBe('0');
  });

  it('rejects an invalid or empty Jupiter route instead of creating an executable quote', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({ routePlan: [] }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    }));

    await expect(getSolanaSwapQuote({
      fromAsset: sol,
      toAsset: usdc,
      amount: '1',
    })).rejects.toThrow('invalid or unavailable Solana route');
  });

  it('does not report success when Jupiter times out or the provider rejects the request', async () => {
    vi.spyOn(globalThis, 'fetch').mockRejectedValue(new Error('request timed out'));

    await expect(getSolanaSwapQuote({
      fromAsset: sol,
      toAsset: usdc,
      amount: '1',
    })).rejects.toThrow('request timed out');
  });
});

