/**
 * Real transaction signing + broadcast for EVM-family assets, using the
 * wallet's own private key (derived on-the-fly from the unlocked mnemonic,
 * never persisted) and a public RPC endpoint. This sends an actual
 * on-chain transaction - there is no test/sandbox mode here, so amount and
 * recipient should always be double-checked, exactly like any real wallet.
 *
 * sendSolanaAsset below is the same idea for SOL/SPL token transfers.
 * Bitcoin sending is implemented in bitcoin.ts with its own UTXO-based transaction
 * builder and broadcast path; it intentionally remains separate from account-based sends.
 */
import { Contract, JsonRpcProvider, parseUnits } from 'ethers';
import { NETWORKS, type AssetConfig } from './chains';
import { walletFromMnemonic, deriveSolanaKeypair } from './engine';

const ERC20_TRANSFER_ABI = ['function transfer(address to, uint256 amount) returns (bool)'];

export async function sendEvmAsset(params: {
  mnemonic: string;
  asset: AssetConfig;
  toAddress: string;
  amount: string; // human units, e.g. "0.5"
}): Promise<{ hash: string; explorerUrl?: string }> {
  const { asset } = params;
  const network = NETWORKS[asset.network];
  if (network.chainType !== 'evm') throw new Error(`${asset.symbol} sending is not yet supported`);
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);
  if (!Number.isFinite(Number(params.amount)) || Number(params.amount) <= 0) throw new Error('Amount must be greater than zero');

  const provider = new JsonRpcProvider(network.rpcUrl);
  const signer = walletFromMnemonic(params.mnemonic).connect(provider);
  const amountUnits = parseUnits(params.amount, asset.decimals);

  let tx;
  if (asset.isNative) {
    tx = await signer.sendTransaction({ to: params.toAddress, value: amountUnits });
  } else if (asset.contractAddress) {
    const contract = new Contract(asset.contractAddress, ERC20_TRANSFER_ABI, signer);
    tx = await contract.transfer(params.toAddress, amountUnits);
  } else {
    throw new Error('Asset is missing a contract address');
  }

  return { hash: tx.hash, explorerUrl: network.explorerTx?.(tx.hash) };
}

export async function sendSolanaAsset(params: {
  mnemonic: string;
  asset: AssetConfig;
  toAddress: string;
  amount: string; // human units, e.g. "0.5"
}): Promise<{ hash: string; explorerUrl?: string }> {
  const { asset } = params;
  const network = NETWORKS[asset.network];
  if (network.chainType !== 'sol') throw new Error(`${asset.symbol} sending is not supported on Solana send path`);
  if (!network.rpcUrl) throw new Error(`${network.label} RPC is not configured yet`);
  if (!Number.isFinite(Number(params.amount)) || Number(params.amount) <= 0) throw new Error('Amount must be greater than zero');

  const {
    Connection,
    PublicKey,
    SystemProgram,
    Transaction,
    sendAndConfirmTransaction,
    LAMPORTS_PER_SOL,
  } = await import('@solana/web3.js');

  const connection = new Connection(network.rpcUrl, 'confirmed');
  const keypair = deriveSolanaKeypair(params.mnemonic);
  const toPubkey = new PublicKey(params.toAddress);

  let signature: string;

  if (asset.isNative) {
    const lamports = Math.round(Number(params.amount) * LAMPORTS_PER_SOL);
    const balance = await connection.getBalance(keypair.publicKey);
    if (lamports > balance) throw new Error('Insufficient SOL balance');
    const tx = new Transaction().add(
      SystemProgram.transfer({ fromPubkey: keypair.publicKey, toPubkey, lamports }),
    );
    signature = await sendAndConfirmTransaction(connection, tx, [keypair]);
  } else if (asset.contractAddress) {
    const {
      getOrCreateAssociatedTokenAccountSafe,
      createTransferCheckedInstructionSafe,
      getMintSafe,
    } = await import('./solanaSplSafe');

    const mint = new PublicKey(asset.contractAddress);
    const mintInfo = await getMintSafe(connection, mint);

    const fromAta = await getOrCreateAssociatedTokenAccountSafe(connection, keypair, mint, keypair.publicKey);
    const toAta = await getOrCreateAssociatedTokenAccountSafe(connection, keypair, mint, toPubkey);

    const amountUnits = BigInt(Math.round(Number(params.amount) * 10 ** mintInfo.decimals));
    if (amountUnits <= 0n) throw new Error('Amount is too small for the token decimals');
    if (amountUnits > fromAta.amount) throw new Error(`Insufficient ${asset.symbol} balance`);
    const tx = new Transaction().add(
      createTransferCheckedInstructionSafe(
        fromAta.address,
        mint,
        toAta.address,
        keypair.publicKey,
        amountUnits,
        mintInfo.decimals,
      ),
    );
    signature = await sendAndConfirmTransaction(connection, tx, [keypair]);
  } else {
    throw new Error('Asset is missing a contract (mint) address');
  }

  return { hash: signature, explorerUrl: network.explorerTx?.(signature) };
}
