/**
 * Token security/holder-concentration checks via GoPlus Security's public
 * Token Security API - free, open, no account or key required for this
 * volume of use (it's the same open dataset DexScreener itself licenses
 * for its own token-safety badges).
 *
 * The `holders` array field names below follow GoPlus's documented
 * schema. If GoPlus ever changes that shape, this fails closed (returns
 * null / omits the field) rather than silently showing a wrong number -
 * same "don't fake it" rule the rest of the price/stats code follows.
 */

const GOPLUS_API = 'https://api.gopluslabs.io/api/v1/token_security';

// Our internal network id -> GoPlus's numeric chain_id.
const GOPLUS_CHAIN_ID: Record<string, string> = {
  ethereum: '1',
  bsc: '56',
};

interface GoPlusHolder {
  address: string;
  percent: string; // decimal fraction as a string, e.g. "0.05" = 5%
  tag?: string;
}

interface GoPlusTokenRaw {
  holder_count?: string;
  holders?: GoPlusHolder[];
  lp_holder_count?: string;
  is_open_source?: string;
  is_honeypot?: string;
  is_mintable?: string;
  is_blacklisted?: string;
  is_proxy?: string;
  buy_tax?: string;
  sell_tax?: string;
  owner_percent?: string;
}

export interface TokenSecurity {
  holderCount: number | null;
  top10HolderPct: number | null;
  lpHolderCount: number | null;
  isOpenSource: boolean | null;
  isHoneypot: boolean | null;
  isMintable: boolean | null;
  hasBlacklistFn: boolean | null; // the contract CAN blacklist addresses - not that this address is blacklisted
  isProxy: boolean | null;
  buyTaxPct: number | null;
  sellTaxPct: number | null;
  ownerPct: number | null;
}

function toBool(v: string | undefined): boolean | null {
  if (v === '1') return true;
  if (v === '0') return false;
  return null;
}

function toPct(v: string | undefined): number | null {
  const n = v ? Number(v) : NaN;
  return Number.isFinite(n) ? n * 100 : null;
}

export async function fetchTokenSecurity(networkId: string, contractAddress: string): Promise<TokenSecurity | null> {
  const chainId = GOPLUS_CHAIN_ID[networkId];
  if (!chainId) return null;
  const lowerAddress = contractAddress.toLowerCase();
  try {
    const url = `${GOPLUS_API}/${chainId}?contract_addresses=${lowerAddress}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`GoPlus returned ${res.status}`);
    const data: { code: number; result: Record<string, GoPlusTokenRaw> } = await res.json();
    const raw = data.result?.[lowerAddress];
    if (!raw) return null;

    let top10Pct: number | null = null;
    if (Array.isArray(raw.holders) && raw.holders.length > 0) {
      const sum = raw.holders.slice(0, 10).reduce((acc, h) => acc + (Number(h.percent) || 0), 0);
      top10Pct = sum * 100;
    }

    return {
      holderCount: raw.holder_count ? Number(raw.holder_count) : null,
      top10HolderPct: top10Pct,
      lpHolderCount: raw.lp_holder_count ? Number(raw.lp_holder_count) : null,
      isOpenSource: toBool(raw.is_open_source),
      isHoneypot: toBool(raw.is_honeypot),
      isMintable: toBool(raw.is_mintable),
      hasBlacklistFn: toBool(raw.is_blacklisted),
      isProxy: toBool(raw.is_proxy),
      buyTaxPct: toPct(raw.buy_tax),
      sellTaxPct: toPct(raw.sell_tax),
      ownerPct: toPct(raw.owner_percent),
    };
  } catch (err) {
    console.warn(`GoPlus security lookup failed for ${contractAddress}:`, err);
    return null;
  }
}
