/**
 * Local transaction history.
 *
 * This is the wallet's own log: every Send/Swap/Bridge this app broadcasts
 * gets recorded here the moment it's submitted, keyed off the real tx hash,
 * starting in `pending` status. On its own this only covers "what did I
 * just do in this app" - it can't know about transactions made outside it
 * (like a plain receive from someone else, or activity from before this
 * device had the wallet installed).
 *
 * For the full picture - real confirmations, receives, fees - this is
 * merged with on-chain data at read time. See `txIndexer.ts`
 * (`getFullHistory`), which resolves each pending local record's real
 * status via RPC and unions in on-chain history from a block explorer API.
 * `getTxRecords` below is still useful on its own for "what this app has
 * done" without a network round-trip (e.g. instant paint before the merged
 * fetch resolves).
 */

import { notifyForTransaction } from '../phase3Local';

export type TxType = 'send' | 'receive' | 'swap' | 'bridge' | 'create';
export type TxStatus = 'pending' | 'confirmed' | 'failed';

export interface TxRecord {
  id: string;
  type: TxType;
  networkId: string;
  hash: string;
  explorerUrl?: string;
  fromSymbol: string;
  fromAmount: string;
  toSymbol?: string; // swap/bridge only
  toAmount?: string; // swap/bridge only, estimated
  toNetworkId?: string; // bridge only, destination chain
  counterparty?: string; // send: recipient address, receive: sender address
  timestamp: number;
  status?: TxStatus; // undefined is treated as 'confirmed' (older records predate this field)
  feeAmount?: string; // network fee actually paid, once known
  feeSymbol?: string;
  source?: 'local' | 'onchain'; // local = broadcast by this app; onchain = discovered via indexer (e.g. a receive)
}

const KEY = 'paxi-tx-history';
const MAX_RECORDS = 200;

export function getTxRecords(): TxRecord[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    if (!Array.isArray(raw)) return [];
    return raw.sort((a: TxRecord, b: TxRecord) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export function addTxRecord(record: Omit<TxRecord, 'id' | 'timestamp' | 'source'> & { status?: TxStatus }): TxRecord {
  const full: TxRecord = {
    status: 'pending',
    ...record,
    source: 'local',
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: Date.now(),
  };
  const existing = getTxRecords();
  existing.unshift(full);
  localStorage.setItem(KEY, JSON.stringify(existing.slice(0, MAX_RECORDS)));
  if (full.type !== 'create') {
    const symbol = full.type === 'swap' || full.type === 'bridge' ? full.toSymbol ?? full.fromSymbol : full.fromSymbol;
    const amount = full.type === 'swap' || full.type === 'bridge' ? full.toAmount ?? full.fromAmount : full.fromAmount;
    notifyForTransaction({ hash: full.hash, networkId: full.networkId, type: full.type, status: full.status === 'pending' ? 'submitted' : 'confirmed', symbol, amount, timestamp: full.timestamp, source: 'local-wallet' });
  }
  if (full.status === 'confirmed' && full.type !== 'create') {
    const symbol = full.type === 'swap' || full.type === 'bridge' ? full.toSymbol ?? full.fromSymbol : full.fromSymbol;
    const amount = full.type === 'swap' || full.type === 'bridge' ? full.toAmount ?? full.fromAmount : full.fromAmount;
    notifyForTransaction({ hash: full.hash, networkId: full.networkId, type: full.type, status: 'confirmed', symbol, amount, timestamp: full.timestamp });
  }
  return full;
}

/** Patches a previously-logged record in place (used to persist resolved pending -> confirmed/failed status + fee). */
export function updateTxRecord(hash: string, patch: Partial<Pick<TxRecord, 'status' | 'feeAmount' | 'feeSymbol'>>) {
  const existing = getTxRecords();
  const idx = existing.findIndex((r) => r.hash.toLowerCase() === hash.toLowerCase());
  if (idx === -1) return;
  const previous = existing[idx];
  existing[idx] = { ...previous, ...patch };
  localStorage.setItem(KEY, JSON.stringify(existing.slice(0, MAX_RECORDS)));
  if (patch.status && patch.status !== 'pending' && patch.status !== previous.status && previous.type !== 'create') {
    const symbol = previous.type === 'swap' || previous.type === 'bridge' ? previous.toSymbol ?? previous.fromSymbol : previous.fromSymbol;
    const amount = previous.type === 'swap' || previous.type === 'bridge' ? previous.toAmount ?? previous.fromAmount : previous.fromAmount;
    notifyForTransaction({ hash: previous.hash, networkId: previous.networkId, type: previous.type, status: patch.status, symbol, amount, timestamp: previous.timestamp, source: 'local-wallet' });
  }
}

export function clearTxRecords() {
  localStorage.removeItem(KEY);
}
