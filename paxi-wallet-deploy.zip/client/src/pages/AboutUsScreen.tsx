import { ArrowLeft, ExternalLink, Mail } from 'lucide-react';
import { toast } from 'sonner';
import { ABOUT_LINKS, APP_BUILD_NAME, APP_VERSION, SUPPORT_EMAIL, TOKEN_STORY } from '@/lib/appInfo';

interface AboutUsScreenProps {
  onBack: () => void;
}

export default function AboutUsScreen({ onBack }: AboutUsScreenProps) {
  const openLink = (url: string, label: string) => {
    if (url === '#') {
      toast.info(`${label} link isn't set up yet.`);
      return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">About Us</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div className="glass-card text-center py-8">
          <h2 className="text-3xl font-bold text-accent mb-1">PAXI</h2>
          <p className="text-sm text-muted-foreground">Version {APP_VERSION}</p>
          <p className="text-xs text-muted-foreground mt-1">{APP_BUILD_NAME}</p>
        </div>

        <div className="glass-card space-y-3">
          <h3 className="text-sm font-semibold text-foreground">Why PAXI</h3>
          {TOKEN_STORY.split('\n\n').map((paragraph, i) => (
            <p key={i} className="text-sm text-muted-foreground leading-relaxed">
              {paragraph}
            </p>
          ))}
        </div>

        <div className="glass-card space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Security, privacy & legal</h3>
          <div className="space-y-3 text-xs text-muted-foreground leading-relaxed">
            <p><span className="font-semibold text-foreground">Security:</span> PAXI Wallet is non-custodial. Recovery phrases and private keys remain on this device and are not sent to support, market providers, dApps, or AI services.</p>
            <p><span className="font-semibold text-foreground">Privacy:</span> Wallet activity is kept local unless a user explicitly initiates a provider, blockchain, support, or dApp request. Provider availability and privacy policies may vary.</p>
            <p><span className="font-semibold text-foreground">Terms:</span> This wallet software is provided for self-custody use. Users must independently review addresses, networks, fees, approvals, and transaction details before signing.</p>
            <p><span className="font-semibold text-foreground">Licenses:</span> PAXI Wallet includes open-source dependencies. The complete dependency license inventory is maintained with the source distribution.</p>
          </div>
        </div>

        <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
          {ABOUT_LINKS.map((link) => (
            <button
              key={link.label}
              onClick={() => openLink(link.url, link.label)}
              className="w-full flex items-center justify-between py-3.5 px-4 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all"
            >
              <span className="text-sm text-foreground">{link.label}</span>
              <span className="w-7 h-7 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                <ExternalLink className="w-3.5 h-3.5 text-accent" />
              </span>
            </button>
          ))}
          <button
            onClick={() => (window.location.href = `mailto:${SUPPORT_EMAIL}`)}
            className="w-full flex items-center justify-between py-3.5 px-4 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all"
          >
            <span className="text-sm text-foreground">Contact Support</span>
            <span className="w-7 h-7 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
              <Mail className="w-3.5 h-3.5 text-accent" />
            </span>
          </button>
        </div>

        <p className="text-xs text-muted-foreground text-center px-4">
          PAXI Wallet is a non-custodial wallet - your keys never leave this device. Nobody, including us, can
          recover your funds if your recovery phrase is lost.
        </p>
      </div>
    </div>
  );
}
