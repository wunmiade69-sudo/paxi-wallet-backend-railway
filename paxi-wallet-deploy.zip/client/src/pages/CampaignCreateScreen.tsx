import { useState } from 'react';
import { ArrowLeft, CheckCircle2, ImagePlus } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

interface CampaignCreateScreenProps {
  onBack: () => void;
  onViewCampaigns: () => void;
}

function multiplyUsdByWhole(value: string, multiplier: string): string {
  if (!/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/.test(value) || !/^\d{1,10}$/.test(multiplier)) return "0";
  const [whole, fraction = ""] = value.split(".");
  const scaled = BigInt(`${whole}${fraction}`) * BigInt(multiplier);
  const scale = 10n ** BigInt(fraction.length);
  const scaledWhole = scaled / scale;
  const scaledFraction = (scaled % scale).toString().padStart(fraction.length, "0").replace(/0+$/, "");
  return scaledFraction ? `${scaledWhole}.${scaledFraction}` : scaledWhole.toString();
}

export default function CampaignCreateScreen({ onBack, onViewCampaigns }: CampaignCreateScreenProps) {
  const { data: myListings, isLoading: loadingListings } = trpc.listings.myListings.useQuery();
  const treasury = trpc.fees.getTreasury.useQuery();
  const verifiedListings = (myListings ?? []).filter((l) => l.status === 'verified');

  const [listingId, setListingId] = useState<number | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [banner, setBanner] = useState<string | null>(null);
  const [bannerPreview, setBannerPreview] = useState<string | null>(null);
  const [icon, setIcon] = useState<string | null>(null);
  const [iconPreview, setIconPreview] = useState<string | null>(null);
  const [website, setWebsite] = useState('');
  const [twitter, setTwitter] = useState('');
  const [telegram, setTelegram] = useState('');
  const [startAt, setStartAt] = useState('');
  const [endAt, setEndAt] = useState('');
  const [minTokenAmount, setMinTokenAmount] = useState('');
  const [rewardAmount, setRewardAmount] = useState('');
  const [rewardValueUsd, setRewardValueUsd] = useState('');
  const [maxWinners, setMaxWinners] = useState('100');
  const [createdCampaignId, setCreatedCampaignId] = useState<number | null>(null);
  const [poolTxHash, setPoolTxHash] = useState('');
  const [submittedForReview, setSubmittedForReview] = useState(false);
  const [requiredPoolAmountUsd, setRequiredPoolAmountUsd] = useState<string | null>(null);

  const selectedListing = verifiedListings.find((l) => l.id === listingId);

  const createCampaign = trpc.campaigns.create.useMutation({
    onSuccess: (res) => {
      setCreatedCampaignId(res.id);
      setRequiredPoolAmountUsd(res.poolRequiredAmountUsd);
      toast.success('Campaign created as a private draft. Fund the pool to submit it for review.');
    },
    onError: (err) => toast.error(err.message),
  });

  const fundPool = trpc.campaigns.fundPool.useMutation({
    onSuccess: () => setSubmittedForReview(true),
    onError: (err) => toast.error(err.message),
  });

  const poolAmountUsd = multiplyUsdByWhole(rewardValueUsd.trim(), maxWinners.trim());

  const canCreate =
    selectedListing &&
    title.trim().length > 0 &&
    minTokenAmount.trim().length > 0 &&
    rewardAmount.trim().length > 0 &&
    rewardValueUsd.trim().length > 0 &&
    Number(maxWinners) > 0 &&
    Boolean(banner) &&
    Boolean(icon) &&
    Boolean(startAt) &&
    Boolean(endAt) &&
    new Date(endAt) > new Date(startAt);

  const handleImage = (file: File | undefined, kind: 'banner' | 'icon') => {
    if (!file) return;
    const maximum = kind === 'banner' ? 5 * 1024 * 1024 : 1 * 1024 * 1024;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > maximum) {
      toast.error(`${kind === 'banner' ? 'Campaign banner' : 'Campaign icon'} must be a PNG, JPEG, or WebP smaller than ${maximum / 1024 / 1024}MB.`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      if (kind === 'banner') { setBanner(dataUrl); setBannerPreview(dataUrl); }
      else { setIcon(dataUrl); setIconPreview(dataUrl); }
    };
    reader.readAsDataURL(file);
  };

  const handleCreate = () => {
    if (!selectedListing || !banner || !icon) return;
    createCampaign.mutate({
      listingId: selectedListing.id,
      title: title.trim(),
      description: description.trim() || undefined,
      banner,
      icon,
      website: website.trim() || undefined,
      socials: { ...(twitter.trim() && { twitter: twitter.trim() }), ...(telegram.trim() && { telegram: telegram.trim() }) },
      minTokenAmount: minTokenAmount.trim(),
      taskTokenSymbol: selectedListing.symbol,
      taskTokenContractAddress: selectedListing.contractAddress,
      taskTokenNetwork: selectedListing.network,
      rewardAmount: rewardAmount.trim(),
      rewardValueUsd: rewardValueUsd.trim(),
      rewardTokenSymbol: selectedListing.symbol,
      rewardTokenContractAddress: selectedListing.contractAddress,
      rewardNetwork: selectedListing.network,
      maxWinners: Number(maxWinners),
      startAt: new Date(startAt).toISOString(),
      endAt: new Date(endAt).toISOString(),
    });
  };

  const handleFund = () => {
    if (!createdCampaignId) return;
    fundPool.mutate({ campaignId: createdCampaignId, feeTxHash: poolTxHash.trim() });
  };

  if (submittedForReview) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="max-w-md text-center space-y-4">
          <CheckCircle2 className="w-14 h-14 text-accent mx-auto" />
          <h1 className="text-xl font-bold text-foreground">Campaign submitted for review</h1>
          <p className="text-sm text-muted-foreground">
            Your reward pool was verified. PAXI will review the campaign details and assets before it becomes visible in Discover.
          </p>
          <button
            onClick={onViewCampaigns}
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm px-6 py-3 rounded-lg transition-all active:scale-[0.98]"
          >
            View My Campaigns
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Start a Campaign</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        {!createdCampaignId ? (
          <>
            {loadingListings ? (
              <p className="text-sm text-muted-foreground">Loading your listings…</p>
            ) : verifiedListings.length === 0 ? (
              <div className="glass-card p-4">
                <p className="text-sm text-foreground font-medium">No verified listing yet</p>
                <p className="text-xs text-muted-foreground mt-1">
                  You need a verified Discover listing before you can run a campaign. Submit and get approved first.
                </p>
              </div>
            ) : (
              <Field label="Which token is this campaign for?">
                <select
                  value={listingId ?? ''}
                  onChange={(e) => setListingId(Number(e.target.value))}
                  className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground outline-none focus:border-accent/50"
                >
                  <option value="" disabled>
                    Select a verified token
                  </option>
                  {verifiedListings.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.symbol} — {l.name}
                    </option>
                  ))}
                </select>
              </Field>
            )}

            <Field label="Campaign title">
              <TextInput value={title} onChange={setTitle} placeholder="Trade $50 of PAXI, win $1.50 back" />
            </Field>

            <Field label="Description (optional)">
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Explain the promo to your community..."
                className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50 resize-none"
              />
            </Field>

            <div className="space-y-3">
              <p className="px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Campaign branding</p>
              <ImageUpload label="Campaign banner · recommended 1200 × 630 · max 5MB" preview={bannerPreview} onFile={(file) => handleImage(file, 'banner')} wide />
              <ImageUpload label="Campaign icon · square · max 1MB" preview={iconPreview} onFile={(file) => handleImage(file, 'icon')} />
              <p className="text-xs text-muted-foreground">Assets remain private until an administrator approves this funded campaign.</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Start date"><input type="datetime-local" value={startAt} onChange={(event) => setStartAt(event.target.value)} className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3 text-sm text-foreground outline-none focus:border-accent/50" /></Field>
              <Field label="End date"><input type="datetime-local" value={endAt} onChange={(event) => setEndAt(event.target.value)} className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3 text-sm text-foreground outline-none focus:border-accent/50" /></Field>
            </div>

            <div className="space-y-3">
              <p className="px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Project links</p>
              <TextInput value={website} onChange={setWebsite} placeholder="Website URL (optional)" />
              <TextInput value={twitter} onChange={setTwitter} placeholder="Twitter/X URL (optional)" />
              <TextInput value={telegram} onChange={setTelegram} placeholder="Telegram URL (optional)" />
            </div>

            <Field label={`Task: minimum ${selectedListing?.symbol ?? 'token'} amount to trade inside Paxi`}>
              <TextInput value={minTokenAmount} onChange={setMinTokenAmount} placeholder="e.g. 50" />
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Reward per winner (tokens)">
                <TextInput value={rewardAmount} onChange={setRewardAmount} placeholder="e.g. 3" />
              </Field>
              <Field label="Reward value (USD, for escrow)">
                <TextInput value={rewardValueUsd} onChange={setRewardValueUsd} placeholder="1.50" />
              </Field>
            </div>

            <Field label="Max winners (first N)">
              <TextInput value={maxWinners} onChange={setMaxWinners} placeholder="100" />
            </Field>

            {Number(poolAmountUsd) > 0 && (
              <div className="glass-card p-4">
                <p className="text-sm text-foreground">
                  Total pool to escrow: <span className="font-semibold">${Number(poolAmountUsd).toFixed(2)}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {maxWinners} winners × ${rewardValueUsd || '0'} each
                </p>
              </div>
            )}

            <button
              onClick={handleCreate}
              disabled={!canCreate || createCampaign.isPending}
              className="w-full bg-accent hover:bg-accent/90 disabled:opacity-40 disabled:cursor-not-allowed text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              {createCampaign.isPending ? 'Creating private draft…' : 'Create Campaign Draft'}
            </button>
          </>
        ) : (
          <div className="space-y-4">
            <div className="glass-card p-4 space-y-2">
              <p className="text-sm text-foreground font-medium">Fund the reward pool to submit for review</p>
              <p className="text-xs text-muted-foreground break-all">
                Send <span className="text-foreground font-semibold">${Number(requiredPoolAmountUsd ?? poolAmountUsd).toFixed(2)}</span> in USDT/USDC
                to Paxi's address, then paste the transaction hash:
                <br />
                <span className="text-foreground font-mono">{treasury.data?.treasuryAddress ?? 'Loading…'}</span>
              </p>
            </div>
            <Field label="Pool funding transaction hash">
              <TextInput value={poolTxHash} onChange={setPoolTxHash} placeholder="0x..." />
            </Field>
            <button
              onClick={handleFund}
              disabled={poolTxHash.trim().length === 0 || fundPool.isPending}
              className="w-full bg-accent hover:bg-accent/90 disabled:opacity-40 disabled:cursor-not-allowed text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-all active:scale-[0.98]"
            >
              {fundPool.isPending ? 'Verifying payment…' : 'Confirm Funding & Submit for Review'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs font-medium text-muted-foreground px-1">{label}</p>
      {children}
    </div>
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50"
    />
  );
}

function ImageUpload({ label, preview, onFile, wide = false }: { label: string; preview: string | null; onFile: (file: File | undefined) => void; wide?: boolean }) {
  return (
    <label className={`relative flex cursor-pointer items-center justify-center overflow-hidden rounded-xl border border-dashed border-border bg-secondary ${wide ? 'min-h-32' : 'h-20 w-20'}`}>
      {preview ? <img src={preview} alt="Campaign asset preview" className="h-full w-full object-cover" /> : <span className="flex flex-col items-center gap-1 px-4 text-center text-xs text-muted-foreground"><ImagePlus className="h-5 w-5 text-accent" />{wide ? label : 'Icon'}</span>}
      {preview && <span className="absolute inset-x-0 bottom-0 bg-black/65 px-2 py-1 text-center text-[10px] text-white">Replace</span>}
      <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(event) => onFile(event.target.files?.[0])} />
    </label>
  );
}
