import { useEffect, useState } from 'react';
import { ArrowLeft, Upload, AlertTriangle, Circle, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { getStoredAddress, getUnlockedMnemonic } from '@/lib/wallet/vault';
import { NETWORKS } from '@/lib/wallet/chains';
import {
  createTokenOnChain,
  payCreationFee,
  isCreationSupported,
  estimateTokenCreationGasFee,
  CREATION_FEE_USD,
} from '@/lib/wallet/tokenFactory';
import { describeChainError } from '@/lib/wallet/chainErrors';
import TransactionAuthSheet from '@/components/TransactionAuthSheet';
import TransactionReceipt from '@/components/TransactionReceipt';
import { addTxRecord, type TxRecord } from '@/lib/wallet/txHistory';

interface CreateTokenScreenProps {
  onBack: () => void;
}

const NETWORK = 'bsc'; // only network wired up for creation right now - see tokenFactory.ts
const network = NETWORKS[NETWORK];

type Phase = 'form' | 'review' | 'approving' | 'creating' | 'saving' | 'done';

export default function CreateTokenScreen({ onBack }: CreateTokenScreenProps) {
  const [tokenName, setTokenName] = useState('');
  const [tokenSymbol, setTokenSymbol] = useState('');
  const [initialSupply, setInitialSupply] = useState('1000000');
  const [logo, setLogo] = useState<string | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [twitter, setTwitter] = useState('');
  const [telegram, setTelegram] = useState('');
  const [website, setWebsite] = useState('');

  const [phase, setPhase] = useState<Phase>('form');
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [createdAddress, setCreatedAddress] = useState<string | null>(null);
  const [txRecord, setTxRecord] = useState<TxRecord | null>(null);
  const [pendingSave, setPendingSave] = useState<{ tokenAddress: string; createTxHash: string; feeTxHash: string; walletAddress: string; initialSupply: string } | null>(null);
  const [gasEstimate, setGasEstimate] = useState<{ estimatedFeeNative: string; nativeSymbol: string } | null>(null);
  const [gasEstimateLoading, setGasEstimateLoading] = useState(false);

  const recordCreatedToken = trpc.listings.recordCreatedToken.useMutation();
  const treasury = trpc.fees.getTreasury.useQuery();

  const supported = isCreationSupported(NETWORK);

  const handleLogoFile = (file: File | undefined) => {
    if (!file) return;
    if (file.size > 500 * 1024) {
      toast.error('Logo must be under 500KB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setLogo(result);
      setLogoPreview(result);
    };
    reader.readAsDataURL(file);
  };

  const nameOk = tokenName.trim().length > 0;
  const symbolOk = tokenSymbol.trim().length > 0;
  const supplyOk = Number(initialSupply) > 0;
  const logoOk = Boolean(logo);
  const socialsCount = [twitter, telegram, website].filter(Boolean).length;

  const canReview = nameOk && symbolOk && supplyOk && logoOk && phase === 'form' && !pendingSave;

  const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  // Pull a live network-fee estimate the moment the review screen opens, using whatever
  // address is available - falls back gracefully (see estimateTokenCreationGasFee) if the
  // wallet happens to be locked, since this is informational, not a blocker.
  useEffect(() => {
    if (phase !== 'review') return;
    const address = getStoredAddress();
    if (!address) return;
    setGasEstimateLoading(true);
    estimateTokenCreationGasFee({
      network: NETWORK,
      fromAddress: address,
      tokenName,
      tokenSymbol,
      initialSupply,
    })
      .then(setGasEstimate)
      .finally(() => setGasEstimateLoading(false));
  }, [phase, tokenName, tokenSymbol, initialSupply]);

  /** The token itself is already live on-chain by the time this runs - this
   * only saves the logo + marks it verified in Paxi's records. A network
   * blip here shouldn't strand an already-deployed token, so this retries a
   * couple of times automatically before falling back to a manual retry button. */
  const trySave = async (result: { tokenAddress: string; createTxHash: string; feeTxHash: string; walletAddress: string; initialSupply: string }) => {
    if (!logo) return;
    setPhase('saving');
    setPendingSave(null);

    const attempt = async () =>
      recordCreatedToken.mutateAsync({
        network: NETWORK,
        contractAddress: result.tokenAddress,
        symbol: tokenSymbol.trim(),
        name: tokenName.trim(),
        logo,
        socials: {
          ...(twitter && { twitter }),
          ...(telegram && { telegram }),
          ...(website && { website }),
        },
        walletAddress: result.walletAddress,
        initialSupply: result.initialSupply,
        feeTxHash: result.feeTxHash,
        deploymentTxHash: result.createTxHash,
      });

    for (let i = 0; i < 3; i++) {
      try {
        await attempt();
        setCreatedAddress(result.tokenAddress);
        const record = addTxRecord({
          type: 'create',
          networkId: NETWORK,
          hash: result.createTxHash,
          explorerUrl: network.explorerTx?.(result.createTxHash),
          fromSymbol: tokenSymbol.trim(),
          fromAmount: initialSupply.trim(),
          counterparty: result.tokenAddress,
          feeAmount: CREATION_FEE_USD.toFixed(2),
          feeSymbol: 'USDT',
          status: 'confirmed',
        });
        setTxRecord(record);
        setPhase('done');
        return;
      } catch (err) {
        if (i < 2) {
          await sleep(1500);
          continue;
        }
        // Out of automatic retries - keep the result around so the button below can retry manually
        // without re-deploying (that already succeeded and shouldn't be repeated).
        setPendingSave(result);
        setPhase('form');
        toast.error(
          err instanceof Error
            ? `Token deployed at ${result.tokenAddress}, but saving its logo keeps failing: ${err.message}`
            : `Token deployed at ${result.tokenAddress}, but saving its logo keeps failing.`
        );
      }
    }
  };

  const handleDeploy = async () => {
    if (!logo) return;
    const mnemonic = getUnlockedMnemonic();
    if (!mnemonic) {
      toast.error('Unlock your wallet first.');
      return;
    }

    const walletAddress = getStoredAddress();
    const treasuryAddress = treasury.data?.treasuryAddress;
    if (!walletAddress || !treasuryAddress) {
      toast.error('Treasury configuration is still loading. Try again shortly.');
      return;
    }

    let onChainResult: { tokenAddress: string; createTxHash: string };
    let feeTxHash = '';
    try {
      setPhase('approving');
      ({ feeTxHash } = await payCreationFee({ mnemonic, network: NETWORK, treasuryAddress }));
      onChainResult = await createTokenOnChain({
        mnemonic,
        network: NETWORK,
        tokenName: tokenName.trim(),
        tokenSymbol: tokenSymbol.trim(),
        initialSupply: initialSupply.trim(),
        onStatus: setPhase,
      });
    } catch (err) {
      toast.error(describeChainError(err, { feeSymbol: 'USDT' }));
      setPhase('review');
      return;
    }

      await trySave({ ...onChainResult, feeTxHash, walletAddress, initialSupply: initialSupply.trim() });
  };

  // PIN confirmed - close the sheet and fire the actual on-chain deployment.
  const handleAuthSuccess = () => {
    setShowAuthGate(false);
    handleDeploy();
  };

  if (!supported) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="max-w-md text-center space-y-3">
          <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto" />
          <h1 className="text-lg font-bold text-foreground">Not set up yet</h1>
          <p className="text-sm text-muted-foreground">
            The token-creation contract hasn't been deployed to BSC mainnet yet - once it is, its address needs to
            be added to <span className="font-mono text-xs">tokenFactory.ts</span>.
          </p>
          <button onClick={onBack} className="text-accent text-sm font-medium">
            Go back
          </button>
        </div>
      </div>
    );
  }

  if (phase === 'done' && createdAddress && txRecord) {
    return <TransactionReceipt record={txRecord} onClose={onBack} />;
  }

  if (phase === 'review') {
    return (
      <div className="min-h-screen bg-background pb-16">
        <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
          <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
            <button
              onClick={() => setPhase('form')}
              className="text-muted-foreground hover:text-foreground"
              disabled={phase !== 'review'}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-lg font-bold text-foreground">Review & Confirm</h1>
          </div>
        </div>

        <div className="max-w-md mx-auto px-6 py-6 space-y-6">
          <div className="glass-card p-4 flex items-center gap-3">
            {logoPreview && <img src={logoPreview} alt="" className="w-12 h-12 rounded-full object-cover shrink-0" />}
            <div className="min-w-0">
              <p className="font-semibold text-foreground truncate">{tokenName}</p>
              <p className="text-sm text-muted-foreground">
                {tokenSymbol} · {Number(initialSupply).toLocaleString()} supply
              </p>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground px-1 mb-2">Checklist</p>
            <div className="glass-card !p-0 divide-y divide-white/5 overflow-hidden">
              <ChecklistRow label="Token logo" ok={logoOk} />
              <ChecklistRow label="Name and symbol" ok={nameOk && symbolOk} />
              <ChecklistRow
                label={socialsCount > 0 ? `Social links (${socialsCount} added)` : 'Social links'}
                ok={socialsCount > 0}
                optional
              />
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground px-1 mb-2">
              Fees for this deployment
            </p>
            <div className="glass-card !p-0 divide-y divide-white/5 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-muted-foreground">Paxi platform fee</span>
                <span className="text-sm font-semibold text-foreground">${CREATION_FEE_USD.toFixed(2)} USDT</span>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-muted-foreground">Network fee (BNB Smart Chain gas)</span>
                <span className="text-sm font-semibold text-foreground">
                  {gasEstimateLoading
                    ? 'Estimating…'
                    : gasEstimate
                      ? `~${gasEstimate.estimatedFeeNative} ${gasEstimate.nativeSymbol}`
                      : 'Unavailable - paid at network rate'}
                </span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground px-1 mt-2">
              The platform fee goes to Paxi in one signature; the network fee is paid to BNB Smart Chain validators,
              same as any transaction on the chain. Both are shown here so nothing is a surprise on the next screen.
            </p>
          </div>

          <div className="flex items-start gap-2.5 bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-3.5">
            <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
            <p className="text-xs text-yellow-300">
              This deploys a real, immutable, permanent token on BNB Smart Chain mainnet. Name, symbol, and supply
              can't be changed after this. Double check everything above before confirming.
            </p>
          </div>

          <button
            onClick={() => setShowAuthGate(true)}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-colors"
          >
            Confirm & Create Token
          </button>
        </div>

        <TransactionAuthSheet
          open={showAuthGate}
          actionLabel={`Create ${tokenSymbol || 'your'} token — $${CREATION_FEE_USD.toFixed(2)} fee`}
          onSuccess={handleAuthSuccess}
          onCancel={() => setShowAuthGate(false)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground" disabled={phase !== 'form'}>
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-foreground">Create a Token</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-6">
        <div className="glass-card p-4 space-y-1.5">
          <p className="text-sm text-foreground font-medium">Deploy a real token on BNB Smart Chain</p>
          <p className="text-xs text-muted-foreground">
            One-time ${CREATION_FEE_USD.toFixed(2)} platform fee (USDT) plus network gas. You'll see the full
            breakdown and confirm with your PIN on the next screen before anything is deployed. This is a real,
            immutable, permanent on-chain deployment on mainnet.
          </p>
        </div>

        {(phase === 'approving' || phase === 'creating' || phase === 'saving') && (
          <div className="glass-card p-4 flex items-center gap-3 border border-accent/30">
            <div className="w-4 h-4 border-2 border-accent border-t-transparent rounded-full animate-spin shrink-0" />
            <p className="text-sm text-foreground">
              {phase === 'approving' && 'Approving fee payment…'}
              {phase === 'creating' && 'Deploying token on-chain…'}
              {phase === 'saving' && 'Saving logo & verifying…'}
            </p>
          </div>
        )}

        {pendingSave && (
          <div className="glass-card p-4 space-y-2 border border-amber-400/30">
            <p className="text-sm text-foreground font-medium">Your token is live, but wasn't saved yet</p>
            <p className="text-xs text-muted-foreground font-mono break-all">{pendingSave.tokenAddress}</p>
            <p className="text-xs text-muted-foreground">
              The deployment succeeded on-chain - only saving the logo/verification failed, likely a brief connection
              issue. Nothing was lost; just retry.
            </p>
            <button
              onClick={() => trySave(pendingSave)}
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-sm py-2.5 rounded-lg transition-colors"
            >
              Retry Saving
            </button>
          </div>
        )}

        <Field label="Token name">
          <TextInput value={tokenName} onChange={setTokenName} placeholder="My Awesome Token" disabled={phase !== 'form'} />
        </Field>
        <Field label="Symbol">
          <TextInput value={tokenSymbol} onChange={setTokenSymbol} placeholder="MAT" disabled={phase !== 'form'} />
        </Field>
        <Field label="Initial supply">
          <TextInput value={initialSupply} onChange={setInitialSupply} placeholder="1000000" disabled={phase !== 'form'} />
        </Field>

        <Field label="Logo (max 500KB)">
          <label className="flex items-center gap-3 bg-secondary border border-dashed border-border rounded-lg py-3 px-3.5 cursor-pointer">
            {logoPreview ? (
              <img src={logoPreview} alt="Logo preview" className="w-10 h-10 rounded-full object-cover" />
            ) : (
              <Upload className="w-5 h-5 text-muted-foreground" />
            )}
            <span className="text-sm text-muted-foreground">{logoPreview ? 'Change logo' : 'Upload logo image'}</span>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp,image/svg+xml"
              className="hidden"
              disabled={phase !== 'form'}
              onChange={(e) => handleLogoFile(e.target.files?.[0])}
            />
          </label>
        </Field>

        <div className="space-y-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground px-1">
            Social Links (optional)
          </p>
          <TextInput value={twitter} onChange={setTwitter} placeholder="Twitter/X URL" disabled={phase !== 'form'} />
          <TextInput value={telegram} onChange={setTelegram} placeholder="Telegram URL" disabled={phase !== 'form'} />
          <TextInput value={website} onChange={setWebsite} placeholder="Website URL" disabled={phase !== 'form'} />
        </div>

        <button
          onClick={() => setPhase('review')}
          disabled={!canReview}
          className="w-full bg-accent hover:bg-accent/90 disabled:opacity-40 disabled:cursor-not-allowed text-accent-foreground font-semibold text-sm py-3 rounded-lg transition-colors"
        >
          Review & Continue
        </button>
      </div>
    </div>
  );
}

function ChecklistRow({ label, ok, optional }: { label: string; ok: boolean; optional?: boolean }) {
  return (
    <div className="flex items-center gap-2.5 px-4 py-3">
      {ok ? (
        <CheckCircle className="w-4 h-4 text-accent shrink-0" />
      ) : (
        <Circle className="w-4 h-4 text-muted-foreground shrink-0" />
      )}
      <span className={`text-sm ${ok ? 'text-foreground' : 'text-muted-foreground'}`}>
        {label}
        {optional && !ok && <span className="text-xs text-muted-foreground/70"> (optional)</span>}
      </span>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs font-medium text-muted-foreground px-1">{label}</p>
      {children}
    </div>
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      className="w-full bg-secondary border border-border rounded-lg py-2.5 px-3.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-accent/50 disabled:opacity-50"
    />
  );
}
