import { useEffect, useState } from 'react';
import { ArrowLeft, Plus, Check, Pencil, Trash2, Eye, KeyRound, Download, Copy } from 'lucide-react';
import { toast } from 'sonner';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import {
  getWallets,
  switchActiveWallet,
  renameWallet,
  deleteWallet,
  addGeneratedWallet,
  addImportedWallet,
  addImportedPrivateKeyWallet,
  addWatchOnlyWallet,
  type WalletSummary,
} from '@/lib/wallet/vault';

interface ManageWalletsScreenProps {
  onBack: () => void;
  /** Called after switching the active wallet, so the caller can refresh dashboard data. */
  onWalletChanged: () => void;
}

function shortAddress(address: string) {
  return `${address.slice(0, 8)}…${address.slice(-6)}`;
}

export default function ManageWalletsScreen({ onBack, onWalletChanged }: ManageWalletsScreenProps) {
  const [wallets, setWallets] = useState<WalletSummary[]>([]);
  const [renaming, setRenaming] = useState<WalletSummary | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const refresh = () => setWallets(getWallets());
  useEffect(refresh, []);

  const handleSwitch = async (w: WalletSummary) => {
    if (w.isActive) return;
    try {
      await switchActiveWallet(w.id);
      refresh();
      onWalletChanged();
      toast.success(`Switched to ${w.label}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not switch wallets');
    }
  };

  const handleCopy = (w: WalletSummary) => {
    navigator.clipboard.writeText(w.address);
    setCopiedId(w.id);
    toast.success('Address copied');
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleDelete = (w: WalletSummary) => {
    if (confirmDeleteId !== w.id) {
      setConfirmDeleteId(w.id);
      return;
    }
    try {
      deleteWallet(w.id);
      refresh();
      if (w.isActive) onWalletChanged();
      toast.success(`${w.label} removed`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not remove this wallet');
    } finally {
      setConfirmDeleteId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">Manage Wallets</h1>
          <button
            onClick={() => setAddOpen(true)}
            className="flex items-center gap-1 text-xs font-semibold text-accent hover:text-accent/80 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add
          </button>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-4">
        <p className="text-xs text-muted-foreground">
          All wallets on this device unlock with the same PIN/biometrics. Watch-only wallets have no keys stored - you can view balances but can't send.
        </p>

        <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
          {wallets.map((w) => (
            <div key={w.id} className={`flex items-center gap-3 px-4 py-3.5 ${w.isActive ? 'bg-accent/5' : ''}`}>
              <button onClick={() => handleSwitch(w)} className="flex items-center gap-3 flex-1 min-w-0 text-left">
                <span
                  className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                    w.isActive ? 'bg-accent/20 text-accent' : 'bg-secondary text-muted-foreground'
                  }`}
                >
                  {w.watchOnly ? <Eye className="w-4 h-4" /> : <KeyRound className="w-4 h-4" />}
                </span>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="font-semibold text-foreground text-sm truncate">{w.label}</p>
                    {w.isActive && <Check className="w-3.5 h-3.5 text-accent shrink-0" />}
                  </div>
                  <p className="text-xs text-muted-foreground font-mono truncate">
                    {shortAddress(w.address)} {w.watchOnly && '· Watch-only'} {w.isPrivateKeyImport && '· Imported (EVM)'}
                  </p>
                </div>
              </button>
              <div className="flex items-center gap-0.5 shrink-0">
                <button
                  onClick={() => handleCopy(w)}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                  aria-label="Copy address"
                >
                  {copiedId === w.id ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setRenaming(w)}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-foreground/5 active:scale-90 transition-all"
                  aria-label="Rename wallet"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(w)}
                  onBlur={() => setConfirmDeleteId(null)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center active:scale-90 transition-all ${confirmDeleteId === w.id ? 'text-destructive bg-destructive/10' : 'text-muted-foreground hover:text-destructive hover:bg-destructive/10'}`}
                  aria-label="Remove wallet"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <RenameDrawer target={renaming} onClose={() => setRenaming(null)} onSaved={refresh} />
      <AddWalletDrawer
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onAdded={() => {
          refresh();
          onWalletChanged();
          setAddOpen(false);
        }}
      />
    </div>
  );
}

function RenameDrawer({ target, onClose, onSaved }: { target: WalletSummary | null; onClose: () => void; onSaved: () => void }) {
  const [label, setLabel] = useState('');
  useEffect(() => setLabel(target?.label ?? ''), [target]);

  const handleSave = () => {
    if (!target) return;
    try {
      renameWallet(target.id, label);
      toast.success('Wallet renamed');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not rename this wallet');
    }
  };

  return (
    <Drawer open={target !== null} onOpenChange={(open) => !open && onClose()}>
      <DrawerContent>
        <DrawerHeader className="text-left">
          <DrawerTitle>Rename Wallet</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-6 space-y-3 max-w-md mx-auto w-full">
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Wallet label"
            className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
          />
          <button onClick={handleSave} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-2.5 rounded-lg transition-all active:scale-[0.98] text-sm">
            Save
          </button>
        </div>
      </DrawerContent>
    </Drawer>
  );
}

type AddStep = 'choose' | 'create-pin' | 'import' | 'import-key' | 'watch';

function AddWalletDrawer({ open, onClose, onAdded }: { open: boolean; onClose: () => void; onAdded: () => void }) {
  const [step, setStep] = useState<AddStep>('choose');
  const [label, setLabel] = useState('');
  const [phrase, setPhrase] = useState('');
  const [privateKey, setPrivateKey] = useState('');
  const [address, setAddress] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setStep('choose');
      setLabel('');
      setPhrase('');
      setPrivateKey('');
      setAddress('');
      setPin('');
      setError('');
    }
  }, [open]);

  const handleCreate = async () => {
    setBusy(true);
    setError('');
    try {
      await addGeneratedWallet(pin, label);
      toast.success('New wallet created');
      onAdded();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Incorrect PIN');
    } finally {
      setBusy(false);
    }
  };

  const handleImport = async () => {
    setBusy(true);
    setError('');
    try {
      await addImportedWallet(phrase, pin, label);
      toast.success('Wallet imported');
      onAdded();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not import this wallet');
    } finally {
      setBusy(false);
    }
  };

  const handleImportKey = async () => {
    setBusy(true);
    setError('');
    try {
      await addImportedPrivateKeyWallet(privateKey, pin, label);
      toast.success('Account imported');
      onAdded();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not import this private key');
    } finally {
      setBusy(false);
    }
  };

  const handleWatch = () => {
    setError('');
    try {
      addWatchOnlyWallet(address, label);
      toast.success('Watch-only wallet added');
      onAdded();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add this address');
    }
  };

  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent>
        <DrawerHeader className="text-left">
          <DrawerTitle>
            {step === 'choose' && 'Add a Wallet'}
            {step === 'create-pin' && 'Create New Wallet'}
            {step === 'import' && 'Import Wallet'}
            {step === 'import-key' && 'Import via Private Key'}
            {step === 'watch' && 'Watch an Address'}
          </DrawerTitle>
        </DrawerHeader>

        <div className="px-4 pb-6 space-y-3 max-w-md mx-auto w-full">
          {step === 'choose' && (
            <>
              <button
                onClick={() => setStep('create-pin')}
                className="w-full flex items-center gap-3 bg-secondary hover:bg-muted border border-border rounded-lg p-3.5 text-left transition-colors"
              >
                <Plus className="w-4 h-4 text-accent shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-foreground">Create a new wallet</p>
                  <p className="text-xs text-muted-foreground">Generates a fresh recovery phrase</p>
                </div>
              </button>
              <button
                onClick={() => setStep('import')}
                className="w-full flex items-center gap-3 bg-secondary hover:bg-muted border border-border rounded-lg p-3.5 text-left transition-colors"
              >
                <Download className="w-4 h-4 text-accent shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-foreground">Import an existing wallet</p>
                  <p className="text-xs text-muted-foreground">Using its 12-word recovery phrase</p>
                </div>
              </button>
              <button
                onClick={() => setStep('import-key')}
                className="w-full flex items-center gap-3 bg-secondary hover:bg-muted border border-border rounded-lg p-3.5 text-left transition-colors"
              >
                <KeyRound className="w-4 h-4 text-accent shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-foreground">Import via private key</p>
                  <p className="text-xs text-muted-foreground">EVM only - no seed phrase, single account</p>
                </div>
              </button>
              <button
                onClick={() => setStep('watch')}
                className="w-full flex items-center gap-3 bg-secondary hover:bg-muted border border-border rounded-lg p-3.5 text-left transition-colors"
              >
                <Eye className="w-4 h-4 text-accent shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-foreground">Watch an address</p>
                  <p className="text-xs text-muted-foreground">View-only, no keys stored - can't send</p>
                </div>
              </button>
            </>
          )}

          {(step === 'create-pin' || step === 'import') && (
            <>
              <input
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Label (optional)"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
              />
              {step === 'import' && (
                <textarea
                  value={phrase}
                  onChange={(e) => setPhrase(e.target.value)}
                  placeholder="12-word recovery phrase"
                  rows={3}
                  className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm font-mono focus:outline-none focus:border-accent/60 resize-none"
                />
              )}
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter your device PIN"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground text-center tracking-[0.5em] text-xl"
              />
              {error && <p className="text-sm text-destructive">{error}</p>}
              <button
                onClick={step === 'create-pin' ? handleCreate : handleImport}
                disabled={busy || pin.length !== 6 || (step === 'import' && !phrase.trim())}
                className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-2.5 rounded-lg transition-all active:scale-[0.98] text-sm"
              >
                {busy ? 'Please wait…' : step === 'create-pin' ? 'Create Wallet' : 'Import Wallet'}
              </button>
            </>
          )}

          {step === 'import-key' && (
            <>
              <div className="flex items-start gap-2 bg-accent/10 border border-accent/25 rounded-lg p-3">
                <KeyRound className="w-3.5 h-3.5 text-accent shrink-0 mt-0.5" />
                <p className="text-xs text-foreground/80">
                  A private key only unlocks EVM chains (Ethereum, BSC, Polygon, Arbitrum) - unlike a recovery
                  phrase, it can't also derive a Bitcoin or Solana address.
                </p>
              </div>
              <input
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Label (optional)"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
              />
              <textarea
                value={privateKey}
                onChange={(e) => setPrivateKey(e.target.value)}
                placeholder="Private key (0x...)"
                rows={2}
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm font-mono focus:outline-none focus:border-accent/60 resize-none"
              />
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter your device PIN"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground text-center tracking-[0.5em] text-xl"
              />
              {error && <p className="text-sm text-destructive">{error}</p>}
              <button
                onClick={handleImportKey}
                disabled={busy || pin.length !== 6 || !privateKey.trim()}
                className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-2.5 rounded-lg transition-all active:scale-[0.98] text-sm"
              >
                {busy ? 'Please wait…' : 'Import Account'}
              </button>
            </>
          )}

          {step === 'watch' && (
            <>
              <input
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Label (optional)"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:border-accent/60"
              />
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="0x… address to watch"
                className="w-full bg-secondary border border-border rounded-lg p-3 text-foreground placeholder:text-muted-foreground font-mono text-sm focus:outline-none focus:border-accent/60"
              />
              {error && <p className="text-sm text-destructive">{error}</p>}
              <button
                onClick={handleWatch}
                disabled={!address.trim()}
                className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground font-semibold py-2.5 rounded-lg transition-all active:scale-[0.98] text-sm"
              >
                Add Watch-only Wallet
              </button>
            </>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
