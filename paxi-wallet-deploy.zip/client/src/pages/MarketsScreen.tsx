import { useEffect, useState } from 'react';
import { Search, TrendingUp, TrendingDown, BarChart3, LayoutGrid, Loader2, ChevronLeft, ChevronRight, ShieldAlert } from 'lucide-react';
import BottomNav, { type NavTab } from '@/components/BottomNav';
import AssetLogo from '@/components/AssetLogo';
import { trpc } from '@/lib/trpc';
import type { AssetConfig } from '@/lib/wallet/chains';
import { ASSETS } from '@/lib/wallet/chains';
import { customTokenToAsset, getCustomTokens } from '@/lib/wallet/customTokens';
import type { AssetBalance } from '@/lib/wallet/balances';
import { canonicalMarketIdentityKey, shortenCanonicalIdentifier } from '@/lib/marketIdentity';
import { formatFiat, useCurrency, useUsdFiatRate } from '@/lib/currency';
import { notifyForPriceMovement } from '@/lib/phase3Local';
import { getTrustedMarketLabel, isOfficialPaxiMarketToken, PAXI_LOGO_URL } from '@/lib/appInfo';

export interface MarketTokenSelection {
  coinId: string | null;
  chain: string | null;
  contractAddress: string | null;
  symbol: string;
  name: string;
}

interface MarketsScreenProps {
  onNavigate: (tab: NavTab) => void;
  onSelectAsset: (asset: AssetConfig, balance: AssetBalance | undefined) => void;
  onSelectToken: (token: MarketTokenSelection) => void;
}

type SortMode = 'market_cap_desc' | 'price_change_percentage_24h_desc' | 'price_change_percentage_24h_asc' | 'volume_desc';

const SORT_TABS: Array<{ id: SortMode; label: string; icon: typeof LayoutGrid }> = [
  { id: 'market_cap_desc', label: 'All', icon: LayoutGrid },
  { id: 'price_change_percentage_24h_desc', label: 'Top Gainers', icon: TrendingUp },
  { id: 'price_change_percentage_24h_asc', label: 'Top Losers', icon: TrendingDown },
  { id: 'volume_desc', label: 'Volume', icon: BarChart3 },
];

/**
 * Real global market data via CoinGecko (server/marketData.ts) - thousands
 * of tokens, fetched from a real provider rather than hand-maintained.
 * Tapping a token you actually hold in this wallet opens its real asset
 * screen (send/receive/swap); tapping any other token is browse-only for
 * now (full external Token Detail page is the next step).
 */
export default function MarketsScreen({ onNavigate, onSelectAsset, onSelectToken }: MarketsScreenProps) {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('market_cap_desc');
  const [page, setPage] = useState(1);
  const currency = useCurrency();
  const fiatRate = useUsdFiatRate(currency);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 400);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    setPage(1);
  }, [sortMode, debouncedQuery]);

  const isSearching = debouncedQuery.length > 0;

  const listQuery = trpc.market.list.useQuery(
    { page, perPage: 50, order: sortMode },
    { enabled: !isSearching, placeholderData: (prev) => prev }
  );
  const searchQuery = trpc.market.search.useQuery({ query: debouncedQuery }, { enabled: isSearching });

  const tokens = isSearching ? (searchQuery.data ?? []) : (listQuery.data ?? []);
  const isLoading = isSearching ? searchQuery.isLoading : listQuery.isLoading;

  useEffect(() => {
    for (const token of tokens) {
      if (!Number.isFinite(Number(token.currentPrice)) || Number(token.currentPrice) <= 0) continue;
      const assetKey = token.chain && token.contractAddress
        ? canonicalMarketIdentityKey(token.chain, token.contractAddress)
        : token.coinId ?? token.id;
      notifyForPriceMovement({ assetKey, symbol: token.symbol, currentPrice: Number(token.currentPrice) });
    }
  }, [tokens]);
  const isFetchingPage = !isSearching && listQuery.isFetching && !listQuery.isLoading;

  // Held-asset matching is intentionally canonical. Symbol-only matching can
  // open the wrong token when the same symbol exists on multiple chains.
  const walletAssets = [...ASSETS, ...getCustomTokens().map(customTokenToAsset)];
  const walletAssetByIdentity = new Map(
    walletAssets
      .filter((a) => a.contractAddress)
      .map((a) => [canonicalMarketIdentityKey(a.network, a.contractAddress!), a]),
  );

  const handleRowTap = (token: (typeof tokens)[number]) => {
    const key = token.chain && token.contractAddress ? canonicalMarketIdentityKey(token.chain, token.contractAddress) : null;
    const asset = key ? walletAssetByIdentity.get(key) : undefined;
    if (asset) onSelectAsset(asset, undefined);
    else onSelectToken({
      coinId: token.coinId ?? null,
      chain: token.chain ?? null,
      contractAddress: token.contractAddress ?? null,
      symbol: token.symbol,
      name: token.name,
    });
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-24 flex flex-col">
      <div className="paxi-page-header sticky top-0 z-40">
        <div className="mx-auto max-w-md space-y-3 px-4 py-4 sm:px-6">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Market intelligence</p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground">Markets</h1>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              type="search"
              aria-label="Search market tokens"
              placeholder="Search by token or symbol"
              className="paxi-field w-full py-2.5 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
          </div>

          {!isSearching && (
            <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
              {SORT_TABS.map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setSortMode(id)}
                    aria-pressed={sortMode === id}
                    className={`paxi-chip shrink-0 flex items-center gap-1 text-xs font-semibold ${
                      sortMode === id ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
                    }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mx-auto w-full max-w-md flex-1 px-4 py-5 sm:px-6">
        {isLoading && tokens.length === 0 ? (
          <div className="glass-card space-y-3 p-5" aria-label="Loading market data" aria-busy="true">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="flex items-center gap-3 py-2">
                <div className="h-10 w-10 animate-pulse rounded-full bg-secondary" />
                <div className="min-w-0 flex-1 space-y-2"><div className="h-3 w-24 animate-pulse rounded bg-secondary" /><div className="h-2.5 w-36 animate-pulse rounded bg-secondary" /></div>
                <div className="space-y-2"><div className="ml-auto h-3 w-16 animate-pulse rounded bg-secondary" /><div className="ml-auto h-2.5 w-10 animate-pulse rounded bg-secondary" /></div>
              </div>
            ))}
            <div className="flex items-center justify-center gap-2 pt-1 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Updating prices</div>
          </div>
        ) : tokens.length === 0 ? (
          <div className="glass-card px-6 py-12 text-center" aria-live="polite">
            <BarChart3 className="mx-auto mb-3 h-7 w-7 text-muted-foreground" aria-hidden={true} />
            <p className="text-sm font-medium text-foreground">{isSearching ? `No tokens match "${debouncedQuery}"` : 'Market data is unavailable right now.'}</p>
            <p className="mt-1 text-xs text-muted-foreground">{isSearching ? 'Try a different symbol or token name.' : 'Please try again in a moment.'}</p>
          </div>
        ) : (
          <>
            <div className={`glass-card divide-y divide-white/5 !p-0 overflow-hidden transition-opacity ${isFetchingPage ? 'opacity-50' : ''}`}>
              {tokens.map((t, i) => {
                const identityKey = t.chain && t.contractAddress ? canonicalMarketIdentityKey(t.chain, t.contractAddress) : null;
                const isHeld = Boolean(identityKey && walletAssetByIdentity.has(identityKey));
                const trustedLabel = getTrustedMarketLabel({ id: t.id, symbol: t.symbol, name: t.name });
                const officialPaxi = isOfficialPaxiMarketToken({ symbol: t.symbol, name: t.name });
                return (
                  <button
                    key={`${t.chain ?? 'unknown'}:${t.contractAddress ?? t.coinId ?? t.id}`}
                    type="button"
                    onClick={() => handleRowTap(t)}
                    style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}
                    className="paxi-pressable flex min-h-[4.75rem] w-full items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-foreground/5 active:bg-foreground/10 animate-in fade-in slide-in-from-bottom-1 duration-300 fill-mode-both"
                  >
                    {t.marketCapRank && (
                      <span className="w-5 text-xs text-muted-foreground text-center shrink-0">{t.marketCapRank}</span>
                    )}
                    <AssetLogo src={officialPaxi ? PAXI_LOGO_URL : t.image} fallback={t.symbol.slice(0, 3) || '?'} size="md" aria-hidden={true} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-foreground text-sm flex items-center gap-1.5">
                        {t.symbol || 'UNKNOWN'}
                        {isHeld && <span className="paxi-status min-h-5 bg-accent/15 px-1.5 py-0.5 text-[9px] text-accent">Held</span>}
                        {trustedLabel ? (
                          <span className="paxi-status min-h-5 bg-accent/12 px-1.5 py-0.5 text-[9px] text-accent" title={trustedLabel}>
                            {officialPaxi ? 'Official PAXI' : 'Canonical asset'}
                          </span>
                        ) : (
                          <span className="paxi-status min-h-5 bg-amber-500/15 px-1.5 py-0.5 text-[9px] text-amber-300" title="Provider market data only; PAXI has not verified this asset identity">
                            <ShieldAlert className="h-2.5 w-2.5" aria-hidden={true} />
                            Provider data only
                          </span>
                        )}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">{t.name || 'Unknown token'}{t.chain ? ` · ${CHAIN_LABELS[t.chain] ?? t.chain}` : ''}</p>
                      {t.contractAddress && <p className="text-[10px] text-muted-foreground/70 font-mono truncate">{shortenCanonicalIdentifier(t.contractAddress)}</p>}
                      <p className="text-[10px] text-muted-foreground/70 truncate">
                        {t.contractAddress ? `Contract · ${t.source === 'coingecko' ? 'CoinGecko' : 'provider'} data` : 'Market data · contract not selected'}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-semibold text-foreground text-sm">
                        {t.currentPrice != null ? formatUsd(t.currentPrice, currency, fiatRate) : '—'}
                      </p>
                      <p className={`text-xs ${t.priceChangePercent24h == null ? 'text-muted-foreground' : t.priceChangePercent24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        {t.priceChangePercent24h != null ? `${t.priceChangePercent24h >= 0 ? '+' : ''}${t.priceChangePercent24h.toFixed(2)}%` : '—'}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {!isSearching && (
              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  type="button"
                  className="paxi-pressable flex min-h-11 items-center gap-1 rounded-lg px-3 py-1.5 text-sm text-muted-foreground transition-all hover:bg-foreground/5 disabled:opacity-30"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Prev
                </button>
                <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                  {isFetchingPage && <Loader2 className="w-3 h-3 animate-spin" />}
                  Page {page}
                </span>
                <button
                  onClick={() => setPage((p) => p + 1)}
                  type="button"
                  className="paxi-pressable flex min-h-11 items-center gap-1 rounded-lg px-3 py-1.5 text-sm text-accent transition-all hover:bg-accent/10"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        )}
      </div>
      <BottomNav active="markets" onNavigate={onNavigate} />
    </div>
  );
}

const CHAIN_LABELS: Record<string, string> = {
  ethereum: 'Ethereum',
  bsc: 'BNB Smart Chain',
  solana: 'Solana',
  polygon: 'Polygon',
  arbitrum: 'Arbitrum',
  bitcoin: 'Bitcoin',
  base: 'Base',
};


function formatUsd(value: number | null, currency: import('@/lib/currency').FiatCurrency, fiatRate: number | null): string {
  return formatFiat(value, currency, fiatRate);
}
