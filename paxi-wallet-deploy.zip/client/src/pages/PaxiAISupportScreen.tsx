import { ArrowLeft, BookOpen, Flag, ShieldAlert, Sparkles } from 'lucide-react';

interface PaxiAISupportScreenProps {
  onBack: () => void;
  onWalletGuide: () => void;
  onReportIssue: () => void;
}

export default function PaxiAISupportScreen({ onBack, onWalletGuide, onReportIssue }: PaxiAISupportScreenProps) {
  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBack} className="text-muted-foreground hover:text-foreground" aria-label="Back">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold text-accent">PAXI AI Support</h1>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6 space-y-5">
        <section className="glass-card p-5 space-y-3 border border-accent/20">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-accent" />
            </span>
            <div>
              <h2 className="font-semibold text-foreground">Wallet guidance</h2>
              <p className="text-xs text-muted-foreground">Learn first, then approve every action yourself.</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            PAXI support can provide educational guidance about wallet security, fees, swaps, bridges, and token approvals.
            This build does not expose private keys or recovery phrases to support, and no support feature can sign, move funds,
            or change security settings for you.
          </p>
        </section>

        <button onClick={onWalletGuide} className="w-full glass-card p-4 flex items-center gap-3 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all">
          <BookOpen className="w-5 h-5 text-accent" />
          <span className="flex-1"><span className="block text-sm font-semibold text-foreground">Open Help Centre</span><span className="block text-xs text-muted-foreground mt-0.5">Security and wallet-use guidance</span></span>
        </button>

        <button onClick={onReportIssue} className="w-full glass-card p-4 flex items-center gap-3 text-left hover:bg-foreground/5 active:scale-[0.99] transition-all">
          <Flag className="w-5 h-5 text-accent" />
          <span className="flex-1"><span className="block text-sm font-semibold text-foreground">Report a problem</span><span className="block text-xs text-muted-foreground mt-0.5">Send a diagnostic report to support</span></span>
        </button>

        <div className="rounded-lg border border-yellow-400/20 bg-yellow-400/5 p-3.5 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 text-yellow-300 shrink-0 mt-0.5" />
          <p className="text-xs text-yellow-100/80">Never share a seed phrase, private key, PIN, or signing approval with support or any dApp.</p>
        </div>
      </div>
    </div>
  );
}
