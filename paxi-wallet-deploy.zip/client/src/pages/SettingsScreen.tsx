import { useState } from 'react';
import { LogOut, ChevronRight, ArrowLeft, ShieldCheck, Upload, Moon, Fingerprint, Globe, Coins, Trash2, Flag, AlertTriangle, Bell } from 'lucide-react';
import { toast } from 'sonner';
import { useTheme } from '@/contexts/ThemeContext';
import {
  disableBiometricUnlock,
  enableBiometricForCurrentSession,
  isBiometricEnabledOnVault,
  unlockWithPIN,
  wipeVault,
} from '@/lib/wallet/vault';
import { useI18n, LANGUAGES, type LangCode } from '@/lib/i18n';
import { getStoredCurrency, setStoredCurrency, SUPPORTED_CURRENCIES, type FiatCurrency } from '@/lib/currency';
import { getNotificationPreferences, setNotificationPreferences, type NotificationPreferences } from '@/lib/phase3Local';
import { getStoredDefaultNetwork, setStoredDefaultNetwork } from '@/lib/defaultNetwork';
import { NETWORKS } from '@/lib/wallet/chains';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';

interface SettingsScreenProps {
  onBack: () => void;
  onLogout: () => void;
  onBackupWallet: () => void;
  onExportWallet: () => void;
  onReportIssue: () => void;
}

function Row({
  icon: Icon,
  label,
  value,
  onClick,
  disabled,
}: {
  icon: typeof Moon;
  label: string;
  value?: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="paxi-pressable flex min-h-14 w-full items-center justify-between px-4 py-3.5 text-left transition-all hover:bg-foreground/5 disabled:opacity-50 disabled:active:scale-100"
    >
      <span className="flex items-center gap-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-accent/10">
          <Icon className="h-4 w-4 text-accent" aria-hidden="true" />
        </span>
        <span className="text-sm text-foreground font-medium">{label}</span>
      </span>
      {value !== undefined ? (
        typeof value === 'string' ? <span className="text-xs text-muted-foreground">{value}</span> : value
      ) : (
        <ChevronRight className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
      )}
    </button>
  );
}

export default function SettingsScreen({ onBack, onLogout, onBackupWallet, onExportWallet, onReportIssue }: SettingsScreenProps) {
  const { theme, toggleTheme, switchable } = useTheme();
  const { lang, setLang, t } = useI18n();
  const [currency, setCurrency] = useState<FiatCurrency>(() => getStoredCurrency());
  const [biometricOn, setBiometricOn] = useState(isBiometricEnabledOnVault());
  const [showLanguagePicker, setShowLanguagePicker] = useState(false);
  const [notificationPreferences, setNotificationPreferencesState] = useState<NotificationPreferences>(() => getNotificationPreferences());
  const [defaultNetwork, setDefaultNetwork] = useState(() => getStoredDefaultNetwork());

  const [showWipeConfirm, setShowWipeConfirm] = useState(false);
  const [wipePin, setWipePin] = useState('');
  const [wipeError, setWipeError] = useState('');
  const [wiping, setWiping] = useState(false);

  const handleCurrencyChange = () => {
    const idx = SUPPORTED_CURRENCIES.indexOf(currency);
    const next = SUPPORTED_CURRENCIES[(idx + 1) % SUPPORTED_CURRENCIES.length];
    setCurrency(next);
    setStoredCurrency(next);
  };

  const toggleNotificationPreference = (key: keyof NotificationPreferences) => {
    const next = setNotificationPreferences({ [key]: !notificationPreferences[key] });
    setNotificationPreferencesState(next);
  };

  const handleDefaultNetworkChange = () => {
    const networkIds = Object.keys(NETWORKS);
    const currentIndex = Math.max(0, networkIds.indexOf(defaultNetwork));
    const nextNetwork = networkIds[(currentIndex + 1) % networkIds.length] ?? 'ethereum';
    setDefaultNetwork(setStoredDefaultNetwork(nextNetwork));
  };

  const handleSelectLanguage = (code: LangCode) => {
    setLang(code);
    setShowLanguagePicker(false);
    toast.success(`${LANGUAGES.find((l) => l.code === code)?.label} selected`);
  };

  const handleToggleBiometric = async () => {
    if (biometricOn) {
      disableBiometricUnlock();
      setBiometricOn(false);
      toast.success('Biometric unlock disabled');
      return;
    }
    try {
      await enableBiometricForCurrentSession();
      setBiometricOn(true);
      toast.success('Biometric unlock enabled');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not enable biometric unlock on this device.');
    }
  };

  const handleWipe = async () => {
    setWipeError('');
    setWiping(true);
    try {
      await unlockWithPIN(wipePin); // throws on a wrong PIN - the last check before an irreversible action
      await wipeVault();
      window.location.reload();
    } catch {
      setWipeError('Incorrect PIN.');
      setWiping(false);
    }
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-background px-4 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto mb-6 flex max-w-md items-center justify-between sm:mb-8">
        <button type="button" onClick={onBack} className="paxi-pressable flex min-h-11 items-center gap-1 rounded-xl px-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Back
        </button>
        <h1 className="text-xl font-bold tracking-tight text-foreground">{t('settings_title')}</h1>
        <div className="w-14" aria-hidden="true" />
      </div>

      <div className="mx-auto w-full max-w-md space-y-6">
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">{t('settings_wallet')}</h4>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            <Row icon={ShieldCheck} label={t('settings_backup')} onClick={onBackupWallet} />
            <Row icon={Upload} label={t('settings_export')} onClick={onExportWallet} />
          </div>
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">{t('settings_preferences')}</h4>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            <Row
              icon={Moon}
              label={t('settings_dark_mode')}
              value={theme === 'dark' ? 'On' : 'Off'}
              onClick={switchable ? toggleTheme : undefined}
              disabled={!switchable}
            />
            <Row icon={Fingerprint} label={t('settings_biometric')} value={biometricOn ? 'On' : 'Off'} onClick={handleToggleBiometric} />
            <Row
              icon={Globe}
              label={t('settings_language')}
              value={LANGUAGES.find((l) => l.code === lang)?.label}
              onClick={() => setShowLanguagePicker((v) => !v)}
            />
            <Row icon={Coins} label={t('settings_currency')} value={currency} onClick={handleCurrencyChange} />
            <Row icon={Globe} label="Default network" value={NETWORKS[defaultNetwork]?.label ?? 'Ethereum'} onClick={handleDefaultNetworkChange} />
          </div>
          {showLanguagePicker && (
            <div className="mt-2 glass-card !p-0 overflow-hidden divide-y divide-white/5 animate-in fade-in slide-in-from-top-1 duration-200">
              {LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  onClick={() => handleSelectLanguage(l.code)}
                  type="button"
                  className={`paxi-pressable flex min-h-11 w-full items-center justify-between px-4 py-2.5 text-sm transition-colors ${
                    l.code === lang ? 'text-accent font-semibold bg-accent/5' : 'text-foreground/80 hover:bg-foreground/5'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2 px-1">Notifications</h4>
          <div className="glass-card divide-y divide-white/5 !p-0 overflow-hidden">
            <Row icon={Bell} label="Transaction notifications" value={notificationPreferences.transaction ? 'On' : 'Off'} onClick={() => toggleNotificationPreference('transaction')} />
            <Row icon={Bell} label="Received-funds notifications" value={notificationPreferences.receivedFunds ? 'On' : 'Off'} onClick={() => toggleNotificationPreference('receivedFunds')} />
            <Row icon={Bell} label="Price alerts" value={notificationPreferences.priceAlerts ? 'On' : 'Off'} onClick={() => toggleNotificationPreference('priceAlerts')} />
            <Row icon={Bell} label="Security warnings" value={notificationPreferences.securityWarnings ? 'On' : 'Off'} onClick={() => toggleNotificationPreference('securityWarnings')} />
            <Row icon={Bell} label="Ecosystem announcements" value={notificationPreferences.ecosystemAnnouncements ? 'On' : 'Off'} onClick={() => toggleNotificationPreference('ecosystemAnnouncements')} />
          </div>
        </div>

        <div className="glass-card !p-0 overflow-hidden">
          <Row icon={Flag} label={t('settings_report_issue')} onClick={onReportIssue} />
        </div>

        <div className="space-y-2">
          <button
            onClick={onLogout}
            type="button"
            className="paxi-pressable flex min-h-12 w-full items-center justify-center rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm font-semibold text-destructive transition-all hover:bg-destructive/15"
          >
            <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
            {t('settings_lock')}
          </button>
          <button
            onClick={() => {
              setWipePin('');
              setWipeError('');
              setShowWipeConfirm(true);
            }}
            type="button"
            className="paxi-pressable flex min-h-12 w-full items-center justify-center gap-2 rounded-xl border border-border bg-secondary px-4 py-3 text-sm text-muted-foreground transition-all hover:border-destructive/40 hover:bg-destructive/10 hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" aria-hidden="true" />
            {t('settings_remove')}
          </button>
        </div>
      </div>

      <Drawer open={showWipeConfirm} onOpenChange={(v) => !wiping && setShowWipeConfirm(v)}>
        <DrawerContent>
          <DrawerHeader className="text-left">
            <DrawerTitle>Remove wallet from this device?</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6 space-y-4 max-w-md mx-auto w-full">
            <div className="paxi-alert-error flex items-start gap-2.5 rounded-xl p-3.5">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden="true" />
              <p className="text-sm text-destructive">
                This erases every wallet on this device. Make sure you've backed up your recovery phrase(s) first -
                this can't be undone.
              </p>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground px-0.5">Enter your PIN to confirm</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={wipePin}
                onChange={(e) => {
                  setWipePin(e.target.value.replace(/\D/g, ''));
                  setWipeError('');
                }}
                aria-label="Wallet PIN"
                className="paxi-field w-full p-3 text-center text-xl tracking-[0.5em] text-foreground"
                placeholder="••••••"
              />
              {wipeError && <p className="text-xs text-destructive px-0.5">{wipeError}</p>}
            </div>
            <button
              type="button"
              onClick={handleWipe}
              disabled={wipePin.length !== 6 || wiping}
              className="paxi-pressable min-h-12 w-full rounded-xl bg-destructive py-3 font-semibold text-white transition-all hover:bg-destructive/90 disabled:opacity-40"
            >
              {wiping ? 'Removing…' : 'Erase This Device'}
            </button>
            <button
              type="button"
              onClick={() => setShowWipeConfirm(false)}
              disabled={wiping}
              className="paxi-pressable min-h-11 w-full rounded-lg py-1 text-sm text-muted-foreground"
            >
              Cancel
            </button>
          </div>
        </DrawerContent>
      </Drawer>
    </div>
  );
}
