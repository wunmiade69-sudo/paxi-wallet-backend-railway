import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, RefreshCw, Trash2 } from 'lucide-react';
import { clearTxRecords, getTxRecords, type TxRecord } from '@/lib/wallet/txHistory';
import { getFullHistory, getHistoryStaleWhileRevalidate } from '@/lib/wallet/txIndexer';
import { getStoredAddress } from '@/lib/wallet/vault';
import TransactionList from '@/components/TransactionList';

interface TransactionHistoryScreenProps {
  onBack: () => void;
}

export default function TransactionHistoryScreen({ onBack }: TransactionHistoryScreenProps) {
  // Paint instantly with whatever's local, then swap in the cached (if any) and finally the
  // fresh merged (on-chain + resolved) view as each resolves.
  const [records, setRecords] = useState<TxRecord[]>(() => getTxRecords());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const address = getStoredAddress();

  // Fast path: cache-first, background refresh. Used on mount so repeat opens of this screen
  // don't sit on a spinner while Blockscout/RPC are slow.
  const loadFromCache = useCallback(() => {
    if (!address) return;
    const cached = getHistoryStaleWhileRevalidate(address, (fresh) => {
      setRecords(fresh.records);
      setIsRefreshing(false);
    });
    if (cached.length > 0) {
      setRecords(cached);
    } else {
      setIsRefreshing(true);
    }
  }, [address]);

  // Slow path: force a fresh fetch, used for the manual refresh button so it's an actual refresh.
  const loadFresh = useCallback(async () => {
    if (!address) return;
    setIsRefreshing(true);
    try {
      const full = await getFullHistory(address);
      setRecords(full);
    } finally {
      setIsRefreshing(false);
    }
  }, [address]);

  useEffect(() => {
    loadFromCache();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address]);

  const handleClear = () => {
    if (!confirmClear) {
      setConfirmClear(true);
      return;
    }
    clearTxRecords();
    setConfirmClear(false);
    loadFresh(); // on-chain records (like receives) aren't "cleared" - they're real chain history, so this just drops the local log
  };

  return (
    <div className="min-h-screen bg-background pb-10">
      <div className="sticky top-0 z-40 bg-secondary/50 backdrop-blur-xl border-b border-foreground/5">
        <div className="max-w-md mx-auto px-6 py-4 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-lg font-bold text-accent">Transaction Records</h1>
          <div className="flex items-center gap-3">
            <button
              onClick={loadFresh}
              className="text-muted-foreground hover:text-foreground transition-colors"
              title="Refresh"
              aria-label="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>
            {records.length > 0 && (
              <button
                onClick={handleClear}
                onBlur={() => setConfirmClear(false)}
                className={`flex items-center gap-1 text-xs font-medium transition-colors ${
                  confirmClear ? 'text-destructive' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Trash2 className="w-3.5 h-3.5" />
                {confirmClear ? 'Confirm?' : 'Clear'}
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-6">
        <p className="text-xs text-muted-foreground mb-4">
          Real on-chain history for Ethereum and BSC (sends, receives, swaps, bridges), plus this app's own record of
          what it broadcast. Bitcoin and Solana aren't indexed yet - no address to look up until those chains are
          supported.
        </p>
        {isRefreshing && records.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm">Loading transaction history…</div>
        ) : (
          <TransactionList records={records} />
        )}
      </div>
    </div>
  );
}
