import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { walletQueryClientDefaults } from "./lib/queryClientOptions";

const indexHtmlPath = fileURLToPath(new URL("../index.html", import.meta.url));
const scrollablePagePaths = [
  new URL("./pages/WelcomeScreen.tsx", import.meta.url),
  new URL("./pages/LoginScreen.tsx", import.meta.url),
  new URL("./pages/PINSetup.tsx", import.meta.url),
];

describe("wallet runtime resilience", () => {
  it("keeps document scrolling available and excludes the embedded developer console", () => {
    const html = readFileSync(indexHtmlPath, "utf8");

    expect(html).not.toMatch(/body\s*\{[^}]*overflow\s*:\s*hidden/i);
    expect(html).not.toContain("eruda.init");
    expect(html).not.toContain("cdn.jsdelivr.net/npm/eruda");
  });

  it("keeps onboarding and unlock screens vertically scrollable on short mobile viewports", () => {
    for (const pagePath of scrollablePagePaths) {
      const source = readFileSync(pagePath, "utf8");

      expect(source).toContain("overflow-x-hidden");
      expect(source).not.toMatch(/min-h-screen[^"`]*overflow-hidden/);
    }
  });

  it("does not repeatedly refetch optional data while users navigate the wallet", () => {
    expect(walletQueryClientDefaults.queries).toMatchObject({
      retry: 1,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
    });
    expect(walletQueryClientDefaults.mutations).toMatchObject({ retry: 0 });
  });
});
