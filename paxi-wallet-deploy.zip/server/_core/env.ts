const parsedTrustProxyHops = Number(process.env.TRUST_PROXY_HOPS ?? "0");
const trustProxyHops = Number.isFinite(parsedTrustProxyHops)
  ? Math.max(0, Math.min(Math.floor(parsedTrustProxyHops), 10))
  : 0;

export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  databaseReadUrl: process.env.DATABASE_READ_URL ?? process.env.DATABASE_REPLICA_URL ?? "",
  /** Optional - Redis is a cache/coordination layer, not a source of truth. Every Redis-backed feature must degrade gracefully (fall back to MySQL/in-process behavior) when this is unset. */
  redisUrl: process.env.REDIS_URL ?? "",
  redisRequired: process.env.REDIS_REQUIRED === "true",
  redisTlsRequired: process.env.REDIS_TLS_REQUIRED === "true",
  /** Background workers are opt-in; ordinary web/API operation must not start BullMQ by default. */
  workersEnabled: process.env.ENABLE_WORKERS === "true",
  /** Startup market prewarming remains enabled by default but can be disabled for isolated tests. */
  marketPrewarmEnabled: process.env.ENABLE_MARKET_PREWARM !== "false",
  metricsToken: process.env.METRICS_TOKEN ?? "",
  trustProxyHops,
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  /** Optional server-only LI.FI key; never prefix with VITE_ or expose it to the browser. */
  lifiApiKey: process.env.LIFI_API_KEY ?? "",
  /** Optional server-only Birdeye key for chain-specific token metadata and market fallbacks. */
  birdeyeApiKey: process.env.BIRDEYE_API_KEY ?? "",
  /** Optional server-only DexPaprika key for higher-limit DEX market fallbacks. */
  dexpaprikaApiKey: process.env.DEXPAPRIKA_API_KEY ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  /** Real object storage for production (S3, or R2/any S3-compatible service via s3Endpoint). */
  s3Bucket: process.env.S3_BUCKET ?? "",
  s3Region: process.env.S3_REGION ?? "auto",
  s3AccessKeyId: process.env.S3_ACCESS_KEY_ID ?? "",
  s3SecretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "",
  /** Only needed for R2/non-AWS S3-compatible providers - leave unset for real AWS S3. */
  s3Endpoint: process.env.S3_ENDPOINT ?? "",
  /**
   * Same EVM address receives fees on every EVM chain (per chains.ts, one
   * address across EVM networks) and is the server-owned source for all
   * PAXI fee payment verification and payment destinations.
   * Set PAXI_TREASURY_ADDRESS in your environment to override if needed.
   */
  paxiTreasuryAddress: process.env.PAXI_TREASURY_ADDRESS ?? "0x7f522D2639DE092d67668b5A2122bADA2d9B035f",
};
