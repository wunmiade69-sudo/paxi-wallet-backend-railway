import { and, desc, eq, gt, inArray, lt, sql } from "drizzle-orm";
import {
  activityEvents,
  type ActivityEvent,
  type InsertActivityEvent,
} from "../../drizzle/schema";
import { getReadDb, getDb } from "../db";

export const ACTIVITY_EVENT_TYPES = [
  "wallet_creation",
  "token_creation",
  "buy",
  "sell",
  "swap",
  "bridge",
  "send",
  "receive",
  "deposit",
  "withdrawal",
] as const;

export type ActivityEventType = (typeof ACTIVITY_EVENT_TYPES)[number];
export type ActivityStatus = "pending" | "confirmed" | "failed";
export const TRUSTED_ACTIVITY_SOURCES = ["server_semantic", "server_internal"] as const;

export interface ActivityStats {
  activeDays: number;
  totalEvents: number;
  eventCounts: Record<ActivityEventType, number>;
  volumeUsdByType: Record<ActivityEventType, string>;
  totalVolumeUsd: string;
  totalPaxiFeesUsd: string;
  totalNetworkFeesUsd: string;
  wallets: string[];
  chains: string[];
  firstActivityAtMs: number | null;
  lastActivityAtMs: number | null;
}

/** Server-owned time boundaries for evaluating a campaign's activity window. */
export interface ActivityStatsWindow {
  since?: Date;
  until?: Date;
}

export interface EligibilityPayload {
  version: "paxi-activity-v1";
  userOpenId: string;
  snapshotGeneratedAtMs: number;
  activeDays: number;
  totalConfirmedEvents: number;
  eventCounts: Record<ActivityEventType, number>;
  volumeUsdByType: Record<ActivityEventType, string>;
  totalVolumeUsd: string;
  totalPaxiFeesUsd: string;
  totalNetworkFeesUsd: string;
  wallets: string[];
  chains: string[];
  firstActivityAtMs: number | null;
  lastActivityAtMs: number | null;
}

export interface ActivityHistoryPage {
  items: Array<ActivityEvent & { createdAtMs: number }>;
  nextCursor: string | null;
}

const DECIMAL_PATTERN = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/;
const HASH_PATTERN = /^[A-Za-z0-9:_-]{1,128}$/;
const WALLET_PATTERN = /^[A-Za-z0-9._:-]{1,128}$/;

function emptyTypeMap<T>(value: T): Record<ActivityEventType, T> {
  return Object.fromEntries(ACTIVITY_EVENT_TYPES.map((type) => [type, value])) as Record<ActivityEventType, T>;
}

function assertUserOpenId(value: string): void {
  if (!value || value.length > 64) throw new Error("Invalid user identifier");
}

function assertActivityValue(value: string | null | undefined, field: string, maxLength: number): void {
  if (value == null) return;
  if (value.length > maxLength) throw new Error(`${field} is too long`);
}

function normalizeDecimal(value: string | null | undefined, field: string): string | null {
  if (value == null || value === "") return null;
  if (!DECIMAL_PATTERN.test(value)) throw new Error(`${field} must be a non-negative decimal with at most 18 fractional digits`);
  return value;
}

function validateEvent(event: InsertActivityEvent): void {
  assertUserOpenId(event.userOpenId);
  if (!WALLET_PATTERN.test(event.walletAddress)) throw new Error("Invalid wallet address");
  if (!/^[a-zA-Z0-9._:-]{1,32}$/.test(event.chainId)) throw new Error("Invalid chain identifier");
  if (!ACTIVITY_EVENT_TYPES.includes(event.eventType as ActivityEventType)) throw new Error("Invalid activity event type");
  if (event.transactionHash != null && !HASH_PATTERN.test(event.transactionHash)) throw new Error("Invalid transaction hash");
  assertActivityValue(event.amount, "amount", 128);
  assertActivityValue(event.amountUsd, "amountUsd", 32);
  assertActivityValue(event.feeUsd, "feeUsd", 32);
  assertActivityValue(event.networkFeeUsd, "networkFeeUsd", 32);
  assertActivityValue(event.paxiFeeUsd, "paxiFeeUsd", 32);
  normalizeDecimal(event.amount, "amount");
  normalizeDecimal(event.amountUsd, "amountUsd");
  normalizeDecimal(event.feeUsd, "feeUsd");
  normalizeDecimal(event.networkFeeUsd, "networkFeeUsd");
  normalizeDecimal(event.paxiFeeUsd, "paxiFeeUsd");
  if (event.createdAt && Number.isNaN(new Date(event.createdAt).getTime())) throw new Error("Invalid activity timestamp");
}

function toTimestampMs(value: Date | string | number | null | undefined): number | null {
  if (value == null) return null;
  const ms = value instanceof Date ? value.getTime() : new Date(value).getTime();
  return Number.isFinite(ms) ? ms : null;
}

function decimalString(value: unknown): string {
  if (value == null) return "0";
  return String(value);
}

function parseCursor(cursor: string | undefined): number | undefined {
  if (!cursor) return undefined;
  if (!/^\d{1,16}$/.test(cursor)) throw new Error("Invalid activity cursor");
  const parsed = Number(cursor);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) throw new Error("Invalid activity cursor");
  return parsed;
}

function trustedActivityConditions(userOpenId: string, window: ActivityStatsWindow = {}) {
  const conditions = [eq(activityEvents.userOpenId, userOpenId), eq(activityEvents.status, "confirmed"), inArray(activityEvents.verificationSource, [...TRUSTED_ACTIVITY_SOURCES])];
  if (window.since) conditions.push(gt(activityEvents.createdAt, window.since));
  if (window.until) conditions.push(lt(activityEvents.createdAt, window.until));
  return conditions;
}

function assertWindow(window: ActivityStatsWindow): void {
  if (window.since && Number.isNaN(window.since.getTime())) throw new Error("Invalid since date");
  if (window.until && Number.isNaN(window.until.getTime())) throw new Error("Invalid until date");
  if (window.since && window.until && window.until <= window.since) throw new Error("Eligibility end date must be after start date");
}

/**
 * Records a server-trusted activity event. The unique key makes retries safe
 * when a transaction completion webhook or worker is delivered more than once.
 */
export async function recordActivity(event: InsertActivityEvent): Promise<ActivityEvent> {
  validateEvent(event);
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (event.transactionHash) {
    const existing = await db
      .select()
      .from(activityEvents)
      .where(
        and(
          eq(activityEvents.userOpenId, event.userOpenId),
          eq(activityEvents.walletAddress, event.walletAddress),
          eq(activityEvents.chainId, event.chainId),
          eq(activityEvents.transactionHash, event.transactionHash),
          eq(activityEvents.eventType, event.eventType),
        ),
      )
      .limit(1);
    if (existing[0]) return existing[0];
  }

  const values: InsertActivityEvent = {
    ...event,
    amount: normalizeDecimal(event.amount, "amount"),
    amountUsd: normalizeDecimal(event.amountUsd, "amountUsd"),
    feeUsd: normalizeDecimal(event.feeUsd, "feeUsd"),
    networkFeeUsd: normalizeDecimal(event.networkFeeUsd, "networkFeeUsd"),
    paxiFeeUsd: normalizeDecimal(event.paxiFeeUsd, "paxiFeeUsd"),
    createdAt: event.createdAt ?? new Date(),
  };

  try {
    const result = await db.insert(activityEvents).values(values);
    const insertedId = Number((result as unknown as { insertId?: number | string }).insertId);
    if (!Number.isSafeInteger(insertedId) || insertedId <= 0) throw new Error("Activity insert did not return an id");
    const inserted = await db.select().from(activityEvents).where(eq(activityEvents.id, insertedId)).limit(1);
    if (!inserted[0]) throw new Error("Activity insert could not be reloaded");
    return inserted[0];
  } catch (error) {
    // A concurrent retry may win the unique key between the initial lookup and insert.
    if (event.transactionHash) {
      const concurrent = await db
        .select()
        .from(activityEvents)
        .where(
          and(
            eq(activityEvents.userOpenId, event.userOpenId),
            eq(activityEvents.walletAddress, event.walletAddress),
            eq(activityEvents.chainId, event.chainId),
            eq(activityEvents.transactionHash, event.transactionHash),
            eq(activityEvents.eventType, event.eventType),
          ),
        )
        .limit(1);
      if (concurrent[0]) return concurrent[0];
    }
    throw error;
  }
}

export async function getActiveDays(userOpenId: string, window: ActivityStatsWindow = {}): Promise<number> {
  assertUserOpenId(userOpenId);
  assertWindow(window);
  const db = await getReadDb();
  if (!db) return 0;

  const conditions = trustedActivityConditions(userOpenId, window);
  const rows = await db
    .select({ day: sql<string>`DATE(${activityEvents.createdAt})` })
    .from(activityEvents)
    .where(and(...conditions))
    .groupBy(sql`DATE(${activityEvents.createdAt})`);
  return rows.length;
}

export async function getActivityStats(userOpenId: string, window: ActivityStatsWindow = {}): Promise<ActivityStats> {
  assertUserOpenId(userOpenId);
  assertWindow(window);
  const db = await getReadDb();
  if (!db) {
    return {
      activeDays: 0,
      totalEvents: 0,
      eventCounts: emptyTypeMap(0),
      volumeUsdByType: emptyTypeMap("0"),
      totalVolumeUsd: "0",
      totalPaxiFeesUsd: "0",
      totalNetworkFeesUsd: "0",
      wallets: [],
      chains: [],
      firstActivityAtMs: null,
      lastActivityAtMs: null,
    };
  }

  const conditions = trustedActivityConditions(userOpenId, window);
  const [summary, counts, volumes, wallets, chains] = await Promise.all([
    db
      .select({
        totalEvents: sql<number>`COUNT(*)`,
        totalVolumeUsd: sql<string>`COALESCE(SUM(CAST(COALESCE(${activityEvents.amountUsd}, '0') AS DECIMAL(38,18))), 0)`,
        totalPaxiFeesUsd: sql<string>`COALESCE(SUM(CAST(COALESCE(${activityEvents.paxiFeeUsd}, '0') AS DECIMAL(38,18))), 0)`,
        totalNetworkFeesUsd: sql<string>`COALESCE(SUM(CAST(COALESCE(${activityEvents.networkFeeUsd}, '0') AS DECIMAL(38,18))), 0)`,
        firstActivityAt: sql<Date | null>`MIN(${activityEvents.createdAt})`,
        lastActivityAt: sql<Date | null>`MAX(${activityEvents.createdAt})`,
      })
      .from(activityEvents)
      .where(and(...conditions)),
    db
      .select({ eventType: activityEvents.eventType, count: sql<number>`COUNT(*)` })
      .from(activityEvents)
      .where(and(...conditions))
      .groupBy(activityEvents.eventType),
    db
      .select({ eventType: activityEvents.eventType, volumeUsd: sql<string>`COALESCE(SUM(CAST(COALESCE(${activityEvents.amountUsd}, '0') AS DECIMAL(38,18))), 0)` })
      .from(activityEvents)
      .where(and(...conditions))
      .groupBy(activityEvents.eventType),
    db
      .selectDistinct({ walletAddress: activityEvents.walletAddress })
      .from(activityEvents)
      .where(and(...conditions)),
    db
      .selectDistinct({ chainId: activityEvents.chainId })
      .from(activityEvents)
      .where(and(...conditions)),
  ]);

  const eventCounts = emptyTypeMap(0);
  for (const row of counts) eventCounts[row.eventType as ActivityEventType] = Number(row.count);
  const volumeUsdByType = emptyTypeMap("0");
  for (const row of volumes) volumeUsdByType[row.eventType as ActivityEventType] = decimalString(row.volumeUsd);
  const activeDays = await getActiveDays(userOpenId, window);
  const firstActivityAtMs = toTimestampMs(summary[0]?.firstActivityAt);
  const lastActivityAtMs = toTimestampMs(summary[0]?.lastActivityAt);

  return {
    activeDays,
    totalEvents: Number(summary[0]?.totalEvents ?? 0),
    eventCounts,
    volumeUsdByType,
    totalVolumeUsd: decimalString(summary[0]?.totalVolumeUsd),
    totalPaxiFeesUsd: decimalString(summary[0]?.totalPaxiFeesUsd),
    totalNetworkFeesUsd: decimalString(summary[0]?.totalNetworkFeesUsd),
    wallets: wallets.map((row) => row.walletAddress),
    chains: chains.map((row) => row.chainId),
    firstActivityAtMs,
    lastActivityAtMs,
  };
}

export async function listActivityHistory(
  userOpenId: string,
  options: { limit?: number; cursor?: string } = {},
): Promise<ActivityHistoryPage> {
  assertUserOpenId(userOpenId);
  const limit = Math.min(Math.max(Math.trunc(options.limit ?? 50), 1), 100);
  const cursor = parseCursor(options.cursor);
  const db = await getReadDb();
  if (!db) return { items: [], nextCursor: null };

  const conditions = [eq(activityEvents.userOpenId, userOpenId)];
  if (cursor) conditions.push(lt(activityEvents.id, cursor));
  const rows = await db
    .select()
    .from(activityEvents)
    .where(and(...conditions))
    .orderBy(desc(activityEvents.id))
    .limit(limit + 1);

  const hasMore = rows.length > limit;
  const pageRows = hasMore ? rows.slice(0, limit) : rows;
  return {
    items: pageRows.map((row) => ({ ...row, createdAtMs: row.createdAt.getTime() })),
    nextCursor: hasMore ? String(pageRows[pageRows.length - 1]?.id ?? "") : null,
  };
}

export async function exportActivityForEligibility(userOpenId: string): Promise<EligibilityPayload> {
  const stats = await getActivityStats(userOpenId);
  return {
    version: "paxi-activity-v1",
    userOpenId,
    snapshotGeneratedAtMs: Date.now(),
    activeDays: stats.activeDays,
    totalConfirmedEvents: stats.totalEvents,
    eventCounts: stats.eventCounts,
    volumeUsdByType: stats.volumeUsdByType,
    totalVolumeUsd: stats.totalVolumeUsd,
    totalPaxiFeesUsd: stats.totalPaxiFeesUsd,
    totalNetworkFeesUsd: stats.totalNetworkFeesUsd,
    wallets: stats.wallets,
    chains: stats.chains,
    firstActivityAtMs: stats.firstActivityAtMs,
    lastActivityAtMs: stats.lastActivityAtMs,
  };
}
