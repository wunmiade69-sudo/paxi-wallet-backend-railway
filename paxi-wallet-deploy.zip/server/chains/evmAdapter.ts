import { formatEther, getAddress, JsonRpcProvider } from "ethers";
import type { ChainAdapter } from "./types";
import { getCircuitBreaker } from "../resilience/circuitBreaker";

export interface EvmNetworkDefinition {
  network: string;
  chainId: number;
  nativeSymbol: string;
  rpcUrl: string;
  explorer: string;
}

export class EvmAdapter implements ChainAdapter {
  readonly family = "evm" as const;

  constructor(private readonly definition: EvmNetworkDefinition) {}

  get network(): string {
    return this.definition.network;
  }

  get nativeSymbol(): string {
    return this.definition.nativeSymbol;
  }

  get rpcUrl(): string {
    return this.definition.rpcUrl;
  }

  normalizeIdentifier(identifier: string): string {
    const value = String(identifier).trim();
    try {
      return getAddress(value);
    } catch {
      return value.toLowerCase();
    }
  }

  validateIdentifier(identifier: string): boolean {
    try {
      getAddress(identifier);
      return true;
    } catch {
      return false;
    }
  }

  async getNativeBalance(address: string): Promise<string> {
    const normalized = this.normalizeIdentifier(address);
    if (!this.validateIdentifier(normalized)) throw new Error(`Invalid ${this.network} address`);
    const provider = new JsonRpcProvider(this.rpcUrl, this.definition.chainId, { staticNetwork: true });
    const breaker = getCircuitBreaker(`rpc-${this.network}`, { failureThreshold: 5, resetTimeoutMs: 15_000 });
    const balance = await breaker.execute(() => provider.getBalance(normalized));
    return formatEther(balance);
  }

  getExplorerUrl(kind: "tx" | "address", value: string): string {
    return `${this.definition.explorer}/${kind === "tx" ? "tx" : "address"}/${encodeURIComponent(value)}`;
  }
}
