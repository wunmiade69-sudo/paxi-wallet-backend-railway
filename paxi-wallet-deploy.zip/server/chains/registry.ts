import { BitcoinAdapter } from "./bitcoinAdapter";
import { EvmAdapter } from "./evmAdapter";
import { SolanaAdapter } from "./solanaAdapter";
import { UnsupportedNetworkError, type ChainAdapter } from "./types";

const adapters: Record<string, ChainAdapter> = {
  ethereum: new EvmAdapter({
    network: "ethereum",
    chainId: 1,
    nativeSymbol: "ETH",
    rpcUrl: "https://ethereum-rpc.publicnode.com",
    explorer: "https://etherscan.io",
  }),
  bsc: new EvmAdapter({
    network: "bsc",
    chainId: 56,
    nativeSymbol: "BNB",
    rpcUrl: "https://bsc-rpc.publicnode.com",
    explorer: "https://bscscan.com",
  }),
  polygon: new EvmAdapter({
    network: "polygon",
    chainId: 137,
    nativeSymbol: "POL",
    rpcUrl: "https://polygon-bor-rpc.publicnode.com",
    explorer: "https://polygonscan.com",
  }),
  arbitrum: new EvmAdapter({
    network: "arbitrum",
    chainId: 42161,
    nativeSymbol: "ETH",
    rpcUrl: "https://arbitrum-one-rpc.publicnode.com",
    explorer: "https://arbiscan.io",
  }),
  solana: new SolanaAdapter(),
  bitcoin: new BitcoinAdapter(),
};

export function getChainAdapter(network: string): ChainAdapter {
  const adapter = adapters[network];
  if (!adapter) throw new UnsupportedNetworkError(network);
  return adapter;
}

export function listChainAdapters() {
  return Object.values(adapters).map((adapter) => ({
    network: adapter.network,
    family: adapter.family,
    nativeSymbol: adapter.nativeSymbol,
    rpcUrl: adapter.rpcUrl ?? null,
  }));
}
