import { Connection, PublicKey } from "@solana/web3.js";
import type { ChainAdapter } from "./types";
import { getCircuitBreaker } from "../resilience/circuitBreaker";

export class SolanaAdapter implements ChainAdapter {
  readonly network = "solana";
  readonly family = "solana" as const;
  readonly nativeSymbol = "SOL";

  constructor(readonly rpcUrl = "https://solana-rpc.publicnode.com") {}

  normalizeIdentifier(identifier: string): string {
    return identifier.trim();
  }

  validateIdentifier(identifier: string): boolean {
    try {
      new PublicKey(identifier);
      return true;
    } catch {
      return false;
    }
  }

  async getNativeBalance(address: string): Promise<string> {
    const normalized = this.normalizeIdentifier(address);
    if (!this.validateIdentifier(normalized)) throw new Error("Invalid Solana address");
    const breaker = getCircuitBreaker("rpc-solana", { failureThreshold: 5, resetTimeoutMs: 15_000 });
    const lamports = await breaker.execute(() => new Connection(this.rpcUrl, "confirmed").getBalance(new PublicKey(normalized)));
    return (lamports / 1_000_000_000).toString();
  }

  getExplorerUrl(kind: "tx" | "address", value: string): string {
    return `https://explorer.solana.com/${kind === "tx" ? "tx" : "address"}/${encodeURIComponent(value)}`;
  }
}
