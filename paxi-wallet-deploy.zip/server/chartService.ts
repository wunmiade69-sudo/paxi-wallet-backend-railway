import { and, desc, eq, sql } from "drizzle-orm";
import { candles, liquidityPools, markets } from "../drizzle/schema";
import { normalizeIdentifier } from "./assetRegistry";
import { getMarketProvider, marketProviders } from "./providers";
import { timestampMs, type ProviderOhlcv } from "./providers/types";
import { getCachedChartData, setCachedChartData } from "./redis";
import { CoinGeckoAdapter } from "./providers/coinGecko";

export const CHART_TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d"] as const;
export type ChartTimeframe = (typeof CHART_TIMEFRAMES)[number];

export interface ChartCandle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number | null;
  source: string;
  fallback: boolean;
}

export interface ChartResult {
  candles: ChartCandle[];
  source: string;
  fallback: boolean;
  requestedLimit: number;
  returned: number;
  generatedAt: number;
}

type ChartDb = NonNullable<Awaited<ReturnType<typeof import("./db").getReadDb>>>;

const NATIVE_COINGECKO_IDS: Record<string, string> = {
  bitcoin: "bitcoin",
  ethereum: "ethereum",
  bsc: "binancecoin",
  solana: "solana",
  polygon: "polygon-ecosystem-token",
  arbitrum: "ethereum", // Arbitrum native is ETH
};

const NATIVE_BINANCE_SYMBOLS: Record<string, string> = {
  bitcoin: "BTCUSDT",
  ethereum: "ETHUSDT",
  bsc: "BNBUSDT",
  solana: "SOLUSDT",
  polygon: "POLUSDT",
  arbitrum: "ETHUSDT",
};

const BINANCE_INTERVALS: Record<ChartTimeframe, string> = {
  "1m": "1m",
  "5m": "5m",
  "15m": "15m",
  "30m": "30m",
  "1h": "1h",
  "4h": "4h",
  "1d": "1d",
};

function finiteNumber(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeProviderCandle(row: ProviderOhlcv, fallback: boolean): ChartCandle | null {
  const open = finiteNumber(row.open);
  const high = finiteNumber(row.high);
  const low = finiteNumber(row.low);
  const close = finiteNumber(row.close);
  if (open === null || high === null || low === null || close === null) return null;

  return {
    timestamp: timestampMs(row.timestamp),
    open,
    high,
    low,
    close,
    volume: finiteNumber(row.volume),
    source: row.source,
    fallback,
  };
}

function normalizeInternalCandle(row: typeof candles.$inferSelect): ChartCandle | null {
  const open = finiteNumber(row.open);
  const high = finiteNumber(row.high);
  const low = finiteNumber(row.low);
  const close = finiteNumber(row.close);
  if (open === null || high === null || low === null || close === null) return null;

  return {
    timestamp: timestampMs(row.timestamp),
    open,
    high,
    low,
    close,
    volume: finiteNumber(row.volume),
    source: "internal",
    fallback: false,
  };
}

export function getProviderCandleLimit(limit: number): number {
  return Math.ceil(Math.max(1, limit) * 1.25);
}

function dedupeAndLimit(rows: ChartCandle[], limit: number): ChartCandle[] {
  const byTimestamp = new Map<number, ChartCandle>();
  for (const row of rows) {
    if (!Number.isFinite(row.timestamp) || row.timestamp <= 0) continue;
    byTimestamp.set(row.timestamp, row);
  }
  return [...byTimestamp.values()]
    .sort((left, right) => left.timestamp - right.timestamp)
    .slice(-limit);
}

export function mergeChartCandles(providerCandles: ChartCandle[], internalCandles: ChartCandle[], limit: number): ChartCandle[] {
  return dedupeAndLimit([...providerCandles, ...internalCandles], limit);
}

/**
 * Liquidity/volume aware pair selection. Prefers active pools with the highest 
 * liquidity to ensure chart accuracy.
 */
async function findPairAddress(db: ChartDb, assetId: number): Promise<string | null> {
  const [row] = await db
    .select({ poolAddress: liquidityPools.poolAddress })
    .from(markets)
    .innerJoin(liquidityPools, eq(markets.poolId, liquidityPools.id))
    .where(and(eq(markets.assetId, assetId), eq(markets.status, "active")))
    .orderBy(
      desc(sql`CAST(${liquidityPools.liquidityUsd} AS DECIMAL(36,18))`),
      desc(sql`CAST(${liquidityPools.volume24hUsd} AS DECIMAL(36,18))`),
      desc(markets.updatedAt)
    )
    .limit(1);
  return row?.poolAddress ?? null;
}

async function loadBinanceNativeCandles(chainId: string, timeframe: ChartTimeframe, limit: number): Promise<ChartCandle[]> {
  const symbol = NATIVE_BINANCE_SYMBOLS[chainId.toLowerCase()];
  if (!symbol) return [];
  try {
    const response = await fetch(
      `https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${BINANCE_INTERVALS[timeframe]}&limit=${Math.min(Math.max(limit, 1), 1000)}`,
      { signal: AbortSignal.timeout(8000) }
    );
    if (!response.ok) return [];
    const rows = (await response.json()) as Array<Array<string | number>>;
    return dedupeAndLimit(
      rows
        .map((row): ChartCandle | null => {
          const timestamp = timestampMs(row[0]);
          const open = finiteNumber(row[1]);
          const high = finiteNumber(row[2]);
          const low = finiteNumber(row[3]);
          const close = finiteNumber(row[4]);
          const volume = finiteNumber(row[5]);
          if (open === null || high === null || low === null || close === null) return null;
          return { timestamp, open, high, low, close, volume, source: "binance", fallback: false };
        })
        .filter((row): row is ChartCandle => row !== null),
      limit
    );
  } catch {
    return [];
  }
}

async function loadProviderCandles(
  chainId: string,
  tokenAddress: string,
  pairAddress: string | null,
  timeframe: ChartTimeframe,
  limit: number,
): Promise<{ candles: ChartCandle[]; source: string } | null> {
  // Request 25% more candles to compensate for overlap and deduplication gaps
  const providerLimit = getProviderCandleLimit(limit);

  // Native assets have no reliable DEX pair address. Binance provides live
  // OHLCV candles for the supported majors and is preferred over CoinGecko's
  // price-only history for this path.
  if (tokenAddress === "native") {
    const nativeCandles = await loadBinanceNativeCandles(chainId, timeframe, providerLimit);
    if (nativeCandles.length > 0) return { candles: nativeCandles, source: "binance" };
  }
  
  const orderedProviders = [
    getMarketProvider("geckoterminal"),
    ...marketProviders.filter((provider) => provider.name !== "geckoterminal" && provider.name !== "coingecko"),
  ].filter(Boolean);

  // 1. Try DEX providers first
  for (const provider of orderedProviders) {
    if (!provider?.getOhlcv) continue;
    try {
      let resolvedPairAddress = pairAddress;
      if (!resolvedPairAddress) {
        const marketsForToken = await provider.getMarketsForToken(chainId, tokenAddress);
        // Score pairs by liquidity if the provider returns it
        const bestPair = marketsForToken
          .sort((a, b) => (b.liquidityUsd ?? 0) - (a.liquidityUsd ?? 0))
          .find((market) => market.pairAddress);
        resolvedPairAddress = bestPair?.pairAddress ?? null;
      }
      if (!resolvedPairAddress) continue;

      const rows = await provider.getOhlcv(chainId, resolvedPairAddress, timeframe, providerLimit);
      const normalized = dedupeAndLimit(
        rows.map((row) => normalizeProviderCandle(row, true)).filter((row): row is ChartCandle => row !== null),
        providerLimit,
      );
      if (normalized.length > 0) return { candles: normalized, source: provider.name };
    } catch (error) {
      console.warn(`[chart-service] ${provider.name} OHLCV fallback failed`, error);
    }
  }

  // 2. Try CoinGecko as the universal fallback
  const coingecko = getMarketProvider("coingecko") as CoinGeckoAdapter | undefined;
  if (coingecko) {
    try {
      // For native assets, use the specialized native lookup
      if (tokenAddress === "native") {
        const coinId = NATIVE_COINGECKO_IDS[chainId];
        if (coinId) {
          const rows = await coingecko.getNativeOhlcv(coinId, timeframe, providerLimit);
          const normalized = dedupeAndLimit(
            rows.map((row) => normalizeProviderCandle(row, true)).filter((row): row is ChartCandle => row !== null),
            providerLimit,
          );
          if (normalized.length > 0) return { candles: normalized, source: "coingecko" };
        }
      } else {
        // For tokens, use contract lookup
        const rows = await coingecko.getOhlcv(chainId, tokenAddress, timeframe, providerLimit);
        const normalized = dedupeAndLimit(
          rows.map((row) => normalizeProviderCandle(row, true)).filter((row): row is ChartCandle => row !== null),
          providerLimit,
        );
        if (normalized.length > 0) return { candles: normalized, source: "coingecko" };
      }
    } catch (error) {
      console.warn(`[chart-service] coingecko fallback failed`, error);
    }
  }

  return null;
}

export async function getChartData(options: {
  db: ChartDb;
  assetId: number;
  chainId: string;
  tokenAddress: string;
  timeframe: ChartTimeframe;
  limit: number;
}): Promise<ChartResult> {
  const { db, assetId, chainId, tokenAddress, timeframe, limit } = options;
  const normalizedAddress = normalizeIdentifier(chainId, tokenAddress);
  const cacheKey = `${chainId.toLowerCase()}:${normalizedAddress}:${timeframe}:${limit}`;
  const cached = await getCachedChartData(cacheKey);
  if (cached) {
    return { ...cached, candles: cached.candles as ChartCandle[] };
  }

  const internalRows = await db
    .select()
    .from(candles)
    .where(and(eq(candles.assetId, assetId), eq(candles.timeframe, timeframe)))
    .orderBy(desc(candles.timestamp))
    .limit(limit);
  const internalCandles = dedupeAndLimit(
    internalRows.map(normalizeInternalCandle).filter((row): row is ChartCandle => row !== null),
    limit,
  );

  let result: ChartResult;
  if (internalCandles.length >= limit) {
    result = {
      candles: internalCandles,
      source: "internal",
      fallback: false,
      requestedLimit: limit,
      returned: internalCandles.length,
      generatedAt: Date.now(),
    };
  } else {
    const pairAddress = tokenAddress === "native" ? null : await findPairAddress(db, assetId);
    const providerResult = await loadProviderCandles(chainId, normalizedAddress, pairAddress, timeframe, limit);
    const merged = providerResult
      ? mergeChartCandles(providerResult.candles, internalCandles, limit)
      : internalCandles;
    const sources = [...new Set(merged.map((row) => row.source))];
    result = {
      candles: merged,
      source: sources.length > 0 ? sources.join("+") : "none",
      fallback: merged.some((row) => row.fallback),
      requestedLimit: limit,
      returned: merged.length,
      generatedAt: Date.now(),
    };
  }

  await setCachedChartData(cacheKey, timeframe, result);
  return result;
}
