import { ethers } from "ethers";
import { ENV } from "./_core/env";
import { getCircuitBreaker } from "./resilience/circuitBreaker";

/**
 * Public RPC per EVM network we accept fees/tasks on, plus that network's
 * USDT/USDC contract addresses (fees must be paid in one of these - see note
 * below about why native-currency fees aren't supported yet).
 * Mirrors the `id`s in client/src/lib/wallet/chains.ts - keep in sync if you
 * add a network there.
 */
const FEE_NETWORKS: Record<string, { rpcUrl: string; stablecoins: Record<string, { address: string; decimals: number }> }> = {
  ethereum: {
    rpcUrl: "https://ethereum-rpc.publicnode.com",
    stablecoins: {
      USDT: { address: "0xdAC17F958D2ee523a2206206994597C13D831ec", decimals: 6 },
      USDC: { address: "0xA0b86991c6218b36c1d19D4A2e9Eb0cE3606eB48", decimals: 6 },
    },
  },
  bsc: {
    rpcUrl: "https://bsc-rpc.publicnode.com",
    stablecoins: {
      USDT: { address: "0x55d398326f99059fF775485246999027B3197955", decimals: 18 },
      USDC: { address: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", decimals: 18 },
    },
  },
};

const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const ERC20_DECIMALS_ABI = ["function decimals() view returns (uint8)"];
const TOKEN_FACTORY_ADDRESSES: Record<string, string> = {
  bsc: process.env.PAXI_BSC_FACTORY_ADDRESS ?? "0xc913e259eeef3d4623900b05e8a8ab6a496b9ef2",
};
const USD_PATTERN = /^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/;
const TOKEN_CREATED_TOPIC = ethers.id("TokenCreated(address,address,string,string,uint256,uint256)");
const TOKEN_CREATED_INTERFACE = new ethers.Interface([
  "event TokenCreated(address indexed tokenAddress,address indexed creator,string name,string symbol,uint256 supply,uint256 feePaid)",
]);

export type FeeVerificationResult = { ok: true } | { ok: false; reason: string };

function getProvider(network: string): { provider: ethers.JsonRpcProvider; cfg: (typeof FEE_NETWORKS)[string] } | null {
  const cfg = FEE_NETWORKS[network];
  if (!cfg) return null;
  const request = new ethers.FetchRequest(cfg.rpcUrl);
  request.timeout = 8_000;
  return { provider: new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 }), cfg };
}

function addressFromTopic(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`).toLowerCase();
  } catch {
    return null;
  }
}

function isTransactionHash(value: string): boolean {
  return ethers.isHexString(value, 32);
}

function transferAmount(data: string): bigint | null {
  try {
    return BigInt(data);
  } catch {
    return null;
  }
}

function usdToUnits(minUsd: string, decimals: number): bigint {
  if (!USD_PATTERN.test(minUsd)) throw new Error("Invalid USD amount");
  const [whole, fraction = ""] = minUsd.split(".");
  if (fraction.length > decimals) throw new Error("USD amount has too many fractional digits");
  const scale = 10n ** BigInt(decimals);
  const fractionalUnits = BigInt(fraction.padEnd(decimals, "0") || "0");
  return BigInt(whole) * scale + fractionalUnits;
}

async function getReceipt(network: string, provider: ethers.JsonRpcProvider, txHash: string): Promise<ethers.TransactionReceipt | null> {
  const breaker = getCircuitBreaker(`fee-rpc-${network}`, { failureThreshold: 3, resetTimeoutMs: 30_000 });
  return breaker.execute(() => provider.getTransactionReceipt(txHash));
}

/**
 * Confirms `txHash` is a real, already-mined USDT or USDC transfer of at
 * least `minUsd` to the Paxi treasury address, on the given network.
 * Used for listing fees, creation fees, and campaign pool funding.
 * Never trust a client-supplied tx hash for anything financial without this.
 */
export async function verifyFeePayment(network: string, txHash: string, minUsd: string): Promise<FeeVerificationResult> {
  const net = getProvider(network);
  if (!net) return { ok: false, reason: `Fee payments aren't supported on "${network}" yet.` };
  if (!isTransactionHash(txHash)) return { ok: false, reason: "Invalid transaction hash." };
  const [wholeUsd] = minUsd.split(".");
  if (!USD_PATTERN.test(minUsd) || BigInt(wholeUsd || "0") <= 0n || BigInt(wholeUsd || "0") > 100_000_000n) {
    return { ok: false, reason: "Invalid fee amount." };
  }
  if (!ENV.paxiTreasuryAddress || !ethers.isAddress(ENV.paxiTreasuryAddress)) return { ok: false, reason: "Treasury address not configured on the server." };

  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await getReceipt(network, net.provider, txHash);
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify that transaction." };
  }
  if (!receipt) return { ok: false, reason: "Transaction not found (or not confirmed yet)." };
  if (receipt.status !== 1) return { ok: false, reason: "That transaction failed on-chain." };

  const stablecoins = Object.values(net.cfg.stablecoins);
  const treasury = ENV.paxiTreasuryAddress.toLowerCase();

  for (const log of receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC) continue;
    const stablecoin = stablecoins.find((candidate) => candidate.address.toLowerCase() === log.address.toLowerCase());
    if (!stablecoin) continue;
    if (addressFromTopic(log.topics[2]) !== treasury) continue;
    const amount = transferAmount(log.data);
    if (amount != null && amount >= usdToUnits(minUsd, stablecoin.decimals)) return { ok: true };
  }

  return { ok: false, reason: `No USDT/USDC transfer of at least $${minUsd} to the Paxi address was found in that transaction.` };
}

/**
 * Confirms `txHash` is a real, mined, successful transaction sent BY
 * `walletAddress` that transferred at least `minHumanAmount` units of
 * `tokenContractAddress` (human units, e.g. "50", not raw base units -
 * decimals are looked up on-chain). Used for campaign task proof
 * ("trade at least X of this token").
 *
 * LIMITATION: this only proves *a* transfer of that size happened in a tx
 * the wallet signed - it can't fully distinguish "swapped through Paxi" from
 * "sent tokens to a friend". Good enough as an anti-fake-entry check for a
 * launch; if campaigns get valuable enough to attract abuse, tighten this to
 * also require the tx `to` address matches Paxi's known swap router/aggregator
 * contract for that network.
 */
/**
 * Verifies the deployment half of Create Token: a confirmed transaction from
 * the authenticated wallet to Paxi's configured factory that emitted a
 * TokenCreated event for the claimed token address.
 */
export async function verifyTokenDeployment(
  network: string,
  txHash: string,
  walletAddress: string,
  tokenAddress: string,
): Promise<FeeVerificationResult> {
  const net = getProvider(network);
  const factoryAddress = TOKEN_FACTORY_ADDRESSES[network];
  if (!net || !factoryAddress) return { ok: false, reason: `Token creation isn't supported on "${network}".` };
  if (!isTransactionHash(txHash) || !ethers.isAddress(walletAddress) || !ethers.isAddress(tokenAddress)) {
    return { ok: false, reason: "Invalid deployment transaction or wallet address." };
  }

  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await getReceipt(network, net.provider, txHash);
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify the deployment transaction." };
  }
  if (!receipt) return { ok: false, reason: "Deployment transaction not found (or not confirmed yet)." };
  if (receipt.status !== 1) return { ok: false, reason: "The token deployment transaction failed on-chain." };
  if (!receipt.from || receipt.from.toLowerCase() !== walletAddress.toLowerCase()) {
    return { ok: false, reason: "The deployment transaction wasn't sent from the wallet on your account." };
  }
  if (!receipt.to || receipt.to.toLowerCase() !== factoryAddress.toLowerCase()) {
    return { ok: false, reason: "The deployment transaction did not call Paxi's configured token factory." };
  }

  const expectedToken = tokenAddress.toLowerCase();
  const expectedCreator = walletAddress.toLowerCase();
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() !== factoryAddress.toLowerCase() || log.topics[0] !== TOKEN_CREATED_TOPIC) continue;
    const emittedToken = addressFromTopic(log.topics[1]);
    const emittedCreator = addressFromTopic(log.topics[2]);
    if (emittedToken !== expectedToken || emittedCreator !== expectedCreator) continue;
    try {
      const parsed = TOKEN_CREATED_INTERFACE.parseLog({ topics: log.topics, data: log.data });
      const feePaid = parsed?.args[5] as bigint | undefined;
      if (feePaid !== 0n) return { ok: false, reason: "The factory still charges an on-chain fee; disable it before using the backend fee flow." };
    } catch {
      return { ok: false, reason: "The matching TokenCreated event could not be decoded." };
    }
    return { ok: true };
  }
  return { ok: false, reason: "The deployment transaction did not emit a matching TokenCreated event." };
}

export async function verifyTokenTransferProof(
  network: string,
  txHash: string,
  tokenContractAddress: string,
  walletAddress: string,
  minHumanAmount: string,
): Promise<FeeVerificationResult> {
  const net = getProvider(network);
  if (!net) return { ok: false, reason: `"${network}" isn't supported for task verification yet.` };
  if (!isTransactionHash(txHash) || !ethers.isAddress(tokenContractAddress) || !ethers.isAddress(walletAddress)) {
    return { ok: false, reason: "Invalid transaction, token, or wallet address." };
  }
  if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(minHumanAmount) || Number(minHumanAmount) <= 0) {
    return { ok: false, reason: "Invalid required token amount." };
  }

  let receipt: ethers.TransactionReceipt | null;
  try {
    receipt = await getReceipt(network, net.provider, txHash);
  } catch {
    return { ok: false, reason: "Couldn't reach the network to verify that transaction." };
  }
  if (!receipt) return { ok: false, reason: "Transaction not found (or not confirmed yet)." };
  if (receipt.status !== 1) return { ok: false, reason: "That transaction failed on-chain." };
  if (receipt.from.toLowerCase() !== walletAddress.toLowerCase()) {
    return { ok: false, reason: "That transaction wasn't sent from the wallet address on your account." };
  }

  let decimals = 18;
  try {
    const token = new ethers.Contract(tokenContractAddress, ERC20_DECIMALS_ABI, net.provider);
    const breaker = getCircuitBreaker(`fee-rpc-${network}`, { failureThreshold: 3, resetTimeoutMs: 30_000 });
    decimals = Number(await breaker.execute(() => token.decimals()));
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36) throw new Error("invalid decimals");
  } catch {
    return { ok: false, reason: "Couldn't read the task token's contract - check the address." };
  }

  let minUnits: bigint;
  try {
    minUnits = ethers.parseUnits(minHumanAmount, decimals);
  } catch {
    return { ok: false, reason: "Invalid required token amount." };
  }
  const wallet = walletAddress.toLowerCase();
  const tokenAddr = tokenContractAddress.toLowerCase();

  for (const log of receipt.logs) {
    if (log.topics[0] !== TRANSFER_TOPIC) continue;
    if (log.address.toLowerCase() !== tokenAddr) continue;
    const from = addressFromTopic(log.topics[1]);
    const to = addressFromTopic(log.topics[2]);
    if (from == null || to == null || (from !== wallet && to !== wallet)) continue;
    const amount = transferAmount(log.data);
    if (amount != null && amount >= minUnits) return { ok: true };
  }

  return { ok: false, reason: `That transaction doesn't show a transfer of at least ${minHumanAmount} of this token.` };
}
