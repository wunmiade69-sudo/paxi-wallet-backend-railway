import { redisSafe } from "../redis";

export type FeeOperation = "swap_evm" | "swap_btc" | "bridge" | "create_token" | "listing";

export interface DefaultFeeConfig {
  operation: FeeOperation;
  chainType: string;
  percentageBps: number;
  fixedUsd: string;
}

/**
 * Server-side seed values. These are not shipped to the mobile client as the
 * source of truth; the database rows seeded from them are authoritative.
 */
export const DEFAULT_FEE_SCHEDULE: readonly DefaultFeeConfig[] = [
  { operation: "swap_evm", chainType: "evm", percentageBps: 50, fixedUsd: "0" },
  { operation: "swap_btc", chainType: "bitcoin", percentageBps: 100, fixedUsd: "0" },
  { operation: "bridge", chainType: "any", percentageBps: 80, fixedUsd: "0" },
  { operation: "create_token", chainType: "bsc", percentageBps: 0, fixedUsd: "0.30" },
  // Existing listing behavior is preserved as a separate paid service.
  { operation: "listing", chainType: "any", percentageBps: 0, fixedUsd: "1.50" },
];

export const FEE_CONFIG_CACHE_TTL_SECONDS = 300;

export function feeConfigCacheKey(operation: FeeOperation, chainType: string): string {
  return `paxi:fee-config:${operation}:${chainType.toLowerCase()}`;
}

export interface CachedFeeConfig {
  operation: FeeOperation;
  chainType: string;
  percentageBps: number;
  fixedUsd: string;
  isActive: boolean;
  updatedAtMs: number;
}

export async function getCachedFeeConfig(operation: FeeOperation, chainType: string): Promise<CachedFeeConfig | null> {
  const raw = await redisSafe((client) => client.get(feeConfigCacheKey(operation, chainType)));
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as CachedFeeConfig;
    if (parsed.operation !== operation || typeof parsed.chainType !== "string" || !Number.isInteger(parsed.percentageBps)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export async function setCachedFeeConfig(config: CachedFeeConfig): Promise<void> {
  await redisSafe((client) =>
    client.set(feeConfigCacheKey(config.operation, config.chainType), JSON.stringify(config), "EX", FEE_CONFIG_CACHE_TTL_SECONDS),
  );
}

export async function clearCachedFeeConfig(operation: FeeOperation, chainType: string): Promise<void> {
  await redisSafe((client) => client.del(feeConfigCacheKey(operation, chainType)));
  if (chainType.toLowerCase() !== "any") {
    await redisSafe((client) => client.del(feeConfigCacheKey(operation, "any")));
  }
}
