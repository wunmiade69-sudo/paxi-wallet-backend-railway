import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./marketProviders", async () => {
  const actual = await vi.importActual<typeof import("./marketProviders")>("./marketProviders");
  return {
    ...actual,
    getBirdeyeChart: vi.fn(),
    getDexPaprikaChart: vi.fn(),
  };
});

import { getMarketChart } from "./marketData";
import * as providerModule from "./marketProviders";

describe("canonical market chart fallback", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubGlobal("fetch", vi.fn());
  });

  it("uses the preferred chain-specific provider first", async () => {
    vi.mocked(providerModule.getBirdeyeChart).mockResolvedValue({
      points: [{ timestamp: 1_700_000_000_000, open: null, high: null, low: null, close: 1.2, volume: null }],
      source: "birdeye",
      historicalAvailable: true,
      providerId: "0xabc",
    });
    vi.mocked(providerModule.getDexPaprikaChart).mockResolvedValue(null);

    const result = await getMarketChart({ chain: "ethereum", contractAddress: "0xabc", coinId: null }, 7);

    expect(result.source).toBe("birdeye");
    expect(result.historicalAvailable).toBe(true);
    expect(providerModule.getDexPaprikaChart).not.toHaveBeenCalled();
  });

  it("passes explicit short-range timeframe to the preferred provider", async () => {
    vi.mocked(providerModule.getBirdeyeChart).mockResolvedValue({
      points: [{ timestamp: 1_700_000_000_000, open: null, high: null, low: null, close: 1.2, volume: null }],
      source: "birdeye",
      historicalAvailable: true,
      providerId: "0xshort",
    });

    const result = await getMarketChart({ chain: "ethereum", contractAddress: "0xshort", coinId: null }, "1H");

    expect(result.source).toBe("birdeye");
    expect(providerModule.getBirdeyeChart).toHaveBeenCalledWith(
      { chain: "ethereum", contractAddress: "0xshort", coinId: null },
      "1H",
    );
  });

  it("falls back to CoinGecko when provider candles are unavailable and coinId exists", async () => {
    vi.mocked(providerModule.getBirdeyeChart).mockResolvedValue(null);
    vi.mocked(providerModule.getDexPaprikaChart).mockResolvedValue(null);
    vi.mocked(globalThis.fetch).mockResolvedValue({
      ok: true,
      json: async () => ({ prices: [[1_700_000_000, 1.1], [1_700_086_400, 1.3]] }),
    } as Response);

    const result = await getMarketChart({ chain: "ethereum", contractAddress: "0xdef", coinId: "chart-token-success" }, 1);

    expect(result.source).toBe("coingecko");
    expect(result.points).toHaveLength(2);
    expect(result.points[0]).toMatchObject({ close: 1.1, open: null, high: null, low: null, volume: null });
  });

  it("returns an explicit unavailable result on provider rate limit and CoinGecko failure", async () => {
    vi.mocked(providerModule.getBirdeyeChart).mockResolvedValue(null);
    vi.mocked(providerModule.getDexPaprikaChart).mockResolvedValue(null);
    vi.mocked(globalThis.fetch).mockResolvedValue({ ok: false, status: 429 } as Response);

    const result = await getMarketChart({ chain: "ethereum", contractAddress: "0xrate", coinId: "chart-token-rate" }, 7);

    expect(result).toEqual({ points: [], source: "unavailable", historicalAvailable: false });
  });

  it("does not call CoinGecko for a canonical identity without an optional coinId", async () => {
    vi.mocked(providerModule.getBirdeyeChart).mockResolvedValue(null);
    vi.mocked(providerModule.getDexPaprikaChart).mockResolvedValue(null);

    const result = await getMarketChart({ chain: "solana", contractAddress: "MintCaseSensitive", coinId: null }, 30);

    expect(result.historicalAvailable).toBe(false);
    expect(globalThis.fetch).not.toHaveBeenCalled();
  });
});
