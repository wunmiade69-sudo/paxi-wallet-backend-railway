import { describe, expect, it } from "vitest";
import { getBinanceChartConfig, getBinanceChartSymbolCandidates } from "./marketData";

describe("market chart fallbacks", () => {
  it("uses a known mapping first and falls back to a normalized USDT market symbol", () => {
    expect(getBinanceChartSymbolCandidates("bitcoin", "btc")).toEqual(["BTCUSDT"]);
    expect(getBinanceChartSymbolCandidates("zcash", "zec")).toEqual(["ZECUSDT"]);
    expect(getBinanceChartSymbolCandidates("wrapped-asset", "w-asset")).toEqual(["WASSETUSDT"]);
  });

  it("keeps timeframes within the exchange candle limits used by the history retry path", () => {
    expect(getBinanceChartConfig(1)).toEqual({ interval: "1h", limit: 24 });
    expect(getBinanceChartConfig(365)).toEqual({ interval: "1w", limit: 52 });
    expect(getBinanceChartConfig("max")).toEqual({ interval: "1w", limit: 1000 });
  });
});
