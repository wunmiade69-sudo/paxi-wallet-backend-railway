import { describe, expect, it } from 'vitest';
import {
  assetSectionIncludes,
  portfolioAssetIdentity,
  portfolioAssetKind,
  toPortfolioAsset,
} from '../client/src/lib/phase3Models';
import type { AssetConfig } from '../client/src/lib/wallet/chains';
import type { AssetBalance } from '../client/src/lib/wallet/balances';

function asset(overrides: Partial<AssetConfig> = {}): AssetConfig {
  return {
    symbol: 'USDT',
    name: 'Tether USD',
    icon: '₮',
    network: 'ethereum',
    isNative: false,
    contractAddress: '0x0000000000000000000000000000000000000001',
    decimals: 6,
    ...overrides,
  };
}

function balance(overrides: Partial<AssetBalance> = {}): AssetBalance {
  return {
    asset: asset(),
    balance: 12.5,
    usdPrice: 1,
    change24h: 0.2,
    ...overrides,
  };
}

describe('Phase 3 portfolio models', () => {
  it('keeps same-symbol assets distinct by chain and contract identity', () => {
    const ethereum = portfolioAssetIdentity(asset({ network: 'ethereum' }));
    const bsc = portfolioAssetIdentity(asset({
      network: 'bsc',
      contractAddress: '0x0000000000000000000000000000000000000002',
    }));

    expect(ethereum).not.toEqual(bsc);
    expect(ethereum.chain).toBe('ethereum');
    expect(bsc.contractOrMint).toBe('0x0000000000000000000000000000000000000002');
  });

  it('does not invent token contracts for native assets', () => {
    const native = asset({ symbol: 'ETH', name: 'Ethereum', isNative: true, contractAddress: undefined });
    expect(portfolioAssetKind(native)).toBe('native');
    expect(portfolioAssetIdentity(native).contractOrMint).toBeUndefined();
  });

  it('preserves zero as a real value and uses null for unavailable metrics', () => {
    const mapped = toPortfolioAsset(balance({ balance: 0, usdPrice: null, change24h: null }));
    expect(mapped.balance).toBe(0);
    expect(mapped.fiatValue).toBeNull();
    expect(mapped.price).toBeNull();
    expect(mapped.change24h).toBeNull();
    expect(mapped.availability).toBe('available');
  });

  it('exposes honest unavailable state when both balance and price are missing', () => {
    const mapped = toPortfolioAsset(balance({ balance: null, usdPrice: null }));
    expect(mapped.availability).toBe('unavailable');
    expect(mapped.fiatValue).toBeNull();
  });

  it('keeps NFTs and future position kinds out of the current token section', () => {
    expect(assetSectionIncludes('tokens', 'token')).toBe(true);
    expect(assetSectionIncludes('tokens', 'nft')).toBe(false);
    expect(assetSectionIncludes('nfts', 'nft')).toBe(true);
    expect(assetSectionIncludes('other', 'lp')).toBe(true);
  });
});

import { toDiscoverEntry } from '../client/src/lib/wallet/discover';

describe('Phase 3 Discover metadata', () => {
  it('keeps curated entries explicit about verification, risk, chain support, and status', () => {
    const entry = toDiscoverEntry({
      id: 'example',
      name: 'Example',
      url: 'https://example.org/app',
      category: 'DEX',
      description: 'A curated example',
      supportedChains: ['ethereum'],
    });

    expect(entry.category).toBe('defi');
    expect(entry.supportedChains).toEqual(['ethereum']);
    expect(entry.verification).toBe('unknown');
    expect(entry.risk).toBe('unknown');
    expect(entry.status).toBe('available');
    expect(entry.domain).toBe('example.org');
  });
});
