import { getCircuitBreaker } from "../resilience/circuitBreaker";
import { isProviderOnCooldown, setProviderCooldown } from "../redis";

const PROVIDER_TIMEOUT_MS = 8_000;
const MAX_PROVIDER_RESPONSE_BYTES = 2 * 1024 * 1024;

async function readLimitedText(response: globalThis.Response): Promise<string> {
  const declaredLength = Number(response.headers.get("content-length") ?? 0);
  if (declaredLength > MAX_PROVIDER_RESPONSE_BYTES) throw new Error("provider response too large");
  if (!response.body) return "";

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > MAX_PROVIDER_RESPONSE_BYTES) {
        await reader.cancel();
        throw new Error("provider response too large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8");
}

export async function fetchJson<T>(url: string, breakerName: string, headers: Record<string, string> = {}): Promise<T> {
  // 1. Check if the provider is on cooldown in Redis
  if (await isProviderOnCooldown(breakerName)) {
    throw new Error(`${breakerName} is on temporary cooldown`);
  }

  const breaker = getCircuitBreaker(`provider-${breakerName}`, { failureThreshold: 5, resetTimeoutMs: 30_000 });
  
  try {
    const response = await breaker.execute(() =>
      fetch(url, {
        headers: {
          Accept: "application/json",
          "User-Agent": "PaxiWallet/1.0 market-data-client",
          ...headers,
        },
        signal: AbortSignal.timeout(PROVIDER_TIMEOUT_MS),
      }),
    );

    if (!response.ok) {
      // 2. Set cooldown for rate limits (429) or server errors (5xx)
      if (response.status === 429) {
        await setProviderCooldown(breakerName, 60); // 1 minute for rate limits
      } else if (response.status >= 500) {
        await setProviderCooldown(breakerName, 30); // 30 seconds for server errors
      }
      throw new Error(`${breakerName} returned HTTP ${response.status}`);
    }

    const body = await readLimitedText(response);
    try {
      return JSON.parse(body) as T;
    } catch {
      throw new Error(`${breakerName} returned invalid JSON`);
    }
  } catch (err) {
    // 3. Set cooldown for timeouts or network failures
    if (err instanceof Error && (err.name === "TimeoutError" || err.message.includes("timeout"))) {
      await setProviderCooldown(breakerName, 15); // 15 seconds for timeouts
    }
    throw err;
  }
}
