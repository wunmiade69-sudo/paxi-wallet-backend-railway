import { ethers } from "ethers";
import { getCircuitBreaker } from "../resilience/circuitBreaker";
import type { RewardPolicy } from "../../drizzle/schema";

const BSC_RPC_URL = process.env.BSC_RPC_URL ?? "https://bsc-rpc.publicnode.com";
const BSC_STABLECOINS: Record<string, number> = {
  "0x55d398326f99059ff775485246999027b3197955": 18,
  "0x8ac76a51cc9509822d68b83fe1ad97b32cd580d": 18,
};
const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const SWAP_TOPIC = ethers.id("Swap(address,uint256,uint256,uint256,uint256,address)");
const TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;
const SWAP_INTERFACE = new ethers.Interface([
  "event Swap(address indexed sender,uint256 amount0In,uint256 amount1In,uint256 amount0Out,uint256 amount1Out,address indexed to)",
]);
const PAIR_INTERFACE = new ethers.Interface([
  "function token0() view returns (address)",
  "function token1() view returns (address)",
]);

export interface VerifiedReferralTrade {
  transactionHash: string;
  walletAddress: string;
  eventType: "buy" | "sell";
  volumeUsd: string;
  pairAddress: string;
  qualifyingAssetAddress: string;
  stablecoinAddress: string;
  blockNumber: number;
}

interface PairSwap {
  pairAddress: string;
  amount0In: bigint;
  amount1In: bigint;
  amount0Out: bigint;
  amount1Out: bigint;
}

export function calculateDirectionalTradeAmounts(params: {
  paxiIsToken0: boolean;
  stableIsToken0: boolean;
  paxiToWallet: boolean;
  amount0In: bigint;
  amount1In: bigint;
  amount0Out: bigint;
  amount1Out: bigint;
}): { paxiAmount: bigint; stablecoinAmount: bigint } {
  const paxiAmountIn = params.paxiIsToken0 ? params.amount0In : params.amount1In;
  const paxiAmountOut = params.paxiIsToken0 ? params.amount0Out : params.amount1Out;
  const stableAmountIn = params.stableIsToken0 ? params.amount0In : params.amount1In;
  const stableAmountOut = params.stableIsToken0 ? params.amount0Out : params.amount1Out;
  return params.paxiToWallet
    ? { paxiAmount: paxiAmountOut, stablecoinAmount: stableAmountIn }
    : { paxiAmount: paxiAmountIn, stablecoinAmount: stableAmountOut };
}

function topicAddress(topic: string | undefined): string | null {
  if (!topic || !/^0x[0-9a-fA-F]{64}$/.test(topic)) return null;
  try {
    return ethers.getAddress(`0x${topic.slice(26)}`).toLowerCase();
  } catch {
    return null;
  }
}

function formatUnits(value: bigint, decimals: number): string {
  const whole = value / (10n ** BigInt(decimals));
  const fraction = (value % (10n ** BigInt(decimals))).toString().padStart(decimals, "0").replace(/0+$/, "");
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function configuredAddresses(policy: RewardPolicy, key: string): Set<string> {
  const raw = policy.config && Array.isArray(policy.config[key]) ? policy.config[key] : [];
  return new Set(raw.filter((value): value is string => typeof value === "string" && ethers.isAddress(value)).map((value) => value.toLowerCase()));
}

function getProvider(): ethers.JsonRpcProvider {
  const request = new ethers.FetchRequest(BSC_RPC_URL);
  request.timeout = 10_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

function parseSwap(log: ethers.Log): PairSwap | null {
  try {
    const parsed = SWAP_INTERFACE.parseLog({ topics: [...log.topics], data: log.data });
    if (!parsed) return null;
    return {
      pairAddress: log.address.toLowerCase(),
      amount0In: BigInt(parsed.args.amount0In),
      amount1In: BigInt(parsed.args.amount1In),
      amount0Out: BigInt(parsed.args.amount0Out),
      amount1Out: BigInt(parsed.args.amount1Out),
    };
  } catch {
    return null;
  }
}

export async function verifyBscPaxiTrade(
  txHash: string,
  walletAddress: string,
  policy: RewardPolicy,
): Promise<VerifiedReferralTrade> {
  if (!TX_HASH_RE.test(txHash) || !ethers.isAddress(walletAddress)) throw new Error("Invalid BSC trade transaction or wallet address");
  if (!policy.qualifyingAssetAddress || !ethers.isAddress(policy.qualifyingAssetAddress)) throw new Error("The policy has no verified PAXI token address");
  const routers = configuredAddresses(policy, "trustedRouterAddresses");
  const pairs = configuredAddresses(policy, "trustedPairAddresses");
  if (routers.size === 0 || pairs.size === 0) throw new Error("Trusted PAXI router and pair configuration is required before referral rewards can activate");

  const provider = getProvider();
  const breaker = getCircuitBreaker("referral-bsc-trade-rpc", { failureThreshold: 3, resetTimeoutMs: 30_000 });
  const [transaction, receipt] = await breaker.execute(() => Promise.all([
    provider.getTransaction(txHash),
    provider.getTransactionReceipt(txHash),
  ]));
  if (!transaction || !receipt) throw new Error("BSC trade transaction is not confirmed");
  if (receipt.status !== 1) throw new Error("BSC trade transaction failed");
  if (!transaction.from || transaction.from.toLowerCase() !== walletAddress.toLowerCase()) throw new Error("Trade transaction sender does not match the referred wallet");
  if (!transaction.to || !routers.has(transaction.to.toLowerCase())) throw new Error("Trade transaction did not call a trusted PAXI router");

  const wallet = walletAddress.toLowerCase();
  const paxi = policy.qualifyingAssetAddress.toLowerCase();
  let paxiFromWallet = false;
  let paxiToWallet = false;
  const swapLogs: PairSwap[] = [];

  for (const log of receipt.logs) {
    const logAddress = log.address.toLowerCase();
    if (log.topics[0] === TRANSFER_TOPIC && log.topics.length >= 3 && logAddress === paxi) {
      const from = topicAddress(log.topics[1]);
      const to = topicAddress(log.topics[2]);
      if (from === wallet) paxiFromWallet = true;
      if (to === wallet) paxiToWallet = true;
    }
    if (log.topics[0] === SWAP_TOPIC && pairs.has(logAddress)) {
      const parsed = parseSwap(log);
      if (parsed) swapLogs.push(parsed);
    }
  }

  if (paxiFromWallet === paxiToWallet) throw new Error("Could not classify the trade as exactly one PAXI buy or sell");
  if (swapLogs.length === 0) throw new Error("No trusted PAXI pair Swap event was found");
  if (swapLogs.length !== 1) throw new Error("Ambiguous transaction contains multiple trusted PAXI pair Swap events");

  const [token0, token1] = await breaker.execute(() => Promise.all([
    provider.call({ to: swapLogs[0].pairAddress, data: PAIR_INTERFACE.encodeFunctionData("token0") }),
    provider.call({ to: swapLogs[0].pairAddress, data: PAIR_INTERFACE.encodeFunctionData("token1") }),
  ]).then(([token0Data, token1Data]) => [
    PAIR_INTERFACE.decodeFunctionResult("token0", token0Data)[0] as string,
    PAIR_INTERFACE.decodeFunctionResult("token1", token1Data)[0] as string,
  ] as const));
  const token0Address = token0.toLowerCase();
  const token1Address = token1.toLowerCase();
  const paxiIsToken0 = token0Address === paxi;
  const paxiIsToken1 = token1Address === paxi;
  const stable0Decimals = BSC_STABLECOINS[token0Address];
  const stable1Decimals = BSC_STABLECOINS[token1Address];
  const stableIsToken0 = stable0Decimals !== undefined;
  const stableIsToken1 = stable1Decimals !== undefined;
  if ((!paxiIsToken0 && !paxiIsToken1) || (!stableIsToken0 && !stableIsToken1) || (paxiIsToken0 && stableIsToken0) || (paxiIsToken1 && stableIsToken1)) {
    throw new Error("Trusted pair does not contain exactly one PAXI side and one supported BSC stablecoin side");
  }

  const swap = swapLogs[0];
  const isBuy = paxiToWallet;
  const { paxiAmount, stablecoinAmount } = calculateDirectionalTradeAmounts({
    paxiIsToken0,
    stableIsToken0,
    paxiToWallet,
    amount0In: swap.amount0In,
    amount1In: swap.amount1In,
    amount0Out: swap.amount0Out,
    amount1Out: swap.amount1Out,
  });
  const stablecoinAddress = stableIsToken0 ? token0Address : token1Address;
  const stablecoinDecimals = stableIsToken0 ? stable0Decimals! : stable1Decimals!;
  if (paxiAmount <= 0n || stablecoinAmount <= 0n) throw new Error("Trusted pair Swap event has no positive PAXI/stablecoin trade amounts");

  return {
    transactionHash: txHash,
    walletAddress: ethers.getAddress(walletAddress),
    eventType: isBuy ? "buy" : "sell",
    volumeUsd: formatUnits(stablecoinAmount, stablecoinDecimals),
    pairAddress: swap.pairAddress,
    qualifyingAssetAddress: ethers.getAddress(policy.qualifyingAssetAddress),
    stablecoinAddress,
    blockNumber: receipt.blockNumber,
  };
}
