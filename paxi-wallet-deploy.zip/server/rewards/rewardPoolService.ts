import { and, asc, eq, isNull, sql } from "drizzle-orm";
import { ethers } from "ethers";
import {
  referrals,
  rewardClaims,
  rewardLedger,
  rewardPolicies,
  rewardPools,
  type RewardPool,
  type RewardPolicy,
} from "../../drizzle/schema";
import { getDb, getReadDb } from "../db";
import { allocateFromVerifiedWpaxiPools } from "./rewardPoolAllocation";

const BSC_RPC_URL = process.env.BSC_RPC_URL ?? "https://bsc-rpc.publicnode.com";
const ERC20_ABI = [
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)",
];
const ADDRESS_RE = /^0x[0-9a-fA-F]{40}$/;
const DECIMAL_RE = /^(?:0|[1-9]\d{0,37})(?:\.\d{1,18})?$/;

function assertId(value: number, label: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`Invalid ${label}`);
}

function assertDecimal(value: string, label: string): void {
  if (!DECIMAL_RE.test(value) || value === "0") throw new Error(`Invalid ${label}`);
}

function affectedRows(result: unknown): number {
  return Number((result as { affectedRows?: number }).affectedRows ?? 0);
}

function provider(): ethers.JsonRpcProvider {
  const request = new ethers.FetchRequest(BSC_RPC_URL);
  request.timeout = 10_000;
  return new ethers.JsonRpcProvider(request, undefined, { staticNetwork: true, batchMaxCount: 1 });
}

export async function listRewardPools(policyId: number): Promise<RewardPool[]> {
  assertId(policyId, "policy id");
  const db = await getReadDb();
  if (!db) return [];
  return db.select().from(rewardPools).where(eq(rewardPools.policyId, policyId)).orderBy(asc(rewardPools.priority));
}

export async function registerRewardPool(params: {
  policyId: number;
  chainId: string;
  tokenAddress: string;
  distributorAddress?: string | null;
  tokenSymbol: string;
  tokenDecimals: number;
  totalAllocation: string;
  priority: number;
}): Promise<RewardPool> {
  assertId(params.policyId, "policy id");
  if (params.chainId !== "bsc") throw new Error("WPAXI reward pools must be on BSC");
  if (!ADDRESS_RE.test(params.tokenAddress) || (params.distributorAddress && !ADDRESS_RE.test(params.distributorAddress))) throw new Error("Invalid reward token or distributor address");
  if (!Number.isInteger(params.tokenDecimals) || params.tokenDecimals < 0 || params.tokenDecimals > 36) throw new Error("Invalid token decimals");
  assertDecimal(params.totalAllocation, "total allocation");
  if (!Number.isSafeInteger(params.priority) || params.priority <= 0) throw new Error("Invalid pool priority");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(rewardPools).where(and(eq(rewardPools.policyId, params.policyId), eq(rewardPools.priority, params.priority))).limit(1);
  if (existing[0]) {
    const sameConfig = existing[0].tokenAddress.toLowerCase() === params.tokenAddress.toLowerCase() && (existing[0].distributorAddress ?? null) === (params.distributorAddress ?? null) && existing[0].tokenSymbol === params.tokenSymbol.trim().toUpperCase() && existing[0].tokenDecimals === params.tokenDecimals && existing[0].totalAllocation === params.totalAllocation;
    if (!sameConfig) throw new Error("A different reward pool already uses this policy priority");
    return existing[0];
  }
  await db.insert(rewardPools).values({
    policyId: params.policyId,
    chainId: params.chainId,
    tokenAddress: ethers.getAddress(params.tokenAddress),
    distributorAddress: params.distributorAddress ? ethers.getAddress(params.distributorAddress) : null,
    tokenSymbol: params.tokenSymbol.trim().toUpperCase(),
    tokenDecimals: params.tokenDecimals,
    totalAllocation: params.totalAllocation,
    allocatedAmount: "0",
    remainingAmount: params.totalAllocation,
    status: "reserve",
    priority: params.priority,
    verified: false,
  });
  const [created] = await db.select().from(rewardPools).where(and(eq(rewardPools.policyId, params.policyId), eq(rewardPools.priority, params.priority))).limit(1);
  if (!created) throw new Error("Reward pool was not created");
  return created;
}

export async function setRewardPoolDistributor(poolId: number, distributorAddress: string): Promise<RewardPool> {
  assertId(poolId, "pool id");
  if (!ADDRESS_RE.test(distributorAddress)) throw new Error("Invalid distributor address");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.update(rewardPools).set({ distributorAddress: ethers.getAddress(distributorAddress), verified: false, verificationData: null }).where(and(eq(rewardPools.id, poolId), eq(rewardPools.status, "reserve"), eq(rewardPools.verified, false)));
  if (affectedRows(result) !== 1) throw new Error("Only an unverified reserve pool can receive a distributor address");
  const [pool] = await db.select().from(rewardPools).where(eq(rewardPools.id, poolId)).limit(1);
  if (!pool) throw new Error("Reward pool not found after distributor update");
  return pool;
}

export async function verifyRewardPool(poolId: number): Promise<RewardPool> {
  assertId(poolId, "pool id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [pool] = await db.select().from(rewardPools).where(eq(rewardPools.id, poolId)).limit(1);
  if (!pool) throw new Error("Reward pool not found");
  if (pool.tokenSymbol !== "WPAXI") throw new Error("Only WPAXI reward pools can be verified for referral rewards");
  if (pool.chainId !== "bsc" || !ADDRESS_RE.test(pool.tokenAddress) || !pool.distributorAddress || !ADDRESS_RE.test(pool.distributorAddress)) throw new Error("Only BSC pools with a configured distributor are supported");
  const token = new ethers.Contract(pool.tokenAddress, ERC20_ABI, provider());
  const [symbol, decimals, totalSupply, distributorBalance] = await Promise.all([
    token.symbol(),
    token.decimals(),
    token.totalSupply(),
    token.balanceOf(pool.distributorAddress),
  ]);
  if (String(symbol).toUpperCase() !== pool.tokenSymbol) throw new Error("On-chain token symbol does not match pool configuration");
  if (Number(decimals) !== pool.tokenDecimals) throw new Error("On-chain token decimals do not match pool configuration");
  if (totalSupply <= 0n) throw new Error("On-chain token supply is empty");
  const allocationUnits = ethers.parseUnits(pool.totalAllocation, pool.tokenDecimals);
  if (totalSupply < allocationUnits) throw new Error("Configured pool allocation exceeds on-chain total supply");
  if (distributorBalance < allocationUnits) throw new Error("Configured distributor does not hold enough WPAXI to fund the pool allocation");
  const updated = await db.update(rewardPools).set({
    verified: true,
    verificationData: { symbol: String(symbol), decimals: Number(decimals), totalSupply: totalSupply.toString(), distributorBalance: distributorBalance.toString(), verifiedAtMs: Date.now() },
  }).where(and(eq(rewardPools.id, poolId), eq(rewardPools.status, "reserve"), eq(rewardPools.verified, false)));
  if (affectedRows(updated) !== 1) throw new Error("Only an unverified reserve pool can be verified");
  const [row] = await db.select().from(rewardPools).where(eq(rewardPools.id, poolId)).limit(1);
  if (!row) throw new Error("Reward pool disappeared after verification");
  return row;
}

export async function activateRewardPool(poolId: number): Promise<RewardPool> {
  assertId(poolId, "pool id");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [poolRead] = await db.select().from(rewardPools).where(eq(rewardPools.id, poolId)).limit(1);
  if (!poolRead) throw new Error("Reward pool not found");
  if (!poolRead.verified || poolRead.status !== "reserve") throw new Error("Only a verified reserve pool can be activated");
  if (!poolRead.distributorAddress) throw new Error("Reward pool has no distributor address configured");

  const token = new ethers.Contract(poolRead.tokenAddress, ERC20_ABI, provider());
  const distributorBalance = await token.balanceOf(poolRead.distributorAddress);
  const remainingUnits = ethers.parseUnits(poolRead.remainingAmount, poolRead.tokenDecimals);
  if (distributorBalance < remainingUnits) {
    throw new Error("Distributor on-chain balance has dropped below the remaining pool allocation requirement");
  }

  return db.transaction(async (tx) => {
    const [pool] = await tx.select().from(rewardPools).where(eq(rewardPools.id, poolId)).limit(1);
    if (!pool) throw new Error("Reward pool not found");
    if (!pool.verified || pool.status !== "reserve") throw new Error("Only a verified reserve pool can be activated");
    // Explicitly deactivate any existing active pool for this policy first
    await tx.update(rewardPools)
      .set({ status: "reserve" })
      .where(and(
        eq(rewardPools.policyId, pool.policyId), 
        eq(rewardPools.status, "active")
      ));
      
    const result = await tx.update(rewardPools)
      .set({ status: "active" })
      .where(and(
        eq(rewardPools.id, poolId), 
        eq(rewardPools.status, "reserve"), 
        eq(rewardPools.verified, true)
      ));
    if (affectedRows(result) !== 1) throw new Error("Reward pool activation race; try again");
    const [updated] = await tx.select().from(rewardPools).where(eq(rewardPools.id, poolId)).limit(1);
    if (!updated) throw new Error("Reward pool was not found after activation");
    return updated;
  });
}

export async function issueReferralReward(params: {
  referralId: number;
  qualifyingVolumeUsd: string;
  policy: RewardPolicy;
}): Promise<{ ledgerId: number; claimId: number; poolId: number }> {
  assertId(params.referralId, "referral id");
  assertDecimal(params.qualifyingVolumeUsd, "qualifying volume");
  if (!params.policy.isActive) throw new Error("Referral policy is not active");
  if (params.policy.rewardAssetNetwork !== "bsc" || params.policy.rewardAssetSymbol !== "WPAXI") throw new Error("Referral reward policy must be WPAXI on BSC");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      return await db.transaction(async (tx) => {
        await tx.execute(sql`SELECT id FROM referrals WHERE id = ${params.referralId} FOR UPDATE`);
        const [referral] = await tx.select().from(referrals).where(eq(referrals.id, params.referralId)).limit(1);
        if (!referral) throw new Error("Referral not found");
        if (referral.rewardLedgerId) {
          const [claim] = await tx.select().from(rewardClaims).where(eq(rewardClaims.rewardLedgerId, referral.rewardLedgerId)).limit(1);
          if (!claim) throw new Error("Referral reward claim is missing");
          return { ledgerId: referral.rewardLedgerId, claimId: claim.id, poolId: claim.poolId ?? 0 };
        }
        if (referral.status !== "pending") throw new Error("Referral is not pending qualification");

        if (!referral.rewardWalletAddress || !ethers.isAddress(referral.rewardWalletAddress)) {
          throw new Error("Inviter must bind an explicit BSC reward wallet before qualification");
        }
        const allocation = await allocateFromVerifiedWpaxiPools(tx, {
          policyId: params.policy.id,
          rewardAmount: params.policy.rewardAmount,
        });
        const pool = allocation.pool;
        const ledgerResult = await tx.insert(rewardLedger).values({
          userOpenId: referral.inviterOpenId,
          sourceType: "referral",
          sourceId: String(referral.id),
          assetSymbol: params.policy.rewardAssetSymbol,
          assetNetwork: params.policy.rewardAssetNetwork,
          assetContractAddress: pool.tokenAddress,
          amount: params.policy.rewardAmount,
          status: "claimable",
          idempotencyKey: `referral:${referral.id}:wpaxi`,
          metadata: { sourceUserOpenId: referral.inviteeOpenId, poolId: pool.id, qualifyingVolumeUsd: params.qualifyingVolumeUsd, rewardWalletAddress: referral.rewardWalletAddress },
          claimableAt: new Date(),
        });
        const ledgerId = Number((ledgerResult as unknown as { insertId?: number | string }).insertId);
        const claimResult = await tx.insert(rewardClaims).values({
          rewardLedgerId: ledgerId,
          userOpenId: referral.inviterOpenId,
          recipientWalletAddress: ethers.getAddress(referral.rewardWalletAddress),
          poolId: pool.id,
          tokenAddress: pool.tokenAddress,
          amount: params.policy.rewardAmount,
          status: "claimable",
          claimIdempotencyKey: `claim:referral:${referral.id}:wpaxi`,
        });
        const claimId = Number((claimResult as unknown as { insertId?: number | string }).insertId);
        const referralUpdate = await tx.update(referrals).set({ status: "qualified", qualifyingVolumeUsd: params.qualifyingVolumeUsd, rewardLedgerId: ledgerId, qualifiedAt: new Date() }).where(and(eq(referrals.id, referral.id), eq(referrals.status, "pending"), isNull(referrals.rewardLedgerId)));
        if (affectedRows(referralUpdate) !== 1) throw new Error("Referral qualification race; retrying");
        return { ledgerId, claimId, poolId: pool.id };
      });
    } catch (error) {
      const [existing] = await db.select({ ledgerId: rewardLedger.id }).from(rewardLedger).where(eq(rewardLedger.idempotencyKey, `referral:${params.referralId}:wpaxi`)).limit(1);
      if (existing?.ledgerId) {
        const [claim] = await db.select().from(rewardClaims).where(eq(rewardClaims.rewardLedgerId, existing.ledgerId)).limit(1);
        if (claim) return { ledgerId: existing.ledgerId, claimId: claim.id, poolId: claim.poolId ?? 0 };
      }
      if (attempt === 2) throw error;
    }
  }
  throw new Error("Could not issue referral reward");
}
