import { TRPCError } from "@trpc/server";
import { and, desc, eq, inArray, ne, or } from "drizzle-orm";
import { z } from "zod";
import { adminAuditEvents, assets, listingEvents, tokenListings, type InsertTokenListing } from "../../drizzle/schema";
import { getDb } from "../db";
import { verifyFeePayment, verifyTokenDeployment } from "../feeVerification";
import { getTokenLiquidityUsd, AUTO_VERIFY_LIQUIDITY_USD } from "../dexLiquidity";
import { storagePut } from "../storage";
import { normalizeIdentifier, syncAssetFromListing } from "../assetRegistry";
import { recordActivity } from "../activity/activityService";
import { enqueueMarketTask } from "../queue";
import { getChainAdapter } from "../chains/registry";
import { requireValidIdentifier } from "../chains/types";
import { adminPermissionProcedure, protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getFeeConfig } from "../fees/feeEngine";
import { recordFee } from "../fees/feeEngine";
import { canResubmitRejectedListing } from "../listingResubmission";

/** Paid in USDT/USDC to the Paxi treasury address - see feeVerification.ts for why. */
// Compatibility exports for server callers. The authoritative values are feeConfig rows in MySQL.
export const CREATION_FEE_USD = "0.30";
export const LISTING_FEE_USD = "1.50";

async function getFixedFeeUsd(operation: "create_token" | "listing", chainType: string): Promise<string> {
  const config = await getFeeConfig(operation, chainType);
  if (config.percentageBps !== 0) throw new Error(`Fee configuration for ${operation}/${chainType} must be fixed USD`);
  if (!/^(?:0|[1-9]\d{0,27})(?:\.\d{1,6})?$/.test(config.fixedUsd) || config.fixedUsd === "0") {
    throw new Error(`Invalid fee configuration for ${operation}/${chainType}`);
  }
  return config.fixedUsd;
}

const MAX_LOGO_BYTES = 500 * 1024; // 500KB - plenty for a token logo, small enough to not be abused as a file host

// Base64 data URL, e.g. "data:image/png;base64,AAAA..." - client reads the
// file picker with FileReader before sending, same as any other upload here.
const logoDataUrl = z
  .string()
  .max(700_000, "Logo payload is too large")
  .regex(/^data:image\/(png|jpeg|jpg|webp);base64,/, "Logo must be a PNG, JPEG or WEBP image");

function decodeLogo(dataUrl: string): { buffer: Buffer; contentType: string; ext: string } {
  const [header, b64] = dataUrl.split(",");
  const contentType = header.slice("data:".length, header.indexOf(";"));
  const ext = contentType.split("/")[1] === "jpeg" || contentType.split("/")[1] === "jpg" ? "jpg" : contentType.split("/")[1] === "webp" ? "webp" : "png";
  const buffer = Buffer.from(b64, "base64");
  if (buffer.byteLength > MAX_LOGO_BYTES) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Logo must be under 500KB. Resize it and try again." });
  }
  const isPng = contentType === "image/png" && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  const isJpeg = (contentType === "image/jpeg" || contentType === "image/jpg") && buffer.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]));
  const isWebp = contentType === "image/webp" && buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP";
  if (!isPng && !isJpeg && !isWebp) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Logo content does not match its declared image type." });
  }
  if (buffer.byteLength > MAX_LOGO_BYTES) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Logo must be under 500KB. Resize it and try again." });
  }
  return { buffer, contentType, ext };
}

const socialsSchema = z.object({
  twitter: z.string().trim().max(255).optional(),
  telegram: z.string().trim().max(255).optional(),
  website: z.string().trim().max(500).optional(),
  discord: z.string().trim().max(255).optional(),
});

const networkAndAddress = {
  network: z.string().trim().min(1).max(32).regex(/^[a-z0-9_-]+$/i),
  contractAddress: z.string().trim().min(1).max(128),
};

export function canonicalTokenInput(network: string, contractAddress: string) {
  try {
    const adapter = getChainAdapter(network.toLowerCase());
    return { network: adapter.network, contractAddress: requireValidIdentifier(adapter, contractAddress) };
  } catch {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Unsupported network or invalid token identifier." });
  }
}

/**
 * A tx hash can only ever pay for one listing. Without this, someone could
 * pay once and reuse the same hash across many different token submissions.
 */
async function assertFeeNotReused(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  feeTxHash: string,
  currentContractAddress: string,
  currentNetwork: string,
) {
  const reused = await db
    .select({ id: tokenListings.id })
    .from(tokenListings)
    .where(
      and(
        eq(tokenListings.feeTxHash, feeTxHash),
        or(ne(tokenListings.contractAddress, currentContractAddress), ne(tokenListings.network, currentNetwork)),
      ),
    )
    .limit(1);
  if (reused.length > 0) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "That payment has already been used for a different token." });
  }
}

export const listingsRouter = router({
  /**
   * Looked up on every "Add Token" / import, and by Discover to show badges.
   * Public - a wallet doesn't need to be logged in to see what's verified.
   */
  getByToken: publicProcedure
    .input(z.object(networkAndAddress))
    .query(async ({ input }) => {
      const { network, contractAddress } = canonicalTokenInput(input.network, input.contractAddress);
      const db = await getDb();
      if (!db) return null;
      const row = await db
        .select()
        .from(tokenListings)
        .where(
          and(
            eq(tokenListings.contractAddress, contractAddress),
            eq(tokenListings.network, network),
          ),
        )
        .limit(1);
      return row[0] ?? null;
    }),

  /** A user's own submitted/created listings, any status - used to let them pick a verified one to attach a campaign to. */
  myListings: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const listings = await db.select().from(tokenListings).where(eq(tokenListings.submittedByOpenId, ctx.user.openId)).orderBy(desc(tokenListings.updatedAt)).limit(100);
    if (listings.length === 0) return [];
    const events = await db
      .select()
      .from(listingEvents)
      .where(inArray(listingEvents.listingId, listings.map((listing) => listing.id)))
      .orderBy(desc(listingEvents.createdAt))
      .limit(500);
    return listings.map((listing) => ({ ...listing, events: events.filter((event) => event.listingId === listing.id) }));
  }),

  /** Verified tokens for the Discover marketplace (trading pairs, badges, etc). */
  listVerified: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(tokenListings).where(eq(tokenListings.status, "verified")).orderBy(desc(tokenListings.updatedAt)).limit(500);
  }),

  /**
   * A project submits their existing token for a paid Discover listing.
   * The $1.50 USDT/USDC payment tx is REQUIRED and verified on-chain right
   * here, before any row is written - so nothing lands in the pending queue
   * without a real, unreused payment behind it. This still only ever
   * produces a `pending` row: paying gets you reviewed, not auto-verified.
   */
  submitCommunityListing: protectedProcedure
    .input(
      z.object({
        ...networkAndAddress,
        symbol: z.string().min(1).max(32),
        name: z.string().min(1).max(128),
        logo: logoDataUrl,
        socials: socialsSchema,
        plan: z.string().min(1).max(2000),
        feeTxHash: z.string().trim().min(1).max(128),
        resubmissionListingId: z.number().int().positive().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const { network, contractAddress } = canonicalTokenInput(input.network, input.contractAddress);

      const listingFeeUsd = await getFixedFeeUsd("listing", network);
      const verification = await verifyFeePayment(network, input.feeTxHash, listingFeeUsd);
      if (!verification.ok) {
        throw new TRPCError({ code: "BAD_REQUEST", message: verification.reason });
      }
      await assertFeeNotReused(db, input.feeTxHash, contractAddress, network);

      const { buffer, contentType, ext } = decodeLogo(input.logo);
      const { key } = await storagePut(`token-logos/${network}-${contractAddress}.${ext}`, buffer, contentType);

      // A token that already has real trading liquidity has already proven
      // itself in a way that's harder to fake than just paying the listing
      // fee - skip the review queue for those. Anything thinner still goes
      // to an admin, same as before.
      const liquidityUsd = await getTokenLiquidityUsd(network, contractAddress);
      const autoVerified = liquidityUsd >= AUTO_VERIFY_LIQUIDITY_USD;

      const values: InsertTokenListing = {
        contractAddress,
        network,
        symbol: input.symbol,
        name: input.name,
        logoKey: key,
        source: "community",
        status: autoVerified ? "verified" : "pending",
        socials: input.socials,
        plan: input.plan,
        feeTxHash: input.feeTxHash,
        feeAmountUsd: listingFeeUsd,
        submittedByOpenId: ctx.user.openId,
        ...(autoVerified ? { reviewedByOpenId: "auto:liquidity" } : {}),
      };

      // Do not use a multi-unique upsert: MySQL can trigger ON DUPLICATE KEY
      // UPDATE from feeTxHash and overwrite a different token row on a payment
      // collision. A rejected owner may only resubmit the exact same identity.
      const [existing] = await db
        .select({ id: tokenListings.id, submittedByOpenId: tokenListings.submittedByOpenId, status: tokenListings.status })
        .from(tokenListings)
        .where(and(eq(tokenListings.contractAddress, contractAddress), eq(tokenListings.network, network)))
        .limit(1);
      const existingOwnerMatches = existing?.submittedByOpenId === ctx.user.openId;
      if (existing && !existingOwnerMatches) {
        throw new TRPCError({ code: "CONFLICT", message: "This token listing belongs to another account." });
      }
      if (input.resubmissionListingId) {
        if (!canResubmitRejectedListing({ existingId: existing?.id, existingStatus: existing?.status, existingOwnerMatches, resubmissionListingId: input.resubmissionListingId })) {
          throw new TRPCError({ code: "CONFLICT", message: "Only your rejected listing with this exact token identity can be resubmitted." });
        }
        await db.update(tokenListings).set({ ...values, rejectionReason: null }).where(eq(tokenListings.id, existing.id));
      } else if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "This token already has a listing. Open My Listings to view its status or resubmit a rejected listing." });
      } else {
        await db.insert(tokenListings).values(values);
      }

      const [row] = await db
        .select()
        .from(tokenListings)
        .where(and(eq(tokenListings.contractAddress, contractAddress), eq(tokenListings.network, network)))
        .limit(1);
      if (row) await syncAssetFromListing(row);
      if (row) {
        await db.insert(listingEvents).values({
          listingId: row.id,
          eventType: input.resubmissionListingId ? "resubmitted" : autoVerified ? "auto_verified" : "submitted",
          actorOpenId: ctx.user.openId,
          feeTxHash: input.feeTxHash,
          message: autoVerified
            ? "Payment verified and listing automatically approved after liquidity verification."
            : input.resubmissionListingId
              ? "Listing resubmitted after the prior rejection; payment evidence was verified again."
              : "Listing fee payment verified and submission placed in the review queue.",
        });
      }
      await recordFee({
        userOpenId: ctx.user.openId,
        operation: "listing",
        chainType: network,
        inputAmountUsd: "0",
        networkFeeEstimateUsd: "0",
        transactionHash: input.feeTxHash,
        status: "confirmed",
      });

      return { success: true, autoVerified, liquidityUsd } as const;
    }),

  /**
   * Used by the token-creation flow (factory contract deploy) once the
   * on-chain deployment tx confirms. The separate backend-configured creation
   * fee is verified
   * on-chain the same way as the listing fee. Verified immediately on
   * success - Paxi minted it, so there's nothing to review.
   */
  recordCreatedToken: protectedProcedure
    .input(
      z.object({
        ...networkAndAddress,
        symbol: z.string().min(1).max(32),
        name: z.string().min(1).max(128),
        logo: logoDataUrl,
        socials: socialsSchema.optional(),
        walletAddress: z.string().trim().min(1).max(128),
        initialSupply: z.string().trim().regex(/^(?:0|[1-9]\d{0,30})(?:\.\d{1,18})?$/),
        feeTxHash: z.string().trim().min(1).max(128),
        deploymentTxHash: z.string().trim().min(1).max(128),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const { network, contractAddress } = canonicalTokenInput(input.network, input.contractAddress);
      let creatorAddress: string;
      try {
        const adapter = getChainAdapter(network);
        creatorAddress = requireValidIdentifier(adapter, input.walletAddress);
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid creator wallet address." });
      }

      const creationDeployment = await verifyTokenDeployment(network, input.deploymentTxHash, creatorAddress, contractAddress);
      if (!creationDeployment.ok) throw new TRPCError({ code: "BAD_REQUEST", message: creationDeployment.reason });

      const creationFeeUsd = await getFixedFeeUsd("create_token", network);
      const verification = await verifyFeePayment(network, input.feeTxHash, creationFeeUsd);
      if (!verification.ok) {
        throw new TRPCError({ code: "BAD_REQUEST", message: verification.reason });
      }
      await assertFeeNotReused(db, input.feeTxHash, contractAddress, network);

      const { buffer, contentType, ext } = decodeLogo(input.logo);
      const { key } = await storagePut(`token-logos/${network}-${contractAddress}.${ext}`, buffer, contentType);

      const values: InsertTokenListing = {
        contractAddress,
        network,
        symbol: input.symbol,
        name: input.name,
        logoKey: key,
        source: "created",
        status: "verified",
        socials: input.socials,
        feeTxHash: input.feeTxHash,
        feeAmountUsd: creationFeeUsd,
        submittedByOpenId: ctx.user.openId,
        reviewedByOpenId: ctx.user.openId,
      };

      const [existing] = await db
        .select({ id: tokenListings.id, source: tokenListings.source, submittedByOpenId: tokenListings.submittedByOpenId })
        .from(tokenListings)
        .where(and(eq(tokenListings.contractAddress, contractAddress), eq(tokenListings.network, network)))
        .limit(1);
      if (existing && (existing.source !== "created" || existing.submittedByOpenId !== ctx.user.openId)) {
        throw new TRPCError({ code: "CONFLICT", message: "This token listing already exists and cannot be replaced." });
      }
      if (existing) {
        await db.update(tokenListings).set(values).where(eq(tokenListings.id, existing.id));
      } else {
        await db.insert(tokenListings).values(values);
      }

      const [row] = await db
        .select()
        .from(tokenListings)
        .where(and(eq(tokenListings.contractAddress, contractAddress), eq(tokenListings.network, network)))
        .limit(1);
      if (row) await syncAssetFromListing(row);
      const [assetRow] = await db
        .select({ id: assets.id })
        .from(assets)
        .where(and(eq(assets.chainId, network), eq(assets.identifier, normalizeIdentifier(network, contractAddress))))
        .limit(1);
      await recordActivity({
        userOpenId: ctx.user.openId,
        walletAddress: creatorAddress,
        chainId: network,
        eventType: "token_creation",
        transactionHash: input.deploymentTxHash,
        assetId: assetRow?.id ?? null,
        amount: input.initialSupply,
        amountUsd: "0",
        feeUsd: creationFeeUsd,
        networkFeeUsd: "0",
        paxiFeeUsd: creationFeeUsd,
        verificationSource: "server_internal",
        amountUsdSource: "server_internal",
        status: "confirmed",
      });
      await enqueueMarketTask({ type: "market.discover", chainId: network });
      if (assetRow) await enqueueMarketTask({ type: "metadata.refresh", chainId: network, assetId: assetRow.id });
      await recordFee({
        userOpenId: ctx.user.openId,
        operation: "create_token",
        chainType: network,
        inputAmountUsd: "0",
        networkFeeEstimateUsd: "0",
        transactionHash: input.feeTxHash,
        status: "confirmed",
      });

      return { success: true } as const;
    }),

  // --- Admin ---

  adminListPending: adminPermissionProcedure("assets.read").query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(tokenListings).where(eq(tokenListings.status, "pending")).orderBy(desc(tokenListings.createdAt)).limit(500);
  }),

  adminReview: adminPermissionProcedure("assets.verify")
    .input(
      z.object({
        id: z.number(),
        decision: z.enum(["verified", "rejected"]),
        rejectionReason: z.string().trim().max(2000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const result = await db
        .update(tokenListings)
        .set({
          status: input.decision,
          reviewedByOpenId: ctx.user.openId,
          rejectionReason: input.decision === "rejected" ? input.rejectionReason ?? "Not specified" : null,
        })
        .where(and(eq(tokenListings.id, input.id), eq(tokenListings.status, "pending")));
      if (Number((result as { affectedRows?: number }).affectedRows ?? 0) !== 1) {
        throw new TRPCError({ code: "CONFLICT", message: "This listing is no longer awaiting review." });
      }

      const [row] = await db.select().from(tokenListings).where(eq(tokenListings.id, input.id)).limit(1);
      if (row) await syncAssetFromListing(row);
      if (row) {
        await db.insert(listingEvents).values({
          listingId: row.id,
          eventType: input.decision,
          actorOpenId: ctx.user.openId,
          message: input.decision === "verified" ? "Listing approved by PAXI review." : row.rejectionReason ?? "Listing rejected by PAXI review.",
        });
        await db.insert(adminAuditEvents).values({
          actorOpenId: ctx.user.openId,
          action: input.decision === "verified" ? "APPROVE_TOKEN_LISTING" : "REJECT_TOKEN_LISTING",
          resourceType: "token_listing",
          resourceId: row.id,
          details: { decision: input.decision, rejectionReason: input.decision === "rejected" ? row.rejectionReason ?? null : null },
        });
      }

      return { success: true } as const;
    }),
});
