import { describe, expect, it } from "vitest";
import { getSessionCookieOptions } from "./_core/cookies";
import { CircuitBreaker, CircuitOpenError } from "./resilience/circuitBreaker";
import { verifyFeePayment, verifyTokenTransferProof } from "./feeVerification";

describe("security hardening", () => {
  it("uses safe local cookie flags for HTTP development", () => {
    const options = getSessionCookieOptions({ protocol: "http", secure: false } as any);
    expect(options).toMatchObject({ httpOnly: true, sameSite: "lax", secure: false, path: "/" });
  });

  it("uses cross-site OAuth cookie flags only for trusted HTTPS requests", () => {
    const options = getSessionCookieOptions({ protocol: "https", secure: true } as any);
    expect(options).toMatchObject({ httpOnly: true, sameSite: "none", secure: true, path: "/" });
  });

  it("rejects malformed financial verification inputs before any RPC call", async () => {
    await expect(verifyFeePayment("bsc", "not-a-hash", "1")).resolves.toMatchObject({ ok: false });
    await expect(verifyTokenTransferProof("bsc", "not-a-hash", "not-an-address", "not-an-address", "1")).resolves.toMatchObject({ ok: false });
  });

  it("opens after repeated failures and permits one half-open recovery request", async () => {
    const breaker = new CircuitBreaker("test", { failureThreshold: 2, resetTimeoutMs: 10 });
    const fail = () => Promise.reject(new Error("upstream failed"));

    await expect(breaker.execute(fail)).rejects.toThrow("upstream failed");
    await expect(breaker.execute(fail)).rejects.toThrow("upstream failed");
    await expect(breaker.execute(async () => "blocked")).rejects.toBeInstanceOf(CircuitOpenError);

    await new Promise((resolve) => setTimeout(resolve, 15));
    await expect(breaker.execute(async () => "recovered")).resolves.toBe("recovered");
    expect(breaker.status).toBe("closed");
  });
});
