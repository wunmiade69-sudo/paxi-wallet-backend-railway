/**
 * Seeds the well-known tokens promised early on: USDT/USDC/WETH/WBNB should
 * show a logo automatically the moment anyone imports them, without needing
 * to be submitted or paid for - they're already known-legitimate.
 *
 * Run once (safe to re-run, it upserts):
 *   npx tsx server/seedTrustedTokens.ts
 *
 * Logos are linked from Trust Wallet's public assets repo rather than
 * uploaded through storagePut, since there's nothing to review here and no
 * network access to fetch/re-host images from this environment.
 */
import "dotenv/config";
import { eq, and } from "drizzle-orm";
import { getDb } from "./db";
import { tokenListings, type InsertTokenListing } from "../drizzle/schema";
import { seedChains, syncAssetFromListing } from "./assetRegistry";

const TW_BASE = "https://raw.githubusercontent.com/trustwallet/assets/master/blockchains";

const SEED_TOKENS: Array<{
  network: string;
  contractAddress: string;
  symbol: string;
  name: string;
  logoUrl: string;
}> = [
  {
    network: "ethereum",
    contractAddress: "0xdac17f958d2ee523a2206206994597c13d831ec",
    symbol: "USDT",
    name: "Tether USD",
    logoUrl: `${TW_BASE}/ethereum/assets/0xdAC17F958D2ee523a2206206994597C13D831ec/logo.png`,
  },
  {
    network: "ethereum",
    contractAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
    symbol: "USDC",
    name: "USD Coin",
    logoUrl: `${TW_BASE}/ethereum/assets/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48/logo.png`,
  },
  {
    network: "ethereum",
    contractAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
    symbol: "WETH",
    name: "Wrapped Ether",
    logoUrl: `${TW_BASE}/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png`,
  },
  {
    network: "bsc",
    contractAddress: "0x55d398326f99059ff775485246999027b3197955",
    symbol: "USDT",
    name: "Tether USD",
    logoUrl: `${TW_BASE}/smartchain/assets/0x55d398326f99059fF775485246999027B3197955/logo.png`,
  },
  {
    network: "bsc",
    contractAddress: "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d",
    symbol: "USDC",
    name: "USD Coin",
    logoUrl: `${TW_BASE}/smartchain/assets/0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d/logo.png`,
  },
  {
    network: "bsc",
    contractAddress: "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c",
    symbol: "WBNB",
    name: "Wrapped BNB",
    logoUrl: `${TW_BASE}/smartchain/assets/0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c/logo.png`,
  },
];

async function main() {
  const db = await getDb();
  if (!db) {
    console.error("No database connection - check DATABASE_URL is set.");
    process.exit(1);
  }

  // Chains must exist before assets can reference them (assets.chainId -> chains.id FK).
  await seedChains();

  for (const t of SEED_TOKENS) {
    const values: InsertTokenListing = {
      contractAddress: t.contractAddress,
      network: t.network,
      symbol: t.symbol,
      name: t.name,
      logoUrl: t.logoUrl,
      source: "seed",
      status: "verified",
    };
    await db.insert(tokenListings).values(values).onDuplicateKeyUpdate({ set: values });

    const [row] = await db
      .select()
      .from(tokenListings)
      .where(and(eq(tokenListings.contractAddress, t.contractAddress), eq(tokenListings.network, t.network)))
      .limit(1);
    if (row) await syncAssetFromListing(row);

    console.log(`Seeded ${t.symbol} on ${t.network}`);
  }

  console.log("Done.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
