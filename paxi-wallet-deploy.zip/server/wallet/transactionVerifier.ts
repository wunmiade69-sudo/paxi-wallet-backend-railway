import { ethers } from "ethers";
import { getCircuitBreaker } from "../resilience/circuitBreaker";
import { getChainAdapter } from "../chains/registry";
import { requireValidIdentifier } from "../chains/types";
import { decodeEvmActivity, type DecodedEvmActivity } from "./activityDecoder";

export interface VerifiedTransaction extends DecodedEvmActivity {
  walletAddress: string;
  chainId: string;
  transactionHash: string;
  blockTimestampMs: number | null;
}

const TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;

function configuredBridgeAddresses(): Set<string> {
  return new Set(
    (process.env.PAXI_TRUSTED_BRIDGE_ADDRESSES ?? "")
      .split(",")
      .map((value) => value.trim().toLowerCase())
      .filter((value) => ethers.isAddress(value)),
  );
}

/**
 * Confirms a mined EVM transaction, proves wallet involvement, and derives the
 * operation/amounts from receipt semantics. Client-provided event labels and
 * USD values are deliberately not accepted here.
 */
export async function verifyConfirmedEvmTransaction(
  network: string,
  walletAddress: string,
  transactionHash: string,
): Promise<VerifiedTransaction> {
  if (!TX_HASH_RE.test(transactionHash)) throw new Error("Invalid EVM transaction hash");
  const adapter = getChainAdapter(network.toLowerCase());
  if (adapter.family !== "evm" || !adapter.rpcUrl) throw new Error("Server transaction verification is not available for this network");
  const normalizedWallet = requireValidIdentifier(adapter, walletAddress);
  const provider = new ethers.JsonRpcProvider(adapter.rpcUrl, undefined, { staticNetwork: true, batchMaxCount: 1 });
  const breaker = getCircuitBreaker(`activity-rpc-${adapter.network}`, { failureThreshold: 5, resetTimeoutMs: 30_000 });
  const receipt = await breaker.execute(() => provider.getTransactionReceipt(transactionHash));
  if (!receipt) throw new Error("Transaction not found or not confirmed");
  if (receipt.status !== 1) throw new Error("Transaction failed on-chain");
  const transaction = await breaker.execute(() => provider.getTransaction(transactionHash));
  if (!transaction) throw new Error("Transaction details unavailable");
  const decoded = await decodeEvmActivity({
    network: adapter.network,
    walletAddress: normalizedWallet,
    transaction,
    receipt,
    provider,
    read: <T>(operation: () => Promise<T>) => breaker.execute(operation),
    trustedBridgeAddresses: configuredBridgeAddresses(),
  });
  const block = await breaker.execute(() => provider.getBlock(receipt.blockNumber));
  const blockTimestampMs = block?.timestamp != null ? block.timestamp * 1000 : null;
  return {
    walletAddress: normalizedWallet,
    chainId: adapter.network,
    transactionHash,
    blockTimestampMs,
    ...decoded,
  };
}
