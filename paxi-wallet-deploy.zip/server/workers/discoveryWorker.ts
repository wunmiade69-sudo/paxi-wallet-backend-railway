import { persistDexSnapshot, DexScreenerPairRaw } from "../dexLiquidity";

/**
 * Phase 3C - Market Discovery Worker
 * 
 * Discovers new pools and markets for a specific chain using 
 * DexScreener's latest pools/search API.
 */
export async function processMarketDiscovery(chainId: string) {
  console.log(`[discovery-worker] discovering markets for chain: ${chainId}`);
  
  // DexScreener search API can be used to find latest/active pools by chain name
  const url = `https://api.dexscreener.com/latest/dex/search?q=${chainId}`;
  
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!res.ok) {
      throw new Error(`DexScreener discovery failed: ${res.status}`);
    }
    
    const data = await res.json();
    const pairs: DexScreenerPairRaw[] = data.pairs ?? [];
    
    console.log(`[discovery-worker] found ${pairs.length} pairs for ${chainId}`);
    
    // Limit to top 20 pairs by liquidity to avoid overloading the DB in one go
    const topPairs = pairs
      .filter(p => p.chainId === chainId)
      .sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))
      .slice(0, 20);

    for (const pair of topPairs) {
      try {
        // persistDexSnapshot handles:
        // 1. getOrCreateAsset for both tokens
        // 2. getOrRegisterDexId for the venue
        // 3. Upserting liquidityPools
        // 4. Upserting markets
        // 5. Upserting assetMarketData
        await persistDexSnapshot(chainId, pair.baseToken.address, pair);
      } catch (err) {
        console.warn(`[discovery-worker] failed to persist pair ${pair.pairAddress}:`, err);
      }
    }
    
    console.log(`[discovery-worker] discovery completed for ${chainId}`);
  } catch (err) {
    console.error(`[discovery-worker] discovery failed for ${chainId}:`, err);
    throw err;
  }
}
