import { eq } from "drizzle-orm";
import { assetMetadata, assets } from "../../drizzle/schema";
import { getDb } from "../db";
import { DexScreenerPairRaw } from "../dexLiquidity";
import { persistAssetRisk } from "../riskEngine";

/**
 * Phase 5 - Token Metadata Worker
 * 
 * Fetches extended token information (socials, description, creator) 
 * and calculates/updates risk scores.
 */
export async function processMetadataRefresh(assetId: number) {
  const db = await getDb();
  if (!db) return;

  const [asset] = await db.select().from(assets).where(eq(assets.id, assetId)).limit(1);
  if (!asset) {
    throw new Error(`Asset not found: ${assetId}`);
  }

  console.log(`[metadata-worker] refreshing metadata for ${asset.chainId}:${asset.identifier}`);

  // Fetch data from DexScreener to get socials/website
  const dexUrl = `https://api.dexscreener.com/latest/dex/tokens/${asset.identifier}`;
  try {
    const res = await fetch(dexUrl, { signal: AbortSignal.timeout(8000) });
    if (res.ok) {
      const data = await res.json();
      const pairs: DexScreenerPairRaw[] = data.pairs ?? [];
      const bestPair = pairs.find(p => p.chainId === asset.chainId) || pairs[0];

      if (bestPair) {
        const info = bestPair.info;
        const websites = info?.websites ?? [];
        const socials = info?.socials ?? [];

        const website = websites[0]?.url ?? null;
        const twitter = socials.find(s => s.type === "twitter")?.url ?? null;
        const telegram = socials.find(s => s.type === "telegram")?.url ?? null;
        const discord = socials.find(s => s.type === "discord")?.url ?? null;

        const metadataValues = {
          assetId: asset.id,
          website,
          twitter,
          telegram,
          discord,
          updatedAt: new Date(),
        };

        await db.insert(assetMetadata).values(metadataValues).onDuplicateKeyUpdate({ set: metadataValues });
      }
    }
  } catch (err) {
    console.warn(`[metadata-worker] failed to fetch from DexScreener:`, err);
  }

  const risk = await persistAssetRisk(asset.id, asset.chainId, asset.identifier);
  console.log(`[metadata-worker] metadata and risk updated for asset ${assetId} (${risk.label})`);
}
